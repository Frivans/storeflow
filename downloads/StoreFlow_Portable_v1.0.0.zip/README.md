STOREFLOW RETAIL POS - README
Read this first. The full guide is in MANUAL.md next to it. The licence terms you
accepted are in EULA.txt.

WHAT IS IN THIS FOLDER
   StoreFlow.exe        Start the till with this. Double-click it.
   Stop_StoreFlow.bat   Close the till cleanly.
   Create_Desktop_Shortcut.bat   Puts a StoreFlow icon on the desktop.
   index.html, api, assets, router.php, sw.js, php   The program itself, including a
                     private copy of PHP. You do not need XAMPP, and you must not
                     install StoreFlow beside a web server you already run unless you
                     know why you are doing it.
   data\                Everything the shop records goes here. This is the folder that
                     matters. Nothing else in this directory is your business.
                     Copy it, back it up, or move it only when StoreFlow is stopped - a
                     live copy catches the book half-written.
   RELEASE_MANIFEST.txt Which build this is. Keep the zip it came in - support asks for it.

WHAT YOUR COMPUTER NEEDS
   The licence only promises the program works on a machine that meets these, so read them
   before anyone buys hardware - and hand this list to whoever sells it to you.
     - A 64-bit Windows PC to run the server. Windows 10 or 11 is the safe choice: the
       launcher is compiled against .NET Framework 4, which those already carry. Any
       desktop, mini PC or laptop of the last few years is enough; it does not need to be fast.
     - That machine switched on while the shop trades. Its window IS the server - close it,
       or let the PC sleep, and every counter stops. A surge protector at the very least,
       and a UPS where power goes often.
     - About 25 MB for the program itself, plus room for the records and for a week of
       automatic backups in data\backups. Give it a few hundred MB and keep the folder on a
       disk that is not nearly full.
     - A free port on that machine - 8095 by default. Whatever already holds it (a second
       copy of StoreFlow, some printer software) has to move.
     - A browser on each device that opens the till. On the machine that prints receipts,
       use Chrome, Edge or Opera if you want the paper to come straight out of a thermal
       printer over Web Serial; other browsers still print, through their own print dialog.
     - A barcode scanner that types like a keyboard - the ordinary USB kind. No driver, no
       setup. A cash drawer is kicked by the receipt printer, so the printer you choose has
       to support that pulse if you want the drawer to open by itself.
     - A secure (https) address for a phone, if a phone is to be the scanner or an aisle
       till must reach the till from outside the shop Wi-Fi. A phone browser will not switch
       its camera on over plain http. See "RUNNING IT ON A SECOND REGISTER" below and
       MANUAL.md section 11.3.
   It needs no XAMPP, no MySQL, no Node.js and no internet connection to run a sale.
   Use the php folder that comes in this package: it is the copy StoreFlow was built
   against, and it already has switched on the one PHP extension the licence check needs
   (sodium). If you start StoreFlow with a PHP of your own instead, enable
   extension=sodium in its php.ini first - without it no activation key can be verified,
   and the till says that out loud rather than calling your good key bad.

FIRST TIME
 1. Put the whole folder somewhere you can find it: C:\StoreFlow is the usual choice.
    Do not run it out of the zip. Extract it first.
 2. Double-click StoreFlow.exe. A small window opens and stays open - that window IS
    the till's server. Closing it stops the shop. Your browser opens on
    http://127.0.0.1:8095
 3. Windows may say "Windows protected your PC", because the launcher is not
    code-signed. Choose More info -> Run anyway. See SUPPORT below if you would rather
    not have to explain that to every staff member.
 4. Sign in as user "admin" with password "admin123" unless the seller handed you a
    different one. The till will refuse to let you do anything until
    you change it - that is deliberate, not a fault. Pick a password you will still know
    in a year, and write it down somewhere that is not taped to the till.
 5. Open Help (F1) -> About. Copy the Machine ID shown there and send it to the seller
    with your payment or trial request. Paste the key you get back into the activation box.
    Evaluation keys run for a standard 14 days (or the duration agreed with your seller);
    lifetime commercial keys never expire. The till checks the key on this machine and
    needs no internet to do it.
 6. Store Profile & Receipts - the Administration item on the left, or press Alt + 0:
    store name, phone, currency, receipt wording, tax rate if your
    country prints it on receipts. This same screen holds the points scheme, the interval
    of the automatic backup, and the switches that show or hide the hire desk and the
    dining floor. Check a printed receipt before you serve a customer.

EVERY DAY
   Open the shift with the morning float. Close it at night and reconcile the drawer.
   Keep the till's computer plugged into a surge protector, and if power goes often in
   your area, into a UPS. MANUAL.md sections 3 and 4 cover this properly.

BACK UP - THIS IS THE ONE THOU SHALT DO
   StoreFlow writes a backup into data\backups every two hours and keeps seven days of
   them, on the same disk as the working file. That is not enough. Once a week:
       the "2-Hour Backups" item in the left-hand menu -> Create Encrypted Copy
   Type a passphrase you will still know next year, write it on paper, keep the paper
   apart from the file, and save the .sfbak on a USB stick or another computer. When the
   till's disk dies - and disks do die - the shop's entire history is whatever is on
   that stick.
   The passphrase is never stored anywhere, not with the seller. Lose it and that file
   cannot be opened by anyone at all, so the copy is worthless. That is the price of a
   backup that is safe to keep outside the shop; EULA.txt section 7 says so in full.
   To put a copy back: the same screen, choose the .sfbak, type its passphrase and press
   Decrypt & Restore. StoreFlow saves today's state first, so a wrong choice is undoable.
   The list on that screen labels every file it holds - Auto (2hr), Manual, Safety (the
   copy taken just before a restore, so a restore can be undone), Uploaded, or Imported
   (encrypted). Read the label before you restore anything: a file from another machine
   is not the same thing as this week's automatic snapshot.

RUNNING IT ON A SECOND REGISTER, OR A PHONE AS A SCANNER
   By default the till answers its own computer only. Other machines on your shop Wi-Fi get
   in once a file named lan-mode.txt sits next to StoreFlow.exe - and you do not have to make
   that file by hand. The first time you open Phone Scanner Gun or the device hub, the till
   writes lan-mode.txt itself and says to restart; restart once, and a second register can
   then open http://YOUR-TILLS-IP:8095.
   Know what that switch is worth. From then on, any device that reaches your shop network
   can reach the sign-in page. The till is only as safe as its passwords after that, so give
   every cashier their own user and change the owner password before you open the network
   (MANUAL.md section 2.4). To shut the door again, delete lan-mode.txt and restart - and
   understand that opening the pairing screen writes the file back.
   Every device pointed at that one machine runs under that machine's licence: a second
   counter is not a second purchase. A location that has to keep its own records is a
   different matter - its own copy, its own key, and a book that never merges with yours.
   EULA.txt section 2 says so in full.
   A phone or a small tablet shown that address rearranges the till for the screen it is
   on: the product grid becomes two columns of short cards with the price along the
   bottom of each, so an attendant can ring a sale from the aisle. It is the same till
   with the same numbers, not a reduced version of it.
   The phone scanner: Help or the sidebar button Phone Scanner Gun shows a QR to aim the
   phone's camera at. A phone browser only switches on its camera for a secure (https)
   address, so over plain shop Wi-Fi the page opens but the viewfinder stays dead. The
   tunnel in MANUAL.md section 11.3 gives the till a real https address and the camera
   works from anywhere.

GETTING AN UPDATE
   An update cannot lose your records: the update package carries no database, no backups and
   no sales - the folder that holds them, data\, is shipped with nothing in it but the three
   small guard files that keep a web server from listing it. Even so, do it in this order:
     1. Close the till with Stop_StoreFlow.bat.
     2. Take an encrypted copy (the weekly one above) and keep it somewhere safe.
     3. Extract the new package over your existing StoreFlow folder, letting Windows
        replace the program files it asks about. It will ask about the guard files in
        data\ and data\backups; they hold none of your records, and replacing them is
        harmless. Say no to anything else it offers to replace if you are unsure.
     4. Start StoreFlow.exe and check the release number in Help -> About is the new one,
        and that yesterday's sales are still there.
     5. Only then delete the old zip.
   Never do this with two copies of StoreFlow on one computer both pointing at different
   data folders - that is two shops, each with half your sales.

MOVING TO A NEW COMPUTER
   Copy the whole StoreFlow folder, including data, to the new machine, then ask the
   seller for a key for it: the licence is tied to this install's identity, which is the
   computer's name together with a value created the first time StoreFlow ran there. Both
   live inside data\. So renaming this PC, reinstalling Windows, or deleting data\ changes
   that identity, the key you hold stops matching, and the till asks for a new one.
   The old machine should stop being used as a till.
   If the disk went rather than the computer, start StoreFlow fresh on the new one and
   use Decrypt & Restore on your weekly .sfbak instead - that is what the encrypted copy
   is for, and it is why the copy lives away from the till rather than beside it.

STOPPING IT / UNINSTALLING
   Stop_StoreFlow.bat, or close the launcher window. StoreFlow writes nothing to the
   Windows registry and installs no service; to remove it, delete the folder. That
   deletes the shop's records with it, so export first and keep the export.

SUPPORT
   Frimpong Evans (Exhibit) - Frivans Technologies
   Email    www.frivans@gmail.com
   Phone    +233 24 834 3007 (calls and WhatsApp)
   The same details are at the top of EULA.txt, which is the agreement you accepted.
   Send three things in the first
   message and you will get an answer faster: the Machine ID and release number from
   Help -> About, the contents of RELEASE_MANIFEST.txt, and what you were doing when it
   went wrong.

   The launcher is unsigned, so Windows may warn each staff member who opens it. To
   stop that, the seller can buy a code-signing certificate; until they have, run the
   till from a shortcut made by Create_Desktop_Shortcut.bat and expect to answer the
   warning once per machine.

A TILL IS NOT A GENERAL-PURPOSE COMPUTER
   Do not browse, install games, or run other servers on the machine that holds your
   shop's accounts. Whatever breaks a normal PC breaks a till, and a till has no second
   copy of anything.
