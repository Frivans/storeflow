# StoreFlow POS & Inventory Manager — Comprehensive Operations Manual
**Version:** 1.0.0 (Production Enterprise Edition)  
**Target Audience:** Store Owners, General Managers, Accountants, Inventory Supervisors, and POS Cashiers

---

## Table of Contents
1. [System Overview & Architecture](#1-system-overview--architecture)
2. [First-Time Setup, License & Store Branding](#2-first-time-setup-license--store-branding)
3. [Cashier Shifts & Opening Float Management](#3-cashier-shifts--opening-float-management)
4. [Point of Sale (POS) & Checkout Guide](#4-point-of-sale-pos--checkout-guide)
5. [Products Catalog & Wholesale Packaging (UOM)](#5-products-catalog--wholesale-packaging-uom)
6. [Barcode & Shelf Tag Printing Studio](#6-barcode--shelf-tag-printing-studio)
7. [Inventory Management & Batch/Expiry Tracking](#7-inventory-management--batchexpiry-tracking)
8. [Factory Purchases & Supplier (Vendor) Accounts](#8-factory-purchases--supplier-vendor-accounts)
9. [Returns, Refunds & Accounting Precision](#9-returns-refunds--accounting-precision)
10. [Expenses, Customer Debts & Financial Ledgers](#10-expenses-customer-debts--financial-ledgers)
11. [Multi-Device Networking & Phone Barcode Scanner](#11-multi-device-networking--phone-barcode-scanner)
12. [Automated 2-Hour Backups & Security Safeguards](#12-automated-2-hour-backups--security-safeguards)
13. [Keyboard Hotkeys Quick Reference](#13-keyboard-hotkeys-quick-reference)

---

## 1. System Overview & Architecture

StoreFlow is an enterprise-grade, offline-first Point of Sale (POS) and inventory management software engineered for retail shops, supermarkets, pharmaceutical distributors, wholesale depots, and commercial farm stores.

### Key Architectural Pillars
* **True Offline-First Operation:** Operates 100% locally in the web browser using IndexedDB (`Dexie.js`). Internet or LAN outages will never halt checkout.
* **Your records stay in your shop:** The till keeps its books in a database inside the `data` folder on your own computer, with Write-Ahead Logging (`WAL`) so a power cut in the middle of a sale cannot leave a half-written record. No StoreFlow server holds any of it, because there is no StoreFlow server.
* **Cross-Tab & Device Live Sync:** Changes made at counter 1 (sales, returns, inventory edits) automatically update counter 2 within 50 milliseconds via `BroadcastChannel` and local delta polling.
* **Portable Runtime:** Can be run on any Windows PC via `StoreFlow_Portable.zip` without installing XAMPP, MySQL, or Node.js.

---

## 2. First-Time Setup, License & Store Branding

### 2.1 Choosing How to Run StoreFlow
StoreFlow runs on a small PHP server, and there are two supported ways to start it.

**A. The bundled runtime (recommended for a shop till).**
Double-click **`StoreFlow.exe`**. It starts its own PHP 8.2 server with every extension
StoreFlow needs already switched on, and opens the till at `http://127.0.0.1:8095`.
Nothing is installed, nothing else has to be configured. Stop it with
**`Stop_StoreFlow.bat`**. Use this route on any machine where nobody is comfortable
administering a web server.

That server answers **its own machine only**, which is the safer default for a counter till.
The switch that lets a second register, a tablet or a phone scanner reach it over the shop Wi-Fi
is a file named **`lan-mode.txt`** next to `StoreFlow.exe` — and you do not have to build it by
hand. The first time you open **Phone Scanner Gun** or the device hub, the till writes
`lan-mode.txt` itself and asks you to restart; restart once and the other machines connect.
Delete the file and restart to put the till back to serving only itself, and know that opening
the pairing screen writes it again. Section 11.4 says what that door is worth; section 2.4 is
the password work to do before you open it.

**B. Your own Apache / XAMPP.**
For a shop that already runs XAMPP, or a hosting account:

1. Put the StoreFlow folder in the web root — e.g. `C:\xampp\htdocs\storemgt` — and open
   `http://localhost/storemgt/`.
2. Use **PHP 8.1 or newer**, and leave the `.htaccess` files that ship inside the folder
   where they are. They are what keeps StoreFlow's data and settings from being readable
   through the web address bar.
3. Switch on the **sodium** extension (see below) *before* you try to activate.

### 2.2 Enabling sodium (required to activate)
StoreFlow checks every activation key against a cryptographic signature, and the check is
performed by the PHP **sodium** extension. Without it StoreFlow refuses *all* keys —
including genuine ones — rather than accepting a key it cannot verify. The bundled runtime
in route **A** already has it enabled.

If the activation screen shows a red box reading *"This StoreFlow install cannot verify
activation keys because the PHP sodium extension is not loaded"*, then the PHP serving the
page is missing it:

1. Open the `php.ini` that **Apache** actually loads. In the XAMPP Control Panel click
   **Config → PHP (php.ini)** on the Apache row. Editing some other `php.ini` on the
   machine changes nothing.
2. Find the line `;extension=sodium` and delete the leading semicolon, so it reads
   `extension=sodium`.
3. Save, then **Stop and Start Apache** from the Control Panel. A reload of the browser
   page is not enough — PHP reads `php.ini` only when the server process starts.
4. Reload StoreFlow. The red box is gone, and the key is checked normally.

If it still complains, you are almost certainly editing a different `php.ini` than the one
Apache reads. Check it from a command prompt inside your XAMPP `php` folder:

```
cd C:\xampp\php
php --ini
```

The line `Loaded Configuration File` names the file to edit. Then confirm the extension
itself is present — `C:\xampp\php\ext\php_sodium.dll` must exist. If that file is missing,
your XAMPP was built without sodium and needs reinstalling or a PHP upgrade.

### 2.3 License Activation
On a fresh installation, StoreFlow starts in **Activation Lock** mode:
1. Open the application in your browser.
2. In the Activation Modal, copy the **Machine ID** displayed for this install and send it to your seller to receive your **License Key**:
   - **Trial / Evaluation Key (Standard 14 Days, or as agreed with your seller):** Unlocks all features with a real-time countdown banner showing the agreed trial days remaining.
   - **Lifetime Commercial Key:** Unlocks perpetual enterprise access without expiration.
3. Once pasted, the key is verified locally against this install's identity (the computer's host name together with a value created in `data\` on first run — no internet connection required).

### 2.4 Change the owner password before the till goes on the network
A fresh install has one owner account, `admin`, with the password `admin123`. StoreFlow
will not let that account do any real work while the default password is still in place:
the first screen you see after signing in asks you to set a new master password and a
4-digit quick PIN. Do that **immediately** — before you add a cashier account, before a
second computer on the shop Wi-Fi can reach the till, and long before you share any link
to it. A till that still answers to `admin123` is a till anyone in the shop can empty.

* The new master password must not be `admin123` itself; the screen rejects it.
* The 4-digit PIN is only the shortcut for the lock screen, so treat it as a screen
  unlock, not as the secret that protects your books.
* Do this on the owner's own machine. Records staff accounts with their own passwords so
  you can tell whose shift a sale happened on (see §12.3).

### 2.5 Store Profile & Receipt Settings
Navigate to **Store Profile & Receipts** from the left sidebar:
* **Business Information:** Set Store Name, Tagline, Primary Phone, Support Email, and Physical Address.
* **Taxation / VAT:**
  - **TIN / GRA Number:** Enter your national tax registration number (printed on receipt headers).
  - **Default Tax / VAT Rate (%):** Set your applicable VAT rate (e.g. `0.5%`, `15%`, `21.9%`). If your business is VAT-exempt, leave at `0.0`.
  - **Show Tax on Receipt:** Toggle to display or hide the VAT breakdown row on printed slips.
* **Currency Symbol:** Set your primary trading currency (e.g., `GH₵`, `$`, `€`, `£`, `₦`, `KSh`).
* **Receipt Customization & Live Thermal Preview:**
  - **Paper Width:** Choose `58mm` (compact mobile receipt), `80mm` (standard high-speed thermal slip), or `A4/Letter` (wholesale invoice).
  - **Font Size & Weight:** Choose between Small, Normal, Medium, or Large font scales, and Light, Regular, or Bold font weights.
  - **Receipt Header & Footer Notes:** Enter personalized customer greetings or return policy text (e.g. *"Goods received in good condition cannot be returned after 48 hours"*).
  - **Mobile Money (MoMo) Prompt:** Add official store merchant payment lines (e.g., *"MoMo Pay: 024XXXXXXX (Store Enterprise)"*).

---

## 3. Cashier Shifts & Opening Float Management

StoreFlow enforces strict cash drawer accountability to eliminate register shortages and unaccounted pilferage.

### 3.1 Morning Opening Float
At the start of every business day:
1. Click the **Shift / Float** button on the POS top bar.
2. Select **Open New Shift**.
3. Enter the **Opening Cash Float** (the initial cash bills and coins provided to the drawer for giving change, e.g. `GH₵200.00`).
4. Enter any opening notes and click **Start Register Shift**.

### 3.2 Mid-Day Shift Handover / Audit
At any time during the day:
* The supervisor or cashier can open **Shift / Float** to view:
  - Total Cash Sales processed during the shift.
  - Total Cash Refunds paid out.
  - Total Petty Cash Expenses paid from the drawer.
  - Expected Drawer Cash balance.

### 3.3 Closing Register Shift & Drawer Reconciliation
At the end of the cashier's shift:
1. Click **Shift / Float &rarr; Close Register Shift**.
2. Count the physical cash in the cash drawer and type the figure into **Counted Cash in Drawer**.
3. StoreFlow immediately computes the reconciliation discrepancy:
   $$\text{Discrepancy} = \text{Counted Cash} - \text{Expected Cash}$$
   **Expected Cash** is what the shop's own book says this drawer holds over and above the
   float it started with:

   `Cash Sales + Cash Collected on Customer Debts + Cash Taken on Rentals − Petty Cash Paid from the Drawer − Cash Handed Back on Returns − Caution Deposits Refunded on Rentals`

   What came into the till's hands it watches for itself. What *left* the box is read off the
   shop's own books rather than typed into the close, and that is arithmetic rather than
   distrust: the figure able to forgive a shortage is the one a short drawer has the strongest
   reason to stretch. GH₵60.00 of generator fuel recorded on the expense screen and GH₵260.00
   of expenses typed into the close takes GH₵200.00 off the cash the drawer is expected to
   hold — so GH₵200.00 walked out of the box closes as **Balanced**, with a green light on the
   counter. StoreFlow subtracts the GH₵60.00 the book actually holds, and the GH₵200.00 shows
   as short.

   The same read works the other way for an honest till: GH₵1,000.00 of cash sales and a
   GH₵115.00 cash refund should expect GH₵885.00 over the float, and a cashier who counts
   GH₵985.00 and calls the difference a shortage has simply not counted that GH₵115.00 out of
   the box yet. The till will not let the close say otherwise either.
   - **Balanced ($0.00):** Perfect drawer count.
   - **Overpayment (+):** Cash surplus recorded with cashier notes.
   - **Shortage (-):** Flags red shortage alert to management.
4. Click **Finalize & Close Shift** to save the shift record and print the cashier Z-report.

Any cash handed back over credit notes appears as a red **Cash Back on Returns** line on the
close screen and as its own line on the printed Z-report, so the figure on the paper is the
same arithmetic the drawer was reconciled against.

Receipts voided during the shift (§4.6) are not inside any of these tender totals. They are
reported beside them, on a line reading **Voided (cash handed back, goods restocked)**, with
the count and the value of what was cancelled — because a drawer that cancelled four bills
and a drawer that cancelled none should not report the same cash.

### 3.4 The owner's Z-note by SMS
**Dispatch Z-Report Summary SMS to Store Owner** is ticked on the close screen (§3.3), and the
number it goes to is Settings → Store profile → **Owner/Manager Mobile Number**. Saving the
shift sends the day's reconciliation to that phone through mNotify; the same note can be sent
again from the Z-report screen at any time.

The note is a text version of the paper the cashier signs:

```
StoreFlow Z-Report: Shift Closed
Store: Ama's Provision (MAIN-01/REG-01)
Operator: Ama Mensah
Shift #: SHIFT-20261104-4821
Date: 2026-11-04 21:15:03
Gross Sales: GHS 1,450.00
Cash Sales: GHS 1,000.00
Debt Cash In: +GHS 40.00
Rental Cash In: +GHS 300.00
Drawer Expenses: -GHS 60.00
Refunds Paid Out: -GHS 115.00
Caution Refunded: -GHS 50.00
Drawer Cash: GHS 1,165.00 (Expected: GHS 1,165.00)
Non-Cash Sales: GHS 200.00
Voided: 2 receipt(s) (GHS 45.00) - cash handed back, goods restocked
Status: BALANCED
```

The two lines that carry the weight of the day are **Drawer Expenses** — petty cash that left
the box on the shop's recorded expense rows, such as GH₵60.00 of generator fuel — and
**Refunds Paid Out** — the GH₵115.00 of cash handed back to customers over credit notes (§9.1).
They are named rather than folded away, because a message reading "Cash Sales 1,000.00" above
"Expected 885.00" leaves an owner with a GH₵115.00 gap and no way to say where it went, and the
guess usually lands on the attendant. With both lines on the paper, the arithmetic is traceable
with a pencil: 1,000 + 40 + 300 − 60 − 115 − 50 = 1,115, plus the float the drawer opened with.

The note is composed from the shop's book, not from the figures the till typed. A close that has
been saved is repeated exactly as it was saved; a summary sent before that close reaches the
book — an offline day whose shift is still waiting in the till's outbox — has its payouts read
off the book and its Expected cash and Status worked out from them. That is deliberate: the
message the cashier cannot edit is the one that carries the shop's own arithmetic, so a till
that types GH₵260.00 of expenses against GH₵60.00 recorded still reads
**Status: SHORTAGE (-GHS 200.00)** on the owner's phone.

Nothing that did not happen is printed. A drawer with no payouts, no refunds and no rentals has
no line for them, because SMS is billed per message and every line costs the shop.

---

---

## 4. Point of Sale (POS) & Checkout Guide

The POS module is built for lightning-fast scanning and keyboard-driven retail checkout.

```
+-------------------------------------------------------------+
| [F2 Search Product] [Category Filter] [Scan] [Phone Scanner]|
+-------------------------------------------------------------+
| Product Grid Cards                      | Cart Summary      |
|                                         | ----------------- |
| [Item Card] [Item Card] [Item Card]     | Item x Qty  Price |
| [Item Card] [Item Card] [Item Card]     | Subtotal: GH₵...  |
|                                         | Tax:      GH₵...  |
|                                         | TOTAL:    GH₵...  |
|                                         | [F4 Pay] [F9 Fast]|
+-------------------------------------------------------------+
```

### 4.1 Adding Products to the Cart
* **Barcode Scanner:** Scan any product barcode; it immediately enters the cart and plays a subtle audio confirmation.
* **Product Grid:** Click or tap any product card on the left panel.
* **Keyboard Hotkey (<kbd>F2</kbd>):** Press <kbd>F2</kbd> to jump straight into the search box, type product name or SKU, and press <kbd>Enter</kbd> to add.
* **Grid Navigation:** Use arrow keys (<kbd>&uarr;</kbd> <kbd>&darr;</kbd> <kbd>&larr;</kbd> <kbd>&rarr;</kbd>) to navigate the product cards, then press <kbd>Enter</kbd>.

### 4.2 Adjusting Cart Quantities & Line-by-Line Discounts
* Click the **`+`** or **`-`** buttons on any cart row, or use keyboard hotkeys <kbd>+</kbd> and <kbd>-</kbd>.
* To remove an item, click the red **`&times;`** button.
* **Line-by-Line Item Discounts:** Turn on **"Enable Line-by-Line Discounts"** in *Settings &rarr; Store Profile & Receipts*. Every cart item displays a **`[🏷️ Disc]`** button. Cashiers can tap it to enter a percentage (e.g. `10%`) or a fixed cash deduction (e.g. `GH₵5.00`). Original unit prices are struck through and net line subtotals re-calculate in real time. Percentage discounts automatically scale if quantity is increased or decreased.
* **Cart-Level Discounts:** Enter a general cash discount in the **Discount** field below the cart subtotal. Total line discounts and cart discounts combine into a single reconciled discount ledger on the printed receipt.
* **Role Discount Ceilings:** How much discount an attendant may grant is set per role on the **Access Map** (§12.4), and
  the ceiling is enforced by the shop server, not only by the till. A GH₵40.00 reduction on a
  GH₵300.00 basket is 13.3%, so a role capped at 10% is refused with the figure named —
  *"This receipt is discounted by 40.00, which is over the 30.00 (10%) this role may give. A
  store manager or administrator must ring it up."* A ceiling of `0` means no discount at all.
  A role that is allowed to reprice lines outright (§12.4) is not capped, because the ceiling
  exists to stop a till writing a receipt down, and repricing is that permission taken openly.

### 4.3 Multi-Unit of Measure (UOM) Selling in Cart
If a product has wholesale packaging configured (e.g. Eggs sold by Crate or by Box):
1. Notice the unit toggle pill on the cart line item:
   ```
   [ Crate ]  [ Box (14x) ]
   ```
2. Click **`Box (14x)`** to switch to bulk packaging.
3. The cart automatically scales the price (e.g., $5 \text{ Boxes} \times \text{GH₵140.00} = \text{GH₵700.00}$) and indicates:
   `5 box (• = 70 crates)`.
4. When checkout completes, StoreFlow deducts the exact **70 base crates** from inventory.

### 4.4 Checkout & Payment Methods (<kbd>F4</kbd>)
Press <kbd>F4</kbd> (or click **Pay**) to open the Interactive Checkout Modal:

* **Cash Payment (<kbd>1</kbd> / <kbd>C</kbd>):**
  - Enter the cash amount handed by the customer.
  - StoreFlow calculates exact **Change Due**.
  - Quick Tender buttons: Click `Exact`, `+GH₵10`, `+GH₵20`, `+GH₵50`, or `+GH₵100`.
  - **Overpayment Deposit:** If the customer pays more than the bill and is a registered customer, check *"Apply overpayment to customer balance"* to credit their account instead of giving change.
* **Instant Fast Cash (<kbd>F9</kbd>):**
  - Pressing <kbd>F9</kbd> directly from the cart processes an exact-cash transaction in one click, registers the sale, and displays the receipt.
* **Mobile Money / Transfer (<kbd>3</kbd> / <kbd>M</kbd>):**
  - Select Transfer / MoMo, enter the transaction reference / network approval code, and complete.
* **Credit Card (<kbd>2</kbd> / <kbd>K</kbd>):**
  - Enter POS terminal reference / slip code and complete.
* **Split Tender (<kbd>5</kbd> / <kbd>S</kbd>):**
  - Combine multiple payment types (e.g., GH₵100 in Cash + GH₵111.05 via MoMo).
  - Click **Auto-fill Cash Remainder** to balance the tender automatically.
* **Buy on Credit / Customer Debt (<kbd>4</kbd> / <kbd>D</kbd>):**
  - Allows registered customers to buy on store credit.
  - Requires selecting a registered customer (Walk-in customers are blocked from taking credit).
  - Cashier can record an initial partial deposit; the remaining balance is automatically posted to the customer's ledger.

### 4.5 What a Product Card Shows
Every card in the grid carries the same things, in the same places, so an attendant reads
a price without hunting for it:

* **Product name**, with the **SKU** and the base unit (`pcs`, `crate`, `bottle`) underneath.
* **A stock number** beside the SKU: how many are left. It sits quiet in grey, turns
  orange once the count reaches the product's low-stock alert, and reads **Out** in red
  at zero. The number is a check, not the decision — the till refuses to sell what is not there.
* **An expiry date**, and only when it is a decision worth making at the till: the chip
  appears once the date comes inside the alert window set on that batch (§7.1), and turns
  red and reads **Expired** once it is past. A tin four years from its date does not wear
  the same badge as one that has to move this week.
* **The selling price**, along the bottom of the card, so a row of prices lines up. Where
  the product has wholesale packaging (§5.2) the pack price sits beside it — a box of 40
  crates shows `Crate: GH₵ 360.00` next to the single-crate price — so a customer asking
  for a carton is priced at the till instead of by a walk to the shelf.

On a phone or a small tablet the same grid rearranges itself: two columns of short cards,
a small thumbnail instead of a large photo box, the price still pinned to the bottom of
each card, and clearance below the last row so the running-total pill never sits over a
price. Six items are on the screen where four used to be. Nothing is hidden on the small
screen that is shown on the big one — only the space around it changes.

### 4.6 A Bill Keyed Wrong: Voiding a Receipt
A customer watches the number get printed. When the wrong item, the wrong quantity or the
wrong price is what came out, the receipt itself has to be cancelled — not quietly adjusted,
and not carried in the day's takings as a sale that nobody made.

**Void** is the door for that, on the receipt's row in **Sales History** and on the open
receipt slip. StoreFlow cancels the bill as though it was never rung:

1. Click **Void** and type a **Reason for voiding** — it is a required field. Write what
   actually happened (`Mis-ring, wrong items keyed, customer changed mind`), because this
   reason is stamped on the ledger, is read back at the shift count, and is the only
   explanation anyone will have in a fortnight.
2. Confirm **Void Receipt**.

What that does, all at once:

* **The goods go straight back on the shelf.** Every line is restocked at the quantity it
  was rung at, so the count on the till matches the shelf without a second job to do.
* **The receipt stays visible and says it is worth nothing.** Its printed total is struck
  through with **GH₵0.00** underneath and a red **VOIDED** badge beside it. Revenue, tax and
  gross profit all read zero — the bill is on the ledger as an event, not as takings.
* **Money and points given on it come back.** A deposit taken to a customer's credit account
  is put back on that account, the statement records the cancelled bill as charging nothing,
  and loyalty points earned on it are taken off the member's balance. The system stops at
  zero rather than going negative if the member has already spent some.
* **The paper stops being proof.** A reprinted slip carries
  **× VOIDED — THIS SLIP IS NOT PROOF OF PURCHASE** with the reason, the time and the name
  of whoever cancelled it.
* **It cannot also be returned.** The **Return** button goes away on a voided bill, so the
  same money cannot be refunded twice.

**Who can void, and until when.** Only a receipt from today, with nothing credited against
it, can be voided — and only by the attendant who rang it, or by a supervisor or manager.
Every other hand is refused, by the till and again by the shop server. That is the whole
difference between **Void** and a **Return**: a void is the counter correcting itself on its
own day; anything later than that, or anything where the customer really did buy and really
did bring the goods back, is a return (§9) and leaves its own credit note behind.

**Cash.** A void that had cash in it means cash has to leave the drawer again. Hand it to the
customer before the drawer is counted; the shift close (§3.3) reconciles against the money the
book says is still in, and a voided bill is not inside that figure.

**A void needs the shop server to see it.** A till that cannot reach it refuses and says so —
*"Nothing has been cancelled"* — rather than queueing a reversal the book has never heard of.

**If the bill settled a table tab.** Voiding the receipt does not re-open the tab it paid,
because the floor keeps its own record. The ledger line for the void names the tab, so the
person clearing the bill also learns whose party paid with it — re-raise the bill before that
customer is asked to pay again.

*Worked example.* Three tins at GH₵80.00 are rung as GH₵240.00 when the customer was being
charged for two at GH₵80.00 each — the till holder typed the wrong quantity and the receipt
went out. Cost of goods on that bill was GH₵180.00, and the member collected 240 points at
the shipped rate of one point per cedi. Voids cost nothing to unwind: today's cash sales fall
by GH₵240.00 rather than carrying a phantom sale, gross profit on the bill reads GH₵0.00, the
GH₵180.00 of stock is back on the shelf, the 240 points come off the member's balance (down
to zero if they have spent some, never below it), and the printed slip the customer is holding
reprints as cancelled. The customer is then rung the correct GH₵160.00 as a fresh bill.

---

## 5. Products Catalog & Wholesale Packaging (UOM)

### 5.1 Creating a Standard Product
1. Go to **Products Catalog &rarr; Add New Product** (or press <kbd>F3</kbd> / <kbd>Alt + N</kbd>).
2. Enter **Product Name**, **Category**, and **Base Unit** (`pcs`, `bottle`, `crate`, `bag`, `kg`, etc.).
3. Enter **Factory Cost Price** (what you pay the supplier) and **Selling Price** (retail price).
4. Enter **Initial Stock Quantity** and **Minimum Stock Alert Threshold** (default: 5).
5. (Optional) Scan or type the manufacturer's **Barcode**. If left blank, StoreFlow auto-generates a unique SKU.

### 5.1b Product Types: Standard Shelf Goods, Services & Combo/Bundle Packs
At the top of the **Add/Edit Product** modal, choose how the item behaves at the counter:
* **Standard Shelf Product (`standard`):** Physical goods tracked on the shelf with stock counts, optional FEFO batches, and wholesale pack sizes.
* **Service / Non-Stock Labor (`service`):** Delivery fees, installation charges, repairs, or service fees. Priced and printed on receipts without ever deducting or checking shelf stock.
* **Combo / Bundle Pack (`combo`):** A promotional hamper or bundle sold as a single receipt line (e.g. *"Party Pack"* containing `2 × Drink` + `10 × Plates`). Select the component products and quantities inside the modal; when the bundle is rung at the counter, StoreFlow charges the bundle's selling price while deducting each component product from the branch shelf automatically and computing the true combined factory cost.

### 5.2 Configuring Wholesale Packs / Boxes / Cartons / Crates (Multi-UOM)
For items you sell both individually and in one or more wholesale containers (up to 12 sellable sizes per product):
1. In the Add/Edit Product modal, scroll to **Sizes This Product Sells In** and click **+ Add a Pack Size**.
2. **Size:** Enter or pick the packaging name (e.g. `Crate`, `Carton`, `Box`, `Bale`, `Pack`, `Half-Crate`).
3. **Holds:** Enter how many loose base units make 1 pack (e.g. `24` bottles per crate, or `12` cans per carton).
4. **Price for One:** Click the calculator button to compute `Holds × Loose Selling Price`, or type a discounted wholesale price for that pack size.
5. **Code on It (Optional):** Scan or type the barcode printed on the outer carton or crate. Scanning that code at the counter rings up the whole pack at the pack price automatically.
6. Click **Save Product**. Every sale, return, factory purchase, quotation, and inter-branch transfer can be rung in any of the product's configured sizes while all stock comes off the single loose-unit count.

### 5.2b Bulk Product Import (CSV / XLSX Column Mapper) & Catalog Export
For shops migrating from another POS or maintaining master price sheets in Excel:
1. Go to **Products Catalog &rarr; Import (CSV / XLSX)**.
2. Choose any `.xlsx` (Excel) or `.csv` file from your computer (or click **Sample .XLSX** / **Sample .CSV** to download a ready-made template).
3. StoreFlow opens the **Interactive Column Mapper & Preview Table**, displaying your spreadsheet's columns and sample rows.
4. Above each column, StoreFlow automatically matches common column headers (`Product Name`, `Selling Price`, `Factory Cost Price`, `Stock Quantity`, `Pack 1 Name`, `Pack 1 Holds`, `Pack 1 Price`, etc.). Use the dropdown at the top of any column to adjust the mapping or set unneeded columns to `-- Ignore Column --`.
5. Choose how duplicates should be handled (**Update existing prices, pack sizes & stock** or **Skip existing products**) and click **Import Products**.
6. To export your entire catalog at any time, click **Export .XLSX** or **Export .CSV** in the Products Catalog header.

### 5.3 Price Quotations, Proforma Invoices & Expiry Controls
* **Creating a Quotation:** You can start a quotation in two ways:
  1. From **Quotations & Estimates**, click **`+ New Quotation`** (which switches to the POS counter with a prompt to add the items to quote), **or**
  2. Directly in **Point of Sale (POS)**, add the products and pack sizes to the cart and click **`Save as Quote / Proforma`** at the bottom of the cart.
  Enter the buyer's name, phone number, validity days, and optional notes, then click **Save Quotation**. Preparing a quote never deducts shelf stock.
* **Store Validity Policy:** Store owners set default quote validity days in **Settings &rarr; Store Profile & Receipts** under **Quotation Validity (Days)** (e.g. 7, 14, or 30 days). When minting an estimate, the modal calculates and previews the exact expiry date.
* **Price Lock Guarantee:** A quotation is a commercially locked contract. The prices, multi-size packaging rates, and line totals remain completely frozen during its validity window. Even if wholesale supplier costs or retail prices increase later, the quote protects the customer at agreed rates.
* **Converting to Sale:** When the buyer returns to pay, open **Quotations & Estimates** and click **Convert to Sale**. All quoted products, wholesale pack sizes, multiplier quantities, and locked prices drop straight into the POS cart for immediate checkout.
* **Expired Quotation Guard:** If an attendant clicks *Convert to Sale* on an expired quotation, StoreFlow displays a warning prompt with the expired date, requiring explicit confirmation before converting so management can decide whether to honor the old quote or re-price.
* **Customer Sharing:** Quotations can be printed as professional Proforma Invoices (**Print**) or shared instantly to the customer's WhatsApp chat (**WhatsApp**) with formatted line breakdowns and total payable figures.

### 5.4 Event & Equipment Rentals Desk (The Hire Desk)
When **Enable Rentals & Equipment Hire** is toggled on in Settings, StoreFlow transforms into a hire desk for event canopies, plastic chairs, sound systems, catering coolers, and beverage crates:
* **Configuring Hire Assets:** In *Products Catalog &rarr; Edit Product*, check **Available for Rental / Hire** and specify the daily hire fee, standard damage repair fee, and missing replacement value. Hire assets are protected from being sold outright as normal retail items at the POS counter.
* **Booking or Dispatching Equipment:** In **Rentals & Hire &rarr; `+ New Rental Dispatch`**, select the customer, pickup date, return due date, items, and refundable **Caution Security Deposit**. You can save the contract as a **`Booked / Quote`** reservation (printed as a **Quotation** without deducting stock yet, then dispatched later with one click on **`Dispatch`**) or as **`Out on Hire`** (which deducts warehouse stock immediately, prints an official **`Gate Pass`**, and books cash caution/rental fees into the cashier's shift drawer).
* **Return Inspection & Check-In:** When equipment returns, click **`Check In`** on the rental row and enter the inspection count:
  1. *Good condition units:* Restored immediately into warehouse inventory.
  2. *Damaged units:* Charged at the agreed contract damage fee. Once repaired in your workshop, click **`Restock Repaired Gear`** in the Rentals header to put repaired units back into active warehouse stock.
  3. *Missing / unreturned units:* Charged at the agreed replacement fee.
  4. *Overdue days:* Automatically charged at the daily late fee rate for each day past the return due date.
* **Financial Settlement & Shift Drawer:** StoreFlow automatically deducts late fees and damage penalties from the caution deposit:
  - If caution exceeds penalties, the remaining balance is refunded in cash or digital transfer out of the till drawer.
  - If penalties exceed caution, the deposit is marked **FORFEITED** and a balance invoice is billed to the customer for the difference.
  - Cash collected and caution refunds reconcile automatically on the shift Z-Report slip.

### 5.5 Dining Floor & Hospitality Mode (Tables, Tabs & KDS)
For food & beverage operations, switch **Operating Mode** to *Restaurant, Cafe & Eatery* or *Hybrid Omnichannel* in **Settings &rarr; Store Profile & Receipts**:
* **Dining Floor Map:** Open the **Dining Floor** module to manage tables, bar counters, and private spaces with real-time occupancy status (Available, Occupied, Reserved).
* **Guest & Seat Ordering:** In the POS cart, click **`[🪑 Seat]`** to assign dishes or rounds to specific diners (e.g. `Seat 1`, `Seat 2`, `Shared`).
* **Kitchen Prep Notes:** Click **`[📝 Note]`** on any cart line to attach chef preparation instructions (e.g. `Medium rare`, `No onions`, `Extra spicy`, `Less sugar`).
* **Kitchen Display System (KDS) & Tickets:** Send tickets directly to the kitchen display or print thermal order slips categorized by station.
* **Tab Management:** Guests can add rounds throughout their visit. When ready to settle, the tab opens in POS checkout to complete payment, print itemized customer dining receipts, and free the table space.

---

## 6. Barcode & Shelf Tag Printing Studio

StoreFlow includes a full label design studio:
1. Open **Products Catalog &rarr; Barcode Studio** (or click the purple tag in the left sidebar).
2. **Product & Size Selection:** Select an individual product or choose `All Products in Catalog`, then choose **Which Size** (`Every size with its own code`, `Loose unit only`, `Packs only`, or a specific pack size such as `Crate`).
3. **Print Layout:**
   - `Compact 30-up A4 Sticker Sheet (70 × 29.7 mm)`
   - `Standard 24-up A4 Sticker Sheet (70 × 37 mm)`
   - `Dedicated Thermal Shelf Tag (Single Roll 50 × 30 mm)`
   - `Shelf Price Tag (Large Price & Barcode)`
4. **Label Elements:** Toggle Store Name, Product Name, SKU / Code, Barcode Graphic, and Selling Price.
5. Click **Print Labels** to print directly on any standard office printer or dedicated thermal label printer.

---

## 7. Inventory Management & Batch/Expiry Tracking

### 7.1 Perishable Goods & Drug Expiry (FEFO Engine)
For food, dairy, beverages, and pharmaceuticals:
1. When adding or editing a product, check **Track Batch & Expiry Date**.
2. Enter the **Batch / Lot Number**, **Manufacture Date**, and **Expiry Date**.
3. Set **Alert Before (Days)** (e.g. 30, 60, or 90 days).
4. Products approaching expiry appear in yellow warnings; expired products appear in red badges and can be filtered in **Batches & Expiry**.
5. During sales, StoreFlow automatically deducts stock using **FEFO (First-Expired, First-Out)** order.

### 7.2 Stock Audits & Physical Counts
1. Go to **Live Inventory &rarr; Stock Audit**.
2. Select your store location or pen/aisle.
3. Perform your physical count and enter the counted quantity.
4. StoreFlow generates a discrepancy report:
   - **Shrinkage (-):** Flags missing stock.
   - **Surplus (+):** Discovers unrecorded units.
5. Confirming the audit writes an automated inventory movement record with the auditor's name.

---

## 8. Factory Purchases & Supplier (Vendor) Accounts

### 8.1 Recording Factory Orders & Back-Door Arrival Count-In
1. Navigate to **Factory Purchases &rarr; New Purchase Order**.
2. Select the **Supplier (Vendor)** or create a new one (existing suppliers can also be opened with a one-time **Opening Balance** if you owe them or they hold your deposit from a previous paper book).
3. Add products, choose the **Size** ordered (e.g. `Crate`, `Carton`, or loose unit), and enter quantities and invoice unit costs.
4. Enter the cash/bank **Amount Paid** now (or draw from an existing **Advance Credit** held with that supplier):
   - Paying the full bill stamps the order **Paid in Full**.
   - Paying less than the bill records the balance on the supplier's payable account.
   - Paying more than the bill holds the extra as an **Advance** with that supplier for your next order.
5. Saving the order places it as **Waiting at Factory (`PENDING`)** so your money and supplier balance are recorded immediately, before the truck arrives.
6. When the delivery truck reaches the shop, click **Count In** on the order, verify the physical quantities that actually came off the truck (any short delivery automatically reduces what the supplier can bill you for), and click **Count In & Stock It**. StoreFlow then adds the loose units to your shelf and recalculates the product's weighted average factory cost.

### 8.2 Paying a Supplier
1. Go to **Suppliers (Vendors)** and choose **Record Payout** on the supplier you are paying.
2. Enter the amount, the payment method and, if the factory gave you one, the reference number.
3. The payout settles your oldest open invoice first, then carries on down the list until the money runs out. Each order it closes stops being shown as owing, so the **Suppliers** page and the dashboard always agree about what is still to pay.
4. Part-paying an invoice is recorded as part-paid, not as nothing.
5. If the amount is more than the supplier is owed, StoreFlow asks before it books it. Confirm and the extra is held as an **advance** the supplier owes you in goods; the next purchase order can be paid with it, and the till shows how much of that balance you can spend before you reach for cash.
6. One click records one payout. If the same payment reaches the shop's books twice &mdash; a second click, or a till resending a batch it thinks it lost &mdash; the second copy is refused and nothing moves.

### 8.3 Reading the Supplier Statement
The **Ledger** button prints the supplier's statement of account: each order as a debit at its gross, each payout (and each amount drawn off a balance you held) as a credit, with the running balance beside it. Money paid against an order appears once, on the day it was paid, whether it left the drawer or came out of a balance the factory was holding.

---

## 9. Returns, Refunds & Accounting Precision

StoreFlow follows standard GAAP / IFRS matching principles for retail returns:

A **return** is a customer bringing goods back after a sale that was correctly rung. It leaves
a credit note behind, and the original receipt keeps the figures the customer was quoted. It
is not the same thing as a **void** (§4.6), which cancels a bill the shop keyed wrong on its
own day and leaves a receipt worth nothing. Choosing between them is a bookkeeping decision,
not a convenience: a void reports "this sale never happened", a return reports "this sale
happened and part or all of it came back".

### 9.1 How to Process a Return
1. Go to **Returns & Refunds &rarr; Process New Return** (or click **Return** directly on any receipt slip).
2. Enter the **Receipt Number** (e.g. `REC-20261027-5984`).
3. Select the items and quantity being returned.
4. Specify the **Return Condition**:
   - `Restock to Inventory` &rarr; Goods return to active stock on hand.
   - `Damaged / Waste` &rarr; Written off; not added back to saleable stock.
5. Choose Refund Method (`Cash Refund`, `Store Credit`, or `Reverse Customer Debt`).

A refund paid in cash comes straight out of the drawer that is sitting there, so the shift
close (§3.3) counts it: **Expected Cash** is reduced by the cash credit notes this register
paid today, read off the returns book rather than typed by the till. On a GH₵1,000.00 cash
day with one GH₵115.00 cash refund, the drawer expects GH₵885.00 over its float and the close
screen shows the GH₵115.00 on its own **Cash Back on Returns** line.

### 9.2 Realized Profit Accounting on Returns
* **Fully Refunded Orders:** Net revenue and net profit become **`GH₵0.00`** with a neutral **`Refunded`** badge. The factory cost is marked as `(Restocked)`.
* **Partially Refunded Orders:** Retained revenue, cost, and gross profit scale proportionally with a blue **`[Net]`** badge.
* **Summary KPI Reconciliation:** Revenue and gross profit summary cards automatically deduct refunds, guaranteeing that cashier reports match bank deposits.
* **Voided Receipts:** Contribute nothing to revenue, tax, gross profit, the tender totals or
  the customer's account, and are reported separately wherever a shift or day is summarised.
  A void is never netted off a sale — the sale is simply worth nothing.

### 9.3 What a Credit Note Does to the Member's Points

Goods move, money moves, and on a member's receipt the points follow the goods back. A
credit note is booked against the receipt it came from, so it answers the same fraction of
that receipt as the money does, and the points settle by that fraction:

* **Part of the basket is part of the points.** A member who rings GH₵400.00 of stock earns
  400 points on the receipt. Return GH₵100.00 of those goods and the receipt gives back a
  quarter of the points it earned, leaving the standing on the GH₵300.00 the shop still holds
  their money for. Notes that together cover the whole receipt come to the whole of the
  points: the share is counted off the receipt's own refunded total, so the last note settles
  the balance down to exactly nothing rather than leaving the member holding a point on a
  basket that came home in full.
* **Points handed in come back too.** A refund is worked out of the goods on the receipt and
  the discount typed on it, and points handed in for a price cut appear in neither, so the
  shop never pays them back in cash. A member who handed in 500 points for a GH₵5.00
  reduction, paid the rest of a GH₵95.00 tin in cash and then returned it gets the GH₵95.00
  back *and* the points back on their account — 95 taken off what the tin earned, 500 handed
  over, 405 points net returned. Without this, returning would cost the member
  the goods, the points, and the discount those points bought.
* **Nothing is quietly rewritten.** The receipt keeps the points figure printed on it. The
  reversal is its own line on the member's points statement, naming the credit notes it
  answers and the share of the receipt they cover. A manager who withdraws a note keyed wrong
  gets the same treatment in reverse: the notes still standing are re-counted and the points
  trimmed for the withdrawn note are handed back, with a line saying that happened.
* **A member who has already spent the points is not left owing the shop.** The clawback stops
  at zero and the statement says how much could not be taken, so a balance disputed a month
  later has an explanation written against it instead of a gap in it.
* **A void is not a return.** Clearing a bill under §4.6 takes the whole receipt's points back
  in one line because the whole bill went; a credit note takes a share of them. A receipt
  already voided is turned away at the return desk, so no basket is ever reversed by both
  doors.

A walk-in receipt with no member on it moves no points, and a credit note queued on a shut
till reverses them at the same share the counter would have used, when the outbox replays.

---

## 10. Expenses, Customer Debts & Financial Ledgers

### 10.1 Daily Operating Expenses
To record operational cash outflows:
1. Go to **Expenses & Payouts &rarr; Record Expense**.
2. Select Category (`Utilities & Electricity`, `Store Rent`, `Staff Wages & Lunch`, `Packaging & Bags`, `Transportation & Fuel`, `Maintenance`).
3. Enter amount, payment method (`Cash Drawer`, `Bank`, `MoMo`), and upload receipt image or reference.
4. Expenses deducted from Cash Drawer automatically reflect in the shift closing reconciliation.

### 10.2 Customer Debt & Account Settlement
1. Go to **Customers (Buyers)**.
2. View real-time debt balances for all wholesale and credit customers.
3. Click **Accept Payment** to record debt settlements (full or partial payments).
4. StoreFlow issues an official printed debt clearance receipt and updates the customer's ledger balance.

### 10.3 Customer Loyalty Points & Member Rewards Policy
StoreFlow includes a native points-and-rewards loyalty engine configured in **Settings &rarr; Store Profile & Receipts**:
1. **Points Earning Rate:** Set how many points a customer earns per GH₵1.00 of goods purchased (default: `1.0` point per GH₵1.00). Points are automatically credited upon completed POS checkout.
2. **Redemption Cash Value:** Configure what each point is worth when redeemed at checkout (e.g. `0.01` means 100 points = GH₵1.00 cash deduction).
3. **Counter Redemption Toggle:** Decide whether cashiers are allowed to apply points as cash discounts directly at the POS counter.
4. **Member Points Balance:** At the POS counter, selecting a customer displays their real-time point balance. Cashiers can click *Redeem Points* to deduct money from the total payable amount.
5. **Reversal on Returns:** To safeguard store profit margins, when a customer returns items against a past receipt, points originally earned on that merchandise are automatically reversed from their account in `loyalty_ledger`.

### 10.4 Analytics & Comparative Reports (Dead Stock Clearance, Supplier Spend & Margin Breakdown)
Open **Analytics & Reports** from the left sidebar to inspect executive business health:
* **Period Comparison & Tender Breakdown:** Compare revenue, realized gross profit, operating expenses, and net profit across Today, This Week, This Month, This Quarter, This Year, or any custom date range, alongside a payment method tender breakdown (Cash, Card/POS, Bank/MoMo, Customer Debt, Split/Other) and Top 5 Products by Revenue.
* **Department & Category Margin Breakdown:** Shows gross profit contribution and margin percentage per inventory department.
* **Top Repeat Customers & CLV:** Ranks repeat buyers from the ledger by total visits, Lifetime Value (CLV), average order value, and loyalty tier, with a 1-click **Statement** button.
* **Dead Stock & Dormant Working Capital Alert:** Automatically surfaces shelf products that have been in stock for 30+ days without a single sale, showing how much cash is tied up in dormant inventory. Click **`Clear`** on any dormant row to launch a 1-click **Clearance Promo** discount (e.g. 10%, 15%, or 20% off) while warning you if the discount goes below factory cost.
* **Stock Bought In & Supplier Spend:** Summarizes factory purchase orders, carriage/freight costs, amounts paid to suppliers, and loose volume bought in during the selected period.

### 10.5 Omnichannel E-Commerce Sync (WooCommerce & Shopify Bridge)
Open **E-Commerce Sync** from the left sidebar to connect an online WooCommerce or Shopify storefront:
* **Webhook Order Inbox:** Copy the displayed Webhook URL into WooCommerce (`Settings → Advanced → Webhooks`, Topic: `Order Created`) or Shopify, signed with `STOREFLOW_ECOMMERCE_SECRET` in `api/config/config.php`. Incoming online orders land safely in **Quotations & Estimates** (`ONL-YYYYMMDD-NNN`) so counter staff can verify payment and convert them to a sale without unverified orders deducting shelf stock directly.
* **Live Stock Feed Export:** Provides a token-authenticated JSON stock feed endpoint so your website reflects live shelf quantities.

---

## 11. Multi-Device Networking & Phone Barcode Scanner

### 11.1 Using Your Smartphone as a Cordless Barcode Scanner Gun
You do not need expensive handheld laser scanners:
1. Click **Phone Scanner Gun** on the top bar or left sidebar.
2. A pair QR code will appear on your computer monitor.
3. Scan the QR code using your Android or iPhone camera.
4. Your phone opens the instant web scanner (no app installation needed).
5. Point your phone camera at any physical barcode—it scans instantly and sends the barcode straight into your PC's active POS cart via local wireless bridge!

A phone camera only starts on a **secure address**. On the shop Wi-Fi the till is a plain
`http://192.168.x.x:8095` page, and the browser will refuse the camera there; reach the till
through the tunnel described in §11.3 and scan the QR from that screen, and the camera works
from anywhere. The pairing link itself always points at the address the till was opened on, so
nothing in it needs rewriting by hand.

### 11.2 Multi-Counter LAN Setup
1. Find your main computer's local IP address (e.g. `192.168.1.50`).
2. On any other laptop, tablet, or cashier station connected to the same Wi-Fi / LAN, open the
   address of the machine running the till: `http://192.168.1.50:8095/` when it was started with
   `StoreFlow.exe` (see §2.1 for the `lan-mode.txt` switch that lets other machines in at all),
   or `http://192.168.1.50/storemgt/` when it is served from a XAMPP web folder.
3. Cashier terminals operate independently while synchronizing live sales and stock in real time.

### 11.3 Checking the shop from home
StoreFlow is a counter till, not a website. Everything it holds — your stock, your
customers' debts, your daily takings — lives on the machine it runs on, and the shop attendant
needs no internet to serve a customer. When you need to answer a call at home about someone's
debt, you can borrow a secure tunnel (ngrok, Cloudflare Tunnel, Tailscale, or your router's
VPN) to reach the till from outside. Two rules keep that safe:

1. **Point the tunnel at StoreFlow, never at the whole web server.** The bundled runtime
   serves the till alone on port `8095`, so start it with `StoreFlow.exe` and then run
   `ngrok http 8095`. Tunnelling port `80` on a XAMPP machine publishes *every* folder in
   `htdocs` — other projects, backup archives, and the database administration console —
   to whoever has the address. Those tools trust "you are the computer in front of me", and
   a tunnel comes in through the machine itself, so it looks like you. If you run StoreFlow
   under your own Apache, give it a dedicated virtual host on its own port and tunnel that.
2. **Change the default owner password first (§2.4), and switch the tunnel off when you are
   done.** The tunnel address is a password-free invitation; a short-lived one is far
   better than an address that has pointed at your till for years. Check your tunnel
   service's access-control options and put a login in front of the link if the service
   offers one.

Nothing else changes when you work this way. Sign in as yourself, and StoreFlow will not
let a page through without a valid session.

### 11.4 Several areas, several shops: what a branch is and what it is not
**Counters in one shop.** Every device that opens the same StoreFlow server's address shares
one book — one stock figure, one day's takings, one customer list. That is the §11.2 setup, and
it is one licence: adding a counter does not add a purchase.

**Areas inside one shop: branch codes.** Branch codes work *inside* the one install. Each branch
keeps its own shelf count and, if you set one, its own selling price; **Branches → New Transfer**
moves stock between areas with a printable waybill, and the receiving branch counts it in. A
cashier signed in to `NORTH-02` sells from `NORTH-02`'s shelf, and the owner still reads one set
of accounts. Turn on **multi-branch** in Settings before any of this, or the branch on a device
is just whatever that device last remembered.

**A branch is a shelf and a report line, not a locked room.** Stock is partitioned and sales are
attributed, but it is one database: an owner sign-in sees every branch from the same install, and
a branch report is a filter over the one book. Once the network door is open (§2.1), staff
passwords and per-user permissions are what stand between one cashier's numbers and another's.

**A second shop, or a location that must keep trading when the link drops.** That location runs
its own StoreFlow folder on its own machine. A key is issued for one machine, so that is a second
key — and say the consequence out loud before you sell it: two installs are **two books**. No
code path pushes one install's sales into another install's server, so nothing merges them into
one report, and an owner who wants a single number across sites needs one StoreFlow that every
site's browser can reach (§11.2, or the tunnel in §11.3), not two installs.

**Phone scanner guns at more than one counter.** A phone is paired to a *terminal name*, not to a
branch. `MAIN-01 / REG-01` and `NORTH-02 / REG-01` are both `REG-01` to the till, so they share
one queue of scans and whichever cart polls first takes the barcode — it can land in the wrong
counter's sale. Give every device its own terminal name **on that device**, in the terminal box on
the Phone Scanner Gun screen, before you scan its QR. The name typed in Settings → Store profile
is saved into the store's own profile and remembered on that machine only, so a till that has
never been named falls back to the same profile name as every other till. Two installs on two
machines cannot collide, because each has its own queue.

---

## 12. Automated 2-Hour Backups & Security Safeguards

### 12.1 Automated 2-Hour Backup Engine
* StoreFlow contains a built-in automated backup scheduler.
* Every 2 hours of active operation, the system writes a snapshot of the whole database into the `data/backups/` folder.
* Snapshots older than seven days are trimmed automatically to preserve hard drive space, so that folder is a rolling week of protection rather than an archive. Keep your own copies of anything you want past a week.
* The clock this keeps is *when a copy of this shop was last taken*, not *when the scheduler last ran*. A snapshot you pressed by hand, the copy a restore saves first and the copy a reset saves all stand in place of the scheduled one, because any of them is a file the shop can be put back from.

### 12.2 Manual One-Click Backups
Navigate to **2-Hour Backups** in the left sidebar to:
- Create a snapshot on demand, and download any snapshot to a USB flash drive or another computer.
- Restore from a previous snapshot when a bad entry, a failed update or a dead disk puts the shop's books at risk. StoreFlow saves the state it is about to replace first, so a restore is undoable.
- **Create Encrypted Copy** — one `.sfbak` file sealed with a passphrase you type in, meant to leave the shop. Unlike the snapshots above, it is unreadable without that passphrase, so it is safe on a USB stick in a drawer or in storage you hold with a cloud account of your own.
- **Decrypt & Restore** — put the books back from an encrypted copy, on this machine or on a new one.

The snapshot table labels every file it lists, and the label is worth reading before
anything is restored:

| Label | What that file is |
| --- | --- |
| **Auto (2hr)** | Written by the scheduler on its own, kept for seven days. |
| **Manual** | Taken on demand with **Create Snapshot Now**, or uploaded by you. |
| **Safety** | Taken automatically in the second before a restore, so the restore can be undone. |
| **Before reset** | Taken in the second before a reset cleared the records — the only file that still holds the shop as it was that morning. |
| **Uploaded** | A `.db` file handed over from a USB stick or another computer and put in place. |
| **Imported (encrypted)** | The working database that came out of an encrypted `.sfbak` copy after it was restored. |

*The passphrase on an encrypted copy is never stored: not in the database, not in the activity log, not with the seller. Lose it and that file cannot be opened by anyone, including us. Write it down the day you make the copy and keep the paper apart from the file.*

### 12.3 Starting over clean: Reset Database

The same page carries one destructive button, and it is deliberately not the same thing as a restore.

**Reset Database** clears the shop's trade records and leaves the shop itself standing. Use it to hand
a machine over clean, or to start the books again in the same shop, without deleting the database file
behind the product.

| It clears | It keeps |
| --- | --- |
| Every receipt, return, quotation/estimate and rental contract | This computer's licence and activation |
| Every product, pack unit, combo/bundle, price, stock level, batch and transfer | Staff accounts, their roles and the names you gave them |
| Every supplier, factory purchase order, their debts and their payments | Store settings, branches and receipt wording |
| Every customer and loyalty points ledger (except the walk-in account) | Dining room tables (kept standing and set to vacant) & the shop's audit log |
| Every expense, register shift, dining tab and kitchen ticket | One copy of the shop as it stood, written first |

Three things worth knowing before you press it:

* **It does not cost you the key.** Deleting the database file changes this computer's Machine ID and
  the activation no longer fits; a reset leaves the licence alone, so the same key keeps working.
* **You have to type the word `RESET`.** Reading the list and clicking is not consent to destroy a
  year of takings, so the server refuses the request without the word typed exactly as shown.
* **One copy is written first, and the older rolling snapshots are removed with it.** The copy is named
  on screen and stays in `data/backups/` labelled **Before reset**; restore it if you change your mind.

Every till in the shop is told the book changed when you reset. A phone that is still holding yesterday's
records is then *refused*, not merged: the owner sees how many records it is holding and chooses to load
them into the new book or discard them. That is the reason the reset is safe to press while other counters
are switched on.

### 12.4 Role-Based Access Control (RBAC)
The **Access Map** — on the **Store Managers & Staff** screen — is one row per role and one
column per right the shop is willing to grant, with a **discount ceiling** at the end of each
row. A tick is the only thing that puts a screen on that role's menu, and the ceiling is the
largest discount its staff may apply at the counter (`0` meaning none at all). Saving binds at
once on the server; a till already open shows the new menu the next time it loads.

The seven rights, and what each one actually withholds:

| Right | What it opens |
| --- | --- |
| **Inventory** | Edit products, prices and stock. Includes repricing a line at the till and discounting above the role ceiling. |
| **Sales** | Ring sales at the till, process returns and balance the drawer. |
| **Purchases** | Raise purchase orders, count in arrivals and pay suppliers. |
| **Reports** | The Dashboard and the Analytics screens, each branch's turnover, a product's sales history and the list of saved backups. |
| **Users** | Add staff and edit the Access Map itself. |
| **Settings** | Change shop settings, the tax rate and receipt printing. |
| **Backups** | Create, export and restore the shop's backups. |

Two things about the map are worth being explicit about, because both are about a drawer
being counted rather than about tidiness:

* **A cashier keeps reading the sales book without the Reports right.** Balancing a drawer
  means reading back what the drawer took, so the till's own ledger stays on their menu. What
  **Reports** gates is the analysis screens — and it gates them in the menu, in the router and
  on the server, so a hidden screen is also a refused one.
* **Costs and margins are hidden by the same map, not by the role's name.** A cashier sees the
  selling price and nothing about what the shop paid for the goods; the profit columns on the
  sales ledger appear only for a role allowed to see them.

The shipped roles read as follows unless the map is edited:

* **Administrator:** Full access to all modules, factory cost prices, profit margins, user manager, and system settings.
* **Store Manager:** Access to POS, inventory, stock transfers, purchases, and reporting; restricted from modifying system license or deleting audit logs.
* **Cashier:** Dedicated POS checkout, sales history, customer creation, and register float; factory purchase costs and gross profits are strictly hidden.
* **Lock Screen (<kbd>Lock</kbd>):** Staff can lock the register screen when walking away; unlocked via password or 4-digit quick PIN.

---

## 13. Keyboard Hotkeys Quick Reference

Print this table and place it beside every POS terminal for maximum cashier speed:

| Key | Action | Description |
| :--- | :--- | :--- |
| <kbd>F2</kbd> | **Search Product** | Jumps focus directly into the barcode / product search input |
| <kbd>&uarr;</kbd> <kbd>&darr;</kbd> <kbd>&larr;</kbd> <kbd>&rarr;</kbd> | **Navigate Grid** | Moves the highlighted cursor across the product cards |
| <kbd>Enter</kbd> | **Add to Cart** | Adds the highlighted product into the active cart |
| <kbd>+</kbd> | **Increase Qty** | Increases the quantity of the last selected cart item |
| <kbd>-</kbd> | **Decrease Qty** | Decreases the quantity of the last selected cart item |
| <kbd>F4</kbd> | **Open Payment** | Opens the Interactive Checkout Modal with tender options |
| <kbd>F9</kbd> | **Fast Cash** | Instant checkout with exact cash and prints receipt |
| <kbd>1</kbd> or <kbd>C</kbd> | **Cash Method** | Selects Cash payment in the checkout modal |
| <kbd>2</kbd> or <kbd>K</kbd> | **Card Method** | Selects Credit / Debit Card in the checkout modal |
| <kbd>3</kbd> or <kbd>M</kbd> | **Transfer / MoMo** | Selects Mobile Money or Bank Transfer |
| <kbd>4</kbd> or <kbd>D</kbd> | **Credit Sale** | Selects Buy on Credit / Customer Debt |
| <kbd>5</kbd> or <kbd>S</kbd> | **Split Tender** | Splits payment across Cash, Card, and Transfer |
| <kbd>F1</kbd> | **Help & Manual** | Opens the Interactive System Guide and shortcuts sheet |
| <kbd>Esc</kbd> | **Close / Cancel** | Closes any active modal or dialogue |

---

*© 2026 Frivans Technologies. All rights reserved. Enterprise POS & Retail ERP Engine.*
