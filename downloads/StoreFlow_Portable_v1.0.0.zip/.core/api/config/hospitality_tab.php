<?php
// api/config/hospitality_tab.php
// The dining tab: what the kitchen was asked to make, and what it takes to release a table.
//
// Nothing in this file moves money or stock. A tab is a ticket, not a receipt - the bill is
// written at the counter, through the same path that rings a retail basket, so units, lots,
// stock floors, tax, the discount cap and loyalty are decided once for every door instead of
// once per module. It lives beside the schema rather than inside hospitality.php because two
// doors have to agree on what "this table is paid" means: a till online right now, and the
// same receipt arriving through a queue a day later.

require_once __DIR__ . '/product_units.php';

// Statuses the kitchen screen may move a tab to. SETTLED is deliberately absent: only a
// receipt settles a tab, and a cook tapping "paid" would free a table that still owes the
// shop its bill.
function hospitalityKitchenStatuses(): array {
    return ['OPEN', 'IN_KITCHEN', 'PREPARING', 'READY', 'SERVED'];
}

// The branch a floor request may touch. Non-managers are clamped to their own, exactly as
// every other write in the product is; a waiter asking for another branch's tables would be
// reading and emptying a room they do not work.
function hospitalityBranchScope(array $user, string $requested = ''): string {
    $own = strtoupper(trim((string)($user['branch_code'] ?? ''))) ?: 'MAIN-01';
    $role = strtolower(trim((string)($user['role_name'] ?? '')));
    $isManager = $role === 'administrator' || intval($user['role_id'] ?? 0) === 1;
    $wanted = strtoupper(trim($requested));
    if (!$isManager || $wanted === '' || $wanted === 'ALL') {
        return $own;
    }
    return $wanted;
}

// A tab and the bill being paid for it, compared by what left the pass rather than by the
// paper's total. Two rounds of the same dish in the same size are two lines on a ticket and
// one line on a cart, so each side is summed by (product, size) before anything is judged.
function hospitalityLineMap(array $lines): array {
    $map = [];
    foreach ($lines as $ln) {
        if (!is_array($ln)) continue;
        $productId = trim((string)($ln['product_id'] ?? ''));
        if ($productId === '') continue;
        $unit = mb_strtolower(trim((string)($ln['unit'] ?? '')) ?: 'pcs');
        $key = $productId . '|' . $unit;
        if (!isset($map[$key])) {
            $map[$key] = ['product_id' => $productId, 'unit' => $unit, 'quantity' => 0.0,
                          'name' => trim((string)($ln['product_name'] ?? ($ln['name'] ?? '')))];
        }
        $map[$key]['quantity'] += floatval($ln['quantity'] ?? 0);
        if ($map[$key]['name'] === '') {
            $map[$key]['name'] = trim((string)($ln['product_name'] ?? ($ln['name'] ?? '')));
        }
    }
    return $map;
}

function hospitalityLineLabel(array $line): string {
    $name = $line['name'] !== '' ? $line['name'] : $line['product_id'];
    return sprintf('%g x %s (%s)', round((float)$line['quantity'], 3), $name, $line['unit']);
}

// The question a tab and a receipt have to answer the same way before a table is let go: is
// this bill exactly the ticket? Short, and the shop has fed a party it is not charging for.
// Long, and the customer is being charged for a dish the kitchen never made - or for one the
// table sent back, which is the mistake a voided line leaves behind when the till's cart was
// loaded before the void. Either way the release is the harm, so a mismatch is a message.
//
// @return string|null a sentence naming the difference, or null when the bill matches
function hospitalityTabMismatch(array $tabItems, array $saleLines, string $tableLabel = ''): ?string {
    $onTab = hospitalityLineMap($tabItems);
    $onBill = hospitalityLineMap($saleLines);
    $where = $tableLabel !== '' ? "Table {$tableLabel}'s ticket" : "This tab";

    $missing = [];
    foreach ($onTab as $key => $line) {
        $billed = $onBill[$key]['quantity'] ?? 0.0;
        if ($billed + 0.001 < $line['quantity']) {
            $short = round($line['quantity'] - $billed, 3);
            $missing[] = sprintf('%g x %s (%s)', $short, $line['name'] ?: $line['product_id'], $line['unit']);
        }
    }
    $extra = [];
    foreach ($onBill as $key => $line) {
        $fired = $onTab[$key]['quantity'] ?? 0.0;
        if ($line['quantity'] > $fired + 0.001) {
            $over = round($line['quantity'] - $fired, 3);
            $extra[] = sprintf('%g x %s (%s)', $over, $line['name'] ?: $line['product_id'], $line['unit']);
        }
    }

    if ($missing === [] && $extra === []) {
        return null;
    }
    $parts = [];
    if ($missing !== []) {
        $parts[] = $where . ' has ' . implode(', ', $missing) . ' that this bill does not charge for';
    }
    if ($extra !== []) {
        $parts[] = 'this bill charges ' . implode(', ', $extra) . ' that ' . strtolower($where) . ' never fired';
    }
    return implode('; ', $parts)
        . '. Reload the tab into the cart, or send the change to the kitchen and void the line, so the bill and the ticket agree before the table is released.';
}

// One tab, with its lines, only if this user may see it. Returns null for a tab that does not
// exist; returns ['error' => ...] for one that exists but belongs to another branch or has
// already been settled - a distinction the counter has to make out loud, because "already
// paid" is the sentence a double-tapped settle button needs to hear.
function hospitalityFindTab(PDO $db, string $tabId, string $branchCode, bool $isManager): ?array {
    $stmt = $db->prepare("SELECT o.*, t.zone_name FROM table_orders o
                          LEFT JOIN dining_tables t ON t.id = o.table_id
                          WHERE o.id = ?");
    $stmt->execute([$tabId]);
    $tab = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$tab) return null;

    $tabBranch = strtoupper(trim((string)($tab['branch_code'] ?? ''))) ?: 'MAIN-01';
    if (!$isManager && $tabBranch !== $branchCode) {
        return ['error' => "This tab belongs to branch {$tabBranch}, not to {$branchCode}.", 'status' => 403];
    }
    if (in_array(strtoupper((string)($tab['status'] ?? '')), ['SETTLED', 'CANCELLED'], true)) {
        return ['error' => "This tab is already " . strtoupper((string)$tab['status']) . '.', 'status' => 409];
    }
    $iStmt = $db->prepare("SELECT * FROM table_order_items WHERE order_id = ? ORDER BY created_at ASC");
    $iStmt->execute([$tabId]);
    $tab['items'] = $iStmt->fetchAll(PDO::FETCH_ASSOC);
    return $tab;
}

// Stamp the tab paid and let the table go, inside the caller's transaction so a receipt and
// a released table cannot come apart. The table is only freed when the tab it is holding is
// the one being paid: a second tab settled after the first would otherwise empty a table that
// is still sitting a party.
//
// @return bool whether this call is the one that settled it
function hospitalityCloseTab(PDO $db, string $tabId, string $tableId, string $saleId): bool {
    $upd = $db->prepare("UPDATE table_orders SET status = 'SETTLED', settled_at = datetime('now'),
                                sale_id = ?, updated_at = datetime('now')
                         WHERE id = ? AND status != 'SETTLED'");
    $upd->execute([$saleId, $tabId]);
    if ($upd->rowCount() === 0) {
        // Already settled. If it carries a different receipt but its table still points at
        // it, the table was never freed - so free it, rather than leave the room occupied.
        $db->prepare("UPDATE dining_tables SET status = 'VACANT', active_order_id = NULL, updated_at = datetime('now')
                      WHERE id = ? AND active_order_id = ? AND status != 'VACANT'")->execute([$tableId, $tabId]);
        return false;
    }
    $db->prepare("UPDATE dining_tables SET status = 'VACANT', active_order_id = NULL, updated_at = datetime('now')
                  WHERE id = ? AND active_order_id = ?")->execute([$tableId, $tabId]);
    return true;
}

// The tabs a receipt paid for, if any.
//
// A void clears the money and leaves the floor alone: the tab keeps its SETTLED stamp and its
// sale_id, its table is long vacant, and the party has gone home. That is the right shape - a
// bill is not re-opened by a click at the till, and refusing the void would strand the day's
// reconciliation against a receipt the shop has already agreed to cancel. What the void does not
// get to do is disappear from the room's point of view, so this hands the audit line the table
// number: the manager reading "receipt 4471 voided" at nine also learns whose party paid with it.
function hospitalityTabsSettledBySale(PDO $db, string $saleId): array {
    if (trim($saleId) === '') return [];
    try {
        $stmt = $db->prepare("SELECT id, table_number, status, total_amount
                              FROM table_orders WHERE sale_id = ? ORDER BY settled_at DESC");
        $stmt->execute([$saleId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
        // A book with no floor plan is a shop with no tables, not a failed void.
        return [];
    }
}
