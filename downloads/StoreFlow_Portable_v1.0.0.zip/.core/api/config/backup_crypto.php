<?php
// api/config/backup_crypto.php
// The encrypted backup container a shop owner can hand to a USB stick, a second
// computer, or (later) their own cloud account.
//
// Why not a password-protected .zip: the bundled runtime does not even stage
// php_zip.dll, and PHP's zip password support is ZipCrypto - the 1998 scheme that
// is recoverable from known plaintext. A file that looks like a secure backup and
// is one afternoon of work away from open is worse than no backup feature, because
// the owner stops taking the copies that actually save him. So the container is a
// sodium XChaCha20-Poly1305 secretstream: authenticated, streaming, and built from
// an extension the release builder already proves is loaded.
//
// The passphrase never leaves the browser as part of the file, is never written to
// the database, the activity log, or an error log, and is not recoverable by the
// seller. If the owner loses it, this file is unreadable to everyone including us,
// and the licence says so plainly rather than discovering it during a disaster.

function sfBakRequireSodium(): void
{
    // Checked where the feature is used, not when this file is read: a shop running
    // StoreFlow under its own XAMPP without sodium must keep the plain snapshot and
    // restore paths working, and an include-time throw takes the whole backups
    // endpoint down with it. build_package.ps1 refuses to ship a package whose bundled
    // PHP cannot do this, so a customer on the launcher never sees the message.
    if (!function_exists('sodium_crypto_secretstream_xchacha20poly1305_push')
        || !function_exists('sodium_crypto_pwhash')) {
        throw new RuntimeException(
            'This PHP installation cannot create encrypted backups: the sodium extension is missing. '
            . 'Use the StoreFlow launcher that came with the package, or install PHP with sodium.'
        );
    }
}

// The metadata frame is encrypted with everything else, so the outside of the file
// says only "StoreFlow backup, these KDF parameters, this salt". A curious staff
// member learns nothing about the shop from a filename.
const SFBAK_MAGIC     = 'SFBK1';
const SFBAK_KDF_ID    = 1;   // pins the ops/mem pair below; changing it must bump the magic
const SFBAK_SALT_LEN  = 16;  // sodium_crypto_pwhash salt
const SFBAK_HDR_LEN   = 24;  // secretstream xchacha20poly1305 header
const SFBAK_PREFIX    = 5 + 1 + SFBAK_SALT_LEN + SFBAK_HDR_LEN;  // 46 bytes before ciphertext
const SFBAK_CHUNK     = 1048576;  // plaintext bytes per frame; keeps a large till under memory

// Each secretstream frame is prefixed with its own 3-byte big-endian length, which is
// how libsodium's own file format does it. Without that, a reader cannot find frame
// boundaries at all: the ciphertext of one frame runs into the next, and authentication
// fails on a file nobody tampered with. 1 MB of plaintext plus the 17-byte tag is far
// under 2^24, so the prefix cannot overflow.
const SFBAK_LEN_BYTES = 3;

function sfBakWriteFrame($out, string $cipher): void
{
    $len = strlen($cipher);
    if ($len >= (1 << (SFBAK_LEN_BYTES * 8))) {
        throw new RuntimeException('A backup frame grew larger than the container can describe.');
    }
    fwrite($out, substr(pack('N', $len), 1));
    fwrite($out, $cipher);
}

function sfBakReadFrame($in): ?string
{
    $lenRaw = fread($in, SFBAK_LEN_BYTES);
    if ($lenRaw === false || $lenRaw === '') return null;          // clean end of file
    if (strlen($lenRaw) !== SFBAK_LEN_BYTES) {
        throw new RuntimeException('The backup file ends in the middle of a frame - it was copied incompletely.');
    }
    $len = unpack('N', "\x00" . $lenRaw)[1];
    $frame = $len > 0 ? fread($in, $len) : '';
    if ($frame === false || strlen($frame) !== $len) {
        throw new RuntimeException('The backup file ends in the middle of a frame - it was copied incompletely.');
    }
    return $frame;
}

function sfBakKdfParams(): array
{
    // INTERACTIVE (64 MB, 2 passes) rather than SENSITIVE (1 GB): this runs on the
    // shop's own counter PC, which is often the cheapest machine in the building,
    // and a key derivation that thrashes a till mid-trade is a fault the owner will
    // blame on the backup feature. The protection that matters here is that the
    // passphrase is the owner's and never leaves the machine.
    return ['ops' => SODIUM_CRYPTO_PWHASH_OPSLIMIT_INTERACTIVE,
            'mem' => SODIUM_CRYPTO_PWHASH_MEMLIMIT_INTERACTIVE];
}

/**
 * Derive the container key. Split out so a test can pin the parameters without
 * encrypting anything.
 */
function sfBakDeriveKey(string $passphrase, string $salt, int $ops, int $mem): string
{
    return sodium_crypto_pwhash(
        SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_KEYBYTES,
        $passphrase,
        $salt,
        $ops,
        $mem,
        SODIUM_CRYPTO_PWHASH_ALG_ARGON2ID13
    );
}

/**
 * Encrypt $plainPath into a new .sfbak at $outPath.
 *
 * @param array $meta written as the first encrypted frame, so it is only readable
 *                    with the passphrase.
 * @return array{size:int,sha256_plain:string}
 */
function sfBakEncrypt(string $plainPath, string $outPath, string $passphrase, array $meta): array
{
    sfBakRequireSodium();
    $in = @fopen($plainPath, 'rb');
    if (!$in) throw new RuntimeException('Could not read the database snapshot for encryption.');

    // 'xb' fails if the destination exists: two exports in the same second must not
    // quietly overwrite each other, and a half-written backup is the one file an
    // owner trusts when the disk actually dies.
    $out = @fopen($outPath, 'xb');
    if (!$out) {
        fclose($in);
        throw new RuntimeException('An encrypted backup file with that name already exists. Try again in a second.');
    }

    $kdf = sfBakKdfParams();
    $salt = random_bytes(SFBAK_SALT_LEN);
    $key = sfBakDeriveKey($passphrase, $salt, $kdf['ops'], $kdf['mem']);
    [$state, $streamHeader] = sodium_crypto_secretstream_xchacha20poly1305_init_push($key);
    sodium_memzero($key);

    $plainHash = hash_file('sha256', $plainPath);
    $metaJson = json_encode($meta, JSON_UNESCAPED_SLASHES);
    if ($metaJson === false) {
        fclose($in); fclose($out); @unlink($outPath);
        throw new RuntimeException('Could not encode the backup metadata.');
    }

    fwrite($out, SFBAK_MAGIC);
    fwrite($out, chr(SFBAK_KDF_ID));
    fwrite($out, $salt);
    fwrite($out, $streamHeader);

    $fail = false;
    try {
        // The metadata frame goes first, so a restore can authenticate the file and
        // read which till it came from before touching a single database byte.
        sfBakWriteFrame($out, sodium_crypto_secretstream_xchacha20poly1305_push($state, $metaJson, '',
            SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_TAG_MESSAGE));

        $final = false;
        while (!feof($in)) {
            $chunk = fread($in, SFBAK_CHUNK);
            if ($chunk === false) throw new RuntimeException('Read failed part-way through the snapshot.');
            if ($chunk === '') break;
            $atEnd = feof($in);
            sfBakWriteFrame($out, sodium_crypto_secretstream_xchacha20poly1305_push(
                $state, $chunk, '',
                $atEnd ? SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_TAG_FINAL : SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_TAG_MESSAGE
            ));
            if ($atEnd) { $final = true; break; }
        }
        // A zero-byte or single-frame source still needs the final tag, or a decrypt
        // loop waits for a frame that was never written.
        if (!$final) {
            sfBakWriteFrame($out, sodium_crypto_secretstream_xchacha20poly1305_push($state, '', '',
                SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_TAG_FINAL));
        }
    } catch (Throwable $e) {
        $fail = true;
    }

    fclose($in);
    fclose($out);
    sodium_memzero($state);

    if ($fail) {
        @unlink($outPath);
        throw new RuntimeException('Encryption failed; the partial backup was discarded.');
    }

    clearstatcache(true, $outPath);
    return ['size' => filesize($outPath), 'sha256_plain' => $plainHash];
}

/**
 * Decrypt a .sfbak to $plainPath and hand back the metadata it carried.
 *
 * Authentication is the point: a wrong passphrase, a truncated download, or an
 * edited byte all surface here as a refusal, not as a database that opens and then
 * quietly loses sales.
 */
function sfBakDecrypt(string $inPath, string $passphrase, string $plainPath, &$meta = null): array
{
    sfBakRequireSodium();
    $in = @fopen($inPath, 'rb');
    if (!$in) throw new RuntimeException('Could not open that backup file.');

    $prefix = fread($in, SFBAK_PREFIX);
    if ($prefix === false || strlen($prefix) !== SFBAK_PREFIX || substr($prefix, 0, 5) !== SFBAK_MAGIC) {
        fclose($in);
        throw new RuntimeException('This is not a StoreFlow encrypted backup file.');
    }
    $kdfId = ord($prefix[5]);
    if ($kdfId !== SFBAK_KDF_ID) {
        fclose($in);
        throw new RuntimeException('This backup came from a different StoreFlow format and cannot be read by this version.');
    }
    $salt = substr($prefix, 6, SFBAK_SALT_LEN);
    $streamHeader = substr($prefix, 6 + SFBAK_SALT_LEN, SFBAK_HDR_LEN);

    $kdf = sfBakKdfParams();
    $key = sfBakDeriveKey($passphrase, $salt, $kdf['ops'], $kdf['mem']);
    $state = sodium_crypto_secretstream_xchacha20poly1305_init_pull($streamHeader, $key);
    sodium_memzero($key);

    $out = @fopen($plainPath, 'xb');
    if (!$out) { fclose($in); sodium_memzero($state); throw new RuntimeException('Could not create the restore workspace.'); }

    $wrongPassphrase = 'The passphrase is wrong, or this file is damaged. Nothing was changed.';
    $meta = null;
    $bytes = 0;
    $frames = 0;
    $finalSeen = false;

    try {
        while (true) {
            $frame = sfBakReadFrame($in);
            if ($frame === null) break;
            // PHP 8.2's sodium has no get_tag(): pull() returns [plaintext, tag], and
            // false when the frame's MAC does not verify - which is both the wrong
            // passphrase and a edited byte, from one check.
            $pulled = sodium_crypto_secretstream_xchacha20poly1305_pull($state, $frame);
            if ($pulled === false) throw new RuntimeException($wrongPassphrase);
            [$plain, $tag] = $pulled;
            $frames++;

            if ($meta === null) {
                // First frame is the metadata, never database bytes.
                $decoded = json_decode($plain, true);
                if (!is_array($decoded) || ($decoded['app'] ?? '') !== 'storeflow') {
                    throw new RuntimeException($wrongPassphrase);
                }
                $meta = $decoded;
                $finalSeen = ($tag === SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_TAG_FINAL);
                continue;
            }

            fwrite($out, $plain);
            $bytes += strlen($plain);
            $finalSeen = ($tag === SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_TAG_FINAL);
            if ($finalSeen) break;
        }
    } catch (Throwable $e) {
        fclose($in); fclose($out); @unlink($plainPath); sodium_memzero($state);
        throw $e;
    }

    fclose($in); fclose($out); sodium_memzero($state);

    if ($meta === null || $frames < 2 || !$finalSeen) {
        @unlink($plainPath);
        throw new RuntimeException($wrongPassphrase);
    }

    clearstatcache(true, $plainPath);
    $actual = filesize($plainPath);
    // The FINAL tag says the stream ended where the writer said; the two checks below
    // say the database inside it is the one that went in. A copy truncated mid-stream
    // fails here even if every frame it does contain authenticates.
    if ($actual !== $bytes || ($meta['plain_bytes'] ?? null) !== $bytes) {
        @unlink($plainPath);
        throw new RuntimeException('The decrypted size does not match what the backup recorded. Treat the file as damaged.');
    }
    $actualHash = hash_file('sha256', $plainPath);
    if (!hash_equals((string)($meta['plain_sha256'] ?? ''), $actualHash)) {
        @unlink($plainPath);
        throw new RuntimeException('The decrypted contents do not match the checksum stored inside the backup. Do not restore from this file.');
    }

    return ['bytes' => $bytes, 'sha256' => $actualHash, 'meta' => $meta];
}

/**
 * The bytes a caller needs to build the metadata frame, taken from the live
 * database rather than trusted from the browser.
 */
function sfBakSnapshotMeta(PDO $db, string $plainPath, string $machineRef): array
{
    return [
        'app'          => 'storeflow',
        'release'      => defined('STOREFLOW_VERSION') ? STOREFLOW_VERSION : 'unknown',
        'machine_ref'  => $machineRef,
        'made_at_utc'  => gmdate('Y-m-d\TH:i:s\Z'),
        'plain_bytes'  => filesize($plainPath),
        'plain_sha256' => hash_file('sha256', $plainPath),
        'sqlite'       => $db->getAttribute(PDO::ATTR_SERVER_VERSION),
    ];
}
