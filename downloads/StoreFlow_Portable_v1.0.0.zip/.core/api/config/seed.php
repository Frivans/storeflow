<?php
// api/config/seed.php
// Optional initial seed for demonstration data

// This file writes rows and takes no authentication. router.php keeps it off the
// bundled server's allowlist, but under Apache the same protection is only whatever
// .htaccess says, so refuse to run for a web request here as well.
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once __DIR__ . '/db.php';

$count = $db->query("SELECT COUNT(*) as count FROM products")->fetch()['count'];
if ($count > 0) {
    echo json_encode(['message' => 'Database already seeded with products.']);
    exit;
}

$sampleProducts = [
    [
        'id' => 'prod_rice_50kg',
        'name' => 'Premium Royal Jasmine Rice (50kg Bag)',
        'sku' => 'SKU-RICE-50KG',
        'barcode' => '890100234510',
        'category' => 'Grains & Flour',
        'unit' => 'bag',
        'cost_price' => 38.00,
        'selling_price' => 52.00,
        'stock' => 45,
        'min_stock' => 10,
        'location' => 'Warehouse Bay A'
    ],
    [
        'id' => 'prod_cooking_oil_5l',
        'name' => 'Pure Vegetable Cooking Oil (5 Liters)',
        'sku' => 'SKU-OIL-5L',
        'barcode' => '890100234511',
        'category' => 'Food & Beverages',
        'unit' => 'bottle',
        'cost_price' => 8.50,
        'selling_price' => 12.00,
        'stock' => 60,
        'min_stock' => 15,
        'location' => 'Main Shelf 2'
    ],
    [
        'id' => 'prod_wheat_flour_25kg',
        'name' => 'All-Purpose Baker Wheat Flour (25kg)',
        'sku' => 'SKU-FLOUR-25KG',
        'barcode' => '890100234512',
        'category' => 'Grains & Flour',
        'unit' => 'bag',
        'cost_price' => 18.00,
        'selling_price' => 25.50,
        'stock' => 30,
        'min_stock' => 8,
        'location' => 'Warehouse Bay B'
    ],
    [
        'id' => 'prod_sugar_50kg',
        'name' => 'Refined Granulated Cane Sugar (50kg)',
        'sku' => 'SKU-SUGAR-50KG',
        'barcode' => '890100234513',
        'category' => 'Food & Beverages',
        'unit' => 'bag',
        'cost_price' => 42.00,
        'selling_price' => 56.00,
        'stock' => 20,
        'min_stock' => 5,
        'location' => 'Warehouse Bay A'
    ],
    [
        'id' => 'prod_pasta_carton',
        'name' => 'Italian Spaghetti Pasta (Carton of 20 Packs)',
        'sku' => 'SKU-PASTA-CTN',
        'barcode' => '890100234514',
        'category' => 'Packaged Goods',
        'unit' => 'carton',
        'cost_price' => 14.00,
        'selling_price' => 20.00,
        'stock' => 4,
        'min_stock' => 10, // will trigger low stock alert
        'location' => 'Main Shelf 1'
    ],
    [
        'id' => 'prod_soap_bar_box',
        'name' => 'Antiseptic Bathing Soap (Box of 48)',
        'sku' => 'SKU-SOAP-BX',
        'barcode' => '890100234515',
        'category' => 'Toiletries & Soaps',
        'unit' => 'box',
        'cost_price' => 22.00,
        'selling_price' => 32.00,
        'stock' => 0, // out of stock test
        'min_stock' => 5,
        'location' => 'Main Shelf 4'
    ]
];

$db->beginTransaction();

$pStmt = $db->prepare("INSERT INTO products (id, name, sku, barcode, category, unit, cost_price, selling_price, min_stock_alert, is_active, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, datetime('now'), datetime('now'))");
$iStmt = $db->prepare("INSERT INTO inventory (id, product_id, current_quantity, reorder_level, location, updated_at) VALUES (?, ?, ?, ?, ?, datetime('now'))");
$mStmt = $db->prepare("INSERT INTO inventory_movements (id, product_id, movement_type, quantity, reference_id, unit_price, notes, created_at) VALUES (?, ?, 'INITIAL_STOCK', ?, 'SEED', ?, 'Initial demonstration stock', datetime('now'))");

foreach ($sampleProducts as $p) {
    $pStmt->execute([$p['id'], $p['name'], $p['sku'], $p['barcode'], $p['category'], $p['unit'], $p['cost_price'], $p['selling_price'], $p['min_stock']]);
    $iStmt->execute(['inv_' . bin2hex(random_bytes(6)), $p['id'], $p['stock'], $p['min_stock'], $p['location']]);
    if ($p['stock'] > 0) {
        $mStmt->execute(['mvt_' . bin2hex(random_bytes(6)), $p['id'], $p['stock'], $p['cost_price']]);
    }
}

// Add sample factory purchase order
$poId = 'po_seed_001';
$db->exec("INSERT INTO purchases (id, order_number, supplier_name, supplier_contact, order_date, status, total_cost, shipping_cost, notes, created_by, created_at, updated_at)
           VALUES ('{$poId}', 'PO-20261020-001', 'Golden Harvest Mills Ltd', '+1 (555) 888-1212', '2026-10-20', 'RECEIVED', 2480.00, 50.00, 'Batch delivery to warehouse', 1, datetime('now'), datetime('now'))");

$db->exec("INSERT INTO purchase_items (id, purchase_id, product_id, quantity, cost_price, subtotal)
           VALUES ('pi_seed_1', '{$poId}', 'prod_rice_50kg', 40, 38.00, 1520.00),
                  ('pi_seed_2', '{$poId}', 'prod_cooking_oil_5l', 50, 8.50, 425.00),
                  ('pi_seed_3', '{$poId}', 'prod_sugar_50kg', 12, 42.00, 504.00)");

// Add sample customer
$db->exec("INSERT INTO customers (id, name, phone, email, address, balance, notes, created_at, updated_at)
           VALUES ('cust_101', 'Greenwood Groceries & Retail', '+1 (555) 789-0123', 'orders@greenwoodgroceries.local', '42 Elm Street, Market District', 0.00, 'Regular wholesale buyer', datetime('now'), datetime('now'))");

// Add sample initial sale
$saleId = 'sale_seed_001';
$db->exec("INSERT INTO sales (id, receipt_number, customer_id, user_id, sale_date, subtotal, discount, tax, total_amount, total_cost, gross_profit, payment_method, amount_paid, change_due, status, notes, created_at, updated_at)
           VALUES ('{$saleId}', 'REC-20261021-1001', 'cust_101', 1, datetime('now'), 176.00, 0.00, 0.00, 176.00, 126.00, 50.00, 'CASH', 200.00, 24.00, 'COMPLETED', 'First morning sale', datetime('now'), datetime('now'))");

$db->exec("INSERT INTO sale_items (id, sale_id, product_id, quantity, unit_cost_price, unit_selling_price, subtotal, profit)
           VALUES ('si_seed_1', '{$saleId}', 'prod_rice_50kg', 2, 38.00, 52.00, 104.00, 28.00),
                  ('si_seed_2', '{$saleId}', 'prod_cooking_oil_5l', 6, 8.50, 12.00, 72.00, 21.00)");

$db->commit();
echo json_encode(['success' => true, 'message' => 'Sample products, inventory, factory purchase, and sale seeded successfully.']);
