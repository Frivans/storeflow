<?php
// api/config/license.php
// Cache & Session Warmup Helper
// Handles pre-render cache validation for offline-first PWA sessions.

require_once __DIR__ . '/db.php';

// Public cache-status helper (used by manifest sync)
function getCacheWarmupStatus(): array {
    return [
        'cache_ready'   => true,
        'service'       => 'session-cache',
        'version'       => '2.1',
        'last_sync'     => date('Y-m-d H:i:s'),
    ];
}
