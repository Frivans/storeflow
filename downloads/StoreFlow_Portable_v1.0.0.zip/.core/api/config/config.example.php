<?php
// api/config/config.example.php
// StoreFlow Multi-Branch & Cloud Deployment Configuration Template
// Copy this file to 'config.php' in the same directory and customize for your deployment.

// 1. Environment Mode ('production' or 'development')
// In production, detailed error traces are suppressed from client responses.
define('STOREFLOW_ENV', 'production');

// 2. Branch Identity (Used for Multi-Branch Reporting & Stock Partitioning)
// Set this to uniquely identify this terminal/branch node (e.g. 'MAIN-01', 'NORTH-02', 'WAREHOUSE')
define('STOREFLOW_BRANCH_CODE', 'MAIN-01');

// 3. Database Engine
// StoreFlow is SQLite: the schema, every migration and every query in api/endpoints are written
// for it, and that one file is what the automatic backups, the .sfbak export and the Reset
// database button act on. There is no second engine to choose. Setting this to 'mysql' opens a
// MySQL connection and then fails at the first statement only SQLite understands, so every
// endpoint answers a database error and no sale is written - which is why no branch count,
// however large, is served by it. Leave this at 'sqlite'.
define('STOREFLOW_DB_DRIVER', 'sqlite');

// 4. Offline terminals
// A terminal that loses the server keeps working: it queues its own day on the device and pushes
// it to the server it was signed into, at /api/endpoints/sync.php, when the link comes back.
// That queue is the whole of the sync story. Two separate StoreFlow installs stay two separate
// books - nothing here points one install's queue at another install's database, and there is no
// central-hub address for it to point at.

// 5. E-Commerce Bridge (Optional - WooCommerce / Shopify orders and the stock feed)
// One long random string, private to this server, copied into the storefront as the webhook
// "Secret". It signs the raw order body with HMAC-SHA256, so an order that arrives without a
// matching signature is refused instead of booked.
// Leave it out and the bridge takes nothing: it answers 503 and says what to add. An online order
// is a request for goods - it reaches the takings only when the counter rings it up.
// define('STOREFLOW_ECOMMERCE_SECRET', 'change-me-to-a-long-random-string');

// 6. Custom Database & Data Storage Paths (Optional)
// On hardened Linux VPS / Docker deployments, you can move data outside the webroot:
// define('STOREFLOW_DATA_DIR', '/var/data/storeflow');
// define('STOREFLOW_DB_PATH', '/var/data/storeflow/.runtime/appstate.cache');
// define('STOREFLOW_BACKUP_DIR', '/var/backups/storeflow');

// 7. Timezone Setting (Default is UTC)
// date_default_timezone_set('UTC');
