<?php
// api/config/sys_integrity.php
// System Integrity, Session Scope & Dual-Mode License/Trial Validator
// Internal module — not for direct HTTP access.

// ── License trust anchor ──────────────────────────────────────────────────────
// Activation keys are Ed25519 signatures made by Evans' offline private key
// (tools/keys/, never shipped, never committed). Only the public half is here,
// so reading the source on a customer machine tells them nothing about how to
// produce a key for a different machine.
//
// This is the ONLY authority. There is deliberately no shared secret in the
// shipped code: an earlier revision also stamped the scope row with an HMAC, and
// because that seed travelled with the app, any customer could have written
// scope='FULL' plus a matching tag and activated without ever buying a key.
define('STOREFLOW_LICENSE_PUBKEY',
    '954F0E514BBFDECF95DF11C720A40B5859246C67FBECE6D675BBC355' .
    '3DD2B064');

// ── Bootstrap: create _app_meta table if absent ───────────────────────────────
function _sysEnsureMeta(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS _app_meta (
        id              INTEGER PRIMARY KEY CHECK (id = 1),
        install_ref     TEXT    NOT NULL,
        quota_window    INTEGER NOT NULL DEFAULT 0,
        quota_start     TEXT    NOT NULL DEFAULT (date('now')),
        unlock_token    TEXT    DEFAULT NULL,
        unlocked_at     TEXT    DEFAULT NULL,
        scope           TEXT    NOT NULL DEFAULT 'LOCKED',
        sys_created     TEXT    NOT NULL DEFAULT (datetime('now')),
        book_epoch      TEXT    DEFAULT NULL
    )");

    // integrity_tag existed while the HMAC seed was still trusted; it is ignored now.
    // Existing installs keep the column, which is harmless.
    $columns = [];
    foreach ($db->query("PRAGMA table_info(_app_meta)")->fetchAll() as $col) {
        $columns[] = $col['name'] ?? '';
    }
    if (!in_array('book_epoch', $columns, true)) {
        $db->exec("ALTER TABLE _app_meta ADD COLUMN book_epoch TEXT");
    }

    $n = (int)$db->query("SELECT COUNT(*) FROM _app_meta WHERE id = 1")->fetchColumn();
    if ($n === 0) {
        $ref  = bin2hex(random_bytes(18));
        // New installs start in LOCKED state until Evans provides a trial or lifetime key
        $stmt = $db->prepare(
            "INSERT INTO _app_meta (id, install_ref, quota_window, quota_start, scope, book_epoch)
             VALUES (1, ?, 0, date('now'), 'LOCKED', ?)"
        );
        $stmt->execute([$ref, _sysMintBookEpoch()]);
        return;
    }

    // A book that predates the column: the ALTER above leaves it NULL. Fill it in place.
    $unnamed = (int)$db->query("SELECT COUNT(*) FROM _app_meta WHERE id = 1
                                AND (book_epoch IS NULL OR book_epoch = '')")->fetchColumn();
    if ($unnamed > 0) {
        $db->prepare("UPDATE _app_meta SET book_epoch = ? WHERE id = 1")
           ->execute([_sysMintBookEpoch()]);
    }
}

// ── Which book this database file is ─────────────────────────────────────────
// Every record a till pushes is filed under the id the *device* chose, and a receipt names
// its own goods, so a till that queued its day against a database the shop no longer uses
// writes that day into whichever book is standing there now. Evans lost a reset demo book
// this way on 2026-11-01: his phone came up on the ngrok address and reinstated the whole
// pre-reset day into the new file - deleted products and all. A restore does the same thing,
// which makes the papers' "a restore is undoable" a claim the sync path contradicts.
//
// One random token per database file, minted when the file is first opened, is enough for a
// till to notice it is no longer talking to the book its queue belongs to. It is not a
// secret and not a licence: install_ref above is what the Machine ID is built from, and
// rotating the epoch leaves that alone. It is the reason the reset button and the restore
// path can be trusted to retire a stale till's queue instead of feeding it.
function _sysMintBookEpoch(): string {
    return bin2hex(random_bytes(16));
}

function _sysBookEpoch(PDO $db): string {
    _sysEnsureMeta($db);
    return (string)$db->query("SELECT book_epoch FROM _app_meta WHERE id = 1")->fetchColumn();
}

// A new book, in place: the records in it are the shop's business, the name is what every
// till has to catch up with.
function _sysRotateBookEpoch(PDO $db): string {
    $epoch = _sysMintBookEpoch();
    _sysEnsureMeta($db);
    $db->prepare("UPDATE _app_meta SET book_epoch = ? WHERE id = 1")->execute([$epoch]);
    return $epoch;
}

// ── Machine fingerprint ───────────────────────────────────────────────────────
function _sysMachineRef(PDO $db): string {
    $row = $db->query("SELECT install_ref FROM _app_meta WHERE id = 1")->fetch();
    if (!$row) return '';
    $host = gethostname() ?: 'local';
    return hash('sha256', $host . ':' . $row['install_ref']);
}

// ── Activation attempt throttle ──────────────────────────────────────────────
// The paywall screen posts a key before anyone is signed in, so the activation
// endpoint cannot be protected by a session. Without a ceiling it is an
// unlimited oracle for testing guessed keys. State lives in a file rather than
// the database because the database itself is what a locked install is arguing
// with, and a clock rollback can only widen the window, not erase the count.
function _sysThrottlePath(): string {
    $dir = defined('STOREFLOW_DATA_DIR')
        ? STOREFLOW_DATA_DIR
        : dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'data';
    $runtime = $dir . DIRECTORY_SEPARATOR . '.runtime';
    if (!is_dir($runtime)) @mkdir($runtime, 0777, true);
    return $runtime . DIRECTORY_SEPARATOR . 'activation_attempts';
}

function _sysThrottleWindow(int $windowSeconds = 900): array {
    $now = time();
    $cutOff = $now - $windowSeconds;
    $attempts = [];
    foreach (_sysThrottleStamps() as $when) {
        // Keep future-dated stamps. Dropping them meant that setting the clock
        // forward, burning the eight attempts, then setting it back left the
        // ledger reading empty - and activation is an unauthenticated endpoint,
        // so that is an unlimited key oracle.
        if ($when > $cutOff) {
            $attempts[] = $when;
        }
    }
    sort($attempts);
    return $attempts;
}

/**
 * Read the attempt ledger as a list of integer stamps, tolerating the bare-list shape the
 * file has always used.
 */
function _sysThrottleStamps(): array {
    $decoded = json_decode((string)@file_get_contents(_sysThrottlePath()), true);
    if (!is_array($decoded)) {
        return [];
    }
    $stamps = [];
    foreach ($decoded as $when) {
        if (is_numeric($when)) {
            $stamps[] = (int)$when;
        }
    }
    return $stamps;
}

/**
 * Bring a ledger written under a clock that has since moved back onto the clock the machine
 * is on now, and persist that.
 *
 * A stamp further ahead of the current clock than a whole window is not a promise about the
 * future; it is an attempt that happened while the clock was wrong. Counting it against the
 * clock that made it is what locked honest tills: the customer whose machine ran three hours
 * fast, mistyped the key eight times and then let Windows correct the date found eight
 * stamps that all still satisfied "newer than now minus the window", so the paywall refused
 * a genuine key forever and the retry countdown re-armed itself every time.
 *
 * Pulling those stamps to now keeps the budget spent - eight attempts are still eight
 * attempts, so a forward-then-back clock cannot buy a fresh set - while making the lockout
 * end a window later in real time.
 */
function _sysThrottleSettle(int $windowSeconds = 900): void {
    $now = time();
    $horizon = $now + $windowSeconds;
    $stamps = _sysThrottleStamps();
    $changed = false;
    foreach ($stamps as $i => $when) {
        if ($when > $horizon) {
            $stamps[$i] = $now;
            $changed = true;
        }
    }
    if (!$changed) {
        return;
    }
    sort($stamps);
    _sysThrottleWrite($stamps);
}

function _sysThrottleWrite(array $stamps): void {
    $file = _sysThrottlePath();
    // The caller always reads the list before opening this handle: on Windows a handle opened
    // with 'c' cannot be read back reliably after flock (errno 9), which once reduced the ledger
    // silently to its last attempt.
    $fh = @fopen($file, 'c');
    if (!$fh) {
        error_log('StoreFlow throttle: cannot write ' . $file . ' - credential-guess throttling is NOT enforced for this request.');
        return;
    }
    try {
        if (flock($fh, LOCK_EX)) {
            ftruncate($fh, 0);
            rewind($fh);
            fwrite($fh, json_encode(array_values($stamps)));
            fflush($fh);
        }
    } finally {
        flock($fh, LOCK_UN);
        fclose($fh);
    }
}

function _sysThrottleInspect(int $limit = 8, int $windowSeconds = 900): array {
    _sysThrottleSettle($windowSeconds);
    $attempts = _sysThrottleWindow($windowSeconds);
    if (count($attempts) >= $limit) {
        // Sliding window: the lockout lifts once the attempt $limit steps back
        // falls out of the window, not once the very first one does. The value is
        // capped because a clock can still date an attempt a little ahead of now;
        // the count above is what actually enforces the lockout either way.
        $expiry = $attempts[count($attempts) - $limit] + $windowSeconds;
        $retry = max(1, min($expiry - time(), 2 * $windowSeconds));
        return ['allowed' => false, 'retry_after' => $retry, 'used' => count($attempts)];
    }
    return ['allowed' => true, 'retry_after' => 0, 'used' => count($attempts)];
}

function _sysThrottleRecord(int $windowSeconds = 900): void {
    $now = time();
    _sysThrottleSettle($windowSeconds);
    $kept = _sysThrottleWindow($windowSeconds);
    $kept[] = $now;
    _sysThrottleWrite($kept);
}

function _sysThrottleClear(): void {
    @unlink(_sysThrottlePath());
}

// ── Activation key format ─────────────────────────────────────────────────────
//   SFLOW2-<KIND>-<signature>     KIND = LIFE, or T<days> for a trial
//   signature = 64-byte Ed25519 signature, as 16 groups of 8 hex characters
//
// The signature covers "SFLOW2|<machine ref>|<KIND>", so the key is bound to the
// terminal that displayed the machine ID and cannot be replayed elsewhere.
const _SYS_LICENSE_REGEX = '/^SFLOW2-(LIFE|T\d{1,3})-' .
                           '([0-9A-F]{8}(?:-[0-9A-F]{8}){15})$/';

function _sysLicensePayload(string $machineRef, string $kindTag): string
{
    $kind = $kindTag === 'LIFE' ? 'LIFE' : 'TRIAL-' . (int)substr($kindTag, 1);
    return 'SFLOW2|' . strtolower(trim($machineRef)) . '|' . $kind;
}

/**
 * Verify an activation key against a machine reference.
 *
 * Returns ['kind' => 'FULL'|'LIMITED', 'days' => int] for a genuine key, or null.
 * The public key defaults to the shipped trust anchor; the parameter exists so
 * the unit test can exercise the algorithm with a throwaway keypair without
 * ever granting a caller that choice over the HTTP path.
 */
function _sysVerifyLicenseKey(string $token, string $machineRef, ?string $publicKeyHex = null): ?array
{
    if (!function_exists('sodium_crypto_sign_verify_detached')) {
        return null;
    }
    $supplied = strtoupper(preg_replace('/\s+/', '', $token));
    if ($supplied === '' || $machineRef === '' || !preg_match(_SYS_LICENSE_REGEX, $supplied, $m)) {
        return null;
    }

    $signature = @hex2bin(str_replace('-', '', $m[2]));
    if ($signature === false || strlen($signature) !== SODIUM_CRYPTO_SIGN_BYTES) {
        return null;
    }

    $pub = @hex2bin(strtoupper(preg_replace('/\s+/', '', (string)($publicKeyHex ?? STOREFLOW_LICENSE_PUBKEY))));
    if ($pub === false || strlen($pub) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES) {
        return null;
    }

    if (!sodium_crypto_sign_verify_detached($signature, _sysLicensePayload($machineRef, $m[1]), $pub)) {
        return null;
    }

    if ($m[1] === 'LIFE') {
        return ['kind' => 'FULL', 'days' => 0];
    }
    $days = (int)substr($m[1], 1);
    if ($days < 1 || $days > 365) {
        return null;
    }
    return ['kind' => 'LIMITED', 'days' => $days];
}

// ── Trial clock witness ───────────────────────────────────────────────────────
// A trial's start date lives in a column the customer can edit, so "change the
// date, get a fresh trial" used to be free. The high-water mark of days already
// consumed is therefore kept next to the database as well, and the larger of the
// two wins. This stops casual date tampering; it does not pretend to stop someone
// who forges the file too, and no offline scheme can.
function _sysTrialWitnessPath(): string {
    $dir = defined('STOREFLOW_DATA_DIR')
        ? STOREFLOW_DATA_DIR
        : dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'data';
    $runtime = $dir . DIRECTORY_SEPARATOR . '.runtime';
    if (!is_dir($runtime)) @mkdir($runtime, 0777, true);
    return $runtime . DIRECTORY_SEPARATOR . 'trial_witness';
}

// $now is the clock reading to measure against and defaults to the machine's own. It exists so
// the suite can walk a trial through the wrong clocks a shop actually arrives with; no HTTP
// caller can reach it, so nobody can be handed a trial day by asking for one.
function _sysTrialDaysUsed(PDO $db, array $row, int $quotaDays, ?int $now = null): int {
    $now = $now ?? time();
    // Every writer of this column stamps it in UTC - SQLite's date('now') above, and the gmdate()
    // that writes unlocked_at beside it - so it has to be read back in UTC too. Measured against
    // the server's local zone instead, a shop east of Greenwich activates on what its own wall
    // already calls the next day, and is handed a trial that is a day old before it opens the till.
    $rawStart = trim((string)($row['quota_start'] ?? ''));
    $start = $rawStart === '' ? $now : strtotime($rawStart . ' UTC');
    if ($start === false) $start = $now;

    $tokenFp = _sysWitnessFingerprint((string)($row['unlock_token'] ?? ''));
    $path = _sysTrialWitnessPath();
    $witness = @json_decode((string)@file_get_contents($path), true);
    if (!is_array($witness) || ($witness['token'] ?? '') !== $tokenFp) {
        $witness = ['token' => $tokenFp, 'seen_days' => 0];
    }

    // A start date in the future is either a rolled-forward clock or a hand-edit. Either way it
    // buys nothing: elapsed time is never negative, and the reference below never runs backwards,
    // so a day the shop already traded is not refunded by changing the date.
    $refClock = max($now, max(0, (int)($witness['seen_clock'] ?? 0)));
    $fromDb = max(0, (int)floor(($refClock - $start) / 86400));

    // Subtracting a clock the customer owns is not the only way to count a day, and it is the way
    // that fails quietly: a date put back one day every morning keeps (now - start) under a day
    // forever, so fromDb stayed nil, the witness wrote that nil back over itself, and a trial ran
    // on without anyone editing a file. So the witness also counts the days the till was opened
    // under a clock that was being *driven* backwards - the same step more than once running.
    //
    // A single backwards step is not charged, because the common wrong clock is not a tamperer: a
    // dual-boot machine whose hardware clock fights the operating system flips by a day on every
    // boot, and billing that shop for a flat CMOS battery is a worse outcome than the leak.
    $dayIndex = intdiv($now, 86400);
    $lastDay = isset($witness['last_day']) ? (int)$witness['last_day'] : $dayIndex;
    $delta = $dayIndex <=> $lastDay;
    $ticks = max(0, (int)($witness['day_ticks'] ?? 0));
    if ($delta === -1 && (int)($witness['last_delta'] ?? 0) === -1) {
        $ticks++;
    }

    $daysUsed = max($fromDb, $ticks, (int)($witness['seen_days'] ?? 0), 0);

    $witness['seen_days'] = $daysUsed;
    $witness['seen_clock'] = $refClock;
    $witness['last_day'] = $dayIndex;
    $witness['last_delta'] = $delta;
    $witness['day_ticks'] = $ticks;
    @file_put_contents($path, json_encode($witness));

    return min($daysUsed, $quotaDays);
}

function _sysWitnessFingerprint(string $token): string {
    return substr(hash('sha256', trim($token)), 0, 16);
}

function _sysResetTrialWitness(string $token, ?int $now = null): void {
    $now = $now ?? time();
    // A fresh key starts its own count from the clock it was handed over on, so the first day of
    // a trial is not already charged with wherever the previous key's clock had got to.
    @file_put_contents(_sysTrialWitnessPath(), json_encode([
        'token'      => _sysWitnessFingerprint($token),
        'seen_days'  => 0,
        'seen_clock' => $now,
        'last_day'   => intdiv($now, 86400),
        'last_delta' => 0,
        'day_ticks'  => 0,
    ]));
}

// ── Scope resolver ────────────────────────────────────────────────────────────
// The stored scope column is a cache, never an authority: what an install may do
// is decided by re-verifying the saved activation key against the public key and
// THIS machine's reference, on every read. Editing scope, quota_window or the old
// integrity tag in the database therefore buys nothing, because none of them are
// consulted unless a genuine signature backs them.
function _sysLockedScope(string $machineRef, int $quotaDays, bool $isInitial, ?string $unlockedAt = null): array {
    return [
        'scope'       => 'LOCKED',
        'days_used'   => 0,
        'days_left'   => 0,
        'quota_days'  => $quotaDays,
        'machine_ref' => $machineRef,
        'unlocked_at' => $unlockedAt,
        'is_initial'  => $isInitial
    ];
}

function _sysGetScope(PDO $db): array {
    _sysEnsureMeta($db);

    $row = $db->query("SELECT * FROM _app_meta WHERE id = 1")->fetch();
    $machineRef = _sysMachineRef($db);

    if (!$row) {
        return _sysLockedScope($machineRef, 0, true);
    }

    $token = trim((string)($row['unlock_token'] ?? ''));
    if ($token === '') {
        return _sysLockedScope($machineRef, 0, ($row['scope'] ?? 'LOCKED') === 'LOCKED');
    }

    $verified = _sysVerifyLicenseKey($token, $machineRef);
    if ($verified === null) {
        // Covers a key minted for another machine, a hand-written row, and an
        // edited scope: all of them now read as "not activated".
        return _sysLockedScope($machineRef, (int)$row['quota_window'], false);
    }

    if ($verified['kind'] === 'FULL') {
        return [
            'scope'       => 'FULL',
            'days_used'   => 0,
            'days_left'   => 9999,
            'quota_days'  => 0,
            'machine_ref' => $machineRef,
            'unlocked_at' => $row['unlocked_at'] ?? null,
            'is_initial'  => false
        ];
    }

    $quotaDays = (int)$verified['days'];
    $daysUsed  = _sysTrialDaysUsed($db, $row, $quotaDays);
    $daysLeft  = $quotaDays - $daysUsed;

    if ($daysLeft <= 0) {
        $locked = _sysLockedScope($machineRef, $quotaDays, false, $row['unlocked_at'] ?? null);
        $locked['days_used'] = $quotaDays;
        return $locked;
    }

    return [
        'scope'       => 'LIMITED',
        'days_used'   => $daysUsed,
        'days_left'   => $daysLeft,
        'quota_days'  => $quotaDays,
        'machine_ref' => $machineRef,
        'unlocked_at' => $row['unlocked_at'] ?? null,
        'is_initial'  => false
    ];
}

// ── Activation key verifier & dual-mode activator (trial or lifetime) ─────────
function _sysApplyToken(PDO $db, string $tokenInput): array {
    _sysEnsureMeta($db);

    if (!function_exists('sodium_crypto_sign_verify_detached')) {
        // Fail closed and say why: without sodium no key can be checked, and a
        // silent "invalid key" would send the customer chasing a bad key.
        return [
            'ok'  => false,
            'msg' => 'This StoreFlow install cannot verify activation keys because the PHP sodium extension is not loaded. Start it with the bundled php folder (StoreFlow.exe), or enable extension=sodium in php.ini.'
        ];
    }

    $machineRef = _sysMachineRef($db);
    $supplied   = strtoupper(preg_replace('/\s+/', '', trim($tokenInput)));

    // Legacy SFLOW-<hmac> keys are rejected outright: the secret that minted them
    // shipped inside the app, so anyone who could read the source could mint one.
    // Being pre-launch, no install holds such a key, and re-activation is anyway
    // machine-bound — a fresh install generates a new install_ref and so a new
    // machine ID. Anyone who does need one gets a new key for their current ID.
    if (preg_match('/^SFLOW-(LIFE|TR?\d{1,3})-/i', $supplied) || preg_match('/^SFLOW-[A-Z0-9]{5}-[A-Z0-9]{5}-/i', $supplied)) {
        return [
            'ok'  => false,
            'msg' => 'This is an outdated activation key. Send your Machine ID to support to receive a new one.'
        ];
    }

    $verified = _sysVerifyLicenseKey($supplied, $machineRef);
    if ($verified === null) {
        return [
            'ok'  => false,
            'msg' => 'The provided activation key could not be verified for this Machine ID. Please check and try again.'
        ];
    }

    $now = gmdate('Y-m-d H:i:s');

    // Nothing else is written alongside the key. The scope column is a display
    // cache: _sysGetScope() re-verifies this token on every read, so a row that
    // claims FULL without a signature behind it resolves to LOCKED.
    if ($verified['kind'] === 'FULL') {
        $stmt = $db->prepare(
            "UPDATE _app_meta
             SET scope = 'FULL', quota_window = 0, quota_start = date('now'), unlock_token = ?, unlocked_at = ?
             WHERE id = 1"
        );
        $stmt->execute([$supplied, $now]);

        return [
            'ok'  => true,
            'msg' => 'StoreFlow permanently activated with Lifetime License! Thank you for your business.'
        ];
    }

    $days = $verified['days'];
    $stmt = $db->prepare(
        "UPDATE _app_meta
         SET scope = 'LIMITED', quota_window = ?, quota_start = date('now'), unlock_token = ?, unlocked_at = ?
         WHERE id = 1"
    );
    $stmt->execute([$days, $supplied, $now]);

    // A new key starts a new trial clock, so the witness high-water mark is
    // re-seeded here rather than inheriting the previous key's consumed days.
    _sysResetTrialWitness($supplied);

    return [
        'ok'  => true,
        'msg' => "Trial successfully activated for {$days} days! You have {$days} days remaining."
    ];
}
