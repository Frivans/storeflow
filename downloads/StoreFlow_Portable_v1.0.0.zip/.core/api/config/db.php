<?php
// api/config/db.php
// Central Database Connection & Initialization for SQLite with Products

header('Content-Type: application/json; charset=UTF-8');
date_default_timezone_set('UTC');

// The version every response, package and screen has to agree on.
require_once __DIR__ . DIRECTORY_SEPARATOR . 'version.php';

// StoreFlow Extensible Action & Filter Hook System
require_once __DIR__ . DIRECTORY_SEPARATOR . 'hooks.php';

// StoreFlow Loyalty & Rewards Engine
require_once __DIR__ . DIRECTORY_SEPARATOR . 'loyalty.php';

// Load optional local/cloud configuration overrides if present
$configFile = __DIR__ . DIRECTORY_SEPARATOR . 'config.php';
if (file_exists($configFile)) {
    require_once $configFile;
}

// Production hardening: suppress HTML error output in API JSON responses
ini_set('display_errors', '0');
error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);

// Security: the API authenticates with a cookie, so a credentialed cross-origin
// response would let any page the till's browser visits read the store's data -
// including another device on the same LAN serving itself a 192.168.* origin.
// Only the authority the request was actually served under is allowed, which is
// what every first-party page (till, phone companion) is loaded from anyway.
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
$allowedOrigin = false;

if ($origin) {
    $parsed = parse_url($origin);
    $originHost = strtolower($parsed['host'] ?? '');
    $originPort = $parsed['port'] ?? null;

    // A browser sends one canonical origin: scheme://host[:port], nothing else. Anything
    // carrying userinfo, a path or a query is not an origin a real page can present, so it
    // is refused outright rather than echoed.
    $looksCanonical = $originHost !== ''
        && empty($parsed['user']) && empty($parsed['pass'])
        && ($parsed['path'] ?? '') === ''
        && !isset($parsed['query']) && !isset($parsed['fragment']);

    // Parsing HTTP_HOST by splitting on ':' truncated an IPv6 authority to "[", so a phone
    // companion reaching the till over ::1 was refused its own origin.
    $requestAuthority = parse_url('http://' . strtolower($_SERVER['HTTP_HOST'] ?? ''), PHP_URL_HOST) ?: '';
    $requestHost = strtolower((string)$requestAuthority);
    if ($requestHost !== '' && $requestHost[0] === '[' && substr($requestHost, -1) === ']') {
        $requestHost = substr($requestHost, 1, -1);
    }
    $requestPort = $_SERVER['SERVER_PORT'] ?? null;
    $requestHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
    $scheme = strtolower($parsed['scheme'] ?? '');

    $hostMatches = $looksCanonical && ($originHost === $requestHost
        || ($originHost === 'localhost' && $requestHost === '127.0.0.1')
        || ($originHost === '127.0.0.1' && $requestHost === 'localhost'));

    // Compare the ports the two origins actually resolve to. An origin written
    // without a port means its scheme's default, so treating a missing port as a
    // wildcard let any page served from the same host on another port (a till on
    // :8095 and a second app on :80 is normal on XAMPP) be reflected with
    // credentials, which is exactly the cross-origin session read this block
    // exists to prevent.
    $effectiveOriginPort = (int)($originPort ?? ($scheme === 'https' ? 443 : 80));
    $effectiveRequestPort = (int)($requestPort ?? ($requestHttps ? 443 : 80));

    $portMatches = $effectiveOriginPort === $effectiveRequestPort;

    // The scheme is part of the match, not just used to infer a default port: reflecting
    // a credentialed https page from an http one (or the reverse) crosses origins.
    $schemeMatches = in_array($scheme, ['http', 'https'], true) && ($scheme === 'https') === $requestHttps;

    if ($hostMatches && $portMatches && $schemeMatches) {
        // Rebuilt rather than echoed, so whatever odd serialisation the caller sent can
        // never be handed back as the authoritative origin of this response.
        $allowedOrigin = $scheme . '://'
            . (filter_var($originHost, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) ? '[' . $originHost . ']' : $originHost)
            . ':' . $effectiveOriginPort;
    }
}

if ($allowedOrigin) {
    header("Access-Control-Allow-Origin: $allowedOrigin");
    header('Access-Control-Allow-Credentials: true');
}
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

if (session_status() === PHP_SESSION_NONE) {
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ||
               (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https') ||
               (!empty($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443);

    ini_set('session.cookie_httponly', '1');
    ini_set('session.cookie_samesite', 'Lax');
    if ($isHttps) {
        ini_set('session.cookie_secure', '1');
    }
    ini_set('session.gc_maxlifetime', '50400'); // 14 hours (retail double-shift window)
    ini_set('session.cookie_lifetime', '50400'); // 14 hours
    session_set_cookie_params([
        'lifetime' => 50400,
        'path' => '/',
        'httponly' => true,
        'secure' => $isHttps,
        'samesite' => 'Lax'
    ]);
    session_start();
}

$requestMethod = $_SERVER['REQUEST_METHOD'] ?? 'CLI';
if ($requestMethod === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$envDataDir = getenv('STOREFLOW_DATA_DIR');
if (defined('STOREFLOW_DATA_DIR')) {
    $dbDir = STOREFLOW_DATA_DIR;
} elseif (!empty($envDataDir)) {
    $dbDir = $envDataDir;
} else {
    $rootCandidate = dirname(__DIR__, 2);
    if (is_dir($rootCandidate . DIRECTORY_SEPARATOR . '.Runtime')) {
        $dbDir = $rootCandidate . DIRECTORY_SEPARATOR . '.Runtime';
    } elseif (is_dir(dirname($rootCandidate) . DIRECTORY_SEPARATOR . '.Runtime')) {
        $dbDir = dirname($rootCandidate) . DIRECTORY_SEPARATOR . '.Runtime';
    } else {
        $dbDir = $rootCandidate . DIRECTORY_SEPARATOR . 'data';
    }
}
$baseDirName = strtolower(basename($dbDir));
$runtimeDir = ($baseDirName === '.runtime') ? $dbDir : ($dbDir . DIRECTORY_SEPARATOR . '.runtime');

// If running on a desktop Windows PC, save backups into the user's personal Documents folder:
// C:\Users\<Username>\Documents\StoreFlow\backups\
// This protects backups from Program Files permission restrictions and disk resets.
if (defined('STOREFLOW_BACKUP_DIR')) {
    $backupDir = STOREFLOW_BACKUP_DIR;
} else {
    $userProfile = getenv('USERPROFILE');
    $docDir = ($userProfile && is_dir($userProfile . DIRECTORY_SEPARATOR . 'Documents'))
        ? ($userProfile . DIRECTORY_SEPARATOR . 'Documents' . DIRECTORY_SEPARATOR . 'StoreFlow' . DIRECTORY_SEPARATOR . 'backups')
        : '';
    if ($docDir && (!is_dir($docDir) ? @mkdir($docDir, 0777, true) : true)) {
        $backupDir = $docDir;
    } else {
        $backupDir = $dbDir . DIRECTORY_SEPARATOR . 'backups';
    }
}
$dbPath     = defined('STOREFLOW_DB_PATH') ? STOREFLOW_DB_PATH : ($runtimeDir . DIRECTORY_SEPARATOR . 'appstate.cache'); // disguised filename

if (!is_dir($dbDir))      mkdir($dbDir, 0777, true);
if (!is_dir($runtimeDir)) mkdir($runtimeDir, 0777, true);
if (!is_dir($backupDir))  mkdir($backupDir, 0777, true);

// These directories are created here on a customer's first run, which is also the
// moment they stop having a deny file: an archive that drops dotfiles, a copy that
// skips hidden items, or a data\ this script just made. Without one, Apache stops the
// live database by its .cache extension through the root file alone - a fallback that
// only exists when mod_rewrite is unavailable, and that a renamed state file slips
// past. Re-assert the deny wherever this code makes a directory.
$denyHtaccess = "<IfModule mod_authz_core.c>\n"
    . "    Require all denied\n</IfModule>\n"
    . "<IfModule !mod_authz_core.c>\n"
    . "    Order deny,allow\n"
    . "    Deny from all\n</IfModule>\n";
foreach ([$dbDir, $runtimeDir, $backupDir] as $protectDir) {
    $denyFile = $protectDir . DIRECTORY_SEPARATOR . '.htaccess';
    if (!is_file($denyFile)) { @file_put_contents($denyFile, $denyHtaccess); }
}

// data/store.db is DECOY ONLY (tools/create_bait_db.php): it sits at the obvious
// path so an intruder copies worthless data, while the real database lives in
// .runtime under a disguised name. No shipped release ever used store.db as the
// live database, so nothing here reads or promotes it. It used to be copied into
// appstate.cache when the live file looked "too small", which on a fresh install
// would have booted a customer into the bait.

$dbDriver = defined('STOREFLOW_DB_DRIVER') ? strtolower(STOREFLOW_DB_DRIVER) : 'sqlite';

function storeflow_db_driver(): string {
    return defined('STOREFLOW_DB_DRIVER') ? strtolower(STOREFLOW_DB_DRIVER) : 'sqlite';
}

function storeflow_is_mysql(): bool {
    return storeflow_db_driver() === 'mysql';
}

try {
    if ($dbDriver === 'mysql') {
        $dbHost = defined('STOREFLOW_DB_HOST') ? STOREFLOW_DB_HOST : '127.0.0.1';
        $dbPort = defined('STOREFLOW_DB_PORT') ? (int)STOREFLOW_DB_PORT : 3306;
        $dbName = defined('STOREFLOW_DB_NAME') ? STOREFLOW_DB_NAME : 'storeflow';
        $dbUser = defined('STOREFLOW_DB_USER') ? STOREFLOW_DB_USER : 'root';
        $dbPass = defined('STOREFLOW_DB_PASS') ? STOREFLOW_DB_PASS : '';
        $dsn = "mysql:host={$dbHost};port={$dbPort};dbname={$dbName};charset=utf8mb4";
        $db = new PDO($dsn, $dbUser, $dbPass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
        $db->exec("SET NAMES utf8mb4;");
    } else {
        $db = new PDO("sqlite:" . $dbPath);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

        // Performance & safety pragmas (auto-recover if a stale WAL journal or interrupted restore corrupted sqlite_master)
        try {
            $db->exec("PRAGMA busy_timeout = 5000;");
            $db->exec("PRAGMA foreign_keys = ON;");
            if (strtolower((string)$db->query("PRAGMA journal_mode")->fetchColumn()) !== 'wal') {
                $db->exec("PRAGMA journal_mode = WAL;");
            }
            $db->query("SELECT 1 FROM sqlite_master LIMIT 1")->fetchColumn();
        } catch (Throwable $schemaErr) {
            $db = null;
            if (file_exists($dbPath . '-wal')) @file_put_contents($dbPath . '-wal', '');
            @unlink($dbPath . '-wal');
            @unlink($dbPath . '-shm');
            $recovered = false;
            try {
                $probe = new PDO("sqlite:" . $dbPath);
                $probe->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                if (strtolower((string)$probe->query("PRAGMA integrity_check")->fetchColumn()) === 'ok') {
                    $recovered = true;
                }
                $probe = null;
            } catch (Throwable $probeErr) {
                $probe = null;
            }
            if (!$recovered && is_dir($backupDir)) {
                $candidates = glob($backupDir . DIRECTORY_SEPARATOR . '*.db') ?: [];
                usort($candidates, function ($a, $b) { return filemtime($b) <=> filemtime($a); });
                foreach ($candidates as $cand) {
                    try {
                        if (syncRestoredSqliteRuntime($cand, $dbPath)) {
                            break;
                        }
                    } catch (Throwable $ce) {}
                }
            }
            $db = new PDO("sqlite:" . $dbPath);
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            $db->exec("PRAGMA busy_timeout = 5000;");
            $db->exec("PRAGMA foreign_keys = ON;");
            if (strtolower((string)$db->query("PRAGMA journal_mode")->fetchColumn()) !== 'wal') {
                $db->exec("PRAGMA journal_mode = WAL;");
            }
        }
    }

    // Initialize schema if not present or upgraded
    //
    // Bumping this is what carries a new *table* to an existing till; a new *column* has to
    // go into schemaRequiredColumns() as well, because the number below cannot reach a file a
    // previous release already stamped at it. That is not a theoretical gap - purchases.credit_used
    // was added by ALTER and bumped nothing, and every factory purchase on the owner's own
    // shop died on "table purchases has no column named credit_used" until the shape check
    // below was told to look for it.
    //
    // 24 is the arrival workflow: purchase_events is a new table, so the number has to move
    // for an existing till to get it at all, and the counted columns move with it.
    // 25 is the money a return actually pays back: sales_returns gains three columns and every
    // return INSERT names them, so the shape check has to be the thing that catches a file
    // that never got them.
    // 26 is the number a supplier account starts with. vendor_opening_balances is a new table,
    // so the version has to move for an existing till to be told about it - and it is in the
    // shape check too, because a file an earlier build already stamped at 25 would otherwise
    // never run the migration that makes it.
    // 27 is the dining floor. Three new tables, so the number has to move for a till that has
    // never heard of them to get them - and the tab columns are in the shape check below too,
    // because an endpoint that writes table_orders.sale_id into a file that never got the column
    // does not fail loudly: it fails on the INSERT, after the money has already been taken.
    $schemaVersionTarget = 29;
    $currSchemaVer = 0;
    if ($dbDriver === 'sqlite') {
        try {
            $currSchemaVer = (int)$db->query("PRAGMA user_version")->fetchColumn();
        } catch (Exception $ve) {
            $currSchemaVer = 0;
        }

        if ($currSchemaVer < $schemaVersionTarget || schemaMissingColumns($db) !== []) {
            initializeDatabase($db);
            $db->exec("PRAGMA user_version = {$schemaVersionTarget};");
        }
    } else {
        // MySQL / MariaDB initialization for cloud instances
        initializeDatabase($db);
    }

    // Ensure license/trial table exists on every boot (safe – uses CREATE IF NOT EXISTS)
    require_once __DIR__ . '/sys_integrity.php';
    _sysEnsureMeta($db);

    // Pick up the settlements an earlier release paid but never applied.
    reconcileUnappliedVendorPayouts($db);

    // Heal sale gross profit excluding tax if needed
    healSaleGrossProfitExcludingTax($db);

    // Relink any rental_items whose product_id was replaced by a catalog re-import under the same product name
    healOrphanedRentalProductLinks($db);

    // Check and trigger 2-hour auto backup if due (SQLite file snapshots)
    if ($dbDriver === 'sqlite') {
        triggerAutoBackupIfDue($db, $dbPath, $backupDir);
    }

    // Boot extensible plugins & fire boot hook
    StoreFlowHooks::loadPlugins();
    storeflow_do_action('storeflow_booted', $db);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Database connection failed: ' . $e->getMessage()
    ]);
    exit;
}

function initializeDatabase(PDO $db) {
    // 1. Store Profile
    $db->exec("CREATE TABLE IF NOT EXISTS store_profile (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        store_name TEXT NOT NULL DEFAULT 'My Store Enterprise',
        tagline TEXT DEFAULT 'Your Trusted Quality Goods Supplier',
        phone TEXT DEFAULT '+1 (555) 234-5678',
        email TEXT DEFAULT 'contact@mystore.local',
        address TEXT DEFAULT '104 Commerce Boulevard, Suite 2B',
        tax_number TEXT DEFAULT 'TAX-89472190-TX',
        tax_rate REAL DEFAULT 0.0,
        currency_symbol TEXT DEFAULT '$',
        currency_code TEXT DEFAULT 'USD',
        receipt_header TEXT DEFAULT 'Thank you for shopping with us!',
        receipt_footer TEXT DEFAULT 'Goods received in good condition cannot be returned. We appreciate your patronage!',
        auto_backup_hours INTEGER DEFAULT 2,
        allow_negative_stock INTEGER DEFAULT 0,
        loyalty_enabled INTEGER DEFAULT 1,
        loyalty_points_per_currency REAL DEFAULT 1.0,
        loyalty_redemption_rate REAL DEFAULT 0.01,
        loyalty_redeem_at_counter INTEGER DEFAULT 1,
        loyalty_tier_perks INTEGER DEFAULT 0,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )");

    // Run schema migrations for existing database
    $profCols = $db->query("PRAGMA table_info(store_profile)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('allow_negative_stock', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN allow_negative_stock INTEGER DEFAULT 0");
    }
    if (!in_array('tax_rate', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN tax_rate REAL DEFAULT 0.0");
    }
    if (!in_array('branch_code', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN branch_code TEXT DEFAULT 'MAIN-01'");
    }
    if (!in_array('terminal_id', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN terminal_id TEXT DEFAULT 'REG-01'");
    }
    if (!in_array('is_multi_branch', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN is_multi_branch INTEGER DEFAULT 0");
    }
    if (!in_array('logo_url', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN logo_url TEXT DEFAULT NULL");
    }
    if (!in_array('print_logo_on_receipts', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN print_logo_on_receipts INTEGER DEFAULT 1");
    }
    if (!in_array('mnotify_api_key', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN mnotify_api_key TEXT DEFAULT ''");
    }
    if (!in_array('mnotify_sender_id', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN mnotify_sender_id TEXT DEFAULT 'StoreFlow'");
    }
    if (!in_array('mnotify_auto_sms', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN mnotify_auto_sms INTEGER DEFAULT 0");
    }
    if (!in_array('mnotify_owner_phone', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN mnotify_owner_phone TEXT DEFAULT ''");
    }
    if (!in_array('mnotify_low_stock_alert', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN mnotify_low_stock_alert INTEGER DEFAULT 1");
    }
    if (!in_array('mnotify_shift_close_alert', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN mnotify_shift_close_alert INTEGER DEFAULT 1");
    }
    if (!in_array('receipt_momo_note', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN receipt_momo_note TEXT DEFAULT ''");
    }
    if (!in_array('show_tax_on_receipt', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN show_tax_on_receipt INTEGER DEFAULT 1");
    }
    if (!in_array('show_cashier_on_receipt', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN show_cashier_on_receipt INTEGER DEFAULT 1");
    }
    if (!in_array('scanner_pairing_token', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN scanner_pairing_token TEXT DEFAULT NULL");
    }
    if (!in_array('receipt_font_size', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN receipt_font_size TEXT DEFAULT 'medium'");
    }
    if (!in_array('receipt_font_weight', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN receipt_font_weight TEXT DEFAULT 'normal'");
    }
    if (!in_array('receipt_font_family', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN receipt_font_family TEXT DEFAULT 'monospace'");
    }
    if (!in_array('receipt_paper_width', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN receipt_paper_width TEXT DEFAULT '80mm'");
    }
    if (!in_array('receipt_spacing', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN receipt_spacing TEXT DEFAULT 'ultra_compact'");
    }
    if (!in_array('operating_mode', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN operating_mode TEXT DEFAULT 'RETAIL'");
    }
    if (!in_array('enable_rentals', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN enable_rentals INTEGER DEFAULT 1");
    }
    // Loyalty is the shop's own policy, not a constant in the code: how many points a cedi buys,
    // what a point is worth back, whether a member may hand points over at the counter, and
    // whether a tier's perk is applied for them. Every one of these defaults reproduces what
    // StoreFlow has always actually done (1 pt per GH₵1, 1 pt worth GH₵0.01, redemption allowed,
    // no tier perk), so a shop that never opens the switch keeps behaving as it did.
    if (!in_array('loyalty_enabled', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN loyalty_enabled INTEGER DEFAULT 1");
    }
    if (!in_array('loyalty_points_per_currency', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN loyalty_points_per_currency REAL DEFAULT 1.0");
    }
    if (!in_array('loyalty_redemption_rate', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN loyalty_redemption_rate REAL DEFAULT 0.01");
    }
    if (!in_array('loyalty_redeem_at_counter', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN loyalty_redeem_at_counter INTEGER DEFAULT 1");
    }
    if (!in_array('loyalty_tier_perks', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN loyalty_tier_perks INTEGER DEFAULT 0");
    }
    if (!in_array('estimate_validity_days', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN estimate_validity_days INTEGER DEFAULT 7");
    }
    if (!in_array('enable_line_discounts', $profCols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN enable_line_discounts INTEGER DEFAULT 0");
    }

    // Insert default profile if missing
    //
    // The statement is freed, not merely fetched. A one-row SELECT pulled with fetch() leaves the
    // cursor in flight on store_profile - SQLite has not stepped it to its end - and while it is
    // in flight every later schema change on the same connection raises "database table is
    // locked". On a book that has never existed that went unnoticed, because the roles branch
    // below reassigns $stmt before the next DDL; on an existing till the branch is skipped, the
    // cursor lives to the end of the migration, and the only things that then fail are the
    // statements that genuinely alter the schema - which is how a rebuild of the loyalty index
    // came to break the upgrade boot of every shop installing over an old release.
    $profileStmt = $db->query("SELECT COUNT(*) as count FROM store_profile WHERE id = 1");
    $profileRows = intval($profileStmt->fetch()['count'] ?? 0);
    $profileStmt = null;
    if ($profileRows == 0) {
        $db->exec("INSERT INTO store_profile (id, store_name, tagline, phone, email, address, tax_number, currency_symbol, currency_code, receipt_header, receipt_footer, auto_backup_hours, allow_negative_stock, updated_at) 
                   VALUES (1, 'My Store Enterprise', 'Your Trusted Quality Goods Supplier', '+1 (555) 234-5678', 'contact@mystore.local', '104 Commerce Boulevard, Suite 2B', 'TAX-89472190-TX', '$', 'USD', 'Thank you for shopping with us!', 'Goods received in good condition cannot be returned. We appreciate your patronage!', 2, 0, datetime('now'))");
    }

    // 2. User Roles
    $db->exec("CREATE TABLE IF NOT EXISTS user_roles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        role_name TEXT UNIQUE NOT NULL,
        description TEXT,
        permissions TEXT NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )");

    $rolesCount = $db->query("SELECT COUNT(*) as count FROM user_roles")->fetch()['count'];
    if ($rolesCount == 0) {
        $adminPerms = json_encode(['manage_inventory', 'manage_sales', 'manage_purchases', 'view_reports', 'manage_users', 'manage_settings', 'manage_backups']);
        $mgrPerms = json_encode(['manage_inventory', 'manage_sales', 'manage_purchases', 'view_reports']);
        $cashierPerms = json_encode(['manage_sales']);

        $stmt = $db->prepare("INSERT INTO user_roles (role_name, description, permissions) VALUES (?, ?, ?)");
        $stmt->execute(['Administrator', 'Full system access & administration', $adminPerms]);
        $stmt->execute(['Store Manager', 'Inventory, factory purchasing, sales & reporting', $mgrPerms]);
        $stmt->execute(['Cashier', 'Point of sale and customer receipts', $cashierPerms]);
    }

    // The discount ceiling used to be a literal inside saleDiscountCap(). It belongs to the
    // role now so the Access Map can edit it beside the permissions that grant it. 10 is the
    // number that literal held, so a shop that has never opened the Access Map keeps
    // behaving exactly as it did before this column existed.
    $roleCols = $db->query("PRAGMA table_info(user_roles)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('max_discount_pct', $roleCols)) {
        $db->exec("ALTER TABLE user_roles ADD COLUMN max_discount_pct REAL NOT NULL DEFAULT 10");
    }

    // 3. Users (Store Managers & Staff)
    $db->exec("CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        role_id INTEGER NOT NULL,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        full_name TEXT NOT NULL,
        email TEXT,
        phone TEXT,
        is_active INTEGER DEFAULT 1,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (role_id) REFERENCES user_roles(id)
    )");

    $usersCount = $db->query("SELECT COUNT(*) as count FROM users")->fetch()['count'];
    if ($usersCount == 0) {
        $adminHash = password_hash('admin123', PASSWORD_BCRYPT);
        $stmt = $db->prepare("INSERT INTO users (role_id, username, password_hash, full_name, email, phone, is_active) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([1, 'admin', $adminHash, 'Store Administrator', 'admin@storeflow.local', '+1 (555) 100-2000', 1]);
    }

    // Only one account is seeded, and it is the owner's. A second known-credential
    // staff login is a door a customer never chose and cannot be trusted to have
    // closed; staff accounts are created by the owner once the master is rotated.

    // Run schema migrations for users
    $userCols = $db->query("PRAGMA table_info(users)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('branch_code', $userCols)) {
        $db->exec("ALTER TABLE users ADD COLUMN branch_code TEXT DEFAULT 'MAIN-01'");
    }
    if (!in_array('pin_code', $userCols)) {
        $db->exec("ALTER TABLE users ADD COLUMN pin_code TEXT DEFAULT NULL");
        // No PIN is seeded. A till left standing on a shop floor unlocks on a number, and a
        // default of 1234 is the first thing anyone tries. Staff set their own in the profile.
    }
    if (!in_array('must_change_password', $userCols)) {
        $db->exec("ALTER TABLE users ADD COLUMN must_change_password INTEGER DEFAULT 0");
        $db->exec("UPDATE users SET must_change_password = 1 WHERE username = 'admin'");
    }

    // Migrate any legacy plaintext PINs to secure bcrypt hashes
    $unhashedPins = $db->query("SELECT id, pin_code FROM users WHERE pin_code IS NOT NULL AND pin_code NOT LIKE '$2y$%'")->fetchAll();
    foreach ($unhashedPins as $pRow) {
        $hashedPin = password_hash($pRow['pin_code'], PASSWORD_BCRYPT);
        $uStmt = $db->prepare("UPDATE users SET pin_code = ? WHERE id = ?");
        $uStmt->execute([$hashedPin, $pRow['id']]);
    }

    // 4. Products (Catalog)
    $db->exec("CREATE TABLE IF NOT EXISTS products (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        sku TEXT UNIQUE,
        barcode TEXT,
        category TEXT DEFAULT 'General',
        unit TEXT DEFAULT 'pcs',
        cost_price REAL NOT NULL DEFAULT 0.00,
        selling_price REAL NOT NULL DEFAULT 0.00,
        min_stock_alert INTEGER DEFAULT 5,
        image_url TEXT DEFAULT '',
        description TEXT,
        is_active INTEGER DEFAULT 1,
        product_type TEXT DEFAULT 'standard',
        is_rental INTEGER DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )");

    $prodCols = $db->query("PRAGMA table_info(products)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('image_url', $prodCols)) {
        $db->exec("ALTER TABLE products ADD COLUMN image_url TEXT DEFAULT ''");
    }
    if (!in_array('has_expiry', $prodCols)) {
        $db->exec("ALTER TABLE products ADD COLUMN has_expiry INTEGER DEFAULT 0");
    }
    if (!in_array('batch_number', $prodCols)) {
        $db->exec("ALTER TABLE products ADD COLUMN batch_number TEXT DEFAULT ''");
    }
    if (!in_array('expiry_date', $prodCols)) {
        $db->exec("ALTER TABLE products ADD COLUMN expiry_date TEXT DEFAULT NULL");
    }
    if (!in_array('mfg_date', $prodCols)) {
        $db->exec("ALTER TABLE products ADD COLUMN mfg_date TEXT DEFAULT NULL");
    }
    if (!in_array('alert_before_days', $prodCols)) {
        $db->exec("ALTER TABLE products ADD COLUMN alert_before_days INTEGER DEFAULT 30");
    }
    if (!in_array('pack_unit', $prodCols)) {
        $db->exec("ALTER TABLE products ADD COLUMN pack_unit TEXT DEFAULT ''");
    }
    if (!in_array('pack_size', $prodCols)) {
        $db->exec("ALTER TABLE products ADD COLUMN pack_size REAL DEFAULT 1");
    }
    if (!in_array('pack_price', $prodCols)) {
        $db->exec("ALTER TABLE products ADD COLUMN pack_price REAL DEFAULT 0");
    }
    if (!in_array('product_type', $prodCols)) {
        $db->exec("ALTER TABLE products ADD COLUMN product_type TEXT DEFAULT 'standard'");
    }
    if (!in_array('is_rental', $prodCols)) {
        $db->exec("ALTER TABLE products ADD COLUMN is_rental INTEGER DEFAULT 0");
    }

    // 4b. Sellable units per product.
    //
    // A product used to carry one wholesale pack in three columns on itself, which capped
    // every shop at two sellable sizes. An egg dealer sells a loose egg, a crate of 30 and
    // a box of 14 crates, and the third of those had nowhere to live. Each row here is one
    // size, expressed against the base unit rather than against the row above it, so a
    // chain of any depth is data: 1, 30, 420.
    //
    // selling_price NULL means "derive it as size_in_base * the product's base price",
    // which is what the old pack_price fallback already did and keeps one price authority
    // per product. The base row is the product's own unit and is always present.
    $db->exec("CREATE TABLE IF NOT EXISTS product_units (
        id TEXT PRIMARY KEY,
        product_id TEXT NOT NULL,
        unit_name TEXT NOT NULL,
        size_in_base REAL NOT NULL DEFAULT 1,
        selling_price REAL DEFAULT NULL,
        barcode TEXT DEFAULT '',
        is_base INTEGER NOT NULL DEFAULT 0,
        sort_order INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    )");
    $db->exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_product_units_name ON product_units(product_id, unit_name COLLATE NOCASE)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_product_units_product ON product_units(product_id)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_product_units_barcode ON product_units(barcode)");

    // Backfill from the old columns, guarded per product so it is a no-op on a catalogue
    // that already has its own rows. Products also arrive from sync.php, which invents one
    // it has never seen; that path inserts its own base row, and sales.php reads a missing
    // unit row as the base unit rather than refusing the sale, so no shop can be stopped
    // at the till by a catalogue gap.
    $db->exec("INSERT INTO product_units (id, product_id, unit_name, size_in_base, selling_price, barcode, is_base, sort_order)
               SELECT 'pun_' || lower(hex(randomblob(6))), p.id, COALESCE(NULLIF(TRIM(p.unit), ''), 'pcs'), 1, NULL, '', 1, 0
               FROM products p
               WHERE NOT EXISTS (SELECT 1 FROM product_units u WHERE u.product_id = p.id)");

    // The old columns could name a pack the same as the base unit, which the unique index
    // above would refuse and which sales.php would match in preference to the real base
    // unit. Those packs are dropped rather than carried forward; the API refuses the
    // combination outright from here on.
    $db->exec("INSERT OR IGNORE INTO product_units (id, product_id, unit_name, size_in_base, selling_price, barcode, is_base, sort_order)
               SELECT 'pun_' || lower(hex(randomblob(6))), p.id, TRIM(p.pack_unit), ROUND(p.pack_size, 4),
                      CASE WHEN p.pack_price > 0 THEN p.pack_price ELSE NULL END, '', 0, 1
               FROM products p
               WHERE TRIM(COALESCE(p.pack_unit, '')) <> ''
                 AND ROUND(COALESCE(p.pack_size, 1), 4) > 1
                 AND LOWER(TRIM(p.pack_unit)) <> LOWER(TRIM(COALESCE(NULLIF(p.unit, ''), 'pcs')))
                 AND NOT EXISTS (SELECT 1 FROM product_units u WHERE u.product_id = p.id AND u.is_base = 0)");

    // 4c. Product Combos & Recipe Bundles (Composite Items)
    $db->exec("CREATE TABLE IF NOT EXISTS product_combo_items (
        id TEXT PRIMARY KEY,
        combo_product_id TEXT NOT NULL,
        component_product_id TEXT NOT NULL,
        quantity REAL NOT NULL DEFAULT 1.0,
        unit TEXT DEFAULT 'pcs',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (combo_product_id) REFERENCES products(id) ON DELETE CASCADE,
        FOREIGN KEY (component_product_id) REFERENCES products(id) ON DELETE CASCADE
    )");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_combo_parent ON product_combo_items(combo_product_id)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_combo_component ON product_combo_items(component_product_id)");

    // 5. Inventory (Current Stock & Reorder Levels per Product)
    $db->exec("CREATE TABLE IF NOT EXISTS inventory (
        id TEXT PRIMARY KEY,
        product_id TEXT UNIQUE NOT NULL,
        current_quantity REAL NOT NULL DEFAULT 0.0,
        reorder_level REAL DEFAULT 5.0,
        location TEXT DEFAULT 'Main Storefront',
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    )");

    // 6. Inventory Movements (Stock In / Stock Out Ledger)
    $db->exec("CREATE TABLE IF NOT EXISTS inventory_movements (
        id TEXT PRIMARY KEY,
        product_id TEXT NOT NULL,
        movement_type TEXT NOT NULL,
        quantity REAL NOT NULL,
        reference_id TEXT,
        unit_price REAL DEFAULT 0.0,
        notes TEXT,
        created_by INTEGER,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (product_id) REFERENCES products(id)
    )");

    $mvtCols = $db->query("PRAGMA table_info(inventory_movements)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('branch_code', $mvtCols)) {
        $db->exec("ALTER TABLE inventory_movements ADD COLUMN branch_code TEXT DEFAULT 'MAIN-01'");
    }

    // 6b. Branch Inventory (Multi-Location Stock Levels, Local Price Overrides & Branch Availability)
    $db->exec("CREATE TABLE IF NOT EXISTS branch_inventory (
        id TEXT PRIMARY KEY,
        branch_code TEXT NOT NULL,
        product_id TEXT NOT NULL,
        current_quantity REAL NOT NULL DEFAULT 0.0,
        reorder_level REAL DEFAULT 5.0,
        custom_selling_price REAL DEFAULT NULL,
        is_available INTEGER DEFAULT 1,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(branch_code, product_id),
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    )");

    // Auto-seed branch_inventory from existing single inventory for MAIN-01
    $db->exec("INSERT OR IGNORE INTO branch_inventory (id, branch_code, product_id, current_quantity, reorder_level, is_available, updated_at)
               SELECT 'binv_' || substr(id, 5), 'MAIN-01', product_id, current_quantity, reorder_level, 1, updated_at
               FROM inventory");

    // 6c. Inter-Branch Stock Transfers (IBT)
    $db->exec("CREATE TABLE IF NOT EXISTS stock_transfers (
        id TEXT PRIMARY KEY,
        transfer_number TEXT UNIQUE NOT NULL,
        source_branch TEXT NOT NULL,
        destination_branch TEXT NOT NULL,
        status TEXT DEFAULT 'COMPLETED',
        total_items INTEGER DEFAULT 1,
        total_quantity REAL NOT NULL DEFAULT 0.0,
        notes TEXT,
        created_by INTEGER,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )");

    $db->exec("CREATE TABLE IF NOT EXISTS stock_transfer_items (
        id TEXT PRIMARY KEY,
        transfer_id TEXT NOT NULL,
        product_id TEXT NOT NULL,
        quantity REAL NOT NULL,
        cost_price REAL DEFAULT 0.0,
        FOREIGN KEY (transfer_id) REFERENCES stock_transfers(id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(id)
    )");

    // A waybill that says "4" has to say four of what. The shelf either way is counted in
    // loose units, so the size and its conversion are written next to the line: without them
    // a pallet of crates and a single bottle look identical on the paper, and the receiving
    // branch cannot tell what was actually unpacked at its own counter.
    $trfItemCols = $db->query("PRAGMA table_info(stock_transfer_items)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('unit', $trfItemCols)) {
        $db->exec("ALTER TABLE stock_transfer_items ADD COLUMN unit TEXT DEFAULT ''");
    }
    if (!in_array('multiplier', $trfItemCols)) {
        $db->exec("ALTER TABLE stock_transfer_items ADD COLUMN multiplier REAL DEFAULT 1");
    }
    if (!in_array('base_quantity', $trfItemCols)) {
        $db->exec("ALTER TABLE stock_transfer_items ADD COLUMN base_quantity REAL DEFAULT 0");
    }

    // 7. Factory Purchases / Orders
    //
    // status is where the order is, not where the money is: PENDING (the shop has asked and
    // the goods are still at the factory), COUNTED (someone stood at the shelf and counted
    // what came) or CANCELLED (called off, or handed back). Nothing adds to the shelf on a
    // status change - only the count-in does, and it books what arrived rather than what was
    // ordered. payment_status stays a separate column because the deposit and the debt happen
    // when the paper is signed, not when the truck is unloaded.
    $db->exec("CREATE TABLE IF NOT EXISTS purchases (
        id TEXT PRIMARY KEY,
        order_number TEXT UNIQUE NOT NULL,
        supplier_name TEXT NOT NULL,
        supplier_contact TEXT,
        order_date TEXT NOT NULL,
        status TEXT DEFAULT 'PENDING',
        total_cost REAL NOT NULL DEFAULT 0.0,
        shipping_cost REAL DEFAULT 0.0,
        notes TEXT,
        created_by INTEGER,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )");

    // 8. Purchase Items (Products Purchased)
    $db->exec("CREATE TABLE IF NOT EXISTS purchase_items (
        id TEXT PRIMARY KEY,
        purchase_id TEXT NOT NULL,
        product_id TEXT NOT NULL,
        quantity REAL NOT NULL,
        cost_price REAL NOT NULL,
        subtotal REAL NOT NULL,
        FOREIGN KEY (purchase_id) REFERENCES purchases(id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(id)
    )");

    $purchItemCols = $db->query("PRAGMA table_info(purchase_items)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('batch_number', $purchItemCols)) {
        $db->exec("ALTER TABLE purchase_items ADD COLUMN batch_number TEXT DEFAULT NULL");
    }
    if (!in_array('expiry_date', $purchItemCols)) {
        $db->exec("ALTER TABLE purchase_items ADD COLUMN expiry_date TEXT DEFAULT NULL");
    }
    if (!in_array('mfg_date', $purchItemCols)) {
        $db->exec("ALTER TABLE purchase_items ADD COLUMN mfg_date TEXT DEFAULT NULL");
    }
    // quantity is the count the shop ordered in the size it ordered - five crates - and the
    // shelf only ever counts loose units. Without the conversion written down next to the
    // line, a crate received as one bottle and a supplier invoice that no longer reconciles.
    if (!in_array('unit', $purchItemCols)) {
        $db->exec("ALTER TABLE purchase_items ADD COLUMN unit TEXT DEFAULT ''");
    }
    if (!in_array('multiplier', $purchItemCols)) {
        $db->exec("ALTER TABLE purchase_items ADD COLUMN multiplier REAL DEFAULT 1");
    }
    if (!in_array('base_quantity', $purchItemCols)) {
        $db->exec("ALTER TABLE purchase_items ADD COLUMN base_quantity REAL DEFAULT 0");
    }
    // quantity is what the shop asked the factory for; counted_quantity is what a person
    // stood at the back door and counted in. They are the same number only when nothing went
    // short, and every figure that describes the shelf has to come off the second one.
    // NULL means the line has never been counted, which is the difference between "the truck
    // has not come" and "the truck came with nothing on it" - a zero here is a delivery that
    // arrived empty, not a delivery still on the road.
    if (!in_array('counted_quantity', $purchItemCols)) {
        $db->exec("ALTER TABLE purchase_items ADD COLUMN counted_quantity REAL DEFAULT NULL");
    }

    // 8b. The history of one order: who asked, who counted it in, who called it off and why.
    //
    // activity_logs cannot carry this. It has no reference column at all, so an order's story
    // can only be found by reading every line the shop has ever logged and looking for the
    // order number inside a sentence - which is fine for a shopkeeper skimming and useless
    // for the one question a called-off order has to answer months later: what exactly was
    // decided here, by whom, and what did it cost.
    $db->exec("CREATE TABLE IF NOT EXISTS purchase_events (
        id TEXT PRIMARY KEY,
        purchase_id TEXT NOT NULL,
        event_type TEXT NOT NULL,
        reason_code TEXT,
        details TEXT,
        amount REAL DEFAULT 0.0,
        created_by INTEGER,
        created_by_name TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (purchase_id) REFERENCES purchases(id) ON DELETE CASCADE
    )");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_purchase_events_order ON purchase_events(purchase_id)");

    // 9. Customers (Buyers)
    $db->exec("CREATE TABLE IF NOT EXISTS customers (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        phone TEXT,
        email TEXT,
        address TEXT,
        balance REAL DEFAULT 0.0,
        notes TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )");

    $custCount = $db->query("SELECT COUNT(*) as count FROM customers WHERE id = 'cust-walkin'")->fetch()['count'];
    if ($custCount == 0) {
        $db->exec("INSERT INTO customers (id, name, phone, email, address, balance, notes) 
                   VALUES ('cust-walkin', 'Walk-in Customer', 'N/A', 'walkin@store.local', 'In-Store', 0.0, 'Standard unregistered customer')");
    }

    $custCols = $db->query("PRAGMA table_info(customers)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('loyalty_points', $custCols)) {
        $db->exec("ALTER TABLE customers ADD COLUMN loyalty_points REAL DEFAULT 0.0");
    }
    if (!in_array('loyalty_tier', $custCols)) {
        $db->exec("ALTER TABLE customers ADD COLUMN loyalty_tier TEXT DEFAULT 'BRONZE'");
    }

    // The two kinds of money-off the server decides for itself. Kept off `discount` because
    // that column is the cashier's own figure and is what the role's ceiling is measured
    // against: folding a member's points into it would make an honest redemption read as a
    // cashier giving away more than their role allows, and would lose the shop the ability to
    // answer "what did we give away on loyalty this month".
    // 10. Sales (POS Transactions)
    $db->exec("CREATE TABLE IF NOT EXISTS sales (
        id TEXT PRIMARY KEY,
        receipt_number TEXT UNIQUE NOT NULL,
        customer_id TEXT DEFAULT 'cust-walkin',
        user_id INTEGER,
        sale_date TEXT NOT NULL,
        subtotal REAL NOT NULL,
        discount REAL DEFAULT 0.0,
        tax REAL DEFAULT 0.0,
        total_amount REAL NOT NULL,
        total_cost REAL NOT NULL DEFAULT 0.0,
        gross_profit REAL NOT NULL DEFAULT 0.0,
        payment_method TEXT NOT NULL DEFAULT 'CASH',
        amount_paid REAL NOT NULL,
        change_due REAL DEFAULT 0.0,
        status TEXT DEFAULT 'COMPLETED',
        payment_status TEXT DEFAULT 'PAID',
        loyalty_discount REAL DEFAULT 0.0,
        tier_discount REAL DEFAULT 0.0,
        notes TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (customer_id) REFERENCES customers(id)
    )");

    // 11. Sale Items (Products Sold)
    $db->exec("CREATE TABLE IF NOT EXISTS sale_items (
        id TEXT PRIMARY KEY,
        sale_id TEXT NOT NULL,
        product_id TEXT NOT NULL,
        quantity REAL NOT NULL,
        unit_cost_price REAL NOT NULL,
        unit_selling_price REAL NOT NULL,
        subtotal REAL NOT NULL,
        profit REAL NOT NULL,
        FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(id)
    )");

    $saleItemCols = $db->query("PRAGMA table_info(sale_items)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('batch_id', $saleItemCols)) {
        $db->exec("ALTER TABLE sale_items ADD COLUMN batch_id TEXT DEFAULT NULL");
    }
    if (!in_array('batch_number', $saleItemCols)) {
        $db->exec("ALTER TABLE sale_items ADD COLUMN batch_number TEXT DEFAULT NULL");
    }
    if (!in_array('expiry_date', $saleItemCols)) {
        $db->exec("ALTER TABLE sale_items ADD COLUMN expiry_date TEXT DEFAULT NULL");
    }
    if (!in_array('unit', $saleItemCols)) {
        $db->exec("ALTER TABLE sale_items ADD COLUMN unit TEXT DEFAULT 'pcs'");
    }
    if (!in_array('multiplier', $saleItemCols)) {
        $db->exec("ALTER TABLE sale_items ADD COLUMN multiplier REAL DEFAULT 1");
    }
    if (!in_array('base_quantity', $saleItemCols)) {
        $db->exec("ALTER TABLE sale_items ADD COLUMN base_quantity REAL DEFAULT 0");
    }

    // 12. Backups Record
    $db->exec("CREATE TABLE IF NOT EXISTS backups (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        filename TEXT NOT NULL,
        filepath TEXT NOT NULL,
        file_size_bytes INTEGER NOT NULL,
        backup_type TEXT NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )");

    // 13. Sync Log
    $db->exec("CREATE TABLE IF NOT EXISTS sync_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        client_sync_id TEXT,
        records_received INTEGER DEFAULT 0,
        records_sent INTEGER DEFAULT 0,
        status TEXT DEFAULT 'SUCCESS',
        details TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )");

    // 14. Activity & Audit Logs
    $db->exec("CREATE TABLE IF NOT EXISTS activity_logs (
        id TEXT PRIMARY KEY,
        user_id INTEGER,
        user_name TEXT,
        role_name TEXT,
        action_type TEXT NOT NULL,
        details TEXT NOT NULL,
        ip_address TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )");

    // 15. Customer Debt Payments Ledger
    $db->exec("CREATE TABLE IF NOT EXISTS customer_payments (
        id TEXT PRIMARY KEY,
        customer_id TEXT NOT NULL,
        user_id INTEGER,
        amount REAL NOT NULL,
        payment_method TEXT NOT NULL DEFAULT 'CASH',
        notes TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (customer_id) REFERENCES customers(id)
    )");

    $salesCols = $db->query("PRAGMA table_info(sales)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('loyalty_points_earned', $salesCols)) {
        $db->exec("ALTER TABLE sales ADD COLUMN loyalty_points_earned REAL DEFAULT 0.0");
    }
    if (!in_array('loyalty_points_redeemed', $salesCols)) {
        $db->exec("ALTER TABLE sales ADD COLUMN loyalty_points_redeemed REAL DEFAULT 0.0");
    }
    if (!in_array('loyalty_discount', $salesCols)) {
        $db->exec("ALTER TABLE sales ADD COLUMN loyalty_discount REAL DEFAULT 0.0");
    }
    if (!in_array('tier_discount', $salesCols)) {
        $db->exec("ALTER TABLE sales ADD COLUMN tier_discount REAL DEFAULT 0.0");
    }

    // 15b. Every point that moved, and why. customers.loyalty_points is the answer to "how many";
    // this is the answer to "how did it get there", which is the question a shop owner gets when a
    // regular disputes a balance - and the only way to prove a gift was given on purpose. The
    // unique pair (sale_id, reason) is what stops a receipt replayed from an offline queue from
    // paying out its points a second time; adjustments carry no sale_id and so are never blocked.
    $db->exec("CREATE TABLE IF NOT EXISTS loyalty_ledger (
        id TEXT PRIMARY KEY,
        customer_id TEXT NOT NULL,
        sale_id TEXT DEFAULT NULL,
        points_change REAL NOT NULL,
        money_value REAL NOT NULL DEFAULT 0.0,
        balance_after REAL NOT NULL,
        reason TEXT NOT NULL,
        note TEXT,
        branch_code TEXT DEFAULT 'MAIN-01',
        created_by INTEGER,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (customer_id) REFERENCES customers(id)
    )");
    // The pair is only one-per-receipt for the reasons a receipt authors for itself: it earns once,
    // it hands in once, and it is cleared as a void once. Held to every reason it also forbade a
    // receipt from answering a second credit note - and three returns of a third each are three
    // honest lines against one sale, so the second one would have failed on this index and taken
    // the whole credit note down with it. The guarantee is therefore narrowed to the reasons that
    // are one-per-receipt by nature, which is exactly what a replayed queue relies on.
    //
    // SQLite has no CREATE OR REPLACE INDEX, so the stored DDL is read and the index is rebuilt
    // under the same name only while it is still the old all-reasons shape; a book that has never
    // held one gets it new. The reading statement has to be *freed*, not merely stepped to its
    // end: a PDOStatement still in scope holds its read lock on sqlite_master, and the DROP then
    // fails "database table is locked" on the same connection. That is not a corner of testing -
    // every till updating from a release that shipped the wide index boots through this branch.
    $idxStmt = $db->query("SELECT sql FROM sqlite_master WHERE type = 'index' AND name = 'idx_loyalty_ledger_sale'");
    $ledgerIdxSql = $idxStmt ? (string)$idxStmt->fetchColumn() : '';
    $idxStmt = null;
    if ($ledgerIdxSql !== '' && stripos($ledgerIdxSql, 'reason IN') === false) {
        $db->exec("DROP INDEX idx_loyalty_ledger_sale");
    }
    $db->exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_loyalty_ledger_sale ON loyalty_ledger(sale_id, reason)
               WHERE sale_id IS NOT NULL AND reason IN ('EARNED', 'REDEEMED', 'VOIDED')");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_loyalty_ledger_customer ON loyalty_ledger(customer_id, created_at)");
    if (!in_array('source', $salesCols)) {
        $db->exec("ALTER TABLE sales ADD COLUMN source TEXT DEFAULT 'POS'");
    }

    // Run sales table migrations
    $salesCols = $db->query("PRAGMA table_info(sales)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('terminal_id', $salesCols)) {
        $db->exec("ALTER TABLE sales ADD COLUMN terminal_id TEXT DEFAULT 'REG-01'");
    }
    if (!in_array('branch_code', $salesCols)) {
        $db->exec("ALTER TABLE sales ADD COLUMN branch_code TEXT DEFAULT 'MAIN-01'");
    }
    if (!in_array('payment_reference', $salesCols)) {
        $db->exec("ALTER TABLE sales ADD COLUMN payment_reference TEXT DEFAULT ''");
    }
    if (!in_array('refunded_amount', $salesCols)) {
        $db->exec("ALTER TABLE sales ADD COLUMN refunded_amount REAL DEFAULT 0.0");
    }
    if (!in_array('payment_status', $salesCols)) {
        $db->exec("ALTER TABLE sales ADD COLUMN payment_status TEXT DEFAULT 'PAID'");
    }
    // A VOID is not a refund. The receipt stays on the book exactly as it was printed, with its
    // own reason, hand and timestamp beside it, while every money figure on it reads nil. These
    // four columns are that stamp; the amount was never rewritten into them, so a till that
    // voided a mis-ring and a till that refunded a customer's goods stay two different records.
    if (!in_array('voided_at', $salesCols)) {
        $db->exec("ALTER TABLE sales ADD COLUMN voided_at TEXT DEFAULT NULL");
    }
    if (!in_array('void_reason', $salesCols)) {
        $db->exec("ALTER TABLE sales ADD COLUMN void_reason TEXT DEFAULT ''");
    }
    if (!in_array('void_user_id', $salesCols)) {
        $db->exec("ALTER TABLE sales ADD COLUMN void_user_id INTEGER DEFAULT NULL");
    }
    if (!in_array('void_user_name', $salesCols)) {
        $db->exec("ALTER TABLE sales ADD COLUMN void_user_name TEXT DEFAULT ''");
    }

    // 15c. Price Quotations & Proforma Invoices (Estimates)
    $db->exec("CREATE TABLE IF NOT EXISTS estimates (
        id TEXT PRIMARY KEY,
        estimate_number TEXT UNIQUE NOT NULL,
        customer_id TEXT DEFAULT 'cust-walkin',
        customer_name TEXT,
        customer_phone TEXT,
        user_id INTEGER,
        created_by_name TEXT,
        estimate_date TEXT NOT NULL,
        valid_until TEXT NOT NULL,
        subtotal REAL NOT NULL,
        discount REAL DEFAULT 0.0,
        tax REAL DEFAULT 0.0,
        total_amount REAL NOT NULL,
        notes TEXT,
        status TEXT DEFAULT 'PENDING',
        items_json TEXT NOT NULL,
        branch_code TEXT DEFAULT 'MAIN-01',
        converted_sale_id TEXT DEFAULT NULL,
        converted_at TEXT DEFAULT NULL,
        platform TEXT DEFAULT NULL,
        external_ref TEXT DEFAULT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )");

    // The two columns an online order needs and a hand-typed quotation does not: which
    // storefront sent it, and the number that storefront calls it. Together they are what makes
    // a retried webhook the same quotation rather than a second one, so the pair is unique -
    // and it is a repair here rather than a table an endpoint builds on first click, because a
    // shop whose quotations table predates the bridge would otherwise fail the INSERT on the
    // order it just accepted.
    $estCols = $db->query("PRAGMA table_info(estimates)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('platform', $estCols)) {
        $db->exec("ALTER TABLE estimates ADD COLUMN platform TEXT DEFAULT NULL");
    }
    if (!in_array('external_ref', $estCols)) {
        $db->exec("ALTER TABLE estimates ADD COLUMN external_ref TEXT DEFAULT NULL");
    }
    $db->exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_estimates_online_ref ON estimates(platform, external_ref)");

    // 15b. Sales Returns & Refunds (Credit Notes)
    $db->exec("CREATE TABLE IF NOT EXISTS sales_returns (
        id TEXT PRIMARY KEY,
        return_number TEXT UNIQUE NOT NULL,
        sale_id TEXT NOT NULL,
        receipt_number TEXT NOT NULL,
        customer_id TEXT DEFAULT 'cust-walkin',
        customer_name TEXT DEFAULT 'Walk-in Customer',
        user_id INTEGER,
        cashier_name TEXT NOT NULL,
        terminal_id TEXT DEFAULT 'REG-01',
        branch_code TEXT DEFAULT 'MAIN-01',
        total_refund_amount REAL NOT NULL DEFAULT 0.0,
        refund_method TEXT NOT NULL DEFAULT 'CASH',
        return_date TEXT NOT NULL,
        reason TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (sale_id) REFERENCES sales(id),
        FOREIGN KEY (customer_id) REFERENCES customers(id)
    )");

    // A credit note that only says "93.83" for a GH₵100 item starts an argument the cashier
    // cannot win. The discount and the tax were charged once, on the whole receipt, so the
    // return has to show the share of each it gave back - and the shop needs those two numbers
    // on the paper, not re-derived from the receipt, because a return can outlive the till that
    // issued it and the reduction of output tax is a figure the owner reports.
    $retCols = $db->query("PRAGMA table_info(sales_returns)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('refund_gross', $retCols)) {
        $db->exec("ALTER TABLE sales_returns ADD COLUMN refund_gross REAL DEFAULT 0.0");
    }
    if (!in_array('refund_discount_share', $retCols)) {
        $db->exec("ALTER TABLE sales_returns ADD COLUMN refund_discount_share REAL DEFAULT 0.0");
    }
    if (!in_array('refund_tax_share', $retCols)) {
        $db->exec("ALTER TABLE sales_returns ADD COLUMN refund_tax_share REAL DEFAULT 0.0");
    }

    $db->exec("CREATE TABLE IF NOT EXISTS sales_return_items (
        id TEXT PRIMARY KEY,
        return_id TEXT NOT NULL,
        product_id TEXT NOT NULL,
        product_name TEXT NOT NULL,
        quantity REAL NOT NULL,
        unit_price REAL NOT NULL,
        refund_subtotal REAL NOT NULL,
        item_condition TEXT DEFAULT 'RESTOCK',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (return_id) REFERENCES sales_returns(id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(id)
    )");

    // A credit note that says "2" against a product sold both loose and by the crate is a
    // refund the shop cannot check and a restock count it cannot trust, so the size, the
    // multiplier and the loose-unit total belong on the line the customer was credited for.
    $retItemCols = $db->query("PRAGMA table_info(sales_return_items)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('unit', $retItemCols)) {
        $db->exec("ALTER TABLE sales_return_items ADD COLUMN unit TEXT DEFAULT ''");
    }
    if (!in_array('multiplier', $retItemCols)) {
        $db->exec("ALTER TABLE sales_return_items ADD COLUMN multiplier REAL DEFAULT 1");
    }
    if (!in_array('base_quantity', $retItemCols)) {
        $db->exec("ALTER TABLE sales_return_items ADD COLUMN base_quantity REAL DEFAULT 0");
    }

    // 16. Cash Register Shift Sessions (Z-Reports)
    $db->exec("CREATE TABLE IF NOT EXISTS register_shifts (
        id TEXT PRIMARY KEY,
        shift_number TEXT UNIQUE NOT NULL,
        user_id INTEGER,
        cashier_name TEXT NOT NULL,
        role_name TEXT NOT NULL,
        terminal_id TEXT DEFAULT 'REG-01',
        branch_code TEXT DEFAULT 'MAIN-01',
        shift_date TEXT NOT NULL,
        shift_time TEXT NOT NULL,
        opening_float REAL DEFAULT 0.0,
        total_transactions INTEGER DEFAULT 0,
        total_sales_gross REAL DEFAULT 0.0,
        voided_count INTEGER DEFAULT 0,
        voided_value REAL DEFAULT 0.0,
        cash_sales REAL DEFAULT 0.0,
        card_sales REAL DEFAULT 0.0,
        transfer_sales REAL DEFAULT 0.0,
        credit_sales REAL DEFAULT 0.0,
        debt_cash_collected REAL DEFAULT 0.0,
        cash_refunds_paid REAL DEFAULT 0.0,
        expected_cash REAL DEFAULT 0.0,
        counted_cash REAL DEFAULT 0.0,
        variance REAL DEFAULT 0.0,
        notes TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )");

    $shiftCols = $db->query("PRAGMA table_info(register_shifts)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('branch_code', $shiftCols)) {
        $db->exec("ALTER TABLE register_shifts ADD COLUMN branch_code TEXT DEFAULT 'MAIN-01'");
    }
    if (!in_array('drawer_expenses', $shiftCols)) {
        $db->exec("ALTER TABLE register_shifts ADD COLUMN drawer_expenses REAL DEFAULT 0.0");
    }
    // A Z-report is a statement about one drawer, and a cleared receipt belongs on it: the money
    // went back to the customer and the goods went back on the shelf, so the shift's takings are
    // lower than the number of slips printed. The till says how many, rather than a reprinted
    // report quietly leaving them out.
    if (!in_array('voided_count', $shiftCols)) {
        $db->exec("ALTER TABLE register_shifts ADD COLUMN voided_count INTEGER DEFAULT 0");
    }
    if (!in_array('voided_value', $shiftCols)) {
        $db->exec("ALTER TABLE register_shifts ADD COLUMN voided_value REAL DEFAULT 0.0");
    }
    // Cash handed back over a credit note leaves the same box the takings went into, so a shift
    // that does not name it counts as short by exactly the money the shop refunded on purpose.
    // Read off the book rather than typed by the till, because the figure that explains a
    // shortage is the one figure a dishonest drawer would happily invent.
    if (!in_array('cash_refunds_paid', $shiftCols)) {
        $db->exec("ALTER TABLE register_shifts ADD COLUMN cash_refunds_paid REAL DEFAULT 0.0");
    }
    if (!in_array('rental_cash_collected', $shiftCols)) {
        $db->exec("ALTER TABLE register_shifts ADD COLUMN rental_cash_collected REAL DEFAULT 0.0");
    }
    if (!in_array('rental_caution_refunded', $shiftCols)) {
        $db->exec("ALTER TABLE register_shifts ADD COLUMN rental_caution_refunded REAL DEFAULT 0.0");
    }

    // 16b. Cash Register Opening Floats (Multi-terminal synchronized drawer floats)
    $db->exec("CREATE TABLE IF NOT EXISTS register_floats (
        id TEXT PRIMARY KEY,
        terminal_id TEXT NOT NULL,
        branch_code TEXT DEFAULT 'MAIN-01',
        shift_date TEXT NOT NULL,
        opening_float REAL DEFAULT 0.0,
        user_id INTEGER,
        cashier_name TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(terminal_id, shift_date, branch_code)
    )");

    // 17. Store Branches Directory
    $db->exec("CREATE TABLE IF NOT EXISTS branches (
        id TEXT PRIMARY KEY,
        branch_code TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        address TEXT,
        phone TEXT,
        manager_name TEXT,
        is_active INTEGER DEFAULT 1,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )");

    $branchCount = $db->query("SELECT COUNT(*) as count FROM branches")->fetch()['count'];
    if ($branchCount == 0) {
        $db->exec("INSERT INTO branches (id, branch_code, name, address, phone, manager_name, is_active)
                   VALUES ('branch-main', 'MAIN-01', 'Main Storefront', '104 Commerce Boulevard, Suite 2B', '+1 (555) 234-5678', 'Store Administrator', 1)");
    }

    // 18. Vendors / Factory Suppliers Directory
    $db->exec("CREATE TABLE IF NOT EXISTS vendors (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        contact_person TEXT,
        phone TEXT,
        email TEXT,
        address TEXT,
        tax_id TEXT,
        balance REAL DEFAULT 0.0,
        payment_terms TEXT DEFAULT 'NET30',
        bank_details TEXT,
        notes TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )");

    // 19. Vendor Debt Payments / Payouts Ledger (Accounts Payable)
    $db->exec("CREATE TABLE IF NOT EXISTS vendor_payments (
        id TEXT PRIMARY KEY,
        vendor_id TEXT NOT NULL,
        purchase_id TEXT,
        user_id INTEGER,
        amount REAL NOT NULL,
        payment_method TEXT NOT NULL DEFAULT 'CASH',
        reference_no TEXT,
        payment_date TEXT NOT NULL,
        notes TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (vendor_id) REFERENCES vendors(id)
    )");

    // 19b. The debt or advance a supplier account is carried in with, from the paper book.
    // Keyed by the vendor, not by the row: an account has one opening balance, and whatever
    // comes after it is a payout or an order. The key is also what makes a replay safe - the
    // same carry-in delivered twice is refused by the table before any money moves.
    $db->exec("CREATE TABLE IF NOT EXISTS vendor_opening_balances (
        vendor_id TEXT PRIMARY KEY,
        amount REAL NOT NULL,
        note TEXT,
        user_id INTEGER,
        user_name TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (vendor_id) REFERENCES vendors(id)
    )");

    // Run purchases migrations for vendor linking & accounts payable
    $purchCols = $db->query("PRAGMA table_info(purchases)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('vendor_id', $purchCols)) {
        $db->exec("ALTER TABLE purchases ADD COLUMN vendor_id TEXT DEFAULT NULL");
    }
    if (!in_array('amount_paid', $purchCols)) {
        $db->exec("ALTER TABLE purchases ADD COLUMN amount_paid REAL DEFAULT 0.0");
    }
    // Money drawn back out of a balance the shop already has sitting with this supplier.
    // amount_paid is what left the drawer, so the two have to be separate numbers: settle a
    // GH₵180 invoice with GH₵160 cash and GH₵20 of credit and the order is closed, not
    // still owing GH₵20 - but only if the till knows the credit was spent.
    if (!in_array('credit_used', $purchCols)) {
        $db->exec("ALTER TABLE purchases ADD COLUMN credit_used REAL DEFAULT 0.0");
    }
    if (!in_array('payment_status', $purchCols)) {
        $db->exec("ALTER TABLE purchases ADD COLUMN payment_status TEXT DEFAULT 'PAID'");
    }
    if (!in_array('branch_code', $purchCols)) {
        $db->exec("ALTER TABLE purchases ADD COLUMN branch_code TEXT DEFAULT 'MAIN-01'");
    }
    // total_cost is what the shop is paying for, because that is the number every accounts
    // payable read already uses and a short delivery has to change it or the books go on
    // owing for crates that never came. ordered_cost is what was asked for, kept so the
    // difference is visible instead of being the reason the paper does not add up.
    if (!in_array('ordered_cost', $purchCols)) {
        $db->exec("ALTER TABLE purchases ADD COLUMN ordered_cost REAL DEFAULT NULL");
    }
    if (!in_array('counted_at', $purchCols)) {
        $db->exec("ALTER TABLE purchases ADD COLUMN counted_at TEXT DEFAULT NULL");
    }
    if (!in_array('counted_by', $purchCols)) {
        $db->exec("ALTER TABLE purchases ADD COLUMN counted_by INTEGER DEFAULT NULL");
    }
    if (!in_array('cancelled_at', $purchCols)) {
        $db->exec("ALTER TABLE purchases ADD COLUMN cancelled_at TEXT DEFAULT NULL");
    }
    if (!in_array('cancel_reason', $purchCols)) {
        $db->exec("ALTER TABLE purchases ADD COLUMN cancel_reason TEXT DEFAULT NULL");
    }
    if (!in_array('cancel_note', $purchCols)) {
        $db->exec("ALTER TABLE purchases ADD COLUMN cancel_note TEXT DEFAULT NULL");
    }

    // Orders written by every earlier release said 'RECEIVED' on the day they were created,
    // whether the goods came that day or not, and put the stock up at the same moment. A row
    // still carrying that word is therefore an order whose goods are already on the shelf -
    // which is exactly what COUNTED means - and for those orders the counted figure IS the
    // ordered figure, because nothing else was ever written down.
    $db->exec("UPDATE purchases SET status = 'COUNTED' WHERE status IS NULL OR status = '' OR status = 'RECEIVED'");
    $db->exec("UPDATE purchases SET ordered_cost = total_cost WHERE ordered_cost IS NULL");
    $db->exec("UPDATE purchase_items SET counted_quantity = quantity
                WHERE counted_quantity IS NULL AND quantity IS NOT NULL
                  AND purchase_id IN (SELECT id FROM purchases WHERE status = 'COUNTED')");

    // Seed the sample suppliers, but only into a file that has never had them.
    //
    // "Whenever the suppliers table is empty" reads like "on a fresh install" and is not that:
    // the installer runs again on every upgrade, so a shop that deleted its last supplier - or
    // reset its book to hand a clean demo over - would find three strangers back on the next
    // release, owing GH₵3,650 that came out of the product rather than out of the shop's own
    // bills. So the sample book stamps the file it was written into, the same way the two heal
    // passes above do, and only a file with no stamp gets it.
    $db->exec("CREATE TABLE IF NOT EXISTS _storeflow_flags (key TEXT PRIMARY KEY, value TEXT NOT NULL)");
    $sampleSeeded = $db->query("SELECT value FROM _storeflow_flags WHERE key = 'sample_book_seeded'")->fetchColumn();
    $vendorCount = (int)$db->query("SELECT COUNT(*) FROM vendors")->fetchColumn();
    $seedSample = (defined('STOREFLOW_SEED_DEMO') && STOREFLOW_SEED_DEMO) || (getenv('STOREFLOW_SEED_DEMO') === '1');
    if ($seedSample && $vendorCount === 0 && $sampleSeeded === false) {
        $db->exec("INSERT INTO vendors (id, name, contact_person, phone, email, address, tax_id, balance, payment_terms, bank_details, notes) VALUES
            ('ven-dangote', 'Dangote Agro-Allied Mills', 'Alhaji Musa Dangote', '+234 1 270 1600', 'orders@dangotemills.com', 'Plot 1, Commercial Ave, Ikeja, Lagos', 'TIN-4892019', 2450.00, 'NET30', 'Zenith Bank - 1012938492', 'Primary supplier for flour, refined sugar, and bulk spaghetti.'),
            ('ven-golden', 'Golden Oil & Agro Commodities', 'Kwame Mensah', '+233 24 456 7890', 'sales@goldenoilgh.com', 'Heavy Industrial Area, Plot 14, Tema', 'TIN-GH-829104', 0.00, 'NET15', 'Ecobank Ghana - 004829104928', 'Direct refinery for refined cooking vegetable oil and sunflower oils.'),
            ('ven-unilever', 'Unilever Consumer Distribution Ltd', 'Sarah Jenkins', '+1 (800) 598-1223', 'wholesale@unilever-dist.com', 'Harbor Logistics Park, Bay 4', 'TIN-US-9281920', 1200.00, 'NET60', 'Standard Chartered - 839201948', 'Authorized vendor for soaps, detergents, toiletries, and home care items.');");
        // Two of those three demo accounts start already owing money, and a number sitting in
        // vendors.balance with no row behind it is exactly what the carry-in table exists to
        // prevent. So the sample book carries its own opening balances too, and a supplier's
        // statement on a fresh install adds up without the till inventing a plug line.
        $db->exec("INSERT OR IGNORE INTO vendor_opening_balances (vendor_id, amount, note, user_name, created_at) VALUES
            ('ven-dangote', 2450.00, 'Debt brought in from the sample book', 'StoreFlow', datetime('now')),
            ('ven-unilever', 1200.00, 'Debt brought in from the sample book', 'StoreFlow', datetime('now'))");
    }
    // Stamped whether or not this boot wrote those rows: a shop that came in already having
    // suppliers has also said it does not want the sample book.
    $db->prepare("INSERT OR IGNORE INTO _storeflow_flags (key, value) VALUES ('sample_book_seeded', ?)")
       ->execute([date('Y-m-d H:i:s')]);

    // 20. Product Batches & Lot Expiry Tracking
    $db->exec("CREATE TABLE IF NOT EXISTS product_batches (
        id TEXT PRIMARY KEY,
        product_id TEXT NOT NULL,
        batch_number TEXT NOT NULL,
        expiry_date TEXT NOT NULL,
        manufacture_date TEXT,
        initial_quantity REAL NOT NULL DEFAULT 0.0,
        current_quantity REAL NOT NULL DEFAULT 0.0,
        cost_price REAL DEFAULT 0.0,
        supplier_id TEXT,
        branch_code TEXT DEFAULT 'MAIN-01',
        status TEXT DEFAULT 'ACTIVE', -- ACTIVE, EXPIRED, DEPLETED, RECALLED
        notes TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
    )");

    $db->exec("CREATE INDEX IF NOT EXISTS idx_batches_product ON product_batches(product_id)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_batches_expiry ON product_batches(expiry_date)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_batches_branch ON product_batches(branch_code)");

    // 20. Store Operating Expenses & Cash Drawer Payouts
    $db->exec("CREATE TABLE IF NOT EXISTS expenses (
        id TEXT PRIMARY KEY,
        expense_number TEXT UNIQUE NOT NULL,
        title TEXT NOT NULL,
        category TEXT NOT NULL DEFAULT 'General',
        amount REAL NOT NULL DEFAULT 0.0,
        payment_source TEXT NOT NULL DEFAULT 'CASH_DRAWER', -- CASH_DRAWER, BANK_TRANSFER, MOBILE_MONEY, PETTY_CASH, OWNER_POCKET
        paid_to TEXT DEFAULT '',
        receipt_ref TEXT DEFAULT '',
        notes TEXT DEFAULT '',
        branch_code TEXT DEFAULT 'MAIN-01',
        terminal_id TEXT DEFAULT 'REG-01',
        shift_id TEXT DEFAULT NULL,
        user_id INTEGER,
        recorded_by TEXT NOT NULL,
        expense_date TEXT NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )");

    $db->exec("CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(expense_date)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_expenses_branch ON expenses(branch_code)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_expenses_source ON expenses(payment_source)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_expenses_shift ON expenses(shift_id)");

    // 21. The Dining Floor: tables, the tab open on one, and the lines fired to the kitchen.
    //
    // This lives here rather than in hospitality.php for the reason the purchase_items unit
    // column taught: a table built by an endpoint on the day somebody first clicks the page is
    // invisible to the version gate, to the missing-column probe, to the packaged release and
    // to a till's own mirror. It also meant every request ran a CREATE TABLE and swallowed the
    // error if it failed, so a shop could be holding orders in a schema nobody had checked.
    $db->exec("CREATE TABLE IF NOT EXISTS dining_tables (
        id TEXT PRIMARY KEY,
        table_number TEXT NOT NULL,
        zone_name TEXT DEFAULT 'Main Hall',
        seating_capacity INTEGER DEFAULT 4,
        status TEXT DEFAULT 'VACANT',
        active_order_id TEXT DEFAULT NULL,
        branch_code TEXT DEFAULT 'MAIN-01',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )");

    $db->exec("CREATE TABLE IF NOT EXISTS table_orders (
        id TEXT PRIMARY KEY,
        table_id TEXT NOT NULL,
        table_number TEXT NOT NULL,
        branch_code TEXT DEFAULT 'MAIN-01',
        guest_count INTEGER DEFAULT 1,
        server_user_id INTEGER,
        server_name TEXT,
        status TEXT DEFAULT 'OPEN',
        subtotal REAL DEFAULT 0.0,
        tax REAL DEFAULT 0.0,
        total_amount REAL DEFAULT 0.0,
        kot_number TEXT,
        notes TEXT,
        tab_name TEXT DEFAULT '',
        ticket_count INTEGER DEFAULT 1,
        opened_at TEXT DEFAULT CURRENT_TIMESTAMP,
        settled_at TEXT DEFAULT NULL,
        sale_id TEXT DEFAULT NULL,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (table_id) REFERENCES dining_tables(id)
    )");

    $db->exec("CREATE TABLE IF NOT EXISTS table_order_items (
        id TEXT PRIMARY KEY,
        order_id TEXT NOT NULL,
        product_id TEXT NOT NULL,
        product_name TEXT NOT NULL,
        quantity REAL NOT NULL,
        unit TEXT DEFAULT 'pcs',
        multiplier REAL DEFAULT 1.0,
        base_quantity REAL DEFAULT 0,
        unit_price REAL NOT NULL,
        subtotal REAL NOT NULL,
        ticket_number TEXT,
        seat_number TEXT DEFAULT 'Shared',
        guest_name TEXT DEFAULT '',
        kitchen_status TEXT DEFAULT 'ORDERED',
        prep_notes TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (order_id) REFERENCES table_orders(id) ON DELETE CASCADE
    )");

    // Event & Equipment Rentals & Hire (Chairs, Canopies, Sound, Tools)
    $db->exec("CREATE TABLE IF NOT EXISTS rentals (
        id TEXT PRIMARY KEY,
        rental_number TEXT UNIQUE NOT NULL,
        customer_id TEXT NOT NULL,
        customer_name TEXT NOT NULL,
        customer_phone TEXT,
        customer_id_card TEXT,
        event_location TEXT,
        branch_code TEXT DEFAULT 'MAIN-01',
        pickup_date TEXT NOT NULL,
        return_due_date TEXT NOT NULL,
        actual_return_date TEXT DEFAULT NULL,
        duration_days INTEGER NOT NULL DEFAULT 1,
        subtotal REAL NOT NULL DEFAULT 0.0,
        discount REAL DEFAULT 0.0,
        total_rental_amount REAL NOT NULL DEFAULT 0.0,
        caution_deposit REAL NOT NULL DEFAULT 0.0,
        caution_deposit_status TEXT DEFAULT 'HELD',
        late_fee_per_day REAL DEFAULT 0.0,
        late_fee_charged REAL DEFAULT 0.0,
        damage_fee_charged REAL DEFAULT 0.0,
        missing_fee_charged REAL DEFAULT 0.0,
        deposit_refunded REAL DEFAULT 0.0,
        additional_amount_owed REAL DEFAULT 0.0,
        balance_paid REAL DEFAULT 0.0,
        payment_method TEXT DEFAULT 'CASH',
        payment_status TEXT DEFAULT 'PAID',
        status TEXT DEFAULT 'DISPATCHED',
        notes TEXT,
        created_by INTEGER,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )");

    $db->exec("CREATE TABLE IF NOT EXISTS rental_items (
        id TEXT PRIMARY KEY,
        rental_id TEXT NOT NULL,
        product_id TEXT NOT NULL,
        product_name TEXT NOT NULL,
        quantity_dispatched REAL NOT NULL,
        quantity_returned_good REAL DEFAULT 0.0,
        quantity_damaged REAL DEFAULT 0.0,
        quantity_missing REAL DEFAULT 0.0,
        daily_rate REAL NOT NULL,
        line_total REAL NOT NULL,
        damage_charge_unit REAL DEFAULT 0.0,
        replacement_charge_unit REAL DEFAULT 0.0,
        notes TEXT,
        FOREIGN KEY (rental_id) REFERENCES rentals(id) ON DELETE CASCADE
    )");

    $db->exec("CREATE INDEX IF NOT EXISTS idx_rentals_status ON rentals(status)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_rentals_branch ON rentals(branch_code)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_rentals_due ON rentals(return_due_date)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_rental_items_rental ON rental_items(rental_id)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_rental_items_prod ON rental_items(product_id)");

    $rentalCols = $db->query("PRAGMA table_info(rentals)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('terminal_id', $rentalCols)) {
        $db->exec("ALTER TABLE rentals ADD COLUMN terminal_id TEXT DEFAULT 'REG-01'");
    }
    if (!in_array('balance_paid', $rentalCols)) {
        $db->exec("ALTER TABLE rentals ADD COLUMN balance_paid REAL DEFAULT 0.0");
    }

    // The columns the floor endpoints write on every line, added before anything indexes them.
    // SQLite resolves an index's columns when the index is built, and the first build of this
    // block created idx_tabs_branch on table_orders(branch_code) above the ALTER that adds that
    // column. A book whose tab table predates the floor therefore threw here on every single
    // request - and because this runs at connection time, the shop did not get a floor error but
    // a login screen reading "no such column: branch_code", with no way in.
    //
    // Each shape is probed here and named in schemaRequiredColumns() as well: a book stamped at
    // this version with the tab table still missing sale_id cannot mark a bill paid, which is the
    // difference between a table that frees and one that sits occupied forever.
    $floorCols = $db->query("PRAGMA table_info(dining_tables)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('branch_code', $floorCols)) {
        $db->exec("ALTER TABLE dining_tables ADD COLUMN branch_code TEXT DEFAULT 'MAIN-01'");
    }
    // ALTER cannot add a column whose default is a function: CURRENT_TIMESTAMP is not a
    // constant, and SQLite refuses the statement outright with "Cannot add a column with
    // non-constant default". A column arriving by ALTER on a shop that already has rows
    // therefore starts at NULL and is stamped by the endpoint that writes it. The floor's own
    // CREATE keeps the function, because there it applies to rows made from now on.
    $tabCols = $db->query("PRAGMA table_info(table_orders)")->fetchAll(PDO::FETCH_COLUMN, 1);
    foreach (['branch_code' => "TEXT DEFAULT 'MAIN-01'", 'sale_id' => 'TEXT DEFAULT NULL',
              'updated_at' => 'TEXT DEFAULT NULL',
              'ticket_count' => 'INTEGER DEFAULT 1',
              'tab_name' => "TEXT DEFAULT ''"] as $col => $def) {
        if (!in_array($col, $tabCols)) {
            $db->exec("ALTER TABLE table_orders ADD COLUMN {$col} {$def}");
        }
    }
    $tabItemCols = $db->query("PRAGMA table_info(table_order_items)")->fetchAll(PDO::FETCH_COLUMN, 1);
    foreach (['unit' => "TEXT DEFAULT 'pcs'", 'multiplier' => 'REAL DEFAULT 1.0',
              'base_quantity' => 'REAL DEFAULT 0', 'ticket_number' => 'TEXT DEFAULT NULL',
              'seat_number' => "TEXT DEFAULT 'Shared'", 'guest_name' => "TEXT DEFAULT ''"] as $col => $def) {
        if (!in_array($col, $tabItemCols)) {
            $db->exec("ALTER TABLE table_order_items ADD COLUMN {$col} {$def}");
        }
    }

    // Two branches both calling their first table "Table 1" is normal; one branch cannot have
    // it twice, so the UNIQUE the first build put on the bare column has to come off - and a
    // book left holding the husk of an interrupted rebuild has to be repaired as well. That
    // work is one function, because it is the one migration in this file that drops a table
    // with rows under it.
    repairFloorShape($db);

    $db->exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_floor_table_per_branch ON dining_tables(branch_code, table_number)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_floor_branch ON dining_tables(branch_code)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_tabs_status ON table_orders(status)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_tabs_branch ON table_orders(branch_code)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_tab_items_order ON table_order_items(order_id)");

    // A floor plan is the shop's own furniture, so a demo set is written into a file once -
    // the same rule the sample suppliers now follow. Six tables that come back after the owner
    // deleted them, or after a reset, are not a convenience but a lie about the room.
    $db->exec("CREATE TABLE IF NOT EXISTS _storeflow_flags (key TEXT PRIMARY KEY, value TEXT NOT NULL)");
    // Read and released in one expression. Held in a variable, the statement's cursor stays
    // half-stepped on _storeflow_flags, and the CREATE INDEX statements at the end of this
    // function then fail with "database table is locked": SQLite raises that on one connection,
    // and no busy_timeout waits it out. The shop sees it as a login screen it cannot get past.
    $floorSeeded = $db->query("SELECT value FROM _storeflow_flags WHERE key = 'hospitality_floor_seeded'")->fetchColumn();
    if ($floorSeeded === false) {
        $floorCount = (int)$db->query("SELECT COUNT(*) FROM dining_tables")->fetchColumn();
        if ($floorCount === 0) {
            $demoBranch = 'MAIN-01';
            // The floor belongs to the shop's first branch. There is no "primary" flag on
            // branches - an earlier draft asked for one that does not exist, so the query always
            // threw, was swallowed, and every dining room silently landed on MAIN-01 whatever the
            // shop's own code is.
            $firstBranch = $db->query("SELECT branch_code FROM branches ORDER BY id LIMIT 1")->fetch();
            if (!empty($firstBranch['branch_code'])) $demoBranch = $firstBranch['branch_code'];
            $initTables = [
                ['T-01', 'Table 1', 'Main Dining', 4],
                ['T-02', 'Table 2', 'Main Dining', 4],
                ['T-03', 'Table 3', 'Main Dining', 2],
                ['T-04', 'Table 4', 'Patio Terrace', 6],
                ['T-05', 'Bar-01', 'Bar Area', 2],
                ['T-06', 'VIP-01', 'Private Lounge', 8],
            ];
            $seedFloor = $db->prepare("INSERT OR IGNORE INTO dining_tables
                (id, table_number, zone_name, seating_capacity, status, branch_code) VALUES (?, ?, ?, ?, 'VACANT', ?)");
            foreach ($initTables as $tbl) {
                $seedFloor->execute([$tbl[0], $tbl[1], $tbl[2], $tbl[3], $demoBranch]);
            }
        }
        $db->prepare("INSERT OR IGNORE INTO _storeflow_flags (key, value) VALUES ('hospitality_floor_seeded', ?)")
           ->execute([date('Y-m-d H:i:s')]);
    }

    // High-Performance Query & Live Delta Sync Indices (Schema v15)
    $db->exec("CREATE INDEX IF NOT EXISTS idx_sales_updated ON sales(updated_at)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_sales_created ON sales(created_at)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_sales_branch_date ON sales(branch_code, sale_date)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_sales_customer ON sales(customer_id)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_sale_items_sale ON sale_items(sale_id)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_sale_items_prod ON sale_items(product_id)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_products_updated ON products(updated_at)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_products_barcode ON products(barcode)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_products_sku ON products(sku)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_products_category ON products(category)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_binv_branch_updated ON branch_inventory(branch_code, updated_at)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_inventory_updated ON inventory(updated_at)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_customers_updated ON customers(updated_at)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_activity_logs_created ON activity_logs(created_at)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_estimates_updated ON estimates(updated_at)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_estimates_number ON estimates(estimate_number)");
}

// The dining floor's shape, repaired in one transaction.
//
// Two branches both calling their first table "Table 1" is normal; one branch cannot have it
// twice, so the UNIQUE the first build put on the bare column has to come off. That is done by
// building the replacement under a temporary name and then dropping the old table into its own
// name - never by renaming dining_tables. SQLite rewrites a child's foreign key to follow a
// renamed parent, so the rename repointed table_orders at whatever name dining_tables went by,
// and the shop was left holding a husk it could neither drop (its rows still have tabs on them)
// nor keep (a table the owner adds afterwards is not in it, and seating a party there fails the
// key). Books that already ran that build are repaired here too, because the repair is the same
// swap on the child.
//
// It is a function rather than statements in the migration because it is the only part of this
// file that drops a table with rows under it: the swap is one transaction, so a book cannot be
// left between the drop and the rename, and every read is stepped to its end before a table is
// touched - a cursor left open on sqlite_master makes SQLite raise "database table is locked"
// on the same connection, which no busy_timeout waits out.
function repairFloorShape(PDO $db): void
{
    $peek = function (string $sql) use ($db): string {
        $stmt = $db->query($sql);
        $val = $stmt->fetchColumn();
        $stmt->closeCursor();
        return $val === false ? '' : (string)$val;
    };
    $shared = function (string $a, string $b) use ($db): array {
        return array_values(array_intersect(
            $db->query("PRAGMA table_info({$a})")->fetchAll(PDO::FETCH_COLUMN, 1),
            $db->query("PRAGMA table_info({$b})")->fetchAll(PDO::FETCH_COLUMN, 1)
        ));
    };
    $carryInto = function (string $from, string $to) use ($db, $shared): void {
        $cols = $shared($from, $to);
        if ($cols === []) return;
        $list = implode(', ', $cols);
        $db->exec("INSERT INTO {$to} ({$list}) SELECT {$list} FROM {$from}");
    };

    $ownTx = !$db->inTransaction();
    for ($attempt = 1; $attempt <= 3; $attempt++) {
        $needsFloor = stripos($peek("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'dining_tables'"),
                            'table_number TEXT NOT NULL UNIQUE') !== false;
        $needsTab = stripos($peek("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'table_orders'"),
                            'dining_tables_v21legacy') !== false;
        $hasHusk = $peek("SELECT COUNT(*) FROM sqlite_master WHERE type = 'table' AND name = 'dining_tables_v21legacy'") !== '0';
        $hasV27Husk = $peek("SELECT COUNT(*) FROM sqlite_master WHERE type = 'table' AND name IN ('table_orders_v27', 'dining_tables_v27')") !== '0';
        if (!$needsFloor && !$needsTab && !$hasHusk && !$hasV27Husk) return;

        try {
            // The keys are off for the length of the swap only. Each step drops a parent that
            // still has rows under it, and with the keys on the implicit delete SQLite makes
            // when it drops a parent either raises a violation or - through table_order_items'
            // ON DELETE CASCADE - empties the kitchen lines off every open tab.
            $db->exec("PRAGMA foreign_keys = OFF");
            if ($ownTx) $db->beginTransaction();

            if ($needsFloor) {
                $db->exec("DROP TABLE IF EXISTS dining_tables_v27");
                $db->exec("CREATE TABLE dining_tables_v27 (
                    id TEXT PRIMARY KEY,
                    table_number TEXT NOT NULL,
                    zone_name TEXT DEFAULT 'Main Hall',
                    seating_capacity INTEGER DEFAULT 4,
                    status TEXT DEFAULT 'VACANT',
                    active_order_id TEXT DEFAULT NULL,
                    branch_code TEXT DEFAULT 'MAIN-01',
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
                )");
                $carryInto('dining_tables', 'dining_tables_v27');
                $db->exec("DROP TABLE dining_tables");
                $db->exec("ALTER TABLE dining_tables_v27 RENAME TO dining_tables");
            }
            if ($needsTab) {
                $db->exec("DROP TABLE IF EXISTS table_orders_v27");
                $db->exec("CREATE TABLE table_orders_v27 (
                    id TEXT PRIMARY KEY,
                    table_id TEXT NOT NULL,
                    table_number TEXT NOT NULL,
                    branch_code TEXT DEFAULT 'MAIN-01',
                    guest_count INTEGER DEFAULT 1,
                    server_user_id INTEGER,
                    server_name TEXT,
                    status TEXT DEFAULT 'OPEN',
                    subtotal REAL DEFAULT 0.0,
                    tax REAL DEFAULT 0.0,
                    total_amount REAL DEFAULT 0.0,
                    kot_number TEXT,
                    notes TEXT,
                    tab_name TEXT DEFAULT '',
                    ticket_count INTEGER DEFAULT 1,
                    opened_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    settled_at TEXT DEFAULT NULL,
                    sale_id TEXT DEFAULT NULL,
                    updated_at TEXT DEFAULT NULL,
                    FOREIGN KEY (table_id) REFERENCES dining_tables(id)
                )");
                $carryInto('table_orders', 'table_orders_v27');
                $db->exec("DROP TABLE table_orders");
                $db->exec("ALTER TABLE table_orders_v27 RENAME TO table_orders");
            }
            if ($hasHusk) {
                // Rows the live floor never got are copied forward before the husk goes, so a
                // rebuild interrupted between its copy and its drop heals rather than loses.
                $cols = $shared('dining_tables_v21legacy', 'dining_tables');
                if ($cols !== []) {
                    $list = implode(', ', $cols);
                    $db->exec("INSERT OR IGNORE INTO dining_tables ({$list})
                               SELECT {$list} FROM dining_tables_v21legacy
                               WHERE id NOT IN (SELECT id FROM dining_tables)");
                }
                $db->exec("DROP TABLE dining_tables_v21legacy");
            }
            if ($hasV27Husk) {
                $db->exec("DROP TABLE IF EXISTS table_orders_v27");
                $db->exec("DROP TABLE IF EXISTS dining_tables_v27");
            }

            if ($ownTx) $db->commit();
            return;
        } catch (Exception $e) {
            if ($ownTx && $db->inTransaction()) $db->rollBack();
            if ($attempt === 3) throw $e;
            usleep(200000);
        } finally {
            $db->exec("PRAGMA foreign_keys = ON");
        }
    }
}

// The columns an endpoint writes on every line, so a file missing one of them is not a
// cosmetic gap but a save that fails outright. Only these are probed: a missing optional
// column costs a feature, a missing written column costs the transaction, and this is the
// check that runs on every request.
function schemaRequiredColumns(): array {
    return [
        'purchase_items' => ['batch_number', 'expiry_date', 'mfg_date', 'unit', 'multiplier', 'base_quantity', 'counted_quantity'],
        'sale_items'     => ['batch_number', 'expiry_date', 'unit', 'multiplier', 'base_quantity'],
        'stock_transfer_items' => ['unit', 'multiplier', 'base_quantity'],
        'product_units'  => ['unit_name', 'size_in_base', 'selling_price', 'barcode', 'is_base'],
        // Every one of these arrives by ALTER on an existing shop, and purchases.php names
        // all five on the INSERT - so a till missing any of them cannot record a factory
        // purchase at all. credit_used is the proof: a shop already stamped at the current
        // version was told "table purchases has no column named credit_used" on every order,
        // because the number said it was up to date and only the shape knew it was not.
        'purchases'      => ['vendor_id', 'amount_paid', 'credit_used', 'payment_status', 'branch_code',
                             'ordered_cost', 'counted_at', 'counted_by', 'cancelled_at', 'cancel_reason', 'cancel_note'],
        // Named here so a file that reached this version with the table missing still gets
        // it: a missing table fails the PRAGMA below, which reports every wanted column
        // absent and runs the migration again.
        'purchase_events' => ['purchase_id', 'event_type', 'reason_code', 'details', 'amount'],
        // The three figures a credit note prints beside the refund. returns.php and sync.php
        // both name them on the INSERT, so a till that never got the ALTER cannot file a
        // return at all - not file one with a short note.
        'sales_returns'  => ['refund_gross', 'refund_discount_share', 'refund_tax_share'],
        // Named as a table the endpoints write into, for the same reason purchase_events is:
        // a file already stamped at the current version has never heard of this one, the
        // PRAGMA below fails, every wanted column reads absent, and the migration runs again.
        'vendor_opening_balances' => ['vendor_id', 'amount', 'note', 'user_name', 'created_at'],
        'customers'               => ['loyalty_points', 'loyalty_tier'],
        // A loyalty balance nobody can explain is a balance the shop will waive. Both of these
        // are written on the sale the server books, so a book missing either cannot pay points
        // out or take them in - and the settings row is the one that decides the rate.
        'loyalty_ledger'          => ['customer_id', 'points_change', 'balance_after', 'reason'],
        'store_profile'           => ['loyalty_points_per_currency', 'loyalty_redemption_rate',
                                      'loyalty_redeem_at_counter', 'loyalty_tier_perks',
                                      'estimate_validity_days', 'enable_line_discounts', 'receipt_spacing'],
        // A quotation the storefront sent rather than the counter typed: the pair of columns the
        // bridge names on every INSERT, and the two a converted quotation writes when the
        // register books the sale behind it. An old book missing any of them cannot hold an
        // online order at all.
        'estimates'               => ['platform', 'external_ref', 'converted_sale_id', 'converted_at', 'branch_code'],
        // The floor: each of these is written on the line a waiter's screen sends, so a book
        // that has the table but not the column cannot seat a party, price a tab, or release a
        // table once the bill is paid. sale_id is the one that hurts: without it the money is
        // taken, the INSERT fails, and the table sits OCCUPIED holding a tab nobody can close.
        'products'       => ['product_type'],
        'product_combo_items' => ['combo_product_id', 'component_product_id', 'quantity'],
        // The four stamp a cleared receipt carries. They are named here because a book that wrote
        // its version before they existed reaches the till with the column missing, and the void
        // then dies on "no such column: voided_at" - the receipt stays chargeable, the goods stay
        // off the shelf, and the only way to take the money back is to edit the file by hand.
        'sales'          => ['payment_status', 'loyalty_points_earned', 'loyalty_points_redeemed', 'loyalty_discount', 'tier_discount', 'source', 'terminal_id', 'branch_code', 'payment_reference', 'refunded_amount',
                             'voided_at', 'void_reason', 'void_user_id', 'void_user_name'],
        'dining_tables'           => ['branch_code'],
        // What a Z-report writes beside the takings. A book older than these still has its shifts,
        // but the close would die on the first column the report names - and a shift that cannot be
        // closed is a drawer that cannot be counted or handed over.
        'register_shifts'         => ['branch_code', 'drawer_expenses', 'voided_count', 'voided_value', 'cash_refunds_paid', 'rental_cash_collected', 'rental_caution_refunded'],
        'table_orders'            => ['branch_code', 'sale_id', 'updated_at', 'ticket_count', 'tab_name'],
        'table_order_items'       => ['unit', 'multiplier', 'base_quantity', 'ticket_number', 'seat_number', 'guest_name'],
        'rentals'                 => ['rental_number', 'customer_name', 'pickup_date', 'return_due_date', 'total_rental_amount', 'caution_deposit', 'status', 'terminal_id', 'balance_paid'],
        'rental_items'            => ['rental_id', 'product_id', 'quantity_dispatched', 'daily_rate', 'line_total'],
    ];
}

function schemaMissingColumns(PDO $db): array {
    $missing = [];
    foreach (schemaRequiredColumns() as $table => $wanted) {
        try {
            $have = $db->query("PRAGMA table_info({$table})")->fetchAll(PDO::FETCH_COLUMN, 1);
        } catch (Exception $e) {
            $have = [];
        }
        $absent = array_values(array_diff($wanted, $have));
        if ($absent) $missing[$table] = $absent;
    }
    return $missing;
}

// One payment, one identity, on every device in the shop.
//
// The till used to invent a payment id, write a ledger row with it in its own browser, and
// send the payment to the server - which threw that id away and made a different one. So the
// same GH₵160 existed twice under two keys, and the supplier statement, which merges the
// server's rows with the till's and removes duplicates by id, could never match them. It
// showed the payment twice and then invented an opening balance to make the total still come
// out right.
//
// A payment against a purchase order is named after that order, so both sides arrive at the
// same string without having to ask each other.
function vendorLedgerIdFor(string $purchaseId, string $method): string {
    return 'vpay_' . $purchaseId . '_' . strtolower($method === 'BALANCE' ? 'balance' : 'cash');
}

// Book the number a supplier account starts with.
//
// A shop that has traded with a factory for years does not begin its book at zero. The debt
// still owing from the paper ledger, or the deposit handed over for goods not yet delivered,
// has to be entered on day one - and until now the only door for it was vendors.balance itself:
// a number typed straight into a column, with no date, no name behind it, and nothing on the
// statement but the plug line the till invents when the orders and payouts do not add up to
// the account. A carry-in belongs in the book the same way a payout does - one row, one staff
// member, one date, read back by the statement as what it is.
//
// An account gets one, keyed by the vendor: everything after the first line is a purchase or a
// payout, and a second carry-in on the same account is a correction dressed up as an opening.
// The key is also what makes a replay harmless - the same queued row delivered twice, or two
// tills syncing the same supplier, is refused by the table before any money moves. The account
// is then moved by the amount of the row that actually landed, inside the database, never by a
// figure the till worked out.
function applyVendorOpeningBalance(PDO $db, string $vendorId, float $amount, string $note, $userId, string $userName, string $when = ''): bool {
    $amount = round($amount, 2);
    if ($vendorId === '' || abs($amount) < 0.005) return false;

    // Never a row for an account that is not in this shop's book. Without it the only way the
    // insert below can be refused is the key, which is the answer the callers report.
    $acct = $db->prepare("SELECT 1 FROM vendors WHERE id = ?");
    $acct->execute([$vendorId]);
    if ($acct->fetchColumn() === false) return false;

    // The till sends the date the shopkeeper read off his paper, not the date the row reached
    // the server: a carry-in synced on Tuesday that belonged to 1 October is booked at October.
    $stamp = preg_match('/^\d{4}-\d{2}-\d{2}( [0-2]\d:[0-5]\d(:[0-5]\d)?)?$/', trim($when)) ? trim($when) : null;

    $ins = $db->prepare("INSERT OR IGNORE INTO vendor_opening_balances (vendor_id, amount, note, user_id, user_name, created_at)
                         VALUES (?, ?, ?, ?, ?, COALESCE(?, datetime('now')))");
    $ins->execute([
        $vendorId, $amount, trim($note),
        ($userId === null || $userId === '') ? null : intval($userId),
        trim($userName), $stamp
    ]);
    if ($ins->rowCount() < 1) return false;

    $db->prepare("UPDATE vendors SET balance = balance + ?, updated_at = datetime('now') WHERE id = ?")
       ->execute([$amount, $vendorId]);
    return true;
}

// What a drawer should have held, and by how much the count fell short of it.
//
// The amounts a cashier watched pass during the day, and the figure they physically counted in
// the box, are the till's to report. expected_cash and variance are not - they are arithmetic
// over the rest. Accepting them as typed meant a close-out could read "variance 0.00" on a
// drawer that was GH₵60 short, because the one number that flags a dirty day came from the hand
// that owed the money.
//
// One copy of the rule lives here, because the same close reaches the shop's books through
// shifts.php at the counter and through a queued shift on the sync door a day later. Two copies
// of the arithmetic is how one drawer came to read short on one screen and level on another.
function shiftFigures(array $in): array {
    $openingFloat          = round(floatval($in['opening_float'] ?? 0), 2);
    $cashSales             = max(0, round(floatval($in['cash_sales'] ?? 0), 2));
    $debtCashCollected     = max(0, round(floatval($in['debt_cash_collected'] ?? 0), 2));
    $rentalCashCollected   = max(0, round(floatval($in['rental_cash_collected'] ?? 0), 2));
    $rentalCautionRefunded = max(0, round(floatval($in['rental_caution_refunded'] ?? 0), 2));
    $drawerExpenses        = max(0, round(floatval($in['drawer_expenses'] ?? 0), 2));
    $cashRefundsPaid       = max(0, round(floatval($in['cash_refunds_paid'] ?? 0), 2));

    // The float is money that was already in the drawer, so it is not takings: expected_cash is
    // what the box holds beyond the change it started with. Cash refunds and caution deposit refunds
    // come off the same box, while cash sales, customer debt payments, and rental collections enter it.
    $expectedCash = round($cashSales + $debtCashCollected + $rentalCashCollected - $drawerExpenses - $cashRefundsPaid - $rentalCautionRefunded, 2);
    $countedCash  = round(floatval($in['counted_cash'] ?? ($expectedCash + $openingFloat)), 2);
    $variance     = round($countedCash - ($expectedCash + $openingFloat), 2);

    return [
        'opening_float'           => $openingFloat,
        'cash_sales'              => $cashSales,
        'debt_cash_collected'     => $debtCashCollected,
        'rental_cash_collected'   => $rentalCashCollected,
        'rental_caution_refunded' => $rentalCautionRefunded,
        'drawer_expenses'         => $drawerExpenses,
        'cash_refunds_paid'       => $cashRefundsPaid,
        'expected_cash'           => $expectedCash,
        'counted_cash'            => $countedCash,
        'variance'                => $variance,
        // Reported beside the takings, never inside them.
        'voided_count'            => max(0, intval($in['voided_count'] ?? 0)),
        'voided_value'            => max(0, round(floatval($in['voided_value'] ?? 0), 2)),
    ];
}

// The cash this drawer took in or paid out over event equipment rentals today.
// Reads cash collected at dispatch (hire fee + caution deposit) and at return (additional fees),
// and caution security deposits refunded in cash out of the drawer upon return inspection.
function shiftRentalFigures(PDO $db, string $terminalId, string $branchCode, string $date): array {
    $term = strtoupper(trim($terminalId));
    $branch = strtoupper(trim($branchCode));

    $dispatchCash = 0.0;
    $returnRefunds = 0.0;
    $returnExtraCash = 0.0;

    try {
        // 1. Rental cash collected at dispatch today
        $sql = "SELECT COALESCE(SUM(
                    (CASE WHEN upper(payment_status) = 'PAID' THEN total_rental_amount ELSE 0 END) +
                    (CASE WHEN caution_deposit_status IN ('HELD', 'SETTLED', 'FORFEITED') THEN caution_deposit ELSE 0 END)
                ), 0) FROM rentals
                WHERE upper(COALESCE(payment_method, 'CASH')) = 'CASH'
                  AND substr(COALESCE(pickup_date, created_at), 1, 10) = ?";
        $args = [$date];
        if ($term !== '' && $term !== 'ALL') {
            $sql .= " AND upper(COALESCE(terminal_id, 'REG-01')) = ?";
            $args[] = $term;
        }
        if ($branch !== '' && $branch !== 'ALL') {
            $sql .= " AND upper(COALESCE(branch_code, 'MAIN-01')) = ?";
            $args[] = $branch;
        }
        $stmt = $db->prepare($sql);
        $stmt->execute($args);
        $dispatchCash = floatval($stmt->fetchColumn() ?: 0.0);

        // 2. Rental caution deposits refunded in cash upon return inspection today
        $sqlRef = "SELECT COALESCE(SUM(deposit_refunded), 0) FROM rentals
                   WHERE status = 'RETURNED'
                     AND deposit_refunded > 0
                     AND substr(COALESCE(NULLIF(actual_return_date, ''), updated_at), 1, 10) = ?";
        $argsRef = [$date];
        if ($term !== '' && $term !== 'ALL') {
            $sqlRef .= " AND upper(COALESCE(terminal_id, 'REG-01')) = ?";
            $argsRef[] = $term;
        }
        if ($branch !== '' && $branch !== 'ALL') {
            $sqlRef .= " AND upper(COALESCE(branch_code, 'MAIN-01')) = ?";
            $argsRef[] = $branch;
        }
        $stmtRef = $db->prepare($sqlRef);
        $stmtRef->execute($argsRef);
        $returnRefunds = floatval($stmtRef->fetchColumn() ?: 0.0);

        // 3. Additional penalty/late balances collected in cash at return or settled later
        $sqlExtra = "SELECT COALESCE(SUM(
                        CASE 
                            WHEN COALESCE(balance_paid, 0) > 0 THEN balance_paid
                            WHEN upper(payment_status) = 'PAID' AND additional_amount_owed > 0 THEN additional_amount_owed
                            ELSE 0 
                        END
                     ), 0) FROM rentals
                     WHERE status = 'RETURNED'
                       AND upper(COALESCE(payment_method, 'CASH')) = 'CASH'
                       AND (upper(payment_status) = 'PAID' OR COALESCE(balance_paid, 0) > 0)
                       AND substr(COALESCE(NULLIF(actual_return_date, ''), updated_at), 1, 10) = ?";
        $argsExtra = [$date];
        if ($term !== '' && $term !== 'ALL') {
            $sqlExtra .= " AND upper(COALESCE(terminal_id, 'REG-01')) = ?";
            $argsExtra[] = $term;
        }
        if ($branch !== '' && $branch !== 'ALL') {
            $sqlExtra .= " AND upper(COALESCE(branch_code, 'MAIN-01')) = ?";
            $argsExtra[] = $branch;
        }
        $stmtExtra = $db->prepare($sqlExtra);
        $stmtExtra->execute($argsExtra);
        $returnExtraCash = floatval($stmtExtra->fetchColumn() ?: 0.0);
    } catch (Throwable $e) {
        error_log('StoreFlow: rental drawer figures error - ' . $e->getMessage());
    }

    return [
        'rental_cash_collected' => round($dispatchCash + $returnExtraCash, 2),
        'rental_caution_refunded' => round($returnRefunds, 2),
        'rental_dispatch_cash' => round($dispatchCash, 2),
        'rental_additional_cash' => round($returnExtraCash, 2)
    ];
}

// The cash this drawer handed back over credit notes today.
//
// Scoped the way the till scopes its own figures - this terminal, this branch, this day - because
// a drawer counted against another till's refunds would report a shortage that belongs to somebody
// else's box. A shift closed on 'ALL' is a manager's read of the whole branch, so it takes every
// terminal's payouts.
function shiftCashRefundsPaid(PDO $db, string $terminalId, string $branchCode, string $date): float {
    $sql = "SELECT COALESCE(SUM(total_refund_amount), 0) FROM sales_returns
            WHERE upper(COALESCE(refund_method, 'CASH')) = 'CASH'
              AND substr(COALESCE(NULLIF(return_date, ''), created_at), 1, 10) = ?";
    $args = [$date];
    $term = strtoupper(trim($terminalId));
    if ($term !== '' && $term !== 'ALL') {
        $sql .= " AND upper(COALESCE(terminal_id, 'REG-01')) = ?";
        $args[] = $term;
    }
    $branch = strtoupper(trim($branchCode));
    if ($branch !== '' && $branch !== 'ALL') {
        $sql .= " AND upper(COALESCE(branch_code, 'MAIN-01')) = ?";
        $args[] = $branch;
    }
    try {
        $stmt = $db->prepare($sql);
        $stmt->execute($args);
        return round(floatval($stmt->fetchColumn()), 2);
    } catch (Throwable $e) {
        // A book whose returns table is unreadable today closes the shift on the figures it can
        // stand behind rather than failing the close; the shortage is visible either way.
        error_log('StoreFlow: cash refunds not counted for the shift - ' . $e->getMessage());
        return 0.0;
    }
}

// The petty cash this drawer paid out on expenses today, read off the shop's own book.
//
// Same reason the refund above is read rather than taken as typed, and pointing the other way.
// A refund the till invents explains a shortage that is already showing; an expense the till
// invents *hides* one, because every cedi it claims to have paid out of the box lowers the cash
// the box is expected to hold. GH₵60.00 of expenses actually booked and GH₵260.00 typed takes
// GH₵200.00 off expected cash, and a GH₵200.00 shortage closes as BALANCED with a green light
// on the counter. The figure that can forgive a shortfall is the one the drawer must not own.
//
// Scoped and defaulted exactly as the till scopes its own list - a payout recorded without a
// terminal belongs to the shop's first register, not to whichever drawer is being counted - so
// the number on the close screen and the number in the book are the same number by construction.
function shiftDrawerExpensesPaid(PDO $db, string $terminalId, string $branchCode, string $date): float {
    $sql = "SELECT COALESCE(SUM(amount), 0) FROM expenses
            WHERE upper(COALESCE(payment_source, 'CASH_DRAWER')) = 'CASH_DRAWER'
              AND substr(COALESCE(NULLIF(expense_date, ''), created_at), 1, 10) = ?";
    $args = [$date];
    $term = strtoupper(trim($terminalId));
    if ($term !== '' && $term !== 'ALL') {
        $sql .= " AND upper(COALESCE(terminal_id, 'REG-01')) = ?";
        $args[] = $term;
    }
    $branch = strtoupper(trim($branchCode));
    if ($branch !== '' && $branch !== 'ALL') {
        $sql .= " AND upper(COALESCE(branch_code, 'MAIN-01')) = ?";
        $args[] = $branch;
    }
    try {
        $stmt = $db->prepare($sql);
        $stmt->execute($args);
        return round(floatval($stmt->fetchColumn()), 2);
    } catch (Throwable $e) {
        error_log('StoreFlow: drawer expenses not counted for the shift - ' . $e->getMessage());
        return 0.0;
    }
}

// What the shop made on a basket - before the tax it collected for somebody else.
//
// total_amount is what the customer handed over, and it carries the VAT/NHIL the shop must
// remit. Reading gross profit off that figure booked the tax as the shop's own margin: on
// GH₵1,000 of goods sold against GH₵700 of cost with GH₵150 of tax on the receipt, the true
// gross is GH₵300 and every board that reads the column has been saying GH₵450. The receipt the
// till prints already excluded the tax, so the two numbers a shopkeeper compares never agreed,
// and the disagreement grew with his tax rate.
//
// One copy of the rule, because a sale reaches the book at the counter and through a queued
// sync a day later.
function saleGrossProfit(float $subtotal, float $discount, float $tax, float $totalCost): float {
    $net = max(0.0, round($subtotal, 2) - max(0.0, round($discount, 2)));
    return round($net - round($totalCost, 2), 2);
}

// Restate the profit already on the shop's receipts.
//
// Not a second movement of money: subtotal, discount, tax and total_cost are already on the
// row, and this writes the figure those columns add up to. Stamped once per database file, so
// the cost of checking on every boot is one indexed read.
function healSaleGrossProfitExcludingTax(PDO $db): int {
    $db->exec("CREATE TABLE IF NOT EXISTS _storeflow_flags (key TEXT PRIMARY KEY, value TEXT NOT NULL)");
    $stamp = $db->prepare("SELECT value FROM _storeflow_flags WHERE key = 'gross_profit_ex_tax'");
    $stamp->execute();
    if ($stamp->fetchColumn() !== false) return 0;

    $fixed = 0;
    try {
        $rows = $db->query("SELECT id, COALESCE(subtotal, 0) AS subtotal, COALESCE(discount, 0) AS discount,
                                   COALESCE(tax, 0) AS tax, COALESCE(total_cost, 0) AS total_cost,
                                   COALESCE(gross_profit, 0) AS gross_profit
                              FROM sales WHERE COALESCE(tax, 0) > 0")->fetchAll(PDO::FETCH_ASSOC);
        $upd = $db->prepare("UPDATE sales SET gross_profit = ?, updated_at = datetime('now') WHERE id = ?");
        foreach ($rows as $r) {
            $true = saleGrossProfit(floatval($r['subtotal']), floatval($r['discount']),
                                    floatval($r['tax']), floatval($r['total_cost']));
            if (abs($true - round(floatval($r['gross_profit']), 2)) < 0.005) continue;
            $upd->execute([$true, $r['id']]);
            $fixed++;
        }
    } catch (Throwable $e) {
        // A book that cannot be restated today is tried again on the next boot; the receipts
        // themselves are untouched either way.
        error_log('StoreFlow: gross profit restatement skipped - ' . $e->getMessage());
        return 0;
    }

    $ins = $db->prepare("INSERT OR IGNORE INTO _storeflow_flags (key, value) VALUES ('gross_profit_ex_tax', ?)");
    $ins->execute([date('Y-m-d H:i:s') . ' rows=' . $fixed]);
    return $fixed;
}

function healOrphanedRentalProductLinks(PDO $db): void {
    try {
        $orphans = $db->query("
            SELECT DISTINCT ri.product_id AS old_id, ri.product_name
            FROM rental_items ri
            LEFT JOIN products p ON p.id = ri.product_id
            WHERE p.id IS NULL AND TRIM(COALESCE(ri.product_name, '')) <> ''
        ")->fetchAll(PDO::FETCH_ASSOC);
        if (!$orphans) return;

        $findProd = $db->prepare("SELECT id FROM products WHERE LOWER(TRIM(name)) = LOWER(TRIM(?)) ORDER BY is_active DESC, updated_at DESC LIMIT 1");
        $updRentalItems = $db->prepare("UPDATE rental_items SET product_id = ? WHERE product_id = ?");
        $updMovements = $db->prepare("UPDATE inventory_movements SET product_id = ? WHERE product_id = ?");
        foreach ($orphans as $row) {
            $findProd->execute([$row['product_name']]);
            $newProdId = $findProd->fetchColumn();
            $findProd->closeCursor();
            if ($newProdId) {
                $updRentalItems->execute([$newProdId, $row['old_id']]);
                $updMovements->execute([$newProdId, $row['old_id']]);
            }
        }
    } catch (Throwable $e) {
        // Non-fatal heal
    }
}

/**
 * Safely stage, schema-upgrade, and install a backup SQLite file over the live runtime path.
 *
 * Even if an external viewer (such as DB Browser for SQLite or another worker thread) holds
 * an open handle to the -wal or -shm sidecar on Windows (preventing unlink()), this stages
 * the backup in WAL mode with an initialized 0-frame WalIndexHdr, truncates -wal to 0 bytes,
 * and writes the valid 120-byte WalIndexHdr + WalCkptInfo into -shm so SQLite never replays
 * stale WAL frames or fails with "malformed database schema (1)".
 */
function syncRestoredSqliteRuntime(string $sourcePath, string $dbPath): bool {
    if (!is_file($sourcePath)) return false;
    $tmp = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'sf_stage_' . uniqid('', true) . '.db';
    if (!@copy($sourcePath, $tmp)) return false;

    $shm120 = '';
    try {
        $tmpPdo = new PDO("sqlite:" . $tmp);
        $tmpPdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $tmpPdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $tmpPdo->exec("PRAGMA busy_timeout = 5000;");
        $tmpPdo->exec("PRAGMA foreign_keys = ON;");
        if (strtolower((string)$tmpPdo->query("PRAGMA integrity_check")->fetchColumn()) !== 'ok') {
            $tmpPdo = null;
            @unlink($tmp);
            return false;
        }
        initializeDatabase($tmpPdo);
        healOrphanedRentalProductLinks($tmpPdo);
        if (function_exists('_sysEnsureMeta')) {
            _sysEnsureMeta($tmpPdo);
        }
        $tmpPdo->exec("PRAGMA user_version = 28;");
        $tmpPdo->exec("PRAGMA journal_mode = WAL;");
        $tmpPdo->exec("CREATE TABLE IF NOT EXISTS _sf_wal_init (x INT); DROP TABLE _sf_wal_init;");
        $tmpPdo->exec("PRAGMA wal_checkpoint(TRUNCATE);");
        if (is_file($tmp . '-shm')) {
            $shm120 = (string)@file_get_contents($tmp . '-shm', false, null, 0, 120);
        }
        $tmpPdo = null;
    } catch (Throwable $e) {
        $tmpPdo = null;
        @unlink($tmp);
        @unlink($tmp . '-wal');
        @unlink($tmp . '-shm');
        return false;
    }

    if (file_exists($dbPath . '-wal')) {
        @file_put_contents($dbPath . '-wal', '');
        @unlink($dbPath . '-wal');
    }
    @unlink($dbPath . '-shm');

    $copied = @copy($tmp, $dbPath);
    @unlink($tmp);
    @unlink($tmp . '-wal');
    @unlink($tmp . '-shm');
    if (!$copied) return false;

    if (file_exists($dbPath . '-wal')) {
        @file_put_contents($dbPath . '-wal', '');
        @unlink($dbPath . '-wal');
    }
    if (file_exists($dbPath . '-shm') && !@unlink($dbPath . '-shm') && strlen($shm120) === 120) {
        $fp = @fopen($dbPath . '-shm', 'r+b');
        if ($fp) {
            @fwrite($fp, $shm120, 120);
            @fclose($fp);
        }
    }
    return true;
}

// Apply a supplier settlement to the invoices it paid for.
//
// vendors.balance is one signed number for the whole relationship; a purchase order is a
// separate piece of paper. Only a payout the cashier *linked* to an order ever touched that
// order, so paying a debt off the Suppliers page settled the account and left the invoice
// reading PARTIAL for ever. The owner's own till ended up saying "WE OWE SUPPLIERS GH₵0.00"
// on one screen and "GH₵1,233,000.00 still to pay" on another, both true about their own
// table and both wrong about the money.
//
// This is bookkeeping about where recorded money went, not a second movement of it: the
// caller moves vendors.balance by the payout once, and an order already covered by its own
// down payment has nothing here left to claim. Oldest open invoice first, which is what a
// shopkeeper pushing cash across the counter means by "against what I owe you".
function allocateVendorPaymentToOrders(PDO $db, string $vendorId, float $amount, string $linkedPurchaseId = ''): array {
    $remaining = round($amount, 2);
    if ($vendorId === '' || $remaining <= 0.005) return [];

    $applied = [];
    $poStmt = $db->prepare("SELECT id, order_number, order_date, total_cost, amount_paid, COALESCE(credit_used, 0) AS credit_used
                              FROM purchases
                             WHERE vendor_id = ?
                             ORDER BY (id = ?) DESC, order_date ASC, created_at ASC");
    $poStmt->execute([$vendorId, $linkedPurchaseId]);

    $upStmt = $db->prepare("UPDATE purchases SET amount_paid = ?, payment_status = ?, updated_at = datetime('now') WHERE id = ?");

    foreach ($poStmt as $po) {
        if ($remaining <= 0.005) break;
        $left = round(floatval($po['total_cost']) - floatval($po['amount_paid']) - floatval($po['credit_used']), 2);
        if ($left <= 0.005) continue;

        $take = round(min($left, $remaining), 2);
        $newPaid = round(floatval($po['amount_paid']) + $take, 2);
        $newStatus = (round($newPaid + floatval($po['credit_used']), 2) >= floatval($po['total_cost']) - 0.005) ? 'PAID' : 'PARTIAL';
        $upStmt->execute([$newPaid, $newStatus, $po['id']]);

        $remaining = round($remaining - $take, 2);
        $applied[] = [
            'id' => $po['id'], 'order_number' => $po['order_number'], 'amount' => $take,
            'amount_paid' => $newPaid, 'payment_status' => $newStatus,
        ];
    }
    return $applied;
}

// Reconcile the settlements an earlier release recorded but never applied.
//
// Before allocateVendorPaymentToOrders existed, a payout taken from the Suppliers page moved
// vendors.balance, wrote its ledger row, and left every order it had actually paid for at its
// old amount_paid and its PARTIAL badge. The owner's own book is in that state right now: two
// payouts on 2026-10-30, GH₵1,200,000 to Unilever and GH₵33,000 to Dangote, neither linked to
// an order, against PO-20261030-5405 and PO-20261030-5622, which are still open. The code is
// fixed; the fix does not revise history, so this walks the rows once.
//
// The account is the authority and the ledger is only the ceiling. Summing vendor_payments
// would say more money left the till than really did - the same Dangote account carries two
// GH₵2,450 payouts written twice and debited once - so the amount settled here is the gap the
// signed balance already shows, capped by the payouts no order has ever claimed. That cap is
// the fingerprint of this bug, and it is what stops the walk inventing a settlement for goods
// bought for cash at the counter, where the money left with the order and never became a payout.
//
// Idempotent twice over, and it has to be the second way. Once the invoices close, the account
// and the paper agree and the gap is zero - but a vendor whose settle was capped by the ledger
// (the Half Paid Depot case below) still shows a gap afterwards, so a naive walk would move
// another GH₵2,000 of invoices on every boot until the account was satisfied out of nothing.
// This is a one-time correction to history, so it says so once, in the file it corrected.
function reconcileUnappliedVendorPayouts(PDO $db): array {
    $healed = [];

    $db->exec("CREATE TABLE IF NOT EXISTS _storeflow_flags (key TEXT PRIMARY KEY, value TEXT NOT NULL)");
    $stamp = $db->prepare("SELECT value FROM _storeflow_flags WHERE key = 'payouts_reconciled'");
    $stamp->execute();
    if ($stamp->fetchColumn() !== false) return $healed;

    $vendors = $db->query("SELECT id, name, balance FROM vendors")->fetchAll();
    // A book with no suppliers in it has nothing to reconcile - and on a fresh install this runs
    // before the sample suppliers are seeded, so stamping here would mark the file done before
    // it had ever looked at a row. Leave the flag for a boot that actually read a supplier.
    if (!$vendors) return $healed;

    // Per order, never netted: an order paid twice over must not hide an order nobody has
    // paid at all, so each line contributes its own open amount and nothing negative.
    $openStmt = $db->prepare("SELECT COALESCE(SUM(still_open), 0)
                                FROM (SELECT MAX(0.0, total_cost - COALESCE(amount_paid, 0.0) - COALESCE(credit_used, 0.0)) AS still_open
                                        FROM purchases
                                       WHERE vendor_id = ? AND COALESCE(status, '') <> 'CANCELLED'
                                         AND total_cost IS NOT NULL)");
    $unlinkedStmt = $db->prepare("SELECT COALESCE(SUM(amount), 0) FROM vendor_payments
                                   WHERE vendor_id = ? AND (purchase_id IS NULL OR purchase_id = '')");

    foreach ($vendors as $vendor) {
        $openStmt->execute([$vendor['id']]);
        $owedByOrders = round(floatval($openStmt->fetchColumn()), 2);
        if ($owedByOrders <= 0.005) continue;

        // A negative balance is an advance the factory is holding, not a debt: the orders it
        // has not yet delivered are not yet owed anything, so the account counts as owing zero.
        $accountOwed = max(0.0, round(floatval($vendor['balance']), 2));
        $gap = round($owedByOrders - $accountOwed, 2);
        if ($gap <= 0.01) continue;

        $unlinkedStmt->execute([$vendor['id']]);
        $settle = round(min($gap, floatval($unlinkedStmt->fetchColumn())), 2);
        if ($settle <= 0.01) continue;

        $applied = allocateVendorPaymentToOrders($db, $vendor['id'], $settle);
        if (!$applied) continue;

        logActivity($db, 1, 'StoreFlow', 'System', 'VENDOR_PAYOUT_RECONCILE',
            "Applied {$settle} of already-recorded payouts to supplier '{$vendor['name']}' against "
            . count($applied) . " order(s) they had paid for but never closed: "
            . implode(', ', array_map(fn($a) => "{$a['order_number']} +{$a['amount']} ({$a['payment_status']})", $applied))
            . ". No cash moved; this only says where money already paid went.");

        $healed[] = [
            'vendor_id' => $vendor['id'],
            'vendor_name' => $vendor['name'],
            'settled' => $settle,
            'orders' => $applied,
        ];
    }

    $db->exec("INSERT OR REPLACE INTO _storeflow_flags (key, value) VALUES ('payouts_reconciled', datetime('now'))");
    return $healed;
}

// ── The arrival workflow: order, count in, call off ──────────────────────────────────
//
// A purchase is written at three doors - the counter with the line up, the same counter
// with the cable out and replayed through sync, and the back door where the delivery is
// counted - and all three have to reach the same shelf and the same invoice. So the
// arithmetic lives here once. It used to be copied into purchases.php and sync.php line
// for line, which is how a crate came to mean thirty eggs at one door and one at another.
//
// None of these touch a supplier's account. The order books the debt when the paper is
// signed, because that is when the deposit is paid; a count-in only says what arrived, and
// its caller moves the account by the difference between what was invoiced and what came.

/**
 * Write the lines of an order. Nothing reaches the shelf here - this is what the shop
 * asked the factory for, not what it got.
 */
function recordPurchaseOrderLines(PDO $db, string $purchaseId, array $items): array {
    require_once __DIR__ . '/product_units.php';

    $ins = $db->prepare("INSERT INTO purchase_items (id, purchase_id, product_id, quantity, cost_price, subtotal,
                                                       batch_number, expiry_date, mfg_date, unit, multiplier, base_quantity, counted_quantity)
                                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL)");
    $prodLook = $db->prepare("SELECT id, name, unit FROM products WHERE id = ?");
    $lineTaken = $db->prepare("SELECT 1 FROM purchase_items WHERE id = ?");

    $lines = [];
    $problems = [];

    foreach ($items as $item) {
        $productId = trim((string)($item['product_id'] ?? $item['item_id'] ?? ''));
        $qty = round(floatval($item['quantity'] ?? 0), 4);
        $cost = round(floatval($item['cost_price'] ?? 0), 2);
        if ($productId === '' || $qty <= 0) continue;

        $prodLook->execute([$productId]);
        $prod = $prodLook->fetch();
        if ($prod === false) {
            $problems[] = ['kind' => 'unknown_product', 'product_id' => $productId,
                'message' => "It names a product that is not in this shop's catalogue ({$productId})."];
            continue;
        }

        // The size is the catalogue's answer, never the till's: "5 crates at 90" is thirty
        // eggs per crate only if the shop said so when it set the product up.
        $reqUnit = trim((string)($item['unit'] ?? ''));
        $unitRow = sfUnitResolve($db, $productId, $reqUnit, true);
        if ($unitRow === null) {
            $known = [];
            foreach (sfUnitsFor($db, $productId) as $knownUnit) {
                $known[] = trim((string)($knownUnit['unit_name'] ?? ''));
            }
            $problems[] = [
                'kind' => 'unknown_unit', 'product_id' => $productId, 'product_name' => $prod['name'], 'unit' => $reqUnit,
                'message' => sprintf("'%s' does not take delivery in a %s. This shop stocks it in %s.",
                    $prod['name'], $reqUnit !== '' ? $reqUnit : 'that size',
                    $known ? implode(', ', $known) : 'no recorded size'),
            ];
            continue;
        }

        $unitLabel = trim((string)($unitRow['unit_name'] ?? '')) ?: (trim((string)($prod['unit'] ?? '')) ?: 'pcs');
        $multiplier = max(1.0, round(floatval($unitRow['size_in_base'] ?? 1), 4));
        $baseQty = round($qty * $multiplier, 4);

        // A till that took this order with the cable out has already written its count-in
        // against the line ids on its own copy, so those ids are kept when they are well
        // formed and free. Roll a fresh one otherwise: an id already in use belongs to
        // another order, and booking against it would count goods onto the wrong shelf.
        $lineId = trim((string)($item['id'] ?? ''));
        if (!preg_match('/^pi_[A-Za-z0-9_\-]{4,48}$/', $lineId)) {
            $lineId = '';
        } else {
            $lineTaken->execute([$lineId]);
            if ($lineTaken->fetchColumn()) $lineId = '';
        }
        if ($lineId === '') $lineId = 'pi_' . bin2hex(random_bytes(6));

        $ins->execute([$lineId, $purchaseId, $productId, $qty, $cost, round($qty * $cost, 2),
            trim((string)($item['batch_number'] ?? '')) ?: null,
            trim((string)($item['expiry_date'] ?? '')) ?: null,
            trim((string)($item['mfg_date'] ?? '')) ?: null,
            $unitLabel, $multiplier, $baseQty]);

        $lines[] = [
            'id' => $lineId, 'product_id' => $productId, 'product_name' => $prod['name'],
            'quantity' => $qty, 'unit' => $unitLabel, 'multiplier' => $multiplier,
            'base_quantity' => $baseQty, 'cost_price' => $cost, 'subtotal' => round($qty * $cost, 2),
        ];
    }

    return ['lines' => $lines, 'problems' => $problems];
}

/**
 * Count an order in: write down what actually came and put exactly that on the shelf.
 *
 * $countedByLine is purchase_item_id => the number that arrived, in the size the line was
 * ordered in. Every line of the order has to be answered, because a line nobody counted is
 * the difference between "the truck came without it" and "nobody looked at it".
 */
function bookCountedPurchaseLines(PDO $db, array $po, array $countedByLine, string $branchCode, int $userId, string $origin = '', array $batchDetails = []): array {
    require_once __DIR__ . '/product_units.php';

    $lineStmt = $db->prepare("SELECT * FROM purchase_items WHERE purchase_id = ? ORDER BY rowid");
    $lineStmt->execute([$po['id']]);
    $orderLines = $lineStmt->fetchAll();

    $prodInfo = $db->prepare("SELECT p.cost_price, p.has_expiry, p.unit, COALESCE(i.current_quantity, 0) AS current_quantity
                              FROM products p LEFT JOIN inventory i ON p.id = i.product_id WHERE p.id = ?");
    $setCounted = $db->prepare("UPDATE purchase_items SET counted_quantity = ? WHERE id = ?");
    $updateLineBatch = $db->prepare("UPDATE purchase_items SET batch_number = ?, expiry_date = ?, mfg_date = ? WHERE id = ?");
    // One statement for both cases. An UPDATE on its own quietly books nothing when a product
    // has no inventory row yet, which is the silent half of a delivery that never appeared.
    $stockUp = $db->prepare("INSERT INTO inventory (id, product_id, current_quantity, reorder_level, location, updated_at)
                             VALUES (?, ?, ?, 5.0, 'Main Storefront', datetime('now'))
                             ON CONFLICT(product_id) DO UPDATE SET
                               current_quantity = inventory.current_quantity + excluded.current_quantity,
                               updated_at = datetime('now')");
    $binvUp = $db->prepare("INSERT INTO branch_inventory (id, branch_code, product_id, current_quantity, updated_at)
                            VALUES (?, ?, ?, ?, datetime('now'))
                            ON CONFLICT(branch_code, product_id) DO UPDATE SET
                              current_quantity = branch_inventory.current_quantity + excluded.current_quantity,
                              updated_at = datetime('now')");
    $prodCost = $db->prepare("UPDATE products SET cost_price = ?, updated_at = datetime('now') WHERE id = ?");
    $batchIns = $db->prepare("INSERT INTO product_batches (id, product_id, batch_number, expiry_date, manufacture_date,
                                                             initial_quantity, current_quantity, cost_price, supplier_id,
                                                             branch_code, status, notes, created_at, updated_at)
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ACTIVE', ?, datetime('now'), datetime('now'))");
    $prodExpiry = $db->prepare("UPDATE products SET has_expiry = 1, batch_number = ?, expiry_date = ?, updated_at = datetime('now') WHERE id = ?");
    $mvtIns = $db->prepare("INSERT INTO inventory_movements (id, product_id, movement_type, quantity, reference_id, unit_price, notes, branch_code, created_at)
                            VALUES (?, ?, 'PURCHASE', ?, ?, ?, ?, ?, datetime('now'))");

    $booked = [];
    $problems = [];
    $receivedValue = 0.0;
    $orderedValue = 0.0;
    $orderNumber = (string)($po['order_number'] ?? $po['id']);
    $supplierName = (string)($po['supplier_name'] ?? 'Supplier');

    foreach ($orderLines as $line) {
        $lineId = (string)$line['id'];
        $orderedQty = round(floatval($line['quantity']), 4);
        $cost = round(floatval($line['cost_price']), 2);
        $orderedValue = round($orderedValue + ($orderedQty * $cost), 2);

        if (!array_key_exists($lineId, $countedByLine)) {
            $problems[] = ['kind' => 'not_counted', 'purchase_item_id' => $lineId,
                'product_name' => (string)($line['product_name'] ?? $line['product_id']),
                'message' => 'Every line of the order has to be counted, including the ones that did not come.'];
            continue;
        }

        $countedQty = round(max(0.0, floatval($countedByLine[$lineId])), 4);
        $setCounted->execute([$countedQty, $lineId]);
        $receivedValue = round($receivedValue + ($countedQty * $cost), 2);

        if ($countedQty <= 0) {
            // Nothing came for this line. The count is still written, because "0 crates" is
            // a fact about the delivery that the shopkeeper will want in six weeks.
            $booked[] = ['purchase_item_id' => $lineId, 'product_id' => (string)$line['product_id'],
                         'counted_quantity' => 0.0, 'base_quantity' => 0.0, 'subtotal' => 0.0];
            continue;
        }

        $prodInfo->execute([(string)$line['product_id']]);
        $prod = $prodInfo->fetch();
        if ($prod === false) {
            $problems[] = ['kind' => 'unknown_product', 'product_id' => (string)$line['product_id'],
                'message' => 'A product on this order is no longer in the catalogue, so its delivery cannot be booked.'];
            $setCounted->execute([null, $lineId]);
            $receivedValue = round($receivedValue - ($countedQty * $cost), 2);
            continue;
        }

        $multiplier = round(floatval($line['multiplier'] ?? 1), 4);
        if ($multiplier < 1) {
            // A line written before the size was recorded on the row. Ask the catalogue
            // rather than assume, because assuming 1 stocks one bottle for a crate of thirty.
            $unitRow = sfUnitResolve($db, (string)$line['product_id'], (string)($line['unit'] ?? ''), false);
            $multiplier = max(1.0, round(floatval($unitRow['size_in_base'] ?? 1), 4));
        }
        $unitLabel = trim((string)($line['unit'] ?? '')) ?: (trim((string)($prod['unit'] ?? '')) ?: 'pcs');
        $baseQty = round($countedQty * $multiplier, 4);
        $perBaseCost = round($cost / $multiplier, 4);

        $curQty = floatval($prod['current_quantity'] ?? 0);
        $oldCost = floatval($prod['cost_price'] ?? $perBaseCost);
        $weightedCost = $curQty > 0
            ? round((($curQty * $oldCost) + ($baseQty * $perBaseCost)) / ($curQty + $baseQty), 2)
            : round($perBaseCost, 2);

        $stockUp->execute(['inv_' . bin2hex(random_bytes(6)), (string)$line['product_id'], $baseQty]);
        $binvUp->execute(['binv_' . bin2hex(random_bytes(6)), $branchCode, (string)$line['product_id'], $baseQty]);
        $prodCost->execute([$weightedCost, (string)$line['product_id']]);

        $bInfo = $batchDetails[$lineId] ?? [];
        $batchNumber = (isset($bInfo['batch_number']) && $bInfo['batch_number'] !== '')
            ? $bInfo['batch_number']
            : trim((string)($line['batch_number'] ?? ''));
        $expiryDate = (isset($bInfo['expiry_date']) && $bInfo['expiry_date'] !== '')
            ? $bInfo['expiry_date']
            : trim((string)($line['expiry_date'] ?? ''));
        $mfgDate = (isset($bInfo['mfg_date']) && $bInfo['mfg_date'] !== null)
            ? $bInfo['mfg_date']
            : (trim((string)($line['mfg_date'] ?? '')) ?: null);

        if (!empty($bInfo)) {
            $updateLineBatch->execute([
                $batchNumber !== '' ? $batchNumber : null,
                $expiryDate !== '' ? $expiryDate : null,
                $mfgDate,
                $lineId
            ]);
        }

        if ($batchNumber !== '' || $expiryDate !== '' || intval($prod['has_expiry'] ?? 0) === 1) {
            $bNo = $batchNumber !== '' ? $batchNumber : ('LOT-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(2))));
            $exp = $expiryDate !== '' ? $expiryDate : date('Y-m-d', strtotime('+1 year'));
            $batchIns->execute(['batch_' . bin2hex(random_bytes(6)), (string)$line['product_id'], $bNo, $exp, $mfgDate,
                $baseQty, $baseQty, $perBaseCost, $po['vendor_id'] ?? null, $branchCode,
                "Counted in from Order #{$orderNumber} ({$supplierName})"]);
            $prodExpiry->execute([$bNo, $exp, (string)$line['product_id']]);
        }

        $sizeNote = $multiplier > 1
            ? "{$countedQty} {$unitLabel} ({$baseQty} " . trim((string)($prod['unit'] ?? '')) . ")"
            : "{$countedQty} {$unitLabel}";
        $note = "Counted in: {$supplierName} (Order #{$orderNumber}). Received {$sizeNote} at {$cost} per {$unitLabel}."
              . " Ordered " . round(floatval($line['quantity']), 4) . " {$unitLabel}."
              . " Avg cost moved from {$oldCost} to {$weightedCost} per loose unit";
        if ($origin !== '') $note = "{$origin} {$note}";
        if ($batchNumber !== '' || $expiryDate !== '') $note .= " [Batch: {$batchNumber}, Exp: {$expiryDate}]";
        $mvtIns->execute(['mvt_' . bin2hex(random_bytes(6)), (string)$line['product_id'], $baseQty,
            $orderNumber, $perBaseCost, $note, $branchCode]);

        $booked[] = [
            'purchase_item_id' => $lineId, 'product_id' => (string)$line['product_id'],
            'product_name' => (string)($prod['name'] ?? $line['product_id']),
            'ordered_quantity' => $orderedQty, 'counted_quantity' => $countedQty, 'unit' => $unitLabel,
            'multiplier' => $multiplier, 'base_quantity' => $baseQty, 'cost_price' => $cost,
            'subtotal' => round($countedQty * $cost, 2), 'average_cost' => $weightedCost,
        ];
    }

    return [
        'booked' => $booked,
        'problems' => $problems,
        'ordered_value' => round($orderedValue, 2),
        'received_value' => round($receivedValue, 2),
        'value_delta' => round($orderedValue - $receivedValue, 2),
    ];
}

/**
 * Take a counted delivery back off the shelf, because the shop is handing it to the
 * supplier and not keeping it.
 *
 * All of it or none of it, and the shelf has to be holding it. Stock is fungible, so what the
 * books can ask is "is there this much on the shelf" - a delivery whose goods have gone out of a
 * busy shelf is still a delivery the shop can hand back, and a shop that has sold more than it
 * is holding is not. Half-reversing is how a shelf ends up below zero and a cost average nobody
 * can explain, so a shortfall refuses the whole hand-back rather than taking what it can.
 */
function reverseCountedPurchaseLines(PDO $db, array $po, string $branchCode, int $userId, string $origin = ''): array {
    $lineStmt = $db->prepare("SELECT * FROM purchase_items WHERE purchase_id = ? AND COALESCE(counted_quantity, 0) > 0 ORDER BY rowid");
    $lineStmt->execute([$po['id']]);
    $countedLines = $lineStmt->fetchAll();

    $prodLook = $db->prepare("SELECT p.name, p.unit, COALESCE(i.current_quantity, 0) AS current_quantity
                              FROM products p LEFT JOIN inventory i ON p.id = i.product_id WHERE p.id = ?");
    $binvLook = $db->prepare("SELECT current_quantity FROM branch_inventory WHERE branch_code = ? AND product_id = ?");

    // Work the whole order out before writing a single number: a cancellation that fails
    // halfway leaves the shop holding two shelves, one of them wrong.
    $plan = [];
    $shortfall = [];
    foreach ($countedLines as $line) {
        $countedQty = round(floatval($line['counted_quantity']), 4);
        $multiplier = max(1.0, round(floatval($line['multiplier'] ?? 1), 4));
        $baseQty = round($countedQty * $multiplier, 4);

        $prodLook->execute([(string)$line['product_id']]);
        $prod = $prodLook->fetch();
        if ($prod === false) {
            $shortfall[] = ['product_id' => (string)$line['product_id'], 'product_name' => (string)$line['product_id'],
                            'counted' => $baseQty, 'on_hand' => 0.0];
            continue;
        }
        $onHand = round(floatval($prod['current_quantity']), 4);
        $binvLook->execute([$branchCode, (string)$line['product_id']]);
        $atBranch = round(floatval($binvLook->fetchColumn() ?: 0), 4);

        if ($onHand < $baseQty - 0.0001 || $atBranch < $baseQty - 0.0001) {
            $shortfall[] = [
                'product_id' => (string)$line['product_id'],
                'product_name' => (string)($prod['name'] ?? $line['product_id']),
                'counted' => $baseQty, 'on_hand' => min($onHand, $atBranch),
                'already_gone' => round($baseQty - min($onHand, $atBranch), 4),
            ];
            continue;
        }

        $plan[] = ['line' => $line, 'prod' => $prod, 'base_qty' => $baseQty, 'counted_qty' => $countedQty,
                   'multiplier' => $multiplier, 'cost' => round(floatval($line['cost_price']), 2)];
    }

    if ($shortfall) {
        return ['ok' => false, 'shortfall' => $shortfall, 'reversed_value' => 0.0];
    }

    $stockDown = $db->prepare("UPDATE inventory SET current_quantity = MAX(0, current_quantity - ?), updated_at = datetime('now') WHERE product_id = ?");
    $binvDown = $db->prepare("UPDATE branch_inventory SET current_quantity = MAX(0, current_quantity - ?), updated_at = datetime('now')
                              WHERE branch_code = ? AND product_id = ?");
    $batchFind = $db->prepare("SELECT id, current_quantity FROM product_batches
                               WHERE product_id = ? AND branch_code = ? AND current_quantity > 0 AND status = 'ACTIVE'
                               ORDER BY expiry_date ASC");
    $batchTake = $db->prepare("UPDATE product_batches SET current_quantity = MAX(0, current_quantity - ?),
                                      status = CASE WHEN (current_quantity - ?) <= 0.001 THEN 'DEPLETED' ELSE status END,
                                      updated_at = datetime('now') WHERE id = ?");
    $mvtIns = $db->prepare("INSERT INTO inventory_movements (id, product_id, movement_type, quantity, reference_id, unit_price, notes, branch_code, created_at)
                            VALUES (?, ?, 'PURCHASE_RETURN', ?, ?, ?, ?, ?, datetime('now'))");

    $orderNumber = (string)($po['order_number'] ?? $po['id']);
    $supplierName = (string)($po['supplier_name'] ?? 'Supplier');
    $reversed = [];
    $reversedValue = 0.0;

    foreach ($plan as $p) {
        $stockDown->execute([$p['base_qty'], (string)$p['line']['product_id']]);
        $binvDown->execute([$p['base_qty'], $branchCode, (string)$p['line']['product_id']]);

        // The lots go back oldest-first, which is the same order the till sells them in, so
        // the shelf is left holding the newer goods rather than an expiry nobody can reach.
        $left = $p['base_qty'];
        $batchFind->execute([(string)$p['line']['product_id'], $branchCode]);
        foreach ($batchFind->fetchAll() as $lot) {
            if ($left <= 0.0001) break;
            $take = round(min($left, floatval($lot['current_quantity'])), 4);
            if ($take <= 0.0001) continue;
            $batchTake->execute([$take, $take, (string)$lot['id']]);
            $left = round($left - $take, 4);
        }

        $unitLabel = trim((string)($p['line']['unit'] ?? '')) ?: (trim((string)($p['prod']['unit'] ?? '')) ?: 'pcs');
        $note = "Delivery handed back to {$supplierName} (Order #{$orderNumber}): "
              . "{$p['counted_qty']} {$unitLabel} ({$p['base_qty']} loose) taken off the shelf.";
        if ($origin !== '') $note = "{$origin} {$note}";
        $mvtIns->execute(['mvt_' . bin2hex(random_bytes(6)), (string)$p['line']['product_id'], -$p['base_qty'],
            $orderNumber, $p['cost'], $note, $branchCode]);

        $reversedValue = round($reversedValue + ($p['counted_qty'] * $p['cost']), 2);
        $reversed[] = ['product_id' => (string)$p['line']['product_id'], 'counted_quantity' => $p['counted_qty'],
                       'base_quantity' => $p['base_qty'], 'value' => round($p['counted_qty'] * $p['cost'], 2)];
    }

    return ['ok' => true, 'reversed' => $reversed, 'reversed_value' => $reversedValue];
}

/**
 * One line of an order's history.
 *
 * activity_logs has no reference column, so an order's story could only be found by
 * reading every line the shop has logged and looking for a number inside a sentence.
 *
 * $eventId is the till's own key for the action being recorded. Passing it makes this row
 * the receipt that the action happened once: a count-in resent from an offline till collides
 * here and is skipped, rather than stocking the shelf a second time.
 */
function recordPurchaseEvent(PDO $db, string $purchaseId, string $eventType, string $reasonCode, string $details, float $amount, array $user, string $eventId = ''): array {
    $id = $eventId !== '' ? $eventId : ('pev_' . bin2hex(random_bytes(6)));
    $stmt = $db->prepare("INSERT INTO purchase_events (id, purchase_id, event_type, reason_code, details, amount, created_by, created_by_name, created_at)
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))");
    $stmt->execute([$id, $purchaseId, $eventType, $reasonCode !== '' ? $reasonCode : null, $details,
        round($amount, 2), intval($user['id'] ?? 0) ?: null, (string)($user['full_name'] ?? 'Staff')]);
    return ['id' => $id, 'purchase_id' => $purchaseId, 'event_type' => $eventType, 'reason_code' => $reasonCode,
            'details' => $details, 'amount' => round($amount, 2), 'created_by_name' => (string)($user['full_name'] ?? 'Staff')];
}

function purchaseEventAlreadyRecorded(PDO $db, string $eventId): bool {
    if ($eventId === '') return false;
    $stmt = $db->prepare("SELECT 1 FROM purchase_events WHERE id = ?");
    $stmt->execute([$eventId]);
    return (bool)$stmt->fetchColumn();
}

/**
 * Count a delivery in, and let the shop's books follow what actually came.
 *
 * One function for both doors on purpose. The same order can arrive from the till over the
 * wire or from an offline queue a day later, and the two used to disagree about what a
 * delivery was worth because each wrote its own arithmetic. A refusal here is a decision
 * about money, so it is the same decision whichever door it came through.
 *
 * Returns ['ok' => bool, 'status' => int, 'body' => array] - the caller commits on ok and
 * rolls back otherwise, and answers the browser with body/status verbatim.
 */
function countInPurchaseOrder(PDO $db, array $po, array $payloadLines, array $authUser, string $eventId = '', string $reasonCode = '', string $note = '', string $origin = ''): array {
    $purchaseId = (string)$po['id'];
    $orderNumber = (string)($po['order_number'] ?? $purchaseId);
    $branchCode = strtoupper(trim((string)($po['branch_code'] ?? ''))) ?: 'MAIN-01';
    $refuse = function (string $message, int $status, bool $already = false): array {
        return ['ok' => false, 'status' => $status,
            'body' => array_filter(['success' => false, 'message' => $message, 'already_applied' => $already ?: null],
                fn($v) => $v !== null)];
    };

    if (purchaseEventAlreadyRecorded($db, $eventId)) {
        return $refuse("That count-in is already in the shop's books. The shelf was not moved a second time.", 409, true);
    }
    $poStatus = strtoupper(trim((string)($po['status'] ?? 'PENDING')));
    if ($poStatus === 'CANCELLED') {
        return $refuse("Order #{$orderNumber} was called off, so its delivery cannot be counted in. Re-open it as a new order if the goods did arrive after all.", 409);
    }
    if ($poStatus === 'COUNTED') {
        return $refuse("Order #{$orderNumber} was already counted in. Nothing was added to the shelf a second time.", 409, true);
    }

    $ownStmt = $db->prepare("SELECT id FROM purchase_items WHERE purchase_id = ?");
    $ownStmt->execute([$purchaseId]);
    $ownLines = array_map('strval', $ownStmt->fetchAll(PDO::FETCH_COLUMN));

    $countedByLine = [];
    $batchDetails = [];
    foreach ($payloadLines as $line) {
        if (!is_array($line)) continue;
        $lineId = trim((string)($line['purchase_item_id'] ?? $line['id'] ?? ''));
        if ($lineId === '') continue;
        $countedByLine[$lineId] = max(0.0, round(floatval($line['counted_quantity'] ?? 0), 4));
        if (isset($line['batch_number']) || isset($line['expiry_date']) || isset($line['mfg_date'])) {
            $batchDetails[$lineId] = [
                'batch_number' => trim((string)($line['batch_number'] ?? '')),
                'expiry_date' => trim((string)($line['expiry_date'] ?? '')),
                'mfg_date' => trim((string)($line['mfg_date'] ?? '')) ?: null,
            ];
        }
    }

    // A line the order has never heard of is not a count, it is a different delivery note -
    // and booking it would let a browser invent stock by naming a row id.
    $foreign = array_values(array_diff(array_keys($countedByLine), $ownLines));
    if ($foreign) {
        return $refuse('The count-in names a line that is not on this order, so nothing was booked.', 400);
    }

    $result = bookCountedPurchaseLines($db, $po, $countedByLine, $branchCode, intval($authUser['id'] ?? 0), $origin, $batchDetails);
    if ($result['problems']) {
        return $refuse("Order #{$orderNumber} was not counted in: " . $result['problems'][0]['message']
            . ' Nothing reached the shelf and no money was moved.', 400);
    }

    $shipping = round(floatval($po['shipping_cost'] ?? 0), 2);
    $oldTotal = round(floatval($po['total_cost']), 2);
    // The invoice becomes the delivery. total_cost is the number every accounts-payable read
    // uses, so a shortfall that never reached the shelf must reach it too, or the shop goes
    // on owing for crates the factory never sent.
    $newTotal = round($result['received_value'] + $shipping, 2);
    $valueDelta = round($oldTotal - $newTotal, 2);

    $amountPaid = round(floatval($po['amount_paid']), 2);
    $creditUsed = round(floatval($po['credit_used'] ?? 0), 2);
    $paymentStatus = ($amountPaid + $creditUsed) >= ($newTotal - 0.005) ? 'PAID' : ($amountPaid > 0 ? 'PARTIAL' : 'UNPAID');

    $db->prepare("UPDATE purchases SET status = 'COUNTED', total_cost = ?, payment_status = ?, counted_at = datetime('now'), counted_by = ?, updated_at = datetime('now') WHERE id = ?")
       ->execute([$newTotal, $paymentStatus, intval($authUser['id'] ?? 0) ?: null, $purchaseId]);

    // What the shop did not receive comes off what it owes - and if it had already paid, the
    // difference stays with the factory as the shop's money rather than vanishing. One signed
    // number carries both, which is why this is a subtraction of the shortfall and nothing else.
    if (!empty($po['vendor_id']) && abs($valueDelta) >= 0.005) {
        $db->prepare("UPDATE vendors SET balance = balance - ?, updated_at = datetime('now') WHERE id = ?")
           ->execute([$valueDelta, $po['vendor_id']]);
    }

    $shortLines = array_values(array_filter($result['booked'],
        fn($b) => round(floatval($b['counted_quantity']), 4) < round(floatval($b['ordered_quantity']), 4)));
    $finalReason = $reasonCode !== '' ? $reasonCode : ($valueDelta > 0.005 ? 'SHORT_DELIVERY' : ($valueDelta < -0.005 ? 'WRONG_GOODS' : ''));

    $detail = sprintf('Counted in %s of %s. Invoice moved from %s to %s.',
        round($result['received_value'], 2), round($result['ordered_value'], 2), $oldTotal, $newTotal);
    if (abs($valueDelta) >= 0.005) {
        $detail .= $valueDelta > 0
            ? sprintf(' %s less than invoiced came off what the shop owes.', $valueDelta)
            : sprintf(' The factory sent %s more than invoiced, and the shop owes it.', abs($valueDelta));
    }
    if ($note !== '') $detail .= " Note: {$note}";
    $event = recordPurchaseEvent($db, $purchaseId, 'COUNTED_IN', $finalReason, $detail, -$valueDelta, $authUser, $eventId);

    logActivity($db, $authUser['id'] ?? 0, $authUser['full_name'] ?? 'Staff', $authUser['role_name'] ?? '',
        'PURCHASE_COUNTED_IN',
        "Counted in order #{$orderNumber} from '" . ($po['supplier_name'] ?? '') . "': goods worth "
        . $result['received_value'] . ' of ' . $result['ordered_value'] . " arrived. Invoice is now {$newTotal}." . ($origin !== '' ? " ({$origin})" : ''));

    return ['ok' => true, 'status' => 201, 'body' => [
        'success' => true,
        'message' => "Order #{$orderNumber} counted in. {$result['received_value']} of goods reached the shelf.",
        'order_id' => $purchaseId,
        'order_number' => $orderNumber,
        'status' => 'COUNTED',
        'received_value' => round($result['received_value'], 2),
        'ordered_value' => round($result['ordered_value'], 2),
        'value_delta' => $valueDelta,
        'total_cost' => $newTotal,
        'payment_status' => $paymentStatus,
        'booked' => $result['booked'],
        'short_lines' => $shortLines,
        'event' => $event,
    ]];
}

/**
 * Call an order off, and take its invoice back off the shop's account.
 *
 * The rule is the same whether the truck came or not: the invoice leaves the account whole.
 * Cash the shop already paid stays where it is - in the supplier's hands - so cancelling a
 * paid-for order lands on the account as an advance instead of money the till has to go and
 * find. Goods that reached the shelf go back to the factory, all of them or none of them.
 */
function cancelPurchaseOrder(PDO $db, array $po, array $authUser, string $reasonCode, string $note = '', string $eventId = '', string $origin = ''): array {
    $purchaseId = (string)$po['id'];
    $orderNumber = (string)($po['order_number'] ?? $purchaseId);
    $branchCode = strtoupper(trim((string)($po['branch_code'] ?? ''))) ?: 'MAIN-01';
    $refuse = function (string $message, int $status, array $extra = []): array {
        return ['ok' => false, 'status' => $status, 'body' => array_merge(['success' => false, 'message' => $message], $extra)];
    };

    if ($reasonCode === '') {
        return $refuse('Say why the order is being called off. "Other" is enough; nothing is a note a shopkeeper cannot read back in six months.', 400);
    }
    if (purchaseEventAlreadyRecorded($db, $eventId)) {
        return $refuse("That cancellation is already in the shop's books. Nothing was reversed a second time.", 409, ['already_applied' => true]);
    }
    if (strtoupper(trim((string)($po['status'] ?? 'PENDING'))) === 'CANCELLED') {
        return $refuse("Order #{$orderNumber} is already cancelled. The debt was not taken off the account twice.", 409, ['already_applied' => true]);
    }

    $reversal = null;
    if (strtoupper(trim((string)($po['status'] ?? 'PENDING'))) === 'COUNTED') {
        $reversal = reverseCountedPurchaseLines($db, $po, $branchCode, intval($authUser['id'] ?? 0), $origin);
        if (empty($reversal['ok'])) {
            $names = array_map(fn($s) => sprintf('%s (%s of the %s counted in is already gone)',
                $s['product_name'], $s['already_gone'], $s['counted']), $reversal['shortfall']);
            return $refuse("Order #{$orderNumber} was counted in and part of it has since been sold, so it cannot be cancelled: "
                . implode('; ', $names) . ". Nothing was reversed. Take the goods back with a supplier credit instead.",
                409, ['shortfall' => $reversal['shortfall']]);
        }
    }

    $invoiceTotal = round(floatval($po['total_cost']), 2);
    if (!empty($po['vendor_id']) && abs($invoiceTotal) >= 0.005) {
        $db->prepare("UPDATE vendors SET balance = balance - ?, updated_at = datetime('now') WHERE id = ?")
           ->execute([$invoiceTotal, $po['vendor_id']]);
    }

    $db->prepare("UPDATE purchases SET status = 'CANCELLED', cancelled_at = datetime('now'), cancel_reason = ?, cancel_note = ?, updated_at = datetime('now') WHERE id = ?")
       ->execute([$reasonCode, $note !== '' ? $note : null, $purchaseId]);

    $detail = sprintf('Order called off (%s). Invoice of %s taken off what the shop owes.', $reasonCode, $invoiceTotal);
    if ($reversal !== null) {
        $detail = sprintf('Delivery handed back to the supplier and %s taken off the shelf; invoice of %s cancelled.',
            round($reversal['reversed_value'], 2), $invoiceTotal);
    }
    if ($note !== '') $detail .= " Note: {$note}";
    $event = recordPurchaseEvent($db, $purchaseId, 'CANCELLED', $reasonCode, $detail, -$invoiceTotal, $authUser, $eventId);

    logActivity($db, $authUser['id'] ?? 0, $authUser['full_name'] ?? 'Staff', $authUser['role_name'] ?? '',
        'PURCHASE_CANCELLED',
        "Cancelled purchase order #{$orderNumber} from '" . ($po['supplier_name'] ?? '') . "' ({$reasonCode})."
        . ' Invoice of ' . $invoiceTotal . ' taken off accounts payable'
        . ($reversal !== null ? ' and ' . $reversal['reversed_value'] . ' of goods handed back.' : '')
        . ($origin !== '' ? " ({$origin})" : '.'));

    return ['ok' => true, 'status' => 200, 'body' => [
        'success' => true,
        'message' => "Order #{$orderNumber} cancelled.",
        'order_id' => $purchaseId,
        'order_number' => $orderNumber,
        'status' => 'CANCELLED',
        'cancelled_value' => $invoiceTotal,
        'goods_handed_back' => $reversal['reversed_value'] ?? 0.0,
        'event' => $event,
    ]];
}

// Authentication & Access Control Helpers
function getCurrentUser(bool $verifyDb = false): ?array {
    $user = $_SESSION['storeflow_user'] ?? null;
    if ($user && $verifyDb) {
        global $db;
        if (isset($db) && $db instanceof PDO) {
            try {
                $stmt = $db->prepare("SELECT u.*, r.role_name, r.permissions, r.max_discount_pct 
                                      FROM users u 
                                      JOIN user_roles r ON u.role_id = r.id 
                                      WHERE u.id = ? AND u.is_active = 1");
                $stmt->execute([$user['id'] ?? 0]);
                $fresh = $stmt->fetch();
                if (!$fresh) {
                    clearCurrentUser();
                    return null;
                }
                $fresh['permissions'] = json_decode($fresh['permissions'] ?? '[]', true) ?: [];
                $fresh['branch_code'] = $fresh['branch_code'] ?? 'MAIN-01';
                // Neither credential belongs in the session, and therefore not in any
                // response that echoes the session user. A 4-digit PIN hashed with
                // bcrypt is crackable in microseconds offline, so shipping the hash to
                // the browser is a weaker form of shipping the PIN itself.
                $fresh['has_pin'] = !empty($fresh['pin_code']);
                unset($fresh['pin_code'], $fresh['password_hash']);
                $_SESSION['storeflow_user'] = $fresh;
                return $fresh;
            } catch (Throwable $e) {
                // Fail open on purpose: this query throws when the database is briefly
                // locked, and logging a whole shop out mid-shift is worse than honouring
                // a session that was already validated against the database at login.
                // What must not happen is that path handing back a credential - the
                // session copy is sanitised, but this is the one place that decides it.
                error_log('StoreFlow: session revalidation failed, honouring cached session: ' . $e->getMessage());
                unset($user['password_hash'], $user['pin_code']);
                return $user;
            }
        }
    }
    return $user;
}

function setCurrentUser(array $user): void {
    $_SESSION['storeflow_user'] = $user;
}

function clearCurrentUser(): void {
    unset($_SESSION['storeflow_user']);
    if (session_status() === PHP_SESSION_ACTIVE) {
        @session_destroy();
    }
}

function requireAuth(): array {
    // Verified against the database, not just the cookie: a cashier deleted or
    // deactivated mid-shift otherwise keeps a working till session for the whole
    // 14-hour cookie life.
    $user = getCurrentUser(true);
    if (!$user) {
        jsonResponse([
            'success' => false,
            'message' => 'Authentication required. Please sign in.',
            'unauthenticated' => true
        ], 401);
    }

    // Server-Side Guard: Block all operations if user must change their default password
    if (!empty($user['must_change_password'])) {
        $script = basename($_SERVER['SCRIPT_NAME'] ?? '');
        $rawInput = file_get_contents('php://input');
        $data = !empty($rawInput) ? (json_decode($rawInput, true) ?: []) : [];

        // Both the query string and the body are read, because endpoints disagree on
        // which one they dispatch on (users.php uses the body, returns.php prefers the
        // query). Reading only one side let `?action=current` mask a body of
        // `action=save`, so an account still on admin123 could create a second
        // Administrator and keep it forever. Every action the request might perform
        // must be safe while un-rotated, or the request is refused.
        //
        // Method matters too: `current` is a read-only GET, but users.php POSTs to the
        // same file and treats a missing body action as `save`. Guessing the verb was the
        // last bypass - {"action":"current"} on POST, or no action at all, both reached the
        // create-user handler through this list.
        $isPost = ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
        $candidates = [];
        foreach ([$_GET['action'] ?? null, $data['action'] ?? null] as $raw) {
            if (is_string($raw) && trim($raw) !== '') $candidates[] = strtolower(trim($raw));
        }
        if ($isPost && $script === 'users.php' && ($data['action'] ?? '') === '') {
            $candidates[] = 'save';
        }
        $safeWhileGated = $isPost ? ['change_initial_password', 'logout'] : ['current', 'me'];
        $isExempt = ($script === 'users.php'
            && $candidates !== []
            && array_diff($candidates, $safeWhileGated) === []);

        if (!$isExempt) {
            jsonResponse([
                'success' => false,
                'must_change_password' => true,
                'message' => 'Access Denied: You must change your default password and PIN before accessing the system.'
            ], 403);
        }
    }

    return $user;
}

function hasPermission(array $user, string $permission): bool {
    $roleName = strtolower(trim($user['role_name'] ?? ''));
    if ($roleName === 'administrator' || intval($user['role_id'] ?? 0) === 1) {
        return true;
    }
    $permissions = $user['permissions'] ?? [];
    if (!is_array($permissions)) {
        $permissions = json_decode($permissions, true) ?: [];
    }
    return in_array($permission, $permissions);
}

function requirePermission(string $permission): array {
    $user = requireAuth();
    if (!hasPermission($user, $permission)) {
        jsonResponse([
            'success' => false,
            'message' => "Forbidden: You lack the required permission '{$permission}'.",
            'forbidden' => true
        ], 403);
    }
    return $user;
}

// Every permission a role can be granted, and what granting it actually opens. Written
// out rather than collected from the source: 'manage_customers' appears in the codebase
// exactly once, as a permission that was deliberately retired when a check turned out to
// mean "administrators only" by accident (see sync.php), and an Access Map that built its
// list by scanning strings would offer it to owners as though it did something.
function storeflowPermissionCatalogue(): array {
    return [
        'manage_sales'     => 'Ring sales at the till, process returns and balance the drawer.',
        'manage_inventory' => 'Edit products, prices and stock. Includes repricing a line at the till and discounts above the role ceiling.',
        'manage_purchases' => 'Raise purchase orders, count in arrivals and pay suppliers.',
        // Worded as what the tick actually withholds, because it is not what the sentence
        // used to promise: the sales book stays on a till's menu while it holds manage_sales
        // (balancing a drawer means reading back what the drawer took), and the analytics
        // boards render from the till's own mirror rather than from an endpoint this could
        // refuse. What it does gate is written beside it, screen by screen, in
        // assets/js/app-shell.js navRights().
        'view_reports'     => 'Open the Dashboard and the Analytics screens. Also each branch\'s turnover, a product\'s sales history and the list of saved backups.',
        'manage_users'     => 'Add staff and edit the Access Map itself.',
        'manage_settings'  => 'Change shop settings, the tax rate and receipt printing.',
        'manage_backups'   => 'Create, export and restore the shop\'s backups.',
    ];
}

// ── Profile masking ───────────────────────────────────────────────────────────
// The store_profile row carries the SMS provider key and the scanner pairing
// secret. Two endpoints hand a profile to the browser - profile.php for the
// settings screen and sync.php inside server_state - so the masking lives here
// rather than in either caller: when it was written inline in profile.php, sync
// kept returning the raw row and every cashier still received the credentials.
function maskProfileForClient(array $profile, array $user): array {
    $profile['mnotify_api_key_set'] = !empty($profile['mnotify_api_key']);
    $profile['mnotify_api_key']     = $profile['mnotify_api_key_set'] ? '********' : '';

    $profile['scanner_pairing_token_set'] = !empty($profile['scanner_pairing_token']);
    if (!hasPermission($user, 'manage_settings')) {
        $profile['scanner_pairing_token'] = '';
    }
    return $profile;
}

// Cost price is the owner's margin, not till data. The same rule has to hold for
// every response that carries product rows, so it is expressed once here.
// Administrators pass hasPermission() without holding the permission explicitly.
function maySeeProductCost(array $user): bool {
    return hasPermission($user, 'manage_inventory') || hasPermission($user, 'manage_purchases');
}

// The same rule for the sales book. A receipt row carries what the goods cost the shop
// and what it made on them, and every door that hands one out has to strip both: the
// receipt a cashier prints, the ledger they scroll, the return slip they build and the
// delta another till pulls all carry the same columns. Stripped means absent, not zero -
// the analytics board already reads a missing cost as "not visible to this user" and
// says so, while a zero would book the whole takings as profit.
function maskSaleRowForClient(array $sale): array {
    unset($sale['total_cost'], $sale['gross_profit'], $sale['net_profit']);
    if (isset($sale['items']) && is_array($sale['items'])) {
        foreach ($sale['items'] as &$line) {
            unset($line['unit_cost_price'], $line['profit']);
        }
        unset($line);
    }
    return $sale;
}

// Who may put a price on a receipt. The role that can change the price list is the
// role that can apply it at the till; a name match would let a custom "Store Manager"
// role reprice goods it cannot even edit.
function maySetSalePrices(array $user): bool {
    return hasPermission($user, 'manage_inventory');
}

// The largest discount a given user may put on a given basket, or null for "no cap".
// A session that predates the column falls back to 10 rather than to no cap: the whole
// point of the ceiling is that a till cannot write a receipt off, and a missing value is
// not an instruction to let it.
function saleDiscountCapPct(array $user): ?float {
    if (maySetSalePrices($user)) {
        return null;
    }
    $pct = $user['max_discount_pct'] ?? null;
    if ($pct === null || $pct === '') {
        $pct = 10;
    }
    return max(0, min(100, floatval($pct)));
}

function saleDiscountCap(array $user, float $subtotal): ?float {
    $pct = saleDiscountCapPct($user);
    if ($pct === null) {
        return null;
    }
    return round($subtotal * $pct / 100, 2);
}

// The largest tax a receipt may carry: the rate the owner configured in settings,
// applied to what the till actually sold. A shop with no rate configured allows no
// tax line at all, which is what makes an added one unsanitised data from the browser.
function saleTaxCap(array $profile, float $subtotal): float {
    $rate = max(0, min(100, floatval($profile['tax_rate'] ?? 0)));
    if ($rate <= 0) {
        return 0.0;
    }
    return round($subtotal * $rate / 100, 2);
}

// What a customer gets back when they hand goods in.
//
// The receipt is taxed and discounted once, at the top, while a return is written line by
// line - so the only honest answer is a share. Returning one GH₵100 item off a receipt of
// GH₵300 with GH₵20 off and 0.5% tax cannot refund GH₵100 (the shop never took GH₵100 for
// that item) and cannot refund GH₵93.33 either (the customer paid the tax on it and is owed
// that back). It is GH₵100 − 6.67 of the discount + 0.50 of the tax = GH₵93.83.
//
// This used to be no apportionment at all: a return paid out Σ(qty × unit price), so a taxed
// receipt always shorted the customer by its tax and left the sale stuck at PARTIAL_REFUNDED
// with a residue nobody could ever claim, while a discounted receipt refunded more than it
// took in - or, once the cap below caught it, could not be returned in full at all. Whether a
// customer could hand goods back depended on the accident of tax rate against discount.
//
// The tax share is the plug when the figures will not add up to the cent. A receipt paid back
// in three returns of 93.83 lands on 281.49 against 281.50 taken in, and the last return has
// to settle the remainder rather than strand one pesewa on a sale that is now fully returned -
// which is the same "stuck at PARTIAL forever" bug at a hundredth the size.
function saleRefundSplit(array $sale, float $gross, float $refundableLeft, bool $emptiesReceipt = false): array {
    $gross = round($gross, 2);
    $subtotal = round(floatval($sale['subtotal'] ?? 0), 2);
    $discount = round(floatval($sale['discount'] ?? 0), 2);
    $tax = round(floatval($sale['tax'] ?? 0), 2);
    $refundableLeft = round($refundableLeft, 2);

    // A receipt with no priced lines has no discount and no tax on it either (both are
    // computed from that subtotal), so there is nothing to apportion against.
    if ($subtotal <= 0.005) {
        return [
            'gross' => $gross,
            'discount_share' => 0.0,
            'tax_share' => 0.0,
            'refund' => round(max(0.0, min($gross, $refundableLeft)), 2),
        ];
    }

    $discountShare = round($gross * $discount / $subtotal, 2);
    $taxShare = round($gross * $tax / $subtotal, 2);
    $refund = round($gross - $discountShare + $taxShare, 2);

    // Every unit on the receipt is back on the shelf: the shop keeps nothing of that sale, so
    // the customer takes the exact remainder and the sale reaches REFUNDED.
    if ($emptiesReceipt) $refund = $refundableLeft;
    if ($refund > $refundableLeft) $refund = $refundableLeft;
    if ($refund < 0) $refund = 0.0;

    $taxShare = round($refund - $gross + $discountShare, 2);

    return [
        'gross' => $gross,
        'discount_share' => $discountShare,
        'tax_share' => $taxShare,
        'refund' => round($refund, 2),
    ];
}

// A discount is only a discount while it has a size. `discount: 100000` on a 500.00
// basket booked the receipt at zero and recorded the whole cost of goods as a loss, in
// both the online and the offline path, because the number came straight from the till.
// Returns null when the basket is payable as described, or a message for the operator.
function saleDiscountProblem(array $user, float $subtotal, float $discount): ?string {
    if ($discount < 0) {
        return 'A discount cannot be negative.';
    }
    $limit = saleDiscountCap($user, $subtotal);
    if ($limit !== null && $discount > $limit + 0.01) {
        $pct = saleDiscountCapPct($user);
        if ($pct <= 0) {
            return sprintf(
                'This receipt is discounted by %.2f, but the Access Map does not let this role discount at all. A store manager or administrator must ring it up.',
                $discount
            );
        }
        return sprintf(
            'This receipt is discounted by %.2f, which is over the %.2f (%s%%) this role may give. A store manager or administrator must ring it up.',
            $discount, $limit, rtrim(rtrim(number_format($pct, 2, '.', ''), '0'), '.')
        );
    }
    return null;
}

// Tax is a shop-wide setting, not a per-receipt number the till invents. An added tax
// line the owner never configured inflates takings; a negative one moves money out.
function saleTaxProblem(array $profile, float $subtotal, float $tax): ?string {
    if ($tax < 0) {
        return 'Tax cannot be negative.';
    }
    $limit = saleTaxCap($profile, $subtotal);
    if ($tax > $limit + 0.01) {
        return sprintf(
            'This receipt adds %.2f tax, but the configured rate allows at most %.2f on a %.2f basket. Change the tax rate in Settings if the shop has started charging it.',
            $tax, $limit, $subtotal
        );
    }
    return null;
}

// ── Credential-guessing throttle ─────────────────────────────────────────────
// Sliding-window counters, one small file per key under .runtime. Counting in the
// activity log instead means the window can be reset by rotating usernames or
// cleared by log pruning, and a locked till has no session to key the count on.
function storeflowThrottleDir(): string {
    $base = $GLOBALS['runtimeDir']
        ?? (defined('STOREFLOW_DATA_DIR') ? STOREFLOW_DATA_DIR : dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'data')
            . DIRECTORY_SEPARATOR . '.runtime';
    $dir = $base . DIRECTORY_SEPARATOR . 'throttle';
    if (!is_dir($dir)) @mkdir($dir, 0777, true);
    return $dir;
}

function storeflowThrottleFile(string $key): string {
    return storeflowThrottleDir() . DIRECTORY_SEPARATOR . hash('sha256', $key) . '.json';
}

function throttleWindow(string $key, int $windowSeconds): array {
    $now = time();
    $cutOff = $now - $windowSeconds;
    $attempts = [];
    $decoded = json_decode((string)@file_get_contents(storeflowThrottleFile($key)), true);
    if (is_array($decoded)) {
        foreach ($decoded as $when) {
            // Only stamps that have genuinely aged out are dropped. A stamp dated in
            // the future is kept: dropping it turned "set the clock forward, burn the
            // budget, set it back" into a reset button on login and unlock throttling,
            // because the rolled-back clock made every attempt look not-yet-happened.
            if (is_numeric($when) && (int)$when > $cutOff) $attempts[] = (int)$when;
        }
    }
    sort($attempts);
    return $attempts;
}

function throttleInspect(string $key, int $limit, int $windowSeconds): array {
    $attempts = throttleWindow($key, $windowSeconds);
    if (count($attempts) >= $limit) {
        // Sliding window: the lock lifts when the $limit-th most recent attempt ages out.
        // Capped, because a rolled-back clock can date an attempt far into the future and
        // the count below is what actually enforces the lockout.
        $expiry = $attempts[count($attempts) - $limit] + $windowSeconds;
        $retry = max(1, min($expiry - time(), 2 * $windowSeconds));
        return ['allowed' => false, 'retry_after' => $retry, 'used' => count($attempts)];
    }
    return ['allowed' => true, 'retry_after' => 0, 'used' => count($attempts)];
}

function throttleRecord(string $key, int $windowSeconds): void {
    $file = storeflowThrottleFile($key);
    $kept = throttleWindow($key, $windowSeconds);
    $kept[] = time();

    // Read-then-write with no lock let two concurrent guesses each see the same short
    // history and both put back the same count, so the fifth and sixth wrong password
    // arrived as one entry. The window is therefore rewritten under an exclusive lock,
    // in the same shape _sysThrottleRecord() uses: on Windows a handle opened 'c+'
    // cannot always be read back after flock, so the read happens before the open.
    $fh = @fopen($file, 'c');
    if (!$fh) {
        // Nothing enforces the lockout if the counter cannot be written. Failing the
        // login outright would lock the shopkeeper out over a full disk, so the
        // compromise is to keep serving but say loudly, in the log the operator reads,
        // that guess-counting is currently off.
        error_log('StoreFlow throttle: cannot write ' . $file . ' - credential-guess throttling is NOT enforced for this request.');
        return;
    }
    try {
        if (flock($fh, LOCK_EX)) {
            ftruncate($fh, 0);
            rewind($fh);
            $written = fwrite($fh, json_encode($kept));
            fflush($fh);
            if ($written === false) {
                error_log('StoreFlow throttle: write failed for ' . $file . '.');
            }
        }
    } finally {
        flock($fh, LOCK_UN);
        fclose($fh);
    }
}

function throttleClear(string $key): void {
    @unlink(storeflowThrottleFile($key));
}

// Several endpoints keep working after commit() inside the same try block (activity
// logging, response building). If that later work throws, the catch's rollBack() has
// no transaction left to unwind and PDO throws again — turning a reportable 500 into a
// fatal with an empty body and masking the original error.
function safeRollback(PDO $db): void {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
}

// Who actually sent this request. A tunnel (ngrok) or a local reverse proxy always
// connects from loopback, so an X-Forwarded-For arriving over loopback is that proxy's
// word for the real client and can be believed. From anywhere else the header is
// client-supplied, and trusting it unconditionally would let anyone pick the address
// their failed logins are counted against - resetting a lockout or framing a neighbour.
// Without this, a till reached through a tunnel records every remote visitor as the
// proxy, so one stranger's wrong PIN locks out the owner and the audit trail cannot
// tell the two apart.
function clientIp(): string {
    $direct = trim((string)($_SERVER['REMOTE_ADDR'] ?? ''));
    if ($direct === '') $direct = '127.0.0.1';

    $fromLoopback = filter_var($direct, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)
        ? (strpos($direct, '127.') === 0)
        : in_array(strtolower($direct), ['::1', '0:0:0:0:0:0:0:1'], true);

    if ($fromLoopback && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        // Only the left-most address is the original client; each further hop is
        // appended by a proxy this server has no way to verify.
        $forwarded = trim(explode(',', (string)$_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
        if (filter_var($forwarded, FILTER_VALIDATE_IP)) return $forwarded;
    }

    return $direct;
}

function logActivity(PDO $db, $userId, $userName, $roleName, string $actionType, string $details) {
    try {
        $id = 'act_' . bin2hex(random_bytes(6));
        $ip = clientIp();
        $now = date('Y-m-d H:i:s');
        $stmt = $db->prepare("INSERT INTO activity_logs (id, user_id, user_name, role_name, action_type, details, ip_address, created_at)
                             VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$id, $userId ?: 1, $userName ?: 'Staff', $roleName ?: 'Staff', $actionType, $details, $ip, $now]);
    } catch (Exception $e) {
        // Silently prevent log errors from failing primary operations
    }
}

function triggerAutoBackupIfDue(PDO $db, string $dbPath, string $backupDir) {
    try {
        $intervalHours = 2;
        $profStmt = $db->query("SELECT auto_backup_hours FROM store_profile WHERE id = 1");
        if ($prof = $profStmt->fetch()) {
            $intervalHours = max(1, intval($prof['auto_backup_hours'] ?? 2));
        }
        $intervalSeconds = $intervalHours * 3600;

        // What this reads is "when was a copy of THIS book last taken", not "when did the
        // scheduler last run". A snapshot the owner pressed by hand, the copy a restore saves
        // first and the copy a reset saves first are each a file on this disk the shop could be
        // put back from, which is the thing the interval exists to guarantee. Without that, a
        // reset - which clears the rolling copies and their rows - had the scheduler writing a
        // brand new one on the next request, in the same second, and the folder the owner was
        // promised empty was not. Files that arrived from somebody else's shop (an uploaded .db,
        // a decrypted .sfbak) are deliberately not counted: they are another shop's books.
        $stmt = $db->query("SELECT created_at FROM backups WHERE backup_type IN
                                ('AUTOMATIC_2HR', 'MANUAL', 'PRE_RESTORE_SAFETY', 'SAFETY', 'PRE_RESET_SAFETY')
                            ORDER BY id DESC LIMIT 1");
        $lastBackup = $stmt->fetch();

        $shouldBackup = false;
        if (!$lastBackup) {
            $shouldBackup = true;
        } else {
            $lastTime = strtotime($lastBackup['created_at']);
            $currentTime = time();
            if ($lastTime && ($currentTime - $lastTime) >= $intervalSeconds) {
                $shouldBackup = true;
            }
        }

        if ($shouldBackup) {
            performDatabaseBackup($db, $dbPath, $backupDir, 'AUTOMATIC_2HR');
            cleanOldBackups($db, $backupDir, 7);
            pruneOldLogs($db, 180);
        }
    } catch (Exception $e) {
        error_log("Auto-backup check error: " . $e->getMessage());
    }
}

function performDatabaseBackup(PDO $db, string $dbPath, string $backupDir, string $type = 'MANUAL'): array {
    $timestamp = date('Y-m-d_H-i-s');
    $filename = "store_backup_{$timestamp}.db";
    $targetPath = $backupDir . DIRECTORY_SEPARATOR . $filename;
    // Two snapshots inside one second is ordinary behaviour: an owner presses "Create
    // Snapshot" and then "Restore" before the clock moves. VACUUM INTO refuses a path
    // that exists and the copy fallback below overwrites one without asking, so a unique
    // name is what stops the pre-restore safety copy from landing on top of the very
    // snapshot being restored - which would make the restore re-apply the state it was
    // meant to undo and report that it had worked.
    for ($suffix = 2; file_exists($targetPath) && $suffix < 100; $suffix++) {
        $filename = "store_backup_{$timestamp}_{$suffix}.db";
        $targetPath = $backupDir . DIRECTORY_SEPARATOR . $filename;
    }

    try {
        $stmt = $db->prepare("VACUUM INTO ?");
        $stmt->execute([$targetPath]);
    } catch (Exception $e) {
        copy($dbPath, $targetPath);
    }

    $fileSize = file_exists($targetPath) ? filesize($targetPath) : 0;
    $now = date('Y-m-d H:i:s');

    $stmt = $db->prepare("INSERT INTO backups (filename, filepath, file_size_bytes, backup_type, created_at) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$filename, $targetPath, $fileSize, $type, $now]);

    return [
        'success' => true,
        'filename' => $filename,
        'filepath' => $targetPath,
        'size' => $fileSize,
        'created_at' => $now,
        'type' => $type
    ];
}

function cleanOldBackups(PDO $db, string $backupDir, int $daysToKeep = 7) {
    try {
        $cutoffDate = date('Y-m-d H:i:s', strtotime("-{$daysToKeep} days"));
        $stmt = $db->prepare("SELECT id, filepath FROM backups WHERE backup_type = 'AUTOMATIC_2HR' AND created_at < ?");
        $stmt->execute([$cutoffDate]);
        $oldBackups = $stmt->fetchAll();

        foreach ($oldBackups as $backup) {
            if (file_exists($backup['filepath'])) {
                @unlink($backup['filepath']);
            }
            $delStmt = $db->prepare("DELETE FROM backups WHERE id = ?");
            $delStmt->execute([$backup['id']]);
        }
    } catch (Exception $e) {
        error_log("Failed to clean old backups: " . $e->getMessage());
    }
}

function pruneOldLogs(PDO $db, int $daysToKeep = 180) {
    try {
        $cutoffDate = date('Y-m-d H:i:s', strtotime("-{$daysToKeep} days"));
        
        // Prune activity_logs older than retention period
        $stmt = $db->prepare("DELETE FROM activity_logs WHERE created_at < ?");
        $stmt->execute([$cutoffDate]);
        
        // Prune sync_log older than retention period
        $stmt = $db->prepare("DELETE FROM sync_log WHERE created_at < ?");
        $stmt->execute([$cutoffDate]);
        
        // Prune terminal scan buffer older than 24 hours.
        // The table is created by the scanner bridge on its first request, so an
        // install that has never scanned has no such table: the delete then threw,
        // was swallowed here, and wrote a warning into the customer's error log on
        // every call. Ask first - a missing optional table is not a failure.
        $hasScanBuffer = $db->query("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'terminal_scan_buffer'")->fetchColumn();
        if ($hasScanBuffer) {
            $db->exec("DELETE FROM terminal_scan_buffer WHERE created_at < datetime('now', '-1 day')");
        }
    } catch (Exception $e) {
        error_log("Failed to prune old logs: " . $e->getMessage());
    }
}

function jsonResponse($data, int $statusCode = 200) {
    http_response_code($statusCode);
    echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    exit;
}

function getDB(): PDO {
    global $db;
    return $db;
}

function getJsonInput(): array {
    if (isset($GLOBALS['__TEST_JSON_INPUT__'])) {
        return is_array($GLOBALS['__TEST_JSON_INPUT__']) ? $GLOBALS['__TEST_JSON_INPUT__'] : [];
    }
    $raw = file_get_contents('php://input');
    if (empty($raw)) {
        return [];
    }
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

// ── Licensing choke point ─────────────────────────────────────────────────────
// Until now the scope returned by system.php was only ever read by the browser,
// which hid the UI on an unlicensed terminal while every endpoint happily kept
// serving and writing. Skipping activation was then a matter of not loading the
// JavaScript. The paywall screen still needs system.php, so that endpoint stays
// reachable and everything else stops until a key is applied.
// The decision is separated from the refusal so it can be tested without a web SAPI:
// 'ok' licences the request, 'locked' is the paywall, and 'unreadable' means StoreFlow
// could not establish either and must not serve data.
function storeflowLicenceVerdict(PDO $db): string {
    require_once __DIR__ . '/sys_integrity.php';

    // A failed scope read used to `return`, which licensed everything: throwing is
    // as easy as making _app_meta unreadable, and the paywall was one SQLITE_BUSY
    // away from being switched off. It now retries, then refuses.
    $lastError = null;
    for ($attempt = 0; $attempt < 3; $attempt++) {
        try {
            _sysEnsureMeta($db);
            $scope = _sysGetScope($db);
            $lastError = null;
            break;
        } catch (Throwable $e) {
            $lastError = $e;
            error_log('StoreFlow: licence scope read failed (attempt ' . ($attempt + 1) . '): ' . $e->getMessage());
            usleep(250000);
        }
    }

    if ($lastError !== null) return 'unreadable';
    return (($scope['scope'] ?? 'LOCKED') === 'LOCKED') ? 'locked' : 'ok';
}

function storeflowLicenseGate(PDO $db): void {
    if (PHP_SAPI === 'cli') return;
    $script = strtolower(basename($_SERVER['SCRIPT_NAME'] ?? ''));
    if ($script === 'system.php') return;

    $verdict = storeflowLicenceVerdict($db);

    if ($verdict === 'unreadable') {
        // Worded so a paying customer is not told to buy a key they already have.
        jsonResponse([
            'success'  => false,
            'licensed' => false,
            'message'  => 'StoreFlow could not read its licence record on this terminal. Your activation is intact - restart StoreFlow, and if it persists send this message to support.',
        ], 503);
    }

    if ($verdict === 'locked') {
        jsonResponse([
            'success'  => false,
            'licensed' => false,
            'message'  => 'StoreFlow is not activated on this terminal. Enter an activation key to continue.',
        ], 402);
    }
}
storeflowLicenseGate($db);
