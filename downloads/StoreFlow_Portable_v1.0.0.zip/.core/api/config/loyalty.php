<?php
// api/config/loyalty.php
// Customer Loyalty Points, Tiers & Redemption for StoreFlow.
//
// The shop decides the policy; the server applies it. Every figure here - what a cedi earns,
// what a point is worth back, whether points may be handed in at the counter, whether a tier's
// perk is applied - is read from store_profile, so an owner running a festive gift scheme and an
// owner who only wants a spend-and-earn card get the product they configured.
//
// What the till gets to decide is narrower: which member is standing there and how many points
// they would like to hand over. The money those points are worth is computed here, from the
// shop's own rate, against the shop's own balance. That distinction is the whole file: a browser
// that multiplies points by a rate it hard-coded used to cut the bill by GH₵5.00 while the book
// recorded a discount the cashier typed, and an offline receipt could cut the price and burn no
// points at all.

if (!defined('STOREFLOW_LOYALTY_LOADED')) {
    define('STOREFLOW_LOYALTY_LOADED', true);

    class StoreFlowLoyalty {
        public const TIER_BRONZE   = 'BRONZE';
        public const TIER_SILVER   = 'SILVER';
        public const TIER_GOLD     = 'GOLD';
        public const TIER_PLATINUM = 'PLATINUM';

        // What a shop that has never opened the settings screen behaves like. These are the
        // numbers every copy of StoreFlow has silently used, so switching the feature into
        // settings changes nothing until somebody moves a figure.
        public const DEFAULT_POINTS_PER_CURRENCY = 1.0;
        public const DEFAULT_REDEMPTION_RATE     = 0.01;

        public static function calculateTier(float $points): string {
            if ($points >= 5000) return self::TIER_PLATINUM;
            if ($points >= 2000) return self::TIER_GOLD;
            if ($points >= 500)  return self::TIER_SILVER;
            return self::TIER_BRONZE;
        }

        public static function getTierDiscount(string $tier): float {
            return match (strtoupper($tier)) {
                self::TIER_PLATINUM => 0.15,
                self::TIER_GOLD     => 0.10,
                self::TIER_SILVER   => 0.05,
                default             => 0.00,
            };
        }

        public static function calculatePointsEarned(float $amount, float $rate = 1.0): float {
            if ($amount <= 0) return 0.0;
            return round($amount * $rate, 2);
        }

        public static function pointsToCurrency(float $points, float $redemptionRate = 0.01): float {
            return round($points * $redemptionRate, 2);
        }

        /**
         * The shop's loyalty policy, as it stands on the book right now.
         *
         * Read from store_profile rather than passed in by the caller, because the doors that
         * need it are the counter, the queued sync and the customers page, and three callers
         * reading three copies of the rule is how a shop ends up paying points out twice.
         *
         * $fresh is for a caller that has just written the settings in the same process and must
         * price the next receipt off the new rule, not off the copy held in the cache.
         */
        public static function settings(PDO $db, bool $fresh = false): array {
            static $cache = null;
            if ($cache !== null && !$fresh) return $cache;
            $row = false;
            try {
                $row = $db->query("SELECT * FROM store_profile WHERE id = 1")->fetch();
            } catch (\Throwable $e) {
                $row = false;
            }
            $row = is_array($row) ? $row : [];
            $flag = function (string $key, int $fallback) use ($row): int {
                if (!array_key_exists($key, $row) || $row[$key] === null || $row[$key] === '') return $fallback;
                return intval($row[$key]) === 1 ? 1 : 0;
            };
            $rate = function (string $key, float $fallback) use ($row): float {
                if (!array_key_exists($key, $row) || $row[$key] === null || $row[$key] === '') return $fallback;
                $v = floatval($row[$key]);
                return $v >= 0 ? round($v, 4) : $fallback;
            };
            $cache = [
                'enabled'           => $flag('loyalty_enabled', 1),
                'points_per_unit'   => $rate('loyalty_points_per_currency', self::DEFAULT_POINTS_PER_CURRENCY),
                'redemption_rate'   => $rate('loyalty_redemption_rate', self::DEFAULT_REDEMPTION_RATE),
                'redeem_at_counter' => $flag('loyalty_redeem_at_counter', 1),
                'tier_perks'        => $flag('loyalty_tier_perks', 0),
            ];
            return $cache;
        }

        public static function emptyResult(): array {
            return [
                'earned' => 0.0, 'redeemed' => 0.0,
                'loyalty_value' => 0.0, 'tier_value' => 0.0, 'tier' => self::TIER_BRONZE,
                'points_balance' => 0.0, 'refused' => null, 'note' => null,
            ];
        }

        /**
         * Decide what a receipt does to a member's points, and what it is worth in money.
         *
         * Called with the goods value before any tax, because tax is not the shop's money: points
         * may buy off what the shop keeps, never off what the shop owes the revenue authority.
         * Writes the customer's balance and one ledger line per movement, and returns the two
         * figures the caller must subtract from the bill - the till does not get to keep its own
         * arithmetic.
         *
         * $saleId must be the id the receipt will be stored under, so a receipt replayed from an
         * offline queue finds its own ledger rows and pays out nothing a second time.
         */
        public static function authorSaleLoyalty(
            PDO $db,
            string $customerId,
            float $subtotal,
            float $cashierDiscount,
            float $claimedRedeemed,
            ?string $saleId,
            int $userId = 0,
            string $branchCode = 'MAIN-01'
        ): array {
            $settings = self::settings($db);

            if ($customerId === '' || $customerId === 'cust-walkin' || $customerId === 'walkin') {
                $r = self::emptyResult();
                if ($claimedRedeemed > 0) {
                    $r['refused'] = 'A walk-in has no points to hand in. Ring the receipt without the redemption, or put the customer on the book first.';
                }
                return $r;
            }

            $stmt = $db->prepare("SELECT loyalty_points, loyalty_tier FROM customers WHERE id = ?");
            $stmt->execute([$customerId]);
            $cust = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$cust) {
                $r = self::emptyResult();
                if ($claimedRedeemed > 0) {
                    $r['refused'] = "No member named '{$customerId}' is on the book, so the points claimed on this receipt cannot be checked.";
                }
                return $r;
            }

            $balance = round(floatval($cust['loyalty_points'] ?? 0.0), 2);
            // The perk is the status the member had already earned. A sale that would push them
            // into GOLD does not pay its own discount - otherwise one receipt could discount
            // itself and then promote itself.
            $standingTier = strtoupper((string)($cust['loyalty_tier'] ?? self::TIER_BRONZE)) ?: self::TIER_BRONZE;

            // Already accounted for? Both doors refuse a receipt that is on the book before they
            // reach here, so this is the author's own idempotence rather than a caller's: it
            // travels with the engine to the next door that writes points, and it is what keeps
            // the (sale_id, reason) index from throwing when a receipt is filed twice.
            if ($saleId !== null && $saleId !== '') {
                $seen = self::bookedForSale($db, $saleId);
                if ($seen !== null) {
                    return $seen + ['note' => 'already recorded'];
                }
            }

            $goodsValue = round(max(0.0, $subtotal - max(0.0, $cashierDiscount)), 2);
            $out = self::emptyResult();
            $out['tier'] = $standingTier;
            $out['points_balance'] = $balance;

            // 1. The tier perk, when the shop switched it on. Server-computed from the member's
            //    standing, so a cashier cannot invent a 15% by naming a customer.
            if ($settings['tier_perks'] === 1 && $settings['enabled'] === 1) {
                $pct = self::getTierDiscount($standingTier);
                if ($pct > 0 && $goodsValue > 0) {
                    $out['tier_value'] = round($goodsValue * $pct, 2);
                }
            }

            // 2. Points handed in. Only worth what the receipt still has left to pay, and only
            //    ever as many as the member actually holds.
            $claimed = round(max(0.0, $claimedRedeemed), 2);
            if ($claimed > 0) {
                if ($settings['enabled'] !== 1 || $settings['redeem_at_counter'] !== 1) {
                    $why = $settings['enabled'] !== 1
                        ? 'This shop has switched the loyalty scheme off'
                        : 'This shop does not let points be handed in at the counter';
                    $out['refused'] = $why . ', so the ' . $claimed . ' points claimed on this receipt were not taken. '
                        . 'Nothing was discounted for them either - ring it without the redemption, or change the setting in Settings > Loyalty.';
                } else {
                    $affordable = round(max(0.0, $goodsValue - $out['tier_value']), 2);
                    $rate = $settings['redemption_rate'];
                    if ($rate <= 0) {
                        $out['refused'] = 'The shop has set a point to be worth GH₵0.00, so no points can be exchanged for money. Set a redemption rate in Settings > Loyalty.';
                    } else {
                        $byMoney = round($affordable / $rate, 2);
                        $redeemed = round(min($claimed, $balance, $byMoney), 2);
                        $value = round($redeemed * $rate, 2);
                        if ($value > $affordable) $value = $affordable;
                        $out['redeemed'] = $redeemed;
                        $out['loyalty_value'] = $value;
                        if ($redeemed < $claimed) {
                            $short = round($claimed - $redeemed, 2);
                            $out['note'] = $short > 0
                                ? sprintf('%s of the %s points claimed could not be used on this receipt (balance %s, and points cover at most GH₵%s of the GH₵%s still payable).',
                                    number_format($short, 2), number_format($claimed, 2), number_format($balance, 2),
                                    number_format($affordable, 2), number_format($goodsValue, 2))
                                : null;
                        }
                    }
                }
            }

            // 3. What the member earns. The base is what the shop actually took for the goods -
            //    after the cashier's discount, the perk and the points - so nobody earns points on
            //    money that was waived, and nobody earns points on tax.
            if ($settings['enabled'] === 1) {
                $earnedBase = round(max(0.0, $goodsValue - $out['loyalty_value'] - $out['tier_value']), 2);
                $out['earned'] = self::calculatePointsEarned($earnedBase, $settings['points_per_unit']);
            }

            $newBalance = round($balance - $out['redeemed'] + $out['earned'], 2);
            $newTier = self::calculateTier($newBalance);

            if ($saleId !== null && $saleId !== '' && ($out['redeemed'] > 0 || $out['earned'] > 0)) {
                $upd = $db->prepare("UPDATE customers SET loyalty_points = ?, loyalty_tier = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
                $upd->execute([$newBalance, $newTier, $customerId]);
                if ($out['redeemed'] > 0) {
                    self::writeLedger($db, $customerId, $saleId, -$out['redeemed'],
                        round($balance - $out['redeemed'], 2), 'REDEEMED', $out['loyalty_value'], $userId, $branchCode,
                        'Handed in at the counter');
                }
                if ($out['earned'] > 0) {
                    self::writeLedger($db, $customerId, $saleId, $out['earned'], $newBalance, 'EARNED',
                        0.0, $userId, $branchCode, 'Earned on this receipt');
                }
            }

            $out['tier'] = $newTier;
            $out['points_balance'] = $saleId !== null && $saleId !== '' ? $newBalance : $balance;
            return $out;
        }

        /**
         * The points a receipt moved, moved back, when that receipt is cleared as a void.
         *
         * A void puts the goods on the shelf and the money out of the day's takings, and the points
         * the bill paid out have to follow it: a member who earned 20 points on a GH₵200.00 bill
         * that never happened would otherwise keep redeeming them against real money. Points handed
         * in on that bill go back too, because the member gave them up for a discount that no longer
         * stands.
         *
         * The original EARNED and REDEEMED lines stay on the ledger - a points statement that loses
         * its rows cannot be read beside the paper the customer held - and one reversing line is
         * written in their place, the same way the shelf ledger answers a void.
         *
         * A member who has already spent the points is not left owing the shop: the clawback stops
         * at zero and the shortfall is said out loud, because the shop's books stay honest either
         * way and the till needs to know whose balance was trimmed.
         *
         * @return array{reversed: bool, clawed_back: float, handed_back: float, short: float, balance: float, tier: string}
         */
        public static function reverseSaleLoyalty(PDO $db, string $saleId, int $userId, string $branchCode = 'MAIN-01'): array {
            $nil = ['reversed' => false, 'clawed_back' => 0.0, 'handed_back' => 0.0, 'short' => 0.0, 'balance' => 0.0, 'tier' => ''];
            if ($saleId === '') return $nil;

            $booked = self::bookedForSale($db, $saleId);
            if ($booked === null) return $nil;
            $earned = round(floatval($booked['earned'] ?? 0), 2);
            $redeemed = round(floatval($booked['redeemed'] ?? 0), 2);
            if ($earned <= 0.005 && $redeemed <= 0.005) return $nil;

            $who = $db->prepare("SELECT customer_id FROM sales WHERE id = ?");
            $who->execute([$saleId]);
            $customerId = trim((string)$who->fetchColumn());
            if ($customerId === '' || $customerId === 'cust-walkin' || $customerId === 'walkin') return $nil;

            // One clearing per receipt. The void's own stamp lets only one counter through, so this
            // is the guard for whatever door writes points next.
            $already = $db->prepare("SELECT 1 FROM loyalty_ledger WHERE sale_id = ? AND reason = 'VOIDED' LIMIT 1");
            $already->execute([$saleId]);
            if ($already->fetchColumn()) {
                $c = $db->prepare("SELECT loyalty_points, loyalty_tier FROM customers WHERE id = ?");
                $c->execute([$customerId]);
                $seen = $c->fetch(PDO::FETCH_ASSOC) ?: [];
                return $nil + ['balance' => round(floatval($seen['loyalty_points'] ?? 0), 2), 'tier' => (string)($seen['loyalty_tier'] ?? '')];
            }

            $c = $db->prepare("SELECT loyalty_points, loyalty_tier FROM customers WHERE id = ?");
            $c->execute([$customerId]);
            $cust = $c->fetch(PDO::FETCH_ASSOC);
            if (!$cust) return $nil;
            $from = round(floatval($cust['loyalty_points'] ?? 0.0), 2);

            $to = round($from - $earned + $redeemed, 2);
            $short = 0.0;
            if ($to < 0) {
                $short = round(-$to, 2);
                $to = 0.0;
            }

            $tier = self::calculateTier($to);
            $db->prepare("UPDATE customers SET loyalty_points = ?, loyalty_tier = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?")
                ->execute([$to, $tier, $customerId]);

            $words = [];
            if ($earned > 0.005) $words[] = $earned . ' point(s) the receipt had earned taken back';
            if ($redeemed > 0.005) $words[] = $redeemed . ' point(s) handed in on it given back';
            if ($short > 0.005) $words[] = number_format($short, 2) . ' of the clawback could not be taken because the member had already spent them';
            self::writeLedger($db, $customerId, $saleId, round($to - $from, 2), $to, 'VOIDED', 0.0, $userId, $branchCode,
                'Receipt cleared as a void: ' . implode(', ', $words) . '.');

            return ['reversed' => true, 'clawed_back' => $earned, 'handed_back' => $redeemed, 'short' => $short, 'balance' => $to, 'tier' => $tier];
        }

        /**
         * The points a receipt paid out, answered by a credit note - in the share the note took back.
         *
         * A void clears a bill that was keyed wrong, and its points follow the whole bill. A return
         * keeps the bill and gives part of it back, so the points follow the same fraction: a member
         * who earned 200 points on a GH₵200.00 receipt and returns GH₵50.00 of goods off it keeps
         * the points on the GH₵150.00 the shop still holds their money for, and gives back 50.
         *
         * The points the member handed *in* come back on the same share, and that half is not
         * generosity - the refund is worked out of the receipt's gross line value and its typed
         * discount (see saleRefundSplit), so the loyalty discount off the original bill is never
         * paid back in cash. A member who handed in 500 points for GH₵5.00 off and returns the
         * whole basket would otherwise lose the goods, the points, and the GH₵5.00 those points
         * bought: a scheme that charges the member for returning is a scheme they will read as a
         * rip-off, and the shop's own returns book is the only place that can say otherwise.
         *
         * Written as a catch-up rather than as one guess per slip, which is what makes it hold: the
         * share is read off the shop's own refunded_amount, what has already moved is read off this
         * receipt's own RETURNED lines, and the difference is what the balance is trimmed by. Three
         * notes of a third each then come to the whole of the points without a pesewa of rounding
         * stranding a tenth point on the balance; a queue replayed a day later cannot pay the
         * reversal twice; and a posted note deleted as a mistake lifts the share back down, so the
         * points taken for it go back to the member rather than staying gone.
         *
         * A member who has already spent the points is not left owing the shop: the clawback stops
         * at zero and the shortfall is said on the line. The line records what actually moved, not
         * what the share asked for, because a shortfall written as though it had landed would tell
         * the next credit note the balance was already trimmed - and the points it then took would
         * come off whatever the member had earned since.
         *
         * @return array{reversed: bool, share: float, change: float, taken: float, handed_back: float, short: float, balance: float, tier: string}
         */
        public static function reverseLoyaltyForReturns(PDO $db, string $saleId, int $userId, string $branchCode = 'MAIN-01'): array {
            $nil = ['reversed' => false, 'share' => 0.0, 'change' => 0.0, 'taken' => 0.0,
                    'handed_back' => 0.0, 'short' => 0.0, 'balance' => 0.0, 'tier' => ''];
            if ($saleId === '') return $nil;

            $stmt = $db->prepare("SELECT customer_id, total_amount, refunded_amount, status FROM sales WHERE id = ?");
            $stmt->execute([$saleId]);
            $sale = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
            $customerId = trim((string)($sale['customer_id'] ?? ''));
            if ($customerId === '' || $customerId === 'cust-walkin' || $customerId === 'walkin') return $nil;
            // A cleared bill has already answered its own points, in full, at the void.
            if (strtoupper(trim((string)($sale['status'] ?? ''))) === 'VOID') return $nil;

            $booked = self::bookedForSale($db, $saleId);
            if ($booked === null) return $nil;
            $earned = round(floatval($booked['earned'] ?? 0), 2);
            $redeemed = round(floatval($booked['redeemed'] ?? 0), 2);
            if ($earned <= 0.005 && $redeemed <= 0.005) return $nil;

            // How far this receipt has been handed back, as the shop's own book says. One cent of
            // residue is the receipt read as whole: the split settles the last note on the exact
            // remainder, so a share of 0.99998 would strand a point on the balance forever.
            $total = round(floatval($sale['total_amount'] ?? 0), 2);
            if ($total <= 0.005) return $nil;
            $refunded = round(max(0.0, floatval($sale['refunded_amount'] ?? 0)), 2);
            $share = $refunded >= $total - 0.01 ? 1.0 : round($refunded / $total, 6);

            $taken = round(min($earned * $share, $earned), 2);
            $handed = round(min($redeemed * $share, $redeemed), 2);
            $target = round($handed - $taken, 2);

            $movedStmt = $db->prepare("SELECT COALESCE(SUM(points_change), 0) FROM loyalty_ledger
                                       WHERE sale_id = ? AND reason = 'RETURNED'");
            $movedStmt->execute([$saleId]);
            $moved = round(floatval($movedStmt->fetchColumn()), 2);
            $delta = round($target - $moved, 2);

            // The share the lines already booked answered, carried on each line's money_value. The
            // balance rising is not enough to say a note was withdrawn: a note that hands back more
            // points than the receipt earned raises the balance too, and the two need saying
            // differently - one is the shop correcting itself, the other is the scheme working.
            // Read off the book rather than taken from the caller because a queue replayed a day
            // later reaches this method with no caller left to ask.
            $shareStmt = $db->prepare("SELECT COALESCE(MAX(money_value), -1) FROM loyalty_ledger
                                       WHERE sale_id = ? AND reason = 'RETURNED'");
            $shareStmt->execute([$saleId]);
            $answeredShare = floatval($shareStmt->fetchColumn());

            // Every key written on the right: array union keeps the LEFT operand's value for a shared
            // key, so reading $nil first would have answered every question below with the zero it
            // started life as - the balance the clawback is computed from above all others.
            $read = function () use ($db, $customerId, $share, $taken, $handed): array {
                $c = $db->prepare("SELECT loyalty_points, loyalty_tier FROM customers WHERE id = ?");
                $c->execute([$customerId]);
                $row = $c->fetch(PDO::FETCH_ASSOC) ?: [];
                return ['reversed' => true, 'share' => $share, 'change' => 0.0,
                        'taken' => $taken, 'handed_back' => $handed, 'short' => 0.0,
                        'balance' => round(floatval($row['loyalty_points'] ?? 0), 2),
                        'tier' => (string)($row['loyalty_tier'] ?? '')];
            };
            if (abs($delta) < 0.005) return $read();

            $from = $read()['balance'];
            $to = round($from + $delta, 2);
            $short = 0.0;
            if ($to < 0) {
                $short = round(-$to, 2);
                $to = 0.0;
            }
            $applied = round($to - $from, 2);
            // A clawback the balance could not meet is still written, at zero movement, exactly as
            // the void path writes its own: the line is where "why does this member still hold 200
            // points when that basket came back" gets answered, and a silent skip is how a disputed
            // balance ends up with nothing in the book to read against it.
            if (abs($applied) < 0.005 && $short <= 0.005) return $read();

            $tier = self::calculateTier($to);
            $db->prepare("UPDATE customers SET loyalty_points = ?, loyalty_tier = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?")
                ->execute([$to, $tier, $customerId]);

            $slips = [];
            $s = $db->prepare("SELECT return_number FROM sales_returns WHERE sale_id = ? ORDER BY created_at, return_number");
            $s->execute([$saleId]);
            foreach ($s->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $slips[] = (string)$row['return_number'];
            }
            $pct = rtrim(rtrim(number_format($share * 100, 2, '.', ''), '0'), '.');

            if ($delta > 0.005 && $share < $answeredShare - 0.0000005) {
                // The share fell, so a note came off the book. Name the notes that still stand,
                // because the line has to say why the member is suddenly richer.
                $note = 'A credit note on this receipt has been withdrawn'
                    . ($slips === [] ? '' : ', leaving ' . implode(', ', array_slice($slips, 0, 3))
                        . (count($slips) > 3 ? ' and ' . (count($slips) - 3) . ' more' : ''))
                    . ', so ' . $pct . '% of it stands given back: '
                    . abs($applied) . ' point(s) trimmed for it earlier are handed back.';
            } else {
                $words = [];
                if ($taken > 0.005) {
                    $words[] = $taken . ' of the ' . $earned . ' point(s) this receipt earned are taken back';
                }
                if ($handed > 0.005) {
                    $words[] = $handed . ' of the ' . $redeemed . ' point(s) handed in on it are given back';
                }
                if ($short > 0.005) {
                    $words[] = number_format($short, 2) . ' of the clawback could not be taken because the member had already spent them';
                }
                $note = 'Goods returned against this receipt ('
                    . ($slips === [] ? 'no note left on the book' : implode(', ', array_slice($slips, 0, 3))
                        . (count($slips) > 3 ? ' and ' . (count($slips) - 3) . ' more' : ''))
                    . '), ' . $pct . '% of it given back: ' . implode(', ', $words) . '.';
            }
            self::writeLedger($db, $customerId, $saleId, $applied, $to, 'RETURNED', $share, $userId, $branchCode,
                $note . ' Balance ' . number_format($to, 2) . '.');

            return ['reversed' => true, 'share' => $share, 'change' => $applied, 'taken' => $taken,
                    'handed_back' => $handed, 'short' => $short, 'balance' => $to, 'tier' => $tier];
        }

        /**
         * A gift, a correction, or the points a shop promised at a festive promotion.
         * The only way points move that is not tied to a receipt, so it is the only one that
         * takes a note the ledger keeps: "who gave these, and why" is the first thing a disputed
         * balance is asked.
         */
        public static function adjust(
            PDO $db,
            string $customerId,
            float $points,
            string $note,
            int $userId,
            string $branchCode = 'MAIN-01'
        ): array {
            $stmt = $db->prepare("SELECT loyalty_points FROM customers WHERE id = ?");
            $stmt->execute([$customerId]);
            $current = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$current) return ['success' => false, 'message' => 'No such member on the book.'];

            $change = round($points, 2);
            if (abs($change) < 0.005) return ['success' => false, 'message' => 'Say how many points to add or take off.'];
            $from = round(floatval($current['loyalty_points'] ?? 0.0), 2);
            $to = round($from + $change, 2);
            if ($to < 0) {
                return ['success' => false, 'message' => sprintf(
                    '%s holds %s points, so %s cannot be taken off without leaving a negative balance. Give a smaller amount.',
                    $customerId, number_format($from, 2), number_format($change, 2))];
            }

            $tier = self::calculateTier($to);
            $upd = $db->prepare("UPDATE customers SET loyalty_points = ?, loyalty_tier = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
            $upd->execute([$to, $tier, $customerId]);
            self::writeLedger($db, $customerId, null, $change, $to, 'ADJUSTED', 0.0, $userId, $branchCode, $note);

            return ['success' => true, 'points_balance' => $to, 'tier' => $tier, 'change' => $change];
        }

        public static function writeLedger(
            PDO $db, string $customerId, ?string $saleId, float $pointsChange, float $balanceAfter,
            string $reason, float $moneyValue, int $userId, string $branchCode, string $note = ''
        ): void {
            $ins = $db->prepare("INSERT INTO loyalty_ledger
                (id, customer_id, sale_id, points_change, money_value, balance_after, reason, note, branch_code, created_by, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))");
            $ins->execute([
                'lyl_' . bin2hex(random_bytes(8)), $customerId,
                ($saleId !== null && $saleId !== '') ? $saleId : null,
                $pointsChange, $moneyValue, $balanceAfter, $reason, $note, $branchCode,
                $userId > 0 ? $userId : null,
            ]);
        }

        /**
         * The figures already booked for a receipt, so a receipt replayed from an offline queue
         * or a double-clicked till reports what the shop agreed to instead of paying again.
         *
         * The points ledger is the movement record and is written in the same transaction as the
         * receipt, so it is what proves the receipt was accounted for. The receipt row is read on
         * top of it because it also holds the tier perk, which is a discount and not a points
         * movement - a replay priced off the ledger alone would drop the perk and hand back a
         * bill different from the one the customer was given.
         */
        public static function bookedForSale(PDO $db, string $saleId): ?array {
            $stmt = $db->prepare("SELECT reason, points_change, money_value FROM loyalty_ledger WHERE sale_id = ?");
            $stmt->execute([$saleId]);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            if (!$rows) return null;

            $out = self::emptyResult();
            foreach ($rows as $row) {
                $change = abs(floatval($row['points_change']));
                if ($row['reason'] === 'EARNED') $out['earned'] = round($change, 2);
                if ($row['reason'] === 'REDEEMED') {
                    $out['redeemed'] = round($change, 2);
                    $out['loyalty_value'] = round(floatval($row['money_value']), 2);
                }
            }

            $sale = $db->prepare("SELECT customer_id, tier_discount FROM sales WHERE id = ?");
            $sale->execute([$saleId]);
            $row = $sale->fetch(PDO::FETCH_ASSOC);
            if ($row) {
                $out['tier_value'] = round(floatval($row['tier_discount'] ?? 0), 2);
                $cid = (string)($row['customer_id'] ?? '');
            } else {
                $who = $db->prepare("SELECT customer_id FROM loyalty_ledger WHERE sale_id = ? LIMIT 1");
                $who->execute([$saleId]);
                $cid = (string)$who->fetchColumn();
            }
            if ($cid !== '') {
                $c = $db->prepare("SELECT loyalty_points, loyalty_tier FROM customers WHERE id = ?");
                $c->execute([$cid]);
                $cust = $c->fetch(PDO::FETCH_ASSOC);
                if ($cust) {
                    $out['tier'] = strtoupper((string)($cust['loyalty_tier'] ?? '')) ?: $out['tier'];
                    $out['points_balance'] = round(floatval($cust['loyalty_points'] ?? 0), 2);
                }
            }
            return $out;
        }
    }
}
