<?php
// api/config/product_units.php
//
// The sellable sizes of a product: one base unit plus any number of larger ones, each
// expressed as a multiple of the base. A shop that sells an egg, a crate of 30 and a box
// of 14 crates stores 1, 30 and 420 - the chain is data, so nothing here recurses.
//
// This file exists because three callers need identical answers and they must not
// disagree: the catalogue form, the till settling a sale, and sync replaying a sale that
// was made while the network was down. A multiplier that means 30 at one of those three
// and 1 at another is a shop's stock count, so there is one implementation.

/**
 * Turn whatever the client sent into rows we are willing to write, or say why not.
 *
 * $baseUnitName is products.unit - the base row is not a choice the client makes, it is
 * the product itself, so its name and its size are taken from here and its price is left
 * NULL to mean "products.selling_price", which keeps one price per unit per product.
 *
 * $looseCode is products.barcode. A size that answers to the same number is not a second
 * name for the product, it is a second price for it, so the loose code joins the ledger
 * the sizes are checked against.
 *
 * @return array{error: ?string, rows: array<int, array<string, mixed>>}
 */
function sfUnitsNormalize(?array $rawUnits, string $baseUnitName, string $looseCode = ''): array
{
    $base = trim($baseUnitName) !== '' ? trim($baseUnitName) : 'pcs';
    // The loose unit used to be a dropdown, so nothing ever bounded it. It is typed now,
    // and it turns up on every card, pill and receipt line in the shop.
    if (mb_strlen($base) > 40) {
        return ['error' => 'The base unit name is too long', 'rows' => []];
    }
    $rows = [[
        'unit_name'     => $base,
        'size_in_base'  => 1.0,
        'selling_price' => null,
        'barcode'       => '',
        'is_base'       => 1,
        'sort_order'    => 0,
    ]];

    if ($rawUnits === null) {
        return ['error' => null, 'rows' => $rows];
    }

    if (count($rawUnits) > 12) {
        return ['error' => 'A product can have at most 12 sellable units', 'rows' => []];
    }

    $seen = ['_' . strtolower($base) => true];
    // The loose unit's code is the product's own column, and a scanner reads it before
    // any size row, so it belongs in this ledger even though it is not a row here.
    $seenCodes = [];
    $looseKey = sfUnitCodeKey($looseCode);
    if ($looseKey !== '') $seenCodes[$looseKey] = 'the loose ' . $base;
    $order = 1;

    foreach ($rawUnits as $raw) {
        if (!is_array($raw)) {
            return ['error' => 'Each unit must be an object', 'rows' => []];
        }
        $name = trim((string)($raw['unit_name'] ?? ''));
        if ($name === '') {
            return ['error' => 'A unit needs a name, such as Crate or Carton', 'rows' => []];
        }
        if (mb_strlen($name) > 40) {
            return ['error' => "Unit name '{$name}' is too long", 'rows' => []];
        }
        $key = '_' . strtolower($name);
        if (isset($seen[$key])) {
            return ['error' => "The unit name '{$name}' is used twice on this product", 'rows' => []];
        }
        $seen[$key] = true;

        // An unparseable size used to arrive as 1, which quietly turned a crate into a
        // loose egg on the shelf. Refuse it instead of guessing.
        if (!isset($raw['size_in_base']) || !is_numeric($raw['size_in_base'])) {
            return ['error' => "Unit '{$name}' needs a multiplier in base units", 'rows' => []];
        }
        $size = round((float)$raw['size_in_base'], 4);
        if ($size <= 1) {
            return ['error' => "Unit '{$name}' must hold more than one base unit", 'rows' => []];
        }
        if ($size > 1000000) {
            return ['error' => "Unit '{$name}' is too large to be a real pack", 'rows' => []];
        }

        $price = null;
        if (array_key_exists('selling_price', $raw) && $raw['selling_price'] !== null
            && $raw['selling_price'] !== '' && !is_numeric($raw['selling_price'])) {
            return ['error' => "Unit '{$name}' has a price that is not a number", 'rows' => []];
        }
        if (array_key_exists('selling_price', $raw) && $raw['selling_price'] !== null
            && $raw['selling_price'] !== '') {
            $price = round((float)$raw['selling_price'], 2);
            if ($price < 0) {
                return ['error' => "Unit '{$name}' cannot have a negative price", 'rows' => []];
            }
        }

        // A size's own code is what the till rings it up by, so two sizes answering the
        // same number is not a typo to keep: the scan picks whichever row the catalogue
        // reads first and the customer is charged for the other one.
        $code = trim((string)($raw['barcode'] ?? ''));
        if (mb_strlen($code) > 64) {
            return ['error' => "Unit '{$name}' has a barcode that is too long", 'rows' => []];
        }
        // Compared the way a scanner reads it, with the digit grouping taken out, so two
        // sizes written differently by two shops are still the one ambiguous code.
        $codeKey = sfUnitCodeKey($code);
        if ($codeKey !== '') {
            if (isset($seenCodes[$codeKey])) {
                return ['error' => "Units '{$seenCodes[$codeKey]}' and '{$name}' share the same barcode", 'rows' => []];
            }
            $seenCodes[$codeKey] = $name;
        }

        $rows[] = [
            'unit_name'     => $name,
            'size_in_base'  => $size,
            'selling_price' => $price,
            'barcode'       => $code,
            'is_base'       => 0,
            'sort_order'    => $order++,
        ];
    }

    return ['error' => null, 'rows' => $rows];
}

/**
 * Replace a product's units wholesale. Called inside the caller's transaction.
 */
function sfUnitsReplace(PDO $db, string $productId, array $rows): void
{
    $db->prepare("DELETE FROM product_units WHERE product_id = ?")->execute([$productId]);
    $stmt = $db->prepare("INSERT INTO product_units
        (id, product_id, unit_name, size_in_base, selling_price, barcode, is_base, sort_order)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    foreach ($rows as $row) {
        $stmt->execute([
            'pun_' . bin2hex(random_bytes(8)),
            $productId,
            $row['unit_name'],
            $row['size_in_base'],
            $row['selling_price'],
            $row['barcode'] ?? '',
            $row['is_base'],
            $row['sort_order'],
        ]);
    }
}

/** @return array<int, array<string, mixed>> */
function sfUnitsFor(PDO $db, string $productId): array
{
    $stmt = $db->prepare("SELECT id, unit_name, size_in_base, selling_price, barcode, is_base, sort_order
                          FROM product_units WHERE product_id = ?
                          ORDER BY is_base DESC, sort_order ASC");
    $stmt->execute([$productId]);
    return $stmt->fetchAll();
}

/**
 * Every product's units in one query, for the listing that would otherwise fire one per
 * row in front of a queue of customers.
 *
 * @param array<int, string> $productIds
 * @return array<string, array<int, array<string, mixed>>>
 */
function sfUnitsForMany(PDO $db, array $productIds): array
{
    $map = [];
    if ($productIds === []) {
        return $map;
    }
    $chunks = array_chunk($productIds, 500);
    foreach ($chunks as $chunk) {
        $in = implode(',', array_fill(0, count($chunk), '?'));
        $stmt = $db->prepare("SELECT product_id, id, unit_name, size_in_base, selling_price, barcode, is_base, sort_order
                              FROM product_units WHERE product_id IN ({$in})
                              ORDER BY product_id, is_base DESC, sort_order ASC");
        $stmt->execute($chunk);
        foreach ($stmt->fetchAll() as $row) {
            $map[$row['product_id']][] = $row;
        }
    }
    return $map;
}

/**
 * Resolve the unit a line was sold in.
 *
 * Matched on the label rather than an id because that is all a receipt, an offline till
 * or a synced sale carries, and a sale must mean the same thing three years later even if
 * the catalogue has been renamed since. $strict asks for the named unit only, which is
 * what a live sale wants: a line for a unit the shop no longer sells is a mistake worth
 * hearing about, not one to quietly price as a loose egg.
 *
 * @return array<string, mixed>|null
 */
function sfUnitResolve(PDO $db, string $productId, string $label, bool $strict = false): ?array
{
    $label = trim($label);
    $stmt = $db->prepare("SELECT id, unit_name, size_in_base, selling_price, is_base
                          FROM product_units WHERE product_id = ?
                          ORDER BY is_base DESC, sort_order ASC");
    $stmt->execute([$productId]);
    $rows = $stmt->fetchAll();

    if ($label !== '') {
        foreach ($rows as $row) {
            if (strcasecmp((string)$row['unit_name'], $label) === 0) {
                return $row;
            }
        }
        // Refused only when the shop does have sizes and this is not one of them. A product
        // with no rows at all is one this table never described - a till's own record, an
        // import, a database that has not been opened since the migration - and a counter
        // that refuses to sell it loose is a counter that has stopped working.
        if ($strict && $rows !== []) {
            return null;
        }
    }

    foreach ($rows as $row) {
        if (!empty($row['is_base'])) return $row;
    }
    if ($rows !== []) {
        return $rows[0];
    }
    return ['id' => null, 'unit_name' => $label !== '' ? $label : 'pcs', 'size_in_base' => 1.0,
            'selling_price' => null, 'is_base' => 1];
}

/**
 * The price a unit sells at when the catalogue gives no override: the base price times
 * the multiplier, which is what the old pack_price fallback already did.
 */
function sfUnitPrice(?float $unitPrice, float $sizeInBase, float $basePrice): float
{
    return $unitPrice !== null ? round($unitPrice, 2) : round($sizeInBase * $basePrice, 2);
}

/**
 * The rows a product record that only knows the legacy pack triple describes.
 *
 * The catalogue form and a till's pushed product both have to answer this the same way:
 * a product that arrives with a carton and no unit rows would otherwise get a base row
 * only, and the shop's carton stops selling at the carton price the moment it reaches
 * the server. A pack named the same as the loose unit is deliberately not filtered here
 * - sfUnitsNormalize refuses it, which is the answer both writers want.
 *
 * @return array<int, array<string, mixed>> rows in the shape sfUnitsNormalize takes
 */
function sfUnitsFromLegacy(?string $packUnit, ?float $packSize, ?float $packPrice): array
{
    $packUnit = trim((string)$packUnit);
    if ($packUnit === '' || $packSize === null || $packSize <= 1) {
        return [];
    }
    return [[
        'unit_name'     => $packUnit,
        'size_in_base'  => $packSize,
        'selling_price' => ($packPrice !== null && $packPrice > 0) ? $packPrice : null,
    ]];
}

/**
 * The key a receipt line and a credit note line are matched on: the product and the size
 * it was sold in, with the spelling the catalogue uses.
 *
 * Both returns.php and sync.php group a receipt's lines this way, and they have to agree:
 * a credit note booked through sync counts against the ceiling that a credit note booked
 * online left behind, and if one keys 'Crate' while the other keys 'crate', a shop can be
 * refunded twice for the same box. Sizing names come from a text field, so case is not
 * meaning; the blank label is what a line written before sizing arrived carries.
 */
function sfUnitKey(string $productId, ?string $label): string
{
    return $productId . '|' . mb_strtolower(trim((string)$label));
}

/**
 * A barcode compared the way a scanner hands it over: lower case, with the spaces,
 * dashes and underscores a shop types to keep long digits readable taken back out.
 * '' for an empty code, so "no code" never collides with another "no code".
 */
function sfUnitCodeKey(string $code): string
{
    return preg_replace('/[\s\-_]/u', '', mb_strtolower(trim($code))) ?? '';
}

/**
 * The biggest pack, projected back onto the one pack_unit/pack_size/pack_price triple
 * still sitting on the products row.
 *
 * Those three columns are read by returns, purchases and the offline till's own product
 * record, none of which know about units yet. Projecting the largest size keeps every one
 * of them agreeing with the catalogue for the two-size shop every till runs today, and
 * stops them choosing a pack the shop never meant as "the" pack. Each reader moves onto
 * product_units in its own right; when the last one has, this mirror goes with it.
 *
 * @return array{pack_unit: string, pack_size: float, pack_price: float}
 */
function sfUnitsLegacyMirror(array $rows): array
{
    $largest = null;
    foreach ($rows as $row) {
        if (!empty($row['is_base'])) continue;
        if ($largest === null || $row['size_in_base'] > $largest['size_in_base']) {
            $largest = $row;
        }
    }
    if ($largest === null) {
        return ['pack_unit' => '', 'pack_size' => 1.0, 'pack_price' => 0.0];
    }
    return [
        'pack_unit'  => $largest['unit_name'],
        'pack_size'  => $largest['size_in_base'],
        // A size with no price of its own stays unpiced here too: the legacy readers fall
        // back to multiplier x base price, which is the same answer the units table gives.
        'pack_price' => $largest['selling_price'] !== null ? round((float)$largest['selling_price'], 2) : 0.0,
    ];
}

/**
 * Read a waybill the way the shelf will be read.
 *
 * A transfer names a product and a count, and until now that count was always loose units -
 * so a shop that ships by the crate typed 120 for a pallet of crates, and nobody wrote down
 * which size actually left. Resolving here means the two callers (the live endpoint and the
 * sync path an offline till drains into) cannot disagree about what a line means, which is
 * the same reason the cart counts room in base units: two rules that differ is a shelf that
 * oversells through whichever door was left open.
 *
 * Returns ['error' => ?string, 'lines' => [...], 'byProduct' => [product_id => base units]].
 * byProduct is the number the source branch has to cover, with every line for the same
 * product already added together.
 */
function sfTransferPlan(PDO $db, array $items): array
{
    $lines = [];
    $byProduct = [];
    $prodStmt = $db->prepare("SELECT id, name, unit, cost_price FROM products WHERE id = ? AND is_active = 1");

    foreach ($items as $it) {
        $productId = trim((string)($it['product_id'] ?? ''));
        $qty = floatval($it['quantity'] ?? 0);
        if ($productId === '' || $qty <= 0) continue;

        $prodStmt->execute([$productId]);
        $prod = $prodStmt->fetch();
        if (!$prod) continue;

        $reqUnit = trim((string)($it['unit'] ?? ''));
        $unitRow = sfUnitResolve($db, $productId, $reqUnit, true);
        if ($unitRow === null) {
            $known = [];
            foreach (sfUnitsFor($db, $productId) as $knownUnit) {
                $known[] = trim((string)($knownUnit['unit_name'] ?? ''));
            }
            return [
                'error' => sprintf("'%s' is not stocked in a %s. This shop has it in %s.",
                    trim((string)($prod['name'] ?? $productId)),
                    $reqUnit,
                    $known ? implode(', ', $known) : 'no recorded size'),
                'lines' => [],
                'byProduct' => [],
            ];
        }

        $multiplier = max(1.0, round(floatval($unitRow['size_in_base'] ?? 1), 4));
        $baseQty = round($qty * $multiplier, 4);
        $lines[] = [
            'product_id'    => $productId,
            'name'          => (string)($prod['name'] ?? ''),
            'unit'          => trim((string)($unitRow['unit_name'] ?? '')),
            'base_unit'     => trim((string)($prod['unit'] ?? '')),
            'multiplier'    => $multiplier,
            'quantity'      => $qty,
            'base_quantity' => $baseQty,
            // The catalogue's cost, never the till's: a waybill that carried its own price
            // would revalue the receiving branch with whatever number the sender typed.
            'cost_price'    => floatval($prod['cost_price'] ?? 0),
        ];
        $byProduct[$productId] = round(($byProduct[$productId] ?? 0) + $baseQty, 4);
    }

    return ['error' => null, 'lines' => $lines, 'byProduct' => $byProduct];
}

/**
 * Return combo items grouped by combo_product_id.
 *
 * @param array<int, string> $productIds
 * @return array<string, array<int, array<string, mixed>>>
 */
function sfComboItemsForMany(PDO $db, array $productIds): array
{
    $map = [];
    if ($productIds === []) {
        return $map;
    }
    $chunks = array_chunk($productIds, 500);
    foreach ($chunks as $chunk) {
        $in = implode(',', array_fill(0, count($chunk), '?'));
        $stmt = $db->prepare("SELECT c.id, c.combo_product_id, c.component_product_id, c.quantity, c.unit,
                                     p.name as component_name, p.cost_price as component_cost, p.selling_price as component_price
                              FROM product_combo_items c
                              LEFT JOIN products p ON c.component_product_id = p.id
                              WHERE c.combo_product_id IN ({$in})
                              ORDER BY c.created_at ASC");
        $stmt->execute($chunk);
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $map[$row['combo_product_id']][] = [
                'id' => $row['id'],
                'combo_product_id' => $row['combo_product_id'],
                'component_product_id' => $row['component_product_id'],
                'component_name' => $row['component_name'] ?? 'Unknown Item',
                'quantity' => floatval($row['quantity']),
                'unit' => $row['unit'] ?? 'pcs',
                'component_cost' => floatval($row['component_cost'] ?? 0),
                'component_price' => floatval($row['component_price'] ?? 0)
            ];
        }
    }
    return $map;
}

/**
 * Save or replace combo components for a bundle product.
 *
 * @param array<int, array<string, mixed>> $components
 */
function sfSaveComboItems(PDO $db, string $comboProductId, array $components): void
{
    $db->prepare("DELETE FROM product_combo_items WHERE combo_product_id = ?")->execute([$comboProductId]);
    if (empty($components)) return;

    $stmt = $db->prepare("INSERT INTO product_combo_items (id, combo_product_id, component_product_id, quantity, unit, created_at)
                          VALUES (?, ?, ?, ?, ?, datetime('now'))");
    foreach ($components as $comp) {
        $compId = trim((string)($comp['component_product_id'] ?? ($comp['product_id'] ?? '')));
        if ($compId === '' || $compId === $comboProductId) continue; // prevent empty or self-reference loop
        $qty = max(0.001, floatval($comp['quantity'] ?? 1.0));
        $unit = trim((string)($comp['unit'] ?? 'pcs')) ?: 'pcs';
        $stmt->execute(['pci_' . bin2hex(random_bytes(6)), $comboProductId, $compId, $qty, $unit]);
    }
}

