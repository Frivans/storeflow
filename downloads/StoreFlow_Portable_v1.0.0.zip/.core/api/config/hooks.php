<?php
// api/config/hooks.php
// StoreFlow Lightweight Action & Filter Hook System
// Allows custom plugins, modules, and integrations to extend core behavior without modifying core files.

if (!defined('STOREFLOW_HOOKS_LOADED')) {
    define('STOREFLOW_HOOKS_LOADED', true);

    class StoreFlowHooks {
        private static array $actions = [];
        private static array $filters = [];

        public static function addAction(string $tag, callable $callback, int $priority = 10): void {
            self::$actions[$tag][$priority][] = $callback;
        }

        public static function doAction(string $tag, ...$args): void {
            if (empty(self::$actions[$tag])) {
                return;
            }
            ksort(self::$actions[$tag]);
            foreach (self::$actions[$tag] as $priority => $callbacks) {
                foreach ($callbacks as $callback) {
                    // One callback blowing up is that plugin's bad day, not the shop's. The
                    // alternative is a hook fired mid-checkout taking the receipt down with it:
                    // the counter would see a failed sale it had already been told to ring.
                    try {
                        call_user_func_array($callback, $args);
                    } catch (\Throwable $hookError) {
                        error_log('StoreFlow hooks: action "' . $tag . '" (priority ' . $priority . ') threw '
                                  . get_class($hookError) . ': ' . $hookError->getMessage());
                    }
                }
            }
        }

        public static function addFilter(string $tag, callable $callback, int $priority = 10): void {
            self::$filters[$tag][$priority][] = $callback;
        }

        public static function applyFilters(string $tag, mixed $value, ...$args): mixed {
            if (empty(self::$filters[$tag])) {
                return $value;
            }
            ksort(self::$filters[$tag]);
            $filtered = $value;
            foreach (self::$filters[$tag] as $priority => $callbacks) {
                foreach ($callbacks as $callback) {
                    // A filter that throws hands back the number it was given, unchanged. Half a
                    // shop's price being a guess is worse than the price before the plugin spoke.
                    try {
                        $filtered = call_user_func_array($callback, array_merge([$filtered], $args));
                    } catch (\Throwable $hookError) {
                        error_log('StoreFlow hooks: filter "' . $tag . '" (priority ' . $priority . ') threw '
                                  . get_class($hookError) . ': ' . $hookError->getMessage()
                                  . '; the value passed in is kept.');
                    }
                }
            }
            return $filtered;
        }

        public static function hasAction(string $tag): bool {
            return !empty(self::$actions[$tag]);
        }

        public static function hasFilter(string $tag): bool {
            return !empty(self::$filters[$tag]);
        }

        public static function loadPlugins(?string $pluginsDir = null): void {
            if ($pluginsDir === null) {
                $pluginsDir = dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'plugins';
            }
            if (!is_dir($pluginsDir)) {
                return;
            }
            $entries = scandir($pluginsDir);
            if ($entries === false) {
                return;
            }
            foreach ($entries as $entry) {
                if ($entry === '.' || $entry === '..') {
                    continue;
                }
                $path = $pluginsDir . DIRECTORY_SEPARATOR . $entry;
                if (is_file($path) && pathinfo($path, PATHINFO_EXTENSION) === 'php') {
                    self::includeSafely($path);
                } elseif (is_dir($path)) {
                    $mainPluginFile = $path . DIRECTORY_SEPARATOR . 'plugin.php';
                    if (is_file($mainPluginFile)) {
                        self::includeSafely($mainPluginFile);
                    }
                }
            }
        }

        /**
         * Load one plugin, and keep going if it cannot be loaded.
         *
         * These files are somebody's own PHP - a shop's add-on dropped into /plugins - and a
         * parse error or a call to a function that does not exist used to be raised at the
         * require itself, which took the whole shop's page down: a till could not open the
         * counter because an unrelated integration had been edited badly. The one exception is
         * a file that dies rather than throws, which no caller can catch.
         */
        private static function includeSafely(string $path): void {
            try {
                require_once $path;
            } catch (\Throwable $pluginError) {
                error_log('StoreFlow plugins: "' . basename($path) . '" failed to load ('
                          . get_class($pluginError) . ': ' . $pluginError->getMessage()
                          . ') and was skipped; the shop runs without it.');
            }
        }
    }

    // Procedural helper wrappers for developer convenience
    function storeflow_add_action(string $tag, callable $callback, int $priority = 10): void {
        StoreFlowHooks::addAction($tag, $callback, $priority);
    }

    function storeflow_do_action(string $tag, ...$args): void {
        StoreFlowHooks::doAction($tag, ...$args);
    }

    function storeflow_add_filter(string $tag, callable $callback, int $priority = 10): void {
        StoreFlowHooks::addFilter($tag, $callback, $priority);
    }

    function storeflow_apply_filters(string $tag, mixed $value, ...$args): mixed {
        return StoreFlowHooks::applyFilters($tag, $value, ...$args);
    }
}
