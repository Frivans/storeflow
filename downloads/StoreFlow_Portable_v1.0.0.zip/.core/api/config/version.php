<?php
// api/config/version.php
// The one place a StoreFlow version number is written.
//
// Before this file the number existed four times over and disagreed with itself:
// installer/build_package.ps1 named the zip v1.0.0, StoreFlow_Setup.iss declared
// v1.0.0, the About pane advertised "Release v2.4.0 (Enterprise)", and the Terms
// pane said "Effective Release v2.4". A shop owner phoning support about build A
// while reading build B off the screen is not a fixable conversation, so the
// constant below is what the server answers, what the package is named after, and
// what the installer is audited against.
//
// Bumping this is a two-step act: change it here, then re-run installer/build_package.ps1,
// which fails the build if the installer script still names an older version.

if (!defined('STOREFLOW_VERSION')) {
    define('STOREFLOW_VERSION', '1.0.0');
}
