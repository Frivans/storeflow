<?php
// api/endpoints/estimates.php
// Price Quotations & Proforma Invoices Engine
//
// This table is also where an online order lands (api/endpoints/ecommerce_sync.php): a
// storefront posting an order is asking for goods, which is what a quotation is. It is not a
// receipt, and nothing here books money - "convert" marks a quotation against a receipt the
// register has already rung.
require_once __DIR__ . '/../config/db.php';

// api/config/db.php owns the shape of this table, including the two columns the bridge writes.
// It used to be created here as well, on the first click of this page, with the error swallowed:
// that left a shop able to hold online orders in a schema the version gate, the column probe
// and the packaged release had never seen.

$currentUser = requireAuth();
$method = $_SERVER['REQUEST_METHOD'];

// Handle GET Requests
if ($method === 'GET') {
    try {
        $id = $_GET['id'] ?? null;
        if ($id) {
            $stmt = $db->prepare("SELECT * FROM estimates WHERE id = ? LIMIT 1");
            $stmt->execute([$id]);
            $estimate = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$estimate) {
                jsonResponse(['success' => false, 'message' => 'Quotation not found'], 404);
            }
            $estimate['items'] = json_decode($estimate['items_json'] ?? '[]', true);
            jsonResponse(['success' => true, 'estimate' => $estimate]);
        }

        $status = $_GET['status'] ?? 'all';
        $search = trim($_GET['search'] ?? '');
        $branchCode = $_GET['branch_code'] ?? null;

        $sql = "SELECT * FROM estimates WHERE 1=1";
        $params = [];

        if ($status !== 'all' && $status !== '') {
            $sql .= " AND status = ?";
            $params[] = strtoupper($status);
        }

        if ($branchCode) {
            $sql .= " AND branch_code = ?";
            $params[] = $branchCode;
        }

        if ($search !== '') {
            $sql .= " AND (estimate_number LIKE ? OR customer_name LIKE ? OR customer_phone LIKE ?)";
            $params[] = "%$search%";
            $params[] = "%$search%";
            $params[] = "%$search%";
        }

        $sql .= " ORDER BY created_at DESC LIMIT 200";

        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $estimates = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($estimates as &$est) {
            $est['items'] = json_decode($est['items_json'] ?? '[]', true);
        }

        jsonResponse(['success' => true, 'estimates' => $estimates]);
    } catch (Exception $e) {
        jsonResponse(['success' => false, 'message' => 'Error loading estimates: ' . $e->getMessage()], 500);
    }
}

// Handle POST Requests
if ($method === 'POST') {
    $authUser = requirePermission('manage_sales');
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) {
        jsonResponse(['success' => false, 'message' => 'Invalid JSON payload'], 400);
    }

    $action = $input['action'] ?? 'create';

    // 1. Create or Save Quotation / Estimate
    if ($action === 'create' || $action === 'save') {
        try {
            $id = $input['id'] ?? ('est-' . uniqid() . '-' . bin2hex(random_bytes(3)));
            $branchCode = $input['branch_code'] ?? 'MAIN-01';
            $customerId = $input['customer_id'] ?? 'cust-walkin';
            $customerName = trim($input['customer_name'] ?? 'Walk-in Customer');
            $customerPhone = trim($input['customer_phone'] ?? '');
            $userId = $currentUser['id'] ?? null;
            $createdByName = $currentUser['full_name'] ?? 'Cashier';
            $estimateDate = $input['estimate_date'] ?? date('Y-m-d H:i:s');
            
            // Default validity: 7 days from now
            $validUntil = $input['valid_until'] ?? date('Y-m-d', strtotime('+7 days'));
            $subtotal = floatval($input['subtotal'] ?? 0);
            $discount = floatval($input['discount'] ?? 0);
            $tax = floatval($input['tax'] ?? 0);
            $notes = trim($input['notes'] ?? '');
            $status = strtoupper($input['status'] ?? 'PENDING');
            $items = $input['items'] ?? [];

            if (empty($items)) {
                jsonResponse(['success' => false, 'message' => 'Cannot create an empty quotation.'], 400);
            }

            // The paper is typed at the till, so the discount stays the shopkeeper's to offer -
            // a quotation is a promise, not a receipt. The arithmetic is not his to type: the
            // subtotal comes from the lines below it and the total from the three figures above
            // it. A till that sent a total of its own used to file "Subtotal 1,000.00, discount
            // 200.00, tax 150.00, TOTAL 400.00" on a document a customer then came back with.
            $lineTotal = 0.0;
            foreach ($items as $it) {
                if (!is_array($it)) continue;
                $lineTotal += isset($it['subtotal'])
                    ? floatval($it['subtotal'])
                    : floatval($it['quantity'] ?? 0) * floatval($it['selling_price'] ?? 0);
            }
            if (round($lineTotal, 2) !== round($subtotal, 2)) {
                logActivity($db, $authUser['id'], $authUser['full_name'], $authUser['role_name'], 'ESTIMATE_TOTAL_CORRECTED',
                    sprintf("Quotation for %s typed a subtotal of %.2f against %.2f of goods; booked the goods.",
                        $customerName, round($subtotal, 2), round($lineTotal, 2)));
            }
            $subtotal = round(max(0, $lineTotal), 2);
            $discount = round(max(0, min($discount, $subtotal)), 2);
            $tax = round(max(0, $tax), 2);
            $totalAmount = round(max(0, $subtotal - $discount) + $tax, 2);

            // Generate sequential Quotation Number if not provided
            $estimateNumber = $input['estimate_number'] ?? null;
            if (!$estimateNumber) {
                $todayPrefix = 'EST-' . date('Ymd') . '-';
                $stmtCount = $db->prepare("SELECT COUNT(*) as count FROM estimates WHERE estimate_number LIKE ?");
                $stmtCount->execute([$todayPrefix . '%']);
                $cnt = (int)$stmtCount->fetch(PDO::FETCH_ASSOC)['count'];
                $estimateNumber = $todayPrefix . str_pad($cnt + 1, 4, '0', STR_PAD_LEFT);
            }

            $itemsJson = json_encode($items, JSON_UNESCAPED_UNICODE);
            $now = date('Y-m-d H:i:s');

            $stmt = $db->prepare("INSERT INTO estimates (
                id, estimate_number, customer_id, customer_name, customer_phone,
                user_id, created_by_name, estimate_date, valid_until, subtotal,
                discount, tax, total_amount, notes, status, items_json,
                branch_code, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                estimate_number = excluded.estimate_number,
                customer_id = excluded.customer_id,
                customer_name = excluded.customer_name,
                customer_phone = excluded.customer_phone,
                estimate_date = excluded.estimate_date,
                valid_until = excluded.valid_until,
                subtotal = excluded.subtotal,
                discount = excluded.discount,
                tax = excluded.tax,
                total_amount = excluded.total_amount,
                notes = excluded.notes,
                status = excluded.status,
                items_json = excluded.items_json,
                updated_at = excluded.updated_at");

            $stmt->execute([
                $id, $estimateNumber, $customerId, $customerName, $customerPhone,
                $userId, $createdByName, $estimateDate, $validUntil, $subtotal,
                $discount, $tax, $totalAmount, $notes, $status, $itemsJson,
                $branchCode, $now, $now
            ]);

            logActivity($db, $authUser['id'], $authUser['full_name'], $authUser['role_name'], 'ESTIMATE_CREATE', "Created Proforma Invoice $estimateNumber for $customerName (Total: $totalAmount)");

            jsonResponse([
                'success' => true,
                'message' => "Quotation $estimateNumber created successfully",
                'estimate' => [
                    'id' => $id,
                    'estimate_number' => $estimateNumber,
                    'customer_id' => $customerId,
                    'customer_name' => $customerName,
                    'customer_phone' => $customerPhone,
                    'created_by_name' => $createdByName,
                    'estimate_date' => $estimateDate,
                    'valid_until' => $validUntil,
                    'subtotal' => $subtotal,
                    'discount' => $discount,
                    'tax' => $tax,
                    'total_amount' => $totalAmount,
                    'notes' => $notes,
                    'status' => $status,
                    'items' => $items,
                    'created_at' => $now
                ]
            ]);
        } catch (Exception $e) {
            jsonResponse(['success' => false, 'message' => 'Failed to save quotation: ' . $e->getMessage()], 500);
        }
    }

    // 2. Convert Quotation to Completed Sale
    if ($action === 'convert') {
        try {
            $estimateId = $input['id'] ?? null;
            $saleId = trim((string)($input['sale_id'] ?? ''));
            if (!$estimateId) {
                jsonResponse(['success' => false, 'message' => 'Quotation ID is required'], 400);
            }

            // "Converted" is the owner's record of a quotation that became a receipt, so both
            // halves have to be real. This used to write the status onto any id it was given -
            // including one that matches no quotation, and a sale_id the shop never rang up -
            // and answer "marked as converted". A quotation can be quoted from, so a fake
            // conversion hides a lost sale behind a green tick.
            $whoStmt = $db->prepare("SELECT estimate_number, status FROM estimates WHERE id = ?");
            $whoStmt->execute([$estimateId]);
            $quotation = $whoStmt->fetch(PDO::FETCH_ASSOC);
            if (!$quotation) {
                jsonResponse(['success' => false, 'message' => "No quotation '{$estimateId}' on the shop's book to convert."], 404);
            }
            if ($saleId === '') {
                jsonResponse(['success' => false,
                    'message' => 'Say which receipt this quotation became, so the paper and the money can be checked against each other.'], 400);
            }
            $saleStmt = $db->prepare("SELECT receipt_number FROM sales WHERE id = ?");
            $saleStmt->execute([$saleId]);
            $bookedSale = $saleStmt->fetch(PDO::FETCH_ASSOC);
            if (!$bookedSale) {
                jsonResponse(['success' => false,
                    'message' => "Receipt '{$saleId}' is not on the shop's book, so the quotation cannot be marked against it. Ring the sale up first."], 404);
            }

            $now = date('Y-m-d H:i:s');
            $stmt = $db->prepare("UPDATE estimates SET status = 'CONVERTED', converted_sale_id = ?, converted_at = ?, updated_at = ? WHERE id = ?");
            $stmt->execute([$saleId, $now, $now, $estimateId]);

            logActivity($db, $authUser['id'], $authUser['full_name'], $authUser['role_name'], 'ESTIMATE_CONVERT', "Converted Quotation {$quotation['estimate_number']} to Sale {$bookedSale['receipt_number']}");
            jsonResponse(['success' => true, 'message' => "Quotation {$quotation['estimate_number']} marked against receipt {$bookedSale['receipt_number']}"]);
        } catch (Exception $e) {
            jsonResponse(['success' => false, 'message' => 'Failed to convert quotation: ' . $e->getMessage()], 500);
        }
    }

    // 3. Update Quotation Status (e.g. Cancelled)
    if ($action === 'update_status') {
        try {
            $id = $input['id'] ?? null;
            $status = strtoupper($input['status'] ?? 'PENDING');
            if (!$id) {
                jsonResponse(['success' => false, 'message' => 'Quotation ID required'], 400);
            }

            $now = date('Y-m-d H:i:s');
            $stmt = $db->prepare("UPDATE estimates SET status = ?, updated_at = ? WHERE id = ?");
            $stmt->execute([$status, $now, $id]);

            jsonResponse(['success' => true, 'message' => "Quotation status updated to $status"]);
        } catch (Exception $e) {
            jsonResponse(['success' => false, 'message' => 'Failed to update quotation: ' . $e->getMessage()], 500);
        }
    }

    // 4. Delete Quotation
    if ($action === 'delete') {
        try {
            $id = $input['id'] ?? null;
            if (!$id) {
                jsonResponse(['success' => false, 'message' => 'Quotation ID required'], 400);
            }

            $stmt = $db->prepare("DELETE FROM estimates WHERE id = ?");
            $stmt->execute([$id]);

            logActivity($db, $authUser['id'], $authUser['full_name'], $authUser['role_name'], 'ESTIMATE_DELETE', "Deleted Quotation $id");
            jsonResponse(['success' => true, 'message' => 'Quotation deleted successfully']);
        } catch (Exception $e) {
            jsonResponse(['success' => false, 'message' => 'Failed to delete quotation: ' . $e->getMessage()], 500);
        }
    }

    jsonResponse(['success' => false, 'message' => 'Unknown action'], 400);
}

jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
