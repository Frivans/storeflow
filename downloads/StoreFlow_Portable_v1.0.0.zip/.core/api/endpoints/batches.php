<?php
// api/endpoints/batches.php
// Enterprise Product Batch & Expiry Date Management
require_once __DIR__ . '/../config/db.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET') {
    $authUser = requireAuth();

    $productId = trim($_GET['product_id'] ?? '');
    $branchCode = strtoupper(trim($_GET['branch_code'] ?? 'ALL'));
    $filter = strtolower(trim($_GET['filter'] ?? 'all'));
    $search = trim($_GET['search'] ?? '');

    $where = [];
    $params = [];

    if (!empty($productId)) {
        $where[] = "b.product_id = ?";
        $params[] = $productId;
    }

    if (!empty($branchCode) && $branchCode !== 'ALL') {
        $where[] = "b.branch_code = ?";
        $params[] = $branchCode;
    }

    $today = date('Y-m-d');
    $thirtyDays = date('Y-m-d', strtotime('+30 days'));
    $ninetyDays = date('Y-m-d', strtotime('+90 days'));

    if ($filter === 'expired') {
        $where[] = "b.expiry_date < ? AND b.current_quantity > 0 AND b.status != 'DEPLETED'";
        $params[] = $today;
    } elseif ($filter === 'expiring_critical' || $filter === 'expiring_30') {
        $where[] = "b.expiry_date >= ? AND b.expiry_date <= ? AND b.current_quantity > 0 AND b.status != 'DEPLETED'";
        $params[] = $today;
        $params[] = $thirtyDays;
    } elseif ($filter === 'expiring_soon' || $filter === 'expiring_90') {
        $where[] = "b.expiry_date >= ? AND b.expiry_date <= ? AND b.current_quantity > 0 AND b.status != 'DEPLETED'";
        $params[] = $today;
        $params[] = $ninetyDays;
    } elseif ($filter === 'active') {
        $where[] = "b.current_quantity > 0 AND b.status = 'ACTIVE'";
    } elseif ($filter === 'depleted') {
        $where[] = "(b.current_quantity <= 0 OR b.status = 'DEPLETED')";
    }

    if (!empty($search)) {
        $where[] = "(b.batch_number LIKE ? OR p.name LIKE ? OR p.sku LIKE ?)";
        $term = "%{$search}%";
        $params[] = $term;
        $params[] = $term;
        $params[] = $term;
    }

    $whereClause = count($where) > 0 ? "WHERE " . implode(" AND ", $where) : "";

    $sql = "SELECT b.*,
                   p.name as product_name,
                   p.sku as product_sku,
                   p.unit as product_unit,
                   p.category as product_category,
                   p.selling_price as product_selling_price,
                   COALESCE(br.name, b.branch_code) as branch_name,
                   COALESCE(v.name, 'Direct Factory') as supplier_name,
                   CAST(ROUND(julianday(b.expiry_date) - julianday('now')) AS INTEGER) as days_left
            FROM product_batches b
            JOIN products p ON b.product_id = p.id
            LEFT JOIN branches br ON b.branch_code = br.branch_code
            LEFT JOIN vendors v ON b.supplier_id = v.id
            {$whereClause}
            ORDER BY b.expiry_date ASC, b.created_at DESC";

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $batches = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Compute summary KPI metrics across all batches for the selected branch
    $metricWhere = "WHERE 1=1";
    $metricParams = [];
    if (!empty($branchCode) && $branchCode !== 'ALL') {
        $metricWhere .= " AND branch_code = ?";
        $metricParams[] = $branchCode;
    }

    $metricSql = "SELECT 
        COUNT(CASE WHEN expiry_date < '{$today}' AND current_quantity > 0 AND status != 'DEPLETED' THEN 1 END) as expired_count,
        COALESCE(SUM(CASE WHEN expiry_date < '{$today}' AND current_quantity > 0 AND status != 'DEPLETED' THEN current_quantity ELSE 0 END), 0) as expired_units,
        COALESCE(SUM(CASE WHEN expiry_date < '{$today}' AND current_quantity > 0 AND status != 'DEPLETED' THEN current_quantity * cost_price ELSE 0 END), 0) as expired_cost,
        
        COUNT(CASE WHEN expiry_date >= '{$today}' AND expiry_date <= '{$thirtyDays}' AND current_quantity > 0 AND status != 'DEPLETED' THEN 1 END) as expiring_30_count,
        COALESCE(SUM(CASE WHEN expiry_date >= '{$today}' AND expiry_date <= '{$thirtyDays}' AND current_quantity > 0 AND status != 'DEPLETED' THEN current_quantity ELSE 0 END), 0) as expiring_30_units,
        COALESCE(SUM(CASE WHEN expiry_date >= '{$today}' AND expiry_date <= '{$thirtyDays}' AND current_quantity > 0 AND status != 'DEPLETED' THEN current_quantity * cost_price ELSE 0 END), 0) as expiring_30_cost,
        
        COUNT(CASE WHEN expiry_date >= '{$today}' AND expiry_date <= '{$ninetyDays}' AND current_quantity > 0 AND status != 'DEPLETED' THEN 1 END) as expiring_90_count,
        COALESCE(SUM(CASE WHEN expiry_date >= '{$today}' AND expiry_date <= '{$ninetyDays}' AND current_quantity > 0 AND status != 'DEPLETED' THEN current_quantity ELSE 0 END), 0) as expiring_90_units,
        
        COUNT(CASE WHEN current_quantity > 0 AND status = 'ACTIVE' THEN 1 END) as active_batches_count,
        COALESCE(SUM(CASE WHEN current_quantity > 0 AND status = 'ACTIVE' THEN current_quantity ELSE 0 END), 0) as active_units,
        COALESCE(SUM(CASE WHEN current_quantity > 0 AND status = 'ACTIVE' THEN current_quantity * cost_price ELSE 0 END), 0) as active_cost
    FROM product_batches {$metricWhere}";

    $metricStmt = $db->prepare($metricSql);
    $metricStmt->execute($metricParams);
    $summary = $metricStmt->fetch(PDO::FETCH_ASSOC);

    // `b.*` hands every lot row back with the cost the shop paid its supplier for that
    // delivery, and the KPI block totals the whole expiry stock at cost. Expiry dates are
    // till data; what the margin was is not.
    $hideCost = !maySeeProductCost($authUser);

    if ($hideCost) {
        foreach ($batches as $i => $batchRow) {
            unset($batches[$i]['cost_price']);
        }
    }

    jsonResponse([
        'success' => true,
        'branch_code' => $branchCode,
        'filter' => $filter,
        'summary' => [
            'expired_count' => intval($summary['expired_count'] ?? 0),
            'expired_units' => floatval($summary['expired_units'] ?? 0),
            'expired_cost' => $hideCost ? null : round(floatval($summary['expired_cost'] ?? 0), 2),
            'expiring_30_count' => intval($summary['expiring_30_count'] ?? 0),
            'expiring_30_units' => floatval($summary['expiring_30_units'] ?? 0),
            'expiring_30_cost' => $hideCost ? null : round(floatval($summary['expiring_30_cost'] ?? 0), 2),
            'expiring_90_count' => intval($summary['expiring_90_count'] ?? 0),
            'expiring_90_units' => floatval($summary['expiring_90_units'] ?? 0),
            'active_batches_count' => intval($summary['active_batches_count'] ?? 0),
            'active_units' => floatval($summary['active_units'] ?? 0),
            'active_cost' => $hideCost ? null : round(floatval($summary['active_cost'] ?? 0), 2)
        ],
        'batches' => $batches
    ]);
}

if ($method === 'POST') {
    $authUser = requirePermission('manage_inventory');
    $data = getJsonInput();
    $action = trim($data['action'] ?? 'save');

    // 1. Action: Write-Off Expired or Damaged Batch Stock
    if ($action === 'write_off') {
        $batchId = trim($data['batch_id'] ?? '');
        $writeOffQty = round(floatval($data['quantity'] ?? 0), 2);
        $reason = strtoupper(trim($data['reason'] ?? 'EXPIRED'));
        $notes = trim($data['notes'] ?? 'Stock write-off due to expiry / damage');

        if (empty($batchId) || $writeOffQty <= 0) {
            jsonResponse(['success' => false, 'message' => 'Batch ID and a valid write-off quantity greater than 0 are required.'], 400);
        }

        try {
            $db->beginTransaction();

            $bStmt = $db->prepare("SELECT b.*, p.name as product_name FROM product_batches b JOIN products p ON b.product_id = p.id WHERE b.id = ?");
            $bStmt->execute([$batchId]);
            $batch = $bStmt->fetch(PDO::FETCH_ASSOC);

            if (!$batch) {
                $db->rollBack();
                jsonResponse(['success' => false, 'message' => 'Batch not found.'], 404);
            }

            $currentBatchQty = floatval($batch['current_quantity'] ?? 0);
            if ($writeOffQty > $currentBatchQty) {
                $db->rollBack();
                jsonResponse(['success' => false, 'message' => "Cannot write off {$writeOffQty} units. Only {$currentBatchQty} units remaining in Batch {$batch['batch_number']}."], 400);
            }

            $newBatchQty = round(max(0, $currentBatchQty - $writeOffQty), 2);
            $newStatus = ($newBatchQty <= 0) ? ($reason === 'EXPIRED' ? 'EXPIRED' : 'DEPLETED') : $batch['status'];

            // Update batch
            $upBatch = $db->prepare("UPDATE product_batches SET current_quantity = ?, status = ?, updated_at = datetime('now') WHERE id = ?");
            $upBatch->execute([$newBatchQty, $newStatus, $batchId]);

            // Deduct from branch_inventory
            $bCode = $batch['branch_code'] ?: 'MAIN-01';
            $pId = $batch['product_id'];

            $upBinv = $db->prepare("UPDATE branch_inventory SET current_quantity = MAX(0, current_quantity - ?), updated_at = datetime('now') WHERE branch_code = ? AND product_id = ?");
            $upBinv->execute([$writeOffQty, $bCode, $pId]);

            // Deduct from consolidated inventory
            $upInv = $db->prepare("UPDATE inventory SET current_quantity = MAX(0, current_quantity - ?), updated_at = datetime('now') WHERE product_id = ?");
            $upInv->execute([$writeOffQty, $pId]);

            // Record audit movement log
            $mvtId = 'mvt_' . bin2hex(random_bytes(6));
            $unitCost = floatval($batch['cost_price'] ?? 0);
            $mvtNotes = "Stock Write-Off [{$reason}]: Batch #{$batch['batch_number']} (Exp: {$batch['expiry_date']}). {$notes}";
            $mvtStmt = $db->prepare("INSERT INTO inventory_movements (id, product_id, movement_type, quantity, reference_id, unit_price, notes, branch_code, created_by, created_at)
                                     VALUES (?, ?, 'WRITE_OFF', ?, ?, ?, ?, ?, ?, datetime('now'))");
            $mvtStmt->execute([$mvtId, $pId, -$writeOffQty, $batch['batch_number'], $unitCost, $mvtNotes, $bCode, $authUser['id']]);

            // Activity log
            logActivity($db, $authUser['id'], $authUser['full_name'], $authUser['role_name'], 'STOCK_WRITEOFF',
                "Wrote off {$writeOffQty} units of '{$batch['product_name']}' from Batch #{$batch['batch_number']} ({$reason}). Remaining: {$newBatchQty}.");

            $db->commit();

            jsonResponse([
                'success' => true,
                'message' => "Successfully wrote off {$writeOffQty} units from Batch #{$batch['batch_number']}.",
                'batch_id' => $batchId,
                'remaining_quantity' => $newBatchQty,
                'status' => $newStatus
            ]);

        } catch (Exception $e) {
            safeRollback($db);
            jsonResponse(['success' => false, 'message' => 'Failed to write off batch stock: ' . $e->getMessage()], 500);
        }
    }

    // 2. Action: Create or Edit Batch
    $id = trim($data['id'] ?? '') ?: ('batch_' . bin2hex(random_bytes(6)));
    $productId = trim($data['product_id'] ?? '');
    $batchNumber = trim($data['batch_number'] ?? '');
    $expiryDate = trim($data['expiry_date'] ?? '');
    $mfgDate = trim($data['manufacture_date'] ?? '') ?: null;
    $initialQty = round(floatval($data['initial_quantity'] ?? $data['quantity'] ?? 0), 2);
    $currentQty = isset($data['current_quantity']) ? round(floatval($data['current_quantity']), 2) : $initialQty;
    $costPrice = round(floatval($data['cost_price'] ?? 0), 2);
    $supplierId = trim($data['supplier_id'] ?? '') ?: null;
    $branchCode = strtoupper(trim($data['branch_code'] ?? 'MAIN-01')) ?: 'MAIN-01';
    $status = strtoupper(trim($data['status'] ?? 'ACTIVE')) ?: 'ACTIVE';
    $notes = trim($data['notes'] ?? '');

    if (empty($productId)) {
        jsonResponse(['success' => false, 'message' => 'Product is required.'], 400);
    }
    if (empty($batchNumber)) {
        $batchNumber = 'LOT-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(2)));
    }
    if (empty($expiryDate)) {
        jsonResponse(['success' => false, 'message' => 'Expiry date is required for batch tracking.'], 400);
    }

    try {
        $db->beginTransaction();

        $checkStmt = $db->prepare("SELECT id FROM product_batches WHERE id = ?");
        $checkStmt->execute([$id]);
        $existing = $checkStmt->fetch();

        if ($existing) {
            $upStmt = $db->prepare("UPDATE product_batches SET
                batch_number = ?, expiry_date = ?, manufacture_date = ?,
                current_quantity = ?, cost_price = ?, supplier_id = ?,
                branch_code = ?, status = ?, notes = ?, updated_at = datetime('now')
                WHERE id = ?");
            $upStmt->execute([$batchNumber, $expiryDate, $mfgDate, $currentQty, $costPrice, $supplierId, $branchCode, $status, $notes, $id]);
        } else {
            $insStmt = $db->prepare("INSERT INTO product_batches (
                id, product_id, batch_number, expiry_date, manufacture_date,
                initial_quantity, current_quantity, cost_price, supplier_id,
                branch_code, status, notes, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))");
            $insStmt->execute([$id, $productId, $batchNumber, $expiryDate, $mfgDate, $initialQty, $currentQty, $costPrice, $supplierId, $branchCode, $status, $notes]);

            // Update product to mark as perishable
            $prodUp = $db->prepare("UPDATE products SET has_expiry = 1, batch_number = ?, expiry_date = ?, mfg_date = ?, updated_at = datetime('now') WHERE id = ?");
            $prodUp->execute([$batchNumber, $expiryDate, $mfgDate, $productId]);
        }

        $db->commit();

        logActivity($db, $authUser['id'], $authUser['full_name'], $authUser['role_name'], 'BATCH_SAVE',
            "Recorded/updated batch #{$batchNumber} (Exp: {$expiryDate}, Qty: {$currentQty}).");

        jsonResponse([
            'success' => true,
            'message' => 'Batch saved successfully.',
            'batch' => [
                'id' => $id,
                'product_id' => $productId,
                'batch_number' => $batchNumber,
                'expiry_date' => $expiryDate,
                'current_quantity' => $currentQty,
                'branch_code' => $branchCode
            ]
        ], $existing ? 200 : 201);

    } catch (Exception $e) {
        safeRollback($db);
        jsonResponse(['success' => false, 'message' => 'Failed to save batch: ' . $e->getMessage()], 500);
    }
}

if ($method === 'DELETE') {
    $authUser = requirePermission('manage_inventory');
    $batchId = trim($_GET['id'] ?? '');

    if (empty($batchId)) {
        jsonResponse(['success' => false, 'message' => 'Batch ID required'], 400);
    }

    $bStmt = $db->prepare("SELECT batch_number FROM product_batches WHERE id = ?");
    $bStmt->execute([$batchId]);
    $batchNo = $bStmt->fetchColumn() ?: $batchId;

    $stmt = $db->prepare("UPDATE product_batches SET status = 'RECALLED', updated_at = datetime('now') WHERE id = ?");
    $stmt->execute([$batchId]);

    logActivity($db, $authUser['id'], $authUser['full_name'], $authUser['role_name'], 'BATCH_RECALL', "Marked batch #{$batchNo} as RECALLED.");

    jsonResponse(['success' => true, 'message' => "Batch #{$batchNo} marked as RECALLED."]);
}

jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
