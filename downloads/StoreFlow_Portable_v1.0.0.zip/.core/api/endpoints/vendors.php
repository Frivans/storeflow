<?php
// api/endpoints/vendors.php
// Factory Vendors & Suppliers Management, Accounts Payable, and Ledger Settlements
require_once __DIR__ . '/../config/db.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET') {
    $user = requireAuth();

    $vendorId = trim($_GET['vendor_id'] ?? $_GET['id'] ?? '');

    // What the shop owes its suppliers, what it has paid them and the bank details it
    // pays them into are the same class of data as cost_price, and followed no rule of
    // its own: any signed-in till could read the whole accounts-payable book.
    $seesMoney = maySeeProductCost($user);
    $noMoney = function (): void {
        jsonResponse(['success' => false, 'message' => 'You do not have access to supplier accounts.'], 403);
    };
    $maskVendor = function (array $row): array {
        $row['balance'] = null;
        $row['bank_details'] = '';
        unset($row['total_orders_cost']);
        // A carry-in is the same class of number as the balance it produced. Handing it to a
        // till that may not see accounts payable would leak the debt back out through a column
        // the masking rule had never heard of.
        $row['opening_amount'] = null;
        unset($row['opening_note'], $row['opening_date'], $row['opening_by']);
        return $row;
    };
    // One account, one carry-in, so the LEFT JOIN below cannot multiply the supplier into two
    // rows. The key is what makes that a fact of the schema rather than a promise.
    $openingJoin = "LEFT JOIN vendor_opening_balances ob ON ob.vendor_id = v.id";
    $openingCols = "ob.amount AS opening_amount, ob.note AS opening_note,
                    ob.created_at AS opening_date, ob.user_name AS opening_by";

    // 1. Fetch payout ledger for a specific vendor
    if (isset($_GET['payments']) && !empty($vendorId)) {
        if (!$seesMoney) $noMoney();
        $stmt = $db->prepare("SELECT vp.*, u.full_name as officer_name, p.order_number
                              FROM vendor_payments vp
                              LEFT JOIN users u ON vp.user_id = u.id
                              LEFT JOIN purchases p ON vp.purchase_id = p.id
                              WHERE vp.vendor_id = ?
                              ORDER BY vp.payment_date DESC, vp.created_at DESC");
        $stmt->execute([$vendorId]);
        $payments = $stmt->fetchAll();
        jsonResponse(['success' => true, 'payments' => $payments]);
    }

    // 2. Fetch purchase order history for a specific vendor
    if (isset($_GET['purchases']) && !empty($vendorId)) {
        if (!$seesMoney) $noMoney();
        $stmt = $db->prepare("SELECT p.*, COUNT(pi.id) as total_products_count
                              FROM purchases p
                              LEFT JOIN purchase_items pi ON p.id = pi.purchase_id
                              WHERE p.vendor_id = ?
                              GROUP BY p.id
                              ORDER BY p.order_date DESC, p.created_at DESC");
        $stmt->execute([$vendorId]);
        $purchases = $stmt->fetchAll();
        jsonResponse(['success' => true, 'purchases' => $purchases]);
    }

    // 3. Fetch specific vendor with full ledger statement
    if (!empty($vendorId) && !isset($_GET['summary'])) {
        $stmt = $db->prepare("SELECT v.*, 
                                     {$openingCols},
                                     COUNT(DISTINCT p.id) as total_orders_count,
                                     COALESCE(SUM(p.total_cost), 0) as total_orders_cost
                              FROM vendors v
                              LEFT JOIN purchases p ON v.id = p.vendor_id
                              {$openingJoin}
                              WHERE v.id = ?
                              GROUP BY v.id");
        $stmt->execute([$vendorId]);
        $vendor = $stmt->fetch();
        if (!$vendor) {
            jsonResponse(['success' => false, 'message' => 'Supplier not found'], 404);
        }
        if (!$seesMoney) {
            $vendor = $maskVendor($vendor);
        }
        jsonResponse(['success' => true, 'vendor' => $vendor]);
    }

    // 4. Default: List all vendors with metrics
    $search = trim($_GET['search'] ?? '');
    $sql = "SELECT v.*, 
                   {$openingCols},
                   COUNT(DISTINCT p.id) as total_orders_count,
                   COALESCE(SUM(p.total_cost), 0) as total_orders_cost,
                   COALESCE(MAX(p.order_date), '') as last_order_date
            FROM vendors v
            LEFT JOIN purchases p ON v.id = p.vendor_id
            {$openingJoin}
            WHERE 1=1";
    $params = [];

    if (!empty($search)) {
        $sql .= " AND (v.name LIKE ? OR v.contact_person LIKE ? OR v.phone LIKE ? OR v.email LIKE ?)";
        $params[] = "%{$search}%";
        $params[] = "%{$search}%";
        $params[] = "%{$search}%";
        $params[] = "%{$search}%";
    }

    $sql .= " GROUP BY v.id ORDER BY v.name ASC";
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $vendors = $stmt->fetchAll();

    // Summary calculations
    $totalVendors = count($vendors);
    // Netting the two directions into one figure let a supplier holding our deposit cancel
    // a supplier we owe, so the headline "Accounts Payable (Owed)" was neither number.
    $totalAccountsPayable = 0.0;
    $totalAdvancesReceivable = 0.0;
    $totalOrdersCost = 0.0;
    $vendorsWithDebt = 0;
    $vendorsHoldingAdvances = 0;

    foreach ($vendors as $i => $v) {
        $bal = round(floatval($v['balance'] ?? 0), 2);
        if ($bal > 0.01) {
            $totalAccountsPayable += $bal;
            $vendorsWithDebt++;
        } elseif ($bal < -0.01) {
            $totalAdvancesReceivable += abs($bal);
            $vendorsHoldingAdvances++;
        }
        $totalOrdersCost += floatval($v['total_orders_cost'] ?? 0);
        if (!$seesMoney) {
            $vendors[$i] = $maskVendor($v);
        }
    }

    jsonResponse([
        'success' => true,
        'vendors' => $vendors,
        'metrics' => [
            'total_vendors' => $totalVendors,
            'total_accounts_payable' => $seesMoney ? round($totalAccountsPayable, 2) : null,
            'total_advances_receivable' => $seesMoney ? round($totalAdvancesReceivable, 2) : null,
            'total_orders_cost' => $seesMoney ? round($totalOrdersCost, 2) : null,
            'vendors_with_debt' => $seesMoney ? $vendorsWithDebt : null,
            'vendors_holding_advances' => $seesMoney ? $vendorsHoldingAdvances : null
        ]
    ]);
}

if ($method === 'POST') {
    $authUser = requirePermission('manage_purchases');
    $data = getJsonInput();
    $action = trim($data['action'] ?? '');

    // Action 1: Record Supplier Payout (Accounts Payable Debt Settlement)
    if ($action === 'record_payment') {
        $vendorId = trim($data['vendor_id'] ?? '');
        $purchaseId = trim($data['purchase_id'] ?? '') ?: null;
        $paymentAmount = round(floatval($data['amount'] ?? 0), 2);
        $paymentMethod = strtoupper(trim($data['payment_method'] ?? 'CASH'));
        $referenceNo = trim($data['reference_no'] ?? '');
        $paymentDate = trim($data['payment_date'] ?? date('Y-m-d'));
        $notes = trim($data['notes'] ?? 'Vendor payout / debt settlement');
        // The till's own id for its own ledger row. Keeping it is what lets a payment that
        // arrives twice collide on the key instead of being filed as two payments, and what
        // lets the supplier statement recognise the shop's copy of a payment as the same
        // line the till is holding. A till too old to send one still gets a server id.
        $postedId = trim((string)($data['id'] ?? ''));
        $paymentId = preg_match('/^vpay_[A-Za-z0-9_\-]{4,48}$/', $postedId) ? $postedId : ('vpay_' . bin2hex(random_bytes(6)));

        if (empty($vendorId) || $paymentAmount <= 0) {
            jsonResponse(['success' => false, 'message' => 'Valid vendor and positive payout amount required'], 400);
        }

        try {
            $db->beginTransaction();

            $vStmt = $db->prepare("SELECT * FROM vendors WHERE id = ?");
            $vStmt->execute([$vendorId]);
            $vendor = $vStmt->fetch();

            if (!$vendor) {
                throw new Exception("Vendor record not found");
            }

            // Ask whether this payment is already in the books before asking whether it
            // overshoots. A cashier who hits Pay twice on a GH₵1,000 payout used to get the
            // second click answered as "this is more than the supplier is owed - confirm it
            // as an advance?", because the first click had already settled the debt. That is
            // not a question about money, it is the same money arriving twice, and answering
            // it as an advance offer is how a shop ends up holding a deposit it never paid.
            // The ledger key below is what actually guarantees it under a real race; this is
            // what makes the answer honest.
            $seenStmt = $db->prepare("SELECT id FROM vendor_payments WHERE id = ?");
            $seenStmt->execute([$paymentId]);
            if ($seenStmt->fetchColumn()) {
                safeRollback($db);
                jsonResponse([
                    'success' => false,
                    'already_recorded' => true,
                    'message' => "That payout is already in the shop's books. Nothing was paid a second time."
                ], 409);
            }

            $currentBalance = round(floatval($vendor['balance'] ?? 0), 2);
            $overshoot = round($paymentAmount - $currentBalance, 2);
            $wantsAdvance = !empty($data['allow_advance']);
            // max(0, balance - amount) used to hide the overshoot: a payout larger than
            // the debt settled the account at zero and still recorded the whole amount as
            // paid to the supplier, so cash left the till for nothing. Refusing every
            // overshoot was the other half of the same mistake - paying a factory a
            // deposit for goods not yet delivered is ordinary trade, and the shop is
            // then owed that money. It is allowed, but only when the cashier says so.
            if ($overshoot > 0.01 && !$wantsAdvance) {
                safeRollback($db);
                jsonResponse([
                    'success' => false,
                    'advance_offer' => true,
                    'overshoot' => $overshoot,
                    'message' => "This payout is {$overshoot} more than what '{$vendor['name']}' is owed. If you are paying a deposit for goods not yet delivered, confirm it as an advance and the account will hold that money for you. If it is a mis-typed amount, correct it and pay again."
                ], 400);
            }
            // Record in the ledger first. If this exact payment is already in the shop's books
            // the key refuses it and nothing else in this request moves - so a cashier who
            // hits Pay twice, or a till that resends a row it already delivered, cannot pay
            // the same debt twice.
            $pStmt = $db->prepare("INSERT INTO vendor_payments (id, vendor_id, purchase_id, user_id, amount, payment_method, reference_no, payment_date, notes, created_at)
                                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))");
            try {
                $pStmt->execute([
                    $paymentId,
                    $vendorId,
                    $purchaseId,
                    $authUser['id'],
                    $paymentAmount,
                    $paymentMethod,
                    $referenceNo,
                    $paymentDate,
                    $notes
                ]);
            } catch (PDOException $clash) {
                safeRollback($db);
                if (stripos($clash->getMessage(), 'UNIQUE constraint failed') !== false) {
                    jsonResponse([
                        'success' => false,
                        'already_recorded' => true,
                        'message' => "That payout is already in the shop's books. Nothing was paid a second time."
                    ], 409);
                }
                throw $clash;
            }

            // The account moves by subtraction inside the database, not by a figure worked out
            // in PHP from a balance read a moment earlier. Two payouts two seconds apart used
            // to read the same GH₵2,450 owed, both write GH₵0, and both leave a ledger row
            // behind - so the shop appeared to pay GH₵4,900 against a GH₵2,450 debt while the
            // account quietly disagreed with its own ledger. That is in the owner's live
            // database twice over, on Dangote and on Golden Oil.
            $db->prepare("UPDATE vendors SET balance = balance - ?, updated_at = datetime('now') WHERE id = ?")
               ->execute([$paymentAmount, $vendorId]);
            $afterStmt = $db->prepare("SELECT balance FROM vendors WHERE id = ?");
            $afterStmt->execute([$vendorId]);
            $newBalance = round(floatval($afterStmt->fetchColumn()), 2);

            // A settlement pays off invoices, not just a number. An order kept its PARTIAL
            // badge for ever unless the cashier happened to link the payout to it, so the
            // suppliers page reported GH₵0.00 owed while the dashboard reported GH₵1,233,000
            // still to pay - the same money, two answers, and the wrong one is the figure that
            // makes a shopkeeper pay a bill he has already cleared.
            $appliedOrders = allocateVendorPaymentToOrders($db, $vendorId, $paymentAmount, (string)$purchaseId);

            $db->commit();

            $advanceHeld = $newBalance < -0.01 ? round(abs($newBalance), 2) : 0.0;

            logActivity($db, $authUser['id'], $authUser['full_name'], $authUser['role_name'], 'VENDOR_PAYOUT',
                "Recorded supplier payout of {$paymentAmount} ({$paymentMethod}) to vendor '{$vendor['name']}'. "
                . ($advanceHeld > 0
                    ? "The account is now settled with an advance of {$advanceHeld} held with the supplier."
                    : "Remaining debt: {$newBalance}"));

            jsonResponse([
                'success' => true,
                'message' => $advanceHeld > 0
                    ? "Payout recorded. '{$vendor['name']}' is settled and now holds an advance of {$advanceHeld} against future deliveries."
                    : 'Vendor payout recorded successfully',
                'advance_held' => $advanceHeld,
                'applied_orders' => $appliedOrders,
                'payment' => [
                    'id' => $paymentId,
                    'vendor_id' => $vendorId,
                    'vendor_name' => $vendor['name'],
                    'amount' => $paymentAmount,
                    'payment_method' => $paymentMethod,
                    'reference_no' => $referenceNo,
                    'payment_date' => $paymentDate,
                    'previous_balance' => $currentBalance,
                    'new_balance' => $newBalance,
                    'officer_name' => $authUser['full_name']
                ]
            ]);

        } catch (Exception $e) {
            safeRollback($db);
            jsonResponse(['success' => false, 'message' => 'Failed to record vendor payout: ' . $e->getMessage()], 500);
        }
    }

    // Action 2: Book the carry-in a supplier account starts with
    //
    // The one door for "this is what the paper book said on the day we started typing it in".
    // It writes a row and lets the account move by that row, instead of letting a number be
    // dropped straight into vendors.balance where no date, no name and no statement line can
    // ever account for it.
    if ($action === 'record_opening') {
        $vendorId = trim($data['vendor_id'] ?? '');
        $grossAmount = round(floatval($data['amount'] ?? 0), 2);
        $direction = strtoupper(trim($data['direction'] ?? 'DEBT'));
        $note = trim($data['note'] ?? '');
        $openingDate = trim($data['opening_date'] ?? '');
        // The till decides which way the money leans, the server does the arithmetic: a debt
        // the shop carried in raises what it owes, an advance it handed over pulls the account
        // negative, and one signed column holds both.
        $signedAmount = $direction === 'ADVANCE' ? -$grossAmount : $grossAmount;

        if ($vendorId === '') {
            jsonResponse(['success' => false, 'message' => 'A supplier is required to carry a balance into.'], 400);
        }
        if ($grossAmount <= 0) {
            jsonResponse(['success' => false, 'message' => 'Enter the amount the account starts with. A carry-in of zero books nothing.'], 400);
        }
        if (!in_array($direction, ['DEBT', 'ADVANCE'], true)) {
            jsonResponse(['success' => false, 'message' => 'Say which way it leans: we owe them, or they hold our money.'], 400);
        }

        try {
            $db->beginTransaction();

            $vStmt = $db->prepare("SELECT * FROM vendors WHERE id = ?");
            $vStmt->execute([$vendorId]);
            $vendor = $vStmt->fetch();
            if (!$vendor) {
                safeRollback($db);
                jsonResponse(['success' => false, 'message' => 'Supplier not found'], 404);
            }

            $defaultNote = 'Opening balance brought forward';
            if ($note === '') $note = $defaultNote;
            if ($note === $defaultNote) {
                // Carrying a number in after the account has traded is not an opening balance -
                // it is a correction, and the books can only be trusted if a correction says so.
                $hist = $db->prepare("SELECT (SELECT COUNT(*) FROM purchases WHERE vendor_id = ?)
                                            + (SELECT COUNT(*) FROM vendor_payments WHERE vendor_id = ?) AS n");
                $hist->execute([$vendorId, $vendorId]);
                if (intval($hist->fetchColumn() ?? 0) > 0) {
                    safeRollback($db);
                    jsonResponse(['success' => false, 'message' => "This account has already traded, so a balance carried into it now has to say why - the note is what the statement shows. If the figures on this supplier are simply wrong, settle or top up the account with a payout instead of stacking a second number on top."], 400);
                }
            }

            if (!applyVendorOpeningBalance($db, $vendorId, $signedAmount, $note, $authUser['id'], $authUser['full_name'], $openingDate)) {
                safeRollback($db);
                jsonResponse([
                    'success' => false,
                    'already_recorded' => true,
                    'message' => "'{$vendor['name']}' already carries a balance into this shop's book. One account gets one opening; settle it with a payout or an order rather than booking a second."
                ], 409);
            }

            $afterStmt = $db->prepare("SELECT balance FROM vendors WHERE id = ?");
            $afterStmt->execute([$vendorId]);
            $newBalance = round(floatval($afterStmt->fetchColumn()), 2);

            $db->commit();

            logActivity($db, $authUser['id'], $authUser['full_name'], $authUser['role_name'], 'VENDOR_OPENING',
                "Booked an opening balance of " . abs($signedAmount) . " on supplier '{$vendor['name']}' as "
                . ($signedAmount > 0 ? "debt owed from before StoreFlow kept this book" : "an advance this shop holds with them")
                . ". Note: \"{$note}\". The account now reads {$newBalance}.");

            jsonResponse([
                'success' => true,
                'message' => $signedAmount > 0
                    ? "'{$vendor['name']}' now carries {$newBalance} of debt into the books."
                    : "'{$vendor['name']}' now holds " . abs($newBalance) . " of this shop's money as an advance.",
                'opening' => [
                    'vendor_id' => $vendorId,
                    'opening_amount' => $signedAmount,
                    'opening_note' => $note,
                    'opening_by' => $authUser['full_name'],
                    'new_balance' => $newBalance
                ]
            ]);

        } catch (Exception $e) {
            safeRollback($db);
            jsonResponse(['success' => false, 'message' => 'Failed to book the opening balance: ' . $e->getMessage()], 500);
        }
    }

    // Action 3: Create or Update Vendor Profile
    $id = trim($data['id'] ?? '');
    $name = trim($data['name'] ?? '');
    $contactPerson = trim($data['contact_person'] ?? '');
    $phone = trim($data['phone'] ?? '');
    $email = trim($data['email'] ?? '');
    $address = trim($data['address'] ?? '');
    $taxId = trim($data['tax_id'] ?? '');
    $paymentTerms = trim($data['payment_terms'] ?? 'NET30');
    $bankDetails = trim($data['bank_details'] ?? '');
    $notes = trim($data['notes'] ?? '');
    // Only ever read to be refused. An account's starting number used to be taken from this
    // field and dropped straight into vendors.balance, which is where a supplier ended up
    // owing GH₵5,000 that no date, no staff member and no ledger row could account for.
    $profileBalance = round(floatval($data['balance'] ?? 0), 2);

    if (empty($name)) {
        jsonResponse(['success' => false, 'message' => 'Vendor / Supplier name is required'], 400);
    }

    // Is this account already on the shop's book? The till names the supplier it is creating -
    // it mints the id in its own browser so the same account can be queued while the line is
    // down - so an id on the request means "the till calls this one new", not "this row exists".
    // Asking the book instead of trusting the field is the whole of the fix below.
    $isNewAccount = $id === '';
    if (!$isNewAccount) {
        $existsStmt = $db->prepare("SELECT 1 FROM vendors WHERE id = ?");
        $existsStmt->execute([$id]);
        $isNewAccount = $existsStmt->fetchColumn() === false;
    }

    // Shut the back door on a new account: a starting number that arrives on the profile is a
    // balance with no row behind it. It has to be refused out loud, not quietly dropped, or a
    // till that still sends the old field would report a supplier at zero and believe it owed
    // what it typed.
    if ($isNewAccount && abs($profileBalance) > 0.005) {
        jsonResponse([
            'success' => false,
            'message' => "A supplier is not created with a balance written straight onto it. Save the profile, then book the money as an opening balance, so the account carries the date and the name of whoever entered it."
        ], 400);
    }

    try {
        $db->beginTransaction();

        // Write the account the book has never seen; correct the one it already holds.
        //
        // The till names the supplier it is creating - it mints the id in its own browser so the
        // same account can be queued while the line is down - so an id on this request never
        // meant "this row exists". The branch used to read the other way round: any id at all
        // went to an UPDATE, which matched no row, booked nothing, and answered "Vendor saved
        // successfully". A supplier added at an online till therefore lived only in that one
        // browser and disappeared the next time the list was read back off the shop. ON
        // CONFLICT is what keeps a double-clicked Save from being two suppliers.
        $vendorId = $id !== '' ? $id : ('ven_' . bin2hex(random_bytes(6)));
        $inserted = false;
        if ($isNewAccount) {
            // A brand-new account opens at zero. Every figure above that arrives through a row -
            // a purchase, a payout, or a carry-in.
            $stmt = $db->prepare("INSERT INTO vendors (id, name, contact_person, phone, email, address, tax_id, balance, payment_terms, bank_details, notes, created_at, updated_at)
                                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
                                   ON CONFLICT(id) DO NOTHING");
            $stmt->execute([
                $vendorId,
                $name,
                $contactPerson,
                $phone,
                $email,
                $address,
                $taxId,
                0.0,
                $paymentTerms,
                $bankDetails,
                $notes
            ]);
            $inserted = $stmt->rowCount() > 0;
        }

        if (!$inserted) {
            $stmt = $db->prepare("UPDATE vendors SET 
                                  name = ?,
                                  contact_person = ?,
                                  phone = ?,
                                  email = ?,
                                  address = ?,
                                  tax_id = ?,
                                  payment_terms = ?,
                                  bank_details = ?,
                                  notes = ?,
                                  updated_at = datetime('now')
                                  WHERE id = ?");
            $stmt->execute([
                $name,
                $contactPerson,
                $phone,
                $email,
                $address,
                $taxId,
                $paymentTerms,
                $bankDetails,
                $notes,
                $vendorId
            ]);
        }

        // The account the shop now holds is the answer, and the log says which door wrote it:
        // an account that appeared is news a manager reads differently from one edited.
        $actionDesc = $inserted ? "Created new vendor '{$name}'" : "Updated vendor details for '{$name}'";

        $vFetch = $db->prepare("SELECT * FROM vendors WHERE id = ?");
        $vFetch->execute([$vendorId]);
        $savedVendor = $vFetch->fetch();

        $db->commit();

        logActivity($db, $authUser['id'], $authUser['full_name'], $authUser['role_name'], 'VENDOR_MANAGEMENT', $actionDesc);

        jsonResponse([
            'success' => true,
            'message' => 'Vendor saved successfully',
            'vendor' => $savedVendor
        ]);

    } catch (Exception $e) {
        safeRollback($db);
        jsonResponse(['success' => false, 'message' => 'Failed to save vendor: ' . $e->getMessage()], 500);
    }
}

if ($method === 'DELETE') {
    $authUser = requirePermission('manage_purchases');
    $id = trim($_GET['id'] ?? '');

    if (empty($id)) {
        jsonResponse(['success' => false, 'message' => 'Vendor ID is required'], 400);
    }

    try {
        $checkStmt = $db->prepare("SELECT COUNT(*) as count FROM purchases WHERE vendor_id = ?");
        $checkStmt->execute([$id]);
        $poCount = $checkStmt->fetch()['count'] ?? 0;

        if ($poCount > 0) {
            jsonResponse([
                'success' => false,
                'message' => "Cannot delete vendor: {$poCount} purchase order(s) are linked to this supplier. Archive or settle accounts instead."
            ], 400);
        }

        $balStmt = $db->prepare("SELECT name, balance FROM vendors WHERE id = ?");
        $balStmt->execute([$id]);
        $balRow = $balStmt->fetch();
        $openBal = round(floatval($balRow['balance'] ?? 0), 2);
        // An account with money in it is not a row to discard, whichever side it sits on:
        // positive is this shop's debt, negative is this shop's advance with the supplier.
        if (abs($openBal) > 0.01) {
            jsonResponse([
                'success' => false,
                'message' => $openBal > 0
                    ? "Cannot delete '{$balRow['name']}': this shop still owes them {$openBal}. Settle the account first."
                    : "Cannot delete '{$balRow['name']}': they are holding an advance of " . abs($openBal) . " against future deliveries. Reclaim or book it off first."
            ], 400);
        }

        $vStmt = $db->prepare("SELECT name FROM vendors WHERE id = ?");
        $vStmt->execute([$id]);
        $vendorName = $vStmt->fetchColumn() ?: 'Vendor';

        // The account's own money rows go with it. Both of them point at this supplier through a
        // foreign key, so deleting the profile first - which is what this door used to do - made
        // SQLite refuse the whole request: a settled supplier that had ever been paid in cash
        // could not be deleted at all, and the till was handed a bare "FOREIGN KEY constraint
        // failed". Leaving either row behind instead would orphan it under a supplier id that no
        // longer exists, and the next account handed that id would open with someone else's
        // history. This is the same cascade sync.php already runs on the offline delete, and it
        // goes in one transaction: an account whose payouts have gone but whose profile remains is
        // a supplier at zero with no way to tell anyone the ledger was erased.
        $payStmt = $db->prepare("SELECT COUNT(*) FROM vendor_payments WHERE vendor_id = ?");
        $payStmt->execute([$id]);
        $payCount = intval($payStmt->fetchColumn());
        $openStmt = $db->prepare("SELECT COUNT(*) FROM vendor_opening_balances WHERE vendor_id = ?");
        $openStmt->execute([$id]);
        $openingCount = intval($openStmt->fetchColumn());

        try {
            $db->beginTransaction();
            $db->prepare("DELETE FROM vendor_payments WHERE vendor_id = ?")->execute([$id]);
            $db->prepare("DELETE FROM vendor_opening_balances WHERE vendor_id = ?")->execute([$id]);
            $delStmt = $db->prepare("DELETE FROM vendors WHERE id = ?");
            $delStmt->execute([$id]);
            $db->commit();
        } catch (Exception $e) {
            safeRollback($db);
            jsonResponse(['success' => false, 'message' => 'Failed to delete vendor: ' . $e->getMessage()], 500);
        }

        logActivity($db, $authUser['id'], $authUser['full_name'], $authUser['role_name'], 'VENDOR_DELETE',
            "Deleted vendor '{$vendorName}' (ID: {$id}) with a settled account, taking {$payCount} payout row(s)"
            . ($openingCount > 0 ? " and its opening balance" : "") . " with it.");

        jsonResponse([
            'success' => true,
            'message' => "Vendor '{$vendorName}' deleted successfully"
        ]);

    } catch (Exception $e) {
        jsonResponse(['success' => false, 'message' => 'Failed to delete vendor: ' . $e->getMessage()], 500);
    }
}

jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
