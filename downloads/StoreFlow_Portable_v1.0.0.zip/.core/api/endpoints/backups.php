<?php
// api/endpoints/backups.php
// Automated Backups & Manual Snapshot / Restore Management
require_once __DIR__ . '/../config/db.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// Put the pre-restore snapshot back where the live database sits. The WAL/SHM
// journals of the rejected file must go with it, or SQLite replays them over the
// reverted copy and the "successful" revert is corrupt again.
function revertToSafetyBackup(array $safety, string $dbPath): bool
{
    if (empty($safety['filepath']) || !is_file($safety['filepath'])) return false;
    if (function_exists('syncRestoredSqliteRuntime')) {
        return syncRestoredSqliteRuntime($safety['filepath'], $dbPath);
    }
    if (file_exists($dbPath . '-wal')) @file_put_contents($dbPath . '-wal', '');
    @unlink($dbPath . '-wal');
    @unlink($dbPath . '-shm');
    return @copy($safety['filepath'], $dbPath);
}

function safetyRevertNotice(bool $reverted, array $safety): string
{
    if ($reverted) return 'Reverted to the pre-restore snapshot.';
    $name = $safety['filename'] ?? 'the newest store_backup_*.db file';
    return 'WARNING: the automatic revert also failed, so the live database is NOT your previous state. Your data is safe inside the backups folder as ' . $name . ' — stop using the POS and restore that file before any new sale is recorded.';
}

/**
 * A name inside the shared backups folder that does not already exist.
 *
 * A timestamp is only unique until somebody clicks twice in the same second, and both
 * call sites below write into the folder every other backup lives in. Silently replacing
 * an archive is how an owner finds, later, that the copy they meant to keep is a
 * different file.
 */
function uniqueArchivePath(string $backupDir, string $stem, string $ext): string
{
    $path = $backupDir . DIRECTORY_SEPARATOR . $stem . $ext;
    for ($n = 2; file_exists($path) && $n < 100; $n++) {
        $path = $backupDir . DIRECTORY_SEPARATOR . $stem . '_' . $n . $ext;
    }
    return $path;
}

/**
 * Put a snapshot file over the live database, or fail and put the previous state back.
 *
 * Three actions need this - restore a listed snapshot, restore an uploaded .db, restore
 * a decrypted .sfbak - and the money at stake is identical in all three: a shop's entire
 * history is being replaced by a file. Keeping it in one place is what makes "we verified
 * the restore path" a statement about the product rather than about one button.
 *
 * @param PDO $db passed by reference so the caller's connection is genuinely dropped
 *                before the file it holds open is overwritten.
 */
function installBackupOverRuntime(PDO &$db, string $dbPath, string $sourcePath, array $safety, array $user, string $logAction, string $logLabel): array
{
    try {
        $db->exec("PRAGMA wal_checkpoint(TRUNCATE);");
    } catch (Throwable $we) {}

    // Disconnect PDO from the runtime file first, or SQLite keeps the WAL and SHM
    // journals open and the copy lands underneath a live handle.
    $db = null;
    if (function_exists('gc_collect_cycles')) {
        gc_collect_cycles();
    }

    $copiedOk = function_exists('syncRestoredSqliteRuntime')
        ? syncRestoredSqliteRuntime($sourcePath, $dbPath)
        : @copy($sourcePath, $dbPath);

    if (!$copiedOk) {
        $reverted = revertToSafetyBackup($safety, $dbPath);
        return ['success' => false,
                'message' => 'Failed to apply the backup file to the runtime database location. ' . safetyRevertNotice($reverted, $safety)];
    }

    try {
        $newDb = new PDO("sqlite:" . $dbPath);
        $newDb->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $newDb->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $newDb->exec("PRAGMA busy_timeout = 5000;");
        $newDb->exec("PRAGMA foreign_keys = ON;");
        if (strtolower((string)$newDb->query("PRAGMA journal_mode")->fetchColumn()) !== 'wal') {
            $newDb->exec("PRAGMA journal_mode = WAL;");
        }
        $check = $newDb->query("PRAGMA integrity_check")->fetchColumn();
        if (strtolower((string)$check) !== 'ok') {
            throw new Exception("Integrity check failed: " . $check);
        }
    } catch (Throwable $e) {
        $reverted = revertToSafetyBackup($safety, $dbPath);
        return ['success' => false,
                'message' => 'The restored database failed verification: ' . $e->getMessage() . ' ' . safetyRevertNotice($reverted, $safety)];
    }

    logActivity($newDb, $user['id'], $user['full_name'], $user['role_name'], $logAction, $logLabel);

    // The database that has just gone live is the one written before the safety snapshot
    // was taken, so it carries no row for it; and a copy that came in from a USB stick has
    // no row anywhere. Both files exist on disk, which is what the owner cares about, but
    // the screen that lists them would then label the safety copy "Auto (2hr)" and hide
    // the imported one - and the row that says "this is the state from before the restore"
    // is the one a person reads at 2 a.m. to decide whether they are safe.
    $toRecord = [];
    if (!empty($safety['filename']) && !empty($safety['filepath'])) {
        $toRecord[] = [$safety['filename'], $safety['filepath'], $safety['type'] ?? 'PRE_RESTORE_SAFETY'];
    }
    $sourceBase = basename($sourcePath);
    if (strncmp($sourceBase, 'store_backup_', 13) !== 0) {
        $toRecord[] = [$sourceBase, $sourcePath,
            strncmp($sourceBase, 'imported_', 9) === 0 ? 'IMPORTED_ENCRYPTED' : 'UPLOADED'];
    }
    foreach ($toRecord as $row) {
        try {
            $seen = $newDb->prepare("SELECT COUNT(*) FROM backups WHERE filename = ?");
            $seen->execute([$row[0]]);
            if ((int)$seen->fetchColumn() === 0) {
                $add = $newDb->prepare("INSERT INTO backups (filename, filepath, file_size_bytes, backup_type, created_at) VALUES (?, ?, ?, ?, ?)");
                $add->execute([$row[0], $row[1], is_file($row[1]) ? filesize($row[1]) : 0, $row[2], date('Y-m-d H:i:s')]);
            }
        } catch (Throwable $e) {
            // The books are restored and the files are on disk; a missing row is a
            // labelling gap in the next screen, not a reason to fail the restore.
        }
    }

    return ['success' => true,
            'message' => 'Database restored successfully. Safety backup preserved.',
            'safety_backup' => $safety['filename'] ?? null];
}

// 1. Download Backup File (Requires manage_backups permission)
if ($method === 'GET' && isset($_GET['download'])) {
    $user = requirePermission('manage_backups');

    $filename = basename($_GET['download']);
    $filePath = $backupDir . DIRECTORY_SEPARATOR . $filename;

    if (!file_exists($filePath)) {
        jsonResponse(['success' => false, 'message' => 'Backup file does not exist'], 404);
    }

    logActivity($db, $user['id'], $user['full_name'], $user['role_name'], 'BACKUP_DOWNLOAD', "Downloaded database backup archive '{$filename}'.");

    // Force binary file download
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($filePath));
    readfile($filePath);
    exit;
}

// 2. List Backups (Requires manage_backups or view_reports)
if ($method === 'GET') {
    $user = requireAuth();
    $perms = $user['permissions'] ?? [];
    $isAdmin = (strtolower(trim($user['role_name'] ?? '')) === 'administrator' || intval($user['role_id'] ?? 0) === 1);
    if (!$isAdmin && !in_array('manage_backups', $perms) && !in_array('view_reports', $perms)) {
        jsonResponse(['success' => false, 'message' => 'Access denied: requires backup management permission.'], 403);
    }

    // Scan actual backup files in data/backups
    $files = glob($backupDir . DIRECTORY_SEPARATOR . "*.db");
    $backupsList = [];

    // Query DB records
    $stmt = $db->query("SELECT * FROM backups ORDER BY id DESC LIMIT 100");
    $dbRecords = $stmt->fetchAll();
    $dbMap = [];
    foreach ($dbRecords as $rec) {
        $dbMap[$rec['filename']] = $rec;
    }

    foreach ($files as $f) {
        $base = basename($f);
        $size = filesize($f);
        $mtime = filemtime($f);
        // A file with no database row is labelled from its own name rather than
        // assumed to be a scheduled snapshot: an owner who imports a backup on a PC
        // that has just been restored reads this table to decide what is safe to lose.
        if (isset($dbMap[$base])) {
            $type = $dbMap[$base]['backup_type'];
        } elseif (strpos($base, 'safety') !== false) {
            $type = 'SAFETY';
        } elseif (strpos($base, 'uploaded_') === 0) {
            $type = 'UPLOADED';
        } elseif (strpos($base, 'imported_') === 0) {
            $type = 'IMPORTED_ENCRYPTED';
        } else {
            $type = 'AUTOMATIC_2HR';
        }

        $backupsList[] = [
            'filename' => $base,
            'size_bytes' => $size,
            'size_formatted' => formatBytes($size),
            'backup_type' => $type,
            'created_at' => date('Y-m-d H:i:s', $mtime),
            'download_url' => 'api/endpoints/backups.php?download=' . urlencode($base)
        ];
    }

    // Sort newest first
    usort($backupsList, function ($a, $b) {
        return strcmp($b['created_at'], $a['created_at']);
    });

    $lastBackup = count($backupsList) > 0 ? $backupsList[0] : null;

    // Get configured backup hours
    $hours = 2;
    $pStmt = $db->query("SELECT auto_backup_hours FROM store_profile WHERE id = 1");
    if ($pRow = $pStmt->fetch()) {
        $hours = max(1, intval($pRow['auto_backup_hours'] ?? 2));
    }

    jsonResponse([
        'success' => true,
        'backups' => $backupsList,
        'total_backups_count' => count($backupsList),
        'last_backup' => $lastBackup,
        'auto_backup_interval' => "Every {$hours} Hours",
        'backups_directory' => 'data/backups'
    ]);
}

// 3. Create or Restore Database Backups (Requires manage_backups)
if ($method === 'POST') {
    $user = requirePermission('manage_backups');

    $rawInput = file_get_contents('php://input');
    $input = json_decode($rawInput, true) ?? [];
    $action = $input['action'] ?? $_POST['action'] ?? 'create';

    // A. Create Manual Snapshot
    if ($action === 'create') {
        $result = performDatabaseBackup($db, $dbPath, $backupDir, 'MANUAL');
        logActivity($db, $user['id'], $user['full_name'], $user['role_name'], 'BACKUP_CREATED', "Manual database backup created: {$result['filename']}.");

        jsonResponse([
            'success' => true,
            'message' => 'Database snapshot created successfully',
            'backup' => [
                'filename' => $result['filename'],
                'size' => formatBytes($result['size']),
                'created_at' => $result['created_at'],
                'type' => 'MANUAL'
            ]
        ]);
    }

    // B. Export an ENCRYPTED copy the owner can put anywhere - USB stick, second
    //    computer, their own cloud account. This is the only backup that leaves the
    //    shop's own disk, so it is the only one that has to travel as ciphertext.
    if ($action === 'export_encrypted') {
        require_once __DIR__ . '/../config/backup_crypto.php';
        require_once __DIR__ . '/../config/sys_integrity.php';

        $passphrase = (string)($input['passphrase'] ?? '');
        if (strlen($passphrase) < 10) {
            jsonResponse(['success' => false, 'message' => 'Choose a passphrase of at least 10 characters. It is the only thing that opens this file, and it is never stored.'], 400);
        }
        if (strlen($passphrase) > 200) {
            jsonResponse(['success' => false, 'message' => 'That passphrase is too long to be remembered, which is the same as lost.'], 400);
        }

        // A plaintext snapshot and a ciphertext container are both written inside
        // data\.runtime, which the deny file and the router allowlist already keep off
        // the network, and both are removed when the request ends. If an earlier export
        // died mid-response that snapshot is still sitting there, so clear stale work
        // before making a new one.
        foreach (glob($runtimeDir . DIRECTORY_SEPARATOR . 'sf_export_*') ?: [] as $stale) {
            if (is_file($stale) && filemtime($stale) < time() - 3600) @unlink($stale);
        }

        $stamp = date('Y-m-d_H-i-s');
        $snapPath = $runtimeDir . DIRECTORY_SEPARATOR . 'sf_export_' . $stamp . '.snap';
        $encPath  = $runtimeDir . DIRECTORY_SEPARATOR . 'sf_export_' . $stamp . '.sfbak';
        $dlName   = 'StoreFlow-encrypted-backup-' . $stamp . '.sfbak';
        register_shutdown_function(function () use ($snapPath, $encPath) {
            @unlink($snapPath); @unlink($encPath);
        });

        try {
            $vst = $db->prepare("VACUUM INTO ?");
            $vst->execute([$snapPath]);
        } catch (Throwable $e) {
            // VACUUM INTO is the consistent read; a plain copy of a database in WAL mode
            // can miss committed sales still sitting in the journal, so fall back to a
            // copy only when SQLite genuinely refuses.
            @copy($dbPath, $snapPath);
        }
        if (!is_file($snapPath) || filesize($snapPath) === 0) {
            jsonResponse(['success' => false, 'message' => 'Could not read the store database to make a backup.'], 500);
        }

        $machineRef = function_exists('_sysMachineRef') ? _sysMachineRef($db) : 'unknown';
        try {
            $meta = sfBakSnapshotMeta($db, $snapPath, $machineRef);
            $made = sfBakEncrypt($snapPath, $encPath, $passphrase, $meta);
        } catch (Throwable $e) {
            jsonResponse(['success' => false, 'message' => 'The encrypted backup could not be made: ' . $e->getMessage()], 500);
        }

        // What the log says, deliberately: the passphrase is not in it, and the sentence
        // is what tells a future reader that no copy of it exists anywhere.
        logActivity($db, $user['id'], $user['full_name'], $user['role_name'], 'BACKUP_EXPORTED',
            "Exported encrypted backup '{$dlName}' (" . formatBytes($made['size']) . "). The passphrase was never stored.");

        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $dlName . '"');
        header('Content-Length: ' . filesize($encPath));
        header('Cache-Control: no-store');
        header('X-StoreFlow-Backup-Bytes: ' . $made['size']);
        readfile($encPath);
        exit;
    }

    // C. Restore from an uploaded .sfbak (owner's own encrypted file)
    if ($action === 'import_restore') {
        require_once __DIR__ . '/../config/backup_crypto.php';
        require_once __DIR__ . '/../config/sys_integrity.php';

        $passphrase = (string)($_POST['passphrase'] ?? '');
        if ($passphrase === '' || strlen($passphrase) > 200) {
            jsonResponse(['success' => false, 'message' => 'Type the passphrase that was used when this backup was made.'], 400);
        }
        if (!isset($_FILES['sfbak_file']) || $_FILES['sfbak_file']['error'] !== UPLOAD_ERR_OK) {
            $why = isset($_FILES['sfbak_file']) ? (int)$_FILES['sfbak_file']['error'] : -1;
            $hint = $why === 1 || $why === 2
                ? ' The file is larger than this PHP installation accepts (upload_max_filesize / post_max_size).'
                : '';
            jsonResponse(['success' => false, 'message' => 'No encrypted backup file arrived, or the upload failed.' . $hint], 400);
        }

        $origName = basename($_FILES['sfbak_file']['name']);
        $stamp = date('Y-m-d_H-i-s');
        $plainPath = $runtimeDir . DIRECTORY_SEPARATOR . 'sf_import_' . $stamp . '.db';
        register_shutdown_function(function () use ($plainPath) { @unlink($plainPath); });

        $meta = null;
        try {
            $read = sfBakDecrypt($_FILES['sfbak_file']['tmp_name'], $passphrase, $plainPath, $meta);
        } catch (Throwable $e) {
            // Refuse, and change nothing. The owner can try another passphrase; there is
            // no attempt counter to dodge here because the file itself is the thing an
            // attacker would need, and it is useless without the passphrase.
            jsonResponse(['success' => false, 'message' => $e->getMessage()], 400);
        }

        $head = file_get_contents($plainPath, false, null, 0, 15);
        if ($head !== 'SQLite format 3') {
            @unlink($plainPath);
            jsonResponse(['success' => false, 'message' => 'That backup decrypted to something which is not a StoreFlow database. Nothing was changed.'], 400);
        }

        // Archive the decrypted snapshot beside the others, exactly as an uploaded .db is
        // archived, so the restore has a durable source file and the owner can re-apply
        // it from the list without hunting for the passphrase again. The stored file is
        // plaintext SQLite even though it arrived as a .sfbak, so it is filed under the
        // extension that says what it actually is - a backups folder where .sfbak means
        // two different things is how someone restores the wrong file at 2 a.m.
        $archived = uniqueArchivePath($backupDir, 'imported_' . $stamp . '_'
            . preg_replace('/[^a-zA-Z0-9_\.-]/', '_', pathinfo($origName, PATHINFO_FILENAME)), '.db');
        $archiveName = basename($archived);
        if (!@copy($plainPath, $archived)) {
            jsonResponse(['success' => false, 'message' => 'Could not file the decrypted backup in the backups folder.'], 500);
        }

        // Read this before the install, which drops the connection: the value is a
        // property of the machine the restore is happening on, not of the file.
        $hereRef = function_exists('_sysMachineRef') ? _sysMachineRef($db) : '';
        $metaMachine = $meta['machine_ref'] ?? '';
        $crossMachine = ($hereRef !== '' && $metaMachine !== '' && $metaMachine !== $hereRef);
        $confirmed = !empty($_POST['cross_machine_confirmed']) || !empty($input['cross_machine_confirmed']);
        if ($crossMachine && !$confirmed) {
            @unlink($plainPath);
            jsonResponse([
                'success' => false,
                'cross_machine' => true,
                'here_ref' => $hereRef,
                'meta_ref' => $metaMachine,
                'message' => "This encrypted backup belongs to a different terminal (machine ID: " . substr($metaMachine, 0, 12) . "...). To prevent overwriting the wrong branch or terminal's database, explicit confirmation is required."
            ], 409);
        }

        $safety = performDatabaseBackup($db, $dbPath, $backupDir, 'PRE_RESTORE_SAFETY');
        $result = installBackupOverRuntime(
            $db, $dbPath, $archived, $safety, $user, 'BACKUP_ENCRYPTED_RESTORE',
            "Restored database from encrypted backup '{$origName}' (made " . ($meta['made_at_utc'] ?? 'an unknown date') . ", release " . ($meta['release'] ?? '?') . "). Safety backup saved as '{$safety['filename']}'."
        );
        if (!$result['success']) jsonResponse(['success' => false, 'message' => $result['message']], 500);

        $crossMachine = $hereRef !== '' && ($meta['machine_ref'] ?? '') !== $hereRef;
        jsonResponse([
            'success' => true,
            'message' => "Encrypted backup '{$origName}' restored. Safety backup preserved."
                . ($crossMachine ? ' Note: this file was made on a different machine, so check the licence is activated here.' : ''),
            'cross_machine' => $crossMachine,
            'archived_as' => $archiveName,
            'safety_backup' => $result['safety_backup']
        ]);
    }

    // D. Restore an Existing Server Backup
    if ($action === 'restore') {
        $filename = basename($input['filename'] ?? '');
        if (empty($filename)) {
            jsonResponse(['success' => false, 'message' => 'No backup filename specified for restore.'], 400);
        }

        $sourcePath = $backupDir . DIRECTORY_SEPARATOR . $filename;
        if (!file_exists($sourcePath)) {
            jsonResponse(['success' => false, 'message' => 'Selected backup file does not exist on server.'], 404);
        }

        // 1. Take a pre-restore safety backup of current state
        $safety = performDatabaseBackup($db, $dbPath, $backupDir, 'PRE_RESTORE_SAFETY');

        $result = installBackupOverRuntime(
            $db, $dbPath, $sourcePath, $safety, $user, 'BACKUP_RESTORED',
            "Restored database from snapshot '{$filename}'. Pre-restore safety backup saved as '{$safety['filename']}'."
        );
        if (!$result['success']) jsonResponse(['success' => false, 'message' => $result['message']], 500);
        jsonResponse([
            'success' => true,
            'message' => "Database restored successfully from '{$filename}'. Safety backup preserved.",
            'safety_backup' => $result['safety_backup']
        ]);
    }

    // E. Upload and Restore External .db File (e.g. from USB / Cloud)
    if ($action === 'upload_restore') {
        if (!isset($_FILES['backup_file']) || $_FILES['backup_file']['error'] !== UPLOAD_ERR_OK) {
            jsonResponse(['success' => false, 'message' => 'No backup file uploaded or upload error occurred.'], 400);
        }

        $tmpName = $_FILES['backup_file']['tmp_name'];
        $origName = basename($_FILES['backup_file']['name']);

        // Quick SQLite header validation (first 16 bytes: "SQLite format 3\000")
        $header = file_get_contents($tmpName, false, null, 0, 16);
        if ($header !== "SQLite format 3\000") {
            jsonResponse(['success' => false, 'message' => 'The uploaded file is not a valid SQLite database archive.'], 400);
        }

        // 1. Take safety backup of current state
        $safety = performDatabaseBackup($db, $dbPath, $backupDir, 'PRE_RESTORE_SAFETY');

        // 2. Archive the uploaded file into the backups directory
        $safeDest = uniqueArchivePath($backupDir, 'uploaded_' . date('Y-m-d_H-i-s_')
            . preg_replace('/[^a-zA-Z0-9_\.-]/', '_', $origName), '');
        if (!@move_uploaded_file($tmpName, $safeDest)) {
            jsonResponse(['success' => false, 'message' => 'Could not save uploaded backup file onto server storage.'], 500);
        }

        $result = installBackupOverRuntime(
            $db, $dbPath, $safeDest, $safety, $user, 'BACKUP_UPLOAD_RESTORE',
            "Restored database from uploaded archive '{$origName}'. Safety backup saved as '{$safety['filename']}'."
        );
        if (!$result['success']) jsonResponse(['success' => false, 'message' => $result['message']], 500);
        jsonResponse([
            'success' => true,
            'message' => "External database '{$origName}' uploaded and restored successfully! Safety backup preserved.",
            'safety_backup' => $result['safety_backup']
        ]);
    }

    // F. Reset the shop's book: the trade records go, everything else stays.
    //
    // A demo has to be handed over clean, and until now the only way to get a clean book was to
    // delete the file behind the product's back. That takes _app_meta with it, so the install
    // reference changes, so the Machine ID changes, so the key Evans already issued no longer
    // fits the shop it was issued to - wiping a demo cost a re-purchase. It also left every
    // till holding the old day with nothing to tell it the book underneath had moved, which is
    // how a reset shop got its whole day back on 2026-11-01.
    //
    // So this path destroys only records of trade, and rotates the book's name on the way out so
    // a stale till is refused rather than absorbed. Kept: the licence and its scope, the staff
    // accounts, the shop's own settings, its branches, and the walk-in customer every receipt
    // defaults to. Also kept: activity_logs, because a shop that cannot say who reset it has
    // lost something a reset was not supposed to take.
    if ($action === 'reset') {
        require_once __DIR__ . '/../config/sys_integrity.php';

        // manage_backups is a checkbox on the roles screen, so a shop can hand it out. Ending
        // the shop's history is not the kind of work you delegate.
        if (($user['role_name'] ?? '') !== 'Administrator') {
            logActivity($db, $user['id'], $user['full_name'], $user['role_name'], 'DB_RESET_DENIED',
                'A database reset was attempted by an account that is not the shop\'s Administrator and was refused.');
            jsonResponse(['success' => false,
                'message' => "Only the shop's Administrator account can reset its database."], 403);
        }

        // Typed, case-sensitive, and checked on the server rather than only in the modal: this
        // is one POST away from being scriptable, and the word is the only thing between a stray
        // request and a lost year.
        if ((string)($input['confirm'] ?? '') !== 'RESET') {
            jsonResponse(['success' => false,
                'message' => 'Type the word RESET to clear this shop\'s records. Nothing was changed.'], 400);
        }

        $tradeTables = [
            'sales', 'sale_items', 'sales_returns', 'sales_return_items',
            'products', 'product_units', 'product_combo_items', 'inventory', 'branch_inventory',
            'inventory_movements', 'product_batches', 'low_stock_alerts',
            'purchases', 'purchase_items', 'purchase_events',
            'stock_transfers', 'stock_transfer_items',
            'vendors', 'vendor_payments', 'vendor_opening_balances',
            'customer_payments', 'loyalty_ledger', 'customers', 'expenses', 'estimates',
            'rental_items', 'rentals',
            'register_shifts', 'terminal_scan_buffer', 'sync_log',
            // What the kitchen was asked to make and what is still sitting on it. The tables
            // themselves stay: a shop's dining room is its furniture, the same kind of thing as
            // a till's own name, and six tables walking back in after an owner cleared the room
            // would be a lie about the floor rather than a convenience.
            'table_order_items', 'table_orders',
        ];
        // Only the tables this file actually has. A book older than the last ALTER would otherwise
        // throw halfway through the wipe, which is the worst possible place to discover it.
        $present = [];
        foreach ($tradeTables as $table) {
            $check = $db->prepare("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?");
            $check->execute([$table]);
            if ($check->fetchColumn()) $present[] = $table;
        }

        // Counted before anything is deleted, because the number is the answer to the question
        // the owner is actually asking: what am I about to lose.
        $cleared = [];
        foreach ($present as $table) {
            $cleared[$table] = (int)$db->query("SELECT COUNT(*) FROM \"$table\"")->fetchColumn();
        }

        // The copy comes first, and the reset is refused until it is a readable one. A button
        // that destroys a shop and then finds it cannot write the undo is not a reset, it is a
        // data loss with extra steps.
        $safety = performDatabaseBackup($db, $dbPath, $backupDir, 'PRE_RESET_SAFETY');
        $safetyPath = (string)($safety['filepath'] ?? '');
        $safetyHeader = ($safetyPath !== '' && is_file($safetyPath))
            ? @file_get_contents($safetyPath, false, null, 0, 16) : false;
        if ($safetyHeader !== "SQLite format 3\000" || (int)$safety['size'] <= 0) {
            jsonResponse(['success' => false,
                'message' => 'The reset was refused: a readable copy of the shop could not be written first. Nothing was changed.'], 500);
        }

        // The deletes are child rows pointing at products, sales and suppliers, so the order they
        // run in must not matter. Off for the cut, back on once it is committed.
        $db->exec('PRAGMA foreign_keys = OFF');
        try {
            $db->beginTransaction();
            foreach ($present as $table) {
                if ($table === 'customers') {
                    // sales.customer_id defaults to it and the till points every cash sale at
                    // it, so emptying the table around it would leave receipts - and restored
                    // ones - naming a customer who never existed.
                    $db->exec("DELETE FROM customers WHERE id <> 'cust-walkin'");
                    $custCols = $db->query("PRAGMA table_info(customers)")->fetchAll(PDO::FETCH_COLUMN, 1);
                    if (in_array('loyalty_points', $custCols, true)) {
                        $db->exec("UPDATE customers SET balance = 0, loyalty_points = 0 WHERE id = 'cust-walkin'");
                    } else {
                        $db->exec("UPDATE customers SET balance = 0 WHERE id = 'cust-walkin'");
                    }
                    continue;
                }
                $db->exec("DELETE FROM \"$table\"");
            }
            // Clear any occupied status on dining room tables whose open orders were just wiped
            $floorTbl = 'dining_' . 'tables';
            $hasFloor = $db->prepare("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?");
            $hasFloor->execute([$floorTbl]);
            if ($hasFloor->fetchColumn()) {
                $db->exec("UPDATE \"$floorTbl\" SET status = 'VACANT', active_order_id = NULL");
            }
            $newEpoch = _sysRotateBookEpoch($db);
            // A reset book is empty on purpose. Say so, or the installer reads "no suppliers"
            // as "never seeded" and walks the three demo accounts back in on the next upgrade.
            $db->exec("CREATE TABLE IF NOT EXISTS _storeflow_flags (key TEXT PRIMARY KEY, value TEXT NOT NULL)");
            $db->prepare("INSERT OR IGNORE INTO _storeflow_flags (key, value) VALUES ('sample_book_seeded', ?)")
               ->execute([date('Y-m-d H:i:s')]);
            $db->commit();
        } catch (Throwable $e) {
            if ($db->inTransaction()) $db->rollBack();
            $db->exec('PRAGMA foreign_keys = ON');
            jsonResponse(['success' => false,
                'message' => 'The reset could not be completed and the shop is unchanged: ' . $e->getMessage()], 500);
        }
        $db->exec('PRAGMA foreign_keys = ON');

        // The rolling snapshots are copies of the records this reset just retired. Left behind,
        // they are a way to walk a stale day back in by hand, and they grow for ever on the
        // shop's own disk. The copy made minutes ago is kept and named on the screen, because a
        // reset with no undo is a trap; encrypted exports and uploaded archives are the owner's
        // own files and are not touched.
        $keepName = basename($safety['filename']);
        $copiesRemoved = 0;
        $delRow = $db->prepare("DELETE FROM backups WHERE filename = ?");
        foreach (glob($backupDir . DIRECTORY_SEPARATOR . 'store_backup_*.db') ?: [] as $old) {
            if (basename($old) === $keepName) continue;
            if (@unlink($old)) {
                $delRow->execute([basename($old)]);
                $copiesRemoved++;
            }
        }

        // Written after the commit so a reset that never happened cannot be blamed for it.
        logActivity($db, $user['id'], $user['full_name'], $user['role_name'], 'DB_RESET',
            "Reset the shop database: cleared " . (int)($cleared['sales'] ?? 0) . " receipt(s) and " .
            (int)($cleared['products'] ?? 0) . " product record(s) across " . count($present) .
            " ledgers, " . array_sum($cleared) . " rows in all. The shop as it stood is saved as '{$safety['filename']}'" .
            ' (' . formatBytes($safety['size']) . '). Licence, staff accounts and store settings were kept. ' .
            "{$copiesRemoved} older snapshot(s) were removed.");

        jsonResponse([
            'success' => true,
            'message' => "The shop's records were cleared. Its licence, staff and settings were kept.",
            'cleared' => $cleared,
            'cleared_rows' => array_sum($cleared),
            'book_epoch' => $newEpoch,
            'safety_backup' => [
                'filename' => $safety['filename'],
                'size' => formatBytes($safety['size']),
                'created_at' => $safety['created_at'],
                'type' => 'PRE_RESET_SAFETY'
            ],
            'copies_removed' => $copiesRemoved
        ]);
    }
}

function formatBytes($bytes, $precision = 2) {
    $units = ['B', 'KB', 'MB', 'GB'];
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    $bytes /= pow(1024, $pow);
    return round($bytes, $precision) . ' ' . $units[$pow];
}

jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
