<?php
// api/endpoints/branches.php
// Multi-Store Branch Directory & Location Registry Endpoint
require_once __DIR__ . '/../config/db.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET') {
    $authUser = requireAuth();

    $activeOnly = isset($_GET['active_only']) && $_GET['active_only'] == '1';
    // A voided receipt turned no money at all, so it is not this branch's turnover and not one of
    // its transactions. COALESCE because a row written by an import can carry no status, and in
    // SQLite NULL <> 'VOID' is not true - it is unknown, and the receipt would vanish.
    $sql = "SELECT b.*,
            (SELECT COUNT(*) FROM sales s WHERE s.branch_code = b.branch_code AND COALESCE(s.status, '') <> 'VOID') as total_sales_count,
            (SELECT COALESCE(SUM(s.total_amount), 0) FROM sales s WHERE s.branch_code = b.branch_code AND COALESCE(s.status, '') <> 'VOID') as total_revenue
            FROM branches b";

    if ($activeOnly) {
        $sql .= " WHERE b.is_active = 1";
    }

    $sql .= " ORDER BY b.is_active DESC, b.name ASC";
    $stmt = $db->query($sql);
    $branches = $stmt->fetchAll();

    // The till needs the branch list to pick a shelf; it does not need each shop's turnover.
    // Sales totals are report data, so they travel with the reports permission only.
    if (!hasPermission($authUser, 'view_reports')) {
        foreach ($branches as &$branchRow) {
            unset($branchRow['total_sales_count'], $branchRow['total_revenue']);
        }
        unset($branchRow);
    }

    jsonResponse([
        'success' => true,
        'branches' => $branches,
        'count' => count($branches)
    ]);
}

if ($method === 'POST') {
    $authUser = requirePermission('manage_settings');
    $data = getJsonInput();
    $action = trim($data['action'] ?? 'save');

    if ($action === 'toggle_status') {
        $id = trim($data['id'] ?? '');
        if (empty($id)) {
            jsonResponse(['success' => false, 'message' => 'Branch ID required.'], 400);
        }

        // Prevent deactivating if it's the only active branch
        $activeCount = $db->query("SELECT COUNT(*) as count FROM branches WHERE is_active = 1")->fetch()['count'];
        $current = $db->prepare("SELECT is_active, name, branch_code FROM branches WHERE id = ?");
        $current->execute([$id]);
        $branch = $current->fetch();

        if (!$branch) {
            jsonResponse(['success' => false, 'message' => 'Branch not found.'], 404);
        }

        if ($branch['is_active'] == 1 && $activeCount <= 1) {
            jsonResponse(['success' => false, 'message' => 'Cannot deactivate the sole active branch in the system.'], 400);
        }

        $newStatus = $branch['is_active'] == 1 ? 0 : 1;
        $upd = $db->prepare("UPDATE branches SET is_active = ?, updated_at = datetime('now') WHERE id = ?");
        $upd->execute([$newStatus, $id]);

        logActivity($db, $authUser['id'], $authUser['full_name'], $authUser['role_name'], 'BRANCH_TOGGLE', 
            ($newStatus ? 'Activated' : 'Deactivated') . " branch '{$branch['name']}' ({$branch['branch_code']}).");

        jsonResponse([
            'success' => true,
            'message' => "Branch {$branch['name']} " . ($newStatus ? 'activated' : 'deactivated') . " successfully."
        ]);
    }

    // Standard Save / Edit Branch
    $id = trim($data['id'] ?? '');
    $branchCode = strtoupper(preg_replace('/[^A-Za-z0-9\-_]/', '', trim($data['branch_code'] ?? '')));
    $name = trim($data['name'] ?? '');
    $address = trim($data['address'] ?? '');
    $phone = trim($data['phone'] ?? '');
    $managerName = trim($data['manager_name'] ?? '');
    $isActive = isset($data['is_active']) ? intval($data['is_active']) : 1;

    if (empty($branchCode)) {
        jsonResponse(['success' => false, 'message' => 'Branch Code is required (e.g. MAIN-01, NORTH-02).'], 400);
    }
    if (empty($name)) {
        jsonResponse(['success' => false, 'message' => 'Branch Name is required.'], 400);
    }

    // Check code uniqueness
    $codeCheck = $db->prepare("SELECT id FROM branches WHERE branch_code = ? AND id != ?");
    $codeCheck->execute([$branchCode, $id]);
    if ($codeCheck->fetch()) {
        jsonResponse(['success' => false, 'message' => "A branch with code '{$branchCode}' already exists."], 400);
    }

    if (!empty($id)) {
        $stmt = $db->prepare("UPDATE branches SET 
            branch_code = ?,
            name = ?,
            address = ?,
            phone = ?,
            manager_name = ?,
            is_active = ?,
            updated_at = datetime('now')
            WHERE id = ?");
        $stmt->execute([$branchCode, $name, $address, $phone, $managerName, $isActive, $id]);

        logActivity($db, $authUser['id'], $authUser['full_name'], $authUser['role_name'], 'BRANCH_UPDATE', 
            "Updated branch profile '{$name}' ({$branchCode}).");

        jsonResponse([
            'success' => true,
            'message' => 'Branch updated successfully.',
            'branch' => [
                'id' => $id,
                'branch_code' => $branchCode,
                'name' => $name
            ]
        ]);
    } else {
        $newId = 'branch_' . bin2hex(random_bytes(6));
        $stmt = $db->prepare("INSERT INTO branches (id, branch_code, name, address, phone, manager_name, is_active, created_at, updated_at) 
                              VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))");
        $stmt->execute([$newId, $branchCode, $name, $address, $phone, $managerName, $isActive]);

        logActivity($db, $authUser['id'], $authUser['full_name'], $authUser['role_name'], 'BRANCH_CREATE', 
            "Created new branch location '{$name}' ({$branchCode}).");

        jsonResponse([
            'success' => true,
            'message' => 'New branch created successfully.',
            'branch' => [
                'id' => $newId,
                'branch_code' => $branchCode,
                'name' => $name
            ]
        ], 201);
    }
}

jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
