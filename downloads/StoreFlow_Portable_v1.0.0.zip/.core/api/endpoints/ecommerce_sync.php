<?php
// api/endpoints/ecommerce_sync.php
// StoreFlow Omnichannel E-Commerce Bridge: WooCommerce, Shopify and hand-rolled storefronts.
//
// An online order is a request for goods, not a receipt. Nothing in this file writes money or
// touches the shelf. A verified order arrives as a quotation (api/endpoints/estimates.php)
// priced the way this shop's shelf prices it, and the counter decides whether it becomes a
// sale - the same rule the dining floor works under, for the same reason: whoever asked for
// the goods does not get to say what they cost, what left the shelf, or whether they were
// paid for. A storefront posting a total of GH₵1.00 for GH₵200.00 of goods used to be booked
// as a completed sale, and the shop's takings then carried money nobody had handed over.
//
// Proof of who is posting is an HMAC-SHA256 of the raw body under the shop's own secret,
// STOREFLOW_ECOMMERCE_SECRET in api/config/config.php. There is no shipped default: a till
// that has not set one refuses every order and says why, rather than quietly accepting
// anything a stranger addresses to it.

require_once __DIR__ . '/../config/db.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$action = trim($_GET['action'] ?? 'status');

// The shop's own webhook secret, or '' when the shop has not chosen one yet. An empty secret
// is never a valid secret, so every caller of this must treat '' as "closed".
function ecommerceSecret(): string {
    $fromConfig = defined('STOREFLOW_ECOMMERCE_SECRET') ? trim((string)STOREFLOW_ECOMMERCE_SECRET) : '';
    if ($fromConfig !== '') return $fromConfig;
    $fromEnv = getenv('STOREFLOW_ECOMMERCE_SECRET');
    return is_string($fromEnv) ? trim($fromEnv) : '';
}

// WooCommerce signs the body as lowercase hex, Shopify as base64, and either form is accepted
// on the generic header a custom storefront can set. Only one header is trusted per request,
// in this order, so a request that presents two signatures in different formats cannot be made
// to pass on the one the shop did not intend to send.
function ecommerceSignature(array $server): array {
    foreach ([
        'HTTP_X_WC_WEBHOOK_SIGNATURE' => 'WooCommerce',
        'HTTP_X_SHOPIFY_HMAC_SHA256'  => 'Shopify',
        'HTTP_X_STOREFLOW_SIGNATURE'  => 'Webhook',
    ] as $header => $label) {
        $value = trim((string)($server[$header] ?? ''));
        if ($value !== '') return [$header, $value, $label];
    }
    return ['', '', ''];
}

function ecommerceMoney(float $amount): string {
    return 'GH₵' . number_format($amount, 2);
}

// -------------------------------------------------------------
// 1. GET /api/endpoints/ecommerce_sync.php?action=status
// What the bridge is holding, and whether it is open at all.
// -------------------------------------------------------------
if ($method === 'GET' && $action === 'status') {
    requireAuth();
    $waiting = $db->prepare("SELECT COUNT(*) AS n, COALESCE(SUM(total_amount), 0.0) AS v
                             FROM estimates
                             WHERE external_ref IS NOT NULL AND external_ref != '' AND status = 'PENDING'");
    $waiting->execute();
    $waitingRow = $waiting->fetch() ?: ['n' => 0, 'v' => 0];
    $collected = $db->prepare("SELECT COUNT(*) FROM estimates
                               WHERE external_ref IS NOT NULL AND external_ref != '' AND status = 'CONVERTED'");
    $collected->execute();

    jsonResponse([
        'success' => true,
        'channel' => 'StoreFlow Omnichannel E-Commerce Bridge',
        // 'open' is the honest word for the only state that matters to the shopkeeper: with no
        // secret of its own the bridge takes nothing, and an online store retrying against a
        // closed door is a complaint the shop will not see until the orders are gone.
        'status' => ecommerceSecret() !== '' ? 'open' : 'closed_no_secret',
        'secret_configured' => ecommerceSecret() !== '',
        'stats' => [
            'orders_waiting' => intval($waitingRow['n']),
            'orders_waiting_value' => round(floatval($waitingRow['v']), 2),
            'orders_collected' => intval($collected->fetchColumn()),
        ],
        'booked_note' => 'An online order is booked when the counter rings it, not when the storefront posts it.',
        'supported_platforms' => ['WooCommerce', 'Shopify', 'Custom Webhooks'],
        'signature_headers' => ['X-WC-Webhook-Signature (hex HMAC-SHA256)',
                                'X-Shopify-Hmac-Sha256 (base64 HMAC-SHA256)',
                                'X-Storeflow-Signature (either form)'],
    ]);
}

// -------------------------------------------------------------
// 2. GET /api/endpoints/ecommerce_sync.php?action=export_stock
// The shelf, for a storefront that must not sell what is not there.
// -------------------------------------------------------------
if ($method === 'GET' && $action === 'export_stock') {
    $secret = ecommerceSecret();
    $token = trim($_GET['token'] ?? '');
    if ($token === '') {
        $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        if (preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) $token = trim($matches[1]);
    }

    $authorized = ($secret !== '' && $token !== '' && hash_equals($secret, $token));
    if (!$authorized) {
        // A signed-in manager may poll it from the bridge page; a cashier session may not,
        // and neither is the door an online store is meant to come through.
        $user = getCurrentUser();
        $authorized = $user !== null && hasPermission($user, 'manage_settings');
    }
    if (!$authorized) {
        jsonResponse([
            'success' => false,
            'message' => $secret === ''
                ? 'The stock feed is closed on this till: set STOREFLOW_ECOMMERCE_SECRET in api/config/config.php first, then point the storefront at it.'
                : 'The stock feed needs the token this till was given, as ?token=... or an Authorization: Bearer header.'
        ], 401);
    }

    $stmt = $db->query("SELECT p.id, p.name, p.barcode, p.sku, COALESCE(i.current_quantity, 0.0) as stock_quantity, p.selling_price, p.is_active
                        FROM products p
                        LEFT JOIN inventory i ON p.id = i.product_id
                        WHERE p.is_active = 1");
    $catalog = $stmt->fetchAll();

    jsonResponse([
        'success' => true,
        'timestamp' => date('Y-m-d H:i:s'),
        'item_count' => count($catalog),
        'inventory' => $catalog
    ]);
}

// -------------------------------------------------------------
// 3. POST /api/endpoints/ecommerce_sync.php?action=webhook
// A storefront saying a customer has asked for goods.
// -------------------------------------------------------------
if ($method === 'POST' && $action === 'webhook') {
    $secret = ecommerceSecret();
    if ($secret === '') {
        jsonResponse([
            'success' => false,
            'message' => 'This till is not taking online orders yet: it has no webhook secret. Set STOREFLOW_ECOMMERCE_SECRET in api/config/config.php to a long random string, put the same string in the storefront, and post the order again.'
        ], 503);
    }

    $raw = (string)file_get_contents('php://input');
    if (strlen($raw) > 512 * 1024) {
        jsonResponse(['success' => false, 'message' => 'That order is too large for the bridge to read.'], 413);
    }

    // The order has to prove it came from a storefront the shop told about this secret. The
    // signature covers the bytes exactly as they arrived, so the body is never re-encoded
    // before hashing - a reformatted JSON payload hashes differently and would refuse a real
    // order.
    [$signatureHeader, $supplied, $signatureLabel] = ecommerceSignature($_SERVER);
    if ($signatureHeader === '') {
        jsonResponse([
            'success' => false,
            'message' => 'Refused: the order carried no signature. Send X-WC-Webhook-Signature (WooCommerce), X-Shopify-Hmac-Sha256 (Shopify) or X-Storeflow-Signature, each an HMAC-SHA256 of the raw body under the shop secret.'
        ], 401);
    }
    $expectedHex = hash_hmac('sha256', $raw, $secret, false);
    $expectedBase64 = base64_encode(hash_hmac('sha256', $raw, $secret, true));
    // Both forms are tried against the header that arrived, because which one a sender uses is
    // that platform's choice and not a fact the shop can set: WooCommerce core signs lowercase
    // hex, and a gateway that signs the same body in base64 is still telling the truth. What is
    // not on offer is a signature made under some other secret.
    $signed = hash_equals($expectedHex, $supplied)
        || hash_equals($expectedHex, strtolower($supplied))
        || hash_equals($expectedBase64, $supplied);
    if (!$signed) {
        jsonResponse(['success' => false, 'message' => 'Refused: the signature does not match this order under the shop secret.'], 403);
    }

    $data = json_decode($raw, true);
    if (!is_array($data) || $data === []) {
        jsonResponse(['success' => false, 'message' => 'Malformed or empty JSON payload'], 400);
    }

    $platform = 'Online store';
    if (isset($_SERVER['HTTP_X_WC_WEBHOOK_SOURCE']) || isset($_SERVER['HTTP_X_WC_WEBHOOK_TOPIC'])) {
        $platform = 'WooCommerce';
    } elseif (isset($_SERVER['HTTP_X_SHOPIFY_STORE_DOMAIN']) || isset($_SERVER['HTTP_X_SHOPIFY_TOPIC'])) {
        $platform = 'Shopify';
    } elseif ($signatureLabel !== 'Webhook') {
        $platform = $signatureLabel;
    } else {
        $channel = strtolower(trim((string)($_GET['channel'] ?? '')));
        if ($channel === 'woocommerce' || $channel === 'shopify') $platform = ucfirst($channel);
    }

    $externalRef = mb_substr(trim((string)($data['id'] ?? $data['order_number'] ?? '')), 0, 100);
    if ($externalRef === '') {
        jsonResponse(['success' => false, 'message' => 'Missing external order identifier'], 400);
    }

    // A storefront that retries a slow webhook must not leave the shop with two quotations for
    // one customer's order, so the same platform + order number answers with the paper it
    // already produced.
    $seenStmt = $db->prepare("SELECT id, estimate_number, status FROM estimates
                              WHERE platform = ? AND external_ref = ? LIMIT 1");
    $seenStmt->execute([$platform, $externalRef]);
    $already = $seenStmt->fetch(PDO::FETCH_ASSOC);
    if ($already) {
        jsonResponse([
            'success' => true,
            'duplicate' => true,
            'estimate_id' => $already['id'],
            'estimate_number' => $already['estimate_number'],
            'message' => sprintf('%s order #%s is already on the Quotations page as %s (%s). Nothing new was written.',
                $platform, $externalRef, $already['estimate_number'], $already['status'])
        ]);
    }

    $lineItems = $data['line_items'] ?? $data['items'] ?? null;
    if (!is_array($lineItems) || $lineItems === []) {
        jsonResponse(['success' => false, 'message' => 'Order carries no line items'], 400);
    }
    if (count($lineItems) > 200) {
        jsonResponse(['success' => false, 'message' => 'That order has more lines than the bridge will hold in one quotation.'], 400);
    }

    // Who asked, as the storefront told us. Held on the quotation itself, not pushed into the
    // customer book: an unverified name from the internet is not a record of a person the shop
    // has met, and the counter decides whether it becomes one.
    $billing = is_array($data['billing'] ?? null) ? $data['billing'] : (is_array($data['customer'] ?? null) ? $data['customer'] : []);
    $customerName = mb_substr(trim(($billing['first_name'] ?? '') . ' ' . ($billing['last_name'] ?? ''))
        ?: trim((string)($billing['name'] ?? '')) ?: 'Online customer', 0, 120);
    $customerPhone = mb_substr(trim((string)($billing['phone'] ?? $billing['telephone'] ?? '')), 0, 40);
    $customerEmail = mb_substr(trim((string)($billing['email'] ?? '')), 0, 120);

    $findSku = $db->prepare("SELECT id, name, sku, unit, selling_price FROM products
                             WHERE (sku = ? OR barcode = ?) AND is_active = 1 LIMIT 1");
    $findName = $db->prepare("SELECT id, name, sku, unit, selling_price FROM products
                              WHERE name = ? AND is_active = 1 LIMIT 1");

    $items = [];
    $subtotal = 0.0;
    $claimedLines = 0.0;
    $unmatchedNames = [];
    foreach ($lineItems as $line) {
        if (!is_array($line)) continue;
        $name = mb_substr(trim((string)($line['name'] ?? 'Online item')), 0, 150);
        $sku = mb_substr(trim((string)($line['sku'] ?? '')), 0, 60);
        $qty = round(floatval($line['quantity'] ?? 1), 4);
        if ($qty <= 0) $qty = 1.0;
        if ($qty > 100000) $qty = 100000.0;
        // What the storefront says it charged the customer. Kept, but never used as the price
        // the shop promises to sell at.
        $claimedPrice = round(floatval($line['price'] ?? $line['total_price'] ?? 0), 2);

        $prod = false;
        if ($sku !== '') {
            $findSku->execute([$sku, $sku]);
            $prod = $findSku->fetch(PDO::FETCH_ASSOC) ?: false;
        }
        if (!$prod && $name !== '') {
            $findName->execute([$name]);
            $prod = $findName->fetch(PDO::FETCH_ASSOC) ?: false;
        }

        // The shelf's own number where the shop recognises the goods; the claimed number only
        // where it does not, and then flagged so the counter sees it is a price nobody has set.
        $price = $prod ? round(floatval($prod['selling_price']), 2) : $claimedPrice;
        $lineSubtotal = round($price * $qty, 2);
        $subtotal += $lineSubtotal;
        $claimedLines += round($claimedPrice * $qty, 2);

        if (!$prod) $unmatchedNames[] = $name !== '' ? $name : 'a line with no name';

        $items[] = [
            'product_id' => $prod ? $prod['id'] : null,
            'name' => $prod ? $prod['name'] : $name,
            'sku' => $prod ? (string)($prod['sku'] ?? $sku) : $sku,
            'unit' => $prod ? (string)($prod['unit'] ?? 'pcs') : 'pcs',
            'quantity' => $qty,
            'selling_price' => $price,
            'subtotal' => $lineSubtotal,
            'claimed_price' => $claimedPrice,
            'matched' => $prod ? true : false,
        ];
    }

    $subtotal = round($subtotal, 2);
    if ($subtotal <= 0) {
        jsonResponse(['success' => false, 'message' => 'None of the lines on that order have a price this shop can read.'], 400);
    }
    $totalAmount = $subtotal; // the counter adds its own tax and discount when it rings the sale

    $estimateNumber = null;
    $todayPrefix = 'ONL-' . date('Ymd') . '-';
    $countStmt = $db->prepare("SELECT COUNT(*) FROM estimates WHERE estimate_number LIKE ?");
    $countStmt->execute([$todayPrefix . '%']);
    $estimateNumber = $todayPrefix . str_pad(intval($countStmt->fetchColumn()) + 1, 3, '0', STR_PAD_LEFT);

    $claimedOrderTotal = round(floatval($data['total'] ?? $data['total_price'] ?? 0), 2);
    $notes = sprintf(
        "%s order #%s, received %s. %s",
        $platform, $externalRef, date('Y-m-d H:i'),
        $customerEmail !== '' ? "Contact: {$customerName} <{$customerEmail}>" . ($customerPhone !== '' ? " · {$customerPhone}" : '') : ''
    );
    if ($claimedOrderTotal > 0 && abs($claimedOrderTotal - $claimedLines) < 0.01) {
        // The storefront and its lines agree, so the only difference worth naming is the one
        // between the site and this shelf.
        $notes .= sprintf(" The storefront charged %s for these goods; this shop's shelf prices them at %s.",
            ecommerceMoney($claimedLines), ecommerceMoney($subtotal));
    } elseif ($claimedOrderTotal > 0) {
        $notes .= sprintf(" The storefront's order total reads %s; its lines add to %s; this shop's shelf prices them at %s.",
            ecommerceMoney($claimedOrderTotal), ecommerceMoney($claimedLines), ecommerceMoney($subtotal));
    }
    if ($unmatchedNames !== []) {
        $notes .= ' Not on this shop\'s list: ' . implode(', ', array_slice($unmatchedNames, 0, 8))
            . (count($unmatchedNames) > 8 ? ' (and ' . (count($unmatchedNames) - 8) . ' more)' : '')
            . '. Check those lines before you ring it up.';
    }
    $notes .= ' Nothing has been booked to takings and no stock has moved.';
    $notes = trim($notes);

    $estimateId = 'est-onl-' . bin2hex(random_bytes(5));
    $now = date('Y-m-d H:i:s');
    $branchCode = defined('STOREFLOW_BRANCH_CODE') ? STOREFLOW_BRANCH_CODE : 'MAIN-01';

    try {
        $stmt = $db->prepare("INSERT INTO estimates (
            id, estimate_number, customer_id, customer_name, customer_phone,
            user_id, created_by_name, estimate_date, valid_until, subtotal,
            discount, tax, total_amount, notes, status, items_json,
            branch_code, platform, external_ref, created_at, updated_at
        ) VALUES (?, ?, 'cust-walkin', ?, ?, NULL, ?, ?, ?, ?, 0.0, 0.0, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $estimateId,
            $estimateNumber,
            $customerName,
            $customerPhone,
            $platform,
            $now,
            date('Y-m-d', strtotime('+7 days')),
            $subtotal,
            $totalAmount,
            $notes,
            'PENDING',
            json_encode($items, JSON_UNESCAPED_UNICODE),
            $branchCode,
            $platform,
            $externalRef,
            $now,
            $now
        ]);
    } catch (PDOException $e) {
        // Two webhooks for one order can arrive in the same second; the unique pair of
        // platform + order number is what says there is only one quotation for it.
        if (stripos($e->getMessage(), 'UNIQUE') !== false) {
            $again = $db->prepare("SELECT id, estimate_number, status FROM estimates WHERE platform = ? AND external_ref = ? LIMIT 1");
            $again->execute([$platform, $externalRef]);
            $row = $again->fetch(PDO::FETCH_ASSOC);
            if ($row) {
                jsonResponse([
                    'success' => true,
                    'duplicate' => true,
                    'estimate_id' => $row['id'],
                    'estimate_number' => $row['estimate_number'],
                    'message' => sprintf('%s order #%s is already on the Quotations page as %s.', $platform, $externalRef, $row['estimate_number'])
                ]);
            }
        }
        jsonResponse(['success' => false, 'message' => 'Could not put that order on the Quotations page: ' . $e->getMessage()], 500);
    }

    storeflow_do_action('ecommerce_order_received', $estimateId, $platform, $externalRef, $data);

    jsonResponse([
        'success' => true,
        'estimate_id' => $estimateId,
        'estimate_number' => $estimateNumber,
        'total_amount' => $totalAmount,
        'orders_waiting' => 'on the Quotations page',
        'message' => sprintf('%s order #%s is now quotation %s at %s. No receipt has been written and no stock has moved - the counter books both when it takes the money.',
            $platform, $externalRef, $estimateNumber, ecommerceMoney($totalAmount))
    ]);
}

jsonResponse(['success' => false, 'message' => 'Unsupported e-commerce sync action'], 400);
