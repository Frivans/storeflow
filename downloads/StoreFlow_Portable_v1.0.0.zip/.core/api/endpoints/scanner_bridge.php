<?php
// api/endpoints/scanner_bridge.php
// Real-time Wireless Companion Scanner Bridge
// Allows floor attendants to beam scanned barcodes from mobile cameras directly into POS terminal carts over local LAN Wi-Fi.

require_once __DIR__ . '/../config/db.php';

// Auto-initialize terminal scan buffer table and indices if absent
try {
    $db->exec("CREATE TABLE IF NOT EXISTS terminal_scan_buffer (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        terminal_id TEXT NOT NULL DEFAULT 'REG-01',
        barcode TEXT NOT NULL,
        product_name TEXT DEFAULT NULL,
        selling_price REAL DEFAULT 0,
        stock_qty REAL DEFAULT 0,
        device_info TEXT DEFAULT 'Mobile Companion',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        processed INTEGER DEFAULT 0,
        processed_at DATETIME DEFAULT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_scan_term_proc ON terminal_scan_buffer (terminal_id, processed);
    CREATE INDEX IF NOT EXISTS idx_scan_term_time ON terminal_scan_buffer (terminal_id, created_at);");
} catch (Exception $e) {
    error_log("Failed to initialize terminal_scan_buffer table: " . $e->getMessage());
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$action = trim($_GET['action'] ?? ($_POST['action'] ?? ''));

// If no explicit action given, handle based on method
if (empty($action)) {
    if ($method === 'POST') {
        $action = 'push';
    } else {
        $action = 'poll';
    }
}

// -------------------------------------------------------------
// Pairing token
// The mobile companion page deliberately runs without a POS login, so it is
// authenticated by a secret carried in the pairing URL/QR instead.
// -------------------------------------------------------------
function scannerPairingToken(PDO $db): string {
    $token = null;
    try {
        $token = $db->query("SELECT scanner_pairing_token FROM store_profile WHERE id = 1")->fetchColumn();
    } catch (Exception $e) {
        $token = null;
    }
    if (!is_string($token) || !preg_match('/^[a-f0-9]{32,64}$/i', $token)) {
        $token = bin2hex(random_bytes(16));
        try {
            $upd = $db->prepare("UPDATE store_profile SET scanner_pairing_token = ? WHERE id = 1");
            $upd->execute([$token]);
        } catch (Exception $e) {
            error_log('Unable to persist scanner pairing token: ' . $e->getMessage());
        }
    }
    return strtolower($token);
}

function scannerTokenIsValid(PDO $db, $supplied): bool {
    if (!is_string($supplied) || $supplied === '') return false;
    return hash_equals(scannerPairingToken($db), strtolower(trim($supplied)));
}

// -------------------------------------------------------------
// ACTION: info
// Returns pairing details, local LAN IPs, default terminal ID,
// and constructed companion URL for QR code generation.
// -------------------------------------------------------------
if ($action === 'info') {
    // Discloses hostnames, LAN addresses and the pairing secret: terminal-side only.
    $infoUser = requireAuth();
    $canPair  = hasPermission($infoUser, 'manage_settings');

    // Determine terminal ID from database or fallback
    $terminalId = 'REG-01';
    try {
        $profStmt = $db->query("SELECT terminal_id FROM store_profile WHERE id = 1 LIMIT 1");
        $prof = $profStmt->fetch(PDO::FETCH_ASSOC);
        if (!empty($prof['terminal_id'])) {
            $terminalId = trim($prof['terminal_id']);
        }
    } catch (Exception $e) { }

    if (!empty($_GET['terminal_id'])) {
        $terminalId = trim($_GET['terminal_id']);
    }

    // Determine current host & protocol
    $httpHost = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $hostOnly = explode(':', $httpHost)[0];
    $port = $_SERVER['SERVER_PORT'] ?? '80';

    // A tunnel (ngrok, Cloudflare) ends TLS at its own edge and hands the till plain
    // HTTP, naming the original scheme in X-Forwarded-Proto - the same signal db.php
    // already trusts for the session cookie. Without it a phone pointed at the till
    // through a tunnel is handed an http:// link to a port nothing outside the
    // machine can reach, and the camera page refuses to start because it is not a
    // secure context.
    $forwardedProto = strtolower(trim(explode(',', (string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? ''))[0]));
    $viaTunnel = $forwardedProto !== '' || !empty($_SERVER['HTTP_X_FORWARDED_HOST']);
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || ($_SERVER['SERVER_PORT'] ?? '') == 443
        || $forwardedProto === 'https';
    $scheme = $isHttps ? 'https' : 'http';

    // Detect all candidate local LAN IPv4 addresses
    $detectedIps = [];
    $primaryIp = gethostbyname(gethostname());
    if (!empty($primaryIp) && $primaryIp !== '127.0.0.1' && filter_var($primaryIp, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        $detectedIps[] = $primaryIp;
    }

    // On Windows, parse ipconfig for active Wi-Fi / Ethernet IPv4 addresses
    if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
        @exec('ipconfig', $ipLines);
        if (!empty($ipLines) && is_array($ipLines)) {
            foreach ($ipLines as $line) {
                if (preg_match('/IPv4.*?:\s*([0-9.]+)/i', $line, $m)) {
                    $cand = trim($m[1]);
                    if ($cand !== '127.0.0.1' && filter_var($cand, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                        $detectedIps[] = $cand;
                    }
                }
            }
        }
    }

    $detectedIps = array_values(array_unique($detectedIps));
    $lanIp = !empty($detectedIps) ? $detectedIps[0] : $hostOnly;

    // Detect base directory path (e.g. /storemgt when served from an Apache subfolder)
    $scriptDir = dirname($_SERVER['SCRIPT_NAME'] ?? '/api/endpoints/scanner_bridge.php');
    $baseDir = preg_replace('#/api/endpoints.*$#i', '', $scriptDir);
    // A till that cannot locate a subfolder is being served from the web root, which
    // is how every packaged copy runs (php -S with docroot = the app folder). Assuming
    // /storemgt there prints a QR to a path that does not exist, and the phone gets a
    // 404 the first time someone pairs a scanner.
    if (empty($baseDir) || $baseDir === '/' || $baseDir === '\\' || $baseDir === '.') {
        $baseDir = '';
    }
    $baseDir = str_replace('\\', '/', $baseDir);
    if ($baseDir !== '' && $baseDir[0] !== '/') {
        $baseDir = '/' . $baseDir;
    }
    $baseDir = rtrim($baseDir, '/');

    // Build pairing host: if currently accessed on localhost/127.0.0.1, substitute detected LAN IP
    $pairHost = ($hostOnly === 'localhost' || $hostOnly === '127.0.0.1' || $hostOnly === '::1') ? $lanIp : $hostOnly;
    // Through a tunnel the authority in HTTP_HOST is the one the phone can actually
    // open, and SERVER_PORT is the private port behind it, so the port never belongs
    // in the link.
    $portSuffix = (!$viaTunnel && $port && $port != '80' && $port != '443') ? (':' . $port) : '';

    // The pairing secret is what lets any device on the network drop barcodes into a
    // till's cart, and the companion URL carries it. Pairing devices is a settings
    // task, so staff without manage_settings get the connectivity facts only.
    $companionUrl = $canPair
        ? "{$scheme}://{$pairHost}{$portSuffix}{$baseDir}/?mode=scanner&term=" . urlencode($terminalId)
          . "&pair=" . urlencode(scannerPairingToken($db))
        : '';

    // Count pending scans
    $pendingCount = 0;
    try {
        $cntStmt = $db->prepare("SELECT COUNT(*) FROM terminal_scan_buffer WHERE terminal_id = ? AND processed = 0");
        $cntStmt->execute([$terminalId]);
        $pendingCount = (int)$cntStmt->fetchColumn();
    } catch (Exception $e) { }

    // The launcher binds 127.0.0.1 unless lan-mode.txt exists, in which case it
    // sets STOREFLOW_LAN_MODE=1. Tell the terminal whether a phone could actually
    // reach the address in this QR, instead of letting it print a dead code.
    $lanMode = filter_var(getenv('STOREFLOW_LAN_MODE'), FILTER_VALIDATE_BOOLEAN);
    if (!$lanMode && PHP_SAPI !== 'cli-server') $lanMode = true;

    // Auto-create lan-mode.txt if it does not exist yet so the user never has to
    // manually open File Explorer, create files, or fight with hidden .txt.txt extensions.
    $lanModeFile = dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'lan-mode.txt';
    $autoCreated = false;
    if (!file_exists($lanModeFile)) {
        if (@file_put_contents($lanModeFile, "LAN mode enabled automatically by StoreFlow Device Hub\n") !== false) {
            $autoCreated = true;
        }
    }

    jsonResponse([
        'success' => true,
        'terminal_id' => $terminalId,
        'pairing_token' => $canPair ? scannerPairingToken($db) : '',
        'can_pair' => $canPair,
        'server_ip' => $lanIp,
        'all_ips' => $detectedIps,
        'http_host' => $httpHost,
        'port' => $port,
        'via_tunnel' => $viaTunnel,
        'base_path' => $baseDir,
        'companion_url' => $companionUrl,
        'lan_mode' => $lanMode,
        'lan_mode_created' => $autoCreated || file_exists($lanModeFile),
        'pending_scans' => $pendingCount
    ]);
}

// -------------------------------------------------------------
// ACTION: push
// Mobile companion pushes a barcode scanned by phone camera.
// Resolves product in SQLite and buffers for PC terminal cart ingestion.
// -------------------------------------------------------------
if ($action === 'push') {
    $input = getJsonInput();
    if (empty($input)) {
        $input = $_POST;
    }

    // The companion page has no POS session, so a valid pairing token is the
    // only thing that separates a paired scanner from anyone on the LAN.
    if (!scannerTokenIsValid($db, $input['pair'] ?? ($_GET['pair'] ?? null))) {
        jsonResponse(['success' => false, 'message' => 'Unpaired device: a valid pairing token is required. Re-scan the QR code shown on the POS terminal.'], 401);
    }

    $terminalId = trim($input['terminal_id'] ?? ($_GET['terminal_id'] ?? 'REG-01'));
    $barcode = trim($input['barcode'] ?? '');
    $deviceInfo = trim($input['device'] ?? 'Mobile Phone Scanner');

    if (empty($barcode)) {
        jsonResponse(['success' => false, 'message' => 'Barcode is required'], 400);
    }

    if (empty($terminalId)) {
        $terminalId = 'REG-01';
    }

    // Look up product by barcode, sku, or ID
    $product = null;
    $cleanBarcode = trim($barcode);
    $compactBarcode = preg_replace('/[\s\-_]/', '', strtolower($cleanBarcode));

    try {
        $stmt = $db->prepare("SELECT p.id, p.name, p.sku, p.barcode, p.selling_price, p.unit, p.image_url, p.category, 
                                     COALESCE(inv.current_quantity, 0) as stock 
                              FROM products p 
                              LEFT JOIN inventory inv ON p.id = inv.product_id 
                              WHERE p.barcode = ? OR p.sku = ? OR p.id = ? 
                              LIMIT 1");
        $stmt->execute([$cleanBarcode, $cleanBarcode, $cleanBarcode]);
        $product = $stmt->fetch(PDO::FETCH_ASSOC);

        // If not found, attempt fuzzy match without hyphens/spaces
        if (!$product && !empty($compactBarcode)) {
            $stmtFuzzy = $db->prepare("SELECT p.id, p.name, p.sku, p.barcode, p.selling_price, p.unit, p.image_url, p.category, 
                                              COALESCE(inv.current_quantity, 0) as stock 
                                       FROM products p 
                                       LEFT JOIN inventory inv ON p.id = inv.product_id 
                                       WHERE REPLACE(REPLACE(REPLACE(LOWER(p.barcode), ' ', ''), '-', ''), '_', '') = ? 
                                          OR REPLACE(REPLACE(REPLACE(LOWER(p.sku), ' ', ''), '-', ''), '_', '') = ? 
                                       LIMIT 1");
            $stmtFuzzy->execute([$compactBarcode, $compactBarcode]);
            $product = $stmtFuzzy->fetch(PDO::FETCH_ASSOC);
        }
    } catch (Exception $e) {
        error_log("Scanner bridge product lookup error: " . $e->getMessage());
    }

    $product = $product ?: null;
    $prodName = $product ? $product['name'] : 'Unknown Item (' . $cleanBarcode . ')';
    $price = $product ? (float)$product['selling_price'] : 0.0;
    $stock = $product ? (float)$product['stock'] : 0.0;

    // Buffer the scan for Cashier PC
    try {
        $ins = $db->prepare("INSERT INTO terminal_scan_buffer 
            (terminal_id, barcode, product_name, selling_price, stock_qty, device_info, created_at, processed) 
            VALUES (?, ?, ?, ?, ?, ?, datetime('now'), 0)");
        $ins->execute([$terminalId, $cleanBarcode, $prodName, $price, $stock, $deviceInfo]);
        $scanId = $db->lastInsertId();

        jsonResponse([
            'success' => true,
            'message' => 'Beamed to terminal ' . $terminalId,
            'scan_id' => $scanId,
            'terminal_id' => $terminalId,
            'barcode' => $cleanBarcode,
            'product' => $product,
            'found' => ($product !== null)
        ], 200);
    } catch (Exception $e) {
        jsonResponse([
            'success' => false,
            'message' => 'Failed to buffer scan: ' . $e->getMessage()
        ], 500);
    }
}

// -------------------------------------------------------------
// ACTION: poll
// Cashier PC terminal polls for unread/pending scans beamed to its terminal ID.
// Returns array of scans and marks them processed immediately.
// -------------------------------------------------------------
if ($action === 'poll') {
    requireAuth();
    // Marking scans consumed is a state change, and the session cookie is SameSite=Lax,
    // which still travels on a top-level cross-site GET. Force it through POST.
    if ($method !== 'POST') {
        jsonResponse(['success' => false, 'message' => 'poll requires a POST request.'], 405);
    }
    $terminalId = trim($_GET['terminal_id'] ?? ($_POST['terminal_id'] ?? 'REG-01'));
    if (empty($terminalId)) {
        $terminalId = 'REG-01';
    }

    try {
        // Fetch unread scans for this terminal
        $sel = $db->prepare("SELECT id, terminal_id, barcode, product_name, selling_price, stock_qty, device_info, created_at 
                             FROM terminal_scan_buffer 
                             WHERE terminal_id = ? AND processed = 0 
                             ORDER BY id ASC 
                             LIMIT 50");
        $sel->execute([$terminalId]);
        $scans = $sel->fetchAll(PDO::FETCH_ASSOC);

        if (!empty($scans)) {
            $ids = array_column($scans, 'id');
            $inClause = implode(',', array_fill(0, count($ids), '?'));
            $upd = $db->prepare("UPDATE terminal_scan_buffer 
                                 SET processed = 1, processed_at = datetime('now') 
                                 WHERE id IN ($inClause)");
            $upd->execute($ids);
        }

        // Periodic maintenance: clean up processed scans older than 24 hours (1% lottery chance per poll)
        if (mt_rand(1, 100) === 42) {
            $db->exec("DELETE FROM terminal_scan_buffer WHERE processed = 1 AND created_at < datetime('now', '-24 hours')");
        }

        jsonResponse([
            'success' => true,
            'terminal_id' => $terminalId,
            'scans' => $scans,
            'count' => count($scans)
        ]);
    } catch (Exception $e) {
        jsonResponse([
            'success' => false,
            'message' => 'Poll error: ' . $e->getMessage()
        ], 500);
    }
}

// -------------------------------------------------------------
// ACTION: history
// Returns recent scans (processed or unprocessed) for audit feed.
// -------------------------------------------------------------
if ($action === 'history') {
    requireAuth();
    $terminalId = trim($_GET['terminal_id'] ?? 'REG-01');
    $limit = min(50, max(5, intval($_GET['limit'] ?? 20)));

    try {
        $stmt = $db->prepare("SELECT id, terminal_id, barcode, product_name, selling_price, device_info, created_at, processed 
                              FROM terminal_scan_buffer 
                              WHERE terminal_id = ? 
                              ORDER BY id DESC 
                              LIMIT ?");
        $stmt->bindValue(1, $terminalId, PDO::PARAM_STR);
        $stmt->bindValue(2, $limit, PDO::PARAM_INT);
        $stmt->execute();
        $history = $stmt->fetchAll(PDO::FETCH_ASSOC);

        jsonResponse([
            'success' => true,
            'terminal_id' => $terminalId,
            'history' => $history
        ]);
    } catch (Exception $e) {
        jsonResponse(['success' => false, 'message' => $e->getMessage()], 500);
    }
}

// -------------------------------------------------------------
// ACTION: clear
// Discards or clears all pending scans for a terminal.
// -------------------------------------------------------------
if ($action === 'clear') {
    requireAuth();
    if ($method !== 'POST') {
        jsonResponse(['success' => false, 'message' => 'clear requires a POST request.'], 405);
    }
    $terminalId = trim($_POST['terminal_id'] ?? ($_GET['terminal_id'] ?? 'REG-01'));
    try {
        $stmt = $db->prepare("UPDATE terminal_scan_buffer SET processed = 1, processed_at = datetime('now') WHERE terminal_id = ? AND processed = 0");
        $stmt->execute([$terminalId]);
        jsonResponse(['success' => true, 'message' => 'Buffer cleared for ' . $terminalId]);
    } catch (Exception $e) {
        jsonResponse(['success' => false, 'message' => $e->getMessage()], 500);
    }
}

// -------------------------------------------------------------
// ACTION: rotate
// Issues a new pairing secret, invalidating every previously issued QR/URL.
// Used when a companion device is lost or the pairing link has leaked.
// -------------------------------------------------------------
if ($action === 'rotate') {
    $user = requirePermission('manage_settings');
    $newToken = bin2hex(random_bytes(16));
    try {
        $upd = $db->prepare("UPDATE store_profile SET scanner_pairing_token = ?, updated_at = datetime('now') WHERE id = 1");
        $upd->execute([$newToken]);
        logActivity($db, $user['id'], $user['full_name'], $user['role_name'], 'SCANNER_PAIRING_ROTATED',
            'Wireless scanner pairing secret rotated; existing companion devices must re-pair.');
        jsonResponse(['success' => true, 'message' => 'Pairing secret rotated. Re-print the companion QR code.', 'token' => $newToken]);
    } catch (Exception $e) {
        jsonResponse(['success' => false, 'message' => $e->getMessage()], 500);
    }
}

// Fallback unknown action
jsonResponse(['success' => false, 'message' => 'Invalid scanner action'], 400);
