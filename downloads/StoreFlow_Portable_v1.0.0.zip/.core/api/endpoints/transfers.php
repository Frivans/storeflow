<?php
// api/endpoints/transfers.php
// Inter-Branch Stock Transfers (IBT) Management & Audit Waybills
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/product_units.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET') {
    $authUser = requireAuth();

    // A waybill hands out the cost price of every line and the username of the officer
    // who moved it. Staff who are not allowed to see product cost get neither.
    $canSeeCost = maySeeProductCost($authUser);
    $maskTransferRow = function (array $row) use ($canSeeCost): array {
        if (!$canSeeCost) {
            unset($row['officer_username']);
            if (isset($row['items']) && is_array($row['items'])) {
                foreach ($row['items'] as &$item) {
                    if (is_array($item)) unset($item['cost_price']);
                }
                unset($item);
            }
        }
        return $row;
    };

    $id = trim($_GET['id'] ?? '');
    if (!empty($id)) {
        $stmt = $db->prepare("SELECT t.*, 
                                     COALESCE(b_src.name, t.source_branch) as source_branch_name,
                                     COALESCE(b_dest.name, t.destination_branch) as destination_branch_name,
                                     u.full_name as officer_name,
                                     u.username as officer_username
                              FROM stock_transfers t
                              LEFT JOIN branches b_src ON t.source_branch = b_src.branch_code
                              LEFT JOIN branches b_dest ON t.destination_branch = b_dest.branch_code
                              LEFT JOIN users u ON t.created_by = u.id
                              WHERE t.id = ? OR t.transfer_number = ?");
        $stmt->execute([$id, $id]);
        $transfer = $stmt->fetch();

        if (!$transfer) {
            jsonResponse(['success' => false, 'message' => 'Transfer order not found'], 404);
        }

        // ti.unit is the size the waybill moved in; p.unit is the loose unit the shelf counts.
        // Selecting p.unit bare used to overwrite the line's own size in the result row.
        $itemsStmt = $db->prepare("SELECT ti.*, p.name as product_name, p.sku, p.unit as base_unit, p.selling_price
                                   FROM stock_transfer_items ti
                                   JOIN products p ON ti.product_id = p.id
                                   WHERE ti.transfer_id = ?");
        $itemsStmt->execute([$transfer['id']]);
        $transfer['items'] = $itemsStmt->fetchAll();

        jsonResponse(['success' => true, 'transfer' => $maskTransferRow($transfer)]);
    }

    $source = trim($_GET['source_branch'] ?? '');
    $destination = trim($_GET['destination_branch'] ?? '');

    $sql = "SELECT t.*, 
                   COALESCE(b_src.name, t.source_branch) as source_branch_name,
                   COALESCE(b_dest.name, t.destination_branch) as destination_branch_name,
                   u.full_name as officer_name,
                   u.username as officer_username
            FROM stock_transfers t
            LEFT JOIN branches b_src ON t.source_branch = b_src.branch_code
            LEFT JOIN branches b_dest ON t.destination_branch = b_dest.branch_code
            LEFT JOIN users u ON t.created_by = u.id
            WHERE 1=1";
    $params = [];

    if (!empty($source) && $source !== 'ALL') {
        $sql .= " AND t.source_branch = ?";
        $params[] = $source;
    }
    if (!empty($destination) && $destination !== 'ALL') {
        $sql .= " AND t.destination_branch = ?";
        $params[] = $destination;
    }

    $sql .= " ORDER BY t.created_at DESC LIMIT 100";
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $transfers = $stmt->fetchAll();

    // Attach items preview to each transfer
    $itemsLookup = $db->prepare("SELECT ti.*, p.name as product_name, p.sku, p.unit as base_unit
                                 FROM stock_transfer_items ti
                                 JOIN products p ON ti.product_id = p.id
                                 WHERE ti.transfer_id = ?");
    foreach ($transfers as &$trf) {
        $itemsLookup->execute([$trf['id']]);
        $trf['items'] = $itemsLookup->fetchAll();
        $trf = $maskTransferRow($trf);
    }
    unset($trf);

    jsonResponse(['success' => true, 'transfers' => $transfers]);
}

if ($method === 'POST') {
    $authUser = requirePermission('manage_inventory');
    $data = getJsonInput();

    $sourceBranch = strtoupper(trim($data['source_branch'] ?? 'MAIN-01'));
    $destBranch = strtoupper(trim($data['destination_branch'] ?? ''));
    $notes = trim($data['notes'] ?? '');
    $items = $data['items'] ?? [];

    if (empty($sourceBranch) || empty($destBranch)) {
        jsonResponse(['success' => false, 'message' => 'Source and destination branches are required.'], 400);
    }

    if ($sourceBranch === $destBranch) {
        jsonResponse(['success' => false, 'message' => 'Source and destination branches cannot be the same.'], 400);
    }

    if (empty($items) || !is_array($items)) {
        jsonResponse(['success' => false, 'message' => 'Transfer must contain at least one item.'], 400);
    }

    // Check negative stock rule
    $profRow = $db->query("SELECT allow_negative_stock FROM store_profile WHERE id = 1")->fetch();
    $allowNegativeStock = intval($profRow['allow_negative_stock'] ?? 0);

    // What each line means, and what the source branch has to give up in total, is decided
    // once here - by the same reader the offline sync path uses - so a waybill cannot mean
    // "4 crates" at one counter and "4 bottles" at the other.
    $plan = sfTransferPlan($db, $items);
    if ($plan['error'] !== null) {
        jsonResponse(['success' => false, 'message' => $plan['error']], 400);
    }
    if (empty($plan['lines'])) {
        jsonResponse(['success' => false, 'message' => 'No valid products to transfer.'], 400);
    }

    try {
        $db->beginTransaction();

        $transferId = 'trf_' . bin2hex(random_bytes(8));
        $transferNumber = 'TRF-' . date('YmdHis') . '-' . strtoupper(bin2hex(random_bytes(2)));

        $totalItemsCount = count($plan['byProduct']);
        $totalQuantitySum = array_sum($plan['byProduct']);
        $processedItems = $plan['lines'];

        $stockCheckStmt = $db->prepare("SELECT current_quantity FROM branch_inventory WHERE branch_code = ? AND product_id = ?");

        // The shelf is covered per product, in loose units, with every line for that product
        // added together first. Validating each line against the shelf and deducting later
        // meant [{P,50},{P,50}] passed both checks against 60 in stock and left the source
        // branch at -40.
        foreach ($plan['byProduct'] as $productId => $baseQty) {
            $stockCheckStmt->execute([$sourceBranch, $productId]);
            $srcQty = floatval($stockCheckStmt->fetchColumn() ?: 0.0);

            if ($allowNegativeStock === 0 && $srcQty < $baseQty) {
                $db->rollBack();
                $prodName = '';
                foreach ($processedItems as $p) {
                    if ($p['product_id'] === $productId) { $prodName = $p['name']; break; }
                }
                jsonResponse([
                    'success' => false,
                    'message' => "Insufficient stock at source branch ({$sourceBranch}) for '{$prodName}'. Available: {$srcQty}, requested to transfer: {$baseQty}."
                ], 400);
            }
        }

        // Insert Master Transfer Record
        $trfStmt = $db->prepare("INSERT INTO stock_transfers (id, transfer_number, source_branch, destination_branch, status, total_items, total_quantity, notes, created_by, created_at, updated_at)
                                 VALUES (?, ?, ?, ?, 'COMPLETED', ?, ?, ?, ?, datetime('now'), datetime('now'))");
        $trfStmt->execute([
            $transferId,
            $transferNumber,
            $sourceBranch,
            $destBranch,
            $totalItemsCount,
            $totalQuantitySum,
            $notes,
            $authUser['id']
        ]);

        $itemInsertStmt = $db->prepare("INSERT INTO stock_transfer_items (id, transfer_id, product_id, quantity, cost_price, unit, multiplier, base_quantity)
                                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

        // Pre-initialize branch_inventory rows so updates never erroneously add stock
        $branchInitStmt = $db->prepare("INSERT OR IGNORE INTO branch_inventory (id, branch_code, product_id, current_quantity, updated_at)
                                        VALUES ('binv_' || lower(hex(randomblob(6))), ?, ?, 0, datetime('now'))");

        // 1. Deduct from Source Branch. When negative stock is switched off the availability
        // test is part of the UPDATE, so a second transfer (or a sale) that took the stock
        // between the check above and this statement fails here instead of going negative.
        $deductGuard = ($allowNegativeStock === 0) ? " AND current_quantity >= ?" : "";
        $deductStmt = $db->prepare("UPDATE branch_inventory SET
                                    current_quantity = current_quantity - ?,
                                    updated_at = datetime('now')
                                    WHERE branch_code = ? AND product_id = ?{$deductGuard}");

        // 2. Add to Destination Branch
        $addStmt = $db->prepare("UPDATE branch_inventory SET
                                 current_quantity = current_quantity + ?,
                                 updated_at = datetime('now')
                                 WHERE branch_code = ? AND product_id = ?");

        // 3. Audit Movements Log
        $mvtStmt = $db->prepare("INSERT INTO inventory_movements (id, product_id, movement_type, quantity, reference_id, unit_price, notes, created_by, branch_code, created_at)
                                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))");

        foreach ($processedItems as $p) {
            $tiId = 'ti_' . bin2hex(random_bytes(6));
            // quantity stays the count in the size the shop named; base_quantity is what
            // leaves and arrives on the shelf. Both are written, because the paper has to
            // say "4 Crate" and the ledger has to say 120.
            $itemInsertStmt->execute([$tiId, $transferId, $p['product_id'], $p['quantity'], $p['cost_price'],
                $p['unit'], $p['multiplier'], $p['base_quantity']]);

            $moved = $p['base_quantity'];

            // Deduct source
            $branchInitStmt->execute([$sourceBranch, $p['product_id']]);
            $deductParams = [$moved, $sourceBranch, $p['product_id']];
            if ($deductGuard !== '') $deductParams[] = $moved;
            $deductStmt->execute($deductParams);
            if ($deductGuard !== '' && $deductStmt->rowCount() === 0) {
                $db->rollBack();
                jsonResponse([
                    'success' => false,
                    'message' => "Stock at source branch ({$sourceBranch}) changed while this transfer was being saved, so \"{$p['name']}\" was not moved. Retry with the current quantities."
                ], 409);
            }

            // Add destination
            $branchInitStmt->execute([$destBranch, $p['product_id']]);
            $addStmt->execute([$moved, $destBranch, $p['product_id']]);

            // Audit movement: Transfer Out
            $mvtStmt->execute([
                'mvt_' . bin2hex(random_bytes(6)),
                $p['product_id'],
                'TRANSFER_OUT',
                -$moved,
                $transferNumber,
                $p['cost_price'],
                "Transferred out to {$destBranch}: {$p['quantity']} " . ($p['unit'] !== '' ? $p['unit'] : 'unit')
                    . ($p['multiplier'] > 1 ? " ({$moved} " . ($p['base_unit'] ?: 'base') . ")" : '')
                    . ". Notes: {$notes}",
                $authUser['id'],
                $sourceBranch
            ]);

            // Audit movement: Transfer In
            $mvtStmt->execute([
                'mvt_' . bin2hex(random_bytes(6)),
                $p['product_id'],
                'TRANSFER_IN',
                $moved,
                $transferNumber,
                $p['cost_price'],
                "Transferred in from {$sourceBranch}: {$p['quantity']} " . ($p['unit'] !== '' ? $p['unit'] : 'unit')
                    . ($p['multiplier'] > 1 ? " ({$moved} " . ($p['base_unit'] ?: 'base') . ")" : '')
                    . ". Notes: {$notes}",
                $authUser['id'],
                $destBranch
            ]);
        }

        $db->commit();

        logActivity(
            $db,
            $authUser['id'],
            $authUser['full_name'],
            $authUser['role_name'],
            'STOCK_TRANSFER',
            "Completed Inter-Branch Transfer {$transferNumber}: moved {$totalQuantitySum} units ({$totalItemsCount} products) from {$sourceBranch} to {$destBranch}."
        );

        jsonResponse([
            'success' => true,
            'message' => "Stock transfer {$transferNumber} completed successfully!",
            'transfer_number' => $transferNumber,
            'transfer_id' => $transferId
        ], 201);

    } catch (Exception $e) {
        safeRollback($db);
        jsonResponse(['success' => false, 'message' => 'Transfer failed: ' . $e->getMessage()], 500);
    }
}

jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
