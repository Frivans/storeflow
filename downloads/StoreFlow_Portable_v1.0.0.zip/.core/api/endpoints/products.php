<?php
// api/endpoints/products.php
// Product Catalog Management with Multi-Branch Stock, Localized Pricing & Availability
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/product_units.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET') {
    $authUser = requireAuth();

    // Specific Product Sales History & Velocity Endpoint
    if (isset($_GET['action']) && $_GET['action'] === 'sales_history') {
        $productId = trim($_GET['product_id'] ?? '');
        if (empty($productId)) {
            jsonResponse(['success' => false, 'message' => 'Product ID required'], 400);
        }

        // This is the whole sales book for one product - every receipt, its number, its
        // amount and who bought it - reachable by asking for any product id. Velocity is
        // a reporting question, so it answers to the reporting permission.
        if (!hasPermission($authUser, 'view_reports') && !hasPermission($authUser, 'manage_inventory')) {
            jsonResponse(['success' => false, 'message' => 'You do not have access to product sales history.'], 403);
        }

        // A receipt line's quantity is in the size it was sold, so summing it counted a box
        // of four hundred and twenty eggs as one. The label this feeds is the product's
        // loose unit, so the count has to be in loose units too: rows written before sizing
        // arrived have no base_quantity and were one size only, where quantity is already
        // the right answer.
        $stmt = $db->prepare("SELECT si.quantity, si.unit, si.multiplier, si.base_quantity,
                                     si.unit_selling_price as selling_price, si.subtotal,
                                     s.id as sale_id, s.receipt_number, s.sale_date,
                                     COALESCE(c.name, 'Walk-in Customer') as customer_name
                              FROM sale_items si
                              JOIN sales s ON si.sale_id = s.id
                              LEFT JOIN customers c ON s.customer_id = c.id
                              WHERE si.product_id = ? AND COALESCE(s.status, '') <> 'VOID'
                              ORDER BY s.sale_date DESC LIMIT 20");
        $stmt->execute([$productId]);
        $recentSales = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Joined to the receipt because a voided bill put its goods straight back on this shelf.
        // Counting the line as sold anyway would have the stock card say ten bottles are out
        // there and this board say they sold.
        $sumStmt = $db->prepare("SELECT COALESCE(SUM(CASE WHEN si.base_quantity > 0 THEN si.base_quantity ELSE si.quantity END), 0) as total_units,
                                        COALESCE(SUM(si.subtotal), 0) as total_revenue
                                 FROM sale_items si
                                 JOIN sales s ON si.sale_id = s.id
                                 WHERE si.product_id = ? AND COALESCE(s.status, '') <> 'VOID'");
        $sumStmt->execute([$productId]);
        $summary = $sumStmt->fetch(PDO::FETCH_ASSOC);

        jsonResponse([
            'success' => true,
            'product_id' => $productId,
            'total_units' => floatval($summary['total_units'] ?? 0),
            'total_revenue' => floatval($summary['total_revenue'] ?? 0),
            'recent_sales' => $recentSales
        ]);
    }

    $search = trim($_GET['search'] ?? '');
    $category = trim($_GET['category'] ?? '');
    $branchCode = strtoupper(trim($_GET['branch_code'] ?? 'ALL'));
    $onlyAvailable = isset($_GET['only_available']) ? intval($_GET['only_available']) : 0;

    $params = [];

    if (!empty($branchCode) && $branchCode !== 'ALL') {
        $sql = "SELECT p.*, 
                       COALESCE(binv.current_quantity, 0.0) as current_quantity,
                       COALESCE(binv.custom_selling_price, p.selling_price) as selling_price,
                       p.selling_price as master_selling_price,
                       binv.custom_selling_price as custom_selling_price,
                       COALESCE(binv.is_available, 1) as is_available,
                       COALESCE(b.name, binv.branch_code, ?) as location,
                       ? as branch_code
                FROM products p
                LEFT JOIN branch_inventory binv ON p.id = binv.product_id AND binv.branch_code = ?
                LEFT JOIN branches b ON b.branch_code = ?
                WHERE p.is_active = 1";
        $params[] = $branchCode;
        $params[] = $branchCode;
        $params[] = $branchCode;
        $params[] = $branchCode;

        if ($onlyAvailable === 1) {
            $sql .= " AND COALESCE(binv.is_available, 1) = 1";
        }
    } else {
        $sql = "SELECT p.*, 
                       COALESCE(inv.current_quantity, 0.0) as current_quantity,
                       p.selling_price as master_selling_price,
                       COALESCE(inv.location, 'All Locations (Consolidated)') as location,
                       'ALL' as branch_code
                FROM products p
                LEFT JOIN inventory inv ON p.id = inv.product_id
                WHERE p.is_active = 1";
    }

    if (!empty($search)) {
        $sql .= " AND (p.name LIKE ? OR p.sku LIKE ? OR p.barcode LIKE ?)";
        $term = "%{$search}%";
        $params[] = $term;
        $params[] = $term;
        $params[] = $term;
    }

    if (!empty($category) && $category !== 'All') {
        $sql .= " AND p.category = ?";
        $params[] = $category;
    }

    $sql .= " ORDER BY p.name ASC";
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $products = $stmt->fetchAll();

    // Attach multi-branch settings to products
    $binvStmt = $db->query("SELECT binv.product_id, binv.branch_code, binv.current_quantity, binv.custom_selling_price, binv.is_available,
                                   COALESCE(b.name, binv.branch_code) as branch_name
                            FROM branch_inventory binv
                            LEFT JOIN branches b ON binv.branch_code = b.branch_code
                            WHERE binv.branch_code != 'ALL'
                            ORDER BY binv.branch_code ASC");
    $allBranchRows = $binvStmt->fetchAll();
    $branchSettingsMap = [];
    foreach ($allBranchRows as $brow) {
        $branchSettingsMap[$brow['product_id']][] = $brow;
    }

    // Both listing queries are SELECT p.*, so the unit rows have to be fetched beside
    // them: a product that comes back without its units loses the pack price and the
    // unit pills at the till, and looks exactly like a product that never had them.
    $unitsMap = sfUnitsForMany($db, array_column($products, 'id'));
    $combosMap = sfComboItemsForMany($db, array_column($products, 'id'));
    foreach ($products as &$p) {
        $p['branch_settings'] = $branchSettingsMap[$p['id']] ?? [];
        $p['units'] = $unitsMap[$p['id']] ?? [];
        $p['combo_items'] = $combosMap[$p['id']] ?? [];
        $p['product_type'] = $p['product_type'] ?? 'standard';
    }
    unset($p);

    // Security: Mask cost_price for cashiers so wholesale margins are never leaked in client DevTools / IndexedDB
    $canViewCost = maySeeProductCost($authUser);
    if (!$canViewCost) {
        foreach ($products as &$p) {
            $p['cost_price'] = 0.0;
        }
        unset($p);
    }

    // Distinct categories
    $catStmt = $db->query("SELECT DISTINCT category FROM products WHERE is_active = 1 AND category IS NOT NULL AND category != '' ORDER BY category ASC");
    $categories = $catStmt->fetchAll(PDO::FETCH_COLUMN);

    jsonResponse([
        'success' => true,
        'branch_code' => $branchCode,
        'products' => $products,
        'categories' => $categories
    ]);
}

if ($method === 'POST') {
    $user = requirePermission('manage_inventory');

    $data = getJsonInput();

    // Fast Transactional Bulk Import (CSV / XLSX Column Mapper)
    if (isset($data['action']) && $data['action'] === 'bulk_import') {
        $items = isset($data['items']) && is_array($data['items']) ? $data['items'] : [];
        $duplicateMode = strtolower(trim((string)($data['duplicate_mode'] ?? 'update')));
        if (!in_array($duplicateMode, ['update', 'skip', 'create'], true)) {
            $duplicateMode = 'update';
        }

        if (empty($items)) {
            jsonResponse(['success' => false, 'message' => 'No product rows provided for import.'], 400);
        }

        $created = 0;
        $updated = 0;
        $skipped = 0;
        $warnings = [];
        $activeBranch = !empty($user['branch_code']) && $user['branch_code'] !== 'ALL' ? $user['branch_code'] : 'MAIN-01';

        try {
            $db->beginTransaction();

            $findBySkuStmt = $db->prepare("SELECT * FROM products WHERE is_active = 1 AND LOWER(sku) = LOWER(?) LIMIT 1");
            $findByBarcodeStmt = $db->prepare("SELECT * FROM products WHERE is_active = 1 AND barcode != '' AND barcode = ? LIMIT 1");
            $findByNameStmt = $db->prepare("SELECT * FROM products WHERE is_active = 1 AND LOWER(name) = LOWER(?) LIMIT 1");
            $skuCollisionStmt = $db->prepare("SELECT id FROM products WHERE LOWER(sku) = LOWER(?) AND id != ? LIMIT 1");

            $insertProdStmt = $db->prepare("INSERT INTO products (id, name, sku, barcode, category, unit, cost_price, selling_price, min_stock_alert, image_url, description, is_active, has_expiry, batch_number, expiry_date, mfg_date, alert_before_days, pack_unit, pack_size, pack_price, product_type, is_rental, created_at, updated_at)
                                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'assets/images/products/placeholder.svg', ?, 1, ?, ?, ?, NULL, 30, ?, ?, ?, 'standard', ?, datetime('now'), datetime('now'))");

            $upsertBinvStmt = $db->prepare("INSERT INTO branch_inventory (id, branch_code, product_id, current_quantity, reorder_level, custom_selling_price, is_available, updated_at)
                                            VALUES (?, ?, ?, ?, ?, NULL, 1, datetime('now'))
                                            ON CONFLICT(branch_code, product_id) DO UPDATE SET
                                            current_quantity = excluded.current_quantity,
                                            reorder_level = excluded.reorder_level,
                                            updated_at = datetime('now')");

            $upsertInvStmt = $db->prepare("INSERT INTO inventory (id, product_id, current_quantity, reorder_level, location, updated_at)
                                           VALUES (?, ?, ?, ?, ?, datetime('now'))
                                           ON CONFLICT(product_id) DO UPDATE SET
                                           current_quantity = excluded.current_quantity,
                                           reorder_level = excluded.reorder_level,
                                           location = excluded.location,
                                           updated_at = datetime('now')");

            $mvtStmt = $db->prepare("INSERT INTO inventory_movements (id, product_id, movement_type, quantity, reference_id, unit_price, notes, branch_code, created_at)
                                     VALUES (?, ?, ?, ?, 'BULK_IMPORT', ?, ?, ?, datetime('now'))");

            $batchStmt = $db->prepare("INSERT INTO product_batches (id, product_id, batch_number, expiry_date, manufacture_date, initial_quantity, current_quantity, cost_price, branch_code, status, notes, created_at, updated_at)
                                       VALUES (?, ?, ?, ?, NULL, ?, ?, ?, ?, 'ACTIVE', 'Imported batch lot', datetime('now'), datetime('now'))");

            foreach ($items as $idx => $row) {
                $rowNum = $idx + 1;
                $name = trim((string)($row['name'] ?? ''));
                if ($name === '') {
                    $skipped++;
                    continue;
                }

                $sku = trim((string)($row['sku'] ?? ''));
                $barcode = trim((string)($row['barcode'] ?? ''));
                $category = trim((string)($row['category'] ?? '')) ?: 'General';
                $unit = trim((string)($row['unit'] ?? '')) ?: 'pcs';
                $costPrice = isset($row['cost_price']) && $row['cost_price'] !== '' ? max(0, round(floatval($row['cost_price']), 2)) : null;
                $sellingPrice = isset($row['selling_price']) && $row['selling_price'] !== '' ? max(0, round(floatval($row['selling_price']), 2)) : null;
                $stockMapped = array_key_exists('initial_stock', $row) && $row['initial_stock'] !== '' && $row['initial_stock'] !== null;
                $stockVal = $stockMapped ? max(0, floatval($row['initial_stock'])) : 0.0;
                $minAlert = isset($row['min_stock_alert']) && $row['min_stock_alert'] !== '' ? max(0, intval($row['min_stock_alert'])) : null;
                $location = trim((string)($row['location'] ?? '')) ?: 'Main Storefront';
                $description = trim((string)($row['description'] ?? ''));
                $expiryDate = trim((string)($row['expiry_date'] ?? '')) ?: null;
                $batchNumber = trim((string)($row['batch_number'] ?? ''));
                $hasExpiry = !empty($expiryDate) ? 1 : 0;

                $rawUnits = (isset($row['units']) && is_array($row['units'])) ? $row['units'] : [];

                // Check for existing active product match
                $existing = null;
                if ($duplicateMode !== 'create') {
                    if ($sku !== '') {
                        $findBySkuStmt->execute([$sku]);
                        $existing = $findBySkuStmt->fetch(PDO::FETCH_ASSOC) ?: null;
                    }
                    if (!$existing && $barcode !== '') {
                        $findByBarcodeStmt->execute([$barcode]);
                        $existing = $findByBarcodeStmt->fetch(PDO::FETCH_ASSOC) ?: null;
                    }
                    if (!$existing) {
                        $findByNameStmt->execute([$name]);
                        $existing = $findByNameStmt->fetch(PDO::FETCH_ASSOC) ?: null;
                    }
                }

                if ($existing) {
                    if ($duplicateMode === 'skip') {
                        $skipped++;
                        continue;
                    }

                    // Update existing product
                    $prodId = $existing['id'];
                    $finalSku = $sku !== '' ? $sku : $existing['sku'];
                    $skuCollisionStmt->execute([$finalSku, $prodId]);
                    if ($skuCollisionStmt->fetch()) {
                        $finalSku = $existing['sku'];
                    }

                    $finalBarcode = $barcode !== '' ? $barcode : ($existing['barcode'] ?? '');
                    $finalCategory = !empty($row['category']) ? $category : ($existing['category'] ?: 'General');
                    $finalUnit = !empty($row['unit']) ? $unit : ($existing['unit'] ?: 'pcs');
                    $finalCost = $costPrice !== null ? $costPrice : floatval($existing['cost_price'] ?? 0);
                    $finalPrice = $sellingPrice !== null ? $sellingPrice : floatval($existing['selling_price'] ?? 0);
                    $finalAlert = $minAlert !== null ? $minAlert : intval($existing['min_stock_alert'] ?? 5);
                    $finalDesc = $description !== '' ? $description : ($existing['description'] ?? '');
                    $finalHasExpiry = $expiryDate !== null ? 1 : intval($existing['has_expiry'] ?? 0);
                    $finalExpiry = $expiryDate !== null ? $expiryDate : ($existing['expiry_date'] ?? null);
                    $finalBatch = $batchNumber !== '' ? $batchNumber : ($existing['batch_number'] ?? '');

                    $packUnit = $existing['pack_unit'] ?? '';
                    $packSize = floatval($existing['pack_size'] ?? 1);
                    $packPrice = floatval($existing['pack_price'] ?? 0);

                    if (!empty($rawUnits)) {
                        $unitPlan = sfUnitsNormalize($rawUnits, $finalUnit, $finalBarcode);
                        if ($unitPlan['error'] === null) {
                            $packMirror = sfUnitsLegacyMirror($unitPlan['rows']);
                            $packUnit = $packMirror['pack_unit'];
                            $packSize = $packMirror['pack_size'];
                            $packPrice = $packMirror['pack_price'];
                            sfUnitsReplace($db, $prodId, $unitPlan['rows']);
                        } else {
                            $warnings[] = "Row {$rowNum} ({$name}): Pack size skipped — {$unitPlan['error']}";
                        }
                    }

                    $updStmt = $db->prepare("UPDATE products SET
                        name = ?, sku = ?, barcode = ?, category = ?, unit = ?,
                        cost_price = ?, selling_price = ?, min_stock_alert = ?, description = ?,
                        has_expiry = ?, batch_number = ?, expiry_date = ?,
                        pack_unit = ?, pack_size = ?, pack_price = ?, updated_at = datetime('now')
                        WHERE id = ?");
                    $updStmt->execute([
                        $name, $finalSku, $finalBarcode, $finalCategory, $finalUnit,
                        $finalCost, $finalPrice, $finalAlert, $finalDesc,
                        $finalHasExpiry, $finalBatch, $finalExpiry,
                        $packUnit, $packSize, $packPrice, $prodId
                    ]);

                    if ($stockMapped) {
                        $prevStmt = $db->prepare("SELECT current_quantity FROM inventory WHERE product_id = ?");
                        $prevStmt->execute([$prodId]);
                        $prevStock = floatval($prevStmt->fetchColumn() ?: 0.0);

                        $upsertBinvStmt->execute(['binv_' . bin2hex(random_bytes(6)), $activeBranch, $prodId, $stockVal, $finalAlert]);
                        $sumStmt = $db->prepare("SELECT COALESCE(SUM(current_quantity), 0) FROM branch_inventory WHERE product_id = ?");
                        $sumStmt->execute([$prodId]);
                        $totalStock = floatval($sumStmt->fetchColumn() ?: $stockVal);

                        $upsertInvStmt->execute(['inv_' . bin2hex(random_bytes(6)), $prodId, $totalStock, $finalAlert, $location]);

                        $diff = $totalStock - $prevStock;
                        if (abs($diff) > 0.0001) {
                            $mvtStmt->execute(['mvt_' . bin2hex(random_bytes(6)), $prodId, 'ADJUSTMENT', $diff, $finalCost, 'Stock updated via Bulk Import', $activeBranch]);
                        }
                    }

                    $updated++;
                    continue;
                }

                // Create new product
                $prodId = 'prod_' . bin2hex(random_bytes(6));
                if ($sku === '') {
                    $cleanName = strtoupper(substr(preg_replace('/[^a-zA-Z0-9]/', '', $name), 0, 4));
                    if (strlen($cleanName) < 2) $cleanName = 'PROD';
                    $sku = 'SKU-' . $cleanName . '-' . strtoupper(bin2hex(random_bytes(3)));
                }
                $skuCollisionStmt->execute([$sku, $prodId]);
                if ($skuCollisionStmt->fetch()) {
                    $sku .= '-' . strtoupper(bin2hex(random_bytes(2)));
                }

                $finalCost = $costPrice ?? 0.0;
                $finalPrice = $sellingPrice ?? 0.0;
                $finalAlert = $minAlert ?? 5;
                $isRental = (stripos($category, 'rental') !== false || stripos($category, 'hire') !== false) ? 1 : 0;

                $unitPlan = sfUnitsNormalize($rawUnits, $unit, $barcode);
                if ($unitPlan['error'] !== null) {
                    $warnings[] = "Row {$rowNum} ({$name}): Pack size skipped — {$unitPlan['error']}";
                    $unitPlan = sfUnitsNormalize([], $unit, $barcode);
                }
                $packMirror = sfUnitsLegacyMirror($unitPlan['rows']);

                $insertProdStmt->execute([
                    $prodId, $name, $sku, $barcode, $category, $unit,
                    $finalCost, $finalPrice, $finalAlert, $description,
                    $hasExpiry, $batchNumber, $expiryDate,
                    $packMirror['pack_unit'], $packMirror['pack_size'], $packMirror['pack_price'],
                    $isRental
                ]);

                $upsertBinvStmt->execute(['binv_' . bin2hex(random_bytes(6)), $activeBranch, $prodId, $stockVal, $finalAlert]);
                $upsertInvStmt->execute(['inv_' . bin2hex(random_bytes(6)), $prodId, $stockVal, $finalAlert, $location]);
                sfUnitsReplace($db, $prodId, $unitPlan['rows']);

                if ($stockVal > 0) {
                    $mvtStmt->execute(['mvt_' . bin2hex(random_bytes(6)), $prodId, 'INITIAL_STOCK', $stockVal, $finalCost, 'Initial stock via Bulk Import', $activeBranch]);
                    if ($hasExpiry === 1 && !empty($expiryDate)) {
                        $bNo = $batchNumber !== '' ? $batchNumber : ('LOT-' . date('Ymd') . '-IMP');
                        $batchStmt->execute(['batch_' . bin2hex(random_bytes(6)), $prodId, $bNo, $expiryDate, $stockVal, $stockVal, $finalCost, $activeBranch]);
                    }
                }

                $created++;
            }

            $db->commit();

            logActivity($db, $user['id'], $user['full_name'], $user['role_name'], 'PRODUCT_BULK_IMPORT', "Bulk imported products: {$created} created, {$updated} updated, {$skipped} skipped.");

            jsonResponse([
                'success' => true,
                'message' => "Bulk import completed: {$created} added, {$updated} updated, {$skipped} skipped.",
                'created' => $created,
                'updated' => $updated,
                'skipped' => $skipped,
                'warnings' => $warnings
            ]);
        } catch (Exception $e) {
            safeRollback($db);
            jsonResponse(['success' => false, 'message' => 'Bulk import failed: ' . $e->getMessage()], 500);
        }
    }

    $id = trim($data['id'] ?? '') ?: ('prod_' . bin2hex(random_bytes(6)));
    $name = trim($data['name'] ?? '');
    $sku = trim($data['sku'] ?? '');
    $barcode = trim($data['barcode'] ?? '');
    $category = trim($data['category'] ?? 'General');
    $unit = trim($data['unit'] ?? 'pcs');
    $costPrice = round(floatval($data['cost_price'] ?? 0), 2);
    $sellingPrice = round(floatval($data['selling_price'] ?? 0), 2);
    $minStockAlert = intval($data['min_stock_alert'] ?? 5);
    $initialStock = floatval($data['initial_stock'] ?? 0);
    $location = trim($data['location'] ?? 'Main Storefront');
    $description = trim($data['description'] ?? '');
    $imageUrl = trim($data['image_url'] ?? 'assets/images/products/placeholder.svg');
    $branchSettings = $data['branch_settings'] ?? [];
    $hasExpiry = !empty($data['has_expiry']) ? 1 : 0;
    $batchNumber = trim($data['batch_number'] ?? '');
    $expiryDate = trim($data['expiry_date'] ?? '') ?: null;
    $mfgDate = trim($data['mfg_date'] ?? '') ?: null;
    $alertBeforeDays = intval($data['alert_before_days'] ?? 30);
    if ($alertBeforeDays <= 0) $alertBeforeDays = 30;
    $packUnit = trim($data['pack_unit'] ?? '');
    $packSize = max(1, floatval($data['pack_size'] ?? 1));
    $packPrice = floatval($data['pack_price'] ?? 0);

    // The form sends a units array. When it does not, the single pack triple on the same
    // payload is read as one, so an older till or a synced product upsert keeps the
    // packaging it knows about instead of silently losing it.
    $rawUnits = (isset($data['units']) && is_array($data['units']))
        ? $data['units'] : sfUnitsFromLegacy($packUnit, (float)$packSize, $packPrice);
    $unitPlan = sfUnitsNormalize($rawUnits, $unit, $barcode);
    if ($unitPlan['error'] !== null) {
        jsonResponse(['success' => false, 'message' => $unitPlan['error']], 400);
    }

    // The unit rows are what the shop asked for; the one pack triple left on the products
    // row is a projection of them, so a reader that has not moved onto product_units yet
    // cannot disagree with the catalogue or invent which of several packs was "the" one.
    $packMirror = sfUnitsLegacyMirror($unitPlan['rows']);
    $packUnit = $packMirror['pack_unit'];
    $packSize = $packMirror['pack_size'];
    $packPrice = $packMirror['pack_price'];

    if (empty($name)) {
        jsonResponse(['success' => false, 'message' => 'Product name is required'], 400);
    }

    if (empty($sku)) {
        $cleanName = strtoupper(substr(preg_replace('/[^a-zA-Z0-9]/', '', $name), 0, 4));
        if (strlen($cleanName) < 2) $cleanName = 'PROD';
        $sku = 'SKU-' . $cleanName . '-' . strtoupper(bin2hex(random_bytes(3)));
    }

    $skuCheck = $db->prepare("SELECT id FROM products WHERE LOWER(sku) = LOWER(?) AND id != ?");
    $skuCheck->execute([$sku, $id]);
    if ($skuCheck->fetch()) {
        $sku .= '-' . strtoupper(bin2hex(random_bytes(2)));
    }

    // The tested value and the stored value have to come from one string: trim() of a missing key
    // is '', and '' passes neither 'standard' nor 'service', so a product created by a caller that
    // omits the type - an import, a queued push - was filed under a type nothing recognised.
    $productType = strtolower(trim((string)($data['product_type'] ?? '')));
    if (!in_array($productType, ['standard', 'service', 'combo'], true)) {
        $productType = 'standard';
    }
    if ($productType === 'service') {
        $initialStock = 0.0;
        $hasExpiry = 0;
    }

    $isRental = (isset($data['is_rental']) && (intval($data['is_rental']) === 1 || $data['is_rental'] === true || $data['is_rental'] === '1'))
        ? 1
        : ((stripos($category, 'rental') !== false || stripos($category, 'hire') !== false) ? 1 : 0);

    try {
        $db->beginTransaction();

        $stmt = $db->prepare("INSERT INTO products (id, name, sku, barcode, category, unit, cost_price, selling_price, min_stock_alert, image_url, description, is_active, has_expiry, batch_number, expiry_date, mfg_date, alert_before_days, pack_unit, pack_size, pack_price, product_type, is_rental, created_at, updated_at)
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))");
        $stmt->execute([$id, $name, $sku, $barcode, $category, $unit, $costPrice, $sellingPrice, $minStockAlert, $imageUrl, $description, $hasExpiry, $batchNumber, $expiryDate, $mfgDate, $alertBeforeDays, $packUnit, $packSize, $packPrice, $productType, $isRental]);

        // Branch inventory entries
        $consolidatedStock = 0.0;
        $binvStmt = $db->prepare("INSERT INTO branch_inventory (id, branch_code, product_id, current_quantity, reorder_level, custom_selling_price, is_available, updated_at)
                                  VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
                                  ON CONFLICT(branch_code, product_id) DO UPDATE SET
                                  current_quantity = excluded.current_quantity,
                                  reorder_level = excluded.reorder_level,
                                  custom_selling_price = excluded.custom_selling_price,
                                  is_available = excluded.is_available,
                                  updated_at = datetime('now')");

        if (!empty($branchSettings) && is_array($branchSettings)) {
            foreach ($branchSettings as $b) {
                $bCode = strtoupper(trim($b['branch_code'] ?? ''));
                if (empty($bCode)) continue;
                $bStock = floatval($b['current_quantity'] ?? $b['stock'] ?? 0);
                $customPrice = (isset($b['custom_selling_price']) && $b['custom_selling_price'] !== '' && $b['custom_selling_price'] !== null)
                               ? round(floatval($b['custom_selling_price']), 2) : null;
                $isAvail = isset($b['is_available']) ? (intval($b['is_available']) ? 1 : 0) : 1;

                $binvId = 'binv_' . bin2hex(random_bytes(6));
                $binvStmt->execute([$binvId, $bCode, $id, $bStock, $minStockAlert, $customPrice, $isAvail]);
                $consolidatedStock += $bStock;
            }
        } else {
            // Default single branch assignment for MAIN-01
            $binvId = 'binv_' . bin2hex(random_bytes(6));
            $binvStmt->execute([$binvId, 'MAIN-01', $id, $initialStock, $minStockAlert, null, 1]);
            $consolidatedStock = $initialStock;
        }

        // Create consolidated inventory record
        $invStmt = $db->prepare("INSERT INTO inventory (id, product_id, current_quantity, reorder_level, location, updated_at)
                                 VALUES (?, ?, ?, ?, ?, datetime('now'))");
        $invId = 'inv_' . bin2hex(random_bytes(6));
        $invStmt->execute([$invId, $id, $consolidatedStock, $minStockAlert, $location]);

        // If initial stock > 0, log movement
        if ($consolidatedStock > 0) {
            $mvtStmt = $db->prepare("INSERT INTO inventory_movements (id, product_id, movement_type, quantity, reference_id, unit_price, notes, branch_code, created_at)
                                     VALUES (?, ?, 'INITIAL_STOCK', ?, 'INIT', ?, 'Initial inventory stock on creation', 'MAIN-01', datetime('now'))");
            $mvtStmt->execute(['mvt_' . bin2hex(random_bytes(6)), $id, $consolidatedStock, $costPrice]);

            // If perishable, auto-create initial batch lot
            if ($hasExpiry === 1 && !empty($expiryDate)) {
                $batchId = 'batch_' . bin2hex(random_bytes(6));
                $bNo = !empty($batchNumber) ? $batchNumber : ('LOT-' . date('Ymd') . '-INIT');
                $bStmt = $db->prepare("INSERT INTO product_batches (id, product_id, batch_number, expiry_date, manufacture_date, initial_quantity, current_quantity, cost_price, branch_code, status, notes, created_at, updated_at)
                                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'MAIN-01', 'ACTIVE', 'Initial stock batch lot', datetime('now'), datetime('now'))");
                $bStmt->execute([$batchId, $id, $bNo, $expiryDate, $mfgDate, $consolidatedStock, $consolidatedStock, $costPrice]);
            }
        }

        sfUnitsReplace($db, $id, $unitPlan['rows']);

        if ($productType === 'combo' && isset($data['combo_items']) && is_array($data['combo_items'])) {
            sfSaveComboItems($db, $id, $data['combo_items']);
        }

        $db->commit();

        logActivity($db, $user['id'], $user['full_name'], $user['role_name'], 'PRODUCT_CREATE', "Added product '{$name}' (SKU: {$sku}, Total Stock: {$consolidatedStock}).");
        jsonResponse([
            'success' => true,
            'message' => 'Product created successfully',
            'product' => [
                'id' => $id,
                'name' => $name,
                'sku' => $sku,
                'barcode' => $barcode,
                'category' => $category,
                'unit' => $unit,
                'cost_price' => $costPrice,
                'selling_price' => $sellingPrice,
                'current_quantity' => $consolidatedStock,
                'min_stock_alert' => $minStockAlert,
                'location' => $location
            ]
        ], 201);
    } catch (Exception $e) {
        safeRollback($db);
        jsonResponse(['success' => false, 'message' => 'Error saving product: ' . $e->getMessage()], 500);
    }
}

if ($method === 'PUT') {
    $user = requirePermission('manage_inventory');

    $data = getJsonInput();
    $id = trim($data['id'] ?? '');

    if (empty($id)) {
        jsonResponse(['success' => false, 'message' => 'Product ID is required'], 400);
    }

    $name = trim($data['name'] ?? '');
    $sku = trim($data['sku'] ?? '');
    $barcode = trim($data['barcode'] ?? '');
    $category = trim($data['category'] ?? 'General');
    $unit = trim($data['unit'] ?? 'pcs');
    $costPrice = round(floatval($data['cost_price'] ?? 0), 2);
    $sellingPrice = round(floatval($data['selling_price'] ?? 0), 2);
    $minStockAlert = intval($data['min_stock_alert'] ?? 5);
    $imageUrl = trim($data['image_url'] ?? '');
    $description = trim($data['description'] ?? '');
    $branchSettings = $data['branch_settings'] ?? null;
    $hasExpiry = isset($data['has_expiry']) ? (!empty($data['has_expiry']) ? 1 : 0) : null;
    $batchNumber = isset($data['batch_number']) ? trim($data['batch_number']) : null;
    $expiryDate = isset($data['expiry_date']) ? (trim($data['expiry_date']) ?: null) : null;
    $mfgDate = isset($data['mfg_date']) ? (trim($data['mfg_date']) ?: null) : null;
    $alertBeforeDays = isset($data['alert_before_days']) ? intval($data['alert_before_days']) : null;
    $packUnit = isset($data['pack_unit']) ? trim($data['pack_unit']) : null;
    $packSize = isset($data['pack_size']) ? max(1, floatval($data['pack_size'])) : null;
    $packPrice = isset($data['pack_price']) ? floatval($data['pack_price']) : null;

    // PUT is field-by-field, and so are its units: a payload that says nothing about
    // packaging leaves the shop's existing unit rows alone rather than quietly reducing
    // the product to its base unit.
    $unitsSent = isset($data['units']) && is_array($data['units']);
    $rawUnits = $unitsSent ? $data['units'] : sfUnitsFromLegacy($packUnit, $packSize, $packPrice);
    if (!$unitsSent && $rawUnits !== []) {
        $unitsSent = true;
    }
    $unitPlan = sfUnitsNormalize($rawUnits, $unit, $barcode);
    if ($unitPlan['error'] !== null) {
        jsonResponse(['success' => false, 'message' => $unitPlan['error']], 400);
    }
    if ($unitsSent) {
        $packMirror = sfUnitsLegacyMirror($unitPlan['rows']);
        $packUnit = $packMirror['pack_unit'];
        $packSize = $packMirror['pack_size'];
        $packPrice = $packMirror['pack_price'];
    }

    if (empty($sku)) {
        $existingSkuStmt = $db->prepare("SELECT sku FROM products WHERE id = ?");
        $existingSkuStmt->execute([$id]);
        $existingSku = $existingSkuStmt->fetchColumn();
        $sku = !empty($existingSku) ? $existingSku : ('SKU-' . strtoupper(substr(preg_replace('/[^a-zA-Z0-9]/', '', $name), 0, 4)) . '-' . strtoupper(bin2hex(random_bytes(3))));
    } else {
        $skuCheck = $db->prepare("SELECT id FROM products WHERE LOWER(sku) = LOWER(?) AND id != ?");
        $skuCheck->execute([$sku, $id]);
        if ($skuCheck->fetch()) {
            $sku .= '-' . strtoupper(bin2hex(random_bytes(2)));
        }
    }

    $productType = isset($data['product_type']) && in_array(strtolower(trim($data['product_type'])), ['standard', 'service', 'combo'], true)
        ? strtolower(trim($data['product_type'])) : null;

    $isRental = isset($data['is_rental'])
        ? (intval($data['is_rental']) === 1 || $data['is_rental'] === true || $data['is_rental'] === '1' ? 1 : 0)
        : ((stripos($category, 'rental') !== false || stripos($category, 'hire') !== false) ? 1 : null);

    try {
        $db->beginTransaction();

        if (!empty($imageUrl)) {
            $stmt = $db->prepare("UPDATE products SET 
                name = ?, sku = ?, barcode = ?, category = ?, unit = ?, 
                cost_price = ?, selling_price = ?, min_stock_alert = ?, 
                image_url = ?, description = ?,
                has_expiry = COALESCE(?, has_expiry),
                batch_number = COALESCE(?, batch_number),
                expiry_date = COALESCE(?, expiry_date),
                mfg_date = COALESCE(?, mfg_date),
                alert_before_days = COALESCE(?, alert_before_days),
                pack_unit = COALESCE(?, pack_unit),
                pack_size = COALESCE(?, pack_size),
                pack_price = COALESCE(?, pack_price),
                product_type = COALESCE(?, product_type),
                is_rental = COALESCE(?, is_rental),
                updated_at = datetime('now')
                WHERE id = ?");
            $stmt->execute([$name, $sku, $barcode, $category, $unit, $costPrice, $sellingPrice, $minStockAlert, $imageUrl, $description, $hasExpiry, $batchNumber, $expiryDate, $mfgDate, $alertBeforeDays, $packUnit, $packSize, $packPrice, $productType, $isRental, $id]);
        } else {
            $stmt = $db->prepare("UPDATE products SET 
                name = ?, sku = ?, barcode = ?, category = ?, unit = ?, 
                cost_price = ?, selling_price = ?, min_stock_alert = ?, 
                description = ?,
                has_expiry = COALESCE(?, has_expiry),
                batch_number = COALESCE(?, batch_number),
                expiry_date = COALESCE(?, expiry_date),
                mfg_date = COALESCE(?, mfg_date),
                alert_before_days = COALESCE(?, alert_before_days),
                pack_unit = COALESCE(?, pack_unit),
                pack_size = COALESCE(?, pack_size),
                pack_price = COALESCE(?, pack_price),
                product_type = COALESCE(?, product_type),
                is_rental = COALESCE(?, is_rental),
                updated_at = datetime('now')
                WHERE id = ?");
            $stmt->execute([$name, $sku, $barcode, $category, $unit, $costPrice, $sellingPrice, $minStockAlert, $description, $hasExpiry, $batchNumber, $expiryDate, $mfgDate, $alertBeforeDays, $packUnit, $packSize, $packPrice, $productType, $isRental, $id]);
        }

        if ($unitsSent) {
            sfUnitsReplace($db, $id, $unitPlan['rows']);
        }

        if (isset($data['combo_items']) && is_array($data['combo_items'])) {
            sfSaveComboItems($db, $id, $data['combo_items']);
        }

        // If branch settings were updated
        if ($branchSettings && is_array($branchSettings)) {
            $binvStmt = $db->prepare("INSERT INTO branch_inventory (id, branch_code, product_id, current_quantity, reorder_level, custom_selling_price, is_available, updated_at)
                                      VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
                                      ON CONFLICT(branch_code, product_id) DO UPDATE SET
                                      current_quantity = excluded.current_quantity,
                                      reorder_level = excluded.reorder_level,
                                      custom_selling_price = excluded.custom_selling_price,
                                      is_available = excluded.is_available,
                                      updated_at = datetime('now')");

            foreach ($branchSettings as $b) {
                $bCode = strtoupper(trim($b['branch_code'] ?? ''));
                if (empty($bCode)) continue;
                $bStock = floatval($b['current_quantity'] ?? $b['stock'] ?? 0);
                $customPrice = (isset($b['custom_selling_price']) && $b['custom_selling_price'] !== '' && $b['custom_selling_price'] !== null)
                               ? round(floatval($b['custom_selling_price']), 2) : null;
                $isAvail = isset($b['is_available']) ? (intval($b['is_available']) ? 1 : 0) : 1;

                $binvId = 'binv_' . bin2hex(random_bytes(6));
                $binvStmt->execute([$binvId, $bCode, $id, $bStock, $minStockAlert, $customPrice, $isAvail]);
            }

            // Sync consolidated total in inventory
            $sumStmt = $db->prepare("SELECT SUM(current_quantity) FROM branch_inventory WHERE product_id = ?");
            $sumStmt->execute([$id]);
            $totalStock = floatval($sumStmt->fetchColumn() ?: 0.0);

            $invStmt = $db->prepare("UPDATE inventory SET current_quantity = ?, reorder_level = ?, updated_at = datetime('now') WHERE product_id = ?");
            $invStmt->execute([$totalStock, $minStockAlert, $id]);
        } else {
            if ($productType !== 'service' && (isset($data['current_stock']) || isset($data['initial_stock']))) {
                $newStock = floatval($data['current_stock'] ?? $data['initial_stock'] ?? 0);
                $bCode = $user['branch_code'] ?? 'MAIN-01';

                // Check previous stock
                $prevStmt = $db->prepare("SELECT current_quantity FROM branch_inventory WHERE branch_code = ? AND product_id = ?");
                $prevStmt->execute([$bCode, $id]);
                $prevStock = floatval($prevStmt->fetchColumn() ?: 0.0);

                // Upsert branch_inventory
                $upsertBinv = $db->prepare("INSERT INTO branch_inventory (id, branch_code, product_id, current_quantity, reorder_level, custom_selling_price, is_available, updated_at)
                                            VALUES (?, ?, ?, ?, ?, ?, 1, datetime('now'))
                                            ON CONFLICT(branch_code, product_id) DO UPDATE SET
                                            current_quantity = excluded.current_quantity,
                                            reorder_level = excluded.reorder_level,
                                            updated_at = datetime('now')");
                $upsertBinv->execute(['binv_' . bin2hex(random_bytes(6)), $bCode, $id, $newStock, $minStockAlert, $sellingPrice]);

                // Update inventory
                $invStmt = $db->prepare("INSERT INTO inventory (id, product_id, current_quantity, reorder_level, location, updated_at)
                                         VALUES (?, ?, ?, ?, ?, datetime('now'))
                                         ON CONFLICT(product_id) DO UPDATE SET
                                         current_quantity = excluded.current_quantity,
                                         reorder_level = excluded.reorder_level,
                                         updated_at = datetime('now')");
                $invStmt->execute(['inv_' . bin2hex(random_bytes(6)), $id, $newStock, $minStockAlert, $location]);

                // If stock was adjusted, log movement
                if ($newStock != $prevStock) {
                    $mvtStmt = $db->prepare("INSERT INTO inventory_movements (id, product_id, movement_type, quantity, reference_id, unit_price, notes, branch_code, created_at)
                                             VALUES (?, ?, 'ADJUSTMENT', ?, 'MANUAL_EDIT', ?, 'Stock updated via Edit Product', ?, datetime('now'))");
                    $mvtStmt->execute(['mvt_' . bin2hex(random_bytes(6)), $id, ($newStock - $prevStock), $costPrice, $bCode]);
                }
            } else {
                $invStmt = $db->prepare("UPDATE inventory SET reorder_level = ?, updated_at = datetime('now') WHERE product_id = ?");
                $invStmt->execute([$minStockAlert, $id]);
            }
        }

        $db->commit();

        logActivity($db, $user['id'], $user['full_name'], $user['role_name'], 'PRODUCT_UPDATE', "Updated product '{$name}' (SKU: {$sku}).");

        jsonResponse(['success' => true, 'message' => 'Product updated successfully']);
    } catch (Exception $e) {
        safeRollback($db);
        jsonResponse(['success' => false, 'message' => 'Failed to update product: ' . $e->getMessage()], 500);
    }
}

if ($method === 'DELETE') {
    $user = requirePermission('manage_inventory');

    $data = getJsonInput();
    $id = trim($data['id'] ?? $_GET['id'] ?? '');

    if (empty($id)) {
        jsonResponse(['success' => false, 'message' => 'Product ID is required'], 400);
    }

    $nameStmt = $db->prepare("SELECT name FROM products WHERE id = ?");
    $nameStmt->execute([$id]);
    $pName = $nameStmt->fetchColumn() ?: $id;

    $stmt = $db->prepare("UPDATE products SET is_active = 0, updated_at = datetime('now') WHERE id = ?");
    $stmt->execute([$id]);

    logActivity($db, $user['id'], $user['full_name'], $user['role_name'], 'PRODUCT_DELETE', "Archived product '{$pName}' (ID: {$id}).");

    jsonResponse(['success' => true, 'message' => 'Product archived successfully']);
}

jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
