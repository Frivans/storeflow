<?php
// api/endpoints/users.php
// Users (Store Managers, Cashiers, Admins) Management & Authentication
require_once __DIR__ . '/../config/db.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET') {
    $action = trim($_GET['action'] ?? '');

    // Return current authenticated user session if requested (always verify against database)
    if ($action === 'current' || $action === 'me') {
        $currentUser = getCurrentUser(true);
        if ($currentUser) {
            $currentUser['has_pin'] = !empty($currentUser['has_pin']);
            unset($currentUser['pin_code']);
            unset($currentUser['password_hash']);
            jsonResponse(['success' => true, 'authenticated' => true, 'user' => $currentUser]);
        } else {
            jsonResponse(['success' => false, 'authenticated' => false, 'message' => 'No active session'], 401);
        }
    }

    $currentUser = requireAuth();
    $isAdmin = (strtolower(trim($currentUser['role_name'] ?? '')) === 'administrator' || intval($currentUser['role_id'] ?? 0) === 1);
    $hasManageUsers = in_array('manage_users', $currentUser['permissions'] ?? []);

    if ($isAdmin || $hasManageUsers) {
        $sql = "SELECT u.id, u.role_id, u.username, u.full_name, u.email, u.phone, u.branch_code, u.is_active, u.created_at,
                       (CASE WHEN u.pin_code IS NOT NULL AND u.pin_code != '' THEN 1 ELSE 0 END) as has_pin,
                       r.role_name, r.permissions
                FROM users u
                JOIN user_roles r ON u.role_id = r.id
                ORDER BY u.id ASC";
        $stmt = $db->query($sql);
        $users = $stmt->fetchAll();

        foreach ($users as &$user) {
            $user['permissions'] = json_decode($user['permissions'] ?? '[]', true);
            $user['branch_code'] = $user['branch_code'] ?? 'MAIN-01';
            $user['has_pin'] = (bool)($user['has_pin'] ?? false);
        }

        jsonResponse(['success' => true, 'users' => $users]);
    } else {
        // Limited staff can only view themselves
        jsonResponse(['success' => true, 'users' => [$currentUser]]);
    }
}

if ($method === 'POST') {
    $data = getJsonInput();
    $action = trim((string)($data['action'] ?? 'save')); // 'save', 'login', 'logout'

    // Only these actions exist. Everything else used to fall through to the
    // create/update handler at the bottom of this block, and the forced-password-rotation
    // gate admits `current` as a safe action - so a session still on admin123 could POST
    // {"action":"current", ...} and mint a second Administrator that outlived the gate.
    $allowedPostActions = ['login', 'change_initial_password', 'unlock', 'logout', 'save'];
    if (!in_array($action, $allowedPostActions, true)) {
        jsonResponse(['success' => false, 'message' => 'Unrecognized user action.'], 400);
    }

    // 1. Login Endpoint
    if ($action === 'login') {
        $username = trim($data['username'] ?? '');
        $password = trim($data['password'] ?? '');

        if (empty($username) || empty($password)) {
            jsonResponse(['success' => false, 'message' => 'Username and password are required'], 400);
        }

        // Rate-limit failed attempts per client and per username. Matching on the log
        // text used to mean a username containing a wildcard broke the count, and
        // simply trying a different name reset it. clientIp() rather than REMOTE_ADDR
        // because a till reached through a tunnel would otherwise count every stranger
        // into one bucket and lock the owner out of their own shop.
        $clientIp = clientIp();
        $loginThrottleKey = 'login|' . $clientIp . '|' . strtolower($username);
        try {
            $inspect = throttleInspect($loginThrottleKey, 10, 300);
            if (!$inspect['allowed']) {
                jsonResponse([
                    'success' => false,
                    'message' => 'Too many failed login attempts. Please wait ' . $inspect['retry_after'] . ' seconds before trying again.'
                ], 429);
            }
        } catch (Exception $throttleEx) {
            error_log("Login rate limiting check error: " . $throttleEx->getMessage());
        }

        $stmt = $db->prepare("SELECT u.*, r.role_name, r.permissions, r.max_discount_pct 
                              FROM users u 
                              JOIN user_roles r ON u.role_id = r.id 
                              WHERE LOWER(u.username) = LOWER(?) AND u.is_active = 1");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password_hash'])) {
            $isDefaultAdmin = (strtolower($user['username']) === 'admin' && $password === 'admin123');
            $mustChange = !empty($user['must_change_password']) || $isDefaultAdmin;
            $user['must_change_password'] = (bool)$mustChange;

            unset($user['password_hash']);
            $user['has_pin'] = !empty($user['pin_code']);
            unset($user['pin_code']);
            $user['permissions'] = json_decode($user['permissions'] ?? '[]', true) ?: [];
            $user['branch_code'] = $user['branch_code'] ?? 'MAIN-01';

            // Secure session fixation protection
            if (session_status() === PHP_SESSION_ACTIVE) {
                session_regenerate_id(true);
            }
            setCurrentUser($user);
            throttleClear($loginThrottleKey);

            logActivity($db, $user['id'], $user['full_name'], $user['role_name'], 'LOGIN', "Staff member '{$user['username']}' signed in successfully.");

            jsonResponse([
                'success' => true,
                'message' => 'Login successful',
                'user' => $user
            ]);
        } else {
            // Brute-force delay to mitigate automated timing & dictionary attacks
            usleep(400000); // 400ms delay
            throttleRecord($loginThrottleKey, 300);
            logActivity($db, 0, $username, 'Unknown', 'LOGIN_FAILED', "Failed login attempt for username '{$username}'.");
            jsonResponse(['success' => false, 'message' => 'Invalid username or password'], 401);
        }
    }

    // 1b. Mandatory Initial Password Setup on First Run
    if ($action === 'change_initial_password') {
        $currentUser = getCurrentUser(true);
        if (!$currentUser) {
            jsonResponse(['success' => false, 'message' => 'Unauthorized or session expired'], 401);
        }
        $newPassword = trim($data['new_password'] ?? '');
        $newPin = trim($data['new_pin'] ?? '');

        if (strlen($newPassword) < 6) {
            jsonResponse(['success' => false, 'message' => 'New password must be at least 6 characters.'], 400);
        }
        if ($newPassword === 'admin123' || $newPassword === 'cashier123') {
            jsonResponse(['success' => false, 'message' => 'You cannot reuse default system passwords.'], 400);
        }
        if (!preg_match('/^\d{4}$/', $newPin)) {
            jsonResponse(['success' => false, 'message' => 'A 4-digit quick PIN is required (e.g. 5821).'], 400);
        }
        if ($newPin === '1234' || $newPin === '0000') {
            jsonResponse(['success' => false, 'message' => 'Please choose a more secure PIN than 1234 or 0000.'], 400);
        }

        $newHash = password_hash($newPassword, PASSWORD_BCRYPT);
        $pinHash = password_hash($newPin, PASSWORD_BCRYPT);
        $stmt = $db->prepare("UPDATE users SET password_hash = ?, pin_code = ?, must_change_password = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
        $stmt->execute([$newHash, $pinHash, $currentUser['id']]);

        $currentUser['must_change_password'] = false;
        $currentUser['has_pin'] = true;
        // Rotating the credential is the moment an eavesdropped or pre-set session id
        // stops being worth anything to whoever holds it, so it stops being the session.
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_regenerate_id(true);
        }
        setCurrentUser($currentUser);

        logActivity($db, $currentUser['id'], $currentUser['full_name'], $currentUser['role_name'], 'SECURITY_UPDATE', "Master password and PIN updated on first run.");
        jsonResponse(['success' => true, 'message' => 'Master credentials updated successfully!', 'user' => $currentUser]);
    }

    // 2. Unlock Endpoint (Quick PIN or Password verification for idle terminal lock)
    if ($action === 'unlock') {
        $currentUser = getCurrentUser(true);
        if (!$currentUser) {
            jsonResponse(['success' => false, 'message' => 'Session expired. Please sign in again.', 'session_expired' => true], 401);
        }

        $pinOrPass = trim($data['pin_or_password'] ?? '');
        if ($pinOrPass === '') {
            jsonResponse(['success' => false, 'message' => 'Password or PIN is required'], 400);
        }

        // The idle till unlocks with the same 4-digit PIN the login form uses, so the
        // per-attempt delay alone still left every combination reachable while nobody was
        // watching the counter. Cap guesses per user and client.
        $unlockThrottleKey = 'unlock|' . clientIp() . '|u' . ($currentUser['id'] ?? 0);
        $unlockInspect = throttleInspect($unlockThrottleKey, 5, 300);
        if (!$unlockInspect['allowed']) {
            jsonResponse([
                'success' => false,
                'message' => 'Too many incorrect unlock attempts. Please wait ' . $unlockInspect['retry_after'] . ' seconds before trying again.'
            ], 429);
        }

        $stmt = $db->prepare("SELECT u.id, u.username, u.password_hash, u.pin_code, u.full_name, r.role_name 
                              FROM users u 
                              JOIN user_roles r ON u.role_id = r.id 
                              WHERE u.id = ? AND u.is_active = 1");
        $stmt->execute([$currentUser['id']]);
        $row = $stmt->fetch();

        if (!$row) {
            jsonResponse(['success' => false, 'message' => 'User account not found or inactive', 'session_expired' => true], 401);
        }

        $isPass = password_verify($pinOrPass, $row['password_hash']);
        $isPin = false;
        if (!empty($row['pin_code'])) {
            if (strpos($row['pin_code'], '$2y$') === 0) {
                $isPin = password_verify($pinOrPass, $row['pin_code']);
            } else {
                $isPin = ($row['pin_code'] === $pinOrPass);
                if ($isPin) {
                    // Transparently upgrade plaintext PIN to BCRYPT
                    try {
                        $updPin = $db->prepare("UPDATE users SET pin_code = ? WHERE id = ?");
                        $updPin->execute([password_hash($pinOrPass, PASSWORD_BCRYPT), $row['id']]);
                    } catch (Exception $pe) {}
                }
            }
        }

        if ($isPass || $isPin) {
            throttleClear($unlockThrottleKey);
            logActivity($db, $row['id'], $row['full_name'], $row['role_name'], 'TERMINAL_UNLOCKED', "Terminal unlocked by staff '{$row['username']}'.");
            jsonResponse(['success' => true, 'message' => 'Terminal unlocked']);
        } else {
            usleep(300000); // 300ms anti-brute force delay
            throttleRecord($unlockThrottleKey, 300);
            logActivity($db, $row['id'], $row['full_name'], $row['role_name'], 'UNLOCK_FAILED', "Incorrect password or PIN entered while unlocking the terminal.");
            jsonResponse(['success' => false, 'message' => 'Incorrect password or PIN'], 401);
        }
    }

    // 3. Logout Endpoint
    if ($action === 'logout') {
        $curr = getCurrentUser();
        if ($curr) {
            logActivity($db, $curr['id'], $curr['full_name'], $curr['role_name'], 'LOGOUT', "Staff member '{$curr['username']}' logged out.");
        }
        clearCurrentUser();
        jsonResponse(['success' => true, 'message' => 'Logged out successfully']);
    }

    // 4. Save/Create or Update User (Requires manage_users permission)
    $authAdmin = requirePermission('manage_users');

    $id = intval($data['id'] ?? 0);
    $roleId = intval($data['role_id'] ?? 2);
    $username = trim($data['username'] ?? '');
    $password = trim($data['password'] ?? '');
    $pinCode = isset($data['pin_code']) ? trim($data['pin_code']) : null;
    $fullName = trim($data['full_name'] ?? '');
    $email = trim($data['email'] ?? '');
    $phone = trim($data['phone'] ?? '');
    $branchCode = trim($data['branch_code'] ?? 'MAIN-01');
    if (empty($branchCode)) $branchCode = 'MAIN-01';
    $isActive = isset($data['is_active']) ? intval($data['is_active']) : 1;

    if (empty($username) || empty($fullName)) {
        jsonResponse(['success' => false, 'message' => 'Username and full name are required'], 400);
    }

    if ($pinCode !== null && $pinCode !== '') {
        if (!preg_match('/^\d{4,6}$/', $pinCode)) {
            jsonResponse(['success' => false, 'message' => 'Quick Unlock PIN must be 4 to 6 numeric digits'], 400);
        }
    }

    // Check for username collision on other users
    $chkStmt = $db->prepare("SELECT id FROM users WHERE LOWER(username) = LOWER(?) AND id != ?");
    $chkStmt->execute([$username, $id]);
    if ($chkStmt->fetch()) {
        jsonResponse(['success' => false, 'message' => "The username '{$username}' is already taken."], 400);
    }

    try {
        $pinHash = ($pinCode !== null && $pinCode !== '') ? password_hash($pinCode, PASSWORD_BCRYPT) : null;

        if ($id > 0) {
            // Update
            if (!empty($password)) {
                $hash = password_hash($password, PASSWORD_BCRYPT);
                if ($pinCode !== null) {
                    $stmt = $db->prepare("UPDATE users SET role_id = ?, username = ?, full_name = ?, email = ?, phone = ?, branch_code = ?, is_active = ?, password_hash = ?, pin_code = ?, updated_at = datetime('now') WHERE id = ?");
                    $stmt->execute([$roleId, $username, $fullName, $email, $phone, $branchCode, $isActive, $hash, $pinHash, $id]);
                } else {
                    $stmt = $db->prepare("UPDATE users SET role_id = ?, username = ?, full_name = ?, email = ?, phone = ?, branch_code = ?, is_active = ?, password_hash = ?, updated_at = datetime('now') WHERE id = ?");
                    $stmt->execute([$roleId, $username, $fullName, $email, $phone, $branchCode, $isActive, $hash, $id]);
                }
            } else {
                if ($pinCode !== null) {
                    $stmt = $db->prepare("UPDATE users SET role_id = ?, username = ?, full_name = ?, email = ?, phone = ?, branch_code = ?, is_active = ?, pin_code = ?, updated_at = datetime('now') WHERE id = ?");
                    $stmt->execute([$roleId, $username, $fullName, $email, $phone, $branchCode, $isActive, $pinHash, $id]);
                } else {
                    $stmt = $db->prepare("UPDATE users SET role_id = ?, username = ?, full_name = ?, email = ?, phone = ?, branch_code = ?, is_active = ?, updated_at = datetime('now') WHERE id = ?");
                    $stmt->execute([$roleId, $username, $fullName, $email, $phone, $branchCode, $isActive, $id]);
                }
            }
            logActivity($db, $authAdmin['id'], $authAdmin['full_name'], $authAdmin['role_name'], 'USER_UPDATE', "Updated staff account '{$username}' (ID {$id}, Branch {$branchCode}).");
            $msg = 'User updated successfully';
        } else {
            // Create
            if (empty($password)) {
                jsonResponse(['success' => false, 'message' => 'A password is required for new accounts'], 400);
            }
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $db->prepare("INSERT INTO users (role_id, username, password_hash, pin_code, full_name, email, phone, branch_code, is_active, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))");
            $stmt->execute([$roleId, $username, $hash, $pinHash, $fullName, $email, $phone, $branchCode, $isActive]);
            logActivity($db, $authAdmin['id'], $authAdmin['full_name'], $authAdmin['role_name'], 'USER_CREATE', "Created new staff user '{$username}' ({$fullName}, Branch {$branchCode}).");
            $msg = 'User created successfully';
        }

        jsonResponse(['success' => true, 'message' => $msg]);
    } catch (Exception $e) {
        jsonResponse(['success' => false, 'message' => 'Failed to save user: ' . $e->getMessage()], 500);
    }
}

if ($method === 'DELETE') {
    $authAdmin = requirePermission('manage_users');

    $id = intval($_GET['id'] ?? 0);
    if ($id <= 0) {
        $data = getJsonInput();
        $id = intval($data['id'] ?? 0);
    }

    if ($id <= 1) {
        jsonResponse(['success' => false, 'message' => 'The primary Administrator account cannot be deleted.'], 400);
    }

    if ($id === intval($authAdmin['id'])) {
        jsonResponse(['success' => false, 'message' => 'You cannot delete your own active account.'], 400);
    }

    try {
        $look = $db->prepare("SELECT id, username, full_name FROM users WHERE id = ?");
        $look->execute([$id]);
        $retired = $look->fetch();
        if (!$retired) {
            jsonResponse(['success' => false, 'message' => 'No such staff account.'], 404);
        }

        // Retire the account, do not erase the row. sales.user_id points at it for the life
        // of the book and has no foreign key to lean on, so deleting a cashier left every
        // receipt they ever rang up with nobody's name beside it - the staff board lost the
        // row, and an owner reconciling a till could not say who took the money. Login only
        // accepts is_active = 1, so this closes the door just as hard.
        $stmt = $db->prepare("UPDATE users SET is_active = 0, updated_at = datetime('now') WHERE id = ?");
        $stmt->execute([$id]);
        logActivity($db, $authAdmin['id'], $authAdmin['full_name'], $authAdmin['role_name'], 'USER_DEACTIVATED',
            "Retired staff account '{$retired['username']}' ({$retired['full_name']}, ID {$id}). "
            . "The account can no longer sign in; the receipts it rang up keep its name.");
        jsonResponse([
            'success' => true,
            'deactivated' => true,
            'message' => "Staff account '{$retired['username']}' retired. It can no longer sign in, "
                . "and the sales it rang up still name it. Reactivate it from the staff list any time."
        ]);
    } catch (Exception $e) {
        jsonResponse(['success' => false, 'message' => 'Failed to retire user: ' . $e->getMessage()], 500);
    }
}

jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
