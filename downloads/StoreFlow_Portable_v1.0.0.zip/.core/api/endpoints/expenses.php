<?php
// api/endpoints/expenses.php
// Store Operating Expenses & Cash Drawer Payouts Ledger
require_once __DIR__ . '/../config/db.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET') {
    $authUser = requireAuth();
    $roleName = strtolower(trim($authUser['role_name'] ?? ''));
    $isAdmin = ($roleName === 'administrator' || intval($authUser['role_id'] ?? 0) === 1);
    $isManager = ($roleName === 'store manager');

    $startDate = trim($_GET['start_date'] ?? '');
    $endDate = trim($_GET['end_date'] ?? '');
    $singleDate = trim($_GET['date'] ?? '');
    $category = trim($_GET['category'] ?? '');
    $paymentSource = trim($_GET['payment_source'] ?? '');
    $branchCode = trim($_GET['branch_code'] ?? '');
    $limit = intval($_GET['limit'] ?? 100);
    if ($limit <= 0 || $limit > 500) $limit = 100;

    $sql = "SELECT e.*, u.username, u.full_name as user_full_name 
            FROM expenses e 
            LEFT JOIN users u ON e.user_id = u.id 
            WHERE 1=1";
    $params = [];

    // Cashiers are restricted to their own branch or terminal
    if (!$isAdmin && !$isManager) {
        if (!empty($authUser['branch_code']) && $authUser['branch_code'] !== 'ALL') {
            $sql .= " AND (e.branch_code = ? OR e.branch_code = 'ALL')";
            $params[] = $authUser['branch_code'];
        }
    } elseif (!empty($branchCode) && $branchCode !== 'ALL') {
        $sql .= " AND e.branch_code = ?";
        $params[] = $branchCode;
    }

    if (!empty($singleDate)) {
        $sql .= " AND (DATE(e.expense_date) = ? OR e.expense_date LIKE ?)";
        $params[] = $singleDate;
        $params[] = "{$singleDate}%";
    } else {
        if (!empty($startDate)) {
            $sql .= " AND DATE(e.expense_date) >= ?";
            $params[] = $startDate;
        }
        if (!empty($endDate)) {
            $sql .= " AND DATE(e.expense_date) <= ?";
            $params[] = $endDate;
        }
    }

    if (!empty($category) && $category !== 'All') {
        $sql .= " AND e.category = ?";
        $params[] = $category;
    }

    if (!empty($paymentSource) && $paymentSource !== 'All') {
        $sql .= " AND e.payment_source = ?";
        $params[] = $paymentSource;
    }

    $sql .= " ORDER BY e.expense_date DESC, e.created_at DESC LIMIT ?";
    $params[] = $limit;

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $expenses = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Calculate Summary Metrics
    $totalAmount = 0.0;
    $drawerPayoutsTotal = 0.0;
    $bankMomoTotal = 0.0;
    $pettyCashTotal = 0.0;
    $byCategory = [];

    foreach ($expenses as $exp) {
        $amt = (float)$exp['amount'];
        $totalAmount += $amt;
        $src = strtoupper(trim($exp['payment_source'] ?? 'CASH_DRAWER'));
        $cat = trim($exp['category'] ?? 'General');

        if ($src === 'CASH_DRAWER') {
            $drawerPayoutsTotal += $amt;
        } elseif ($src === 'BANK_TRANSFER' || $src === 'MOBILE_MONEY') {
            $bankMomoTotal += $amt;
        } elseif ($src === 'PETTY_CASH') {
            $pettyCashTotal += $amt;
        }

        $byCategory[$cat] = ($byCategory[$cat] ?? 0.0) + $amt;
    }

    jsonResponse([
        'success' => true,
        'expenses' => $expenses,
        'count' => count($expenses),
        'summary' => [
            'total_amount' => round($totalAmount, 2),
            'drawer_payouts_total' => round($drawerPayoutsTotal, 2),
            'bank_momo_total' => round($bankMomoTotal, 2),
            'petty_cash_total' => round($pettyCashTotal, 2),
            'by_category' => $byCategory
        ]
    ]);
}

if ($method === 'POST') {
    // Both cashiers and managers can record an operational expense or drawer payout
    $authUser = requirePermission('manage_sales');
    $data = getJsonInput();
    if (empty($data)) {
        $data = $_POST;
    }

    $title = trim($data['title'] ?? '');
    $amount = round(floatval($data['amount'] ?? 0), 2);
    $category = trim($data['category'] ?? 'General');
    $paymentSource = strtoupper(trim($data['payment_source'] ?? 'CASH_DRAWER'));
    $paidTo = trim($data['paid_to'] ?? '');
    $receiptRef = trim($data['receipt_ref'] ?? '');
    $notes = trim($data['notes'] ?? '');
    $branchCode = trim($data['branch_code'] ?? ($authUser['branch_code'] ?? 'MAIN-01'));
    $terminalId = trim($data['terminal_id'] ?? 'REG-01');
    $shiftId = trim($data['shift_id'] ?? '') ?: null;
    $expenseDate = trim($data['expense_date'] ?? date('Y-m-d'));

    if (empty($title)) {
        jsonResponse(['success' => false, 'message' => 'Expense title/purpose is required'], 400);
    }
    if ($amount <= 0) {
        jsonResponse(['success' => false, 'message' => 'Expense amount must be greater than zero'], 400);
    }

    $id = trim($data['id'] ?? ('exp_' . bin2hex(random_bytes(6))));
    $expenseNumber = trim($data['expense_number'] ?? ('EXP-' . date('Ymd') . '-' . rand(1000, 9999)));
    $recordedBy = $authUser['full_name'] ?: ($authUser['username'] ?: 'Cashier');

    $expIsSuper = (strtolower(trim($authUser['role_name'] ?? '')) === 'administrator'
        || intval($authUser['role_id'] ?? 0) === 1);
    if (!$expIsSuper) {
        $ownBranch = strtoupper(trim((string)($authUser['branch_code'] ?? 'MAIN-01')));
        if ($ownBranch !== '' && strtoupper($branchCode) !== $ownBranch) {
            jsonResponse(['success' => false,
                'message' => "Access denied: You are assigned to branch {$ownBranch} and cannot record an expense against {$branchCode}."], 403);
        }
    }

    // A drifted till clock must not file tomorrow's rent in a period the owner has not
    // closed yet, where it silently joins the wrong day's totals.
    $claimedExpenseEpoch = strtotime($expenseDate);
    if ($claimedExpenseEpoch === false || $claimedExpenseEpoch > time() + 120) {
        $expenseDate = date('Y-m-d');
    }

    try {
        // The row id came from the request into an INSERT OR REPLACE, so posting an
        // existing expense number back overwrote it in place: the amount, what it was
        // spent on and who recorded it all changed, and nothing said so.
        $clashStmt = $db->prepare("SELECT id, title FROM expenses WHERE id = ?");
        $clashStmt->execute([$id]);
        $clash = $clashStmt->fetch(PDO::FETCH_ASSOC);
        if ($clash) {
            jsonResponse([
                'success' => false,
                'message' => "An expense already exists with id '{$id}' ('{$clash['title']}'). Recording does not overwrite a posted expense - amend it from the expense list instead."
            ], 409);
        }

        $stmt = $db->prepare("INSERT INTO expenses (
            id, expense_number, title, category, amount, payment_source, paid_to, 
            receipt_ref, notes, branch_code, terminal_id, shift_id, user_id, 
            recorded_by, expense_date, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))");

        $stmt->execute([
            $id,
            $expenseNumber,
            $title,
            $category,
            $amount,
            $paymentSource,
            $paidTo,
            $receiptRef,
            $notes,
            $branchCode,
            $terminalId,
            $shiftId,
            $authUser['id'],
            $recordedBy,
            $expenseDate
        ]);

        // Audit Trail
        logActivity(
            $db,
            $authUser['id'],
            $recordedBy,
            $authUser['role_name'],
            'RECORD_EXPENSE',
            "Recorded expense #{$expenseNumber}: '{$title}' - \${$amount} ({$paymentSource})"
        );

        jsonResponse([
            'success' => true,
            'message' => 'Expense recorded successfully',
            'expense' => [
                'id' => $id,
                'expense_number' => $expenseNumber,
                'title' => $title,
                'category' => $category,
                'amount' => $amount,
                'payment_source' => $paymentSource,
                'paid_to' => $paidTo,
                'receipt_ref' => $receiptRef,
                'notes' => $notes,
                'branch_code' => $branchCode,
                'terminal_id' => $terminalId,
                'shift_id' => $shiftId,
                'user_id' => $authUser['id'],
                'recorded_by' => $recordedBy,
                'expense_date' => $expenseDate,
                'created_at' => date('Y-m-d H:i:s')
            ]
        ], 201);
    } catch (Exception $e) {
        jsonResponse([
            'success' => false,
            'message' => 'Failed to record expense: ' . $e->getMessage()
        ], 500);
    }
}

if ($method === 'DELETE') {
    $authUser = requirePermission('manage_settings');
    $id = trim($_GET['id'] ?? '');

    if (empty($id)) {
        jsonResponse(['success' => false, 'message' => 'Expense ID is required'], 400);
    }

    try {
        $stmt = $db->prepare("SELECT * FROM expenses WHERE id = ?");
        $stmt->execute([$id]);
        $expense = $stmt->fetch();

        if (!$expense) {
            jsonResponse(['success' => false, 'message' => 'Expense record not found'], 404);
        }

        $delStmt = $db->prepare("DELETE FROM expenses WHERE id = ?");
        $delStmt->execute([$id]);

        logActivity(
            $db,
            $authUser['id'],
            $authUser['full_name'],
            $authUser['role_name'],
            'DELETE_EXPENSE',
            "Deleted expense record #{$expense['expense_number']}: '{$expense['title']}' (\${$expense['amount']})"
        );

        jsonResponse([
            'success' => true,
            'message' => 'Expense deleted successfully'
        ]);
    } catch (Exception $e) {
        jsonResponse(['success' => false, 'message' => 'Delete failed: ' . $e->getMessage()], 500);
    }
}

jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
