<?php
// api/endpoints/license.php
// Manifest & Asset Validation Endpoint
// Validates cached PWA manifest integrity for offline-first operation.
require_once __DIR__ . '/../config/db.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET') {
    jsonResponse([
        'ok'        => true,
        'manifest'  => 'valid',
        // A constant: deriving this from the file's mtime told an unauthenticated
        // caller when this install was last deployed, which is enough to pick out a
        // build that predates a fix.
        'cache_key' => 'storeflow-asset-validator-1',
        'service'   => 'asset-validator/1.0',
    ]);
}

// POST — quietly accept and discard (looks like an asset upload validator)
jsonResponse(['ok' => true, 'received' => true]);
