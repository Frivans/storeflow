<?php
// api/endpoints/system.php
// System Health & Heartbeat Endpoint
// Actions: heartbeat (scope check), sync (token apply), node (machine ref for support)
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/sys_integrity.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$action = $_GET['action'] ?? 'heartbeat';

// ── GET ?action=heartbeat — returns session scope (trial / full / locked) ─────
if ($method === 'GET' && $action === 'heartbeat') {
    // Unauthenticated — called even on paywall screen before login
    $scope = _sysGetScope($db);

    // Translate internal scope names to frontend-friendly ones
    // (deliberately different from the DB values so grep of JS/HTML doesn't match DB)
    $map = ['LIMITED' => 'trial', 'FULL' => 'active', 'LOCKED' => 'expired'];

    jsonResponse([
        'ok'         => true,
        'version'    => STOREFLOW_VERSION,       // so the About pane reports the build actually installed
        'status'     => $map[$scope['scope']] ?? 'expired',
        'quota'      => $scope['days_left'],
        'total'      => $scope['quota_days'],
        'used'       => $scope['days_used'],
        'ref'        => $scope['machine_ref'],    // machine fingerprint for support
        'since'      => $scope['unlocked_at'],
        'is_initial' => !empty($scope['is_initial'])
    ]);
}

// ── POST ?action=sync — submit an unlock token ────────────────────────────────
if ($method === 'POST' && $action === 'sync') {
    $gate = _sysThrottleInspect();
    if (!$gate['allowed']) {
        logActivity($db, 1, 'System Administrator', 'Administrator', 'LICENSE_THROTTLED',
            'Activation locked out after ' . $gate['used'] . ' attempts; ' . $gate['retry_after'] . 's remaining.');
        jsonResponse([
            'ok'          => false,
            'msg'         => 'Too many activation attempts. Wait ' . $gate['retry_after'] . ' seconds and try again.',
            'retry_after' => $gate['retry_after']
        ], 429);
    }
    _sysThrottleRecord();

    $data  = getJsonInput();
    $token = trim($data['token'] ?? '');

    if (empty($token)) {
        jsonResponse(['ok' => false, 'msg' => 'No token provided.'], 400);
    }

    $result = _sysApplyToken($db, $token);
    $scope  = _sysGetScope($db);
    $map    = ['LIMITED' => 'trial', 'FULL' => 'active', 'LOCKED' => 'expired'];
    $status = $map[$scope['scope']] ?? 'expired';

    if ($result['ok']) {
        _sysThrottleClear();
        logActivity($db, 1, 'System Administrator', 'Administrator', 'LICENSE_ACTIVATED', "License unlock key successfully applied: " . substr($token, 0, 12) . "... (" . ($result['msg'] ?? 'Activated') . ")");
    } else {
        logActivity($db, 1, 'System Administrator', 'Administrator', 'LICENSE_FAILED', "Failed license key activation attempt: " . substr($token, 0, 12) . "... (" . ($result['msg'] ?? 'Invalid token') . ")");
    }
    jsonResponse([
        'ok'     => $result['ok'],
        'msg'    => $result['msg'],
        'status' => $status,
        'quota'  => $scope['days_left'],
        'total'  => $scope['quota_days']
    ], $result['ok'] ? 200 : 400);
}

// ── GET ?action=node — returns machine ref (admin only, for support) ──────────
if ($method === 'GET' && $action === 'node') {
    requirePermission('manage_settings');
    _sysEnsureMeta($db);
    jsonResponse([
        'ok'  => true,
        'ref' => _sysMachineRef($db),
    ]);
}

jsonResponse(['ok' => false, 'msg' => 'Unknown action.'], 400);
