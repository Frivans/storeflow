<?php
// api/endpoints/profile.php
require_once __DIR__ . '/../config/db.php';

// Ensure mNotify columns exist in store_profile
try {
    $cols = $db->query("PRAGMA table_info(store_profile)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('mnotify_api_key', $cols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN mnotify_api_key TEXT DEFAULT ''");
    }
    if (!in_array('mnotify_sender_id', $cols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN mnotify_sender_id TEXT DEFAULT 'StoreFlow'");
    }
    if (!in_array('mnotify_auto_sms', $cols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN mnotify_auto_sms INTEGER DEFAULT 0");
    }
    if (!in_array('operating_mode', $cols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN operating_mode TEXT DEFAULT 'RETAIL'");
    }
    if (!in_array('enable_rentals', $cols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN enable_rentals INTEGER DEFAULT 1");
    }
    if (!in_array('estimate_validity_days', $cols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN estimate_validity_days INTEGER DEFAULT 7");
    }
    if (!in_array('enable_line_discounts', $cols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN enable_line_discounts INTEGER DEFAULT 0");
    }
} catch (Exception $e) {}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET') {
    $authUser = requireAuth();

    $stmt = $db->query("SELECT * FROM store_profile WHERE id = 1");
    $profile = $stmt->fetch();

    // The provider key is only ever needed server-side to send SMS. The settings form
    // renders a truthy/falsy placeholder and posts '********' back to mean "unchanged",
    // so returning a mask keeps the form working without leaking the credential.
    // maskProfileForClient() is shared with sync.php so the two cannot drift apart.
    $profile = maskProfileForClient($profile, $authUser);

    // Append session scope (trial / full / locked) under neutral key 'meta'
    require_once __DIR__ . '/../config/sys_integrity.php';
    $s = _sysGetScope($db);
    $scopeMap = ['LIMITED' => 'trial', 'FULL' => 'active', 'LOCKED' => 'expired'];

    jsonResponse([
        'success' => true,
        'profile' => $profile,
        'meta'    => [
            'scope'  => $scopeMap[$s['scope']] ?? 'expired',
            'quota'  => $s['days_left'],
            'total'  => $s['quota_days'],
            'ref'    => $s['machine_ref'],
            'since'  => $s['unlocked_at'],
        ]
    ]);
}

if ($method === 'POST') {
    $user = requirePermission('manage_settings');
    $data = getJsonInput();
    
    // Quick operating mode toggle support without rewriting entire profile
    if ((isset($data['action']) && $data['action'] === 'set_mode') || (count($data) === 1 && isset($data['operating_mode']))) {
        $mode = strtoupper(trim($data['operating_mode'] ?? 'RETAIL'));
        if (!in_array($mode, ['RETAIL', 'HOSPITALITY', 'HYBRID'])) {
            $mode = 'RETAIL';
        }
        $stmt = $db->prepare("UPDATE store_profile SET operating_mode = ?, updated_at = datetime('now') WHERE id = 1");
        $stmt->execute([$mode]);
        jsonResponse(['success' => true, 'operating_mode' => $mode]);
    }

    if (isset($data['action']) && $data['action'] === 'toggle_rentals') {
        $enabled = !empty($data['enable_rentals']) ? 1 : 0;
        $stmt = $db->prepare("UPDATE store_profile SET enable_rentals = ?, updated_at = datetime('now') WHERE id = 1");
        $stmt->execute([$enabled]);
        jsonResponse(['success' => true, 'enable_rentals' => $enabled]);
    }

    // The loyalty policy is the shop's own decision, so it is saved here rather than baked into
    // the product: whether points exist at all, what a cedi earns, what a point is worth back,
    // whether a member may hand points in at the counter, and whether a tier's percentage perk
    // is honoured. A festive-gift shop and a plain spend-and-earn shop get what they set.
    //
    // It is deliberately NOT part of the big UPDATE below. The settings form posts every field
    // it knows about; letting it also carry these five meant a shop saving its receipt footer
    // could reset its points rate to the shipped default without anybody touching the loyalty
    // box. Here, a figure only changes when the request names it.
    if (isset($data['action']) && $data['action'] === 'set_loyalty_policy') {
        require_once __DIR__ . '/../config/loyalty.php';
        $flags = ['loyalty_enabled', 'loyalty_redeem_at_counter', 'loyalty_tier_perks'];
        $rates = [
            // Points a cedi of goods earns. Zero is legal: it switches accrual off without
            // switching the scheme off, which is what "pause the promotion" looks like.
            'loyalty_points_per_currency' => [0.0, 1000.0],
            // What one point is worth off the bill. The cap is a fat-finger guard only - the
            // server already refuses to let points eat the tax or exceed the member's balance.
            'loyalty_redemption_rate'     => [0.0, 1.0],
        ];

        $sets = [];
        $binds = [];
        $problem = null;
        foreach ($flags as $key) {
            if (!array_key_exists($key, $data)) continue;
            $sets[] = "{$key} = ?";
            $binds[] = (intval($data[$key]) === 1 || $data[$key] === true || $data[$key] === 'true') ? 1 : 0;
        }
        foreach ($rates as $key => $range) {
            if (!array_key_exists($key, $data)) continue;
            [$lo, $hi] = $range;
            $raw = $data[$key];
            $val = is_numeric($raw) ? round(floatval($raw), 4) : null;
            if ($val === null || $val < $lo || $val > $hi) {
                $problem = sprintf('%s must be a number between %s and %s.', $key, number_format($lo, 2), number_format($hi, 2));
                break;
            }
            $sets[] = "{$key} = ?";
            $binds[] = $val;
        }
        if ($problem !== null) {
            jsonResponse(['success' => false, 'message' => $problem . ' Nothing was changed.'], 400);
        }
        if (!$sets) {
            jsonResponse(['success' => false, 'message' => 'No loyalty setting was named in the request.'], 400);
        }

        $binds[] = date('Y-m-d H:i:s');
        $db->prepare("UPDATE store_profile SET " . implode(', ', $sets) . ", updated_at = ? WHERE id = 1")
           ->execute($binds);

        $policy = StoreFlowLoyalty::settings($db, true);
        logActivity($db, $user['id'], $user['full_name'], $user['role_name'], 'SETTINGS_UPDATE',
            'Loyalty policy: ' . json_encode($policy));
        jsonResponse(['success' => true, 'loyalty_policy' => $policy]);
    }

    $storeName = trim($data['store_name'] ?? 'My Store');
    $tagline = trim($data['tagline'] ?? '');
    $phone = trim($data['phone'] ?? '');
    $email = trim($data['email'] ?? '');
    $address = trim($data['address'] ?? '');
    $taxNumber = trim($data['tax_number'] ?? '');
    $taxRate = max(0, min(100, floatval($data['tax_rate'] ?? 0)));
    $currencySymbol = trim($data['currency_symbol'] ?? '$');
    $currencyCode = trim($data['currency_code'] ?? 'USD');
    $receiptHeader = trim($data['receipt_header'] ?? '');
    $receiptFooter = trim($data['receipt_footer'] ?? '');
    $receiptMomoNote = trim($data['receipt_momo_note'] ?? '');
    $showTaxOnReceipt = isset($data['show_tax_on_receipt']) ? intval($data['show_tax_on_receipt']) : 1;
    $showCashierOnReceipt = isset($data['show_cashier_on_receipt']) ? intval($data['show_cashier_on_receipt']) : 1;
    $receiptFontSize = trim($data['receipt_font_size'] ?? 'medium');
    $receiptFontWeight = trim($data['receipt_font_weight'] ?? 'normal');
    $receiptFontFamily = trim($data['receipt_font_family'] ?? 'monospace');
    $receiptPaperWidth = trim($data['receipt_paper_width'] ?? '80mm');
    $autoBackupHours = intval($data['auto_backup_hours'] ?? 2);
    if ($autoBackupHours < 1) $autoBackupHours = 2;
    $allowNegativeStock = isset($data['allow_negative_stock']) ? intval($data['allow_negative_stock']) : 0;
    $branchCode = trim($data['branch_code'] ?? 'MAIN-01');
    $terminalId = trim($data['terminal_id'] ?? 'REG-01');
    $isMultiBranch = isset($data['is_multi_branch']) ? intval($data['is_multi_branch']) : 0;
    $logoUrl = array_key_exists('logo_url', $data) ? $data['logo_url'] : null;
    $printLogoOnReceipts = isset($data['print_logo_on_receipts']) ? intval($data['print_logo_on_receipts']) : 1;

    // mNotify SMS Configuration
    $mnotifyApiKey = array_key_exists('mnotify_api_key', $data) ? trim($data['mnotify_api_key']) : null;
    $mnotifySenderId = trim($data['mnotify_sender_id'] ?? 'StoreFlow');
    $mnotifyAutoSms = isset($data['mnotify_auto_sms']) ? intval($data['mnotify_auto_sms']) : 0;
    $mnotifyOwnerPhone = trim($data['mnotify_owner_phone'] ?? '');
    $mnotifyLowStockAlert = isset($data['mnotify_low_stock_alert']) ? intval($data['mnotify_low_stock_alert']) : 1;
    $mnotifyShiftCloseAlert = isset($data['mnotify_shift_close_alert']) ? intval($data['mnotify_shift_close_alert']) : 1;

    // If mnotify_api_key is not passed or masked, preserve existing
    if ($mnotifyApiKey === null || strpos($mnotifyApiKey, '***') !== false) {
        $curr = $db->query("SELECT mnotify_api_key FROM store_profile WHERE id = 1")->fetch();
        $mnotifyApiKey = $curr['mnotify_api_key'] ?? '';
    }

    // Operating Mode: RETAIL, HOSPITALITY, or HYBRID
    $operatingMode = isset($data['operating_mode']) ? strtoupper(trim($data['operating_mode'])) : null;
    if ($operatingMode !== null && !in_array($operatingMode, ['RETAIL', 'HOSPITALITY', 'HYBRID'])) {
        $operatingMode = 'RETAIL';
    }

    $estimateValidityDays = max(1, min(365, intval($data['estimate_validity_days'] ?? 7)));
    $enableLineDiscounts = !empty($data['enable_line_discounts']) ? 1 : 0;

    $stmt = $db->prepare("UPDATE store_profile SET 
        store_name = ?,
        tagline = ?,
        phone = ?,
        email = ?,
        address = ?,
        tax_number = ?,
        tax_rate = ?,
        currency_symbol = ?,
        currency_code = ?,
        receipt_header = ?,
        receipt_footer = ?,
        receipt_momo_note = ?,
        show_tax_on_receipt = ?,
        show_cashier_on_receipt = ?,
        receipt_font_size = ?,
        receipt_font_weight = ?,
        receipt_font_family = ?,
        receipt_paper_width = ?,
        auto_backup_hours = ?,
        allow_negative_stock = ?,
        branch_code = ?,
        terminal_id = ?,
        is_multi_branch = ?,
        logo_url = ?,
        print_logo_on_receipts = ?,
        mnotify_api_key = ?,
        mnotify_sender_id = ?,
        mnotify_auto_sms = ?,
        mnotify_owner_phone = ?,
        mnotify_low_stock_alert = ?,
        mnotify_shift_close_alert = ?,
        operating_mode = COALESCE(?, operating_mode),
        estimate_validity_days = ?,
        enable_line_discounts = ?,
        updated_at = datetime('now')
        WHERE id = 1");

    $stmt->execute([
        $storeName,
        $tagline,
        $phone,
        $email,
        $address,
        $taxNumber,
        $taxRate,
        $currencySymbol,
        $currencyCode,
        $receiptHeader,
        $receiptFooter,
        $receiptMomoNote,
        $showTaxOnReceipt,
        $showCashierOnReceipt,
        $receiptFontSize,
        $receiptFontWeight,
        $receiptFontFamily,
        $receiptPaperWidth,
        $autoBackupHours,
        $allowNegativeStock,
        $branchCode,
        $terminalId,
        $isMultiBranch,
        $logoUrl,
        $printLogoOnReceipts,
        $mnotifyApiKey,
        $mnotifySenderId,
        $mnotifyAutoSms,
        $mnotifyOwnerPhone,
        $mnotifyLowStockAlert,
        $mnotifyShiftCloseAlert,
        $operatingMode,
        $estimateValidityDays,
        $enableLineDiscounts
    ]);

    $stmt = $db->query("SELECT * FROM store_profile WHERE id = 1");
    $updated = $stmt->fetch();

    logActivity($db, $user['id'], $user['full_name'], $user['role_name'], 'SETTINGS_UPDATE', "Updated store profile and configuration.");

    jsonResponse([
        'success' => true,
        'message' => 'Store profile updated successfully',
        // The GET path masks this row; the write path re-read it raw and handed the
        // saved SMS provider key and scanner pairing token straight back to the browser,
        // where devtools, an extension or any stored XSS could read them.
        'profile' => maskProfileForClient($updated, $user)
    ]);
}

jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
