<?php
// api/endpoints/returns.php
// Sales Returns, Merchandise Restocking & Customer Refunds (Credit Notes)
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/product_units.php';

// Ensure tables exist
try {
    $db->exec("CREATE TABLE IF NOT EXISTS sales_returns (
        id TEXT PRIMARY KEY,
        return_number TEXT UNIQUE NOT NULL,
        sale_id TEXT NOT NULL,
        receipt_number TEXT NOT NULL,
        customer_id TEXT DEFAULT 'cust-walkin',
        customer_name TEXT DEFAULT 'Walk-in Customer',
        user_id INTEGER,
        cashier_name TEXT NOT NULL,
        terminal_id TEXT DEFAULT 'REG-01',
        branch_code TEXT DEFAULT 'MAIN-01',
        total_refund_amount REAL NOT NULL DEFAULT 0.0,
        refund_method TEXT NOT NULL DEFAULT 'CASH',
        return_date TEXT NOT NULL,
        reason TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (sale_id) REFERENCES sales(id),
        FOREIGN KEY (customer_id) REFERENCES customers(id)
    )");

    $db->exec("CREATE TABLE IF NOT EXISTS sales_return_items (
        id TEXT PRIMARY KEY,
        return_id TEXT NOT NULL,
        product_id TEXT NOT NULL,
        product_name TEXT NOT NULL,
        quantity REAL NOT NULL,
        unit TEXT DEFAULT '',
        multiplier REAL DEFAULT 1,
        base_quantity REAL DEFAULT 0,
        unit_price REAL NOT NULL,
        refund_subtotal REAL NOT NULL,
        item_condition TEXT DEFAULT 'RESTOCK',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (return_id) REFERENCES sales_returns(id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products(id)
    )");

    // The same three columns db.php adds to an existing install; kept here so a database
    // that was created before sizing arrived still gets them the first time a return runs.
    $retItemCols = $db->query("PRAGMA table_info(sales_return_items)")->fetchAll(PDO::FETCH_COLUMN, 1);
    foreach ([
        'unit' => "ALTER TABLE sales_return_items ADD COLUMN unit TEXT DEFAULT ''",
        'multiplier' => "ALTER TABLE sales_return_items ADD COLUMN multiplier REAL DEFAULT 1",
        'base_quantity' => "ALTER TABLE sales_return_items ADD COLUMN base_quantity REAL DEFAULT 0",
    ] as $col => $ddl) {
        if (!in_array($col, $retItemCols, true)) $db->exec($ddl);
    }

    // And the same for the header's apportioned figures, which the credit note prints and the
    // return INSERT names - see saleRefundSplit().
    $retHeadCols = $db->query("PRAGMA table_info(sales_returns)")->fetchAll(PDO::FETCH_COLUMN, 1);
    foreach ([
        'refund_gross' => "ALTER TABLE sales_returns ADD COLUMN refund_gross REAL DEFAULT 0.0",
        'refund_discount_share' => "ALTER TABLE sales_returns ADD COLUMN refund_discount_share REAL DEFAULT 0.0",
        'refund_tax_share' => "ALTER TABLE sales_returns ADD COLUMN refund_tax_share REAL DEFAULT 0.0",
    ] as $col => $ddl) {
        if (!in_array($col, $retHeadCols, true)) $db->exec($ddl);
    }
} catch (Exception $e) {}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET') {
    $authUser = requireAuth();

    $action = trim($_GET['action'] ?? '');

    // Look up original sale with line items for returning
    if ($action === 'lookup_sale') {
        $receipt = trim($_GET['receipt_number'] ?? '');
        $saleId = trim($_GET['sale_id'] ?? '');

        if (empty($receipt) && empty($saleId)) {
            jsonResponse(['success' => false, 'message' => 'Receipt number or Sale ID required.'], 400);
        }

        if (!empty($receipt)) {
            $stmt = $db->prepare("SELECT s.*, c.name as customer_name, c.phone as customer_phone, c.balance as customer_balance
                                   FROM sales s
                                   LEFT JOIN customers c ON s.customer_id = c.id
                                   WHERE s.receipt_number = ? LIMIT 1");
            $stmt->execute([$receipt]);
        } else {
            $stmt = $db->prepare("SELECT s.*, c.name as customer_name, c.phone as customer_phone, c.balance as customer_balance
                                   FROM sales s
                                   LEFT JOIN customers c ON s.customer_id = c.id
                                   WHERE s.id = ? LIMIT 1");
            $stmt->execute([$saleId]);
        }
        $sale = $stmt->fetch();

        if (!$sale) {
            jsonResponse(['success' => false, 'message' => 'No sale found matching that receipt number.'], 404);
        }

        // A voided receipt took its goods back the moment it was voided, and it booked nothing.
        // Opening a credit note against it would restock the same bottles a second time and pay
        // out a refund on a sale that never took money in.
        if (strtoupper(trim((string)($sale['status'] ?? ''))) === 'VOID') {
            jsonResponse([
                'success' => false,
                'message' => 'Receipt #' . ($sale['receipt_number'] ?? '') . ' was voided'
                    . (trim((string)($sale['voided_at'] ?? '')) !== '' ? ' at ' . $sale['voided_at'] : '')
                    . '. Its goods went back to the shelf with it and it took no money, so there is nothing left to refund. Ring the sale again if the customer is still buying.'
            ], 409);
        }

        // Fetch sale items
        // p.unit is the product's loose unit; si.unit is the size this line was actually
        // sold in. Both used to arrive named "unit", and the join let the product win, so
        // the returns screen was shown "pcs" against a line that was a crate and had no
        // way back to tell the server which size the customer was handing over.
        $iStmt = $db->prepare("SELECT si.*, p.name as product_name, p.unit AS base_unit, p.sku, p.category
                               FROM sale_items si
                               JOIN products p ON si.product_id = p.id
                               WHERE si.sale_id = ?");
        $iStmt->execute([$sale['id']]);
        $items = $iStmt->fetchAll();

        // Calculate already returned quantities for this sale
        $retQtyStmt = $db->prepare("SELECT sri.product_id, sri.unit, SUM(sri.quantity) as returned_qty
                                    FROM sales_return_items sri
                                    JOIN sales_returns sr ON sri.return_id = sr.id
                                    WHERE sr.sale_id = ?
                                    GROUP BY sri.product_id, sri.unit");
        $retQtyStmt->execute([$sale['id']]);
        $alreadyReturned = [];
        $returnedByKey = [];
        $returnedNoSize = [];
        while ($row = $retQtyStmt->fetch()) {
            $returnedQty = floatval($row['returned_qty']);
            $alreadyReturned[$row['product_id']] = ($alreadyReturned[$row['product_id']] ?? 0) + $returnedQty;
            $rowLabel = trim((string)($row['unit'] ?? ''));
            if ($rowLabel === '') {
                $returnedNoSize[$row['product_id']] = ($returnedNoSize[$row['product_id']] ?? 0) + $returnedQty;
            } else {
                $k = sfUnitKey((string)$row['product_id'], $rowLabel);
                $returnedByKey[$k] = ($returnedByKey[$k] ?? 0) + $returnedQty;
            }
        }

        foreach ($items as &$item) {
            $pid = (string)($item['product_id'] ?? '');
            $key = sfUnitKey($pid, (string)($item['unit'] ?? ''));
            // A credit note that named no size cannot be tied to one line, so it is charged
            // against every size of that product. That can refuse a refund that was genuinely
            // returnable; the alternative is a shop that refunds the same crate twice.
            $prevRet = ($returnedByKey[$key] ?? 0) + ($returnedNoSize[$pid] ?? 0);
            $item['already_returned'] = $prevRet;
            $item['remaining_returnable'] = max(0, floatval($item['quantity']) - $prevRet);
            $item['unit_label'] = trim((string)($item['unit'] ?? '')) ?: trim((string)($item['base_unit'] ?? '')) ?: 'pcs';
        }
        unset($item);

        // The lookup hands the till the lines of a receipt, and both sale_items and sales carry
        // the shop's cost and margin. Staff who are not entitled to see them should not get them
        // from a returns screen any more than from the sales screen.
        if (!maySeeProductCost($authUser)) {
            unset($sale['total_cost'], $sale['gross_profit']);
            foreach ($items as &$item) {
                unset($item['unit_cost_price'], $item['profit']);
            }
            unset($item);
        }

        jsonResponse([
            'success' => true,
            'sale' => $sale,
            'items' => $items
        ]);
    }

    // List historical returns
    $filterDate = trim($_GET['date'] ?? '');
    $filterBranch = trim($_GET['branch_code'] ?? '');
    $limit = intval($_GET['limit'] ?? 100);
    if ($limit <= 0 || $limit > 1000) $limit = 100;

    $sql = "SELECT r.*, COUNT(ri.id) as item_count 
            FROM sales_returns r
            LEFT JOIN sales_return_items ri ON r.id = ri.return_id
            WHERE 1=1";
    $params = [];

    if (!empty($filterDate)) {
        $sql .= " AND DATE(r.return_date) = ?";
        $params[] = $filterDate;
    }
    if (!empty($filterBranch) && $filterBranch !== 'ALL') {
        $sql .= " AND r.branch_code = ?";
        $params[] = $filterBranch;
    }

    $sql .= " GROUP BY r.id ORDER BY r.created_at DESC LIMIT ?";
    $params[] = $limit;

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $returns = $stmt->fetchAll();

    // Attach items
    foreach ($returns as &$ret) {
        $riStmt = $db->prepare("SELECT * FROM sales_return_items WHERE return_id = ?");
        $riStmt->execute([$ret['id']]);
        $ret['items'] = $riStmt->fetchAll();
    }

    jsonResponse([
        'success' => true,
        'returns' => $returns,
        'count' => count($returns)
    ]);
}

if ($method === 'POST') {
    // Same reason as sync.php: this creates and deletes credit notes, so it has to go
    // through requireAuth() and inherit the forced-password rotation guard instead of
    // re-implementing authentication with getCurrentUser().
    $authUser = requireAuth();
    $data = getJsonInput();

    if (!hasPermission($authUser, 'manage_sales')) {
        jsonResponse(['success' => false, 'message' => 'Forbidden: processing returns requires the manage_sales permission.'], 403);
    }

    $action = trim($_GET['action'] ?? ($data['action'] ?? ''));

    // Handle Delete Return
    if ($action === 'delete') {
        // Undoing a credit note undoes money that already left the drawer, so it needs
        // the same permission clearing the book does - not the till's own.
        if (!hasPermission($authUser, 'manage_settings')) {
            jsonResponse(['success' => false, 'message' => 'Forbidden: deleting a posted credit note requires the Manage Settings permission.'], 403);
        }

        $delId = trim($_GET['id'] ?? ($data['id'] ?? ''));
        if (empty($delId)) {
            jsonResponse(['success' => false, 'message' => 'Return ID required for deletion.'], 400);
        }

        $db->beginTransaction();
        try {
            $stmt = $db->prepare("SELECT * FROM sales_returns WHERE id = ? OR return_number = ? LIMIT 1");
            $stmt->execute([$delId, $delId]);
            $ret = $stmt->fetch();
            if (!$ret) {
                safeRollback($db);
                jsonResponse(['success' => true, 'message' => 'Return record already deleted or not on server.']);
            }

            // Fetch return items to reverse restocked quantities
            $itemsStmt = $db->prepare("SELECT * FROM sales_return_items WHERE return_id = ?");
            $itemsStmt->execute([$ret['id']]);
            $retItems = $itemsStmt->fetchAll();

            // A return line counts in the unit it was sold in, the shelf counts in base
            // units, and the two only agree through the sale's own conversion. Reversing
            // the raw carton count left six bottles on the shelf for every crate.
            $ratioStmt = $db->prepare("SELECT product_id, quantity, multiplier, base_quantity FROM sale_items WHERE sale_id = ?");
            $ratioStmt->execute([$ret['sale_id'] ?? '']);
            $soldUnitsByProd = [];
            $baseUnitsByProd = [];
            while ($ratioRow = $ratioStmt->fetch(PDO::FETCH_ASSOC)) {
                $rp = $ratioRow['product_id'];
                $rq = floatval($ratioRow['quantity']);
                $rb = floatval($ratioRow['base_quantity'] ?? 0);
                if ($rb <= 0) $rb = $rq * max(1, floatval($ratioRow['multiplier'] ?? 1));
                $soldUnitsByProd[$rp] = ($soldUnitsByProd[$rp] ?? 0) + $rq;
                $baseUnitsByProd[$rp] = ($baseUnitsByProd[$rp] ?? 0) + $rb;
            }

            foreach ($retItems as $rit) {
                if (strtoupper($rit['item_condition'] ?? 'RESTOCK') === 'RESTOCK') {
                    $qty = floatval($rit['quantity'] ?? 0);
                    $prodId = $rit['product_id'];
                    $bCode = $ret['branch_code'] ?? 'MAIN-01';
                    // The credit note carries its own conversion now, so undoing it reads the
                    // number it was booked with. Re-deriving a ratio from the sale is only for
                    // slips written before the row knew which size it was, and averaging one
                    // across two sizes of the same product is how a deletion moved stock that
                    // was never put back in the first place.
                    $deductQty = round(floatval($rit['base_quantity'] ?? 0), 4);
                    if ($deductQty <= 0) {
                        $soldUnits = $soldUnitsByProd[$prodId] ?? 0;
                        $baseTotal = $baseUnitsByProd[$prodId] ?? $soldUnits;
                        $deductQty = round($qty * ($soldUnits > 0 ? $baseTotal / $soldUnits : 1.0), 4);
                    }

                    // Deduct from consolidated inventory table
                    $updInv = $db->prepare("UPDATE inventory SET current_quantity = MAX(0, current_quantity - ?), updated_at = datetime('now') WHERE product_id = ?");
                    $updInv->execute([$deductQty, $prodId]);

                    // Deduct from branch_inventory
                    $updBranch = $db->prepare("UPDATE branch_inventory SET current_quantity = MAX(0, current_quantity - ?), updated_at = datetime('now') WHERE branch_code = ? AND product_id = ?");
                    $updBranch->execute([$deductQty, $bCode, $prodId]);
                }
            }

            // Revert customer credit balance if tender was STORE_CREDIT
            if (strtoupper($ret['refund_method'] ?? '') === 'STORE_CREDIT' && !empty($ret['customer_id']) && $ret['customer_id'] !== 'cust-walkin') {
                $cUpd = $db->prepare("UPDATE customers SET balance = balance + ? WHERE id = ?");
                $cUpd->execute([floatval($ret['total_refund_amount']), $ret['customer_id']]);
            }

            // Revert sale refunded_amount
            $loyaltyBack = null;
            if (!empty($ret['sale_id'])) {
                $sStmt = $db->prepare("SELECT * FROM sales WHERE id = ?");
                $sStmt->execute([$ret['sale_id']]);
                $saleRow = $sStmt->fetch();
                if ($saleRow) {
                    $newRef = max(0, floatval($saleRow['refunded_amount'] ?? 0) - floatval($ret['total_refund_amount']));
                    $newStatus = ($newRef > 0) ? 'PARTIALLY_REFUNDED' : 'COMPLETED';
                    // A voided receipt keeps its state. Undoing an old credit note must not
                    // write a cancelled bill back as a completed sale - the void guard above
                    // makes that pair impossible for a new book, and this makes it impossible
                    // for one inherited from a build that had no voids.
                    $sUpd = $db->prepare("UPDATE sales SET refunded_amount = ?, status = ? WHERE id = ? AND status <> 'VOID'");
                    $sUpd->execute([$newRef, $newStatus, $ret['sale_id']]);
                }
            }

            // Delete items and return slip
            $db->prepare("DELETE FROM sales_return_items WHERE return_id = ?")->execute([$ret['id']]);
            $db->prepare("DELETE FROM sales_returns WHERE id = ?")->execute([$ret['id']]);

            // The clawback was taken in the share of the receipt the notes had given back. With one
            // note withdrawn the share drops, and the same catch-up hands those points back - a
            // manager correcting a mis-keyed credit note must not leave the member a hundred points
            // poorer for a return that no longer happened.
            //
            // After the delete, not before: the ledger line names the credit notes standing against
            // the receipt, and naming the one being withdrawn as though it still held the goods
            // would leave the next person reading it looking for a note that is gone.
            if (!empty($ret['sale_id'])) {
                $loyaltyBack = StoreFlowLoyalty::reverseLoyaltyForReturns(
                    $db, (string)$ret['sale_id'], intval($authUser['id'] ?? 0),
                    strtoupper(trim((string)($ret['branch_code'] ?? 'MAIN-01'))) ?: 'MAIN-01'
                );
            }

            $db->commit();

            // The slip and its lines are now nowhere in the book, which is exactly what the
            // activity log exists to answer. Before this, a posted credit note - and the cash
            // it took back out of the drawer - could be voided with no name against it.
            logActivity($db, $authUser['id'], $authUser['full_name'], $authUser['role_name'], 'SALE_RETURN_DELETED',
                "Voided credit note {$ret['return_number']} on sale {$ret['sale_id']}. Refund reversed: "
                . round(floatval($ret['total_refund_amount'] ?? 0), 2) . " (" . strtoupper((string)($ret['refund_method'] ?? 'CASH')) . ")"
                . ". Lines removed from the restock: " . count($retItems)
                . (!empty($loyaltyBack['reversed']) ? ". Points: " . number_format($loyaltyBack['change'], 2)
                    . " moved back on the member's balance with the withdrawn note; "
                    . number_format($loyaltyBack['taken'], 2) . " of what the receipt earned now stand taken"
                    . ", balance " . number_format($loyaltyBack['balance'], 2) . '.' : ''));

            jsonResponse(['success' => true, 'message' => "Return slip {$ret['return_number']} deleted successfully."]);
        } catch (Exception $e) {
            safeRollback($db);
            jsonResponse(['success' => false, 'message' => 'Failed to delete return: ' . $e->getMessage()], 500);
        }
    }

    // Handle Clear All Returns
    if ($action === 'clear_all') {
        // Wiping every credit note is a reconciliation task, not a point-of-sale one:
        // without this check any cashier could erase the refund audit trail in one request.
        if (!hasPermission($authUser, 'manage_settings')) {
            jsonResponse(['success' => false, 'message' => 'Forbidden: clearing all returns requires the Manage Settings permission.'], 403);
        }
        $db->beginTransaction();
        try {
            // Counted before the erase, because afterwards there is nothing left to say what
            // was lost. Clearing the returns ledger moves real refund money off the book and
            // used to leave no trace of the amount or of the hand that did it.
            $erasedNotes = intval($db->query("SELECT COUNT(*) FROM sales_returns")->fetchColumn());
            $erasedValue = round(floatval($db->query("SELECT COALESCE(SUM(total_refund_amount), 0) FROM sales_returns")->fetchColumn()), 2);

            $db->exec("DELETE FROM sales_return_items");
            $db->exec("DELETE FROM sales_returns");
            // Reset sales refunded amounts
            $db->exec("UPDATE sales SET refunded_amount = 0, status = 'COMPLETED' WHERE status IN ('REFUNDED', 'PARTIALLY_REFUNDED')");
            $db->commit();
            logActivity($db, $authUser['id'], $authUser['full_name'], $authUser['role_name'], 'SALE_RETURNS_CLEARED',
                "Cleared the entire returns ledger: {$erasedNotes} credit note(s) worth {$erasedValue} erased, "
                . "and every sale's refunded amount reset to 0.");
            jsonResponse(['success' => true, 'message' => 'All returns cleared successfully.']);
        } catch (Exception $e) {
            safeRollback($db);
            jsonResponse(['success' => false, 'message' => 'Failed to clear returns: ' . $e->getMessage()], 500);
        }
    }

    $saleId = trim($data['sale_id'] ?? '');
    $receiptNumber = trim($data['receipt_number'] ?? '');
    $customerId = trim($data['customer_id'] ?? 'cust-walkin') ?: 'cust-walkin';
    $customerName = trim($data['customer_name'] ?? 'Walk-in Customer');
    $terminalId = trim($data['terminal_id'] ?? 'REG-01');
    $branchCode = strtoupper(trim($data['branch_code'] ?? 'MAIN-01'));
    if ($branchCode === '' || $branchCode === 'ALL') $branchCode = 'MAIN-01';
    $refundMethod = strtoupper(trim($data['refund_method'] ?? 'CASH'));
    $reason = trim($data['reason'] ?? 'Customer item return');
    $returnDate = trim($data['return_date'] ?? date('Y-m-d H:i:s'));
    // A credit note dated ahead of today is revenue engineering; the same two-minute tolerance
    // the sale path allows covers a till whose clock has drifted slightly.
    $rdEpoch = strtotime($returnDate);
    if ($rdEpoch === false || $rdEpoch > time() + 120) {
        $returnDate = date('Y-m-d H:i:s');
    }
    $items = $data['items'] ?? [];

    if (empty($saleId) || empty($receiptNumber)) {
        jsonResponse(['success' => false, 'message' => 'Sale ID and Original Receipt Number are required.'], 400);
    }

    if (empty($items) || !is_array($items)) {
        jsonResponse(['success' => false, 'message' => 'Please select at least one item to return.'], 400);
    }

    // Verify original sale exists
    $sCheck = $db->prepare("SELECT * FROM sales WHERE id = ?");
    $sCheck->execute([$saleId]);
    $sale = $sCheck->fetch();
    if (!$sale) {
        jsonResponse(['success' => false, 'message' => 'Original sale not found.'], 404);
    }

    // The same refusal as the lookup, on the door that actually writes: the till may have loaded
    // this receipt before another counter voided it, and a credit note on a voided bill restocks
    // goods that are already back and pays money the receipt never took.
    if (strtoupper(trim((string)($sale['status'] ?? ''))) === 'VOID') {
        jsonResponse([
            'success' => false,
            'message' => 'Receipt #' . ($sale['receipt_number'] ?? '') . ' has been voided, so its goods are already back on the shelf and it booked no money. Nothing was refunded.'
        ], 409);
    }

    // A restock puts goods back on a named shelf, so the branch is not the caller's to pick:
    // staff who can issue a credit note for any branch could move stock between them.
    $retUserBranch = strtoupper(trim($authUser['branch_code'] ?? 'MAIN-01'));
    $retIsSuper = strtolower(trim($authUser['role_name'] ?? '')) === 'administrator'
        || intval($authUser['role_id'] ?? 0) === 1;
    if (!$retIsSuper && $retUserBranch !== '' && $retUserBranch !== $branchCode) {
        jsonResponse([
            'success' => false,
            'message' => "Access denied: You are assigned to branch {$retUserBranch} and cannot process returns for {$branchCode}."
        ], 403);
    }

    $returnId = 'ret_' . bin2hex(random_bytes(6));
    $returnNumber = 'RET-' . date('Ymd') . '-' . rand(1000, 9999);
    $cashierName = $authUser['full_name'] ?: ($authUser['username'] ?: 'Cashier');

    try {
        $db->beginTransaction();

        // 1. Pre-calculate already-returned quantities for this sale to enforce limits
        $prevRetQtyStmt = $db->prepare("SELECT sri.product_id, sri.unit, SUM(sri.quantity) as returned_qty
                                        FROM sales_return_items sri
                                        JOIN sales_returns sr ON sri.return_id = sr.id
                                        WHERE sr.sale_id = ?
                                        GROUP BY sri.product_id, sri.unit");
        $prevRetQtyStmt->execute([$saleId]);
        $alreadyReturnedMap = [];
        $returnedByKey = [];
        $returnedNoSize = [];
        while ($rRow = $prevRetQtyStmt->fetch()) {
            $retQty = floatval($rRow['returned_qty']);
            $alreadyReturnedMap[$rRow['product_id']] = ($alreadyReturnedMap[$rRow['product_id']] ?? 0) + $retQty;
            $retLabel = trim((string)($rRow['unit'] ?? ''));
            if ($retLabel === '') {
                $returnedNoSize[$rRow['product_id']] = ($returnedNoSize[$rRow['product_id']] ?? 0) + $retQty;
            } else {
                $k = sfUnitKey((string)$rRow['product_id'], $retLabel);
                $returnedByKey[$k] = ($returnedByKey[$k] ?? 0) + $retQty;
            }
        }

        // Also load original sale item quantities for ceiling validation. The line prices come
        // from the sale itself: till-supplied unit prices are a request field, and a cashier who
        // can set one can refund a customer more than the store was ever paid for the item.
        $origQtyStmt = $db->prepare("SELECT product_id, quantity, unit_selling_price, unit, multiplier, base_quantity, batch_id FROM sale_items WHERE sale_id = ?");
        $origQtyStmt->execute([$saleId]);
        // Two views of the same receipt, because a receipt can hold the same product in more
        // than one size and the two answers differ. Per product is what a till that has never
        // heard of sizes asks for; per product-and-size is what the shelf and the drawer need.
        // Keyed only by the product, the ceiling was the highest price of the three sizes and
        // the restock used one averaged multiplier, so a loose egg could be credited at the
        // price of a box and a box put back on the shelf as the average of what was sold.
        $origQtyMap = [];
        $baseQtyMap = [];
        $linePriceMap = [];
        $keyQtyMap = [];
        $keyBaseMap = [];
        $keyPriceMap = [];
        $sizesByProd = [];
        // What the sale actually took off the shelf, in base units, per lot. A receipt
        // line saying "1 carton, multiplier 12" sold twelve cans and emptied twelve from
        // a batch; the return table only ever knew about the one carton.
        $lotMap = [];
        while ($oRow = $origQtyStmt->fetch()) {
            $pid = $oRow['product_id'];
            $lineQty = floatval($oRow['quantity']);
            $lineMult = max(1.0, round(floatval($oRow['multiplier'] ?? 1), 4));
            $lineBase = floatval($oRow['base_quantity'] ?? 0);
            if ($lineBase <= 0) $lineBase = $lineQty * $lineMult;
            $lineLabel = trim((string)($oRow['unit'] ?? ''));
            $key = sfUnitKey((string)$pid, $lineLabel);
            $origQtyMap[$pid] = ($origQtyMap[$pid] ?? 0) + $lineQty;
            $baseQtyMap[$pid] = ($baseQtyMap[$pid] ?? 0) + $lineBase;
            $keyQtyMap[$key] = ($keyQtyMap[$key] ?? 0) + $lineQty;
            $keyBaseMap[$key] = ($keyBaseMap[$key] ?? 0) + $lineBase;
            $sizesByProd[$pid][$key] = $lineLabel;
            // Where a product appears on several lines (a promo beside a full-price line), the
            // highest price actually charged is the ceiling; the sale-level cap below keeps the
            // refund total inside the receipt.
            $linePriceMap[$pid] = max($linePriceMap[$pid] ?? 0, round(floatval($oRow['unit_selling_price']), 2));
            $keyPriceMap[$key] = max($keyPriceMap[$key] ?? 0, round(floatval($oRow['unit_selling_price']), 2));
            if (!empty($oRow['batch_id'])) {
                $lotMap[$pid][] = ['id' => $oRow['batch_id'], 'units' => $lineBase];
            }
        }

        // Nothing may be refunded beyond what the receipt actually brought in, once earlier
        // credit notes are counted.
        $saleRefunded = round(floatval($sale['refunded_amount'] ?? 0), 2);
        $refundableValue = round(max(0, floatval($sale['total_amount'] ?? 0) - $saleRefunded), 2);
        if ($refundableValue <= 0.01) {
            safeRollback($db);
            jsonResponse([
                'success' => false,
                'message' => "Receipt #{$receiptNumber} has already been refunded in full ({$saleRefunded} of " . round(floatval($sale['total_amount'] ?? 0), 2) . ")."
            ], 422);
        }

        $totalRefund = 0.0;
        $processedItems = [];
        // What the receipt had already given back before this slip, which the loop below
        // overwrites as it goes. The remainder rule needs the position at the start.
        $returnedByKeyBefore = $returnedByKey;

        foreach ($items as $item) {
            $prodId = trim($item['product_id'] ?? '');
            $prodName = trim($item['product_name'] ?? 'Item');
            $qty = round(floatval($item['quantity'] ?? 0), 2);
            $unitPrice = round(floatval($item['unit_price'] ?? 0), 2);
            $reqUnit = trim((string)($item['unit'] ?? ''));
            $condition = strtoupper(trim($item['item_condition'] ?? 'RESTOCK')); // RESTOCK, DAMAGED

            if ($qty <= 0 || empty($prodId)) continue;

            // Which size is being handed back. A till that has not been opened since sizing
            // arrived names none, and gets the old per-product answer; a till that names one
            // is held to it, because "1" means an egg on one line and a box of 420 on another.
            $sizeKey = null;
            if ($reqUnit !== '') {
                $candidate = sfUnitKey($prodId, $reqUnit);
                if (isset($keyQtyMap[$candidate])) {
                    $sizeKey = $candidate;
                } else {
                    $knownSizes = $sizesByProd[$prodId] ?? [];
                    // One size on the receipt and a differently-spelled name from the till is
                    // the same line, not a forgery; the receipt's own spelling is what we book.
                    if (count($knownSizes) === 1) {
                        $sizeKey = array_key_first($knownSizes);
                    } else {
                        safeRollback($db);
                        $sizeNames = [];
                        foreach ($knownSizes as $lbl) {
                            $sizeNames[] = $lbl !== '' ? "'{$lbl}'" : 'loose units';
                        }
                        jsonResponse([
                            'success' => false,
                            'message' => "Cannot return '{$prodName}' in a '{$reqUnit}': this receipt sold it in "
                                . ($sizeNames ? implode(' and ', $sizeNames) : 'no recorded size') . "."
                        ], 422);
                    }
                }
            }

            $unitsSold = $sizeKey !== null ? ($keyQtyMap[$sizeKey] ?? 0) : ($origQtyMap[$prodId] ?? 0);
            $baseSold = $sizeKey !== null ? ($keyBaseMap[$sizeKey] ?? 0) : ($baseQtyMap[$prodId] ?? $unitsSold);
            $alreadyRet = $sizeKey !== null
                ? ($returnedByKey[$sizeKey] ?? 0) + ($returnedNoSize[$prodId] ?? 0)
                : ($alreadyReturnedMap[$prodId] ?? 0);
            $chargedPrice = $sizeKey !== null ? ($keyPriceMap[$sizeKey] ?? 0) : ($linePriceMap[$prodId] ?? 0);
            $soldLabel = $sizeKey !== null ? (string)($sizesByProd[$prodId][$sizeKey] ?? $reqUnit) : '';
            $sizeWord = $soldLabel !== '' ? $soldLabel : 'unit(s)';

            // Enforce: cannot return more than was originally sold minus already returned
            $remainingLimit = max(0, $unitsSold - $alreadyRet);
            if ($qty > $remainingLimit) {
                safeRollback($db);
                jsonResponse([
                    'success' => false,
                    'message' => "Cannot return {$qty} of '{$prodName}': only {$remainingLimit} {$sizeWord} remaining returnable on this receipt."
                ], 422);
            }

            // A line with no price is not a zero-value refund: the till left the field
            // empty. The receipt says what the item cost, so that is what gets credited,
            // and the restock cannot be booked against a slip worth nothing.
            if ($unitPrice <= 0) $unitPrice = $chargedPrice;
            if ($unitPrice > $chargedPrice + 0.01) {
                safeRollback($db);
                jsonResponse([
                    'success' => false,
                    'message' => "Cannot refund '{$prodName}' at {$unitPrice}: this receipt charged no more than {$chargedPrice} per {$sizeWord}."
                ], 422);
            }

            $subtotal = round($qty * $unitPrice, 2);
            $totalRefund += $subtotal;

            // Two lines of the same size in one request are checked against each other, not
            // only against the receipt: a slip that listed a crate twice would otherwise be
            // judged twice against the same one-crate ceiling and put two back on the shelf.
            if ($sizeKey !== null) {
                $returnedByKey[$sizeKey] = ($returnedByKey[$sizeKey] ?? 0) + $qty;
            }
            $alreadyReturnedMap[$prodId] = ($alreadyReturnedMap[$prodId] ?? 0) + $qty;

            // Convert the returned count into the units the shelf is measured in, using
            // the ratio the sale itself used for this product and size.
            $returnBaseQty = round($qty * ($unitsSold > 0 ? $baseSold / $unitsSold : 1.0), 4);
            $returnMultiplier = $unitsSold > 0 ? round($baseSold / $unitsSold, 4) : 1.0;

            $processedItems[] = [
                'product_id' => $prodId,
                'product_name' => $prodName,
                'quantity' => $qty,
                'unit' => $soldLabel,
                'multiplier' => $returnMultiplier,
                'base_quantity' => $returnBaseQty,
                'unit_price' => $unitPrice,
                'subtotal' => $subtotal,
                'item_condition' => $condition
            ];
        }

        if (empty($processedItems)) {
            safeRollback($db);
            jsonResponse(['success' => false, 'message' => 'No valid items processed for return.'], 400);
        }

        $totalRefund = round($totalRefund, 2);

        // The receipt was taxed and discounted once, at the top; this slip is written line by
        // line, so the money that leaves the drawer is the returned lines' share of it - see
        // saleRefundSplit(). Paying the bare line total shorted a taxed receipt by its tax and
        // left the sale stuck at PARTIAL_REFUNDED owing a residue no line can ever claim.
        //
        // Is this the last of it? Three shares of 93.83 come to 281.49 against the 281.50 the
        // shop took, so a return that empties the receipt settles the exact remainder instead of
        // stranding a pesewa on a sale that has nothing left on it. A return booked before tills
        // knew about sizes names no size and so cannot be matched to one key here; the worst that
        // follows for one of those is that it keeps its ordinary share rather than the remainder.
        $leftGross = 0.0;
        foreach ($keyPriceMap as $sizeKey => $price) {
            $leftUnits = max(0, ($keyQtyMap[$sizeKey] ?? 0) - ($returnedByKeyBefore[$sizeKey] ?? 0));
            $leftGross += $leftUnits * $price;
        }
        $emptiesReceipt = abs(round($leftGross, 2) - $totalRefund) <= 0.01;

        $split = saleRefundSplit($sale, $totalRefund, $refundableValue, $emptiesReceipt);
        $totalRefund = $split['refund'];

        if ($totalRefund > $refundableValue + 0.01) {
            safeRollback($db);
            jsonResponse([
                'success' => false,
                'message' => "Refund of {$totalRefund} exceeds the {$refundableValue} still refundable on receipt #{$receiptNumber}."
            ], 422);
        }

        // 2. Insert parent sales_returns record FIRST (so foreign key on sales_return_items is satisfied)
        $rInsert = $db->prepare("INSERT INTO sales_returns (
            id, return_number, sale_id, receipt_number, customer_id, customer_name,
            user_id, cashier_name, terminal_id, branch_code, total_refund_amount,
            refund_gross, refund_discount_share, refund_tax_share,
            refund_method, return_date, reason, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))");

        $rInsert->execute([
            $returnId, $returnNumber, $saleId, $receiptNumber, $customerId, $customerName,
            $authUser['id'], $cashierName, $terminalId, $branchCode, $totalRefund,
            $split['gross'], $split['discount_share'], $split['tax_share'],
            $refundMethod, $returnDate, $reason
        ]);

        // 3. Insert sales_return_items children and update inventory
        $riInsert = $db->prepare("INSERT INTO sales_return_items (id, return_id, product_id, product_name, quantity, unit, multiplier, base_quantity, unit_price, refund_subtotal, item_condition, created_at)
                                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))");

        $invRestockStmt = $db->prepare("UPDATE inventory SET current_quantity = current_quantity + ?, updated_at = datetime('now') WHERE product_id = ?");
        $branchRestockStmt = $db->prepare("INSERT INTO branch_inventory (id, branch_code, product_id, current_quantity, updated_at)
                                           VALUES (?, ?, ?, ?, datetime('now'))
                                           ON CONFLICT(branch_code, product_id) DO UPDATE SET
                                           current_quantity = current_quantity + excluded.current_quantity,
                                           updated_at = datetime('now')");

        $mvtStmt = $db->prepare("INSERT INTO inventory_movements (id, product_id, movement_type, quantity, reference_id, unit_price, notes, branch_code, created_at)
                                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))");

        $batchRestockStmt = $db->prepare("UPDATE product_batches SET current_quantity = current_quantity + ?, updated_at = datetime('now')
                                          WHERE id = ? AND branch_code = ? AND status = 'ACTIVE'");

        foreach ($processedItems as $vItem) {
            $riId = 'ri_' . bin2hex(random_bytes(6));
            $riInsert->execute([
                $riId,
                $returnId,
                $vItem['product_id'],
                $vItem['product_name'],
                $vItem['quantity'],
                $vItem['unit'],
                $vItem['multiplier'],
                $vItem['base_quantity'],
                $vItem['unit_price'],
                $vItem['subtotal'],
                $vItem['item_condition']
            ]);

            // If condition is RESTOCK, put back into active inventory
            if ($vItem['item_condition'] === 'RESTOCK') {
                $invRestockStmt->execute([$vItem['base_quantity'], $vItem['product_id']]);
                $branchRestockStmt->execute(['binv_' . bin2hex(random_bytes(6)), $branchCode, $vItem['product_id'], $vItem['base_quantity']]);

                // The lot the sale drew from gets its units back. Without this the
                // expiry ledger only ever went down, so a shop that takes returns
                // reports less stock in date than it has and writes off more than it
                // throws away. Only lots still marked ACTIVE are credited: reviving a
                // depleted one would put an expired lot back at the front of the
                // first-expiry-out queue.
                $toCredit = $vItem['base_quantity'];
                foreach ($lotMap[$vItem['product_id']] ?? [] as $i => $lot) {
                    if ($toCredit <= 0.0001 || $lot['units'] <= 0) continue;
                    $credit = min($toCredit, $lot['units']);
                    $lotMap[$vItem['product_id']][$i]['units'] -= $credit;
                    $toCredit -= $credit;
                    $batchRestockStmt->execute([$credit, $lot['id'], $branchCode]);
                    if ($batchRestockStmt->rowCount() === 0) {
                        error_log("Return {$returnNumber}: {$credit} units of '{$vItem['product_name']}' went back to the shelf, but lot {$lot['id']} is no longer saleable.");
                    }
                }

                $mvtStmt->execute([
                    'mvt_' . bin2hex(random_bytes(6)),
                    $vItem['product_id'],
                    'RETURN_RESTOCK',
                    $vItem['base_quantity'],
                    $returnNumber,
                    round($vItem['subtotal'] / max(0.0001, $vItem['base_quantity']), 4),
                    "Customer Return (Resellable): Orig Sale #{$receiptNumber}",
                    $branchCode
                ]);
            } else {
                // Damaged: track movement as write-off / damaged return without increasing active shelf stock
                $mvtStmt->execute([
                    'mvt_' . bin2hex(random_bytes(6)),
                    $vItem['product_id'],
                    'RETURN_DAMAGED',
                    0,
                    $returnNumber,
                    $vItem['unit_price'],
                    "Customer Return (Damaged/Defective, {$vItem['base_quantity']} units not restocked): Orig Sale #{$receiptNumber}",
                    $branchCode
                ]);
            }
        }

        // 4. Update original sale to deduct refunded amount and update status.
        // The remaining-value test is part of the UPDATE, not only the earlier read: two tills
        // can both pass a read-then-write check for the same receipt and refund it twice over.
        // The VOID clause is held to the same standard: the door read above turns a cleared receipt
        // away, but a void that lands between that read and this stamp would otherwise revive the
        // receipt as REFUNDED and restock goods the void had already put back.
        // CAST is not decoration. PDO binds every value to sqlite as TEXT and SQLite orders all
        // numbers before all text, so `expression >= ?` against a computed left side is false
        // for every refund - the first legitimate credit note on a receipt was rejected outright.
        $updateSaleStmt = $db->prepare("UPDATE sales 
                                       SET refunded_amount = COALESCE(refunded_amount, 0) + CAST(? AS REAL),
                                           status = CASE 
                                               WHEN (total_amount - (COALESCE(refunded_amount, 0) + CAST(? AS REAL))) <= 0.01 THEN 'REFUNDED' 
                                               ELSE 'PARTIALLY_REFUNDED' 
                                           END,
                                           updated_at = datetime('now')
                                       WHERE id = ?
                                         AND status <> 'VOID'
                                         AND (total_amount - COALESCE(refunded_amount, 0)) >= CAST(? AS REAL) - 0.01");
        $updateSaleStmt->execute([$totalRefund, $totalRefund, $saleId, $totalRefund]);
        if ($updateSaleStmt->rowCount() === 0) {
            safeRollback($db);
            jsonResponse([
                'success' => false,
                'message' => "This receipt was voided or just refunded by another counter, so there is no value left to credit. Nothing was saved."
            ], 422);
        }

        // 4b. The points follow the goods back.
        //
        // Read off the stamp the UPDATE above just put on the receipt, so this slip is answered
        // together with every note already on the book rather than as one slip's guess: three notes
        // of a third each come to the whole of the points, with no pesewa of rounding left standing
        // on the member's balance, and a member cannot earn the points back by returning and
        // re-buying the same carton.
        $loyaltyBack = StoreFlowLoyalty::reverseLoyaltyForReturns($db, $saleId, intval($authUser['id'] ?? 0), $branchCode);

        // 5. Refund Settlement
        $updatedCustBalance = null;
        if ($refundMethod === 'STORE_CREDIT' && $customerId !== 'cust-walkin') {
            // Deduct customer's debt / add store credit
            $custDeduct = $db->prepare("UPDATE customers SET balance = balance - ?, updated_at = datetime('now') WHERE id = ?");
            $custDeduct->execute([$totalRefund, $customerId]);

            $cbStmt = $db->prepare("SELECT balance FROM customers WHERE id = ?");
            $cbStmt->execute([$customerId]);
            $updatedCustBalance = round(floatval($cbStmt->fetchColumn() ?? 0), 2);
        }

        $db->commit();

        logActivity($db, $authUser['id'], $authUser['full_name'], $authUser['role_name'], 'SALE_RETURN',
            "Processed return {$returnNumber} for original sale #{$receiptNumber}. Refund: {$totalRefund} ({$refundMethod})"
            . " = {$split['gross']} of goods less {$split['discount_share']} share of the receipt discount"
            . " plus {$split['tax_share']} share of its tax."
            . " Items: " . count($processedItems)
            . ($loyaltyBack['reversed'] ? ". Points: " . number_format($loyaltyBack['change'], 2)
                . " moved on the member's balance - " . number_format($loyaltyBack['taken'], 2)
                . " taken of what the receipt earned, " . number_format($loyaltyBack['handed_back'], 2)
                . " given back of what was handed in on it"
                . ($loyaltyBack['short'] > 0.005 ? ", and " . number_format($loyaltyBack['short'], 2)
                    . " of the clawback could not be taken" : '')
                . "; balance now " . number_format($loyaltyBack['balance'], 2) . '.' : ''));

        // Auto-SMS confirmation to customer if phone available
        $smsSent = false;
        try {
            $custPhoneStmt = $db->prepare("SELECT phone FROM customers WHERE id = ?");
            $custPhoneStmt->execute([$customerId]);
            $cPhone = trim($custPhoneStmt->fetchColumn() ?: '');

            $profStmt = $db->query("SELECT mnotify_api_key, mnotify_sender_id, currency_symbol, store_name FROM store_profile LIMIT 1");
            $prof = $profStmt->fetch(PDO::FETCH_ASSOC);

            if (!empty($cPhone) && $cPhone !== 'N/A' && !empty($prof['mnotify_api_key'])) {
                require_once __DIR__ . '/sms.php';
                $cleanPhone = normalizePhoneNumber($cPhone);
                $curr = $prof['currency_symbol'] ?: 'GHS';
                $stName = $prof['store_name'] ?: 'StoreFlow';
                $itemNames = implode(', ', array_map(
                    fn($i) => "{$i['product_name']} (x{$i['quantity']}" . (trim((string)($i['unit'] ?? '')) !== '' ? " {$i['unit']}" : '') . ")",
                    array_slice($processedItems, 0, 2)));

                $retSmsMsg = "StoreFlow Return Receipt\n"
                           . "Store: {$stName}\n"
                           . "Return #: {$returnNumber}\n"
                           . "Original Sale #: {$receiptNumber}\n"
                           . "Items: {$itemNames}\n"
                           . "Goods value: {$curr} " . number_format($split['gross'], 2) . "\n"
                           . ($split['discount_share'] > 0.005 ? "Less share of discount: -{$curr} " . number_format($split['discount_share'], 2) . "\n" : '')
                           . ($split['tax_share'] > 0.005 ? "Plus share of tax: {$curr} " . number_format($split['tax_share'], 2) . "\n" : '')
                           . "Refund: {$curr} " . number_format($totalRefund, 2) . " ({$refundMethod})\n"
                           . "Date: " . date('d-M-Y H:i') . "\n"
                           . "Thank you for your patronage!";

                $smsRes = sendStoreSMS($db, $authUser, $prof['mnotify_api_key'], $prof['mnotify_sender_id'] ?: 'StoreFlow', $cleanPhone, $retSmsMsg, "Return receipt SMS {$returnNumber}");
                $smsSent = !empty($smsRes['success']);
            }
        } catch (Exception $smsErr) {}

        jsonResponse([
            'success' => true,
            'message' => "Return {$returnNumber} processed successfully. Refund: {$totalRefund}",
            'sms_sent' => $smsSent,
            'return' => [
                'id' => $returnId,
                'return_number' => $returnNumber,
                'sale_id' => $saleId,
                'receipt_number' => $receiptNumber,
                'customer_id' => $customerId,
                'customer_name' => $customerName,
                'cashier_name' => $cashierName,
                'total_refund_amount' => $totalRefund,
                // The three figures behind the refund, so the credit note the till prints can
                // answer "my item was GH₵100" without the cashier doing arithmetic on paper.
                'refund_gross' => $split['gross'],
                'refund_discount_share' => $split['discount_share'],
                'refund_tax_share' => $split['tax_share'],
                'receipt_discount' => round(floatval($sale['discount'] ?? 0), 2),
                'receipt_tax' => round(floatval($sale['tax'] ?? 0), 2),
                'refund_method' => $refundMethod,
                'return_date' => $returnDate,
                'reason' => $reason,
                'items' => $processedItems,
                'customer_balance' => $updatedCustBalance,
                // Said out loud rather than left for the member to notice at the next till: the
                // points this note moved, and any the shop could not take because they were spent.
                'loyalty' => $loyaltyBack['reversed'] ? [
                    'change' => $loyaltyBack['change'],
                    'points_taken' => $loyaltyBack['taken'],
                    'points_handed_back' => $loyaltyBack['handed_back'],
                    'short' => $loyaltyBack['short'],
                    'balance' => $loyaltyBack['balance'],
                    'tier' => $loyaltyBack['tier'],
                ] : null
            ]
        ], 201);

    } catch (Exception $e) {
        safeRollback($db);
        jsonResponse(['success' => false, 'message' => 'Failed to process return: ' . $e->getMessage()], 500);
    }
}

jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
