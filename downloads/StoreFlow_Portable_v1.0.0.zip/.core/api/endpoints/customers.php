<?php
// api/endpoints/customers.php
// Customer (Buyers) Management, Accounts, and Balances
require_once __DIR__ . '/../config/db.php';

// Ensure loyalty columns exist
try {
    $custCols = $db->query("PRAGMA table_info(customers)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('loyalty_points', $custCols)) {
        $db->exec("ALTER TABLE customers ADD COLUMN loyalty_points REAL DEFAULT 0.0");
    }
    if (!in_array('loyalty_tier', $custCols)) {
        $db->exec("ALTER TABLE customers ADD COLUMN loyalty_tier TEXT DEFAULT 'BRONZE'");
    }
} catch (Exception $e) {}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET') {
    $user = requireAuth();

    // 1. Fetch payment history for a specific customer if requested
    $customerId = trim($_GET['customer_id'] ?? '');
    if (isset($_GET['payments']) && !empty($customerId)) {
        $stmt = $db->prepare("SELECT p.*, u.full_name as cashier_name
                              FROM customer_payments p
                              LEFT JOIN users u ON p.user_id = u.id
                              WHERE p.customer_id = ?
                              ORDER BY p.created_at DESC");
        $stmt->execute([$customerId]);
        $payments = $stmt->fetchAll();
        jsonResponse(['success' => true, 'payments' => $payments]);
    }

    // 2. The story behind a member's points, oldest movement first. A disputed balance is
    //    answered by reading this, not by asking the counter what it remembers.
    if (isset($_GET['loyalty_ledger']) && !empty($customerId)) {
        $stmt = $db->prepare("SELECT l.*, u.full_name AS by_name
                              FROM loyalty_ledger l
                              LEFT JOIN users u ON u.id = l.created_by
                              WHERE l.customer_id = ?
                              ORDER BY l.created_at DESC, l.rowid DESC
                              LIMIT 200");
        $stmt->execute([$customerId]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $cStmt = $db->prepare("SELECT loyalty_points, loyalty_tier FROM customers WHERE id = ?");
        $cStmt->execute([$customerId]);
        $member = $cStmt->fetch(PDO::FETCH_ASSOC) ?: ['loyalty_points' => 0.0, 'loyalty_tier' => 'BRONZE'];
        jsonResponse(['success' => true, 'ledger' => $rows, 'member' => $member]);
    }

    $search = trim($_GET['search'] ?? '');
    // What a member has spent. A voided receipt is on the ON clause rather than the WHERE, so
    // the member whose only bill was voided still appears - at nil spent - instead of dropping
    // off the customer book.
    $sql = "SELECT c.*, 
                   COUNT(s.id) as total_purchases_count, 
                   COALESCE(SUM(s.total_amount), 0) as total_spent
            FROM customers c
            LEFT JOIN sales s ON c.id = s.customer_id AND COALESCE(s.status, '') <> 'VOID'
            WHERE 1=1";
    $params = [];

    if (!empty($search)) {
        $sql .= " AND (c.name LIKE ? OR c.phone LIKE ? OR c.email LIKE ?)";
        $params[] = "%{$search}%";
        $params[] = "%{$search}%";
        $params[] = "%{$search}%";
    }

    $sql .= " GROUP BY c.id ORDER BY c.name ASC";
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $customers = $stmt->fetchAll();

    jsonResponse([
        'success' => true,
        'customers' => $customers
    ]);
}

if ($method === 'POST' || $method === 'PUT') {
    $authUser = requirePermission('manage_sales');
    $data = getJsonInput();

    // Action: Direct debt payment / balance settlement
    if (($data['action'] ?? '') === 'record_payment') {
        $customerId = trim($data['customer_id'] ?? '');
        $paymentAmount = round(floatval($data['amount'] ?? 0), 2);
        $pMethod = strtoupper(trim($data['payment_method'] ?? 'CASH'));
        $notes = trim($data['notes'] ?? 'Debt settlement payment');

        // The till's own key for the settlement it is handing over. Inventing a fresh id here
        // meant a double tap wrote two ledger rows and took the balance down twice, and it is
        // what lets an offline queue row be replayed without paying the debt a second time.
        $postedPayId = trim((string)($data['payment_id'] ?? ''));
        $paymentId = preg_match('/^pay_[A-Za-z0-9_\-]{4,48}$/', $postedPayId) ? $postedPayId : 'pay_' . bin2hex(random_bytes(6));

        if (empty($customerId) || $paymentAmount <= 0) {
            jsonResponse(['success' => false, 'message' => 'Valid customer and positive payment amount required'], 400);
        }

        // The ledger row and the balance update were separate: for an id the shop does
        // not have, the payment was written against nothing, no balance moved, and the
        // cash still left the drawer.
        $whoStmt = $db->prepare("SELECT id, name FROM customers WHERE id = ?");
        $whoStmt->execute([$customerId]);
        $payingCustomer = $whoStmt->fetch(PDO::FETCH_ASSOC);
        if (!$payingCustomer) {
            jsonResponse(['success' => false, 'message' => "No customer account '{$customerId}' to take payment for."], 404);
        }
        if ($customerId === 'cust-walkin') {
            jsonResponse(['success' => false,
                'message' => 'The walk-in account is shared and holds no balance. Put the customer on their own account before settling a debt.'], 400);
        }

        try {
            $db->beginTransaction();

            // One payment, one ledger row. The till keeps its own key, so a second ask for the
            // same settlement is answered here instead of taking the balance down twice.
            $seenStmt = $db->prepare("SELECT id, amount FROM customer_payments WHERE id = ?");
            $seenStmt->execute([$paymentId]);
            if ($seenStmt->fetch(PDO::FETCH_ASSOC)) {
                safeRollback($db);
                jsonResponse(['success' => false, 'already_recorded' => true,
                    'message' => "A payment of that number is already on the customer's account."], 409);
            }

            // Insert into customer_payments ledger
            $pStmt = $db->prepare("INSERT INTO customer_payments (id, customer_id, user_id, amount, payment_method, notes, created_at) VALUES (?, ?, ?, ?, ?, ?, datetime('now'))");
            $pStmt->execute([$paymentId, $customerId, $authUser['id'], $paymentAmount, $pMethod, $notes]);

            // Deduct customer balance
            $stmt = $db->prepare("UPDATE customers SET balance = balance - ?, updated_at = datetime('now') WHERE id = ?");
            $stmt->execute([$paymentAmount, $customerId]);

            $cStmt = $db->prepare("SELECT * FROM customers WHERE id = ?");
            $cStmt->execute([$customerId]);
            $updatedCustomer = $cStmt->fetch();

            $db->commit();

            // Auto-SMS Debt Payment Receipt via mNotify if customer has phone
            $smsSent = false;
            try {
                $cPhone = trim($updatedCustomer['phone'] ?? '');
                if (!empty($cPhone) && $cPhone !== 'N/A') {
                    $profStmt = $db->query("SELECT mnotify_api_key, mnotify_sender_id, currency_symbol, store_name FROM store_profile LIMIT 1");
                    $prof = $profStmt->fetch(PDO::FETCH_ASSOC);

                    if (!empty($prof['mnotify_api_key'])) {
                        require_once __DIR__ . '/sms.php';
                        $cleanPhone = normalizePhoneNumber($cPhone);
                        $curr = $prof['currency_symbol'] ?: 'GHS';
                        $stName = $prof['store_name'] ?: 'StoreFlow';
                        $sender = $prof['mnotify_sender_id'] ?: 'StoreFlow';
                        $balNum = floatval($updatedCustomer['balance'] ?? 0);
                        $balStr = $balNum <= 0 ? "CLEARED ($0.00)" : "{$curr} " . number_format($balNum, 2);

                        $msg = "Debt Payment Received!\n"
                             . "Store: {$stName}\n"
                             . "Customer: {$updatedCustomer['name']}\n"
                             . "Amount Paid: {$curr} " . number_format($paymentAmount, 2) . " ({$pMethod})\n"
                             . "Remaining Balance: {$balStr}\n"
                             . "Receipt #: {$paymentId}\n"
                             . "Date: " . date('d-M-Y H:i') . "\n"
                             . "Thank you for your settlement!";

                        $res = sendStoreSMS($db, $authUser, $prof['mnotify_api_key'], $sender, $cleanPhone, $msg, 'Debt payment receipt SMS');
                        $smsSent = !empty($res['success']);
                    }
                }
            } catch (Exception $smsErr) {
                // Must never block payment recording
            }

            logActivity($db, $authUser['id'], $authUser['full_name'], $authUser['role_name'], 'DEBT_PAYMENT', "Received payment of {$paymentAmount} ({$pMethod}) from '{$updatedCustomer['name']}'. New Balance: {$updatedCustomer['balance']}. Receipt ID: {$paymentId}");

            jsonResponse([
                'success' => true,
                'message' => 'Payment recorded and customer balance updated successfully' . ($smsSent ? ' (SMS receipt delivered)' : ''),
                'sms_sent' => $smsSent,
                'payment' => [
                    'id' => $paymentId,
                    'customer_id' => $customerId,
                    'amount' => $paymentAmount,
                    'payment_method' => $pMethod,
                    'cashier_name' => $authUser['full_name'],
                    'created_at' => date('Y-m-d H:i:s')
                ],
                'customer' => $updatedCustomer
            ]);
        } catch (Exception $e) {
            safeRollback($db);
            jsonResponse(['success' => false, 'message' => 'Failed to record payment: ' . $e->getMessage()], 500);
        }
    }

    // Action: gift, credit or correct a member's points
    //
    // The only way points move that is not a receipt, because a shop that promises "500 points
    // for joining" or "sorry, that was rung twice" has nowhere else to put it. It is gated above
    // the till's own permission on purpose: points are worth money off a bill, so a cashier must
    // not be able to hand out a discount by naming a customer. The note is required for the same
    // reason a payout needs a voucher - a balance nobody can explain is the one a member argues.
    if (($data['action'] ?? '') === 'adjust_loyalty') {
        $authUser = requirePermission('manage_settings');
        $customerId = trim($data['customer_id'] ?? '');
        $points = round(floatval($data['points'] ?? 0), 2);
        $note = trim($data['note'] ?? '');
        $branchCode = strtoupper(trim($data['branch_code'] ?? 'MAIN-01')) ?: 'MAIN-01';

        if ($customerId === '' || $customerId === 'cust-walkin' || $customerId === 'walkin') {
            jsonResponse(['success' => false,
                'message' => 'Points belong to a named account. The walk-in pot has no member to gift them to.'], 400);
        }
        if ($note === '') {
            jsonResponse(['success' => false,
                'message' => 'Say why the points are moving. The note is kept on the ledger and is the first thing a disputed balance is asked.'], 400);
        }

        require_once __DIR__ . '/../config/loyalty.php';
        $result = StoreFlowLoyalty::adjust($db, $customerId, $points, $note, intval($authUser['id'] ?? 0), $branchCode);
        if (empty($result['success'])) {
            jsonResponse(['success' => false, 'message' => $result['message'] ?? 'The points could not be adjusted.'], 400);
        }

        logActivity($db, $authUser['id'], $authUser['full_name'], $authUser['role_name'], 'LOYALTY_ADJUST',
            sprintf('%s %s points for customer %s. New balance %s (%s). Note: %s',
                $authUser['full_name'], ($points > 0 ? 'added' : 'removed'), $customerId,
                number_format($result['points_balance'], 2), $result['tier'], $note));

        jsonResponse([
            'success' => true,
            'message' => 'Points adjusted.',
            'loyalty' => [
                'change' => $points,
                'points_balance' => $result['points_balance'],
                'tier' => $result['tier']
            ]
        ]);
    }

    $id = trim($data['id'] ?? '') ?: ('cust_' . bin2hex(random_bytes(6)));
    $name = trim($data['name'] ?? '');
    $phone = trim($data['phone'] ?? '');
    $email = trim($data['email'] ?? '');
    $address = trim($data['address'] ?? '');
    $balance = round(floatval($data['balance'] ?? 0), 2);
    $notes = trim($data['notes'] ?? '');

    if (empty($name)) {
        jsonResponse(['success' => false, 'message' => 'Customer name is required'], 400);
    }

    try {
        $checkStmt = $db->prepare("SELECT id FROM customers WHERE id = ?");
        $checkStmt->execute([$id]);
        $exists = $checkStmt->fetch();

        if ($exists) {
            // What a customer owes is moved by the money that passes the counter - a credit
            // sale, a settlement - and never by the figure that happens to be in the edit box.
            // Retyping it here used to let a profile save overwrite a debt the shop had been
            // recording all along, with no ledger row and nobody's name against it.
            $stmt = $db->prepare("UPDATE customers SET name = ?, phone = ?, email = ?, address = ?, notes = ?, updated_at = datetime('now') WHERE id = ?");
            $stmt->execute([$name, $phone, $email, $address, $notes, $id]);
            $heldStmt = $db->prepare("SELECT balance FROM customers WHERE id = ?");
            $heldStmt->execute([$id]);
            $balance = round(floatval($heldStmt->fetchColumn()), 2);
            logActivity($db, $authUser['id'], $authUser['full_name'], $authUser['role_name'], 'CUSTOMER_UPDATE', "Updated customer details for '{$name}' (ID: {$id}).");
            $msg = 'Customer updated successfully';
        } else {
            $stmt = $db->prepare("INSERT INTO customers (id, name, phone, email, address, balance, notes, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))");
            $stmt->execute([$id, $name, $phone, $email, $address, $balance, $notes]);
            logActivity($db, $authUser['id'], $authUser['full_name'], $authUser['role_name'], 'CUSTOMER_CREATE', "Added new customer '{$name}'.");
            $msg = 'Customer added successfully';
        }

        jsonResponse([
            'success' => true,
            'message' => $msg,
            'customer' => [
                'id' => $id,
                'name' => $name,
                'phone' => $phone,
                'email' => $email,
                'address' => $address,
                'balance' => $balance
            ]
        ]);
    } catch (Exception $e) {
        jsonResponse(['success' => false, 'message' => 'Failed to save customer: ' . $e->getMessage()], 500);
    }
}

if ($method === 'DELETE') {
    // Deleting a customer is not deleting a contact card: it takes the account the
    // shop's credit and unpaid-credit notes hang off. manage_sales is the till's
    // permission, and a cashier used to be able to erase a customer's history.
    $authUser = requirePermission('manage_settings');

    $id = trim($_GET['id'] ?? '');
    if (empty($id)) {
        $data = getJsonInput();
        $id = trim($data['id'] ?? '');
    }

    if (empty($id) || $id === 'cust-walkin') {
        jsonResponse(['success' => false, 'message' => 'Cannot delete default Walk-in Customer.'], 400);
    }

    try {
        $nameStmt = $db->prepare("SELECT name, balance FROM customers WHERE id = ?");
        $nameStmt->execute([$id]);
        $customerRow = $nameStmt->fetch(PDO::FETCH_ASSOC);
        if (!$customerRow) {
            jsonResponse(['success' => false, 'message' => 'Customer not found.'], 404);
        }
        $cName = $customerRow['name'] ?: $id;

        $histStmt = $db->prepare("SELECT COUNT(*) FROM sales WHERE customer_id = ?");
        $histStmt->execute([$id]);
        $saleCount = intval($histStmt->fetchColumn());
        $balance = round(floatval($customerRow['balance'] ?? 0), 2);

        if ($saleCount > 0 || abs($balance) > 0.01) {
            jsonResponse([
                'success' => false,
                'message' => "'{$cName}' has {$saleCount} receipt(s) on file"
                    . (abs($balance) > 0.01 ? " and a balance of {$balance}" : '')
                    . ". Deleting the account would erase the shop's record of them; settle the balance and keep the account instead."
            ], 409);
        }

        $stmt = $db->prepare("DELETE FROM customers WHERE id = ?");
        $stmt->execute([$id]);

        logActivity($db, $authUser['id'], $authUser['full_name'], $authUser['role_name'], 'CUSTOMER_DELETE', "Deleted customer '{$cName}' (ID: {$id}).");

        jsonResponse(['success' => true, 'message' => 'Customer account deleted successfully']);
    } catch (Exception $e) {
        jsonResponse(['success' => false, 'message' => 'Failed to delete customer: ' . $e->getMessage()], 500);
    }
}

jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
