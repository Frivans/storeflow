<?php
// api/endpoints/purchases.php
// Factory Purchase Orders (Stocking products at cost price from factory/supplier)
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/product_units.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET') {
    $user = requireAuth();
    $id = trim($_GET['id'] ?? '');

    // Every line of a purchase order is what the shop pays its supplier, and the header
    // totals it. That is the same data cost_price is, so it follows the same rule: a
    // cashier's till has no screen that reads it, and the whole book used to be handed
    // to any session that asked.
    if (!maySeeProductCost($user)) {
        jsonResponse(['success' => false, 'message' => 'You do not have access to purchase orders.'], 403);
    }

    if (!empty($id)) {
        $stmt = $db->prepare("SELECT * FROM purchases WHERE id = ?");
        $stmt->execute([$id]);
        $purchase = $stmt->fetch();
        if (!$purchase) {
            jsonResponse(['success' => false, 'message' => 'Purchase order not found'], 404);
        }

        // pi.unit is the size the shop ordered in, p.unit the product's loose unit. The
        // join used to hand back only the second, so an order of five crates read on screen
        // as five bottles and the print could not tell the supplier what was actually bought.
        $prodStmt = $db->prepare("SELECT pi.*, p.name as product_name, p.unit AS base_unit, p.sku 
                                  FROM purchase_items pi
                                  JOIN products p ON pi.product_id = p.id
                                  WHERE pi.purchase_id = ?");
        $prodStmt->execute([$id]);
        $purchase['items'] = $prodStmt->fetchAll();

        // The order's own story, oldest first: who placed it, who stood at the back door and
        // counted it, who called it off and why. It lives in its own table because
        // activity_logs has no reference column, so this is the only way to hand a shopkeeper
        // one order's history without making them read the whole shop's log to find it.
        $evStmt = $db->prepare("SELECT * FROM purchase_events WHERE purchase_id = ? ORDER BY created_at ASC, rowid ASC");
        $evStmt->execute([$id]);
        $purchase['events'] = $evStmt->fetchAll();

        jsonResponse(['success' => true, 'purchase' => $purchase]);
    }

    // "What came off the truck?" used to be answered with a count of receipt *lines*: an
    // order of five crates of eggs and ten bags of rice read as "2 products", and the shop
    // had to visit the supplier book to find out what those two were. The lines go with the
    // list now. They are deliberately NOT added together: 120 eggs and 10 bags of rice make
    // "130" of nothing, so each keeps the size it was bought in and the loose count inside it.
    $sql = "SELECT p.*, COUNT(pi.id) as total_products_count
            FROM purchases p
            LEFT JOIN purchase_items pi ON p.id = pi.purchase_id
            GROUP BY p.id
            ORDER BY p.order_date DESC, p.created_at DESC";
    $stmt = $db->query($sql);
    $purchases = $stmt->fetchAll();

    if ($purchases) {
        $ids = array_column($purchases, 'id');
        $chunk = array_chunk($ids, 400);
        $linesByOrder = [];
        foreach ($chunk as $set) {
            $in = implode(',', array_fill(0, count($set), '?'));
            // pi.id is the line the count-in has to name, and counted_quantity is the only
            // number that says whether the delivery has been answered yet. Without them a
            // till that loaded this list could not count anything in - it would have to guess
            // at row ids, which is how a browser invents stock.
            $lStmt = $db->prepare("SELECT pi.id, pi.product_id, pi.purchase_id, pi.quantity, pi.unit, pi.multiplier,
                                          pi.base_quantity, pi.counted_quantity, pi.batch_number, pi.expiry_date,
                                          pi.mfg_date,
                                          pi.subtotal, p2.name as product_name, p2.unit as base_unit
                                   FROM purchase_items pi
                                   JOIN products p2 ON p2.id = pi.product_id
                                   WHERE pi.purchase_id IN ($in)
                                   ORDER BY p2.name");
            $lStmt->execute($set);
            foreach ($lStmt->fetchAll() as $l) {
                $linesByOrder[$l['purchase_id']][] = $l;
            }
        }
        foreach ($purchases as &$pRow) {
            $pRow['lines'] = $linesByOrder[$pRow['id']] ?? [];
        }
        unset($pRow);
    }

    // The whole ledger, not the screen: the dashboard asks how much the shop put into stock,
    // and the rows above are only what this till has loaded. Money is the one thing here it
    // is honest to add up across different products.
    //
    // A cancelled order is excluded, and what is still on the road is counted separately from
    // what is in the building. Summing every order as though it had arrived is how a shop
    // reports it put GH₵400,000 into stock on a day the truck came with GH₵80,000 on it.
    $sumStmt = $db->query("SELECT COUNT(*) as orders,
                                  COALESCE(SUM(total_cost), 0) as gross_cost,
                                  COALESCE(SUM(amount_paid), 0) as paid,
                                  COALESCE(SUM(CASE WHEN status = 'PENDING' THEN 1 ELSE 0 END), 0) as awaiting_orders,
                                  COALESCE(SUM(CASE WHEN status = 'PENDING' THEN total_cost ELSE 0 END), 0) as awaiting_cost,
                                  COALESCE(SUM(CASE WHEN status = 'COUNTED' THEN total_cost ELSE 0 END), 0) as received_cost
                           FROM purchases WHERE COALESCE(status, 'PENDING') <> 'CANCELLED'");
    $totals = $sumStmt->fetch() ?: [];

    $top = $db->query("SELECT pi.product_id, p2.name as product_name, p2.unit as base_unit,
                              COALESCE(SUM(COALESCE(pi.counted_quantity, 0) * COALESCE(pi.multiplier, 1)), 0) as base_units,
                              COALESCE(SUM(COALESCE(pi.counted_quantity, 0) * pi.cost_price), 0) as stock_cost
                       FROM purchase_items pi
                       JOIN products p2 ON p2.id = pi.product_id
                       JOIN purchases p ON p.id = pi.purchase_id AND p.status = 'COUNTED'
                       GROUP BY pi.product_id, p2.name, p2.unit
                       ORDER BY stock_cost DESC
                       LIMIT 5")->fetchAll();

    jsonResponse([
        'success' => true,
        'purchases' => $purchases,
        'summary' => ['totals' => $totals, 'top_products' => $top]
    ]);
}

if ($method === 'POST') {
    $authUser = requirePermission('manage_purchases');
    $data = getJsonInput();

    $action = strtoupper(trim((string)($data['action'] ?? '')));

    // The till's own key for the action it is asking for. The server keeps it, so a count-in
    // that is sent twice - a double tap, or an offline till replaying a queue it already
    // emptied - collides here instead of stocking the shelf a second time.
    //
    // Both names are read because the two doors send the same movement under different keys:
    // sync.php hands over the queued row's `id`, while the counter POSTs the modal's `id` and
    // only sets `event_id` when it is told to. Reading one of them meant a count-in booked
    // online rolled its own event id, so the shop's books held two different keys for one
    // delivery - and the key that was supposed to make the replay collide did not exist yet.
    $postedEventId = trim((string)($data['event_id'] ?? $data['id'] ?? ''));
    $eventId = preg_match('/^(pmv|pev)_[A-Za-z0-9_\-]{4,48}$/', $postedEventId) ? $postedEventId : '';

    $reasonWhitelist = [
        'VENDOR_FAILED', 'SHORT_DELIVERY', 'WRONG_GOODS', 'DAMAGED', 'CHANGED_MIND', 'PRICE_CHANGED', 'DELAYED', 'OTHER'
    ];
    $postedReason = strtoupper(trim((string)($data['reason_code'] ?? '')));
    $reasonCode = in_array($postedReason, $reasonWhitelist, true) ? $postedReason : '';
    $reasonNote = trim((string)($data['note'] ?? ''));

    // ── B. The delivery is at the back door: count what came ─────────────────────────
    if ($action === 'COUNT_IN' || $action === 'CANCEL') {
        $purchaseId = trim((string)($data['purchase_id'] ?? ''));

        try {
            $db->beginTransaction();

            $poStmt = $db->prepare("SELECT * FROM purchases WHERE id = ?");
            $poStmt->execute([$purchaseId]);
            $po = $poStmt->fetch();
            if (!$po) {
                safeRollback($db);
                jsonResponse(['success' => false, 'message' => "That purchase order is not in this shop's books"
                    . ($action === 'COUNT_IN' ? ', so nothing was counted in.' : ', so nothing was cancelled.')], 404);
            }

            // The rules live in db.php, because the same order arrives through this door and
            // through an offline till's sync queue a day later. Two copies of the arithmetic
            // is how one delivery ended up worth two different amounts on one shelf.
            $verdict = $action === 'COUNT_IN'
                ? countInPurchaseOrder($db, $po, (array)($data['lines'] ?? []), $authUser, $eventId, $reasonCode, $reasonNote)
                : cancelPurchaseOrder($db, $po, $authUser, $reasonCode, $reasonNote, $eventId);

            if (!$verdict['ok']) {
                safeRollback($db);
                jsonResponse($verdict['body'], $verdict['status']);
            }

            $db->commit();
            jsonResponse($verdict['body'], $verdict['status']);
        } catch (Exception $e) {
            safeRollback($db);
            jsonResponse(['success' => false, 'message' => ($action === 'COUNT_IN'
                ? 'Failed to count the delivery in: ' : 'Failed to cancel the order: ') . $e->getMessage()], 500);
        }
    }

    // ── A. The shop asks the factory for goods ───────────────────────────────────────
    $id = trim($data['id'] ?? '') ?: ('po_' . bin2hex(random_bytes(6)));
    $supplierName = trim($data['supplier_name'] ?? '');
    $supplierContact = trim($data['supplier_contact'] ?? '');
    $orderDate = trim($data['order_date'] ?? date('Y-m-d'));
    $orderNumber = trim($data['order_number'] ?? '');
    $shippingCost = round(floatval($data['shipping_cost'] ?? 0), 2);
    $notes = trim($data['notes'] ?? '');
    $items = $data['items'] ?? [];

    $vendorId = trim($data['vendor_id'] ?? '') ?: null;
    $branchCode = trim($data['branch_code'] ?? 'MAIN-01');
    if (empty($branchCode) || strtoupper($branchCode) === 'ALL') {
        $branchCode = 'MAIN-01';
    }

    if (empty($supplierName)) {
        if ($vendorId) {
            $vStmt = $db->prepare("SELECT name, phone FROM vendors WHERE id = ?");
            $vStmt->execute([$vendorId]);
            $vRow = $vStmt->fetch();
            if ($vRow) {
                $supplierName = $vRow['name'];
                if (empty($supplierContact)) $supplierContact = $vRow['phone'] ?? '';
            }
        }
    }

    if (empty($supplierName)) {
        jsonResponse(['success' => false, 'message' => 'Factory / Supplier name is required'], 400);
    }

    if (empty($items) || !is_array($items)) {
        jsonResponse(['success' => false, 'message' => 'At least one product is required in the purchase order'], 400);
    }

    if (empty($orderNumber)) {
        $orderNumber = 'PO-' . date('Ymd') . '-' . rand(1000, 9999);
    }

    try {
        $db->beginTransaction();

        $totalCost = 0.0;
        foreach ($items as $item) {
            $qty = floatval($item['quantity'] ?? 0);
            $cost = round(floatval($item['cost_price'] ?? 0), 2);
            $subtotal = round($qty * $cost, 2);
            $totalCost += $subtotal;
        }

        $finalTotalCost = round($totalCost + $shippingCost, 2);

        $amountPaid = isset($data['amount_paid']) ? max(0.0, round(floatval($data['amount_paid']), 2)) : $finalTotalCost;

        // What the shop already has sitting with this supplier, read before this order moves
        // it. Paying GH₵200 for a GH₵180 order leaves GH₵20 with the factory; the next GH₵180
        // order is then GH₵160 of cash and GH₵20 of the money already paid. The till asks to
        // draw on that credit, but the server decides how much of the draw is real - a browser
        // can claim any figure, and the credit is the shop's own money, not a rounding
        // allowance. A draw can never exceed what is held, nor what the order still needs.
        $heldCredit = 0.0;
        if ($vendorId) {
            $cStmt = $db->prepare("SELECT balance FROM vendors WHERE id = ?");
            $cStmt->execute([$vendorId]);
            $cRow = $cStmt->fetch();
            if ($cRow) $heldCredit = max(0.0, round(-floatval($cRow['balance']), 2));
        }
        $stillToSettle = max(0.0, round($finalTotalCost - $amountPaid, 2));
        $creditClaimed = max(0.0, round(floatval($data['credit_used'] ?? 0), 2));
        $creditUsed = round(min($creditClaimed, $heldCredit, $stillToSettle), 2);

        // The shop's books, not the till's label, say whether an order is settled. A browser
        // used to be able to POST payment_status=PAID against an unpaid order and have it
        // filed that way, and the same order arriving through the offline queue was stamped
        // from its figures - so one debt had two answers depending on which door it came in.
        if ($amountPaid + $creditUsed >= $finalTotalCost - 0.005) {
            $paymentStatus = 'PAID';
        } else if ($amountPaid > 0) {
            $paymentStatus = 'PARTIAL';
        } else {
            $paymentStatus = 'UNPAID';
        }

        // PENDING: the shop has asked and the factory has not yet delivered. Nothing here
        // touches the shelf - not the stock counts, not the lots, not the cost average -
        // because an order is a promise about goods, not the goods themselves. The count-in is
        // what moves the shelf, and it moves it by what actually arrived.
        $pStmt = $db->prepare("INSERT INTO purchases (id, order_number, supplier_name, supplier_contact, order_date, status, total_cost, ordered_cost, shipping_cost, notes, created_by, vendor_id, amount_paid, credit_used, payment_status, branch_code, created_at, updated_at)
                               VALUES (?, ?, ?, ?, ?, 'PENDING', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))");
        $pStmt->execute([$id, $orderNumber, $supplierName, $supplierContact, $orderDate, $finalTotalCost, $finalTotalCost, $shippingCost, $notes, $authUser['id'], $vendorId, $amountPaid, $creditUsed, $paymentStatus, $branchCode]);

        if ($vendorId) {
            // A deposit larger than the order is not a rounding error to drop. The supplier
            // now owes the shop that money in goods, so the signed account has to carry it;
            // the old `if ($unpaidBalance > 0)` let the cash be written to vendor_payments
            // while the balance stayed put, and the advance vanished from the books.
            // The draw does not get its own subtraction. The account is one signed number:
            // GH₵20 left with the factory is a balance of -20, and taking GH₵180 of goods for
            // GH₵160 of cash puts +20 on it, which lands exactly on zero. Subtracting the
            // credit here as well would move it to -40 and leave the shop free to spend the
            // same GH₵20 on every order after it. credit_used records where the money came
            // from; it does not move the money a second time.
            $balanceDelta = round($finalTotalCost - $amountPaid, 2);
            if (abs($balanceDelta) >= 0.005) {
                $upVen = $db->prepare("UPDATE vendors SET balance = balance + ?, updated_at = datetime('now') WHERE id = ?");
                $upVen->execute([$balanceDelta, $vendorId]);
            }
            if ($amountPaid > 0) {
                // Named after the order it settles, so the till's own copy of this row carries
                // the same key and the supplier statement recognises it as one payment.
                $vpayId = vendorLedgerIdFor($id, 'CASH');
                $vpStmt = $db->prepare("INSERT INTO vendor_payments (id, vendor_id, purchase_id, user_id, amount, payment_method, reference_no, payment_date, notes, created_at)
                                       VALUES (?, ?, ?, ?, ?, 'CASH', ?, ?, 'Down payment on order #' || ?, datetime('now'))");
                $vpStmt->execute([$vpayId, $vendorId, $id, $authUser['id'], $amountPaid, $orderNumber, $orderDate, $orderNumber]);
            }
            // The draw is its own line on the paper. It is not cash leaving the drawer - it
            // left weeks ago - but it settles this invoice, and a statement that shows only
            // the GH₵160 would leave the shopkeeper hunting for the other GH₵20.
            if ($creditUsed > 0) {
                $cpayId = vendorLedgerIdFor($id, 'BALANCE');
                $cpStmt = $db->prepare("INSERT INTO vendor_payments (id, vendor_id, purchase_id, user_id, amount, payment_method, reference_no, payment_date, notes, created_at)
                                       VALUES (?, ?, ?, ?, ?, 'BALANCE', ?, ?, 'Credit balance drawn on order #' || ?, datetime('now'))");
                $cpStmt->execute([$cpayId, $vendorId, $id, $authUser['id'], $creditUsed, $orderNumber, $orderDate, $orderNumber]);
            }
        }

        // The lines are what the shop asked for, in the size it buys them in, and an order
        // arriving from an offline till is written by this same code - so the two doors cannot
        // later disagree about how many eggs a crate holds.
        $recorded = recordPurchaseOrderLines($db, $id, $items);
        if ($recorded['problems']) {
            safeRollback($db);
            jsonResponse(['success' => false, 'message' => "Order #{$orderNumber} was NOT recorded: " . $recorded['problems'][0]['message'] . ' Nothing was ordered and no money was booked.'], 400);
        }
        if (count($recorded['lines']) === 0) {
            safeRollback($db);
            jsonResponse(['success' => false, 'message' => 'At least one product line is required in the purchase order'], 400);
        }

        recordPurchaseEvent($db, $id, 'ORDERED', '',
            sprintf('Order placed with %s for %s. Awaiting delivery.', $supplierName, $finalTotalCost),
            $finalTotalCost, $authUser);

        $db->commit();

        logActivity($db, $authUser['id'], $authUser['full_name'], $authUser['role_name'], 'PURCHASE_ORDER',
            "Placed factory purchase order #{$orderNumber} with '{$supplierName}' for {$finalTotalCost}. Awaiting delivery - no stock has reached the shelf yet.");

        jsonResponse([
            'success' => true,
            'message' => "Purchase order #{$orderNumber} placed with {$supplierName}. Nothing is on the shelf until it is counted in.",
            'order_id' => $id,
            'order_number' => $orderNumber,
            'total_cost' => $finalTotalCost,
            'status' => 'PENDING',
            'lines' => $recorded['lines'],
            'stock_updated' => false
        ], 201);

    } catch (Exception $e) {
        safeRollback($db);
        jsonResponse(['success' => false, 'message' => 'Failed to save factory purchase: ' . $e->getMessage()], 500);
    }
}

jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
