<?php
// api/endpoints/sync.php
// Bidirectional Offline/Online Synchronization Handler
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/product_units.php';
require_once __DIR__ . '/../config/hospitality_tab.php';
require_once __DIR__ . '/../config/sys_integrity.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

function normalizeSyncList($value): array {
    if (!is_array($value)) {
        return [];
    }
    return array_values(array_filter($value, fn($item) => is_array($item) || is_string($item) || is_numeric($item)));
}

// How many records a till is trying to move, read off the body it sent. The refusal below has
// to tell the shopkeeper what is waiting on the device, and the till's own count is the one
// number that cannot be argued with after the batch is thrown away.
function syncPayloadCount(array $data): int {
    $count = 0;
    foreach (['sales', 'purchases', 'purchase_movements', 'products', 'customers', 'payments',
              'shifts', 'activity_logs', 'returns', 'expenses', 'vendors', 'vendor_payments',
              'transfers', 'deleted_product_ids', 'deleted_customer_ids', 'deleted_expense_ids',
              'deleted_vendor_ids'] as $key) {
        if (is_array($data[$key] ?? null)) $count += count($data[$key]);
    }
    return $count;
}

if ($method === 'POST') {
    // requireAuth(), not getCurrentUser(): the forced-password rotation guard lives in
    // requireAuth, and this endpoint writes a till's whole day. Re-implementing auth
    // here meant an account still sitting on its shipped default password could push
    // sales and wipe data through the sync path while every other endpoint refused it.
    $authUser = requireAuth();

    if (!hasPermission($authUser, 'manage_sales')) {
        jsonResponse(['success' => false, 'message' => 'Forbidden: synchronizing offline data requires the manage_sales permission.'], 403);
    }

    $data = getJsonInput();
    $syncId = trim((string)($data['sync_id'] ?? bin2hex(random_bytes(8))));
    $offlineSales = normalizeSyncList($data['sales'] ?? []);
    $offlinePurchases = normalizeSyncList($data['purchases'] ?? []);
    $offlineProducts = normalizeSyncList($data['products'] ?? []);
    $offlineCustomers = normalizeSyncList($data['customers'] ?? []);
    $offlinePayments = normalizeSyncList($data['payments'] ?? []);
    $offlineShifts = normalizeSyncList($data['shifts'] ?? []);
    $offlineVendors = normalizeSyncList($data['vendors'] ?? []);
    $offlineVendorPayments = normalizeSyncList($data['vendor_payments'] ?? []);
    $deletedProductIds = normalizeSyncList($data['deleted_product_ids'] ?? []);
    $deletedCustomerIds = normalizeSyncList($data['deleted_customer_ids'] ?? []);
    $deletedExpenseIds = normalizeSyncList($data['deleted_expense_ids'] ?? []);
    $deletedVendorIds = normalizeSyncList($data['deleted_vendor_ids'] ?? []);

    // ── Is this till still holding a book the shop no longer uses? ─────────────
    // When $isOutageDelta is true, the user intentionally exported transactions recorded
    // on a standalone Android phone/tablet while the PC server was shut down due to a power outage.
    // In that scenario, the device is delivering newly rung sales into the PC, so we permit the sync.
    $isOutageDelta = !empty($data['is_outage_delta']);
    $serverEpoch = _sysBookEpoch($db);
    $tillEpoch = trim((string)($data['book_epoch'] ?? ''));
    $terminalLabel = trim((string)($data['terminal_id'] ?? '')) ?: 'an unnamed till';
    if (!$isOutageDelta && $tillEpoch !== '' && $tillEpoch !== $serverEpoch) {
        $heldRecords = syncPayloadCount($data);
        logActivity(
            $db,
            intval($authUser['id'] ?? 1),
            $authUser['full_name'] ?? 'Staff',
            $authUser['role_name'] ?? 'Staff',
            'SYNC_BOOK_MISMATCH',
            sprintf('%s pushed %d queued record(s) from a book this shop no longer uses (%s, not %s). '
                . 'Nothing was written; the records are still on that till and will not be retried until the owner decides.',
                $terminalLabel, $heldRecords, substr($tillEpoch, 0, 8), substr($serverEpoch, 0, 8))
        );
        jsonResponse([
            'success' => false,
            'code' => 'book_mismatch',
            'message' => 'This till is holding records from a book the shop no longer uses, so nothing was saved to the server.',
            'server_book_epoch' => $serverEpoch,
            'held_records' => $heldRecords,
        ], 409);
    }

    $processedSaleIds = [];
    $processedPurchaseIds = [];
    $processedProductIds = [];
    $processedCustomerIds = [];
    $processedPaymentIds = [];
    $processedShiftIds = [];
    $processedVendorIds = [];
    $processedVendorPaymentIds = [];
    // Hoisted out of their blocks: the response below reads all nine, and a till that sent
    // no transfers would otherwise emit an undefined-variable warning into the JSON body and
    // break the client's res.json().
    $processedTransferIds = [];
    $processedReturnIds = [];
    $processedExpenseIds = [];
    $processedPurchaseMovementIds = [];
    // Why a queued order or count-in was refused, keyed by the till's own id, so the shopkeeper
    // is told which delivery is stuck instead of being shown a number that vanished.
    $purchaseErrors = [];

    // Whether this session may file records into a branch that is not its own - the
    // same test in every section below, computed once.
    $isSuperUser = (strtolower(trim($authUser['role_name'] ?? '')) === 'administrator'
        || intval($authUser['role_id'] ?? 0) === 1);

    // Anything the server could not commit is reported here, not in `processed`. The till
    // deletes an outbox row as soon as its id appears in `processed`, so counting a rolled-back
    // row as processed deleted the shop's copy of a receipt that was never stored: the takings
    // vanished from both sides with a green "synced" message. A rejected row stays queued and
    // is quarantined by the till so it cannot block the rest of the batch.
    $rejectedIds = [
        'sales' => [], 'purchases' => [], 'products' => [], 'customers' => [],
        'payments' => [], 'shifts' => [], 'returns' => [], 'expenses' => [], 'transfers' => [],
        'vendors' => [], 'vendor_payments' => [], 'purchase_movements' => []
    ];

    $totalProcessed = 0;

    try {
        $db->beginTransaction();

        $profRow = $db->query("SELECT allow_negative_stock, tax_rate FROM store_profile WHERE id = 1")->fetch();
        $allowNegativeStock = intval($profRow['allow_negative_stock'] ?? 0);

        // 1. Process Offline Products (Insert new or update existing - requires manage_inventory)
        if (!empty($offlineProducts) && is_array($offlineProducts)) {
            if (hasPermission($authUser, 'manage_inventory')) {
                $pCheck = $db->prepare("SELECT id, sku, barcode, unit, pack_unit, pack_size, pack_price FROM products WHERE id = ?");
                $pInsert = $db->prepare("INSERT INTO products (id, name, sku, barcode, category, unit, cost_price, selling_price, min_stock_alert, description, pack_unit, pack_size, pack_price, is_active, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)");
                $pUpdate = $db->prepare("UPDATE products SET name = ?, sku = ?, barcode = ?, category = ?, unit = ?, cost_price = ?, selling_price = ?, min_stock_alert = ?, description = ?, pack_unit = ?, pack_size = ?, pack_price = ?, updated_at = ? WHERE id = ?");
                $invInsert = $db->prepare("INSERT INTO inventory (id, product_id, current_quantity, reorder_level, location, updated_at) VALUES (?, ?, ?, ?, ?, ?)");
                $binvInit = $db->prepare("INSERT INTO branch_inventory (id, branch_code, product_id, current_quantity, reorder_level, is_available, updated_at)
                                          VALUES (?, ?, ?, ?, ?, 1, datetime('now'))
                                          ON CONFLICT(branch_code, product_id) DO UPDATE SET
                                          current_quantity = excluded.current_quantity,
                                          updated_at = datetime('now')");
                $skuCheck = $db->prepare("SELECT id FROM products WHERE LOWER(sku) = LOWER(?) AND id != ?");

                $pIdx = 0;
                foreach ($offlineProducts as $p) {
                    $pid = trim($p['id'] ?? '');
                    if (empty($pid)) continue;
                    $pIdx++;
                    $spName = 'sp_prod_' . $pIdx;

                    $pName = trim($p['name'] ?? 'Product');
                    if (empty($pName)) $pName = 'Product';

                    // Sanitize SKU: ensure it is never empty or null
                    $sku = trim($p['sku'] ?? '');
                    if ($sku === '') {
                        $cleanName = strtoupper(substr(preg_replace('/[^A-Za-z0-9]/', '', $pName), 0, 4));
                        if (strlen($cleanName) < 2) $cleanName = 'PROD';
                        $sku = 'SKU-' . $cleanName . '-' . strtoupper(bin2hex(random_bytes(3)));
                    }

                    // Check for uniqueness collisions
                    $skuCheck->execute([$sku, $pid]);
                    if ($skuCheck->fetch()) {
                        $sku = $sku . '-' . strtoupper(bin2hex(random_bytes(2)));
                    }

                    $db->exec("SAVEPOINT {$spName}");
                    try {
                        $pCheck->execute([$pid]);
                        $existingProd = $pCheck->fetch();

                        // A till's catalogue row now carries its sizes; the pack triple is what an
                        // older till knows. Whichever arrives is normalised and then projected onto
                        // the columns, so a product that reaches the server with a carton also gets a
                        // carton row - the online till reads sizes from the rows, and a product with
                        // none has nothing to sell in a carton out of. A push that says nothing about
                        // sizes leaves both the shop's rows and its columns standing.
                        $baseUnit = trim((string)($p['unit'] ?? ($existingProd['unit'] ?? ''))) ?: 'pcs';
                        // The loose unit answers to the product's own column, so a size the till
                        // dressed in that same number would be refused here rather than replayed
                        // onto the catalogue and left for the next scan to resolve by row order.
                        // A push that says nothing about the code keeps the shop's, the same way
                        // the pack columns do: a till's own record losing the owner's number would
                        // leave a shelf of barcodes nothing can scan any more.
                        $looseCode = trim((string)($p['barcode'] ?? ($existingProd['barcode'] ?? '')));
                        $pushedUnits = null;
                        if (isset($p['units']) && is_array($p['units'])) {
                            $pushedUnits = $p['units'];
                        } elseif (trim((string)($p['pack_unit'] ?? '')) !== '') {
                            $pushedUnits = sfUnitsFromLegacy(trim((string)$p['pack_unit']),
                                (float)max(1, floatval($p['pack_size'] ?? 1)), floatval($p['pack_price'] ?? 0));
                        }
                        $unitPlan = sfUnitsNormalize($pushedUnits, $baseUnit, $looseCode);
                        if ($unitPlan['error'] !== null) {
                            throw new RuntimeException($unitPlan['error']);
                        }
                        $sizesSent = ($pushedUnits !== null);
                        $packMirror = ($sizesSent || !$existingProd)
                            ? sfUnitsLegacyMirror($unitPlan['rows'])
                            : [
                                'pack_unit' => (string)($existingProd['pack_unit'] ?? ''),
                                'pack_size' => floatval($existingProd['pack_size'] ?? 1),
                                'pack_price' => floatval($existingProd['pack_price'] ?? 0),
                            ];

                        if (!$existingProd) {
                            $pInsert->execute([
                                $pid,
                                $pName,
                                $sku,
                                $looseCode,
                                $p['category'] ?? 'General',
                                $baseUnit,
                                round(floatval($p['cost_price'] ?? 0), 2),
                                round(floatval($p['selling_price'] ?? 0), 2),
                                intval($p['min_stock_alert'] ?? 5),
                                $p['description'] ?? '',
                                $packMirror['pack_unit'],
                                $packMirror['pack_size'],
                                $packMirror['pack_price'],
                                $p['created_at'] ?? date('Y-m-d H:i:s'),
                                $p['updated_at'] ?? date('Y-m-d H:i:s')
                            ]);
                            sfUnitsReplace($db, $pid, $unitPlan['rows']);
                            $invInsert->execute([
                                'inv_' . bin2hex(random_bytes(6)),
                                $pid,
                                floatval($p['current_quantity'] ?? 0),
                                intval($p['min_stock_alert'] ?? 5),
                                $p['location'] ?? 'Main Storefront',
                                date('Y-m-d H:i:s')
                            ]);
                            $binvInit->execute([
                                'binv_' . bin2hex(random_bytes(6)),
                                'MAIN-01',
                                $pid,
                                floatval($p['current_quantity'] ?? 0),
                                intval($p['min_stock_alert'] ?? 5)
                            ]);
                        } else {
                            // If update, only update sku if valid, otherwise preserve existing
                            $skuToUse = (!empty($sku)) ? $sku : ($existingProd['sku'] ?? ('SKU-' . strtoupper(bin2hex(random_bytes(3)))));
                            $pUpdate->execute([
                                $pName,
                                $skuToUse,
                                $looseCode,
                                $p['category'] ?? 'General',
                                $baseUnit,
                                round(floatval($p['cost_price'] ?? 0), 2),
                                round(floatval($p['selling_price'] ?? 0), 2),
                                intval($p['min_stock_alert'] ?? 5),
                                $p['description'] ?? '',
                                $packMirror['pack_unit'],
                                $packMirror['pack_size'],
                                $packMirror['pack_price'],
                                date('Y-m-d H:i:s'),
                                $pid
                            ]);
                            if ($sizesSent) {
                                sfUnitsReplace($db, $pid, $unitPlan['rows']);
                            }
                        }
                        $db->exec("RELEASE SAVEPOINT {$spName}");
                        $processedProductIds[] = $pid;
                        $totalProcessed++;
                    } catch (Throwable $pe) {
                        $db->exec("ROLLBACK TO SAVEPOINT {$spName}");
                        $db->exec("RELEASE SAVEPOINT {$spName}");
                        error_log("Sync: Rejected offline product {$pid}: " . $pe->getMessage());
                        $rejectedIds['products'][] = $pid;
                    }
                }
            } else {
                error_log("Sync: User " . ($authUser['id'] ?? 'unknown') . " lacked manage_inventory permission to sync offline products.");
            }
        }

        // 2. Process Offline Customers (Insert new or update existing)
        if (!empty($offlineCustomers) && is_array($offlineCustomers)) {
            $cCheck = $db->prepare("SELECT id FROM customers WHERE id = ?");
            $cInsert = $db->prepare("INSERT INTO customers (id, name, phone, email, address, balance, notes, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $cUpdate = $db->prepare("UPDATE customers SET name = ?, phone = ?, email = ?, address = ?, notes = ?, updated_at = ? WHERE id = ?");
            // An opening balance is the shop's money owed, so it is a settings-holder's call, not
            // a field a till can invent. Debt changes arrive as payments, which move it honestly.
            $canSetOpeningBalance = hasPermission($authUser, 'manage_settings');

            $cuIdx = 0;
            foreach ($offlineCustomers as $c) {
                $cid = trim($c['id'] ?? '');
                if (empty($cid)) continue;
                $cuIdx++;

                // One broken row used to abort the whole batch and, because nothing was then
                // marked processed, the till replayed it on every sync.
                $spCust = 'sp_cust_' . $cuIdx;
                $db->exec("SAVEPOINT {$spCust}");
                try {
                    $cCheck->execute([$cid]);
                    if (!$cCheck->fetch()) {
                        $openingBalance = round(floatval($c['balance'] ?? 0), 2);
                        if (!$canSetOpeningBalance && abs($openingBalance) > 0.005) {
                            logActivity($db, intval($authUser['id'] ?? 1), $authUser['full_name'] ?? 'Staff', $authUser['role_name'] ?? 'Staff', 'SYNC_BALANCE_IGNORED', "Opening balance of {$openingBalance} for customer {$cid} ignored; only Manage Settings holders may set one.");
                            $openingBalance = 0.0;
                        }
                        $cInsert->execute([
                            $cid,
                            $c['name'] ?? 'Customer',
                            $c['phone'] ?? '',
                            $c['email'] ?? '',
                            $c['address'] ?? '',
                            $openingBalance,
                            $c['notes'] ?? '',
                            $c['created_at'] ?? date('Y-m-d H:i:s'),
                            $c['updated_at'] ?? date('Y-m-d H:i:s')
                        ]);
                    } else {
                        $cUpdate->execute([
                            $c['name'] ?? 'Customer',
                            $c['phone'] ?? '',
                            $c['email'] ?? '',
                            $c['address'] ?? '',
                            $c['notes'] ?? '',
                            date('Y-m-d H:i:s'),
                            $cid
                        ]);
                    }
                    $db->exec("RELEASE SAVEPOINT {$spCust}");
                    $processedCustomerIds[] = $cid;
                    $totalProcessed++;
                } catch (Throwable $ce) {
                    $db->exec("ROLLBACK TO SAVEPOINT {$spCust}");
                    $db->exec("RELEASE SAVEPOINT {$spCust}");
                    error_log("Sync: Rejected offline customer {$cid}: " . $ce->getMessage());
                    $rejectedIds['customers'][] = $cid;
                }
            }
        }

        // Process Offline Product Deletions (requires manage_inventory)
        if (!empty($deletedProductIds) && is_array($deletedProductIds)) {
            if (hasPermission($authUser, 'manage_inventory')) {
                $pDelStmt = $db->prepare("UPDATE products SET is_active = 0, updated_at = datetime('now') WHERE id = ?");
                foreach ($deletedProductIds as $dPid) {
                    $dPid = trim($dPid);
                    if (!empty($dPid)) {
                        $pDelStmt->execute([$dPid]);
                        $totalProcessed++;
                    }
                }
            } else {
                error_log("Sync: User " . ($authUser['id'] ?? 'unknown') . " lacked manage_inventory permission to delete products.");
            }
        }

        // Process Offline Customer Deletions (master-data change: settings rights or user admin)
        // 'manage_customers' is not a permission any role is granted, so this check used to
        // resolve to "administrators only" by accident. Stated explicitly instead.
        if (!empty($deletedCustomerIds) && is_array($deletedCustomerIds)) {
            if (hasPermission($authUser, 'manage_settings') || hasPermission($authUser, 'manage_users')) {
                $cDelStmt = $db->prepare("DELETE FROM customers WHERE id = ? AND id != 'cust-walkin'");
                $dIdx = 0;
                foreach ($deletedCustomerIds as $dCid) {
                    $dCid = trim($dCid);
                    if ($dCid === '') continue;
                    $dIdx++;
                    // A customer referenced by a saved sale cannot be removed - the foreign key
                    // says so. Without a savepoint that one row threw past the whole sync and
                    // rolled back everything else in the batch, which the till then replayed
                    // forever. The account is skipped, the rest of the batch stands.
                    $spDel = 'sp_cdel_' . $dIdx;
                    $db->exec("SAVEPOINT {$spDel}");
                    try {
                        $cDelStmt->execute([$dCid]);
                        $db->exec("RELEASE SAVEPOINT {$spDel}");
                        $totalProcessed++;
                    } catch (Exception $cdelEx) {
                        $db->exec("ROLLBACK TO SAVEPOINT {$spDel}");
                        $db->exec("RELEASE SAVEPOINT {$spDel}");
                        error_log("Sync: Skipped customer delete {$dCid}: " . $cdelEx->getMessage());
                    }
                    $processedCustomerIds[] = $dCid;
                }
            } else {
                error_log("Sync: User " . ($authUser['id'] ?? 'unknown') . " lacked permission to delete customers.");
            }
        }

        // Process Offline Deleted Expenses
        // expenses.php only lets a manage_settings holder delete an expense, so the sync
        // path has to demand the same permission or it becomes a bypass for cashiers.
        if (!empty($deletedExpenseIds) && is_array($deletedExpenseIds)) {
            if (hasPermission($authUser, 'manage_settings')) {
                $eDelStmt = $db->prepare("DELETE FROM expenses WHERE id = ?");
                foreach ($deletedExpenseIds as $dEid) {
                    $dEid = trim($dEid);
                    if (!empty($dEid)) {
                        $eDelStmt->execute([$dEid]);
                        $totalProcessed++;
                    }
                }
            } else {
                error_log("Sync: User " . ($authUser['id'] ?? 'unknown') . " lacked manage_settings permission to delete expenses.");
            }
        }

        // 3. Process Offline Customer Payments
        if (!empty($offlinePayments) && is_array($offlinePayments)) {
            $payCheck = $db->prepare("SELECT id FROM customer_payments WHERE id = ?");
            $payInsert = $db->prepare("INSERT INTO customer_payments (id, customer_id, user_id, amount, payment_method, notes, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $custBalUpdate = $db->prepare("UPDATE customers SET balance = balance - ?, updated_at = datetime('now') WHERE id = ?");

            $payIdx = 0;
            foreach ($offlinePayments as $pay) {
                $payId = trim($pay['id'] ?? '');
                // A till that queued a settlement without a key used to have it skipped on every
                // pass: the row stayed in the outbox forever, so cash taken with the line down
                // never reached the shop's book and the customer's debt stayed on the account.
                // Derive a key from the row's own figures instead - the same content always
                // derives the same id, so a replay lands on the existence check below rather than
                // paying the debt twice.
                if ($payId === '' || !preg_match('/^(pay|cp)[_\-][A-Za-z0-9_\-]{4,48}$/', $payId)) {
                    $payId = 'pay_' . substr(hash('sha256', implode('|', [
                        trim($pay['customer_id'] ?? ''),
                        round(floatval($pay['amount'] ?? 0), 2),
                        strtoupper(trim($pay['payment_method'] ?? 'CASH')),
                        trim((string)($pay['created_at'] ?? '')),
                        trim((string)($pay['notes'] ?? ''))
                    ])), 0, 24);
                }
                $payIdx++;

                $spPay = 'sp_pay_' . $payIdx;
                $db->exec("SAVEPOINT {$spPay}");
                try {
                    $payCheck->execute([$payId]);
                    if (!$payCheck->fetch()) {
                        $payAmt = round(floatval($pay['amount'] ?? 0), 2);
                        $cId = trim($pay['customer_id'] ?? '');
                        if ($payAmt <= 0) {
                            // A negative "payment" is a way of inventing debt on someone else's
                            // account, and a zero one is noise on the takings report.
                            logActivity($db, intval($authUser['id'] ?? 1), $authUser['full_name'] ?? 'Staff', $authUser['role_name'] ?? 'Staff', 'SYNC_PAYMENT_REJECTED', "Offline payment {$payId} for customer {$cId} rejected: amount {$payAmt} is not a payment.");
                        } elseif ($cId === '' || $cId === 'cust-walkin') {
                            logActivity($db, intval($authUser['id'] ?? 1), $authUser['full_name'] ?? 'Staff', $authUser['role_name'] ?? 'Staff', 'SYNC_PAYMENT_REJECTED', "Offline payment {$payId} rejected: it is not against a named account.");
                        } else {
                            // Recorded against whoever is syncing: the till's own user id is a
                            // client field, and debt payments are an audit trail of who took cash.
                            $recorder = intval($authUser['id'] ?? 1);
                            $payInsert->execute([
                                $payId,
                                $cId,
                                $recorder,
                                $payAmt,
                                $pay['payment_method'] ?? 'CASH',
                                $pay['notes'] ?? 'Offline customer payment',
                                $pay['created_at'] ?? date('Y-m-d H:i:s')
                            ]);
                            $custBalUpdate->execute([$payAmt, $cId]);
                            logActivity($db, $recorder, $authUser['full_name'] ?? 'Staff', $authUser['role_name'] ?? 'Staff', 'DEBT_PAYMENT_SYNC', "Synced customer debt payment of {$payAmt} (" . ($pay['payment_method'] ?? 'CASH') . ") for customer {$cId}.");
                        }
                    }
                    $db->exec("RELEASE SAVEPOINT {$spPay}");
                    $totalProcessed++;
                    $processedPaymentIds[] = $payId;
                } catch (Throwable $payEx) {
                    $db->exec("ROLLBACK TO SAVEPOINT {$spPay}");
                    $db->exec("RELEASE SAVEPOINT {$spPay}");
                    error_log("Sync: Rejected offline customer payment {$payId}: " . $payEx->getMessage());
                    $rejectedIds['payments'][] = $payId;
                }
            }
        }

        // 3b. Process Offline Suppliers (same right as vendors.php: manage_purchases)
        //
        // A supplier added at the till while the line was down used to be queued as
        // `vendor`, find no bucket in the till's own syncOutbox() dispatcher, and then be
        // deleted from the outbox as if it had been sent - because an entity with no
        // bucket passed the "was it processed" test by default. The shopkeeper got a green
        // sync and the supplier existed on no book but that one browser.
        //
        // The profile travels; the balance never does. What the shop owes a supplier is
        // derived here from the purchases and payouts that arrived in the same queue, so a
        // till's locally-rounded figure cannot overwrite the shop's account.
        //
        // One figure does travel: the opening balance the shopkeeper entered for a brand-new
        // account, because no purchase or payout in the queue reproduces it. It travels as the
        // carry-in the server books for itself - the row is written here and the account moves
        // by that row, never by the number off the till.
        if (!empty($offlineVendors) && is_array($offlineVendors)) {
            if (hasPermission($authUser, 'manage_purchases')) {
                $venCheck = $db->prepare("SELECT id, balance FROM vendors WHERE id = ?");
                $venInsert = $db->prepare("INSERT INTO vendors (id, name, contact_person, phone, email, address, tax_id, balance, payment_terms, bank_details, notes, created_at, updated_at)
                                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))");
                $venUpdate = $db->prepare("UPDATE vendors SET name = ?, contact_person = ?, phone = ?, email = ?, address = ?, tax_id = ?, payment_terms = ?, bank_details = ?, notes = ?, updated_at = datetime('now') WHERE id = ?");

                foreach ($offlineVendors as $ven) {
                    $venId = trim((string)($ven['id'] ?? ''));
                    $venName = trim((string)($ven['name'] ?? ''));
                    if ($venId === '' || $venName === '') continue;

                    $venCheck->execute([$venId]);
                    $existingVen = $venCheck->fetch();
                    if ($existingVen) {
                        $venUpdate->execute([
                            $venName,
                            trim((string)($ven['contact_person'] ?? '')),
                            trim((string)($ven['phone'] ?? '')),
                            trim((string)($ven['email'] ?? '')),
                            trim((string)($ven['address'] ?? '')),
                            trim((string)($ven['tax_id'] ?? '')),
                            trim((string)($ven['payment_terms'] ?? '')) ?: 'NET30',
                            trim((string)($ven['bank_details'] ?? '')),
                            trim((string)($ven['notes'] ?? '')),
                            $venId
                        ]);
                    } else {
                        $venInsert->execute([
                            $venId, $venName,
                            trim((string)($ven['contact_person'] ?? '')),
                            trim((string)($ven['phone'] ?? '')),
                            trim((string)($ven['email'] ?? '')),
                            trim((string)($ven['address'] ?? '')),
                            trim((string)($ven['tax_id'] ?? '')),
                            0.0,
                            trim((string)($ven['payment_terms'] ?? '')) ?: 'NET30',
                            trim((string)($ven['bank_details'] ?? '')),
                            trim((string)($ven['notes'] ?? '')),
                            $ven['created_at'] ?? date('Y-m-d H:i:s')
                        ]);
                    }

                    // Both doors, because a carry-in can be added to an account the same till
                    // queued before it had ever reached the shop. The key allows one per
                    // supplier, so the queue delivering this row twice - or a second till
                    // syncing the same supplier - books nothing the first pass did not.
                    $venOpening = round(floatval($ven['opening_amount'] ?? 0), 2);
                    if (abs($venOpening) >= 0.005 && applyVendorOpeningBalance(
                        $db, $venId, $venOpening,
                        trim((string)($ven['opening_note'] ?? '')) ?: 'Opening balance brought forward',
                        $authUser['id'] ?? null,
                        $authUser['full_name'] ?? 'Staff',
                        trim((string)($ven['opening_date'] ?? ''))
                    )) {
                        logActivity($db, intval($authUser['id'] ?? 1), $authUser['full_name'] ?? 'Staff',
                            $authUser['role_name'] ?? 'Staff', 'VENDOR_OPENING',
                            "A till synced an opening balance of " . abs($venOpening) . " on supplier '{$venName}' "
                            . ($venOpening > 0 ? "as debt carried in from before this book." : "as an advance this shop holds with them."));
                    }

                    $processedVendorIds[] = $venId;
                    $totalProcessed++;
                }

                // Process Offline Deleted Suppliers
                if (!empty($deletedVendorIds) && is_array($deletedVendorIds)) {
                    $venDelLinked = $db->prepare("SELECT COUNT(*) as n FROM purchases WHERE vendor_id = ?");
                    $venDelRow = $db->prepare("SELECT name, balance FROM vendors WHERE id = ?");
                    $venDelStmt = $db->prepare("DELETE FROM vendors WHERE id = ?");
                    $venDelPays = $db->prepare("DELETE FROM vendor_payments WHERE vendor_id = ?");
                    $venDelOpening = $db->prepare("DELETE FROM vendor_opening_balances WHERE vendor_id = ?");
                    foreach ($deletedVendorIds as $dVid) {
                        $dVid = trim((string)$dVid);
                        if ($dVid === '') continue;
                        $venDelRow->execute([$dVid]);
                        $dVen = $venDelRow->fetch();
                        if (!$dVen) {
                            $processedVendorIds[] = $dVid;
                            continue;
                        }
                        // vendors.php refuses the same delete. An account still holding
                        // money in either direction is not a row to discard: a positive
                        // balance is a debt this shop owes, and a negative one is this
                        // shop's advance sitting with the supplier.
                        $venDelLinked->execute([$dVid]);
                        $linkedPos = intval($venDelLinked->fetch()['n'] ?? 0);
                        $openBal = round(floatval($dVen['balance']), 2);
                        if ($linkedPos > 0 || abs($openBal) > 0.01) {
                            logActivity($db, intval($authUser['id'] ?? 1), $authUser['full_name'] ?? 'Staff', $authUser['role_name'] ?? 'Staff',
                                'SYNC_VENDOR_DELETE_REFUSED',
                                "A till asked to delete supplier '{$dVen['name']}'. Refused: {$linkedPos} purchase order(s) are linked"
                                . (abs($openBal) > 0.01 ? " and the account holds " . ($openBal > 0 ? "a debt of " : "an advance of ") . abs($openBal) : "")
                                . ".");
                            $rejectedIds['vendors'][] = $dVid;
                            continue;
                        }
                        $venDelPays->execute([$dVid]);
                        $venDelOpening->execute([$dVid]);
                        $venDelStmt->execute([$dVid]);
                        $processedVendorIds[] = $dVid;
                        $totalProcessed++;
                    }
                }
            } else {
                error_log("Sync: User " . ($authUser['id'] ?? 'unknown') . " lacked permission to sync suppliers.");
                foreach ($offlineVendors as $ven) {
                    $vid = trim((string)($ven['id'] ?? ''));
                    if ($vid !== '') $rejectedIds['vendors'][] = $vid;
                }
            }
        }

        // 3c. Process Offline Supplier Payouts (Accounts Payable settlements)
        //
        // A payout is cash that physically left the counter. Queued but never delivered,
        // it is the worst kind of loss: the till's ledger shows the supplier settled while
        // the shop's books still carry the debt, and nobody is told.
        //
        // The server recomputes the balance from its own figure rather than accepting the
        // till's, because two tills at one shop each subtract from the same debt.
        if (!empty($offlineVendorPayments) && is_array($offlineVendorPayments)) {
            if (hasPermission($authUser, 'manage_purchases')) {
                $vpCheck = $db->prepare("SELECT id FROM vendor_payments WHERE id = ?");
                $vpVendor = $db->prepare("SELECT id, name, balance FROM vendors WHERE id = ?");
                $vpInsert = $db->prepare("INSERT INTO vendor_payments (id, vendor_id, purchase_id, user_id, amount, payment_method, reference_no, payment_date, notes, created_at)
                                          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))");
                $vpSubtract = $db->prepare("UPDATE vendors SET balance = balance - ?, updated_at = datetime('now') WHERE id = ?");
                $vpBalanceAfter = $db->prepare("SELECT balance FROM vendors WHERE id = ?");
                $vpPoExists = $db->prepare("SELECT id FROM purchases WHERE id = ?");

                foreach ($offlineVendorPayments as $vp) {
                    $vpId = trim((string)($vp['id'] ?? ''));
                    $vpVendorId = trim((string)($vp['vendor_id'] ?? ''));
                    $vpAmount = round(floatval($vp['amount'] ?? 0), 2);
                    if ($vpId === '') continue;

                    $vpCheck->execute([$vpId]);
                    if ($vpCheck->fetch()) {
                        // Already on the books from an earlier pass: consuming the queue row
                        // is the right outcome, not a rejection that retries forever.
                        $processedVendorPaymentIds[] = $vpId;
                        continue;
                    }
                    if ($vpVendorId === '' || $vpAmount <= 0) {
                        $rejectedIds['vendor_payments'][] = $vpId;
                        continue;
                    }

                    $vpVendor->execute([$vpVendorId]);
                    $vpVenRow = $vpVendor->fetch();
                    if (!$vpVenRow) {
                        // The supplier record is queued behind this payout, or was never
                        // sent. Rejecting keeps the payout on the till so it retries once
                        // the supplier arrives, instead of booking cash against nobody.
                        error_log("Sync: Rejected offline payout {$vpId}: supplier '{$vpVendorId}' is unknown to this shop.");
                        $rejectedIds['vendor_payments'][] = $vpId;
                        continue;
                    }

                    $vpRequestedPoId = trim((string)($vp['purchase_id'] ?? ''));
                    $vpPurchaseId = $vpRequestedPoId !== '' ? $vpRequestedPoId : null;
                    if ($vpPurchaseId !== null) {
                        $vpPoExists->execute([$vpPurchaseId]);
                        if (!$vpPoExists->fetch()) $vpPurchaseId = null;
                    }

                    $vpInsert->execute([
                        $vpId,
                        $vpVendorId,
                        $vpPurchaseId,
                        intval($authUser['id'] ?? 1),
                        $vpAmount,
                        strtoupper(trim((string)($vp['payment_method'] ?? 'CASH'))) ?: 'CASH',
                        trim((string)($vp['reference_no'] ?? '')),
                        trim((string)($vp['payment_date'] ?? '')) ?: date('Y-m-d'),
                        trim((string)($vp['notes'] ?? '')) ?: 'Vendor payout / debt settlement'
                    ]);
                    // Subtraction happens inside the database, not against a balance this
                    // request read a moment earlier. Two tills at one shop - or one till
                    // retrying a batch it thinks it lost - used to read the same GH₵2,450
                    // owed, each write zero, and each leave a ledger row behind, so the shop
                    // appeared to pay the bill twice while the account matched neither.
                    $vpSubtract->execute([$vpAmount, $vpVendorId]);
                    $vpBalanceAfter->execute([$vpVendorId]);
                    $newVenBalance = round(floatval($vpBalanceAfter->fetchColumn()), 2);

                    if ($vpPurchaseId !== null) {
                        // Credit drawn off a held balance settles the order without being
                        // cash, so the cash total alone cannot tell this order it is closed -
                        // and re-stamping a settled order PARTIAL is how a shop comes to pay
                        // the same GH₵20 twice.
                        $vpPoStmt = $db->prepare("SELECT total_cost, amount_paid, COALESCE(credit_used, 0) as credit_used FROM purchases WHERE id = ?");
                        $vpPoStmt->execute([$vpPurchaseId]);
                        if ($poRow = $vpPoStmt->fetch()) {
                            $poPaid = round(floatval($poRow['amount_paid']) + $vpAmount, 2);
                            $poStatus = round($poPaid + floatval($poRow['credit_used']), 2) >= floatval($poRow['total_cost']) ? 'PAID' : 'PARTIAL';
                            $db->prepare("UPDATE purchases SET amount_paid = ?, payment_status = ?, updated_at = datetime('now') WHERE id = ?")
                               ->execute([$poPaid, $poStatus, $vpPurchaseId]);
                        }
                    } elseif ($vpRequestedPoId === '') {
                        // A payout the cashier never tied to an invoice still settles invoices.
                        // Before this it moved vendors.balance and nothing else, so every order
                        // it had actually paid for stayed PARTIAL and kept being counted as debt
                        // - which is how a shop ends up with all its suppliers at GH₵0.00 and the
                        // dashboard still reporting GH₵1,233,000.00 outstanding.
                        //
                        // Only a payout that names no order at all gets here. One that names an
                        // order whose row has not arrived from this till yet is a deposit for
                        // that order, and spending it against an older invoice would pay the
                        // same cash twice as soon as the order lands.
                        allocateVendorPaymentToOrders($db, $vpVendorId, $vpAmount);
                    }

                    logActivity($db, intval($authUser['id'] ?? 1), $authUser['full_name'] ?? 'Staff', $authUser['role_name'] ?? 'Staff',
                        'VENDOR_PAYOUT_SYNC', "Synced supplier payout of {$vpAmount} to '{$vpVenRow['name']}' from an offline till. Account balance is now {$newVenBalance}"
                        . ($newVenBalance < -0.01 ? ' (an advance the supplier owes in goods).' : '.'));

                    $processedVendorPaymentIds[] = $vpId;
                    $totalProcessed++;
                }
            } else {
                error_log("Sync: User " . ($authUser['id'] ?? 'unknown') . " lacked permission to sync supplier payouts.");
                foreach ($offlineVendorPayments as $vp) {
                    $vid = trim((string)($vp['id'] ?? ''));
                    if ($vid !== '') $rejectedIds['vendor_payments'][] = $vid;
                }
            }
        }

        // 4. Process Offline Factory Purchases (requires manage_purchases or manage_inventory)
        //
        // A synced order is the same commitment as an online one: the paper is signed, the
        // debt is booked, and the shelf waits for somebody to count what arrived. The stock
        // loop that used to live here is gone - it is what let a till that had already
        // counted eight crates at the back door push ten crates onto the shop's shelf.
        if (!empty($offlinePurchases) && is_array($offlinePurchases)) {
            if (hasPermission($authUser, 'manage_purchases') || hasPermission($authUser, 'manage_inventory')) {
                $poCheck = $db->prepare("SELECT id FROM purchases WHERE id = ?");
                $poInsert = $db->prepare("INSERT INTO purchases (id, order_number, supplier_name, supplier_contact, order_date, status, total_cost, ordered_cost, shipping_cost, notes, created_by, branch_code, vendor_id, amount_paid, credit_used, payment_status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, 'PENDING', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $poRetotal = $db->prepare("UPDATE purchases SET total_cost = ?, ordered_cost = ?, updated_at = datetime('now') WHERE id = ?");
                $poVenLookup = $db->prepare("SELECT id, name, balance FROM vendors WHERE id = ?");
                $poVenBump = $db->prepare("UPDATE vendors SET balance = balance + ?, updated_at = datetime('now') WHERE id = ?");
                $poVpayInsert = $db->prepare("INSERT OR IGNORE INTO vendor_payments (id, vendor_id, purchase_id, user_id, amount, payment_method, reference_no, payment_date, notes, created_at)
                                              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))");

                $poIdx = 0;
                foreach ($offlinePurchases as $po) {
                    $poid = trim((string)($po['id'] ?? ''));
                    if ($poid === '') continue;
                    $poIdx++;
                    $pBranch = strtoupper(trim((string)($po['branch_code'] ?? 'MAIN-01'))) ?: 'MAIN-01';

                    $poCheck->execute([$poid]);
                    if ($poCheck->fetch()) {
                        $processedPurchaseIds[] = $poid;
                        continue;
                    }

                    $poOrderNumber = trim((string)($po['order_number'] ?? '')) ?: ('PO-' . date('YmdHis') . '-' . strtoupper(bin2hex(random_bytes(2))));
                    $poShipping = round(floatval($po['shipping_cost'] ?? 0), 2);
                    $poVendorId = trim((string)($po['vendor_id'] ?? '')) ?: null;
                    $poItems = (array)($po['items'] ?? []);
                    $provisional = 0.0;
                    foreach ($poItems as $probe) {
                        $provisional += round(floatval($probe['quantity'] ?? 0) * floatval($probe['cost_price'] ?? 0), 2);
                    }
                    $provisional = round($provisional + $poShipping, 2);

                    $poSavepoint = 'sp_po_' . $poIdx;
                    $db->exec("SAVEPOINT {$poSavepoint}");
                    try {
                        $poInsert->execute([
                            $poid,
                            $poOrderNumber,
                            $po['supplier_name'] ?? 'Factory Supplier',
                            $po['supplier_contact'] ?? '',
                            $po['order_date'] ?? date('Y-m-d'),
                            $provisional,
                            $provisional,
                            $poShipping,
                            $po['notes'] ?? '',
                            intval($authUser['id'] ?? 1),
                            $pBranch,
                            $poVendorId,
                            0.0,
                            0.0,
                            'UNPAID',
                            $po['created_at'] ?? date('Y-m-d H:i:s'),
                            $po['updated_at'] ?? date('Y-m-d H:i:s')
                        ]);

                        // The lines decide what the order is worth, never the figure the till
                        // carried: a line naming a product or a size this shop does not stock
                        // cannot be priced, and booking the till's total anyway would bill the
                        // owner for goods the catalogue has never heard of.
                        $recorded = recordPurchaseOrderLines($db, $poid, $poItems);
                        foreach ($recorded['problems'] as $problem) {
                            logActivity($db, intval($authUser['id'] ?? 1), $authUser['full_name'] ?? 'Staff', $authUser['role_name'] ?? 'Staff',
                                'SYNC_PURCHASE_LINE_SKIPPED',
                                "Purchase order #{$poOrderNumber} (synced from an offline till) lost a line: {$problem['message']} The rest of the order was booked at its own cost.");
                        }
                        if (!$recorded['lines']) {
                            throw new RuntimeException('none of its lines are products this shop stocks');
                        }

                        $linesTotal = 0.0;
                        foreach ($recorded['lines'] as $line) $linesTotal += floatval($line['subtotal']);
                        $poTotal = round($linesTotal + $poShipping, 2);
                        $poRetotal->execute([$poTotal, $poTotal, $poid]);

                        $poPaid = max(0.0, round(floatval($po['amount_paid'] ?? $poTotal), 2));
                        $poCreditHeld = 0.0;
                        $poVenRow = null;
                        if ($poVendorId !== null) {
                            $poVenLookup->execute([$poVendorId]);
                            $poVenRow = $poVenLookup->fetch() ?: null;
                            if ($poVenRow) $poCreditHeld = max(0.0, round(-floatval($poVenRow['balance']), 2));
                        }
                        $poCredit = round(min(
                            max(0.0, round(floatval($po['credit_used'] ?? 0), 2)),
                            $poCreditHeld,
                            max(0.0, round($poTotal - $poPaid, 2))
                        ), 2);
                        $poPaymentStatus = ($poPaid + $poCredit) >= ($poTotal - 0.005) ? 'PAID' : ($poPaid > 0 ? 'PARTIAL' : 'UNPAID');

                        $db->prepare("UPDATE purchases SET amount_paid = ?, credit_used = ?, payment_status = ?, updated_at = datetime('now') WHERE id = ?")
                           ->execute([$poPaid, $poCredit, $poPaymentStatus, $poid]);

                        if ($poVendorId !== null) {
                            if ($poVenRow) {
                                // Same rule as purchases.php: the credit draw is the reason the
                                // +20 debit closes a -20 balance, not a second payment.
                                $poDelta = round($poTotal - $poPaid, 2);
                                if (abs($poDelta) >= 0.005) {
                                    $poVenBump->execute([$poDelta, $poVendorId]);
                                }
                                if ($poPaid > 0) {
                                    $poVpayInsert->execute([
                                        vendorLedgerIdFor($poid, 'CASH'),
                                        $poVendorId, $poid, intval($authUser['id'] ?? 1), $poPaid, 'CASH',
                                        $poOrderNumber, $po['order_date'] ?? date('Y-m-d'),
                                        'Down payment on order #' . $poOrderNumber
                                    ]);
                                }
                                if ($poCredit > 0) {
                                    $poVpayInsert->execute([
                                        vendorLedgerIdFor($poid, 'BALANCE'),
                                        $poVendorId, $poid, intval($authUser['id'] ?? 1), $poCredit, 'BALANCE',
                                        $poOrderNumber, $po['order_date'] ?? date('Y-m-d'),
                                        'Credit balance drawn on order #' . $poOrderNumber
                                    ]);
                                }
                            } else {
                                // The supplier record never made it in the same batch. The order
                                // is still real, but the debt is not booked against a stranger.
                                logActivity($db, intval($authUser['id'] ?? 1), $authUser['full_name'] ?? 'Staff', $authUser['role_name'] ?? 'Staff',
                                    'SYNC_PURCHASE_VENDOR_MISSING',
                                    "Purchase order #{$poOrderNumber} names supplier '{$poVendorId}', which this shop has no record of. The order was booked but no accounts payable was raised against it. Re-link it to a registered supplier.");
                            }
                        }

                        recordPurchaseEvent($db, $poid, 'ORDERED', '',
                            sprintf('Order placed with %s for %s. Awaiting delivery.', $po['supplier_name'] ?? 'Factory Supplier', $poTotal),
                            $poTotal, $authUser);

                        logActivity($db, intval($authUser['id'] ?? 1), $authUser['full_name'] ?? 'Staff', $authUser['role_name'] ?? 'Staff',
                            'PURCHASE_SYNC',
                            "Synced factory purchase order #{$poOrderNumber} from " . ($po['supplier_name'] ?? 'Supplier') . " (Total: {$poTotal}). Awaiting delivery - no stock has reached the shelf.");

                        $db->exec("RELEASE {$poSavepoint}");
                        $processedPurchaseIds[] = $poid;
                        $totalProcessed++;
                    } catch (Throwable $poError) {
                        // One unbookable order cannot take the till's whole day with it: the
                        // receipts, expenses and payouts queued behind it are still good.
                        $db->exec("ROLLBACK TO {$poSavepoint}");
                        $db->exec("RELEASE {$poSavepoint}");
                        $rejectedIds['purchases'][] = $poid;
                        $purchaseErrors[$poid] = $poError->getMessage();
                        error_log('StoreFlow sync: purchase order ' . $poid . ' was refused - ' . $poError->getMessage());
                    }
                }
            } else {
                error_log("Sync: User " . ($authUser['id'] ?? 'unknown') . " lacked permission to sync purchases.");
                foreach ($offlinePurchases as $po) {
                    $pid = trim((string)($po['id'] ?? ''));
                    if ($pid !== '') $rejectedIds['purchases'][] = $pid;
                }
            }
        }

        // 4b. The deliveries an offline till stood at the back door and counted
        //
        // Replayed through the same helper the online screen calls, so a short delivery means
        // the same thing - and costs the shop the same amount - whichever door it came through.
        // Each movement carries the till's own id, and that id becomes the event's primary key:
        // a queue that is pushed twice moves the shelf once.
        $offlinePurchaseMovements = normalizeSyncList($data['purchase_movements'] ?? []);
        if (!empty($offlinePurchaseMovements) && is_array($offlinePurchaseMovements)) {
            if (!hasPermission($authUser, 'manage_purchases')) {
                error_log("Sync: User " . ($authUser['id'] ?? 'unknown') . " lacked permission to sync purchase count-ins.");
                foreach ($offlinePurchaseMovements as $mv) {
                    $mid = trim((string)($mv['id'] ?? ''));
                    if ($mid !== '') $rejectedIds['purchase_movements'][] = $mid;
                }
            } else {
                $mvPoLookup = $db->prepare("SELECT * FROM purchases WHERE id = ?");
                $purchaseReasons = ['VENDOR_FAILED', 'SHORT_DELIVERY', 'WRONG_GOODS', 'DAMAGED', 'CHANGED_MIND', 'PRICE_CHANGED', 'DELAYED', 'OTHER'];
                $mvSeen = [];
                $mvIdx = 0;
                foreach ($offlinePurchaseMovements as $mv) {
                    $mvIdx++;
                    $mvId = trim((string)($mv['id'] ?? ''));
                    $mvAction = strtoupper(trim((string)($mv['action'] ?? '')));
                    $mvPoId = trim((string)($mv['purchase_id'] ?? ''));

                    // An id that is not a key is not an id, and without one the server has
                    // nothing to collide with on the next replay.
                    if (!preg_match('/^(pmv|pev)_[A-Za-z0-9_\-]{4,48}$/', $mvId)
                        || !in_array($mvAction, ['COUNT_IN', 'CANCEL'], true) || $mvPoId === '') {
                        if ($mvId !== '') $rejectedIds['purchase_movements'][] = $mvId;
                        continue;
                    }
                    if (isset($mvSeen[$mvId])) continue;
                    $mvSeen[$mvId] = true;

                    $mvPoLookup->execute([$mvPoId]);
                    $mvPo = $mvPoLookup->fetch();
                    if (!$mvPo) {
                        // The order has not arrived yet - it is queued behind this count-in in
                        // the same batch, or belongs to another till. Stay queued and retry.
                        $rejectedIds['purchase_movements'][] = $mvId;
                        $purchaseErrors[$mvId] = 'The order it counts in is not on this shop\'s books yet.';
                        continue;
                    }

                    $mvReason = strtoupper(trim((string)($mv['reason_code'] ?? '')));
                    if (!in_array($mvReason, $purchaseReasons, true)) $mvReason = '';
                    $mvNote = trim((string)($mv['note'] ?? ''));
                    $mvSavepoint = 'sp_mv_' . $mvIdx;
                    $db->exec("SAVEPOINT {$mvSavepoint}");

                    $verdict = $mvAction === 'COUNT_IN'
                        ? countInPurchaseOrder($db, $mvPo, (array)($mv['lines'] ?? []), $authUser, $mvId, $mvReason, $mvNote,
                            'Counted at the back door by an offline till.')
                        : cancelPurchaseOrder($db, $mvPo, $authUser, $mvReason, $mvNote, $mvId,
                            'Called off on an offline till.');

                    if ($verdict['ok']) {
                        $db->exec("RELEASE {$mvSavepoint}");
                        $processedPurchaseMovementIds[] = $mvId;
                        $totalProcessed++;
                    } else {
                        $db->exec("ROLLBACK TO {$mvSavepoint}");
                        $db->exec("RELEASE {$mvSavepoint}");
                        $rejectedIds['purchase_movements'][] = $mvId;
                        $purchaseErrors[$mvId] = (string)($verdict['body']['message'] ?? 'The count-in was refused.');
                    }
                }
            }
        }

        // 5. Process Offline Sales
        if (!empty($offlineSales) && is_array($offlineSales)) {
            $sCheck = $db->prepare("SELECT id FROM sales WHERE id = ?");
            $sInsert = $db->prepare("INSERT INTO sales (id, receipt_number, customer_id, user_id, terminal_id, branch_code, sale_date, subtotal, discount, loyalty_discount, tier_discount, tax, total_amount, total_cost, gross_profit, payment_method, amount_paid, change_due, status, notes, loyalty_points_earned, loyalty_points_redeemed, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'COMPLETED', ?, ?, ?, ?, ?)");
            $siInsert = $db->prepare("INSERT INTO sale_items (id, sale_id, product_id, quantity, unit_cost_price, unit_selling_price, subtotal, profit, batch_id, batch_number, expiry_date, unit, multiplier, base_quantity) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $invDec = $db->prepare("UPDATE inventory SET current_quantity = current_quantity - ?, updated_at = datetime('now') WHERE product_id = ?");
            $binvInit = $db->prepare("INSERT OR IGNORE INTO branch_inventory (id, branch_code, product_id, current_quantity, updated_at)
                                      VALUES ('binv_' || lower(hex(randomblob(6))), ?, ?, 0, datetime('now'))");
            $binvDec = $db->prepare("UPDATE branch_inventory SET
                                     current_quantity = current_quantity - ?,
                                     updated_at = datetime('now')
                                     WHERE branch_code = ? AND product_id = ?");

            // Prepared unconditionally. It used to exist only inside the "offline
            // products" block above, which runs only when that list is non-empty AND
            // the user holds manage_inventory, but a sale line reaches it whenever the
            // server has never seen the product. A cashier syncing a receipt for such a
            // product called execute() on null, raising an Error that catch (Exception)
            // does not take: the open transaction never committed, so every queued sale
            // and purchase in the batch was discarded and the till retried forever.
            $invInsert = $db->prepare("INSERT INTO inventory (id, product_id, current_quantity, reorder_level, location, updated_at) VALUES (?, ?, ?, ?, ?, ?)");

            // Lot consumption and the movement ledger, mirroring the online path in
            // sales.php. Offline receipts used to skip both, so product_batches drifted
            // above real stock (wrong expiry KPIs and write-off ceilings) and synced
            // sales were missing from stock movement history.
            $batchFindStmt = $db->prepare("SELECT id, batch_number, expiry_date, current_quantity
                                           FROM product_batches
                                           WHERE product_id = ? AND branch_code = ? AND current_quantity > 0 AND status = 'ACTIVE'
                                           ORDER BY expiry_date ASC");
            $batchDeductStmt = $db->prepare("UPDATE product_batches
                                             SET current_quantity = MAX(0, current_quantity - ?),
                                                 status = CASE WHEN (current_quantity - ?) <= 0.001 THEN 'DEPLETED' ELSE status END,
                                                 updated_at = datetime('now')
                                             WHERE id = ?");
            $mvtStmt = $db->prepare("INSERT INTO inventory_movements (id, product_id, movement_type, quantity, reference_id, unit_price, notes, branch_code, created_at)
                                     VALUES (?, ?, 'SALE', ?, ?, ?, ?, ?, datetime('now'))");

            // The server decides who took the money and where, from what the catalogue
            // says the goods cost, and never from the numbers in the request body.
            $prodLookStmt = $db->prepare("SELECT p.id, p.name, p.cost_price, p.selling_price, p.unit, p.product_type, p.is_rental,
                                                 binv.custom_selling_price
                                          FROM products p
                                          LEFT JOIN branch_inventory binv ON p.id = binv.product_id AND binv.branch_code = ?
                                          WHERE p.id = ?");
            $syncComboLookStmt = $db->prepare("SELECT * FROM product_combo_items WHERE combo_product_id = ?");
            $branchLookStmt = $db->prepare("SELECT branch_code FROM branches WHERE branch_code = ?");

            $sIdx = 0;
            $pEnsureStmt = $db->prepare("SELECT id FROM products WHERE id = ?");
            $pAutoCreate = $db->prepare("INSERT INTO products (id, name, sku, category, unit, cost_price, selling_price, min_stock_alert, is_active, created_at, updated_at) VALUES (?, ?, ?, 'General', ?, ?, ?, 0, 1, datetime('now'), datetime('now'))");

            foreach ($offlineSales as $sale) {
                $sid = trim($sale['id'] ?? '');
                if (empty($sid)) continue;
                $sIdx++;
                $spSale = 'sp_sale_' . $sIdx;

                $db->exec("SAVEPOINT {$spSale}");
                try {
                    $sCheck->execute([$sid]);
                    if (!$sCheck->fetch()) {
                        // Attribution and pricing are decided here, not read from the
                        // request. The till's session says who synced and, for anyone
                        // below a manager, which branch they work in; sales.php already
                        // works that way online. Body-supplied user_id and branch_code
                        // let a devtools edit put takings on a colleague's tab or move a
                        // receipt into another branch's totals, and body-supplied prices
                        // let it invent the amount. Cost always comes from the catalogue,
                        // because profit is the owner's number, not the till's.
                        $canOverridePrice = maySetSalePrices($authUser);

                        $sUser = max(1, intval($authUser['id'] ?? 1));

                        $claimedBranch = strtoupper(trim((string)($sale['branch_code'] ?? '')));
                        if ($claimedBranch === '' || $claimedBranch === 'ALL') $claimedBranch = 'MAIN-01';
                        if ($isSuperUser) {
                            $branchLookStmt->execute([$claimedBranch]);
                            $saleBranch = $branchLookStmt->fetchColumn() ? $claimedBranch : 'MAIN-01';
                        } else {
                            $ownBranch = strtoupper(trim((string)($authUser['branch_code'] ?? 'MAIN-01')));
                            $saleBranch = $ownBranch !== '' ? $ownBranch : 'MAIN-01';
                        }

                        // A till with a drifted clock must not file its trade in the
                        // future, where every date-filtered report the owner runs loses it.
                        $claimedDate = trim((string)($sale['sale_date'] ?? ''));
                        $claimedEpoch = $claimedDate !== '' ? strtotime($claimedDate) : false;
                        $saleDate = ($claimedEpoch !== false && $claimedEpoch <= time() + 120)
                            ? date('Y-m-d H:i:s', $claimedEpoch)
                            : date('Y-m-d H:i:s');

                        $sDiscount = round(floatval($sale['discount'] ?? 0), 2);
                        $sTax = round(floatval($sale['tax'] ?? 0), 2);
                        $paymentMethod = strtoupper(trim($sale['payment_method'] ?? 'CASH')) ?: 'CASH';
                        $receiptNumber = trim((string)($sale['receipt_number'] ?? '')) ?: ('REC-' . date('Ymd') . '-' . rand(1000, 9999));
                        // Until the lines are read there is nothing to price points against, and a
                        // receipt that arrives with no lines keeps these at zero.
                        $sLoyaltyValue = 0.0;
                        $sTierValue = 0.0;
                        $sLoyaltyEarned = 0.0;
                        $sLoyaltyRedeemed = 0.0;

                        $lines = [];
                        $rawItems = isset($sale['items']) && is_array($sale['items']) ? $sale['items'] : [];
                        foreach ($rawItems as $it) {
                            if (!is_array($it)) continue;
                            $prodId = trim((string)($it['product_id'] ?? $it['item_id'] ?? $it['id'] ?? ''));
                            $qty = floatval($it['quantity'] ?? 0);
                            if ($prodId === '' || $qty <= 0) continue;

                            $itUnit = trim((string)($it['unit'] ?? ''));

                            // Ensure product exists to satisfy the foreign key constraint.
                            // If prodId not found by ID, attempt lookup by SKU or barcode so mobile transactions match existing PC catalog
                            $pEnsureStmt->execute([$prodId]);
                            $foundProd = $pEnsureStmt->fetch();
                            if (!$foundProd) {
                                $altSku = trim((string)($it['sku'] ?? ''));
                                $altBarcode = trim((string)($it['barcode'] ?? ''));
                                $altName = trim((string)($it['product_name'] ?? $it['name'] ?? ''));
                                if ($altSku !== '' || $altBarcode !== '' || $altName !== '') {
                                    $altLookup = $db->prepare("SELECT id FROM products WHERE (sku != '' AND LOWER(sku) = LOWER(?)) OR (barcode != '' AND barcode = ?) OR (name != '' AND LOWER(name) = LOWER(?)) LIMIT 1");
                                    $altLookup->execute([$altSku, $altBarcode, $altName]);
                                    $matchedAlt = $altLookup->fetch(PDO::FETCH_ASSOC);
                                    if ($matchedAlt && !empty($matchedAlt['id'])) {
                                        $prodId = $matchedAlt['id'];
                                        $foundProd = true;
                                    }
                                }
                            }
                            if (!$foundProd) {
                                $autoCost = round(floatval($it['unit_cost_price'] ?? 0), 2);
                                $autoPrice = round(floatval($it['unit_selling_price'] ?? 0), 2);
                                $autoSku = !empty($it['sku']) ? trim($it['sku']) : ('SKU-' . strtoupper(bin2hex(random_bytes(4))));
                                $autoName = trim($it['product_name'] ?? $it['name'] ?? ('Product ' . substr($prodId, 0, 8)));
                                // The till's word for the loose unit is the only name this
                                // product will ever have, and a row with no unit rows is one
                                // the online till then refuses to sell in any size at all.
                                $autoUnit = ($itUnit !== '' && mb_strlen($itUnit) <= 40) ? $itUnit : 'pcs';
                                $pAutoCreate->execute([$prodId, $autoName, $autoSku, $autoUnit, $autoCost, $autoPrice]);
                                sfUnitsReplace($db, $prodId, sfUnitsNormalize(null, $autoUnit)['rows']);
                                $invInsert->execute(['inv_' . bin2hex(random_bytes(6)), $prodId, 0, 0, 'Main Storefront', date('Y-m-d H:i:s')]);
                            }

                            $prodLookStmt->execute([$saleBranch, $prodId]);
                            $prodDb = $prodLookStmt->fetch(PDO::FETCH_ASSOC) ?: null;

                            // The till states which size it sold; the catalogue says how many
                            // base units that is and what to charge for it. `multiplier` and
                            // `base_quantity` used to be read from the receipt itself, so a
                            // synced line could claim a 1000x pack and deduct a thousand units
                            // while pricing the goods at one piece - the mismatch was invisible
                            // because the same body supplied both numbers.
                            $unitRow = sfUnitResolve($db, $prodId, $itUnit, true);
                            if ($unitRow !== null) {
                                $itUnit = trim((string)($unitRow['unit_name'] ?? '')) ?: 'pcs';
                                $itMultiplier = round(floatval($unitRow['size_in_base'] ?? 1), 4);
                                if ($itMultiplier < 1) $itMultiplier = 1.0;
                                $unitPrice = ($unitRow['selling_price'] === null || $unitRow['selling_price'] === '')
                                    ? null : floatval($unitRow['selling_price']);
                            } else {
                                // A receipt the customer has already paid cannot be answered by
                                // reading a size the shop has since renamed or dropped as one
                                // loose unit: that would hand the shelf back 419 eggs on a box.
                                // The till's own number is used, bounded by the largest size the
                                // catalogue still sells, and the owner is told which receipt to
                                // check rather than being left to find it in a count.
                                $claimedMultiplier = round(floatval($it['multiplier'] ?? 1), 4);
                                $largestSize = 1.0;
                                foreach (sfUnitsFor($db, $prodId) as $knownUnit) {
                                    $largestSize = max($largestSize, round(floatval($knownUnit['size_in_base'] ?? 1), 4));
                                }
                                $itMultiplier = min(max(1.0, $claimedMultiplier), $largestSize);
                                $unitPrice = null;
                                $saleName = (string)($prodDb['name'] ?? $prodId);
                                logActivity($db, intval($authUser['id'] ?? 1), $authUser['full_name'] ?? 'Staff',
                                    $authUser['role_name'] ?? 'Staff', 'SYNC_UNIT_CAPPED',
                                    sprintf("Receipt %s sold %s in a '%s', which the catalogue does not carry. Booked at %s base units - the largest size %s sells - instead of the %s the till claimed; check this receipt.",
                                        $receiptNumber, $saleName, $itUnit,
                                        number_format($itMultiplier, 2, '.', ''), $saleName,
                                        number_format($claimedMultiplier, 2, '.', '')));
                            }
                            $itBaseQty = $qty * $itMultiplier;

                            $cost = $prodDb !== null
                                ? round(floatval($prodDb['cost_price']), 2)
                                : round(floatval($it['unit_cost_price'] ?? 0), 2);

                            if ($prodDb !== null) {
                                $authPrice = ($prodDb['custom_selling_price'] !== null && $prodDb['custom_selling_price'] !== '')
                                    ? round(floatval($prodDb['custom_selling_price']), 2)
                                    : round(floatval($prodDb['selling_price']), 2);
                                $expected = sfUnitPrice($unitPrice, $itMultiplier, $authPrice);
                                $asked = round(floatval($it['unit_selling_price'] ?? $expected), 2);
                                if (!$canOverridePrice && abs($asked - $expected) >= 0.01) {
                                    // Already paid for at the till, so the receipt is kept -
                                    // but the ledger records what the shop actually sells at.
                                    // The difference then shows as a drawer shortage instead of
                                    // quietly becoming the cashier's price list.
                                    error_log(sprintf("Sync: sale %s priced '%s' at %.2f, recorded at the catalogue price %.2f.", $sid, $prodDb['name'], $asked, $expected));
                                    $price = $expected;
                                } else {
                                    $price = $asked;
                                }
                            } else {
                                $price = round(floatval($it['unit_selling_price'] ?? 0), 2);
                            }

                            $pType = strtolower(trim((string)($prodDb['product_type'] ?? 'standard')));

                            // A hire asset sold while the till was offline is money the customer has
                            // already paid, so the receipt stands and the shelf moves - but the hire
                            // desk is the one that loses, because it will keep showing the chair as
                            // available to hire. The counter refuses this outright; here it is booked
                            // and written where the shopkeeper reads.
                            if (intval($prodDb['is_rental'] ?? 0) === 1) {
                                logActivity($db, intval($authUser['id'] ?? 1), $authUser['full_name'] ?? 'Staff',
                                    $authUser['role_name'] ?? 'Staff', 'SYNC_HIRE_SOLD',
                                    sprintf("Receipt %s sold %s outright. That product is hire equipment, so the sale carries no contract, no caution deposit and nothing to inspect back in - the hire desk should stop offering it until the shelf count matches.",
                                        $receiptNumber, (string)($prodDb['name'] ?? $prodId)));
                            }

                            $cComponents = [];
                            if ($pType === 'combo') {
                                $syncComboLookStmt->execute([$prodId]);
                                $cComponents = $syncComboLookStmt->fetchAll(PDO::FETCH_ASSOC);
                            }

                            $lines[] = [
                                'product_id' => $prodId,
                                // Kept so a floor mismatch can be written into the shop's log as
                                // "1 x Cold Brew (bottle)" rather than as a product id nobody can
                                // look up without opening another table.
                                'product_name' => (string)($prodDb['name'] ?? $prodId),
                                'quantity'   => $qty,
                                'multiplier' => $itMultiplier,
                                'base_qty'   => $itBaseQty,
                                'unit'       => $itUnit,
                                'cost'       => $cost,
                                'price'      => $price,
                                'subtotal'   => round($qty * $price, 2),
                                'line_cost'  => round($itBaseQty * $cost, 2),
                                'product_type' => $pType,
                                'combo_components' => $cComponents
                            ];
                        }

                        if (!empty($lines)) {
                            $sSubtotal = round(array_sum(array_column($lines, 'subtotal')), 2);
                            $sCost     = round(array_sum(array_column($lines, 'line_cost')), 2);

                            // Same reasoning as the price clamp above: the customer has
                            // already been charged, so the receipt stays, but a discount
                            // only a manager may give - or tax the shop does not charge -
                            // is recorded at the largest legitimate size and logged.
                            $discountCap = saleDiscountCap($authUser, $sSubtotal);
                            $allowedDiscount = ($discountCap === null) ? $sDiscount : min($sDiscount, $discountCap);
                            if ($allowedDiscount < 0) {
                                $allowedDiscount = 0.0;
                            }
                            if (round($allowedDiscount, 2) !== round($sDiscount, 2)) {
                                error_log(sprintf("Sync: sale %s discount %.2f limited to %.2f on a %.2f basket.", $sid, $sDiscount, $allowedDiscount, $sSubtotal));
                                $sDiscount = $allowedDiscount;
                            }
                            $allowedTax = max(0, min($sTax, saleTaxCap($profRow ?: [], $sSubtotal)));
                            if (round($allowedTax, 2) !== round($sTax, 2)) {
                                error_log(sprintf("Sync: sale %s tax %.2f limited to the configured %.2f.", $sid, $sTax, $allowedTax));
                                $sTax = $allowedTax;
                            }

                            // The member's points are priced here, by the shop's settings, exactly
                            // as they are at the counter. The till only says how many were offered:
                            // an offline receipt used to be able to cut its own price by a rate the
                            // browser guessed and still leave the balance untouched, which is a
                            // discount the shop never agreed to and points nobody spent.
                            $sLoyalty = StoreFlowLoyalty::authorSaleLoyalty(
                                $db,
                                (string)($sale['customer_id'] ?? 'cust-walkin'),
                                $sSubtotal,
                                $sDiscount,
                                round(floatval($sale['loyalty_points_redeemed'] ?? 0), 2),
                                $sid,
                                intval($sUser ?? 0),
                                (string)$saleBranch
                            );
                            if (!empty($sLoyalty['refused'])) {
                                // Books and tells: the receipt is the shop's own takings and is
                                // never discarded over a redemption it cannot honour.
                                error_log("Sync: sale {$sid} - " . $sLoyalty['refused']);
                            }
                            if (!empty($sLoyalty['note'])) {
                                error_log("Sync: sale {$sid} - " . $sLoyalty['note']);
                            }
                            $sLoyaltyValue = round(floatval($sLoyalty['loyalty_value'] ?? 0), 2);
                            $sTierValue = round(floatval($sLoyalty['tier_value'] ?? 0), 2);
                            $sLoyaltyEarned = round(floatval($sLoyalty['earned'] ?? 0), 2);
                            $sLoyaltyRedeemed = round(floatval($sLoyalty['redeemed'] ?? 0), 2);

                            $sTotal    = round(max(0, ($sSubtotal - $sDiscount - $sLoyaltyValue - $sTierValue) + $sTax), 2);
                            // The same rule the counter applies, out of db.php: the tax on the
                            // receipt is money the shop is holding for somebody else.
                            $sProfit   = saleGrossProfit($sSubtotal, $sDiscount + $sLoyaltyValue + $sTierValue, $sTax, $sCost);
                        } else {
                            // A receipt with no usable lines is not something the till
                            // produces, but dropping one would leave it queued forever.
                            // It is stored as sent and written to the log.
                            $sSubtotal = round(floatval($sale['subtotal'] ?? 0), 2);
                            $sCost     = round(floatval($sale['total_cost'] ?? 0), 2);
                            $sTotal    = round(floatval($sale['total_amount'] ?? $sSubtotal), 2);
                            $sProfit   = saleGrossProfit($sSubtotal, floatval($sale['discount'] ?? 0),
                                                         floatval($sale['tax'] ?? 0), $sCost);
                            error_log("Sync: offline sale {$sid} carried no usable line items; header stored as sent.");
                        }

                        $sPaid = round(floatval($sale['amount_paid'] ?? 0), 2);
                        if ($paymentMethod === 'CASH' && $sPaid <= 0) $sPaid = $sTotal;
                        $sChange = round(max(0, $sPaid - $sTotal), 2);

                        $sInsert->execute([
                            $sid,
                            $receiptNumber,
                            $sale['customer_id'] ?? 'cust-walkin',
                            $sUser,
                            $sale['terminal_id'] ?? 'REG-01',
                            $saleBranch,
                            $saleDate,
                            $sSubtotal,
                            $sDiscount,
                            $sLoyaltyValue,
                            $sTierValue,
                            $sTax,
                            $sTotal,
                            $sCost,
                            $sProfit,
                            $paymentMethod,
                            $sPaid,
                            $sChange,
                            $sale['notes'] ?? '',
                            $sLoyaltyEarned,
                            $sLoyaltyRedeemed,
                            $saleDate,
                            date('Y-m-d H:i:s')
                        ]);

                        $branchStockStmt = $db->prepare("SELECT current_quantity FROM branch_inventory WHERE branch_code = ? AND product_id = ?");

                        foreach ($lines as $ln) {
                            $prodId = $ln['product_id'];

                            $allocatedBatchId = null;
                            $allocatedBatchNo = null;
                            $allocatedExpiry = null;
                            $remToDeduct = $ln['base_qty'];
                            $batchFindStmt->execute([$prodId, $saleBranch]);
                            foreach ($batchFindStmt->fetchAll(PDO::FETCH_ASSOC) as $cBatch) {
                                if ($remToDeduct <= 0) break;
                                $deductFromThis = min($remToDeduct, floatval($cBatch['current_quantity']));
                                $batchDeductStmt->execute([$deductFromThis, $deductFromThis, $cBatch['id']]);
                                $remToDeduct -= $deductFromThis;
                                if ($allocatedBatchNo === null) {
                                    $allocatedBatchId = $cBatch['id'];
                                    $allocatedBatchNo = $cBatch['batch_number'];
                                    $allocatedExpiry = $cBatch['expiry_date'];
                                }
                            }

                            $siInsert->execute([
                                'si_' . bin2hex(random_bytes(6)), $sid, $prodId, $ln['quantity'],
                                $ln['cost'], $ln['price'], $ln['subtotal'],
                                round($ln['subtotal'] - $ln['line_cost'], 2),
                                $allocatedBatchId, $allocatedBatchNo, $allocatedExpiry,
                                $ln['unit'], $ln['multiplier'], $ln['base_qty']
                            ]);

                            if (($ln['product_type'] ?? 'standard') === 'service') {
                                continue;
                            }

                            if (($ln['product_type'] ?? 'standard') === 'combo' && !empty($ln['combo_components'])) {
                                foreach ($ln['combo_components'] as $cComp) {
                                    $compDeduct = round($ln['quantity'] * floatval($cComp['quantity']), 4);
                                    $cProdId = $cComp['component_product_id'];

                                    $batchFindStmt->execute([$cProdId, $saleBranch]);
                                    $cBatches = $batchFindStmt->fetchAll(PDO::FETCH_ASSOC);
                                    if (!empty($cBatches)) {
                                        $remComp = $compDeduct;
                                        foreach ($cBatches as $cb) {
                                            if ($remComp <= 0) break;
                                            $dThis = min($remComp, floatval($cb['current_quantity']));
                                            $batchDeductStmt->execute([$dThis, $dThis, $cb['id']]);
                                            $remComp -= $dThis;
                                        }
                                    }

                                    $invDec->execute([$compDeduct, $cProdId]);
                                    $binvInit->execute([$saleBranch, $cProdId]);
                                    $binvDec->execute([$compDeduct, $saleBranch, $cProdId]);
                                    $mvtStmt->execute([
                                        'mvt_' . bin2hex(random_bytes(6)), $cProdId, -$compDeduct,
                                        $receiptNumber, floatval($cComp['component_cost'] ?? 0),
                                        "Offline combo deduction for '{$ln['product_name']}' (#{$receiptNumber})", $saleBranch
                                    ]);
                                }
                                continue;
                            }

                            $invDec->execute([$ln['base_qty'], $prodId]);

                            $binvInit->execute([$saleBranch, $prodId]);
                            $binvDec->execute([$ln['base_qty'], $saleBranch, $prodId]);

                            // The units have already left the shelf, so the sale is never
                            // refused here - but a shop that forbids negative stock is
                            // entitled to be told the till just drove it below zero.
                            if ($allowNegativeStock === 0) {
                                $branchStockStmt->execute([$saleBranch, $prodId]);
                                $left = floatval($branchStockStmt->fetchColumn());
                                if ($left < 0) {
                                    logActivity($db, $sUser, $authUser['full_name'] ?? 'Cashier', $authUser['role_name'] ?? 'Cashier',
                                        'SYNC_STOCK_SHORTFALL', "Offline receipt {$receiptNumber} took branch {$saleBranch} stock of product {$prodId} to {$left} while negative stock is disabled.");
                                }
                            }

                            $mvtNotes = "Offline POS Sale Receipt: {$receiptNumber}";
                            if ($allocatedBatchNo) $mvtNotes .= " [Batch: {$allocatedBatchNo}, Exp: {$allocatedExpiry}]";
                            $mvtStmt->execute([
                                'mvt_' . bin2hex(random_bytes(6)), $prodId, -$ln['base_qty'],
                                $receiptNumber, round($ln['price'] / max(1.0, $ln['multiplier']), 4), $mvtNotes, $saleBranch
                            ]);
                        }

                        // Update customer balance for offline sale
                        $cId = trim($sale['customer_id'] ?? 'cust-walkin');
                        if ($cId && $cId !== 'cust-walkin') {
                            $pAmountPaid = $sPaid;
                            $pTotalAmount = $sTotal;
                            $pApplyOver = !empty($sale['apply_overpayment_to_account']);

                            if ($paymentMethod === 'CREDIT') {
                                $netCredit = round($pTotalAmount - $pAmountPaid, 2);
                                if ($netCredit != 0) {
                                    $cUpd = $db->prepare("UPDATE customers SET balance = balance + ?, updated_at = datetime('now') WHERE id = ?");
                                    $cUpd->execute([$netCredit, $cId]);
                                }
                            } elseif ($pAmountPaid < $pTotalAmount) {
                                $unpaid = round($pTotalAmount - $pAmountPaid, 2);
                                $cUpd = $db->prepare("UPDATE customers SET balance = balance + ?, updated_at = datetime('now') WHERE id = ?");
                                $cUpd->execute([$unpaid, $cId]);
                            } elseif ($pApplyOver && $pAmountPaid > $pTotalAmount) {
                                $over = round($pAmountPaid - $pTotalAmount, 2);
                                $cUpd = $db->prepare("UPDATE customers SET balance = balance - ?, updated_at = datetime('now') WHERE id = ?");
                                $cUpd->execute([$over, $cId]);
                            }
                        }
                        logActivity($db, $sUser, $authUser['full_name'] ?? 'Cashier', $authUser['role_name'] ?? 'Cashier', 'OFFLINE_SALE_SYNC', "Synced offline receipt #{$receiptNumber} ({$paymentMethod}, Total: {$sTotal}). Terminal: " . ($sale['terminal_id'] ?? 'REG-01'));

                        // A bill taken at an offline table closes its tab here, under the same
                        // rule the counter applies - with one difference, decided by what the
                        // shop can still afford to refuse. The customer was charged at the
                        // table hours ago, so the receipt is not the thing at risk: a tab this
                        // receipt does not cover is left open, and the floor is told in the
                        // audit trail, instead of the queue refusing a paid bill for good.
                        $tabId = trim((string)($sale['table_order_id'] ?? ''));
                        if ($tabId !== '') {
                            $tab = hospitalityFindTab($db, $tabId, $saleBranch, $isSuperUser);
                            if ($tab === null || isset($tab['error'])) {
                                logActivity($db, $sUser, $authUser['full_name'] ?? 'Cashier', $authUser['role_name'] ?? 'Cashier',
                                    'SYNC_TAB_UNRELEASED', "Receipt {$receiptNumber} was paid against dining tab {$tabId}, which this shop cannot release: "
                                        . ($tab === null ? 'no such tab on the books.' : $tab['error']));
                            } else {
                                $tabProblem = hospitalityTabMismatch($tab['items'], $lines, (string)($tab['table_number'] ?? ''));
                                if ($tabProblem === null) {
                                    if (hospitalityCloseTab($db, (string)$tab['id'], (string)$tab['table_id'], $sid)) {
                                        logActivity($db, $sUser, $authUser['full_name'] ?? 'Cashier', $authUser['role_name'] ?? 'Cashier',
                                            'HOSPITALITY_TAB_SETTLED', "Settled the offline tab for {$tab['table_number']} with receipt #{$receiptNumber} and released the table.");
                                        storeflow_do_action('hospitality_order_settled', $tab['id'], $sid, $receiptNumber);
                                    }
                                } else {
                                    logActivity($db, $sUser, $authUser['full_name'] ?? 'Cashier', $authUser['role_name'] ?? 'Cashier',
                                        'SYNC_TAB_UNRELEASED', "Receipt {$receiptNumber} was paid against the tab for {$tab['table_number']}, which is still open: {$tabProblem}");
                                }
                            }
                        }
                    }
                    $db->exec("RELEASE SAVEPOINT {$spSale}");
                    $processedSaleIds[] = $sid;
                    $totalProcessed++;
                } catch (Throwable $se) {
                    $db->exec("ROLLBACK TO SAVEPOINT {$spSale}");
                    $db->exec("RELEASE SAVEPOINT {$spSale}");
                    error_log("Sync: Rejected offline sale {$sid}: " . $se->getMessage());
                    $rejectedIds['sales'][] = $sid;
                }
            }
        }

        // 6. Process Offline Activity Logs
        $offlineLogs = $data['activity_logs'] ?? [];
        $processedLogIds = [];
        if (!empty($offlineLogs) && is_array($offlineLogs)) {
            $logCheck = $db->prepare("SELECT id FROM activity_logs WHERE id = ?");
            $logInsert = $db->prepare("INSERT INTO activity_logs (id, user_id, user_name, role_name, action_type, details, ip_address, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            foreach ($offlineLogs as $l) {
                $lid = trim($l['id'] ?? '');
                if (empty($lid)) continue;
                $logCheck->execute([$lid]);
                if (!$logCheck->fetch()) {
                    // The audit trail says who did it, so that is the session that
                    // synced it, not whatever the receipt of the moment claimed. A till
                    // used to be able to file an entry against a colleague's name, or
                    // backdate one into a period the owner had already closed.
                    $logWhen = trim((string)($l['created_at'] ?? ''));
                    $logEpoch = $logWhen !== '' ? strtotime($logWhen) : false;
                    $loggedAt = ($logEpoch !== false && $logEpoch <= time() + 120)
                        ? date('Y-m-d H:i:s', $logEpoch)
                        : date('Y-m-d H:i:s');
                    $logInsert->execute([
                        $lid,
                        intval($authUser['id'] ?? 1),
                        $authUser['full_name'] ?? 'Staff',
                        $authUser['role_name'] ?? 'Staff',
                        strtoupper(mb_substr(trim((string)($l['action_type'] ?? 'GENERAL')), 0, 40)) ?: 'GENERAL',
                        mb_substr(trim((string)($l['details'] ?? '')), 0, 500),
                        '127.0.0.1 (Offline Sync)',
                        $loggedAt
                    ]);
                }
                $processedLogIds[] = $lid;
                $totalProcessed++;
            }
        }

        // 7b. Process Offline Inter-Branch Transfers (same right as transfers.php: manage_inventory)
        $offlineTransfers = normalizeSyncList($data['transfers'] ?? []);
        $processedTransferIds = [];
        if (!empty($offlineTransfers) && is_array($offlineTransfers)) {
            if (hasPermission($authUser, 'manage_inventory')) {
                $trfCheck = $db->prepare("SELECT id FROM stock_transfers WHERE id = ?");
                $trfInsert = $db->prepare("INSERT INTO stock_transfers (id, transfer_number, source_branch, destination_branch, status, total_items, total_quantity, notes, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, 'COMPLETED', ?, ?, ?, ?, ?, ?)");
                $tiInsert = $db->prepare("INSERT INTO stock_transfer_items (id, transfer_id, product_id, quantity, cost_price, unit, multiplier, base_quantity) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $trfStockCheck = $db->prepare("SELECT current_quantity FROM branch_inventory WHERE branch_code = ? AND product_id = ?");
                $binvInit = $db->prepare("INSERT OR IGNORE INTO branch_inventory (id, branch_code, product_id, current_quantity, updated_at)
                                          VALUES ('binv_' || lower(hex(randomblob(6))), ?, ?, 0, datetime('now'))");
                // The same rule the live endpoint applies: with negative stock switched off,
                // taking the shelf below zero is part of the UPDATE, not a promise made
                // earlier. This path used to deduct unconditionally, so a waybill typed while
                // the cable was out emptied a branch the shop had forbidden it to empty.
                $trfDeductGuard = ($allowNegativeStock === 0) ? " AND current_quantity >= ?" : "";
                $deductStmt = $db->prepare("UPDATE branch_inventory SET
                                            current_quantity = current_quantity - ?,
                                            updated_at = datetime('now')
                                            WHERE branch_code = ? AND product_id = ?{$trfDeductGuard}");
                $addStmt = $db->prepare("UPDATE branch_inventory SET
                                         current_quantity = current_quantity + ?,
                                         updated_at = datetime('now')
                                         WHERE branch_code = ? AND product_id = ?");
                $mvtStmt = $db->prepare("INSERT INTO inventory_movements (id, product_id, movement_type, quantity, reference_id, unit_price, notes, created_by, branch_code, created_at)
                                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))");

                foreach ($offlineTransfers as $trf) {
                    $tid = trim($trf['id'] ?? '');
                    if (empty($tid)) continue;
                    $trfCheck->execute([$tid]);
                    if (!$trfCheck->fetch()) {
                        $spTrf = 'sp_trf_' . substr(preg_replace('/[^A-Za-z0-9_]/', '', $tid), 0, 16);
                        $db->exec("SAVEPOINT {$spTrf}");
                        try {
                            $srcB = strtoupper(trim($trf['source_branch'] ?? 'MAIN-01'));
                            $destB = strtoupper(trim($trf['destination_branch'] ?? ''));
                            if ($srcB === $destB || $destB === '') {
                                $db->exec("RELEASE SAVEPOINT {$spTrf}");
                                $processedTransferIds[] = $tid;
                                $totalProcessed++;
                                continue;
                            }
                            $trfNum = $trf['transfer_number'] ?? ('TRF-' . date('YmdHis') . '-' . strtoupper(bin2hex(random_bytes(2))));
                            $notes = trim((string)($trf['notes'] ?? ''));

                            // Resolved by the same reader the live endpoint uses, so a crate
                            // queued offline is still thirty bottles when it lands - and a
                            // size the shop does not stock is refused here exactly as it would
                            // be refused at a counter that had a server to ask.
                            $plan = sfTransferPlan($db, $trf['items'] ?? []);
                            if ($plan['error'] !== null) throw new RuntimeException($plan['error']);
                            if ($plan['lines'] === []) throw new RuntimeException('no line on this waybill names a product the catalogue still carries');

                            foreach ($plan['byProduct'] as $pid => $baseQty) {
                                $trfStockCheck->execute([$srcB, $pid]);
                                $srcQty = floatval($trfStockCheck->fetchColumn() ?: 0.0);
                                if ($allowNegativeStock === 0 && $srcQty < $baseQty) {
                                    throw new RuntimeException("{$srcB} holds {$srcQty} and the waybill asks for {$baseQty}");
                                }
                            }

                            $trfInsert->execute([
                                $tid, $trfNum, $srcB, $destB,
                                count($plan['byProduct']), array_sum($plan['byProduct']),
                                $notes, intval($authUser['id'] ?? 1),
                                $trf['created_at'] ?? date('Y-m-d H:i:s'),
                                $trf['updated_at'] ?? date('Y-m-d H:i:s')
                            ]);

                            foreach ($plan['lines'] as $line) {
                                $pId = $line['product_id'];
                                $moved = $line['base_quantity'];
                                $cp = $line['cost_price'];
                                $sizeNote = $line['quantity'] . ' ' . ($line['unit'] !== '' ? $line['unit'] : 'unit')
                                    . ($line['multiplier'] > 1 ? ' (' . $moved . ' ' . ($line['base_unit'] !== '' ? $line['base_unit'] : 'base') . ')' : '');

                                $tiInsert->execute(['ti_' . bin2hex(random_bytes(6)), $tid, $pId,
                                    $line['quantity'], $cp, $line['unit'], $line['multiplier'], $moved]);

                                $binvInit->execute([$srcB, $pId]);
                                $deductParams = [$moved, $srcB, $pId];
                                if ($trfDeductGuard !== '') $deductParams[] = $moved;
                                $deductStmt->execute($deductParams);
                                if ($trfDeductGuard !== '' && $deductStmt->rowCount() === 0) {
                                    throw new RuntimeException("{$srcB} did not hold {$moved} for {$line['name']} when the waybill arrived");
                                }

                                $binvInit->execute([$destB, $pId]);
                                $addStmt->execute([$moved, $destB, $pId]);
                                $mvtStmt->execute(['mvt_' . bin2hex(random_bytes(6)), $pId, 'TRANSFER_OUT', -$moved, $trfNum, $cp, "Transferred out to {$destB}: {$sizeNote}", $authUser['id'] ?? 1, $srcB]);
                                $mvtStmt->execute(['mvt_' . bin2hex(random_bytes(6)), $pId, 'TRANSFER_IN', $moved, $trfNum, $cp, "Transferred in from {$srcB}: {$sizeNote}", $authUser['id'] ?? 1, $destB]);
                            }
                            logActivity($db, intval($authUser['id'] ?? 1), $authUser['full_name'] ?? 'Staff', $authUser['role_name'] ?? 'Staff', 'TRANSFER_SYNC', "Synced stock transfer {$trfNum} ({$srcB} -> {$destB}, " . count($plan['byProduct']) . " products, " . array_sum($plan['byProduct']) . " base units).");
                            $db->exec("RELEASE SAVEPOINT {$spTrf}");
                        } catch (Throwable $te) {
                            // Stays in the till's outbox and is quarantined there, rather than
                            // being marked synced and dropped on the floor.
                            $db->exec("ROLLBACK TO SAVEPOINT {$spTrf}");
                            $db->exec("RELEASE SAVEPOINT {$spTrf}");
                            error_log("Sync: Rejected offline transfer {$tid}: " . $te->getMessage());
                            $rejectedIds['transfers'][] = $tid;
                            continue;
                        }
                    }
                    $processedTransferIds[] = $tid;
                    $totalProcessed++;
                }
            } else {
                error_log("Sync: User " . ($authUser['id'] ?? 'unknown') . " lacked permission to sync transfers.");
            }
        }

        // 7c. Process Offline Sales Returns
        $offlineReturns = normalizeSyncList($data['returns'] ?? $data['sales_returns'] ?? []);
        $processedReturnIds = [];
        if (!empty($offlineReturns) && is_array($offlineReturns)) {
            $retCheck = $db->prepare("SELECT id FROM sales_returns WHERE id = ?");
            $retInsert = $db->prepare("INSERT INTO sales_returns (
                id, return_number, sale_id, receipt_number, customer_id, customer_name,
                user_id, cashier_name, terminal_id, branch_code, total_refund_amount,
                refund_gross, refund_discount_share, refund_tax_share,
                refund_method, return_date, reason, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $retItemInsert = $db->prepare("INSERT INTO sales_return_items (
                id, return_id, product_id, product_name, quantity, unit, multiplier, base_quantity,
                unit_price, refund_subtotal, item_condition, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $invRestock = $db->prepare("UPDATE inventory SET current_quantity = current_quantity + ?, updated_at = datetime('now') WHERE product_id = ?");
            $binvRestock = $db->prepare("INSERT INTO branch_inventory (id, branch_code, product_id, current_quantity, updated_at)
                                         VALUES (?, ?, ?, ?, datetime('now'))
                                         ON CONFLICT(branch_code, product_id) DO UPDATE SET
                                         current_quantity = current_quantity + excluded.current_quantity,
                                         updated_at = datetime('now')");
            // Same CAST as returns.php: an unqualified `>= ?` compares a computed number
            // against a bound TEXT value, and SQLite puts every number below every text -
            // the guard would reject the first honest credit note as well as a forged one.
            $saleUpd = $db->prepare("UPDATE sales 
                                     SET refunded_amount = COALESCE(refunded_amount, 0) + CAST(? AS REAL),
                                         status = CASE 
                                             WHEN (total_amount - (COALESCE(refunded_amount, 0) + CAST(? AS REAL))) <= 0.01 THEN 'REFUNDED' 
                                             ELSE 'PARTIALLY_REFUNDED' 
                                         END,
                                         updated_at = datetime('now')
                                     WHERE id = ?
                                       AND status <> 'VOID'
                                       AND (total_amount - COALESCE(refunded_amount, 0)) >= CAST(? AS REAL) - 0.01");
            // The offline till states what it refunded; the server decides what it can afford to
            // refund. Sold quantities, line prices and earlier credit notes all come from the
            // database, so a hand-edited outbox row cannot mint money or stock. The three top-of-
            // receipt figures are here for the same reason: the share of discount and tax a credit
            // note may claim is read off the sale, never off the outbox.
            $retSaleStmt = $db->prepare("SELECT id, receipt_number, subtotal, discount, tax, total_amount,
                                         COALESCE(refunded_amount, 0) AS refunded_amount, branch_code, status
                                         FROM sales WHERE id = ?");
            // The size each line was sold in, because "1" on a synced credit note means one egg
            // on one receipt and one box of 420 on another, and the shelf is counted in neither.
            $soldLineStmt = $db->prepare("SELECT product_id, quantity, unit_selling_price, unit, multiplier, base_quantity, batch_id
                                          FROM sale_items WHERE sale_id = ?");
            $prevRetStmt = $db->prepare("SELECT sri.product_id, sri.unit, SUM(sri.quantity) AS returned_qty
                                         FROM sales_return_items sri
                                         JOIN sales_returns sr ON sri.return_id = sr.id
                                         WHERE sr.sale_id = ?
                                         GROUP BY sri.product_id, sri.unit");
            // The restock belongs in the expiry ledger and the movement history too. An offline
            // counter drains a lot through the synced sale above; a credit note that puts the
            // goods back and updates neither leaves the shop writing off stock it has already
            // taken back, and leaves a shelf movement no report can account for.
            $retBatchCreditStmt = $db->prepare("UPDATE product_batches SET current_quantity = current_quantity + ?, updated_at = datetime('now')
                                               WHERE id = ? AND branch_code = ? AND status = 'ACTIVE'");
            $retMvtStmt = $db->prepare("INSERT INTO inventory_movements (id, product_id, movement_type, quantity, reference_id, unit_price, notes, branch_code, created_at)
                                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))");

            $rIdx = 0;
            foreach ($offlineReturns as $ret) {
                $rid = trim($ret['id'] ?? '');
                if (empty($rid)) continue;
                $rIdx++;
                $spRet = 'sp_ret_' . $rIdx;

                $db->exec("SAVEPOINT {$spRet}");
                try {
                    $retCheck->execute([$rid]);
                    if (!$retCheck->fetch()) {
                        $origSaleId = trim($ret['sale_id'] ?? '');

                        $retSaleStmt->execute([$origSaleId]);
                        $rsale = $retSaleStmt->fetch(PDO::FETCH_ASSOC);
                        if (!$rsale) {
                            // A credit note for a receipt the server never saw cannot be booked.
                            // It is marked processed so it does not replay on every sync forever.
                            error_log("Sync: Dropped return {$rid} - original sale '{$origSaleId}' is not on this server.");
                            logActivity($db, intval($authUser['id'] ?? 1), $authUser['full_name'] ?? 'Staff', $authUser['role_name'] ?? 'Staff', 'SYNC_RETURN_REJECTED', "Offline return {$rid} rejected: receipt " . ($ret['receipt_number'] ?? $origSaleId) . " unknown on the server.");
                            $db->exec("RELEASE SAVEPOINT {$spRet}");
                            $processedReturnIds[] = $rid;
                            continue;
                        }

                        // A receipt cleared at the depot took its goods back and booked nothing, so
                        // the slip the till queued against it cannot be booked either: it would
                        // restock the same units a second time and pay cash out on a sale that never
                        // took money in. Dropped rather than quarantined, because a void does not
                        // turn back into a live sale - but written to the audit trail first, since
                        // the counter did hand this customer money and the shift count has to be
                        // able to find out where it went.
                        if (strtoupper(trim((string)($rsale['status'] ?? ''))) === 'VOID') {
                            error_log("Sync: Dropped return {$rid} - receipt {$origSaleId} is voided.");
                            logActivity($db, intval($authUser['id'] ?? 1), $authUser['full_name'] ?? 'Staff', $authUser['role_name'] ?? 'Staff', 'SYNC_RETURN_REJECTED', "Offline return " . ($ret['return_number'] ?? $rid) . " refused: receipt #" . (trim((string)($rsale['receipt_number'] ?? '')) !== '' ? $rsale['receipt_number'] : $origSaleId) . " was voided, so its goods went back with it and it booked nothing. The GH₵" . number_format(round(floatval($ret['total_refund_amount'] ?? 0), 2), 2) . " the till refunded is not on the book - settle it at the counter or take the goods back as a fresh return.");
                            $db->exec("RELEASE SAVEPOINT {$spRet}");
                            $processedReturnIds[] = $rid;
                            continue;
                        }

                        $refundableValue = round(max(0, floatval($rsale['total_amount']) - floatval($rsale['refunded_amount'])), 2);
                        if ($refundableValue <= 0.01) {
                            error_log("Sync: Dropped return {$rid} - receipt {$origSaleId} already fully refunded.");
                            $db->exec("RELEASE SAVEPOINT {$spRet}");
                            $processedReturnIds[] = $rid;
                            continue;
                        }

                        $soldQtyMap = [];
                        $linePriceMap = [];
                        $soldBaseMap = [];
                        $keyQtyMap = [];
                        $keyBaseMap = [];
                        $keyPriceMap = [];
                        $sizesByProd = [];
                        $lotMap = [];
                        $soldLineStmt->execute([$origSaleId]);
                        while ($sl = $soldLineStmt->fetch(PDO::FETCH_ASSOC)) {
                            $sp = $sl['product_id'];
                            $sQty = floatval($sl['quantity']);
                            $sMult = max(1.0, round(floatval($sl['multiplier'] ?? 1), 4));
                            $sBase = floatval($sl['base_quantity'] ?? 0);
                            if ($sBase <= 0) $sBase = $sQty * $sMult;
                            $sLabel = trim((string)($sl['unit'] ?? ''));
                            $sKey = sfUnitKey((string)$sp, $sLabel);
                            $soldQtyMap[$sp] = ($soldQtyMap[$sp] ?? 0) + $sQty;
                            $soldBaseMap[$sp] = ($soldBaseMap[$sp] ?? 0) + $sBase;
                            $keyQtyMap[$sKey] = ($keyQtyMap[$sKey] ?? 0) + $sQty;
                            $keyBaseMap[$sKey] = ($keyBaseMap[$sKey] ?? 0) + $sBase;
                            $keyPriceMap[$sKey] = max($keyPriceMap[$sKey] ?? 0, round(floatval($sl['unit_selling_price']), 2));
                            $sizesByProd[$sp][$sKey] = $sLabel;
                            $linePriceMap[$sp] = max($linePriceMap[$sp] ?? 0, round(floatval($sl['unit_selling_price']), 2));
                            if (!empty($sl['batch_id'])) {
                                $lotMap[$sp][] = ['id' => $sl['batch_id'], 'units' => $sBase];
                            }
                        }

                        $alreadyReturnedMap = [];
                        $returnedByKey = [];
                        $returnedNoSize = [];
                        $prevRetStmt->execute([$origSaleId]);
                        while ($pr = $prevRetStmt->fetch(PDO::FETCH_ASSOC)) {
                            $prQty = floatval($pr['returned_qty']);
                            $alreadyReturnedMap[$pr['product_id']] = ($alreadyReturnedMap[$pr['product_id']] ?? 0) + $prQty;
                            $prLabel = trim((string)($pr['unit'] ?? ''));
                            if ($prLabel === '') {
                                $returnedNoSize[$pr['product_id']] = ($returnedNoSize[$pr['product_id']] ?? 0) + $prQty;
                            } else {
                                $prKey = sfUnitKey((string)$pr['product_id'], $prLabel);
                                $returnedByKey[$prKey] = ($returnedByKey[$prKey] ?? 0) + $prQty;
                            }
                        }

                        // What the receipt had already given back before this slip, which the loop
                        // below overwrites as it goes. The remainder rule needs the position at the
                        // start, not the position after the same slip has been counted once.
                        $returnedByKeyBefore = $returnedByKey;

                        // Branch decides which shelf is restocked, so it is not the caller's to pick.
                        $retBranch = strtoupper(trim($ret['branch_code'] ?? ''));
                        if ($retBranch === '' || $retBranch === 'ALL') $retBranch = strtoupper(trim($rsale['branch_code'] ?? 'MAIN-01')) ?: 'MAIN-01';
                        $sessionBranch = strtoupper(trim($authUser['branch_code'] ?? 'MAIN-01'));
                        $isSuperUser = strtolower(trim($authUser['role_name'] ?? '')) === 'administrator' || intval($authUser['role_id'] ?? 0) === 1;
                        if (!$isSuperUser && $sessionBranch !== '' && $sessionBranch !== $retBranch) {
                            $retBranch = $sessionBranch;
                        }

                        // What a queued slip may load onto this receipt is its remaining line
                        // value, which is not its remaining cash: on a discounted receipt the two
                        // differ by the discount. Trimming the gross sum against the net refundable
                        // cut back goods the customer really handed back, and left a return of the
                        // whole receipt looking like a partial one - so it took its ordinary share
                        // instead of settling the residue, exactly as returns.php documents.
                        $leftGross = 0.0;
                        foreach ($keyPriceMap as $sizeKey => $price) {
                            $leftUnits = max(0, ($keyQtyMap[$sizeKey] ?? 0) - ($returnedByKeyBefore[$sizeKey] ?? 0));
                            $leftGross += $leftUnits * $price;
                        }
                        $leftGross = round($leftGross, 2);

                        $clampedItems = [];
                        $runningGross = 0.0;
                        if (!empty($ret['items']) && is_array($ret['items'])) {
                            foreach ($ret['items'] as $it) {
                                $rProdId = trim($it['product_id'] ?? '');
                                $rQty = round(floatval($it['quantity'] ?? 0), 2);
                                $rPrice = round(floatval($it['unit_price'] ?? 0), 2);
                                $rUnit = trim((string)($it['unit'] ?? ''));
                                $rCond = strtoupper(trim($it['item_condition'] ?? 'RESTOCK'));
                                if ($rCond !== 'RESTOCK' && $rCond !== 'DAMAGED') $rCond = 'RESTOCK';

                                if ($rProdId === '' || $rQty <= 0) continue;

                                // Which size the till meant. A name that matches a line wins;
                                // anything else - no name, a renamed size, a receipt written
                                // before sizing arrived - falls back to the product as a whole,
                                // because a paid-for refund is corrected here, not refused.
                                $rKey = null;
                                if ($rUnit !== '') {
                                    $candidate = sfUnitKey($rProdId, $rUnit);
                                    if (isset($keyQtyMap[$candidate])) {
                                        $rKey = $candidate;
                                    } elseif (count($sizesByProd[$rProdId] ?? []) === 1) {
                                        $rKey = array_key_first($sizesByProd[$rProdId]);
                                    }
                                }
                                $soldUnits = $rKey !== null ? ($keyQtyMap[$rKey] ?? 0) : ($soldQtyMap[$rProdId] ?? 0);
                                $soldBase = $rKey !== null ? ($keyBaseMap[$rKey] ?? 0) : ($soldBaseMap[$rProdId] ?? $soldUnits);
                                $alreadyRet = $rKey !== null
                                    ? ($returnedByKey[$rKey] ?? 0) + ($returnedNoSize[$rProdId] ?? 0)
                                    : ($alreadyReturnedMap[$rProdId] ?? 0);
                                $rLabel = $rKey !== null ? (string)($sizesByProd[$rProdId][$rKey] ?? $rUnit) : '';

                                $returnable = max(0, $soldUnits - $alreadyRet);
                                if ($returnable <= 0) {
                                    error_log("Sync: Return {$rid} asked for {$rProdId}" . ($rLabel !== '' ? " in a '{$rLabel}'" : '') . " which has nothing left returnable on sale {$origSaleId}; line skipped.");
                                    continue;
                                }
                                $ceilingPrice = $rKey !== null ? ($keyPriceMap[$rKey] ?? 0) : ($linePriceMap[$rProdId] ?? 0);
                                if ($rPrice > $ceilingPrice) {
                                    error_log("Sync: Return {$rid} priced {$rProdId} at {$rPrice}, above the {$ceilingPrice} charged; using the charged price.");
                                    $rPrice = $ceilingPrice;
                                }

                                if ($rQty > $returnable) {
                                    error_log("Sync: Return {$rid} capped {$rProdId} from {$rQty} to {$returnable} unit(s) actually returnable.");
                                    $rQty = $returnable;
                                }

                                $grossHeadroom = round($leftGross - $runningGross, 2);
                                if ($grossHeadroom <= 0.01) {
                                    error_log("Sync: Return {$rid} truncated - receipt {$origSaleId} has no line value left on it.");
                                    break;
                                }

                                $rSubtotal = round($rQty * $rPrice, 2);
                                if ($rSubtotal > $grossHeadroom) {
                                    error_log("Sync: Return {$rid} asked for {$rProdId} worth more than the {$grossHeadroom} of goods left on receipt {$origSaleId}.");
                                    $rSubtotal = $grossHeadroom;
                                    $rQty = $rPrice > 0 ? round($rSubtotal / $rPrice, 2) : 0;
                                    if ($rQty <= 0) break;
                                }

                                // The shelf counts loose units, and a restock written as the
                                // ordered number put one bottle back for a crate taken out.
                                $ratio = $soldUnits > 0 ? $soldBase / $soldUnits : 1.0;
                                $rBaseQty = round($rQty * $ratio, 4);

                                $runningGross = round($runningGross + $rSubtotal, 2);
                                if ($rKey !== null) {
                                    $returnedByKey[$rKey] = ($returnedByKey[$rKey] ?? 0) + $rQty;
                                }
                                $alreadyReturnedMap[$rProdId] = ($alreadyReturnedMap[$rProdId] ?? 0) + $rQty;

                                $clampedItems[] = [
                                    'product_id' => $rProdId,
                                    'product_name' => $it['product_name'] ?? 'Item',
                                    'quantity' => $rQty,
                                    'unit' => $rLabel,
                                    'multiplier' => round($ratio, 4),
                                    'base_quantity' => $rBaseQty,
                                    'unit_price' => $rPrice,
                                    'refund_subtotal' => $rSubtotal,
                                    'item_condition' => $rCond,
                                ];
                            }
                        }

                        if (empty($clampedItems)) {
                            error_log("Sync: Dropped return {$rid} - nothing on it could be booked against sale {$origSaleId}.");
                            $db->exec("RELEASE SAVEPOINT {$spRet}");
                            $processedReturnIds[] = $rid;
                            continue;
                        }

                        // What the lines were worth is not what the customer paid for them: the
                        // receipt was taxed and discounted once, at the top, and this slip takes
                        // its share of both - see saleRefundSplit(). Paying the bare line total
                        // shorted every offline credit note on a taxed receipt by its tax and left
                        // the sale at PARTIAL_REFUNDED owing a residue no future line could claim.
                        $grossRefund = round($runningGross, 2);
                        $emptiesReceipt = abs($leftGross - $grossRefund) <= 0.01;
                        $split = saleRefundSplit($rsale, $grossRefund, $refundableValue, $emptiesReceipt);
                        $totRef = $split['refund'];
                        $claimedRef = round(floatval($ret['total_refund_amount'] ?? 0), 2);
                        if ($claimedRef > 0 && abs($claimedRef - $totRef) > 0.01) {
                            error_log("Sync: Return {$rid} booked at {$totRef}, not the {$claimedRef} the till claimed.");
                        }

                        $retNumber = $ret['return_number'] ?? ('RET-' . date('Ymd') . '-' . rand(1000, 9999));
                        $retInsert->execute([
                            $rid,
                            $retNumber,
                            $origSaleId,
                            $ret['receipt_number'] ?? '',
                            $ret['customer_id'] ?? 'cust-walkin',
                            $ret['customer_name'] ?? 'Walk-in Customer',
                            intval($authUser['id'] ?? 1),
                            $ret['cashier_name'] ?? $authUser['full_name'] ?? 'Cashier',
                            $ret['terminal_id'] ?? 'REG-01',
                            $retBranch,
                            $totRef,
                            $split['gross'],
                            $split['discount_share'],
                            $split['tax_share'],
                            $ret['refund_method'] ?? 'CASH',
                            $ret['return_date'] ?? date('Y-m-d H:i:s'),
                            $ret['reason'] ?? 'Customer item return',
                            $ret['created_at'] ?? date('Y-m-d H:i:s')
                        ]);

                        foreach ($clampedItems as $cItem) {
                            $retItemInsert->execute([
                                'ri_' . bin2hex(random_bytes(6)),
                                $rid,
                                $cItem['product_id'],
                                $cItem['product_name'],
                                $cItem['quantity'],
                                $cItem['unit'],
                                $cItem['multiplier'],
                                $cItem['base_quantity'],
                                $cItem['unit_price'],
                                $cItem['refund_subtotal'],
                                $cItem['item_condition'],
                                date('Y-m-d H:i:s')
                            ]);

                            $retProdId = $cItem['product_id'];
                            $retBaseQty = $cItem['base_quantity'];
                            if ($cItem['item_condition'] === 'RESTOCK') {
                                $invRestock->execute([$retBaseQty, $retProdId]);
                                $binvRestock->execute(['binv_' . bin2hex(random_bytes(6)), $retBranch, $retProdId, $retBaseQty]);

                                // The lot the receipt drew from gets its units back while it is
                                // still ACTIVE; reviving a depleted one would put an expired lot
                                // back at the front of the first-expiry-out queue.
                                $toCredit = $retBaseQty;
                                foreach ($lotMap[$retProdId] ?? [] as $i => $lot) {
                                    if ($toCredit <= 0.0001 || $lot['units'] <= 0) continue;
                                    $credit = min($toCredit, $lot['units']);
                                    $lotMap[$retProdId][$i]['units'] -= $credit;
                                    $toCredit -= $credit;
                                    $retBatchCreditStmt->execute([$credit, $lot['id'], $retBranch]);
                                    if ($retBatchCreditStmt->rowCount() === 0) {
                                        error_log("Sync: Return {$retNumber}: {$credit} units of '{$cItem['product_name']}' went back to the shelf, but lot {$lot['id']} is no longer saleable.");
                                    }
                                }
                            }

                            $retMvtStmt->execute([
                                'mvt_' . bin2hex(random_bytes(6)),
                                $retProdId,
                                $cItem['item_condition'] === 'RESTOCK' ? 'RETURN_RESTOCK' : 'RETURN_DAMAGED',
                                $cItem['item_condition'] === 'RESTOCK' ? $retBaseQty : 0,
                                $retNumber,
                                $cItem['item_condition'] === 'RESTOCK'
                                    ? round($cItem['refund_subtotal'] / max(0.0001, $retBaseQty), 4)
                                    : $cItem['unit_price'],
                                ($cItem['item_condition'] === 'RESTOCK' ? 'Customer Return (Resellable)' : 'Customer Return (Damaged/Defective)')
                                    . ": Orig Sale #{$origSaleId}",
                                $retBranch
                            ]);
                        }

                        if ($origSaleId && $totRef > 0) {
                            $saleUpd->execute([$totRef, $totRef, $origSaleId, $totRef]);
                            if ($saleUpd->rowCount() === 0) {
                                throw new Exception("Receipt {$origSaleId} had no refund value left when the credit note was booked.");
                            }
                            // The points follow the goods back, on the same rule the counter answers
                            // by: the share is read off what the receipt now shows as refunded, so a
                            // note that queued beside two others still comes to the right third and
                            // this replay cannot trim the member a second time. A till that rang the
                            // return offline would otherwise leave the member holding points on goods
                            // that are back on the shelf by the time the book sees the slip.
                            $loyaltyBack = StoreFlowLoyalty::reverseLoyaltyForReturns(
                                $db, (string)$origSaleId, intval($authUser['id'] ?? 1), (string)$retBranch
                            );
                        } else {
                            $loyaltyBack = ['reversed' => false];
                        }
                        logActivity($db, intval($authUser['id'] ?? 1), $authUser['full_name'] ?? 'Cashier', $authUser['role_name'] ?? 'Cashier', 'RETURN_SYNC', "Synced sales return " . ($ret['return_number'] ?? $rid) . " for receipt #" . ($ret['receipt_number'] ?? '')
                            . " (Refund: {$totRef}, Method: " . ($ret['refund_method'] ?? 'CASH') . ")"
                            . " = {$split['gross']} of goods less {$split['discount_share']} share of the receipt discount"
                            . " plus {$split['tax_share']} share of its tax."
                            . (!empty($loyaltyBack['reversed']) ? " Points: " . number_format($loyaltyBack['change'], 2)
                                . " moved on the member's balance - " . number_format($loyaltyBack['taken'], 2)
                                . " of what the receipt earned now stand taken, balance "
                                . number_format($loyaltyBack['balance'], 2) . '.' : ''));
                    }
                    $db->exec("RELEASE SAVEPOINT {$spRet}");
                    $processedReturnIds[] = $rid;
                    $totalProcessed++;
                } catch (Throwable $re) {
                    $db->exec("ROLLBACK TO SAVEPOINT {$spRet}");
                    $db->exec("RELEASE SAVEPOINT {$spRet}");
                    error_log("Sync: Rejected offline return {$rid}: " . $re->getMessage());
                    $rejectedIds['returns'][] = $rid;
                }
            }
        }

        // 9. Process Offline Expenses & Cash Drawer Payouts
        $offlineExpenses = normalizeSyncList($data['expenses'] ?? []);
        $processedExpenseIds = [];
        if (!empty($offlineExpenses) && is_array($offlineExpenses)) {
            $expCheck = $db->prepare("SELECT id FROM expenses WHERE id = ?");
            $expInsert = $db->prepare("INSERT INTO expenses (
                id, expense_number, title, category, amount, payment_source, paid_to, 
                receipt_ref, notes, branch_code, terminal_id, shift_id, user_id, 
                recorded_by, expense_date, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            $eIdx = 0;
            foreach ($offlineExpenses as $exp) {
                $eid = trim($exp['id'] ?? '');
                if (empty($eid)) continue;
                $eIdx++;
                $spExp = 'sp_exp_' . $eIdx;
                $db->exec("SAVEPOINT {$spExp}");
                try {
                    $expCheck->execute([$eid]);
                    if (!$expCheck->fetch()) {
                        // Who spent it, where and when are decided from the session and
                        // the shop's clock, as they are online. `recorded_by` and
                        // `user_id` from the body let one till post spending against a
                        // colleague, and a negative amount subtracts from the shop's
                        // expenses instead of adding to them.
                        $expAmount = round(floatval($exp['amount'] ?? 0), 2);
                        if ($expAmount <= 0) {
                            throw new RuntimeException('expense amount must be greater than zero');
                        }
                        $expBranch = strtoupper(trim((string)($exp['branch_code'] ?? ''))) ?: 'MAIN-01';
                        if (!$isSuperUser) {
                            $expBranch = strtoupper(trim((string)($authUser['branch_code'] ?? 'MAIN-01'))) ?: 'MAIN-01';
                        }
                        $expWhen = trim((string)($exp['expense_date'] ?? date('Y-m-d')));
                        $expEpoch = strtotime($expWhen);
                        if ($expEpoch === false || $expEpoch > time() + 120) {
                            $expWhen = date('Y-m-d');
                        }
                        $expUser = max(1, intval($authUser['id'] ?? 1));
                        $expInsert->execute([
                            $eid,
                            $exp['expense_number'] ?? ('EXP-' . date('Ymd') . '-' . rand(1000, 9999)),
                            $exp['title'] ?? 'Store Expense',
                            $exp['category'] ?? 'General',
                            $expAmount,
                            $exp['payment_source'] ?? 'CASH_DRAWER',
                            $exp['paid_to'] ?? '',
                            $exp['receipt_ref'] ?? '',
                            $exp['notes'] ?? '',
                            $expBranch,
                            $exp['terminal_id'] ?? 'REG-01',
                            $exp['shift_id'] ?? null,
                            $expUser,
                            $authUser['full_name'] ?? 'Staff',
                            $expWhen,
                            $exp['created_at'] ?? date('Y-m-d H:i:s')
                        ]);
                        logActivity($db, $expUser, $authUser['full_name'] ?? 'Staff', $authUser['role_name'] ?? 'Staff', 'EXPENSE_SYNC', "Synced expense #" . ($exp['expense_number'] ?? $eid) . " (" . ($exp['category'] ?? 'General') . ": " . $expAmount . "). Paid to: " . ($exp['paid_to'] ?? '') . ".");
                    }
                    $db->exec("RELEASE SAVEPOINT {$spExp}");
                    $processedExpenseIds[] = $eid;
                } catch (Throwable $ee) {
                    $db->exec("ROLLBACK TO SAVEPOINT {$spExp}");
                    $db->exec("RELEASE SAVEPOINT {$spExp}");
                    error_log("Sync: Rejected offline expense {$eid}: " . $ee->getMessage());
                    $rejectedIds['expenses'][] = $eid;
                }
            }
        }

        // 9b. Process Offline Register Shifts
        //
        // Last of the money loops on purpose, after every row that changes the sum. A close is arithmetic
        // over the day it closed - the credit notes and the petty cash that batch queued with it:
        // a till that refunded or paid out cash offline and synced the shift before those rows
        // reached the book would be told its level drawer was short, because what came out of the
        // box is read off the book, never taken from what the till typed.
        if (!empty($offlineShifts) && is_array($offlineShifts)) {
            $shiftCheck = $db->prepare("SELECT id FROM register_shifts WHERE id = ?");
            $shiftInsert = $db->prepare("INSERT INTO register_shifts (
                id, shift_number, user_id, cashier_name, role_name, terminal_id, branch_code,
                shift_date, shift_time, opening_float, total_transactions, total_sales_gross, 
                voided_count, voided_value,
                cash_sales, card_sales, transfer_sales, credit_sales, debt_cash_collected,
                drawer_expenses, cash_refunds_paid, expected_cash, counted_cash, variance, notes, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            // shift_number is UNIQUE on the table, and this loop used to be the only money loop
            // in the sync with no savepoint of its own. A till that closed two shifts under the
            // same number therefore threw on the second row, and the throw reached the outer
            // catch, which rolled the whole request back: that terminal's sales, settlements,
            // expenses and count-ins stopped reaching the shop's books on every pass after it,
            // with a green "synced" on the counter.
            $numberTaken = $db->prepare("SELECT 1 FROM register_shifts WHERE shift_number = ?");
            $shiftIdx = 0;
            foreach ($offlineShifts as $sh) {
                $shid = trim($sh['id'] ?? '');
                if (empty($shid)) continue;
                $shiftIdx++;

                $spShift = 'sp_sh_' . $shiftIdx;
                $db->exec("SAVEPOINT {$spShift}");
                try {
                    $shiftCheck->execute([$shid]);
                    if (!$shiftCheck->fetch()) {
                        // A shift is the record of who was answerable for a drawer, so the
                        // officer comes from the session that synced it - as it does for
                        // sales - and not from the body. A till could open a shift on a
                        // colleague's name and leave the variance on their tab.
                        $shUser = max(1, intval($authUser['id'] ?? 1));
                        $shBranch = strtoupper(trim((string)($sh['branch_code'] ?? ''))) ?: 'MAIN-01';
                        if (!$isSuperUser) {
                            $shBranch = strtoupper(trim((string)($authUser['branch_code'] ?? 'MAIN-01'))) ?: 'MAIN-01';
                        }

                        $shNumber = trim((string)($sh['shift_number'] ?? ''));
                        if ($shNumber === '') {
                            $shNumber = 'SHIFT-' . date('Ymd') . '-' . substr(sha1($shid), 0, 6);
                        }
                        $numberTaken->execute([$shNumber]);
                        if ($numberTaken->fetchColumn() !== false) {
                            // Somebody else already owns that slip of paper. The number is a
                            // label, not the money: keep the close and mark the label.
                            $shNumber .= '-T' . substr(sha1($shid), 0, 4);
                        }

                        $shTerm = strtoupper(trim((string)($sh['terminal_id'] ?? ''))) ?: 'REG-01';
                        $shDate = substr(trim((string)($sh['shift_date'] ?? '')), 0, 10) ?: date('Y-m-d');
                        $sh['shift_date'] = $shDate;

                        // Same read as shifts.php: the cash the till handed back over credit notes
                        // comes off the box, and the book says how much of it there was. So does the
                        // petty cash it paid out - and that one matters more, because an expense the
                        // till makes up does not explain a shortage, it forgives one.
                        $sh['cash_refunds_paid'] = shiftCashRefundsPaid($db, $shTerm, $shBranch, $shDate);
                        $sh['drawer_expenses'] = shiftDrawerExpensesPaid($db, $shTerm, $shBranch, $shDate);

                        $figures = shiftFigures($sh);
                        $shiftInsert->execute([
                            $shid,
                            $shNumber,
                            $shUser,
                            $authUser['full_name'] ?? 'Cashier',
                            $authUser['role_name'] ?? 'Cashier',
                            $shTerm,
                            $shBranch,
                            $shDate,
                            $sh['shift_time'] ?? date('H:i:s'),
                            $figures['opening_float'],
                            intval($sh['total_transactions'] ?? 0),
                            round(floatval($sh['total_sales_gross'] ?? 0), 2),
                            $figures['voided_count'],
                            $figures['voided_value'],
                            $figures['cash_sales'],
                            round(floatval($sh['card_sales'] ?? 0), 2),
                            round(floatval($sh['transfer_sales'] ?? 0), 2),
                            round(floatval($sh['credit_sales'] ?? 0), 2),
                            $figures['debt_cash_collected'],
                            $figures['drawer_expenses'],
                            $figures['cash_refunds_paid'],
                            $figures['expected_cash'],
                            $figures['counted_cash'],
                            $figures['variance'],
                            $sh['notes'] ?? '',
                            $sh['created_at'] ?? date('Y-m-d H:i:s')
                        ]);
                        logActivity($db, $shUser, $authUser['full_name'] ?? 'Cashier', $authUser['role_name'] ?? 'Cashier', 'SHIFT_SYNC', "Synced register shift {$shNumber} for terminal {$shTerm}. Expected: {$figures['expected_cash']}, Counted: {$figures['counted_cash']}, Variance: {$figures['variance']}."
                            . ($figures['cash_refunds_paid'] > 0.005 ? ' Cash handed back over credit notes, counted out of the drawer before the variance: GH₵' . number_format($figures['cash_refunds_paid'], 2) . '.' : ''));
                    }
                    $db->exec("RELEASE SAVEPOINT {$spShift}");
                    $processedShiftIds[] = $shid;
                    $totalProcessed++;
                } catch (Throwable $shiftEx) {
                    $db->exec("ROLLBACK TO SAVEPOINT {$spShift}");
                    $db->exec("RELEASE SAVEPOINT {$spShift}");
                    error_log("Sync: Rejected offline register shift {$shid}: " . $shiftEx->getMessage());
                    $rejectedIds['shifts'][] = $shid;
                }
            }
        }

        // Log the sync event
        $logStmt = $db->prepare("INSERT INTO sync_log (client_sync_id, records_received, records_sent, status, details, created_at) VALUES (?, ?, ?, 'SUCCESS', ?, datetime('now'))");
        $logStmt->execute([$syncId, $totalProcessed, 0, "Processed: " . count($processedSaleIds) . " sales, " . count($processedPurchaseIds) . " purchases, " . count($processedPaymentIds) . " payments, " . count($processedShiftIds) . " shifts, " . count($processedLogIds) . " logs"]);

        $db->commit();

        // Fetch fresh state to send back to client
        $prodStmt = $db->query("SELECT p.*, COALESCE(inv.current_quantity, 0) as current_quantity FROM products p LEFT JOIN inventory inv ON p.id = inv.product_id WHERE p.is_active = 1 ORDER BY p.name ASC");
        $freshProducts = $prodStmt->fetchAll();

        $custStmt = $db->query("SELECT * FROM customers ORDER BY name ASC");
        $freshCustomers = $custStmt->fetchAll();

        $profStmt = $db->query("SELECT * FROM store_profile WHERE id = 1");
        // A full copy of store_profile sat in every sync response, which reached any
        // cashier: the mNotify provider key, the scanner pairing secret and the owner's
        // phone number. Same masking as profile.php, from the same shared helper.
        $freshProfile = $profStmt->fetch() ?: [];
        $freshProfile = maskProfileForClient($freshProfile, $authUser);

        $canSeeCost = maySeeProductCost($authUser);
        foreach ($freshProducts as &$fp) {
            if (!$canSeeCost) unset($fp['cost_price']);
        }
        unset($fp);

        $freshBranchInventory = $db->query("SELECT * FROM branch_inventory")->fetchAll();

        $branchStmt = $db->query("SELECT * FROM branches WHERE is_active = 1 ORDER BY name ASC");
        $freshBranches = $branchStmt->fetchAll();

        $trfStmt = $db->query("SELECT t.*, 
                                      COALESCE(b_src.name, t.source_branch) as source_branch_name, 
                                      COALESCE(b_dest.name, t.destination_branch) as destination_branch_name 
                               FROM stock_transfers t 
                               LEFT JOIN branches b_src ON t.source_branch = b_src.branch_code 
                               LEFT JOIN branches b_dest ON t.destination_branch = b_dest.branch_code 
                               ORDER BY t.created_at DESC LIMIT 50");
        $freshTransfers = $trfStmt->fetchAll();

        $batchStmt = $db->query("SELECT * FROM product_batches WHERE status != 'DEPLETED' ORDER BY expiry_date ASC");
        $freshBatches = $batchStmt->fetchAll();
        // The lot row carries what the shop paid for that batch. Products were stripped of
        // cost_price a few lines above and the batches were not, so the expiry board a
        // cashier can open named every lot's invoice price.
        foreach ($freshBatches as &$fb) {
            if (!$canSeeCost) unset($fb['cost_price']);
        }
        unset($fb);

        jsonResponse([
            'success' => true,
            'message' => 'Sync completed successfully',
            'sync_id' => $syncId,
            'book_epoch' => $serverEpoch,
            'processed' => [
                'sales' => $processedSaleIds,
                'purchases' => $processedPurchaseIds,
                'products' => $processedProductIds,
                'customers' => $processedCustomerIds,
                'payments' => $processedPaymentIds,
                'shifts' => $processedShiftIds,
                'transfers' => $processedTransferIds,
                'returns' => $processedReturnIds,
                'expenses' => $processedExpenseIds,
                'vendors' => $processedVendorIds,
                'vendor_payments' => $processedVendorPaymentIds,
                'purchase_movements' => $processedPurchaseMovementIds
            ],
            'rejected' => $rejectedIds,
            'purchase_errors' => $purchaseErrors,
            'server_state' => [
                'products' => $freshProducts,
                'customers' => $freshCustomers,
                'profile' => $freshProfile,
                'branches' => $freshBranches,
                'branch_inventory' => $freshBranchInventory,
                'transfers' => $freshTransfers,
                'batches' => $freshBatches,
                'synced_at' => date('Y-m-d H:i:s')
            ]
        ]);

    } catch (Throwable $e) {
        safeRollback($db);
        // Throwable, not Exception: a TypeError from one malformed field (an array where a
        // string was expected) is not an Exception, and used to leave the client with an
        // empty HTTP 500 and no explanation while the whole batch went unrecorded.
        error_log('Sync: batch failed: ' . $e->getMessage());
        jsonResponse(['success' => false, 'message' => 'Sync transaction failed: ' . $e->getMessage()], 500);
    }
}

// GET returns current sync status, latest database timestamp, or live delta changes
if ($method === 'GET') {
    $action = trim($_GET['action'] ?? '');

    // 1. Cross-Device Live Delta Polling (Ultra-Lightweight 5-Second Heartbeat)
    if ($action === 'delta') {
        // requireAuth() so this poll inherits the same forced-rotation and session
        // checks as the write paths, instead of accepting any unexpired cookie.
        $authUser = requireAuth();

        $since = trim($_GET['since'] ?? '');
        $rawBranch = trim($_GET['branch_code'] ?? ($authUser['branch_code'] ?? 'MAIN-01'));
        $branchCode = empty($rawBranch) ? 'MAIN-01' : $rawBranch;

        $now = $db->query("SELECT datetime('now')")->fetchColumn();

        // The book's name rides on the heartbeat as well as on a sync, because a till with an
        // empty queue never calls the sync endpoint at all - syncOutbox() returns first. This
        // poll is the only way such a counter learns which book it is standing in front of.
        $deltaEpoch = _sysBookEpoch($db);

        // If no baseline timestamp provided, return current server time as initial checkpoint
        if (empty($since) || $since === '0') {
            jsonResponse([
                'success' => true,
                'has_changes' => false,
                'server_time' => $now,
                'book_epoch' => $deltaEpoch,
                'changes' => []
            ]);
        }

        // Safety overlap: 5-second buffer to absorb sub-second clock drift & network transit.
        // Guard against future-skewed client timestamps (e.g. timezone mismatch / stale cache).
        $sinceEpoch = strtotime($since);
        $nowEpoch = strtotime($now);
        if ($sinceEpoch === false || $sinceEpoch > $nowEpoch) {
            $sinceSafe = date('Y-m-d H:i:s', max(0, $nowEpoch - 5));
        } else {
            $sinceSafe = date('Y-m-d H:i:s', max(0, $sinceEpoch - 5));
        }

        $isAdmin = (strtolower(trim($authUser['role_name'] ?? '')) === 'administrator' || intval($authUser['role_id'] ?? 0) === 1);
        $hasCostPerm = maySeeProductCost($authUser);

        // Query modified products
        $pStmt = $db->prepare("SELECT id, name, sku, barcode, category, unit, cost_price, selling_price, min_stock_alert, is_active, updated_at 
                               FROM products 
                               WHERE updated_at >= ?
                               ORDER BY updated_at ASC LIMIT 100");
        $pStmt->execute([$sinceSafe]);
        $changedProducts = $pStmt->fetchAll();

        foreach ($changedProducts as &$p) {
            if (!$hasCostPerm) {
                unset($p['cost_price']);
            }
        }
        unset($p);

        // The sizes are part of the product, not a detail the till can be left without: a
        // delta record that carries the price but not the crates has the till ringing a
        // whole crate at the loose unit's price the next time the network is down.
        $changedUnits = sfUnitsForMany($db, array_column($changedProducts, 'id'));
        foreach ($changedProducts as &$p) {
            $p['units'] = $changedUnits[$p['id']] ?? [];
        }
        unset($p);

        // Query modified branch inventory & fallback single inventory
        $biStmt = $db->prepare("SELECT product_id, current_quantity, custom_selling_price, updated_at 
                                FROM branch_inventory 
                                WHERE (? = 'ALL' OR branch_code = ?) AND updated_at >= ?
                                ORDER BY updated_at ASC LIMIT 100");
        $biStmt->execute([$branchCode, $branchCode, $sinceSafe]);
        $changedBranchInventory = $biStmt->fetchAll();

        $siStmt = $db->prepare("SELECT product_id, current_quantity, updated_at 
                                FROM inventory 
                                WHERE updated_at >= ?
                                ORDER BY updated_at ASC LIMIT 100");
        $siStmt->execute([$sinceSafe]);
        $changedSingleInventory = $siStmt->fetchAll();

        $invMap = [];
        foreach ($changedSingleInventory as $si) {
            $invMap[$si['product_id']] = [
                'product_id' => $si['product_id'],
                'current_quantity' => $si['current_quantity'],
                'custom_selling_price' => null,
                'updated_at' => $si['updated_at']
            ];
        }
        foreach ($changedBranchInventory as $bi) {
            $invMap[$bi['product_id']] = $bi;
        }
        $changedInventory = array_values($invMap);

        // Query new or updated sales
        $sStmt = $db->prepare("SELECT s.*, u.full_name as cashier_name, c.name as customer_name
                               FROM sales s
                               LEFT JOIN users u ON s.user_id = u.id
                               LEFT JOIN customers c ON s.customer_id = c.id
                               WHERE (? = 'ALL' OR s.branch_code = ? OR s.branch_code IS NULL) AND (s.updated_at >= ? OR s.created_at >= ?)
                               ORDER BY s.created_at DESC LIMIT 50");
        $sStmt->execute([$branchCode, $branchCode, $sinceSafe, $sinceSafe]);
        $changedSales = $sStmt->fetchAll();

        // s.* carries the margin columns on every receipt. Another till needs the
        // sale to show it; a cashier does not need to see what the shop earns on it.
        if (!$hasCostPerm) {
            foreach ($changedSales as &$cs) {
                unset($cs['total_cost'], $cs['gross_profit']);
            }
            unset($cs);
        }

        // Query modified customers
        $cStmt = $db->prepare("SELECT id, name, phone, email, address, balance, notes, updated_at 
                               FROM customers 
                               WHERE updated_at >= ?
                               ORDER BY updated_at ASC LIMIT 50");
        $cStmt->execute([$sinceSafe]);
        $changedCustomers = $cStmt->fetchAll();

        // Query new expenses
        $eStmt = $db->prepare("SELECT e.* 
                               FROM expenses e 
                               WHERE (? = 'ALL' OR e.branch_code = ? OR e.branch_code IS NULL) AND e.created_at >= ?
                               ORDER BY e.created_at DESC LIMIT 50");
        $eStmt->execute([$branchCode, $branchCode, $sinceSafe]);
        $changedExpenses = $eStmt->fetchAll();

        $hasChanges = !empty($changedProducts) || !empty($changedInventory) || !empty($changedSales) || !empty($changedCustomers) || !empty($changedExpenses);

        jsonResponse([
            'success' => true,
            'has_changes' => $hasChanges,
            'server_time' => $now,
            'book_epoch' => $deltaEpoch,
            'changes' => [
                'products' => $changedProducts,
                'inventory' => $changedInventory,
                'sales' => $changedSales,
                'customers' => $changedCustomers,
                'expenses' => $changedExpenses
            ]
        ]);
    }

    $authUser = requirePermission('manage_sales');
    $stmt = $db->query("SELECT * FROM sync_log ORDER BY id DESC LIMIT 10");
    $logs = $stmt->fetchAll();

    jsonResponse([
        'success' => true,
        'status' => 'ONLINE',
        'server_time' => date('Y-m-d H:i:s'),
        'recent_syncs' => $logs
    ]);
}

jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
