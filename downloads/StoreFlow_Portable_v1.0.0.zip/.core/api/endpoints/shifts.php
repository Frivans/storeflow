<?php
// api/endpoints/shifts.php
// Cash Register Shifts, Balancing Ledger & Z-Report History
require_once __DIR__ . '/../config/db.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET') {
    $authUser = requireAuth();
    $isAdmin = (strtolower(trim($authUser['role_name'] ?? '')) === 'administrator' || intval($authUser['role_id'] ?? 0) === 1);
    $isManager = (strtolower(trim($authUser['role_name'] ?? '')) === 'store manager');

    $action = trim($_GET['action'] ?? '');
    if ($action === 'floats') {
        $filterDate = trim($_GET['date'] ?? date('Y-m-d'));
        $filterBranch = trim($_GET['branch_code'] ?? 'MAIN-01');
        $sql = "SELECT terminal_id, branch_code, shift_date, opening_float, user_id, cashier_name, updated_at 
                FROM register_floats 
                WHERE shift_date = ?";
        $params = [$filterDate];
        if (!empty($filterBranch) && $filterBranch !== 'ALL') {
            $sql .= " AND branch_code = ?";
            $params[] = $filterBranch;
        }
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $floats = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Fetch active terminals across the shop for today
        $terminalsSql = "SELECT DISTINCT upper(terminal_id) as terminal_id FROM register_floats WHERE shift_date = ?
                         UNION
                         SELECT DISTINCT upper(terminal_id) as terminal_id FROM register_shifts WHERE shift_date = ?
                         UNION
                         SELECT DISTINCT upper(terminal_id) as terminal_id FROM sales WHERE DATE(sale_date) = ?
                         UNION
                         SELECT DISTINCT upper(terminal_id) as terminal_id FROM expenses WHERE DATE(expense_date) = ?";
        $tStmt = $db->prepare($terminalsSql);
        $tStmt->execute([$filterDate, $filterDate, $filterDate, $filterDate]);
        $activeTerms = $tStmt->fetchAll(PDO::FETCH_COLUMN);

        jsonResponse([
            'success' => true,
            'floats' => $floats,
            'terminals' => array_values(array_filter($activeTerms))
        ]);
        exit;
    }

    $filterDate = trim($_GET['date'] ?? '');
    $filterTerminal = trim($_GET['terminal_id'] ?? '');
    $filterBranch = trim($_GET['branch_code'] ?? '');
    $filterUser = intval($_GET['user_id'] ?? 0);
    $limit = intval($_GET['limit'] ?? 50);
    if ($limit <= 0 || $limit > 200) $limit = 50;

    $sql = "SELECT s.*, u.username, u.full_name 
            FROM register_shifts s
            LEFT JOIN users u ON s.user_id = u.id
            WHERE 1=1";
    $params = [];

    // Cashiers are restricted to viewing their own shifts
    if (!$isAdmin && !$isManager) {
        $sql .= " AND s.user_id = ?";
        $params[] = $authUser['id'];
    } elseif ($filterUser > 0) {
        $sql .= " AND s.user_id = ?";
        $params[] = $filterUser;
    }

    if (!empty($filterDate)) {
        $sql .= " AND (DATE(s.shift_date) = ? OR s.shift_date LIKE ?)";
        $params[] = $filterDate;
        $params[] = "{$filterDate}%";
    }

    if (!empty($filterTerminal)) {
        $sql .= " AND s.terminal_id = ?";
        $params[] = $filterTerminal;
    }

    if (!empty($filterBranch) && $filterBranch !== 'ALL') {
        $sql .= " AND s.branch_code = ?";
        $params[] = $filterBranch;
    }

    $sql .= " ORDER BY s.created_at DESC LIMIT ?";
    $params[] = $limit;

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $shifts = $stmt->fetchAll();

    jsonResponse([
        'success' => true,
        'shifts' => $shifts,
        'count' => count($shifts)
    ]);
}

if ($method === 'POST') {
    $authUser = requirePermission('manage_sales');
    $data = getJsonInput();

    $action = trim($_GET['action'] ?? ($data['action'] ?? ''));
    if ($action === 'set_float') {
        $terminalId = strtoupper(trim($data['terminal_id'] ?? 'REG-01'));
        $branchCode = trim($data['branch_code'] ?? 'MAIN-01');
        $shiftDate = trim($data['shift_date'] ?? date('Y-m-d'));
        $openingFloat = round(floatval($data['opening_float'] ?? 0), 2);
        $floatId = 'flt_' . md5($terminalId . ':' . $shiftDate . ':' . $branchCode);

        $stmt = $db->prepare("INSERT INTO register_floats (
            id, terminal_id, branch_code, shift_date, opening_float, user_id, cashier_name, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
        ON CONFLICT(terminal_id, shift_date, branch_code) DO UPDATE SET
            opening_float = excluded.opening_float,
            user_id = excluded.user_id,
            cashier_name = excluded.cashier_name,
            updated_at = datetime('now')");

        $stmt->execute([
            $floatId,
            $terminalId,
            $branchCode,
            $shiftDate,
            $openingFloat,
            $authUser['id'] ?? null,
            $authUser['full_name'] ?? 'Cashier'
        ]);

        jsonResponse([
            'success' => true,
            'message' => "Opening float of {$openingFloat} saved for {$terminalId}",
            'float' => [
                'terminal_id' => $terminalId,
                'shift_date' => $shiftDate,
                'opening_float' => $openingFloat
            ]
        ]);
        exit;
    }

    $id = trim($data['id'] ?? ('shift_' . bin2hex(random_bytes(6))));
    $shiftNumber = trim($data['shift_number'] ?? ('SHIFT-' . date('Ymd') . '-' . rand(1000, 9999)));
    $terminalId = trim($data['terminal_id'] ?? 'REG-01');
    $branchCode = trim($data['branch_code'] ?? 'MAIN-01');
    $shiftDate = trim($data['shift_date'] ?? date('Y-m-d'));
    $shiftTime = trim($data['shift_time'] ?? date('H:i:s'));

    // The officer on a shift already comes from the session; the branch and the day
    // used to come from the request, so a till could file its drawer into another
    // branch's reconciliation or into a date the owner has not reached yet.
    if (!hasPermission($authUser, 'manage_settings')) {
        $ownBranch = strtoupper(trim((string)($authUser['branch_code'] ?? 'MAIN-01')));
        if ($ownBranch !== '' && strtoupper($branchCode) !== $ownBranch) {
            jsonResponse(['success' => false,
                'message' => "Access denied: You are assigned to branch {$ownBranch} and cannot close a shift for {$branchCode}."], 403);
        }
    }
    $shiftEpoch = strtotime($shiftDate . ' ' . $shiftTime);
    if ($shiftEpoch === false || $shiftEpoch > time() + 120) {
        $shiftDate = date('Y-m-d');
        $shiftTime = date('H:i:s');
    }

    $openingFloat = round(floatval($data['opening_float'] ?? 0), 2);    $totalTransactions = intval($data['total_transactions'] ?? 0);
    $totalSalesGross = round(floatval($data['total_sales_gross'] ?? 0), 2);
    $cardSales = round(floatval($data['card_sales'] ?? 0), 2);
    $transferSales = round(floatval($data['transfer_sales'] ?? 0), 2);
    $creditSales = round(floatval($data['credit_sales'] ?? 0), 2);
    $notes = trim($data['notes'] ?? '');

    // The drawer's own arithmetic, in the one place it exists: what should be in the box and how
    // far the count fell short are worked out from the components, never taken as typed. The cash
    // handed back over credit notes is one of those components, and it is read off the book for the
    // same reason - a till that is short could otherwise type the refunds that explain it. Petty
    // cash paid out is read the same way and for the sharper reason: an invented expense does not
    // explain a shortage, it forgives one.
    //
    // Not max($typed, $book): the larger of the two is precisely the number a thieving till can
    // raise. GH₵60.00 of fuel on the book and GH₵260.00 typed takes GH₵200.00 off expected cash
    // and closes a stolen GH₵200.00 as BALANCED. An expense the shop has not recorded is an
    // expense that did not leave this drawer - record it on the expenses screen and the next
    // count subtracts it. The replayed close on sync.php reads the book the same way; two doors
    // that reconcile one drawer differently is how the same box reads level here and short there.
    $data['cash_refunds_paid'] = shiftCashRefundsPaid($db, $terminalId, $branchCode, $shiftDate);
    $data['drawer_expenses'] = shiftDrawerExpensesPaid($db, $terminalId, $branchCode, $shiftDate);
    $rentalFigures = shiftRentalFigures($db, $terminalId, $branchCode, $shiftDate);
    $data['rental_cash_collected'] = $rentalFigures['rental_cash_collected'];
    $data['rental_caution_refunded'] = $rentalFigures['rental_caution_refunded'];
    $figures = shiftFigures($data);
    $cashSales = $figures['cash_sales'];
    $debtCashCollected = $figures['debt_cash_collected'];
    $rentalCashCollected = $figures['rental_cash_collected'];
    $rentalCautionRefunded = $figures['rental_caution_refunded'];
    $drawerExpenses = $figures['drawer_expenses'];
    $cashRefundsPaid = $figures['cash_refunds_paid'];
    $expectedCash = $figures['expected_cash'];
    $countedCash = $figures['counted_cash'];
    $variance = $figures['variance'];
    $voidedCount = $figures['voided_count'];
    $voidedValue = $figures['voided_value'];

    try {
        $stmt = $db->prepare("INSERT INTO register_shifts (
            id, shift_number, user_id, cashier_name, role_name, terminal_id, branch_code,
            shift_date, shift_time, opening_float, total_transactions, total_sales_gross, 
            voided_count, voided_value,
            cash_sales, card_sales, transfer_sales, credit_sales, debt_cash_collected, drawer_expenses,
            cash_refunds_paid, rental_cash_collected, rental_caution_refunded,
            expected_cash, counted_cash, variance, notes, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))");

        $stmt->execute([
            $id,
            $shiftNumber,
            $authUser['id'],
            $authUser['full_name'],
            $authUser['role_name'],
            $terminalId,
            $branchCode,
            $shiftDate,
            $shiftTime,
            $openingFloat,
            $totalTransactions,
            $totalSalesGross,
            $voidedCount,
            $voidedValue,
            $cashSales,
            $cardSales,
            $transferSales,
            $creditSales,
            $debtCashCollected,
            $drawerExpenses,
            $cashRefundsPaid,
            $rentalCashCollected,
            $rentalCautionRefunded,
            $expectedCash,
            $countedCash,
            $variance,
            $notes
        ]);

        $statusStr = abs($variance) < 0.01 ? 'BALANCED' : ($variance > 0 ? "SURPLUS (+{$variance})" : "SHORTAGE ({$variance})");
        logActivity($db, $authUser['id'], $authUser['full_name'], $authUser['role_name'], 'SHIFT_CLOSE',
            "Recorded register shift {$shiftNumber} ({$statusStr}). Branch: {$branchCode}, Terminal: {$terminalId}."
            . ($cashRefundsPaid > 0.005 ? ' Cash handed back over credit notes, counted out of the drawer before the variance: GH₵' . number_format($cashRefundsPaid, 2) . '.' : '')
            . ($drawerExpenses > 0.005 ? ' Petty cash paid out of this drawer on the day\'s expense rows: GH₵' . number_format($drawerExpenses, 2) . '.' : ''));

        jsonResponse([
            'success' => true,
            'message' => 'Shift closed and recorded successfully',
            'shift' => [
                'id' => $id,
                'shift_number' => $shiftNumber,
                'variance' => $variance,
                'status' => $statusStr
            ]
        ], 201);
    } catch (Exception $e) {
        jsonResponse([
            'success' => false,
            'message' => 'Failed to record shift session: ' . $e->getMessage()
        ], 500);
    }
}

jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
