<?php
// api/endpoints/inventory.php
// Current Inventory Levels, Multi-Branch Stock Distribution & Adjustments
require_once __DIR__ . '/../config/db.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET') {
    $user = requireAuth();
    $filter = trim($_GET['filter'] ?? 'all');
    $branchCode = strtoupper(trim($_GET['branch_code'] ?? 'ALL'));

    if (!empty($branchCode) && $branchCode !== 'ALL') {
        // Query specific branch inventory
        $sql = "SELECT COALESCE(binv.id, 'binv_' || p.id) as inventory_id,
                       COALESCE(binv.current_quantity, 0.0) as current_quantity,
                       COALESCE(binv.reorder_level, p.min_stock_alert, 5.0) as reorder_level,
                       COALESCE(b.name, binv.branch_code, ?) as location,
                       COALESCE(binv.branch_code, ?) as branch_code,
                       COALESCE(binv.custom_selling_price, p.selling_price) as selling_price,
                       COALESCE(binv.is_available, 1) as is_available,
                       binv.updated_at,
                       p.id as product_id, p.name as product_name, p.sku, p.barcode, p.category, p.unit, p.cost_price, p.min_stock_alert,
                       (COALESCE(binv.current_quantity, 0.0) * p.cost_price) as total_cost_value,
                       (COALESCE(binv.current_quantity, 0.0) * COALESCE(binv.custom_selling_price, p.selling_price)) as total_retail_value
                FROM products p
                LEFT JOIN branch_inventory binv ON p.id = binv.product_id AND binv.branch_code = ?
                LEFT JOIN branches b ON b.branch_code = ?
                WHERE p.is_active = 1";
        $params = [$branchCode, $branchCode, $branchCode, $branchCode];

        if ($filter === 'low_stock') {
            $sql .= " AND COALESCE(binv.current_quantity, 0.0) <= p.min_stock_alert AND COALESCE(binv.current_quantity, 0.0) > 0";
        } elseif ($filter === 'out_of_stock') {
            $sql .= " AND COALESCE(binv.current_quantity, 0.0) <= 0";
        }

        $sql .= " ORDER BY COALESCE(binv.current_quantity, 0.0) ASC, p.name ASC";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $inventory = $stmt->fetchAll();

        // Movements for this branch
        $mvtStmt = $db->prepare("SELECT m.*, p.name as product_name, p.unit
                                 FROM inventory_movements m
                                 JOIN products p ON m.product_id = p.id
                                 WHERE m.branch_code = ?
                                 ORDER BY m.created_at DESC LIMIT 50");
        $mvtStmt->execute([$branchCode]);
        $recentMovements = $mvtStmt->fetchAll();

    } else {
        // Consolidated across all branches
        $sql = "SELECT inv.id as inventory_id,
                       COALESCE(inv.current_quantity, 0.0) as current_quantity,
                       inv.reorder_level,
                       'All Locations (Consolidated)' as location,
                       'ALL' as branch_code,
                       inv.updated_at,
                       p.id as product_id, p.name as product_name, p.sku, p.barcode, p.category, p.unit, p.cost_price, p.selling_price, p.min_stock_alert,
                       (COALESCE(inv.current_quantity, 0.0) * p.cost_price) as total_cost_value,
                       (COALESCE(inv.current_quantity, 0.0) * p.selling_price) as total_retail_value
                FROM products p
                LEFT JOIN inventory inv ON p.id = inv.product_id
                WHERE p.is_active = 1";

        if ($filter === 'low_stock') {
            $sql .= " AND inv.current_quantity <= p.min_stock_alert AND inv.current_quantity > 0";
        } elseif ($filter === 'out_of_stock') {
            $sql .= " AND inv.current_quantity <= 0";
        }

        $sql .= " ORDER BY inv.current_quantity ASC, p.name ASC";
        $stmt = $db->query($sql);
        $inventory = $stmt->fetchAll();

        // Fetch branch breakdowns for all products
        $branchBreakdownStmt = $db->query("SELECT binv.product_id, binv.branch_code, binv.current_quantity, binv.custom_selling_price, binv.is_available,
                                                  COALESCE(b.name, binv.branch_code) as branch_name
                                           FROM branch_inventory binv
                                           LEFT JOIN branches b ON binv.branch_code = b.branch_code
                                           WHERE binv.branch_code != 'ALL'
                                           ORDER BY binv.branch_code ASC");
        $allBranchRows = $branchBreakdownStmt->fetchAll();
        $branchMap = [];
        foreach ($allBranchRows as $brow) {
            $branchMap[$brow['product_id']][] = $brow;
        }

        foreach ($inventory as &$row) {
            $row['branch_stocks'] = $branchMap[$row['product_id']] ?? [];
        }

        $mvtStmt = $db->query("SELECT m.*, p.name as product_name, p.unit, COALESCE(b.name, m.branch_code) as branch_name
                               FROM inventory_movements m
                               JOIN products p ON m.product_id = p.id
                               LEFT JOIN branches b ON m.branch_code = b.branch_code
                               ORDER BY m.created_at DESC LIMIT 50");
        $recentMovements = $mvtStmt->fetchAll();
    }

    // products.php already zeroes cost_price for staff without inventory rights; the
    // stock view has to apply the same rule or margins leak through here instead.
    $canViewCost = maySeeProductCost($user);
    if (!$canViewCost) {
        foreach ($inventory as &$row) {
            $row['cost_price'] = 0.0;
            $row['total_cost_value'] = 0.0;
        }
        unset($row);

        // The movement ledger prices what it moved, so a receipt-in line carries the
        // supplier's price and a write-off carries the cost of the stock lost. Sale and
        // return lines are priced at retail, which the till prints anyway.
        foreach ($recentMovements as &$mvt) {
            $type = strtoupper(trim((string)($mvt['movement_type'] ?? '')));
            if (!in_array($type, ['SALE', 'RETURN_RESTOCK', 'RETURN_DAMAGED'], true)) {
                $mvt['unit_price'] = null;
            }
        }
        unset($mvt);
    }

    $totalStockUnits = 0.0;
    $totalCostValuation = 0.0;
    $totalRetailValuation = 0.0;
    $lowStockCount = 0;
    $outOfStockCount = 0;

    foreach ($inventory as $row) {
        $qty = floatval($row['current_quantity']);
        $totalStockUnits += $qty;
        $totalCostValuation += round(floatval($row['total_cost_value']), 2);
        $totalRetailValuation += round(floatval($row['total_retail_value']), 2);

        if ($qty <= 0) {
            $outOfStockCount++;
        } elseif ($qty <= floatval($row['min_stock_alert'])) {
            $lowStockCount++;
        }
    }

    jsonResponse([
        'success' => true,
        'branch_code' => $branchCode,
        'inventory' => $inventory,
        'movements' => $recentMovements,
        'summary' => [
            'total_products_count' => count($inventory),
            'total_stock_units' => $totalStockUnits,
            'total_cost_valuation' => $canViewCost ? round($totalCostValuation, 2) : null,
            'total_retail_valuation' => round($totalRetailValuation, 2),
            'potential_profit' => $canViewCost ? round($totalRetailValuation - $totalCostValuation, 2) : null,
            'low_stock_count' => $lowStockCount,
            'out_of_stock_count' => $outOfStockCount
        ]
    ]);
}

if ($method === 'POST') {
    $authUser = requirePermission('manage_inventory');
    $data = getJsonInput();

    $productId = trim($data['product_id'] ?? $data['item_id'] ?? '');
    $adjustmentType = trim($data['type'] ?? 'ADJUSTMENT_ADD');
    $quantity = floatval($data['quantity'] ?? 0);
    $reason = trim($data['reason'] ?? 'Manual stock adjustment');
    $branchCode = strtoupper(trim($data['branch_code'] ?? 'MAIN-01'));
    if (empty($branchCode) || $branchCode === 'ALL') $branchCode = 'MAIN-01';

    $locStmt = $db->prepare("SELECT name FROM branches WHERE branch_code = ?");
    $locStmt->execute([$branchCode]);
    $locationName = $locStmt->fetchColumn() ?: $branchCode;

    if (empty($productId) || $quantity <= 0) {
        jsonResponse(['success' => false, 'message' => 'Valid product and positive quantity required'], 400);
    }

    try {
        $db->beginTransaction();

        $profRow = $db->query("SELECT allow_negative_stock FROM store_profile WHERE id = 1")->fetch();
        $allowNegativeStock = intval($profRow['allow_negative_stock'] ?? 0);

        $delta = ($adjustmentType === 'ADJUSTMENT_REMOVE' || $adjustmentType === 'DAMAGE') ? -$quantity : $quantity;

        if ($delta < 0 && $allowNegativeStock === 0) {
            $stockStmt = $db->prepare("SELECT current_quantity FROM branch_inventory WHERE branch_code = ? AND product_id = ?");
            $stockStmt->execute([$branchCode, $productId]);
            $currentQty = floatval($stockStmt->fetchColumn() ?: 0);
            if (($currentQty + $delta) < 0) {
                $db->rollBack();
                jsonResponse(['success' => false, 'message' => "Cannot reduce stock below zero at branch {$branchCode}. Current stock is {$currentQty}."], 400);
            }
        }

        // For rental repairs and found/replaced items, ensure we do not restock more units than were logged as damaged or missing
        if ($adjustmentType === 'REPAIRED') {
            $dmgCheck = $db->prepare("SELECT COALESCE(SUM(quantity_damaged), 0) FROM rental_items WHERE product_id = ?");
            $dmgCheck->execute([$productId]);
            $totDmg = floatval($dmgCheck->fetchColumn() ?: 0);

            $repCheck = $db->prepare("SELECT COALESCE(SUM(quantity), 0) FROM inventory_movements WHERE product_id = ? AND movement_type = 'REPAIRED'");
            $repCheck->execute([$productId]);
            $totRep = floatval($repCheck->fetchColumn() ?: 0);

            $netDamaged = max(0, $totDmg - $totRep);
            if ($quantity > $netDamaged) {
                $db->rollBack();
                jsonResponse([
                    'success' => false, 
                    'message' => "Cannot restock {$quantity} repaired unit(s). Only {$netDamaged} unit(s) are currently recorded as damaged/awaiting repair for this item."
                ], 422);
            }
        } elseif ($adjustmentType === 'FOUND_REPLACED') {
            $misCheck = $db->prepare("SELECT COALESCE(SUM(quantity_missing), 0) FROM rental_items WHERE product_id = ?");
            $misCheck->execute([$productId]);
            $totMis = floatval($misCheck->fetchColumn() ?: 0);

            $resCheck = $db->prepare("SELECT COALESCE(SUM(quantity), 0) FROM inventory_movements WHERE product_id = ? AND movement_type = 'FOUND_REPLACED'");
            $resCheck->execute([$productId]);
            $totRes = floatval($resCheck->fetchColumn() ?: 0);

            $netMissing = max(0, $totMis - $totRes);
            if ($quantity > $netMissing) {
                $db->rollBack();
                jsonResponse([
                    'success' => false, 
                    'message' => "Cannot restore {$quantity} missing unit(s). Only {$netMissing} unit(s) are currently recorded as missing/lost for this item."
                ], 422);
            }
        }

        // 1. Update or Insert into branch_inventory
        $binvStmt = $db->prepare("INSERT INTO branch_inventory (id, branch_code, product_id, current_quantity, updated_at)
                                  VALUES (?, ?, ?, ?, datetime('now'))
                                  ON CONFLICT(branch_code, product_id) DO UPDATE SET
                                  current_quantity = current_quantity + excluded.current_quantity,
                                  updated_at = datetime('now')");
        $binvStmt->execute(['binv_' . bin2hex(random_bytes(6)), $branchCode, $productId, $delta]);

        // 2. Update consolidated inventory
        $stmt = $db->prepare("UPDATE inventory SET current_quantity = current_quantity + ?, location = ?, updated_at = datetime('now') WHERE product_id = ?");
        $stmt->execute([$delta, $locationName, $productId]);

        // 3. Log movement
        $mvtStmt = $db->prepare("INSERT INTO inventory_movements (id, product_id, movement_type, quantity, reference_id, unit_price, notes, created_by, branch_code, created_at)
                                 VALUES (?, ?, ?, ?, 'MANUAL_ADJ', 0, ?, ?, ?, datetime('now'))");
        $mvtStmt->execute(['mvt_' . bin2hex(random_bytes(6)), $productId, $adjustmentType, $delta, $reason, $authUser['id'], $branchCode]);

        $pNameStmt = $db->prepare("SELECT name FROM products WHERE id = ?");
        $pNameStmt->execute([$productId]);
        $pName = $pNameStmt->fetchColumn() ?: $productId;
        logActivity($db, $authUser['id'], $authUser['full_name'], $authUser['role_name'], 'STOCK_ADJUSTMENT', "Stock adjusted by {$delta} for '{$pName}' at {$branchCode}: {$reason}.");

        $db->commit();

        jsonResponse([
            'success' => true,
            'message' => 'Stock adjusted successfully',
            'branch_code' => $branchCode,
            'delta' => $delta
        ]);
    } catch (Exception $e) {
        safeRollback($db);
        jsonResponse(['success' => false, 'message' => 'Failed to adjust stock: ' . $e->getMessage()], 500);
    }
}

jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
