<?php
// api/endpoints/sales.php
// Point of Sale Transactions, Receipts & Profit Tracking (Products)
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/product_units.php';
require_once __DIR__ . '/../config/hospitality_tab.php';

// pdo_sqlite only tracks transactions opened through PDO::beginTransaction(). This
// endpoint opens with exec('BEGIN IMMEDIATE') to serialise concurrent tills, which
// SQLite honours but PDO does not notice, so $db->commit() and $db->rollBack() both
// throw "There is no active transaction". Until that is accounted for, every online
// sale 500s and its rows are discarded when the connection closes.
function saleTxCommit(PDO $db): void {
    if ($db->inTransaction()) {
        $db->commit();
        return;
    }
    $db->exec('COMMIT');
}

function saleTxRollback(PDO $db): void {
    try {
        if ($db->inTransaction()) {
            $db->rollBack();
            return;
        }
        $db->exec('ROLLBACK');
    } catch (Throwable $t) {
        // Nothing was open (the failure happened before BEGIN). The original error
        // is what the caller reports, not this one.
    }
}

// Ensure payment_reference and loyalty columns exist
try {
    $salesCols = $db->query("PRAGMA table_info(sales)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('payment_reference', $salesCols)) {
        $db->exec("ALTER TABLE sales ADD COLUMN payment_reference TEXT DEFAULT ''");
    }
    if (!in_array('loyalty_points_earned', $salesCols)) {
        $db->exec("ALTER TABLE sales ADD COLUMN loyalty_points_earned REAL DEFAULT 0.0");
    }
    if (!in_array('loyalty_points_redeemed', $salesCols)) {
        $db->exec("ALTER TABLE sales ADD COLUMN loyalty_points_redeemed REAL DEFAULT 0.0");
    }
    if (!in_array('source', $salesCols)) {
        $db->exec("ALTER TABLE sales ADD COLUMN source TEXT DEFAULT 'POS'");
    }
    // Same stamp db.php installs on the schema; re-checked here because this is the endpoint that
    // reads it, and a book opened by an older build must answer a void rather than fail on it.
    foreach ([
        'voided_at' => 'TEXT DEFAULT NULL',
        'void_reason' => "TEXT DEFAULT ''",
        'void_user_id' => 'INTEGER DEFAULT NULL',
        'void_user_name' => "TEXT DEFAULT ''",
    ] as $voidCol => $voidType) {
        if (!in_array($voidCol, $salesCols)) {
            $db->exec("ALTER TABLE sales ADD COLUMN {$voidCol} {$voidType}");
        }
    }
} catch (Exception $e) {}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET') {
    $user = requireAuth();
    $canSeeCost = maySeeProductCost($user);
    $saleId = trim($_GET['id'] ?? '');

    if (!empty($saleId)) {
        $stmt = $db->prepare("SELECT s.*, c.name as customer_name, c.phone as customer_phone, c.address as customer_address, u.full_name as cashier_name
                              FROM sales s
                              LEFT JOIN customers c ON s.customer_id = c.id
                              LEFT JOIN users u ON s.user_id = u.id
                              WHERE s.id = ?");
        $stmt->execute([$saleId]);
        $sale = $stmt->fetch();

        if (!$sale) {
            jsonResponse(['success' => false, 'message' => 'Sale not found'], 404);
        }

        // si.unit is the size this line was sold in and p.unit is what the shelf counts;
        // both came back named "unit" and the join let the product win, so a crate of
        // thirty printed on the customer's receipt as "2 pcs" of the loose unit.
        $itemsStmt = $db->prepare("SELECT si.*, p.name as product_name, p.unit AS base_unit, p.sku
                                   FROM sale_items si
                                   JOIN products p ON si.product_id = p.id
                                   WHERE si.sale_id = ?");
        $itemsStmt->execute([$saleId]);
        $sale['items'] = $itemsStmt->fetchAll();

        // The printed receipt is the one paper a cashier handles that carries every line
        // of the sale, and the row was handed out whole: cost, profit, and unit cost on
        // each line. Returns already strips these from the same table.
        if (!$canSeeCost) {
            $sale = maskSaleRowForClient($sale);
        }

        // store_profile is deliberately not embedded: the row holds the mNotify provider
        // key and the scanner pairing secret, so returning it here would hand every
        // cashier who opens a receipt the credentials to spend the owner's SMS credit
        // and to beam barcodes into any till. Receipts read the profile from
        // profile.php, which masks these fields.
        jsonResponse(['success' => true, 'sale' => $sale]);
    }

    $filterDate = trim($_GET['date'] ?? '');
    $customerId = trim($_GET['customer_id'] ?? '');
    $branchCode = trim($_GET['branch_code'] ?? '');
    $withItems = !empty($_GET['with_items']);
    $startDate = trim($_GET['start_date'] ?? '');
    $endDate = trim($_GET['end_date'] ?? '');

    // cashier_name is on the single-receipt read and was missing here, so the analytics
    // staff table put every server-loaded sale under one invented "Store Cashier" and the
    // attendant filter matched against a field that did not exist.
    $sql = "SELECT s.*, c.name as customer_name, u.full_name as cashier_name, COUNT(si.id) as product_count
            FROM sales s
            LEFT JOIN customers c ON s.customer_id = c.id
            LEFT JOIN users u ON s.user_id = u.id
            LEFT JOIN sale_items si ON s.id = si.sale_id
            WHERE 1=1";
    $params = [];

    if (!empty($filterDate)) {
        $sql .= " AND DATE(s.sale_date) = ?";
        $params[] = $filterDate;
    }
    // A window, not only a single day. The analytics boards need their receipt lines and
    // this list is unbounded: asking for the lines of every sale since the shop opened to
    // draw one week's chart is a multi-megabyte response on a till that is standing on a
    // counter. Both are bound parameters, and DATE() keeps a sale at 23:59 inside a window
    // that ends on the same day it was rung up.
    if ($startDate !== '' && $endDate !== '') {
        $sql .= " AND DATE(s.sale_date) BETWEEN ? AND ?";
        $params[] = $startDate;
        $params[] = $endDate;
    }
    if (!empty($customerId)) {
        $sql .= " AND s.customer_id = ?";
        $params[] = $customerId;
    }
    if (!empty($branchCode) && $branchCode !== 'ALL') {
        $sql .= " AND s.branch_code = ?";
        $params[] = $branchCode;
    }

    $sql .= " GROUP BY s.id ORDER BY s.sale_date DESC, s.created_at DESC";
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $sales = $stmt->fetchAll();

    // Analytics ranks products and categories, and it had to do that from a receipt
    // header: every server-loaded sale collapsed into one invented line named
    // "Assorted Store Sale" carrying the whole receipt's revenue. The lines are opt-in
    // because this list is unbounded, and a till that only wants the header should not
    // pay for every bottle sold since the shop opened.
    if ($withItems && $sales !== []) {
        $linesBySale = [];
        foreach ($sales as $sRow) {
            $linesBySale[$sRow['id']] = [];
        }
        foreach (array_chunk(array_keys($linesBySale), 400) as $idChunk) {
            $placeholders = implode(',', array_fill(0, count($idChunk), '?'));
            $lineStmt = $db->prepare("SELECT si.*, p.name as product_name, p.unit AS base_unit, p.sku, p.category
                                      FROM sale_items si
                                      JOIN products p ON si.product_id = p.id
                                      WHERE si.sale_id IN ({$placeholders})");
            $lineStmt->execute($idChunk);
            foreach ($lineStmt->fetchAll() as $line) {
                if (!$canSeeCost) {
                    unset($line['unit_cost_price'], $line['profit']);
                }
                $linesBySale[$line['sale_id']][] = $line;
            }
        }
        foreach ($sales as &$sRow) {
            $sRow['items'] = $linesBySale[$sRow['id']] ?? [];
        }
        unset($sRow);
    }

    $totalRevenue = 0.0;
    $totalGrossProfit = 0.0;
    $totalRefunded = 0.0;
    $voidedCount = 0;
    $voidedValue = 0.0;
    foreach ($sales as &$s) {
        $refAmt = round(floatval($s['refunded_amount'] ?? 0), 2);
        $s['refunded_amount'] = $refAmt;

        // A voided receipt is on the book and is worth nothing. Its own figures stay exactly as
        // they were printed - the paper the customer holds cannot be re-issued at a different
        // number - so the nil is said here, in the one place the ledger's totals are worked out,
        // rather than by rewriting the row.
        $isVoided = strtoupper(trim((string)($s['status'] ?? ''))) === 'VOID';
        if ($isVoided) {
            $voidedCount++;
            $voidedValue = round($voidedValue + max(0, round(floatval($s['total_amount']) - $refAmt, 2)), 2);
        }

        $netSale = $isVoided ? 0.0 : max(0, round(floatval($s['total_amount']) - $refAmt, 2));
        $s['net_amount'] = $netSale;

        $totalRevenue += $netSale;
        $totalRefunded += $refAmt;

        // Pro-rate gross profit on refunded amount
        $origAmt = floatval($s['total_amount']);
        $refundRatio = $origAmt > 0 ? min(1.0, $refAmt / $origAmt) : 0;
        $netProfit = $isVoided ? 0.0 : max(0, round(floatval($s['gross_profit']) * (1 - $refundRatio), 2));
        $s['net_profit'] = $netProfit;
        $totalGrossProfit += $netProfit;
    }
    unset($s);

    // Margin is the owner's figure, not the counter's. This list published it to any
    // signed-in session while the till only hid the columns for a role actually named
    // "Cashier", so a Supervisor or custom staff role with sales rights read the whole
    // book off the ledger screen. Same strip as the printed receipt, the return slip
    // and the delta poll already apply.
    if (!$canSeeCost) {
        foreach ($sales as &$s) {
            $s = maskSaleRowForClient($s);
        }
        unset($s);
    }

    $summary = [
        'total_sales_count' => count($sales),
        'total_revenue' => round($totalRevenue, 2),
        'total_refunded' => round($totalRefunded, 2),
        // Reported beside the takings rather than folded into them: a day with four voids and
        // GH₵900 of sales is a different shop from one with none, and the owner should see which
        // day they are looking at without opening the activity log.
        'voided_receipts' => $voidedCount,
        'voided_value' => round($voidedValue, 2)
    ];
    if ($canSeeCost) {
        $summary['total_profit'] = round($totalGrossProfit, 2);
    }

    jsonResponse([
        'success' => true,
        'sales' => $sales,
        'summary' => $summary
    ]);
}

if ($method === 'POST') {
    $authUser = requirePermission('manage_sales');
    $data = getJsonInput();

    // --- Void a receipt ---------------------------------------------------------------
    //
    // A void is not a smaller return. The whole receipt is taken back as though it was never
    // rung: the goods go back as they came off, the account entry the bill made is undone, and
    // the paper stays on the ledger at nil. That is why it is only allowed on the day the bill
    // was struck, why it insists on a reason, and why a receipt already carrying a credit note
    // is refused rather than restocked a second time. The row keeps its figures - the money
    // paths read a voided receipt as zero - so the receipt the customer held and the book the
    // shop keeps go on agreeing.
    $action = trim((string)($_GET['action'] ?? ($data['action'] ?? '')));
    if ($action === 'void') {
        $voidRef = trim((string)($data['sale_id'] ?? ($data['id'] ?? '')));
        $voidReason = trim(preg_replace('/\s+/', ' ', (string)($data['reason'] ?? '')));

        if ($voidRef === '') {
            jsonResponse(['success' => false, 'message' => 'Name the receipt to void.'], 400);
        }
        if ($voidReason === '') {
            jsonResponse([
                'success' => false,
                'message' => 'Say why the receipt is being voided. The reason is stamped on the ledger and read back at the shift count.'
            ], 400);
        }
        if (mb_strlen($voidReason) > 300) {
            jsonResponse(['success' => false, 'message' => 'Keep the void reason under 300 characters - it prints on the ledger line.'], 400);
        }

        // The attendant's name travels with the read because a refusal has to say whose receipt
        // it is, and "attendant #3" is not something a shop owner can act on at a counter.
        $vStmt = $db->prepare("SELECT s.*, u.full_name as cashier_name FROM sales s
                               LEFT JOIN users u ON s.user_id = u.id
                               WHERE s.id = ? OR s.receipt_number = ? LIMIT 1");
        $vStmt->execute([$voidRef, $voidRef]);
        $sale = $vStmt->fetch();
        if (!$sale) {
            jsonResponse(['success' => false, 'message' => 'No receipt by that number is on the book.'], 404);
        }

        $saleStatus = strtoupper(trim((string)($sale['status'] ?? 'COMPLETED')));
        $saleTotal = round(floatval($sale['total_amount'] ?? 0), 2);
        $saleReceipt = (string)($sale['receipt_number'] ?? '');
        $saleBranch = strtoupper(trim((string)($sale['branch_code'] ?? 'MAIN-01')));
        if ($saleBranch === '') $saleBranch = 'MAIN-01';

        if ($saleStatus === 'VOID') {
            jsonResponse([
                'success' => false,
                'message' => 'Receipt #' . $saleReceipt . ' was already voided'
                    . ($sale['voided_at'] ? ' at ' . $sale['voided_at'] : '')
                    . (trim((string)($sale['void_user_name'] ?? '')) !== '' ? ' by ' . $sale['void_user_name'] : '')
                    . '. Stock is back once; nothing was moved again.'
            ], 409);
        }

        $alreadyCredited = round(floatval($sale['refunded_amount'] ?? 0), 2);
        if (in_array($saleStatus, ['REFUNDED', 'PARTIALLY_REFUNDED'], true) || $alreadyCredited > 0.009) {
            jsonResponse([
                'success' => false,
                'message' => 'Receipt #' . $saleReceipt . ' already carries GH₵' . number_format($alreadyCredited, 2)
                    . ' of credit notes. Those goods were handed back and refunded; finish it with a return for what is left rather than voiding the bill and restocking it twice.'
            ], 409);
        }

        if ($saleStatus !== 'COMPLETED') {
            jsonResponse([
                'success' => false,
                'message' => 'Receipt #' . $saleReceipt . ' is in state ' . $saleStatus . ', so it cannot be voided.'
            ], 409);
        }

        // The day, not the clock: a receipt struck at 23:58 is voided against yesterday's figures
        // if the till gets to it after midnight, and yesterday's takings are already counted.
        if (substr((string)($sale['sale_date'] ?? ''), 0, 10) !== date('Y-m-d')) {
            jsonResponse([
                'success' => false,
                'message' => 'Receipt #' . $saleReceipt . ' was struck on ' . substr((string)($sale['sale_date'] ?? ''), 0, 10)
                    . '. Only today\'s receipts can be voided - a past day\'s sale is taken back through a return, where the refund and the reason sit beside the goods.'
            ], 409);
        }

        $voidIsSuper = strtolower(trim($authUser['role_name'] ?? '')) === 'administrator'
            || intval($authUser['role_id'] ?? 0) === 1;
        if (!$voidIsSuper) {
            // A restock puts goods back on a named shelf, so the branch is not the caller's to
            // pick - the same rule the returns desk applies.
            $voidUserBranch = strtoupper(trim((string)($authUser['branch_code'] ?? 'MAIN-01')));
            if ($voidUserBranch !== '' && $voidUserBranch !== 'ALL' && $voidUserBranch !== $saleBranch) {
                jsonResponse([
                    'success' => false,
                    'message' => "Access denied: You are assigned to branch {$voidUserBranch} and cannot void a receipt struck at {$saleBranch}."
                ], 403);
            }
            // A cashier may clear their own mis-ring on the spot. Undoing somebody else's whole
            // receipt takes the permission that clears the book, which is the bar returns.php
            // sets for deleting a posted credit note.
            if (intval($sale['user_id'] ?? 0) !== intval($authUser['id'] ?? 0)
                && !hasPermission($authUser, 'manage_settings')) {
                jsonResponse([
                    'success' => false,
                    'message' => 'Receipt #' . $saleReceipt . ' was rung by ' . (trim((string)($sale['cashier_name'] ?? '')) !== '' ? $sale['cashier_name'] : 'another attendant')
                        . '. Clearing another attendant\'s receipt needs the Manage Settings permission - or take the goods back as a return.'
                ], 403);
            }
        }

        $voidUserName = trim((string)($authUser['full_name'] ?? '')) !== '' ? $authUser['full_name']
            : (trim((string)($authUser['username'] ?? '')) !== '' ? $authUser['username'] : 'Cashier');

        try {
            $db->beginTransaction();

            // Stamp the row first, on the condition that it is still a completed sale. Two tills
            // both passing the read above is the case this guards, and the second one restocking
            // the same goods would put a shelf that was never emptied back on the book.
            $stampStmt = $db->prepare("UPDATE sales
                                       SET status = 'VOID',
                                           voided_at = datetime('now'),
                                           void_reason = ?,
                                           void_user_id = ?,
                                           void_user_name = ?,
                                           updated_at = datetime('now')
                                       WHERE id = ? AND status = 'COMPLETED'");
            $stampStmt->execute([$voidReason, intval($authUser['id'] ?? 0), $voidUserName, $sale['id']]);
            if ($stampStmt->rowCount() === 0) {
                safeRollback($db);
                jsonResponse([
                    'success' => false,
                    'message' => 'That receipt was just voided or refunded at another counter, so nothing was moved.'
                ], 409);
            }

            // The goods back on the shelf. The movement ledger is what records which products
            // this receipt actually took - a bundle goes out as its components and never as the
            // bundle's own row - so the void returns that list rather than the lines printed on
            // the paper. Quantity is stored negative on the way out, so the take-off is the sign
            // this reverses.
            $takeStmt = $db->prepare("SELECT product_id, SUM(quantity) AS taken, MAX(unit_price) AS unit_price
                                      FROM inventory_movements
                                      WHERE reference_id = ? AND branch_code = ? AND quantity < 0
                                      GROUP BY product_id");
            $takeStmt->execute([$saleReceipt, $saleBranch]);
            $restockRows = $takeStmt->fetchAll();

            $invBackStmt = $db->prepare("UPDATE inventory SET current_quantity = current_quantity + ?, updated_at = datetime('now') WHERE product_id = ?");
            $branchInitStmt = $db->prepare("INSERT OR IGNORE INTO branch_inventory (id, branch_code, product_id, current_quantity, updated_at)
                                            VALUES ('binv_' || lower(hex(randomblob(6))), ?, ?, 0, datetime('now'))");
            $branchBackStmt = $db->prepare("UPDATE branch_inventory SET current_quantity = current_quantity + ?, updated_at = datetime('now')
                                            WHERE branch_code = ? AND product_id = ?");
            $mvtBackStmt = $db->prepare("INSERT INTO inventory_movements (id, product_id, movement_type, quantity, reference_id, unit_price, notes, branch_code, created_at)
                                         VALUES (?, ?, 'VOID_RESTOCK', ?, ?, ?, ?, ?, datetime('now'))");

            $restockedUnits = 0.0;
            foreach ($restockRows as $rs) {
                $backQty = round(abs(floatval($rs['taken'])), 4);
                if ($backQty <= 0) continue;
                $restockedUnits = round($restockedUnits + $backQty, 4);
                $invBackStmt->execute([$backQty, $rs['product_id']]);
                $branchInitStmt->execute([$saleBranch, $rs['product_id']]);
                $branchBackStmt->execute([$backQty, $saleBranch, $rs['product_id']]);
                $mvtBackStmt->execute([
                    'mvt_' . bin2hex(random_bytes(6)),
                    $rs['product_id'],
                    $backQty,
                    $saleReceipt,
                    round(floatval($rs['unit_price']), 4),
                    "Receipt #{$saleReceipt} voided and restocked: {$voidReason}",
                    $saleBranch
                ]);
            }

            // The lot the receipt drew from, when it is still one the shop sells. A lot emptied
            // by this very bill is revived - the units never really left - but a lot since
            // condemned as EXPIRED or RECALLED is not re-opened by a void; the shelf count gets
            // the units back either way and the miss is written out for the expiry board.
            $lotStmt = $db->prepare("SELECT product_id, batch_id, base_quantity, quantity, multiplier
                                     FROM sale_items WHERE sale_id = ? AND batch_id IS NOT NULL AND batch_id != ''");
            $lotStmt->execute([$sale['id']]);
            $lotBackStmt = $db->prepare("UPDATE product_batches
                                         SET current_quantity = current_quantity + ?,
                                             status = CASE WHEN status = 'DEPLETED' AND (current_quantity + ?) > 0.001 THEN 'ACTIVE' ELSE status END,
                                             updated_at = datetime('now')
                                         WHERE id = ? AND branch_code = ? AND status IN ('ACTIVE', 'DEPLETED')");
            foreach ($lotStmt->fetchAll() as $lot) {
                $lotUnits = round(floatval($lot['base_quantity'] ?? 0), 4);
                if ($lotUnits <= 0) {
                    $lotUnits = round(floatval($lot['quantity'] ?? 0) * max(1.0, floatval($lot['multiplier'] ?? 1)), 4);
                }
                if ($lotUnits <= 0) continue;
                $lotBackStmt->execute([$lotUnits, $lotUnits, $lot['batch_id'], $saleBranch]);
                if ($lotBackStmt->rowCount() === 0) {
                    error_log("Void of {$saleReceipt}: {$lotUnits} units of product {$lot['product_id']} went back to the shelf, but lot {$lot['batch_id']} is no longer saleable.");
                }
            }

            // Undo the two moves the sale path makes against an account: the unpaid part of a
            // credit or short-paid bill, and an overpayment put towards the balance instead of
            // handed back as change. Nothing else on the row changes what the member owes.
            $balanceReversal = 0.0;
            $paidAmt = round(floatval($sale['amount_paid'] ?? 0), 2);
            $changeDue = round(floatval($sale['change_due'] ?? 0), 2);
            $paidMethod = strtoupper(trim((string)($sale['payment_method'] ?? 'CASH')));
            $custId = trim((string)($sale['customer_id'] ?? 'cust-walkin'));
            if ($custId !== '' && $custId !== 'cust-walkin') {
                $unpaid = round($saleTotal - $paidAmt, 2);
                if (($paidMethod === 'CREDIT' || $paidAmt < $saleTotal) && $unpaid > 0.009) {
                    $balStmt = $db->prepare("UPDATE customers SET balance = balance - ?, updated_at = datetime('now') WHERE id = ?");
                    $balStmt->execute([$unpaid, $custId]);
                    $balanceReversal = -$unpaid;
                } elseif ($paidAmt > $saleTotal + 0.009 && $changeDue <= 0.009) {
                    $over = round($paidAmt - $saleTotal, 2);
                    $balStmt = $db->prepare("UPDATE customers SET balance = balance + ?, updated_at = datetime('now') WHERE id = ?");
                    $balStmt->execute([$over, $custId]);
                    $balanceReversal = $over;
                }
            }

            // The points follow the receipt. A member who earned 20 on a GH₵200.00 bill that the
            // shop has just agreed never happened would otherwise keep spending them against real
            // money, and the 15 they handed in for a discount on it would be gone with the discount.
            $loyaltyBack = StoreFlowLoyalty::reverseSaleLoyalty($db, (string)$sale['id'], intval($authUser['id'] ?? 0), $saleBranch);

            $db->commit();
        } catch (Exception $e) {
            safeRollback($db);
            jsonResponse([
                'success' => false,
                'message' => 'The receipt could not be voided: ' . $e->getMessage()
            ], 500);
        }

        // The room keeps its own record of the bill this receipt paid. A void that names only the
        // receipt leaves the floor manager hunting for which party's ticket just stopped existing,
        // so the tab it settled is written into the same line as the money.
        $voidTabs = hospitalityTabsSettledBySale($db, (string)$sale['id']);
        $voidTabNote = '';
        if ($voidTabs) {
            $namedTabs = [];
            foreach ($voidTabs as $t) {
                $namedTabs[] = 'table ' . (trim((string)($t['table_number'] ?? '')) !== '' ? trim((string)$t['table_number']) : '?')
                    . ' (GH₵' . number_format(round(floatval($t['total_amount'] ?? 0), 2), 2)
                    . ', ' . (strtoupper(trim((string)($t['status'] ?? ''))) ?: 'SETTLED') . ')';
            }
            $voidTabNote = ' On the floor: ' . count($voidTabs) . ' tab(s) had settled on this receipt - '
                . implode('; ', $namedTabs) . '. The tab still reads paid, so re-raise the bill before the party is asked again.';
        }

        logActivity($db, intval($authUser['id'] ?? 0), $voidUserName, $authUser['role_name'] ?? 'Cashier', 'SALE_VOIDED',
            "Voided receipt #{$saleReceipt} (GH₵" . number_format($saleTotal, 2) . ", tendered as {$paidMethod}, struck " . substr((string)($sale['sale_date'] ?? ''), 0, 19) . ")"
            . " at branch {$saleBranch}. Reason: {$voidReason}."
            . " Restocked: {$restockedUnits} unit(s) across " . count($restockRows) . " product line(s)."
            . ($balanceReversal != 0 ? " Account moved by " . number_format($balanceReversal, 2) . "." : '')
            . ($loyaltyBack['reversed'] ? " Points: " . number_format($loyaltyBack['clawed_back'], 2) . " taken back, "
                . number_format($loyaltyBack['handed_back'], 2) . " handed in on it given back"
                . ($loyaltyBack['short'] > 0.005 ? ", of which " . number_format($loyaltyBack['short'], 2) . " could not be taken because the member had already spent them" : '')
                . "; balance now " . number_format($loyaltyBack['balance'], 2) . "." : '') . $voidTabNote);

        $voidedRow = $db->prepare("SELECT * FROM sales WHERE id = ?");
        $voidedRow->execute([$sale['id']]);
        $voidedSale = $voidedRow->fetch() ?: array_merge($sale, [
            'status' => 'VOID',
            'void_reason' => $voidReason,
            'void_user_name' => $voidUserName
        ]);
        if (!maySeeProductCost($authUser)) {
            $voidedSale = maskSaleRowForClient($voidedSale);
        }

        jsonResponse([
            'success' => true,
            'message' => 'Receipt #' . $saleReceipt . ' is voided. '
                . ($restockedUnits > 0 ? number_format($restockedUnits, 2) . ' unit(s) are back on the shelf. ' : '')
                . 'It stays on the ledger at GH₵0.00, so hand any cash back before the drawer is counted.',
            'sale' => $voidedSale,
            'restocked_units' => $restockedUnits,
            'voided_total' => $saleTotal
        ]);
    }

    $id = trim($data['id'] ?? '') ?: ('sale_' . bin2hex(random_bytes(6)));
    $receiptNumber = trim($data['receipt_number'] ?? '');
    $customerId = trim($data['customer_id'] ?? 'cust-walkin') ?: 'cust-walkin';
    $userId = intval($authUser['id'] ?? $data['user_id'] ?? 1);
    $saleDate = trim($data['sale_date'] ?? date('Y-m-d H:i:s'));
    $paymentMethod = strtoupper(trim($data['payment_method'] ?? 'CASH'));
    $paymentReference = trim($data['payment_reference'] ?? '');
    $discount = round(floatval($data['discount'] ?? 0), 2);
    $tax = round(floatval($data['tax'] ?? 0), 2);
    $amountPaid = round(floatval($data['amount_paid'] ?? 0), 2);
    $notes = trim($data['notes'] ?? '');
    $items = $data['items'] ?? [];

    if (empty($items) || !is_array($items)) {
        jsonResponse(['success' => false, 'message' => 'Cart is empty. Add at least one product.'], 400);
    }

    if (empty($receiptNumber)) {
        $receiptNumber = 'REC-' . date('YmdHis') . '-' . strtoupper(bin2hex(random_bytes(2)));
    }

    // A receipt already on the book is not a new sale. Until now a double-tapped checkout priced
    // the sale all over again - shelf, member's balance, points ledger - and was undone only when
    // sales.id's UNIQUE constraint threw and the transaction rolled back, which answered the till
    // with a 500 carrying the raw SQLite message. The till reads that as a refusal and keeps a
    // second copy of a booked bill in its queue. Answer it before anything moves, with the figures
    // already booked. A fresh id or receipt number minted above cannot match, so this only ever
    // fires on a receipt the till is claiming is new.
    $dupStmt = $db->prepare("SELECT * FROM sales WHERE id = ? OR receipt_number = ? LIMIT 1");
    $dupStmt->execute([$id, $receiptNumber]);
    $alreadyBooked = $dupStmt->fetch();
    if ($alreadyBooked) {
        if (!maySeeProductCost($authUser)) {
            $alreadyBooked = maskSaleRowForClient($alreadyBooked);
        }
        logActivity($db, $userId, $authUser['full_name'] ?? 'Cashier', $authUser['role_name'] ?? 'Cashier',
            'SALE_DUPLICATE', 'Receipt #' . $alreadyBooked['receipt_number'] . ' was already on the book at '
            . number_format((float)$alreadyBooked['total_amount'], 2) . ' (id ' . $id . '); nothing was written again.');
        jsonResponse([
            'success' => false,
            'duplicate' => true,
            'sale' => $alreadyBooked,
            'message' => 'Receipt #' . $alreadyBooked['receipt_number'] . ' is already on the book at GH₵'
                . number_format((float)$alreadyBooked['total_amount'], 2)
                . '. Nothing was written again - reprint that receipt instead of ringing it a second time.',
        ], 409);
    }

    try {
        try {
            $db->exec("BEGIN IMMEDIATE");
        } catch (\PDOException $pde) {
            $db->beginTransaction();
        }

        // Check if negative stock is allowed by store configuration
        $profRow = $db->query("SELECT allow_negative_stock, tax_rate FROM store_profile WHERE id = 1")->fetch();
        $allowNegativeStock = intval($profRow['allow_negative_stock'] ?? 0);

        $subtotal = 0.0;
        $totalCost = 0.0;
        $processedProducts = [];

        $terminalId = trim($data['terminal_id'] ?? 'REG-01');
        $branchCode = strtoupper(trim($data['branch_code'] ?? 'MAIN-01'));
        if (empty($branchCode) || $branchCode === 'ALL') $branchCode = 'MAIN-01';

        // Check branch access permissions for non-admin staff
        $userRole = strtolower(trim($authUser['role_name'] ?? ''));
        $userBranch = strtoupper(trim($authUser['branch_code'] ?? 'MAIN-01'));
        if ($userRole !== 'administrator' && intval($authUser['role_id'] ?? 0) !== 1) {
            if (!empty($userBranch) && $userBranch !== $branchCode) {
                saleTxRollback($db);
                jsonResponse(['success' => false, 'message' => "Access denied: You are assigned to branch {$userBranch} and cannot issue sales for {$branchCode}."], 403);
            }
        }

        // A bill for a dining tab is still this path's to write. The kitchen ticket says what
        // was made; the counter decides what it costs, in which size, out of which lot and
        // with how much tax. The tab is read here, before any stock moves, and closed inside
        // this transaction: a receipt and a released table must not be able to come apart,
        // because a free table that never got paid and a paid table that still sits occupied
        // are the same bug wearing different shoes.
        $diningTab = null;
        $tabId = trim((string)($data['table_order_id'] ?? ''));
        if ($tabId !== '') {
            $isFloorManager = $userRole === 'administrator' || intval($authUser['role_id'] ?? 0) === 1;
            $diningTab = hospitalityFindTab($db, $tabId, $branchCode, $isFloorManager);
            if ($diningTab === null) {
                saleTxRollback($db);
                jsonResponse(['success' => false, 'message' =>
                    "There is no dining tab '{$tabId}' on this shop's books, so no table can be released against it."], 404);
            }
            if (isset($diningTab['error'])) {
                saleTxRollback($db);
                jsonResponse(['success' => false, 'message' => $diningTab['error']], (int)$diningTab['status']);
            }
        }

        $prodLookupStmt = $db->prepare("SELECT p.id, p.name, p.cost_price, p.selling_price, p.unit, p.product_type, p.is_rental, binv.custom_selling_price, binv.is_available
                                        FROM products p
                                        LEFT JOIN branch_inventory binv ON p.id = binv.product_id AND binv.branch_code = ?
                                        WHERE p.id = ?");
        $comboLookupStmt = $db->prepare("SELECT c.*, p.name as component_name, p.cost_price as component_cost, p.selling_price as component_price
                                         FROM product_combo_items c
                                         LEFT JOIN products p ON c.component_product_id = p.id
                                         WHERE c.combo_product_id = ?");
        $bStockLookupStmt = $db->prepare("SELECT current_quantity FROM branch_inventory WHERE branch_code = ? AND product_id = ?");
        $stockLookupStmt = $db->prepare("SELECT current_quantity FROM inventory WHERE product_id = ?");

        foreach ($items as $item) {
            $productId = trim($item['product_id'] ?? $item['item_id'] ?? $item['id'] ?? '');
            $qty = floatval($item['quantity'] ?? 0);
            if (empty($productId) || $qty <= 0) continue;

            $prodLookupStmt->execute([$branchCode, $productId]);
            $prodDb = $prodLookupStmt->fetch();
            if (!$prodDb) continue;

            // A blank is what the ALTER TABLE that added the column left on every product older than
            // it, and both the shelf check and the lot draw below are equalities against 'standard'
            // - read as its own type, a legacy product would sell without emptying anything.
            $pType = strtolower(trim((string)($prodDb['product_type'] ?? '')));
            if ($pType === '') $pType = 'standard';

            if (isset($prodDb['is_available']) && $prodDb['is_available'] !== null && intval($prodDb['is_available']) === 0) {
                saleTxRollback($db);
                jsonResponse(['success' => false, 'message' => "Product '{$prodDb['name']}' is currently disabled for branch {$branchCode}."], 400);
            }

            // The till keeps hire equipment out of the grid, but keeping it out of sight is not the
            // same as refusing it: a phone till still running last week's cache, a scanner gun that
            // matches a chair's barcode, or an edited cart can all put a hire asset through the
            // counter. Sold outright it leaves no contract, no caution deposit and nothing to inspect
            // back in, and the hire desk goes on showing it as available for the rest of the week.
            if (intval($prodDb['is_rental'] ?? 0) === 1) {
                saleTxRollback($db);
                jsonResponse([
                    'success' => false,
                    'message' => sprintf("'%s' is equipment the shop hires out, not stock it sells. Put it on a contract at the hire desk, where the caution deposit and the return inspection live. Nothing was taken.",
                        $prodDb['name'])
                ], 400);
            }

            // Which size a line was sold in, and how much of the loose thing that is, are
            // facts about the product rather than numbers the till sends. The catalogue
            // answers, and a line naming a size the shop does not sell is refused: reading
            // it as a loose unit would hand the customer a crate and charge them for an egg.
            $unitLabel = trim((string)($item['unit'] ?? ''));
            $unitRow = sfUnitResolve($db, $productId, $unitLabel, true);
            if ($unitRow === null) {
                if ($pType === 'service') {
                    $unitRow = ['unit_name' => $unitLabel ?: 'service', 'size_in_base' => 1, 'selling_price' => null];
                } else {
                    saleTxRollback($db);
                    jsonResponse([
                        'success' => false,
                        'message' => sprintf("'%s' does not sell in a %s. The till would have to guess at a price and a stock number, so the sale was stopped.",
                            $prodDb['name'], $unitLabel)
                    ], 400);
                }
            }
            $unitLabel = trim((string)($unitRow['unit_name'] ?? '')) ?: trim((string)($prodDb['unit'] ?? 'pcs')) ?: 'pcs';
            $multiplier = round(floatval($unitRow['size_in_base'] ?? 1), 4);
            if ($multiplier < 1) $multiplier = 1.0;
            $unitPriceOverride = ($unitRow['selling_price'] === null || $unitRow['selling_price'] === '')
                ? null : floatval($unitRow['selling_price']);
            $baseQty = $qty * $multiplier;

            // Enforce negative stock restriction for physical items
            if ($pType === 'standard' && $allowNegativeStock === 0) {
                $bStockLookupStmt->execute([$branchCode, $productId]);
                $bQty = $bStockLookupStmt->fetchColumn();
                $availStock = ($bQty !== false) ? floatval($bQty) : null;

                if ($availStock === null) {
                    $stockLookupStmt->execute([$productId]);
                    $availStock = floatval($stockLookupStmt->fetchColumn() ?: 0);
                }

                if ($availStock < $baseQty) {
                    saleTxRollback($db);
                    jsonResponse([
                        'success' => false,
                        'message' => "Insufficient stock at branch ({$branchCode}) for '{$prodDb['name']}'. Available: {$availStock}, requested: {$baseQty} base units."
                    ], 400);
                }
            }

            // Enforce stock restriction for combo/bundle items based on components
            $comboComponents = [];
            if ($pType === 'combo') {
                $comboLookupStmt->execute([$productId]);
                $comboComponents = $comboLookupStmt->fetchAll(PDO::FETCH_ASSOC);
                if ($allowNegativeStock === 0 && !empty($comboComponents)) {
                    foreach ($comboComponents as $cComp) {
                        $compReq = round($qty * floatval($cComp['quantity']), 4);
                        $bStockLookupStmt->execute([$branchCode, $cComp['component_product_id']]);
                        $bQty = $bStockLookupStmt->fetchColumn();
                        $compAvail = ($bQty !== false) ? floatval($bQty) : null;
                        if ($compAvail === null) {
                            $stockLookupStmt->execute([$cComp['component_product_id']]);
                            $compAvail = floatval($stockLookupStmt->fetchColumn() ?: 0);
                        }
                        if ($compAvail < $compReq) {
                            saleTxRollback($db);
                            jsonResponse([
                                'success' => false,
                                'message' => "Insufficient stock of component '{$cComp['component_name']}' for combo '{$prodDb['name']}'. Available: {$compAvail}, required: {$compReq}."
                            ], 400);
                        }
                    }
                }
            }

            $costPrice = round(floatval($prodDb['cost_price']), 2);
            // Dynamic combo cost calculation if not explicitly set
            if ($pType === 'combo' && $costPrice <= 0.001 && !empty($comboComponents)) {
                $calcCost = 0.0;
                foreach ($comboComponents as $cComp) {
                    $calcCost += floatval($cComp['component_cost'] ?? 0) * floatval($cComp['quantity']);
                }
                $costPrice = round($calcCost, 2);
            }

            // Default authoritative selling price: branch price override if set, else base master selling price
            $authoritativePrice = ($prodDb['custom_selling_price'] !== null && $prodDb['custom_selling_price'] !== '')
                ? round(floatval($prodDb['custom_selling_price']), 2)
                : round(floatval($prodDb['selling_price']), 2);

            $sellingPrice = sfUnitPrice($unitPriceOverride, $multiplier, $authoritativePrice);
            if (isset($item['unit_selling_price'])) {
                $requestedPrice = round(floatval($item['unit_selling_price']), 2);
                if (abs($requestedPrice - $sellingPrice) >= 0.01 && !maySetSalePrices($authUser)) {
                    saleTxRollback($db);
                    jsonResponse([
                        'success' => false,
                        'message' => sprintf(
                            "'%s' sells for %s per %s. A staff member without pricing rights cannot ring it up at %s - a store manager or administrator must approve the change.",
                            $prodDb['name'], number_format($sellingPrice, 2), $unitLabel, number_format($requestedPrice, 2)
                        )
                    ], 403);
                }
                $sellingPrice = $requestedPrice;
            }

            $itemSubtotal = round($qty * $sellingPrice, 2);
            $itemCost = round($baseQty * $costPrice, 2);
            $itemProfit = round($itemSubtotal - $itemCost, 2);

            $subtotal += $itemSubtotal;
            $totalCost += $itemCost;

            $processedProducts[] = [
                'product_id' => $productId,
                'name' => $prodDb['name'],
                'quantity' => $qty,
                'unit' => $unitLabel,
                'multiplier' => $multiplier,
                'base_quantity' => $baseQty,
                'unit_cost_price' => $costPrice,
                'unit_selling_price' => $sellingPrice,
                'subtotal' => $itemSubtotal,
                'profit' => $itemProfit,
                'product_type' => $pType,
                'combo_components' => $comboComponents
            ];
        }

        if (empty($processedProducts)) {
            saleTxRollback($db);
            jsonResponse(['success' => false, 'message' => 'No valid products found in sale.'], 400);
        }

        // The bill and the ticket have to be the same list of dishes before a table lets go.
        // Short, and the shop has fed a party it never charged; long, and the customer is
        // paying for a plate the table sent back. Either is found here, while nothing has
        // moved yet, and the counter is told which line is the problem.
        $targetSeat = trim((string)($data['table_seat'] ?? ''));
        if ($diningTab !== null) {
            $itemsToCheck = ($targetSeat !== '' && $targetSeat !== 'ALL')
                ? array_values(array_filter($diningTab['items'], function($it) use ($targetSeat) {
                    $itemSeat = trim((string)($it['seat_number'] ?? 'Shared'));
                    return ($itemSeat === $targetSeat) && (strtoupper((string)($it['kitchen_status'] ?? '')) !== 'SETTLED');
                }))
                : $diningTab['items'];
            $tabProblem = hospitalityTabMismatch($diningTab['items'] ? $itemsToCheck : $diningTab['items'], $processedProducts, (string)($diningTab['table_number'] ?? ''));
            if ($tabProblem !== null) {
                saleTxRollback($db);
                jsonResponse(['success' => false, 'message' => $tabProblem], 400);
            }
        }

        $subtotal = round($subtotal, 2);
        $totalCost = round($totalCost, 2);

        // Discount and tax arrived from the till as free numbers: a receipt could be
        // written off entirely, or padded with tax the owner never configured. Both are
        // checked against what the catalogue says the basket is worth and who is typing.
        $moneyProblem = saleDiscountProblem($authUser, $subtotal, $discount)
            ?? saleTaxProblem($profRow ?: [], $subtotal, $tax);
        if ($moneyProblem !== null) {
            saleTxRollback($db);
            jsonResponse(['success' => false, 'message' => $moneyProblem], 403);
        }

        // What a member's points are worth is the shop's figure, not the till's. The claim arrives
        // as points offered; the server turns that into money from its own redemption rate, the
        // tier perk the shop chose to honour and the balance it actually holds for that customer -
        // decided before the total is built, so the receipt in the book is the one the shop agreed
        // to and a browser multiplying by a rate it hard-coded cannot price anything.
        $pointsOffered = round(floatval($data['loyalty_points_redeemed'] ?? 0), 2);
        $loyaltyResult = StoreFlowLoyalty::authorSaleLoyalty(
            $db,
            $customerId,
            $subtotal,
            $discount,
            $pointsOffered,
            $id,
            intval($authUser['id'] ?? 0),
            $branchCode
        );
        if (!empty($loyaltyResult['refused'])) {
            // Nothing was burned and nothing was discounted either: the receipt cannot mean what
            // the till tried to make it mean. Refused while the cashier is still standing there.
            saleTxRollback($db);
            jsonResponse(['success' => false, 'message' => $loyaltyResult['refused'], 'loyalty' => $loyaltyResult], 403);
        }
        $loyaltyValue = round(floatval($loyaltyResult['loyalty_value'] ?? 0), 2);
        $tierValue = round(floatval($loyaltyResult['tier_value'] ?? 0), 2);
        $loyaltyEarned = $loyaltyResult['earned'];
        $actualRedeemed = $loyaltyResult['redeemed'];
        // One figure for everything taken off the goods, because profit is measured against what
        // the shop kept - not against the sticker with only the cashier's line removed from it.
        $moneyOff = round($discount + $loyaltyValue + $tierValue, 2);

        // A walk-in account is a shared pot, not somebody's credit: it is excluded from
        // every balance update below, so an unpaid or credit sale to it would leave the
        // shop with no debt recorded and no cash - and no way to say whose loss it was.
        // amount_paid of zero means "the till did not say", which CASH settles below.
        $walkInPromise = ($paymentMethod === 'CREDIT'
            || ($amountPaid > 0 && round($amountPaid, 2) < round($subtotal - $moneyOff + $tax, 2) - 0.01));
        if ($customerId === 'cust-walkin' && $walkInPromise) {
            saleTxRollback($db);
            jsonResponse([
                'success' => false,
                'message' => 'A walk-in sale has no account to charge. Take the full amount, or put the customer on an account first so the debt is recorded against a name and a phone.'
            ], 400);
        }

        $totalAmount = round(max(0, ($subtotal - $moneyOff) + $tax), 2);
        // What the customer handed over contains the tax the shop must remit, so it is not the
        // shop's margin. The rule lives in db.php because the same receipt arrives through a
        // queued sync a day later and both doors have to make the same book.
        $grossProfit = saleGrossProfit($subtotal, $moneyOff, $tax, $totalCost);

        if ($paymentMethod === 'CASH' && $amountPaid <= 0) {
            $amountPaid = $totalAmount;
        }
        $changeDue = round(max(0, $amountPaid - $totalAmount), 2);

        $sStmt = $db->prepare("INSERT INTO sales (id, receipt_number, customer_id, user_id, terminal_id, branch_code, sale_date, subtotal, discount, loyalty_discount, tier_discount, tax, total_amount, total_cost, gross_profit, payment_method, payment_reference, amount_paid, change_due, status, notes, loyalty_points_earned, loyalty_points_redeemed, source, created_at, updated_at)
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'COMPLETED', ?, ?, ?, 'POS', datetime('now'), datetime('now'))");
        $sStmt->execute([
            $id, $receiptNumber, $customerId, $userId, $terminalId, $branchCode, $saleDate,
            $subtotal, $discount, $loyaltyValue, $tierValue, $tax, $totalAmount, $totalCost, $grossProfit,
            $paymentMethod, $paymentReference, $amountPaid, $changeDue, $notes,
            $loyaltyEarned, $actualRedeemed
        ]);

        $siStmt = $db->prepare("INSERT INTO sale_items (id, sale_id, product_id, quantity, unit_cost_price, unit_selling_price, subtotal, profit, batch_id, batch_number, expiry_date, unit, multiplier, base_quantity)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        // PDO hands sqlite every bound value as TEXT, and SQLite ranks any number below
        // any text, so an unqualified `? = 1` is false even when the shop switched
        // negative stock on. The CAST is what makes the flag mean what it says.
        $invDeductStmt = $db->prepare("UPDATE inventory SET current_quantity = current_quantity - ?, updated_at = datetime('now') WHERE product_id = ? AND (CAST(? AS INTEGER) = 1 OR current_quantity >= CAST(? AS REAL))");
        // Pre-initialize branch_inventory row with 0 so the deduct below always hits the UPDATE branch (never inserts a positive qty)
        $branchInitStmt = $db->prepare("INSERT OR IGNORE INTO branch_inventory (id, branch_code, product_id, current_quantity, updated_at)
                                        VALUES ('binv_' || lower(hex(randomblob(6))), ?, ?, 0, datetime('now'))");
        $branchDeductStmt = $db->prepare("UPDATE branch_inventory SET
                                          current_quantity = current_quantity - ?,
                                          updated_at = datetime('now')
                                          WHERE branch_code = ? AND product_id = ? AND (CAST(? AS INTEGER) = 1 OR current_quantity >= CAST(? AS REAL))");
        $batchFindStmt = $db->prepare("SELECT id, batch_number, expiry_date, current_quantity 
                                       FROM product_batches 
                                       WHERE product_id = ? AND branch_code = ? AND current_quantity > 0 AND status = 'ACTIVE'
                                       ORDER BY expiry_date ASC");
        $batchDeductStmt = $db->prepare("UPDATE product_batches 
                                         SET current_quantity = MAX(0, current_quantity - ?),
                                             status = CASE WHEN (current_quantity - ?) <= 0.001 THEN 'DEPLETED' ELSE status END,
                                             updated_at = datetime('now')
                                         WHERE id = ?");
        $mvtStmt = $db->prepare("INSERT INTO inventory_movements (id, product_id, movement_type, quantity, reference_id, unit_price, notes, branch_code, created_at)
                                 VALUES (?, ?, 'SALE', ?, ?, ?, ?, ?, datetime('now'))");

        foreach ($processedProducts as $pItem) {
            $siId = 'si_' . bin2hex(random_bytes(6));
            $pType = $pItem['product_type'] ?? 'standard';

            // FEFO (First-Expired-First-Out) Batch Lot Deduction (for physical items)
            $allocatedBatchId = null;
            $allocatedBatchNo = null;
            $allocatedExpiry = null;

            if ($pType === 'standard') {
                $batchFindStmt->execute([$pItem['product_id'], $branchCode]);
                $candidateBatches = $batchFindStmt->fetchAll(PDO::FETCH_ASSOC);

                if (!empty($candidateBatches)) {
                    $remToDeduct = $pItem['base_quantity'];
                    foreach ($candidateBatches as $cBatch) {
                        if ($remToDeduct <= 0) break;
                        $deductFromThis = min($remToDeduct, floatval($cBatch['current_quantity']));
                        $batchDeductStmt->execute([$deductFromThis, $deductFromThis, $cBatch['id']]);
                        $remToDeduct -= $deductFromThis;

                        if ($allocatedBatchNo === null) {
                            $allocatedBatchId = $cBatch['id'];
                            $allocatedBatchNo = $cBatch['batch_number'];
                            $allocatedExpiry = $cBatch['expiry_date'];
                        }
                    }
                }
            }

            $siStmt->execute([
                $siId, $id, $pItem['product_id'], $pItem['quantity'],
                $pItem['unit_cost_price'], $pItem['unit_selling_price'],
                $pItem['subtotal'], $pItem['profit'],
                $allocatedBatchId, $allocatedBatchNo, $allocatedExpiry,
                $pItem['unit'], $pItem['multiplier'], $pItem['base_quantity']
            ]);

            // Dematerialized / Services: No physical inventory deduction needed
            if ($pType === 'service') {
                continue;
            }

            // Combo / Bundle packs: Deduct stock for each child component
            if ($pType === 'combo' && !empty($pItem['combo_components'])) {
                foreach ($pItem['combo_components'] as $cComp) {
                    $compDeductQty = round($pItem['quantity'] * floatval($cComp['quantity']), 4);
                    $cProdId = $cComp['component_product_id'];

                    // Deduct component batch lot
                    $batchFindStmt->execute([$cProdId, $branchCode]);
                    $cBatches = $batchFindStmt->fetchAll(PDO::FETCH_ASSOC);
                    if (!empty($cBatches)) {
                        $remComp = $compDeductQty;
                        foreach ($cBatches as $cb) {
                            if ($remComp <= 0) break;
                            $dThis = min($remComp, floatval($cb['current_quantity']));
                            $batchDeductStmt->execute([$dThis, $dThis, $cb['id']]);
                            $remComp -= $dThis;
                        }
                    }

                    // Deduct from branch_inventory
                    $branchInitStmt->execute([$branchCode, $cProdId]);
                    $branchDeductStmt->execute([$compDeductQty, $branchCode, $cProdId, $allowNegativeStock, $compDeductQty]);

                    // Deduct from consolidated inventory
                    $invDeductStmt->execute([$compDeductQty, $cProdId, $allowNegativeStock, $compDeductQty]);

                    // Record movement for constituent item
                    $mvtStmt->execute([
                        'mvt_' . bin2hex(random_bytes(6)), $cProdId, -$compDeductQty,
                        $receiptNumber, floatval($cComp['component_cost'] ?? 0),
                        "Combo component deduction for '{$pItem['name']}' (#{$receiptNumber})",
                        $branchCode
                    ]);
                }
                continue;
            }

            // Standard physical inventory deduction:
            $branchInitStmt->execute([$branchCode, $pItem['product_id']]);
            $branchDeductStmt->execute([$pItem['base_quantity'], $branchCode, $pItem['product_id'], $allowNegativeStock, $pItem['base_quantity']]);
            if ($allowNegativeStock === 0 && $branchDeductStmt->rowCount() === 0) {
                saleTxRollback($db);
                jsonResponse([
                    'success' => false,
                    'message' => "Insufficient stock at branch ({$branchCode}) for '{$pItem['name']}'. The remaining stock was just purchased by another counter."
                ], 400);
            }

            // Deduct from consolidated inventory
            $invDeductStmt->execute([$pItem['base_quantity'], $pItem['product_id'], $allowNegativeStock, $pItem['base_quantity']]);
            if ($allowNegativeStock === 0 && $invDeductStmt->rowCount() === 0) {
                saleTxRollback($db);
                jsonResponse([
                    'success' => false,
                    'message' => "Insufficient stock for '{$pItem['name']}'. The remaining stock was just purchased by another counter."
                ], 400);
            }

            $mvtId = 'mvt_' . bin2hex(random_bytes(6));
            $mvtNotes = "POS Sale Receipt: {$receiptNumber}";
            if ($allocatedBatchNo) {
                $mvtNotes .= " [Batch: {$allocatedBatchNo}, Exp: {$allocatedExpiry}]";
            }
            $mvtStmt->execute([
                $mvtId, $pItem['product_id'], -$pItem['base_quantity'],
                $receiptNumber, round($pItem['unit_selling_price'] / max(1.0, $pItem['multiplier']), 4),
                $mvtNotes,
                $branchCode
            ]);
        }

        $applyOverpayment = !empty($data['apply_overpayment_to_account']);
        $updatedBalance = null;

        if ($customerId !== 'cust-walkin') {
            if ($paymentMethod === 'CREDIT') {
                $netCreditChange = round($totalAmount - $amountPaid, 2);
                if ($netCreditChange != 0) {
                    $custStmt = $db->prepare("UPDATE customers SET balance = balance + ?, updated_at = datetime('now') WHERE id = ?");
                    $custStmt->execute([$netCreditChange, $customerId]);
                }
            } elseif ($amountPaid < $totalAmount) {
                // Partial payment / underpayment: increase debt
                $unpaidAmount = round($totalAmount - $amountPaid, 2);
                $custStmt = $db->prepare("UPDATE customers SET balance = balance + ?, updated_at = datetime('now') WHERE id = ?");
                $custStmt->execute([$unpaidAmount, $customerId]);
            } elseif ($applyOverpayment && $amountPaid > $totalAmount) {
                // Overpayment applied to account
                $overpayment = round($amountPaid - $totalAmount, 2);
                $custStmt = $db->prepare("UPDATE customers SET balance = balance - ?, updated_at = datetime('now') WHERE id = ?");
                $custStmt->execute([$overpayment, $customerId]);
                $changeDue = 0.0;
                // change_due was stamped with what the drawer would have handed back, and this bill
                // handed nothing back - the money stayed in the till and went onto the account. The
                // row has to say so: a void reads change_due to tell a banked overpayment from one
                // paid across the counter, and cannot tell them apart while both read 100.
                $db->prepare("UPDATE sales SET change_due = 0, updated_at = datetime('now') WHERE id = ?")->execute([$id]);
            }

            $cStmt = $db->prepare("SELECT balance FROM customers WHERE id = ?");
            $cStmt->execute([$customerId]);
            $updatedBalance = round(floatval($cStmt->fetchColumn()), 2);
        }

        // Settled in the same transaction as the money: if the receipt holds, the table frees;
        // if anything above refused, the tab stays exactly where it was and can be paid again.
        $tableFreed = null;
        if ($diningTab !== null) {
            $isCompleteRelease = true;
            if ($targetSeat !== '' && $targetSeat !== 'ALL') {
                // Settle individual seat: mark this seat's items SETTLED
                $updSeat = $db->prepare("UPDATE table_order_items SET kitchen_status = 'SETTLED' WHERE order_id = ? AND seat_number = ? AND kitchen_status != 'SETTLED'");
                $updSeat->execute([$diningTab['id'], $targetSeat]);

                $remStmt = $db->prepare("SELECT COUNT(*) FROM table_order_items WHERE order_id = ? AND kitchen_status != 'SETTLED'");
                $remStmt->execute([$diningTab['id']]);
                $remainingItems = intval($remStmt->fetchColumn());

                if ($remainingItems > 0) {
                    $isCompleteRelease = false;
                    $sumStmt = $db->prepare("SELECT COALESCE(SUM(subtotal), 0.0) FROM table_order_items WHERE order_id = ? AND kitchen_status != 'SETTLED'");
                    $sumStmt->execute([$diningTab['id']]);
                    $remSubtotal = floatval($sumStmt->fetchColumn());
                    $db->prepare("UPDATE table_orders SET subtotal = ?, total_amount = ?, updated_at = datetime('now') WHERE id = ?")
                       ->execute([$remSubtotal, $remSubtotal, $diningTab['id']]);
                }
            } else {
                $db->prepare("UPDATE table_order_items SET kitchen_status = 'SETTLED' WHERE order_id = ?")->execute([$diningTab['id']]);
            }

            if ($isCompleteRelease) {
                // A seat split rewrites the tab's figure down to what is still owed. Once the last
                // party has paid there is nothing owed, and the row is kept as the ticket's own
                // record - so the figure goes back to what the whole ticket held. A closed tab
                // reading 130.00 beside two receipts of 24.00 and 130.00 is a book nobody can
                // reconcile by reading it.
                if ($targetSeat !== '' && $targetSeat !== 'ALL') {
                    $allStmt = $db->prepare("SELECT COALESCE(SUM(subtotal), 0.0) FROM table_order_items WHERE order_id = ?");
                    $allStmt->execute([$diningTab['id']]);
                    $ticketTotal = round(floatval($allStmt->fetchColumn()), 2);
                    $db->prepare("UPDATE table_orders SET subtotal = ?, total_amount = ?, updated_at = datetime('now') WHERE id = ?")
                      ->execute([$ticketTotal, $ticketTotal, $diningTab['id']]);
                }
                if (hospitalityCloseTab($db, (string)$diningTab['id'], (string)$diningTab['table_id'], $id)) {
                    $tableFreed = (string)($diningTab['table_number'] ?? '');
                }
            }
        }

        saleTxCommit($db);

        if ($tableFreed !== null) {
            storeflow_do_action('hospitality_order_settled', $diningTab['id'], $id, $receiptNumber);
            logActivity($db, $userId, $authUser['full_name'], $authUser['role_name'], 'HOSPITALITY_TAB_SETTLED',
                "Settled the tab for Table {$tableFreed} with receipt #{$receiptNumber} and released the table.");
        }

        // Auto-SMS receipt via mNotify if customer has phone and auto_sms is enabled
        $smsSent = false;
        if (!empty($customerId) && $customerId !== 'cust-walkin') {
            try {
                $custPhoneStmt = $db->prepare("SELECT phone FROM customers WHERE id = ?");
                $custPhoneStmt->execute([$customerId]);
                $cPhone = trim($custPhoneStmt->fetchColumn() ?: '');

                $profStmt = $db->query("SELECT mnotify_api_key, mnotify_sender_id, mnotify_auto_sms, currency_symbol, store_name, phone FROM store_profile LIMIT 1");
                $prof = $profStmt->fetch(PDO::FETCH_ASSOC);

                if (!empty($cPhone) && !empty($prof['mnotify_api_key']) && intval($prof['mnotify_auto_sms'] ?? 0) === 1) {
                    require_once __DIR__ . '/sms.php';
                    $cleanPhone = normalizePhoneNumber($cPhone);
                    $curr = $prof['currency_symbol'] ?: 'GHS';
                    $stName = $prof['store_name'] ?: 'Our Store';
                    $smsMsg = "Thanks for shopping at {$stName}!\nReceipt #: {$receiptNumber}\nTotal: {$curr} {$totalAmount}\nPaid: {$paymentMethod}\nVisit us again!";
                    $smsRes = sendStoreSMS($db, $authUser, $prof['mnotify_api_key'], $prof['mnotify_sender_id'] ?: 'StoreFlow', $cleanPhone, $smsMsg, "SMS receipt #{$receiptNumber}");
                    $smsSent = !empty($smsRes['success']);
                }
            } catch (Exception $smsErr) {
                // Background SMS error must never block completed sale
            }
        }

        // Automatic Low Stock Alert via mNotify (to store owner/manager)
        try {
            $profStmt = $db->query("SELECT mnotify_api_key, mnotify_sender_id, mnotify_low_stock_alert, mnotify_owner_phone, phone, store_name FROM store_profile LIMIT 1");
            $prof = $profStmt->fetch(PDO::FETCH_ASSOC);

            if (!empty($prof['mnotify_api_key']) && intval($prof['mnotify_low_stock_alert'] ?? 1) === 1) {
                $ownerPhone = trim($prof['mnotify_owner_phone'] ?? ($prof['phone'] ?? ''));
                if (!empty($ownerPhone)) {
                    $lowStockItems = [];
                    foreach ($processedProducts as $pItem) {
                        $chkStmt = $db->prepare("SELECT p.name, p.sku, p.min_stock_alert, bi.current_quantity 
                                                FROM products p 
                                                LEFT JOIN branch_inventory bi ON bi.product_id = p.id AND bi.branch_code = ?
                                                WHERE p.id = ?");
                        $chkStmt->execute([$branchCode, $pItem['product_id']]);
                        $currRow = $chkStmt->fetch(PDO::FETCH_ASSOC);
                        if ($currRow) {
                            $curQty = floatval($currRow['current_quantity'] ?? 0);
                            $minAlert = floatval($currRow['min_stock_alert'] ?? 5);
                            if ($curQty <= $minAlert) {
                                $lowStockItems[] = [
                                    'id' => $pItem['product_id'],
                                    'name' => $currRow['name'],
                                    'sku' => $currRow['sku'] ?? '',
                                    'current_quantity' => $curQty,
                                    'min_stock_alert' => $minAlert
                                ];
                            }
                        }
                    }

                    if (!empty($lowStockItems)) {
                        require_once __DIR__ . '/sms.php';
                        $cleanOwnerPhone = normalizePhoneNumber($ownerPhone);
                        $sender = $prof['mnotify_sender_id'] ?: 'StoreFlow';
                        $stName = $prof['store_name'] ?: 'StoreFlow';

                        // An alert that re-sends on every sale of an already-low item spends the
                        // owner's credit for news they have already been told, so each branch/SKU
                        // pair gets one alert per quiet period.
                        $db->exec("CREATE TABLE IF NOT EXISTS low_stock_alerts (
                            product_id TEXT NOT NULL,
                            branch_code TEXT NOT NULL,
                            alerted_at TEXT NOT NULL,
                            PRIMARY KEY (product_id, branch_code)
                        )");
                        $alertedStmt = $db->prepare("SELECT product_id, alerted_at FROM low_stock_alerts
                                                     WHERE branch_code = ? AND alerted_at >= ?");
                        $alertedStmt->execute([$branchCode, date('Y-m-d H:i:s', time() - (6 * 3600))]);
                        $recentlyAlerted = [];
                        while ($ar = $alertedStmt->fetch(PDO::FETCH_ASSOC)) {
                            $recentlyAlerted[$ar['product_id']] = $ar['alerted_at'];
                        }

                        $freshLowItems = array_values(array_filter(
                            $lowStockItems,
                            fn($ls) => !isset($recentlyAlerted[$ls['id']])
                        ));

                        if (!empty($freshLowItems)) {
                            $itemLines = "";
                            foreach (array_slice($freshLowItems, 0, 3) as $ls) {
                                $itemLines .= "- {$ls['name']} (Left: {$ls['current_quantity']}, Min: {$ls['min_stock_alert']})\n";
                            }
                            if (count($freshLowItems) > 3) {
                                $itemLines .= "+" . (count($freshLowItems) - 3) . " more items.\n";
                            }
                            $alertMsg = "StoreFlow LOW STOCK ALERT!\nStore: {$stName} ({$branchCode})\nLow stock detected:\n{$itemLines}Please restock soon.";
                            sendStoreSMS($db, $authUser, $prof['mnotify_api_key'], $sender, $cleanOwnerPhone, $alertMsg, 'Low stock alert');

                            $markStmt = $db->prepare("INSERT INTO low_stock_alerts (product_id, branch_code, alerted_at)
                                                      VALUES (?, ?, datetime('now'))
                                                      ON CONFLICT(product_id, branch_code) DO UPDATE SET alerted_at = datetime('now')");
                            foreach ($freshLowItems as $ls) {
                                $markStmt->execute([$ls['id'], $branchCode]);
                            }
                        }
                    }
                }
            }
        } catch (Exception $lowErr) {
            // Must never block completed sale
        }

        logActivity($db, $userId, $authUser['full_name'], $authUser['role_name'], 'SALE_COMPLETED', "Processed sale receipt #{$receiptNumber} for total {$totalAmount} ({$paymentMethod}).");

        // Fire extensible after sale hook for plugins and listeners
        storeflow_do_action('after_sale_completed', $id, $receiptNumber, $totalAmount, $customerId, $authUser);

        $checkoutReceipt = [
            'success' => true,
            'message' => 'Sale processed successfully',
            'sale_id' => $id,
            'receipt_number' => $receiptNumber,
            'total_amount' => $totalAmount,
            'change_due' => $changeDue,
            'customer_balance' => $updatedBalance,
            'loyalty' => $loyaltyResult
        ];
        if ($tableFreed !== null) {
            // The till has been holding the table on screen since the party sat down. It is
            // the server's answer, not the till's own guess, that says the room is free.
            $checkoutReceipt['table_released'] = $tableFreed;
        }
        // What the shop made on the sale is not the cashier's figure to be handed back
        // over the counter, and the till never reads it off this response - the ledger
        // read applies the same strip.
        if (maySeeProductCost($authUser)) {
            $checkoutReceipt['gross_profit'] = $grossProfit;
        }
        jsonResponse($checkoutReceipt, 201);

    } catch (Exception $e) {
        saleTxRollback($db);
        error_log('Sale failed: ' . $e->getMessage() . ' at ' . $e->getFile() . ':' . $e->getLine());
        jsonResponse(['success' => false, 'message' => 'Failed to complete sale: ' . $e->getMessage()], 500);
    }
}

jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
