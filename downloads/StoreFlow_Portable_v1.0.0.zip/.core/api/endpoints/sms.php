<?php
// api/endpoints/sms.php
// Send digital SMS receipts & notifications via mNotify SMS Gateway (Ghana / West Africa)
require_once __DIR__ . '/../config/db.php';

// Ensure mNotify columns exist in store_profile
try {
    $cols = $db->query("PRAGMA table_info(store_profile)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('mnotify_api_key', $cols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN mnotify_api_key TEXT DEFAULT ''");
    }
    if (!in_array('mnotify_sender_id', $cols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN mnotify_sender_id TEXT DEFAULT 'StoreFlow'");
    }
    if (!in_array('mnotify_auto_sms', $cols)) {
        $db->exec("ALTER TABLE store_profile ADD COLUMN mnotify_auto_sms INTEGER DEFAULT 0");
    }
} catch (Exception $e) {
    // Ignore schema check errors
}

// Outbound SMS throttling constants
if (!defined('SMS_USER_WINDOW_MINUTES')) define('SMS_USER_WINDOW_MINUTES', 10);
if (!defined('SMS_USER_WINDOW_LIMIT')) define('SMS_USER_WINDOW_LIMIT', 40);
if (!defined('SMS_STORE_WINDOW_MINUTES')) define('SMS_STORE_WINDOW_MINUTES', 60);
if (!defined('SMS_STORE_LIMIT')) define('SMS_STORE_LIMIT', 200);

$isDirectAccess = (basename($_SERVER['SCRIPT_FILENAME'] ?? '') === 'sms.php');
if ($isDirectAccess) {

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'POST') {
    $authUser = requireAuth();
    $input = json_decode(file_get_contents('php://input'), true);

    if (!$input) {
        jsonResponse(['success' => false, 'message' => 'Invalid request payload.'], 400);
    }

    $action = $input['action'] ?? 'send_receipt';

    // Fetch store profile for mNotify settings
    $stmt = $db->query("SELECT * FROM store_profile LIMIT 1");
    $profile = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

    // Sending SMS spends the owner's provider credit, so the stored credentials are the
    // only ones a normal send may use. The settings screen legitimately tests a key that
    // has not been saved yet, which is why the override exists — but it is confined to
    // test_sms and to holders of manage_settings, so a cashier cannot redirect traffic
    // through a key or sender ID of their choosing.
    $canManageSmsSettings = hasPermission($authUser, 'manage_settings');

    $apiKey   = trim($profile['mnotify_api_key'] ?? '');
    $senderId = trim($profile['mnotify_sender_id'] ?? 'StoreFlow');

    if ($action === 'test_sms') {
        if (!$canManageSmsSettings) {
            jsonResponse(['success' => false, 'message' => 'Forbidden: testing the SMS gateway requires the Manage Settings permission.'], 403);
        }
        $postedKey = trim($input['api_key'] ?? '');
        if ($postedKey !== '' && $postedKey !== '********') {
            $apiKey = $postedKey;
        }
        $postedSender = trim($input['sender_id'] ?? '');
        if ($postedSender !== '') {
            $senderId = $postedSender;
        }
    }

    if (empty($senderId)) $senderId = 'StoreFlow';
    // mNotify sender ID must be <= 11 characters alphanumeric
    $senderId = substr(preg_replace('/[^a-zA-Z0-9]/', '', $senderId), 0, 11);

    if (empty($apiKey)) {
        jsonResponse([
            'success' => false, 
            'message' => 'mNotify API key is not configured. Please enter your mNotify API key in Store Settings.'
        ], 400);
    }

    // Every message spends the owner's provider credit, so sends are counted and capped
    // here rather than trusted to the UI. The counter is shared with the automatic receipts
    // in sales/returns/customers: one budget, whichever door the message came through.
    try {
        if (smsSpendCount($db, SMS_STORE_WINDOW_MINUTES) >= SMS_STORE_LIMIT) {
            jsonResponse([
                'success' => false,
                'message' => "Store send ceiling reached (" . SMS_STORE_LIMIT . ' messages per ' . SMS_STORE_WINDOW_MINUTES . ' minutes). Please wait before sending more.'
            ], 429);
        }
        if (smsSpendCount($db, SMS_USER_WINDOW_MINUTES, $authUser['id'] ?? 1) >= SMS_USER_WINDOW_LIMIT) {
            jsonResponse([
                'success' => false,
                'message' => "Send limit reached (" . SMS_USER_WINDOW_LIMIT . ' messages per ' . SMS_USER_WINDOW_MINUTES . ' minutes). Please wait before sending more.'
            ], 429);
        }
        logActivity($db, $authUser['id'] ?? null, $authUser['full_name'] ?? null, $authUser['role_name'] ?? null,
            'SMS_DISPATCH', "SMS action '{$action}' dispatched to " . trim((string)($input['recipient'] ?? '')));
    } catch (Exception $sendEx) {
        error_log("SMS send audit error: " . $sendEx->getMessage());
    }

    // --- TEST SMS ACTION ---
    if ($action === 'test_sms') {
        $recipient = trim($input['recipient'] ?? '');
        if (empty($recipient)) {
            jsonResponse(['success' => false, 'message' => 'Please provide a recipient phone number for the test SMS.'], 400);
        }

        $cleanPhone = normalizePhoneNumber($recipient);
        $testMsg = "StoreFlow SMS Test: Your mNotify SMS integration is successfully configured! Sender: {$senderId}.";

        $res = callMNotifySMS($apiKey, $senderId, $cleanPhone, $testMsg);
        if ($res['success']) {
            jsonResponse([
                'success' => true,
                'message' => "Test SMS sent successfully to {$cleanPhone}!",
                'provider_response' => $res['data']
            ]);
        } else {
            jsonResponse([
                'success' => false,
                'message' => "mNotify error: " . ($res['error'] ?? 'Failed to send SMS.'),
                'provider_response' => $res['data'] ?? null
            ], 400);
        }
    }

    // --- SEND RECEIPT SMS ACTION ---
    if ($action === 'send_receipt') {
        $recipient = trim($input['recipient'] ?? '');
        $receiptNumber = trim($input['receipt_number'] ?? '');
        $totalAmount = trim($input['total_amount'] ?? '');
        $currency = trim($profile['currency_symbol'] ?? 'GHS');
        $storeName = trim($profile['store_name'] ?? 'Our Store');
        // A caller-supplied body turns the store's sender ID into a free-text relay, so
        // only settings holders may override the generated receipt text.
        $customMessage = $canManageSmsSettings ? trim($input['message'] ?? '') : '';

        if (empty($recipient)) {
            jsonResponse(['success' => false, 'message' => 'Recipient phone number is required.'], 400);
        }

        $cleanPhone = normalizePhoneNumber($recipient);

        if (!empty($customMessage)) {
            $msg = $customMessage;
        } else {
            // Build standardized compact SMS receipt
            $date = date('d-M-Y H:i');
            $msg = "Thanks for shopping at {$storeName}!\n"
                 . "Receipt #: {$receiptNumber}\n"
                 . "Date: {$date}\n"
                 . "Total: {$currency} {$totalAmount}\n";

            if (!empty($input['payment_method'])) {
                $msg .= "Paid via: " . strtoupper($input['payment_method']) . "\n";
            }
            if (!empty($profile['phone'])) {
                $msg .= "Queries: {$profile['phone']}\n";
            }
            $msg .= "Visit us again!";
        }

        $res = callMNotifySMS($apiKey, $senderId, $cleanPhone, $msg);
        if ($res['success']) {
            logActivity($db, $authUser['id'] ?? null, $authUser['full_name'] ?? null, $authUser['role_name'] ?? null,
                'SMS_RECEIPT_SENT', "Sent SMS receipt for {$receiptNumber} to {$cleanPhone} via mNotify");

            jsonResponse([
                'success' => true,
                'message' => "SMS receipt sent successfully to {$cleanPhone}!",
                'provider_response' => $res['data']
            ]);
        } else {
            jsonResponse([
                'success' => false,
                'message' => "mNotify delivery failed: " . ($res['error'] ?? 'Unknown gateway error.'),
                'provider_response' => $res['data'] ?? null
            ], 400);
        }
    }

    // --- SEND DEBT PAYMENT RECEIPT SMS ---
    if ($action === 'send_debt_receipt') {
        $recipient = trim($input['recipient'] ?? '');
        $customerName = trim($input['customer_name'] ?? 'Valued Customer');
        $receiptNumber = trim($input['receipt_number'] ?? '');
        $amountPaid = trim($input['amount_paid'] ?? '0.00');
        $prevBalance = trim($input['prev_balance'] ?? '0.00');
        $newBalance = trim($input['new_balance'] ?? '0.00');
        $payMethod = strtoupper(trim($input['payment_method'] ?? 'CASH'));
        $currency = trim($profile['currency_symbol'] ?? 'GHS');
        $storeName = trim($profile['store_name'] ?? 'StoreFlow');

        if (empty($recipient)) {
            jsonResponse(['success' => false, 'message' => 'Recipient phone number is required.'], 400);
        }

        $cleanPhone = normalizePhoneNumber($recipient);
        $date = date('d-M-Y H:i');

        $isCleared = floatval($newBalance) <= 0;
        $balanceText = $isCleared ? "CLEARED ($0.00)" : "{$currency} {$newBalance}";

        $msg = "Debt Payment Received!\n"
             . "Store: {$storeName}\n"
             . "Customer: {$customerName}\n"
             . "Receipt #: {$receiptNumber}\n"
             . "Amount Paid: {$currency} {$amountPaid} ({$payMethod})\n"
             . "Previous Balance: {$currency} {$prevBalance}\n"
             . "Remaining Balance: {$balanceText}\n"
             . "Date: {$date}\n"
             . "Thank you for your prompt payment!";

        $res = callMNotifySMS($apiKey, $senderId, $cleanPhone, $msg);
        if ($res['success']) {
            jsonResponse([
                'success' => true,
                'message' => "Debt payment SMS receipt sent successfully to {$cleanPhone}!",
                'provider_response' => $res['data']
            ]);
        } else {
            jsonResponse([
                'success' => false,
                'message' => "mNotify error: " . ($res['error'] ?? 'Failed to send SMS.'),
                'provider_response' => $res['data'] ?? null
            ], 400);
        }
    }

    // --- SEND SHIFT CLOSING Z-REPORT SMS (TO STORE OWNER) ---
    if ($action === 'send_shift_summary') {
        $recipient = trim($input['recipient'] ?? ($profile['mnotify_owner_phone'] ?? ($profile['phone'] ?? '')));
        if (empty($recipient)) {
            jsonResponse(['success' => false, 'message' => 'Owner phone number is not configured in Store Settings.'], 400);
        }

        $branchCode = strtoupper(trim($input['branch_code'] ?? ($profile['branch_code'] ?? 'MAIN-01')));
        $terminalId = strtoupper(trim($input['terminal_id'] ?? 'REG-01'));
        $shiftNumber = trim($input['shift_number'] ?? '');

        // The note the owner reads has to be the shop's arithmetic. What the close left on the
        // book wins; where no close has landed yet (a drawer still being counted, or one queued
        // while the till was offline) the payouts are read off the book the same way shifts.php
        // reads them before it stores the row. Taking expected cash and the variance as typed
        // meant the one message that should disagree with a dishonest till could not.
        $bookDate = shiftSummaryBookDate($input, $shiftNumber);
        $figures = shiftSummaryFigures($db, $input, $bookDate, $terminalId, $branchCode);
        $cleanPhone = normalizePhoneNumber($recipient);

        $msg = buildShiftSummaryNote($figures, $profile);

        $res = callMNotifySMS($apiKey, $senderId, $cleanPhone, $msg);
        if ($res['success']) {
            jsonResponse([
                'success' => true,
                'message' => "Z-Report shift summary sent successfully to {$cleanPhone}!",
                'provider_response' => $res['data']
            ]);
        } else {
            jsonResponse([
                'success' => false,
                'message' => "mNotify error: " . ($res['error'] ?? 'Failed to send shift summary SMS.'),
                'provider_response' => $res['data'] ?? null
            ], 400);
        }
    }

    // --- SEND LOW STOCK SMS ALERT ---
    if ($action === 'send_low_stock_alert') {
        $recipient = trim($input['recipient'] ?? ($profile['mnotify_owner_phone'] ?? ($profile['phone'] ?? '')));
        if (empty($recipient)) {
            jsonResponse(['success' => false, 'message' => 'Notification phone number is not configured.'], 400);
        }

        $items = $input['items'] ?? [];
        $branchCode = trim($input['branch_code'] ?? 'MAIN-01');
        $storeName = trim($profile['store_name'] ?? 'StoreFlow');
        $cleanPhone = normalizePhoneNumber($recipient);

        if (empty($items)) {
            jsonResponse(['success' => false, 'message' => 'No low stock items provided.'], 400);
        }

        $itemListStr = '';
        foreach (array_slice($items, 0, 4) as $it) {
            $name = $it['name'] ?? 'Product';
            $qty = $it['current_quantity'] ?? 0;
            $min = $it['min_stock_alert'] ?? 5;
            $itemListStr .= "- {$name} (Left: {$qty}, Reorder: {$min})\n";
        }
        if (count($items) > 4) {
            $extra = count($items) - 4;
            $itemListStr .= "+{$extra} more items below alert level.\n";
        }

        $msg = "StoreFlow LOW STOCK ALERT!\n"
             . "Store: {$storeName} ({$branchCode})\n"
             . "The following item(s) are running out:\n"
             . $itemListStr
             . "Please place supplier purchase orders.";

        $res = callMNotifySMS($apiKey, $senderId, $cleanPhone, $msg);
        if ($res['success']) {
            jsonResponse([
                'success' => true,
                'message' => "Low stock alert SMS sent successfully to {$cleanPhone}!",
                'provider_response' => $res['data']
            ]);
        } else {
            jsonResponse([
                'success' => false,
                'message' => "mNotify error: " . ($res['error'] ?? 'Failed to send alert.'),
                'provider_response' => $res['data'] ?? null
            ], 400);
        }
    }

    // --- SEND RETURN / REFUND CREDIT NOTE SMS ---
    if ($action === 'send_return_receipt') {
        $recipient = trim($input['recipient'] ?? '');
        if (empty($recipient)) {
            jsonResponse(['success' => false, 'message' => 'Customer phone number is required.'], 400);
        }

        $cleanPhone = normalizePhoneNumber($recipient);
        $customerName = trim($input['customer_name'] ?? 'Customer');
        $returnNumber = trim($input['return_number'] ?? '');
        $origReceipt = trim($input['receipt_number'] ?? '');
        $totalRefund = trim($input['total_refund'] ?? '0.00');
        $refundMethod = strtoupper(trim($input['refund_method'] ?? 'CASH'));
        $currency = trim($profile['currency_symbol'] ?? 'GHS');
        $storeName = trim($profile['store_name'] ?? 'StoreFlow');
        $itemsSummary = trim($input['items_summary'] ?? 'Items');

        $msg = "StoreFlow Return Receipt\n"
             . "Store: {$storeName}\n"
             . "Hello {$customerName},\n"
             . "Return Slip #: {$returnNumber}\n"
             . "Original Sale #: {$origReceipt}\n"
             . "Items: {$itemsSummary}\n"
             . "Refund Issued: {$currency} {$totalRefund} via {$refundMethod}\n"
             . "Date: " . date('d-M-Y H:i') . "\n"
             . "We appreciate your patronage!";

        $res = callMNotifySMS($apiKey, $senderId, $cleanPhone, $msg);
        if ($res['success']) {
            jsonResponse([
                'success' => true,
                'message' => "Return receipt SMS sent successfully to {$cleanPhone}!",
                'provider_response' => $res['data']
            ]);
        } else {
            jsonResponse([
                'success' => false,
                'message' => "mNotify error: " . ($res['error'] ?? 'Failed to send return SMS.'),
                'provider_response' => $res['data'] ?? null
            ], 400);
        }
    }

    jsonResponse(['success' => false, 'message' => 'Unrecognized SMS action.'], 400);
}

// GET: Return current SMS configuration status
if ($method === 'GET') {
    // The owner's phone number and the shape of the provider key are settings-page
    // material; a cashier unlocking the till has no reason to read either.
    $authUser = requirePermission('manage_settings');
    $stmt = $db->query("SELECT mnotify_api_key, mnotify_sender_id, mnotify_auto_sms, mnotify_owner_phone, mnotify_low_stock_alert, mnotify_shift_close_alert, phone FROM store_profile LIMIT 1");
    $conf = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
    
    // Mask API key for security. Showing the first four and last four is only a
    // hint once the key is short: an 8-character key arrived in full, and keys of
    // that length are what the seeded configs use.
    $hasKey = !empty($conf['mnotify_api_key']);
    $maskedKey = '';
    if ($hasKey) {
        $keyLen = strlen($conf['mnotify_api_key']);
        if ($keyLen <= 12) {
            $maskedKey = str_repeat('*', $keyLen);
        } else {
            $maskedKey = substr($conf['mnotify_api_key'], 0, 4) . str_repeat('*', $keyLen - 8) . substr($conf['mnotify_api_key'], -4);
        }
    }

    jsonResponse([
        'success' => true,
        'configured' => $hasKey,
        'masked_api_key' => $maskedKey,
        'sender_id' => $conf['mnotify_sender_id'] ?? 'StoreFlow',
        'auto_sms' => intval($conf['mnotify_auto_sms'] ?? 0) === 1,
        'owner_phone' => $conf['mnotify_owner_phone'] ?? ($conf['phone'] ?? ''),
        'low_stock_alert' => intval($conf['mnotify_low_stock_alert'] ?? 1) === 1,
        'shift_close_alert' => intval($conf['mnotify_shift_close_alert'] ?? 1) === 1
    ]);
}
} // End if ($isDirectAccess)

/**
 * The day a Z-note scopes its drawer to, in the book's own Y-m-d.
 *
 * The close screen hands over the date in the browser's locale, and 04/11/2026 is a Tuesday in
 * one shop and a Thursday in the next, so a slash-dated string is never read as a book date.
 * The note falls back to today rather than to a guess: the seams scope a real drawer, and a
 * drawer scoped to the wrong day reports somebody else's payouts.
 */
function shiftSummaryBookDate(array $input, string $shiftNumber): string
{
    $iso = trim((string)($input['shift_date_iso'] ?? ''));
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $iso) === 1) {
        return $iso;
    }

    if (preg_match('/^SHIFT-(\d{8})-/i', trim($shiftNumber), $m) === 1) {
        $fromNumber = DateTime::createFromFormat('!Ymd', $m[1]);
        if ($fromNumber !== false && $fromNumber->format('Ymd') === $m[1]) {
            return $fromNumber->format('Y-m-d');
        }
    }

    $shown = trim((string)($input['shift_date'] ?? ''));
    foreach (['Y-m-d', 'd-M-Y'] as $fmt) {
        $parsed = DateTime::createFromFormat($fmt, $shown);
        if ($parsed !== false && $parsed->format($fmt) === $shown) {
            return $parsed->format('Y-m-d');
        }
    }

    return date('Y-m-d');
}

/**
 * The figures a Z-note is composed from, read off the shop's book.
 *
 * A close that has landed (shift_number is UNIQUE in register_shifts, so it names one document)
 * is the paper the shopkeeper signed for, and the note repeats it. A close that has not landed
 * - the summary sent while the drawer is still being counted, or a shift still sitting in the
 * outbox after an offline day - is rebuilt from the same seams shifts.php uses before it stores
 * the row: petty cash paid out, cash handed back over credit notes, rental collections.
 *
 * The till's expected cash and variance are not read at all. They are arithmetic over the
 * payouts, and the hand that owes the difference is the hand that would be typing it.
 */
function shiftSummaryFigures(PDO $db, array $input, string $bookDate, string $terminalId, string $branchCode): array
{
    $shiftNumber = trim((string)($input['shift_number'] ?? ''));
    $row = null;
    if ($shiftNumber !== '') {
        try {
            $stmt = $db->prepare("SELECT * FROM register_shifts WHERE shift_number = ?");
            $stmt->execute([$shiftNumber]);
            $found = $stmt->fetch(PDO::FETCH_ASSOC);
            $stmt = null;
            $row = is_array($found) ? $found : null;
        } catch (Throwable $e) {
            error_log('StoreFlow: stored close not readable for the Z-note - ' . $e->getMessage());
        }
    }

    if ($row !== null) {
        return [
            'source'          => 'shift',
            'operator'        => trim((string)($row['cashier_name'] ?? 'Cashier')),
            'shift_number'    => $shiftNumber,
            'branch_code'     => strtoupper(trim((string)($row['branch_code'] ?? $branchCode))) ?: $branchCode,
            'terminal_id'     => strtoupper(trim((string)($row['terminal_id'] ?? $terminalId))) ?: $terminalId,
            'date_display'    => trim((string)($row['shift_date'] ?? $bookDate)),
            'time_display'    => substr(trim((string)($row['shift_time'] ?? '')), 0, 8),
            'gross_sales'     => floatval($row['total_sales_gross'] ?? 0),
            'cash_sales'      => floatval($row['cash_sales'] ?? 0),
            'non_cash'        => floatval($row['card_sales'] ?? 0) + floatval($row['transfer_sales'] ?? 0),
            'debt_cash'       => floatval($row['debt_cash_collected'] ?? 0),
            'rental_cash'     => floatval($row['rental_cash_collected'] ?? 0),
            'caution_refunded'=> floatval($row['rental_caution_refunded'] ?? 0),
            'drawer_expenses' => floatval($row['drawer_expenses'] ?? 0),
            'cash_refunds_paid' => floatval($row['cash_refunds_paid'] ?? 0),
            'opening_float'   => floatval($row['opening_float'] ?? 0),
            'expected_cash'   => floatval($row['expected_cash'] ?? 0),
            'counted_cash'    => floatval($row['counted_cash'] ?? 0),
            'variance'        => floatval($row['variance'] ?? 0),
            'voided_count'    => max(0, intval($row['voided_count'] ?? 0)),
            'voided_value'    => floatval($row['voided_value'] ?? 0),
            'notes'           => trim((string)($row['notes'] ?? '')),
        ];
    }

    $expenses = shiftDrawerExpensesPaid($db, $terminalId, $branchCode, $bookDate);
    $refunds  = shiftCashRefundsPaid($db, $terminalId, $branchCode, $bookDate);
    $rentals  = shiftRentalFigures($db, $terminalId, $branchCode, $bookDate);

    $calc = shiftFigures([
        'opening_float'           => $input['opening_float'] ?? 0,
        'cash_sales'              => $input['cash_sales'] ?? 0,
        'debt_cash_collected'     => $input['debt_cash'] ?? 0,
        'rental_cash_collected'   => $rentals['rental_cash_collected'],
        'rental_caution_refunded' => $rentals['rental_caution_refunded'],
        'drawer_expenses'         => $expenses,
        'cash_refunds_paid'       => $refunds,
        'counted_cash'            => $input['counted_cash'] ?? 0,
        'voided_count'            => $input['voided_count'] ?? 0,
        'voided_value'            => $input['voided_value'] ?? 0,
    ]);

    $shownDate = trim((string)($input['shift_date'] ?? ''));

    return [
        'source'          => 'book',
        'operator'        => trim((string)($input['cashier_name'] ?? 'Cashier')),
        'shift_number'    => $shiftNumber,
        'branch_code'     => $branchCode,
        'terminal_id'     => $terminalId,
        // An owner reading a date off a phone should not have to know the till's browser locale.
        'date_display'    => preg_match('/^\d{4}-\d{2}-\d{2}/', $shownDate) === 1 ? $shownDate : $bookDate,
        'time_display'    => substr(trim((string)($input['shift_time'] ?? '')), 0, 8),
        'gross_sales'     => floatval($input['total_sales'] ?? 0),
        'cash_sales'      => $calc['cash_sales'],
        'non_cash'        => floatval($input['card_transfer'] ?? 0),
        'debt_cash'       => $calc['debt_cash_collected'],
        'rental_cash'     => $calc['rental_cash_collected'],
        'caution_refunded'=> $calc['rental_caution_refunded'],
        'drawer_expenses' => $calc['drawer_expenses'],
        'cash_refunds_paid' => $calc['cash_refunds_paid'],
        'opening_float'   => $calc['opening_float'],
        'expected_cash'   => $calc['expected_cash'],
        'counted_cash'    => $calc['counted_cash'],
        'variance'        => $calc['variance'],
        'voided_count'    => $calc['voided_count'],
        'voided_value'    => $calc['voided_value'],
        'notes'           => trim((string)($input['notes'] ?? '')),
    ];
}

/**
 * The owner's Z-note. Every line that moves the box is named, in the same words the thermal roll
 * uses, so the cedi between "Cash Sales" and "Expected" is traceable on the paper instead of
 * being read as a shortage the cashier caused. A line is left out only when the book holds none
 * of it, because a paid-for SMS is metered by the character.
 */
function buildShiftSummaryNote(array $f, array $profile): string
{
    $currency = trim((string)($profile['currency_symbol'] ?? 'GHS'));
    $money = static function ($v): string {
        return number_format(round(floatval($v), 2), 2, '.', ',');
    };

    $lines = [
        'StoreFlow Z-Report: Shift Closed',
        'Store: ' . trim((string)($profile['store_name'] ?? 'StoreFlow'))
            . ' (' . $f['branch_code'] . '/' . $f['terminal_id'] . ')',
        'Operator: ' . $f['operator'],
    ];
    if ($f['shift_number'] !== '') {
        $lines[] = 'Shift #: ' . $f['shift_number'];
    }
    $lines[] = 'Date: ' . $f['date_display'] . ($f['time_display'] !== '' ? ' ' . $f['time_display'] : '');
    $lines[] = 'Gross Sales: ' . $currency . ' ' . $money($f['gross_sales']);
    $lines[] = 'Cash Sales: ' . $currency . ' ' . $money($f['cash_sales']);

    if ($f['debt_cash'] > 0.005) {
        $lines[] = 'Debt Cash In: +' . $currency . ' ' . $money($f['debt_cash']);
    }
    if ($f['rental_cash'] > 0.005) {
        $lines[] = 'Rental Cash In: +' . $currency . ' ' . $money($f['rental_cash']);
    }
    if ($f['drawer_expenses'] > 0.005) {
        $lines[] = 'Drawer Expenses: -' . $currency . ' ' . $money($f['drawer_expenses']);
    }
    if ($f['cash_refunds_paid'] > 0.005) {
        $lines[] = 'Refunds Paid Out: -' . $currency . ' ' . $money($f['cash_refunds_paid']);
    }
    if ($f['caution_refunded'] > 0.005) {
        $lines[] = 'Caution Refunded: -' . $currency . ' ' . $money($f['caution_refunded']);
    }

    $lines[] = 'Drawer Cash: ' . $currency . ' ' . $money($f['counted_cash'])
             . ' (Expected: ' . $currency . ' ' . $money($f['expected_cash'] + $f['opening_float']) . ')';
    $lines[] = 'Non-Cash Sales: ' . $currency . ' ' . $money($f['non_cash']);

    if ($f['voided_count'] > 0) {
        $lines[] = 'Voided: ' . $f['voided_count'] . ' receipt(s) (' . $currency . ' '
                 . $money($f['voided_value']) . ') - cash handed back, goods restocked';
    }

    $variance = round(floatval($f['variance']), 2);
    $lines[] = 'Status: ' . (abs($variance) < 0.01
        ? 'BALANCED'
        : ($variance > 0 ? 'SURPLUS (+' . $currency . ' ' . $money($variance) . ')'
                         : 'SHORTAGE (-' . $currency . ' ' . $money(abs($variance)) . ')'));

    if ($f['notes'] !== '') {
        // Metered like everything else in the message: the full note is on the slip and in the book.
        $lines[] = 'Notes: "' . (mb_strlen($f['notes']) > 120 ? mb_substr($f['notes'], 0, 119) . '…' : $f['notes']) . '"';
    }

    return implode("\n", $lines);
}

/**
 * Normalizes phone numbers (handles Ghana local formats e.g. 024XXXXXXX, 24XXXXXXX, +23324XXXXXXX -> 024XXXXXXX or 23324XXXXXXX)
 */
function normalizePhoneNumber($phone) {
    $clean = preg_replace('/[^0-9]/', '', $phone);
    // If starts with 0 and 10 digits (Ghana standard e.g. 0244123456)
    if (strlen($clean) === 10 && substr($clean, 0, 1) === '0') {
        return '233' . substr($clean, 1);
    }
    // If 9 digits (e.g. 244123456)
    if (strlen($clean) === 9) {
        return '233' . $clean;
    }
    // If already 233...
    if (substr($clean, 0, 3) === '233') {
        return $clean;
    }
    return $clean;
}

/**
 * Locate a CA bundle for cURL. The bundled runtime ships its own php.ini without
 * curl.cainfo, and Windows PHP has no system trust store to fall back on, so
 * verification needs the file named explicitly.
 */
function smsCaBundlePath() {
    $candidates = [
        getenv('STOREFLOW_CA_BUNDLE') ?: '',
        dirname(__DIR__, 2) . '/php/cacert.pem',
        dirname(__DIR__, 2) . '/cacert.pem',
        (string)ini_get('curl.cainfo'),
        (string)ini_get('openssl.cafile'),
    ];
    foreach ($candidates as $path) {
        if ($path !== '' && is_file($path) && is_readable($path)) return $path;
    }
    return null;
}

// Every outbound message spends the store's provider credit. The per-user ceiling stops one
// operator hammering the send button; the store-wide ceiling stops a busy till (or a script
// cycling staff accounts) from spending past what the owner budgeted for an hour. Automatic
// receipts used to call the gateway directly and counted against neither.
if (!defined('SMS_USER_WINDOW_MINUTES')) define('SMS_USER_WINDOW_MINUTES', 10);
if (!defined('SMS_USER_WINDOW_LIMIT')) define('SMS_USER_WINDOW_LIMIT', 40);
if (!defined('SMS_STORE_WINDOW_MINUTES')) define('SMS_STORE_WINDOW_MINUTES', 60);
if (!defined('SMS_STORE_LIMIT')) define('SMS_STORE_LIMIT', 200);

// activity_logs.created_at is formatted by PHP in the store's timezone, so the window bound
// has to come from the same clock. Comparing it with SQLite's UTC datetime('now') shifted the
// window by the store's timezone offset, and a store behind UTC could send without a limit.
function smsSpendCount(PDO $db, int $windowMinutes, $userId = null): int {
    $sql = "SELECT COUNT(*) FROM activity_logs WHERE action_type = 'SMS_DISPATCH' AND created_at >= ?";
    $args = [date('Y-m-d H:i:s', time() - ($windowMinutes * 60))];
    if ($userId !== null) {
        $sql .= " AND user_id = ?";
        $args[] = intval($userId);
    }
    $stmt = $db->prepare($sql);
    $stmt->execute($args);
    return intval($stmt->fetchColumn() ?: 0);
}

/**
 * The only path an automatic (server-initiated) message should take: it charges the shared
 * spend budget, records the dispatch, then hands off to the gateway.
 */
function sendStoreSMS(PDO $db, $user, string $apiKey, string $senderId, string $phone, string $message, string $note = 'Automatic SMS'): array {
    $userId = intval(is_array($user) ? ($user['id'] ?? 1) : ($user ?: 1));
    $userName = is_array($user) ? ($user['full_name'] ?? 'Staff') : 'Staff';
    $roleName = is_array($user) ? ($user['role_name'] ?? 'Staff') : 'Staff';

    $blocked = static function (string $reason) use ($db, $userId, $userName, $roleName, $note, $phone): array {
        logActivity($db, $userId, $userName, $roleName, 'SMS_BLOCKED', "{$note} to {$phone} withheld: {$reason}");
        return ['success' => false, 'blocked' => true, 'error' => $reason];
    };

    if (smsSpendCount($db, SMS_STORE_WINDOW_MINUTES) >= SMS_STORE_LIMIT) {
        return $blocked("the store's ceiling of " . SMS_STORE_LIMIT . ' messages per ' . SMS_STORE_WINDOW_MINUTES . ' minutes');
    }
    if (smsSpendCount($db, SMS_USER_WINDOW_MINUTES, $userId) >= SMS_USER_WINDOW_LIMIT) {
        return $blocked("this account's ceiling of " . SMS_USER_WINDOW_LIMIT . ' messages per ' . SMS_USER_WINDOW_MINUTES . ' minutes');
    }

    // Counted before the gateway call: a message the provider rejects still cost a request,
    // and a slow or failing gateway must not let an unbounded queue through.
    logActivity($db, $userId, $userName, $roleName, 'SMS_DISPATCH', "{$note} dispatched to {$phone}");
    $res = callMNotifySMS($apiKey, $senderId, $phone, $message);
    return is_array($res) ? ($res + ['blocked' => false]) : ['success' => false, 'blocked' => false, 'error' => 'No gateway response'];
}

/**
 * Dispatch HTTP request to mNotify Quick SMS endpoint
 */
function callMNotifySMS($apiKey, $senderId, $recipient, $message) {
    // mNotify API v2 endpoint
    $url = "https://api.mnotify.com/api/sms/quick?key=" . urlencode($apiKey);

    $payload = [
        'recipient' => [$recipient],
        'sender' => $senderId,
        'message' => $message,
        'is_schedule' => 'false',
        'schedule_date' => ''
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Accept: application/json'
    ]);
    // Verification used to be switched off "for XAMPP compatibility". The request
    // carries the SMS provider key, so an off switch let anyone on the network
    // impersonate api.mnotify.com and capture it.
    $caBundle = smsCaBundlePath();
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
    if ($caBundle !== null) curl_setopt($ch, CURLOPT_CAINFO, $caBundle);

    $response = curl_exec($ch);
    $curlError = curl_error($ch);
    $curlErrNo = curl_errno($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($curlError) {
        // CURLE_SSL_* (35,51,58,60,61,62,63,77,79,83,90): the chain could not be
        // validated. Say what to do about it instead of a bare "cURL error 60".
        if (in_array($curlErrNo, [35, 51, 58, 60, 61, 62, 63, 77, 79, 83, 90], true)) {
            $hint = $caBundle === null
                ? 'No CA bundle was found. Place a cacert.pem next to the bundled PHP runtime (php/cacert.pem) or set STOREFLOW_CA_BUNDLE.'
                : 'The CA bundle in use (' . $caBundle . ') could not validate the certificate; it is probably outdated.';
            return ['success' => false, 'error' => "TLS certificate for api.mnotify.com could not be verified: {$curlError}. {$hint}"];
        }
        return ['success' => false, 'error' => "cURL connection error: {$curlError}"];
    }

    $json = json_decode($response, true);
    if (!$json) {
        return ['success' => false, 'error' => "Raw server response: {$response} (HTTP {$httpCode})"];
    }

    // mNotify returns status 'success' or code '2000'
    $status = strtolower($json['status'] ?? '');
    $code = strval($json['code'] ?? '');

    if ($status === 'success' || $code === '2000' || ($httpCode >= 200 && $httpCode < 300 && $status !== 'error')) {
        return ['success' => true, 'data' => $json];
    }

    $errMsg = $json['message'] ?? ($json['error'] ?? 'Failed to deliver SMS via mNotify');
    return ['success' => false, 'error' => $errMsg, 'data' => $json];
}
