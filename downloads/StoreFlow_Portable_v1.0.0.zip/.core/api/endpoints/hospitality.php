<?php
// api/endpoints/hospitality.php
// StoreFlow Hospitality & Food/Beverage (F&B) module: the dining floor, the tab open on a
// table, and the kitchen tickets fired at it.
//
// This endpoint never writes a receipt. A tab is what the kitchen was told to make; the money
// is authored at the counter by sales.php, which is the only place that knows about lots,
// stock floors, tax, the discount cap and loyalty. The checkout that carries a
// table_order_id closes the tab here (see api/config/hospitality_tab.php), so a table frees
// exactly when the bill for it is booked - online or from an offline queue a day later.

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/product_units.php';
require_once __DIR__ . '/../config/hospitality_tab.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$action = trim($_GET['action'] ?? 'tables');

// The floor belongs to a branch. A manager may ask for another one; everyone else sees the
// room they work in, so a waiter cannot seat, read or empty a table in a shop they are not in.
function hospitalityScope(array $user, array $data = []): array {
    $requested = (string)($data['branch_code'] ?? ($_GET['branch_code'] ?? ''));
    $branchCode = hospitalityBranchScope($user, $requested);
    $role = strtolower(trim((string)($user['role_name'] ?? '')));
    return [$branchCode, $role === 'administrator' || intval($user['role_id'] ?? 0) === 1];
}

// -------------------------------------------------------------
// 1. GET /api/endpoints/hospitality.php?action=tables
// The floor: every table, who is sitting at it, and what the tab is holding so far.
// -------------------------------------------------------------
if ($method === 'GET' && $action === 'tables') {
    $user = requireAuth();
    [$branchCode, $isManager] = hospitalityScope($user);

    $where = '';
    $args = [];
    if (!$isManager) {
        $where = "WHERE t.branch_code = ?";
        $args[] = $branchCode;
    } elseif ($branchCode !== 'ALL') {
        $where = "WHERE t.branch_code = ?";
        $args[] = $branchCode;
    }

    $stmt = $db->prepare("SELECT t.*, o.guest_count, o.server_name, o.status AS tab_status,
                                 o.total_amount AS current_bill_total, o.opened_at AS order_opened_at,
                                 o.kot_number AS latest_kot
                          FROM dining_tables t
                          LEFT JOIN table_orders o ON t.active_order_id = o.id
                          {$where}
                          ORDER BY t.zone_name ASC, t.table_number ASC");
    $stmt->execute($args);

    jsonResponse([
        'success' => true,
        'tables' => $stmt->fetchAll(),
        'branch_code' => $branchCode
    ]);
}

// -------------------------------------------------------------
// 2. POST /api/endpoints/hospitality.php?action=create_table
// Add or edit a table in the room.
// -------------------------------------------------------------
if ($method === 'POST' && $action === 'create_table') {
    $user = requirePermission('manage_settings');
    $data = getJsonInput();
    $branchCode = hospitalityBranchScope($user, (string)($data['branch_code'] ?? ''));

    $id = trim((string)($data['id'] ?? '')) ?: ('tbl_' . bin2hex(random_bytes(4)));
    $tableNum = mb_substr(trim((string)($data['table_number'] ?? '')), 0, 40);
    $zone = mb_substr(trim((string)($data['zone_name'] ?? 'Main Dining')), 0, 60);
    $capacity = intval($data['seating_capacity'] ?? 4);

    if ($tableNum === '') {
        jsonResponse(['success' => false, 'message' => 'A table needs a number or label of its own.'], 400);
    }
    if ($capacity < 1 || $capacity > 200) {
        jsonResponse(['success' => false, 'message' => 'Seating capacity must be between 1 and 200.'], 400);
    }
    // A manager may name the branch, but only one the shop actually has. A table filed under a
    // code nobody opened is a room no waiter can ever sign into - it sits on the floor screen
    // forever, seating nobody.
    $branchCheck = $db->prepare("SELECT branch_code FROM branches WHERE branch_code = ?");
    $branchCheck->execute([$branchCode]);
    if (!$branchCheck->fetchColumn()) {
        jsonResponse(['success' => false,
            'message' => "This shop has no branch '{$branchCode}', so it cannot have a dining table there."], 400);
    }

    // "Table 1" in two rooms is normal; twice in the same room is a slip of the keyboard, and
    // the floor has to be able to tell which table a waiter means.
    $clash = $db->prepare("SELECT id FROM dining_tables WHERE branch_code = ? AND table_number = ? AND id != ?");
    $clash->execute([$branchCode, $tableNum, $id]);
    if ($clash->fetchColumn()) {
        jsonResponse(['success' => false, 'message' => "Branch {$branchCode} already has a table called '{$tableNum}'."], 409);
    }

    $stmt = $db->prepare("INSERT INTO dining_tables (id, table_number, zone_name, seating_capacity, status, branch_code, created_at, updated_at)
                          VALUES (?, ?, ?, ?, 'VACANT', ?, datetime('now'), datetime('now'))
                          ON CONFLICT(id) DO UPDATE SET table_number = excluded.table_number,
                                                        zone_name = excluded.zone_name,
                                                        seating_capacity = excluded.seating_capacity,
                                                        updated_at = datetime('now')");
    $stmt->execute([$id, $tableNum, $zone, $capacity, $branchCode]);

    logActivity($db, $user['id'], $user['full_name'], $user['role_name'], 'HOSPITALITY_TABLE_CONFIGURED',
        "Table '{$tableNum}' ({$zone}, seats {$capacity}) set up for branch {$branchCode}.");

    jsonResponse(['success' => true, 'message' => 'Table configured.', 'table_id' => $id]);
}

// -------------------------------------------------------------
// 2b. POST /api/endpoints/hospitality.php?action=delete_table
// Take a table off the floor.
// -------------------------------------------------------------
if ($method === 'POST' && $action === 'delete_table') {
    $user = requirePermission('manage_settings');
    $data = getJsonInput();
    [$branchCode, $isManager] = hospitalityScope($user, $data);
    $id = trim((string)($data['table_id'] ?? ($data['id'] ?? '')));

    $look = $db->prepare("SELECT * FROM dining_tables WHERE id = ?");
    $look->execute([$id]);
    $table = $look->fetch();
    if (!$table) {
        jsonResponse(['success' => false, 'message' => 'No such table on the floor.'], 404);
    }
    if (!$isManager && strtoupper((string)$table['branch_code']) !== $branchCode) {
        jsonResponse(['success' => false, 'message' => "That table belongs to branch {$table['branch_code']}, not to {$branchCode}."], 403);
    }
    if (!empty($table['active_order_id'])) {
        $open = $db->prepare("SELECT status FROM table_orders WHERE id = ? AND status NOT IN ('SETTLED','CANCELLED')");
        $open->execute([$table['active_order_id']]);
        if ($open->fetchColumn()) {
            jsonResponse(['success' => false,
                'message' => "{$table['table_number']} is holding an unpaid tab. Settle the bill at the counter, or call the tab off, before taking the table off the floor."], 409);
        }
    }

    // The tickets keep pointing at the room even after it is paid, so a delete here would either
    // crash on the key that joins them or, worse, take the ticket with it - and the ticket is the
    // only paper that says the kitchen really fired what the receipt charged.
    $history = $db->prepare("SELECT COUNT(*) FROM table_orders WHERE table_id = ?");
    $history->execute([$id]);
    $ticketsOnFile = intval($history->fetchColumn());
    if ($ticketsOnFile > 0) {
        jsonResponse(['success' => false, 'message' => sprintf(
            '%s has %s on file, and those tickets are the paper behind its receipts. A room that has served parties cannot be deleted - rename it, or leave it for the next one.',
            $table['table_number'], $ticketsOnFile === 1 ? 'one ticket' : $ticketsOnFile . ' tickets'
        )], 409);
    }

    $db->prepare("DELETE FROM dining_tables WHERE id = ?")->execute([$id]);
    logActivity($db, $user['id'], $user['full_name'], $user['role_name'], 'HOSPITALITY_TABLE_REMOVED',
        "Took {$table['table_number']} off the floor at branch {$table['branch_code']}.");

    jsonResponse(['success' => true, 'message' => 'Table removed from the floor.']);
}

// -------------------------------------------------------------
// 3. POST /api/endpoints/hospitality.php?action=open_order
// Seat a party and fire a round to the kitchen. Priced from the catalogue, never from the
// ticket the till sent: the tab is a forecast of the bill, and a forecast the till writes is
// how a crate of beer gets rung up at the price of a bottle.
// -------------------------------------------------------------
if ($method === 'POST' && $action === 'open_order') {
    $user = requirePermission('manage_sales');
    $data = getJsonInput();
    [$branchCode, $isManager] = hospitalityScope($user, $data);

    $tableId = trim((string)($data['table_id'] ?? ''));
    $guestCount = max(1, min(999, intval($data['guest_count'] ?? 1)));
    $items = is_array($data['items'] ?? null) ? $data['items'] : [];
    $notes = mb_substr(trim((string)($data['notes'] ?? '')), 0, 400);

    if ($items === []) {
        jsonResponse(['success' => false,
            'message' => 'Nothing to fire. A table is seated by the first round the kitchen is sent; pick the dishes before sending.'], 400);
    }

    $tStmt = $db->prepare("SELECT * FROM dining_tables WHERE id = ?");
    $tStmt->execute([$tableId]);
    $table = $tStmt->fetch();
    if (!$table) {
        jsonResponse(['success' => false, 'message' => 'No such table on the floor.'], 404);
    }
    $tableBranch = strtoupper(trim((string)($table['branch_code'] ?? ''))) ?: 'MAIN-01';
    if (!$isManager && $tableBranch !== $branchCode) {
        jsonResponse(['success' => false, 'message' => "That table belongs to branch {$tableBranch}, not to {$branchCode}."], 403);
    }

    // A party already sitting at the table keeps its tab. Appending to a tab that has been
    // settled would put food on a bill the shop has already closed and paid out, and to a
    // cancelled one would resurrect a ticket nobody is going to pay.
    $existingOrderId = trim((string)($table['active_order_id'] ?? ''));
    $tab = null;
    if ($existingOrderId !== '') {
        $oStmt = $db->prepare("SELECT * FROM table_orders WHERE id = ?");
        $oStmt->execute([$existingOrderId]);
        $tab = $oStmt->fetch();
        if ($tab && in_array(strtoupper((string)$tab['status']), ['SETTLED', 'CANCELLED'], true)) {
            $existingOrderId = '';
            $tab = null;
            $db->prepare("UPDATE dining_tables SET active_order_id = NULL, updated_at = datetime('now') WHERE id = ?")
              ->execute([$tableId]);
        }
    }
    $orderId = $existingOrderId ?: ('tord_' . bin2hex(random_bytes(6)));
    $ticketNumber = 'KOT-' . date('Ymd-His') . '-' . strtoupper(bin2hex(random_bytes(2)));

    $prodStmt = $db->prepare("SELECT p.id, p.name, p.selling_price, p.unit, p.is_active,
                                     binv.custom_selling_price, binv.is_available
                              FROM products p
                              LEFT JOIN branch_inventory binv ON p.id = binv.product_id AND binv.branch_code = ?
                              WHERE p.id = ?");

    // A round is refused whole or not at all. The checks below run inside the write, so an
    // answer given halfway through a basket has to close the transaction on its own: exiting
    // with an open one leaves the shop holding the lines that were already inserted, and the
    // kitchen cooking a dish nobody is going to be charged for.
    $refuseRound = function (string $message, int $code = 400) use ($db): void {
        if ($db->inTransaction()) { $db->rollBack(); }
        jsonResponse(['success' => false, 'message' => $message], $code);
    };

    try {
        if ($db->inTransaction()) { $db->rollBack(); }
        $db->beginTransaction();

        $roundTotal = 0.0;
        $pendingLines = [];

        foreach ($items as $item) {
            $productId = trim((string)($item['product_id'] ?? ''));
            $qty = round(floatval($item['quantity'] ?? 0), 3);
            if ($qty <= 0) {
                // A zero line on a ticket is a dish the kitchen will make for nobody, and a
                // silently coerced "1" is the shop charging for a plate nobody ordered.
                $refuseRound('Every line sent to the kitchen needs a quantity above zero.');
            }

            $prodStmt->execute([$tableBranch, $productId]);
            $prod = $prodStmt->fetch();
            if (!$prod) {
                $refuseRound(sprintf(
                    "'%s' is not on this shop's catalogue, so the kitchen cannot be sent a dish the till can't charge for. Add it as a product first.",
                    $productId !== '' ? $productId : 'a line with no product'
                ));
            }
            if (intval($prod['is_active'] ?? 1) === 0) {
                $refuseRound("'{$prod['name']}' is not on sale at the counter, so it cannot be fired to the kitchen either.");
            }
            if ($prod['is_available'] !== null && intval($prod['is_available']) === 0) {
                $refuseRound("'{$prod['name']}' is disabled for branch {$tableBranch}.");
            }

            $unitLabel = trim((string)($item['unit'] ?? ''));
            $unitRow = sfUnitResolve($db, $productId, $unitLabel, true);
            if ($unitRow === null) {
                $refuseRound(sprintf(
                    "'%s' does not sell in a %s. The kitchen ticket would have to guess at a size, so the round was stopped.",
                    $prod['name'], $unitLabel
                ));
            }
            $unitLabel = trim((string)($unitRow['unit_name'] ?? '')) ?: trim((string)($prod['unit'] ?? 'pcs')) ?: 'pcs';
            $multiplier = round(floatval($unitRow['size_in_base'] ?? 1), 4);
            if ($multiplier < 1) $multiplier = 1.0;

            $basePrice = ($prod['custom_selling_price'] !== null && $prod['custom_selling_price'] !== '')
                ? round(floatval($prod['custom_selling_price']), 2)
                : round(floatval($prod['selling_price']), 2);
            $price = sfUnitPrice(($unitRow['selling_price'] === null || $unitRow['selling_price'] === '')
                ? null : floatval($unitRow['selling_price']), $multiplier, $basePrice);

            $lineTotal = round($qty * $price, 2);
            $roundTotal = round($roundTotal + $lineTotal, 2);
            $seatNumber = mb_substr(trim((string)($item['seat_number'] ?? 'Shared')), 0, 50) ?: 'Shared';
            $guestName = mb_substr(trim((string)($item['guest_name'] ?? '')), 0, 100);

            $pendingLines[] = [
                'titem_' . bin2hex(random_bytes(6)),
                $orderId,
                $productId,
                $prod['name'],
                $qty,
                $unitLabel,
                $multiplier,
                round($qty * $multiplier, 4),
                $price,
                $lineTotal,
                $ticketNumber,
                mb_substr(trim((string)($item['prep_notes'] ?? '')), 0, 200),
                $seatNumber,
                $guestName
            ];
        }

        // The tab is written before its lines, not after them. table_order_items.order_id is a
        // foreign key and SQLite checks it per statement, so the first build - which inserted
        // each dish on the way through the basket and only created the tab afterwards - refused
        // every single round with an integrity error. A shop could not fire one ticket.
        if ($tab) {
            $db->prepare("UPDATE table_orders SET subtotal = subtotal + ?, total_amount = subtotal + ?,
                                 status = CASE WHEN status IN ('SETTLED','CANCELLED','SERVED') THEN status ELSE 'IN_KITCHEN' END,
                                 kot_number = ?, ticket_count = ticket_count + 1,
                                 notes = COALESCE(NULLIF(notes, '') || ' | ', '') || ?,
                                 updated_at = datetime('now')
                         WHERE id = ?")->execute([
                $roundTotal, $roundTotal, $ticketNumber,
                $notes !== '' ? $notes : 'Additional round', $orderId
            ]);
        } else {
            $db->prepare("INSERT INTO table_orders (id, table_id, table_number, branch_code, guest_count,
                            server_user_id, server_name, status, subtotal, tax, total_amount, kot_number,
                            notes, ticket_count, opened_at, settled_at, sale_id, updated_at)
                          VALUES (?, ?, ?, ?, ?, ?, ?, 'IN_KITCHEN', ?, 0.0, ?, ?, ?, 1, datetime('now'), NULL, NULL, datetime('now'))")
              ->execute([
                $orderId, $tableId, $table['table_number'], $tableBranch, $guestCount,
                $user['id'], $user['full_name'], $roundTotal, $roundTotal, $ticketNumber, $notes
            ]);

            $db->prepare("UPDATE dining_tables SET status = 'OCCUPIED', active_order_id = ?, updated_at = datetime('now') WHERE id = ?")
              ->execute([$orderId, $tableId]);
        }

        $insertItem = $db->prepare("INSERT INTO table_order_items
            (id, order_id, product_id, product_name, quantity, unit, multiplier, base_quantity,
             unit_price, subtotal, ticket_number, kitchen_status, prep_notes, seat_number, guest_name, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ORDERED', ?, ?, ?, datetime('now'))");
        foreach ($pendingLines as $pendingLine) {
            $insertItem->execute($pendingLine);
        }
        $firedLines = count($pendingLines);

        $db->commit();

        storeflow_do_action('hospitality_kot_created', $orderId, $ticketNumber, $table['table_number'], $items);
        logActivity($db, $user['id'], $user['full_name'], $user['role_name'], 'HOSPITALITY_KOT_FIRED',
            "Fired {$ticketNumber} to the kitchen for {$table['table_number']} ({$firedLines} lines, ticket subtotal {$roundTotal}).");

        jsonResponse([
            'success' => true,
            'message' => "Order sent to the kitchen for {$table['table_number']}",
            'order_id' => $orderId,
            'table_id' => $tableId,
            'ticket_number' => $ticketNumber,
            'round_subtotal' => $roundTotal,
            'tab_subtotal' => (function() use ($db, $orderId) {
                $s = $db->prepare("SELECT subtotal FROM table_orders WHERE id = ?");
                $s->execute([$orderId]);
                return round(floatval($s->fetchColumn()), 2);
            })(),
            'is_appended' => $tab !== null
        ]);

    } catch (Exception $e) {
        if ($db->inTransaction()) { $db->rollBack(); }
        jsonResponse(['success' => false, 'message' => 'Failed to send the order to the kitchen: ' . $e->getMessage()], 500);
    }
}

// -------------------------------------------------------------
// 4. GET /api/endpoints/hospitality.php?action=active_orders
// The kitchen's own screen: every ticket still being worked, newest line last.
// -------------------------------------------------------------
if ($method === 'GET' && $action === 'active_orders') {
    $user = requireAuth();
    [$branchCode, $isManager] = hospitalityScope($user);

    $where = "o.status NOT IN ('SETTLED','CANCELLED')";
    $args = [];
    if (!$isManager || $branchCode !== 'ALL') {
        $where .= " AND o.branch_code = ?";
        $args[] = $branchCode;
    }

    // A ticket that has been started has to stay on the board. The first build of this feed
    // listed OPEN/IN_KITCHEN/READY/SERVED and left PREPARING out, so the moment a cook tapped
    // "start cooking" the dish vanished from the screen the kitchen is run from.
    $stmt = $db->prepare("SELECT o.*, t.zone_name FROM table_orders o
                          JOIN dining_tables t ON t.id = o.table_id
                          WHERE {$where}
                          ORDER BY o.opened_at ASC");
    $stmt->execute($args);
    $orders = $stmt->fetchAll();

    $itemStmt = $db->prepare("SELECT * FROM table_order_items WHERE order_id = ? ORDER BY created_at ASC");
    foreach ($orders as &$ord) {
        $itemStmt->execute([$ord['id']]);
        $ord['items'] = $itemStmt->fetchAll();
    }
    unset($ord);

    jsonResponse(['success' => true, 'orders' => $orders]);
}

// -------------------------------------------------------------
// 4b. POST /api/endpoints/hospitality.php?action=update_order_status
// The cook advancing a ticket: started, ready, bumped.
// -------------------------------------------------------------
if ($method === 'POST' && $action === 'update_order_status') {
    $user = requirePermission('manage_sales');
    $data = getJsonInput();
    [$branchCode, $isManager] = hospitalityScope($user, $data);

    $orderId = trim((string)($data['order_id'] ?? ''));
    $newStatus = strtoupper(trim((string)($data['status'] ?? '')));

    if (!in_array($newStatus, hospitalityKitchenStatuses(), true)) {
        // SETTLED in particular: a kitchen screen that could mark a tab paid would free a
        // table without a receipt, and the shop would lose the bill with the food already gone.
        jsonResponse(['success' => false, 'message' => sprintf(
            "The kitchen screen can move a ticket to %s. A tab is settled by taking the bill at the counter, not by a button here.",
            implode(', ', hospitalityKitchenStatuses())
        )], 400);
    }

    $oStmt = $db->prepare("SELECT * FROM table_orders WHERE id = ?");
    $oStmt->execute([$orderId]);
    $order = $oStmt->fetch();
    if (!$order) {
        jsonResponse(['success' => false, 'message' => 'No such ticket.'], 404);
    }
    if (!$isManager && strtoupper((string)($order['branch_code'] ?? '')) !== $branchCode) {
        jsonResponse(['success' => false, 'message' => "That ticket is at branch {$order['branch_code']}, not at {$branchCode}."], 403);
    }
    if (in_array(strtoupper((string)$order['status']), ['SETTLED', 'CANCELLED'], true)) {
        jsonResponse(['success' => false, 'message' => "That tab is already {$order['status']} - the kitchen cannot work a ticket that has been closed."], 409);
    }

    $db->prepare("UPDATE table_orders SET status = ?, updated_at = datetime('now') WHERE id = ?")
      ->execute([$newStatus, $orderId]);
    if (in_array($newStatus, ['PREPARING', 'READY', 'SERVED'], true)) {
        // A line the counter has already taken money for is not the cook's to move back onto the
        // board. At a shared bar the parties pay at different times while the kitchen is still
        // working the tab, and if a paid line read unsettled again the same party could be billed
        // for the same bottle twice - the ticket would agree, because the line is on it.
        $db->prepare("UPDATE table_order_items SET kitchen_status = ?
                      WHERE order_id = ? AND kitchen_status NOT IN ('SERVED', 'SETTLED')")
          ->execute([$newStatus, $orderId]);
    }

    storeflow_do_action('hospitality_order_status', $orderId, $newStatus, $order['table_number']);
    jsonResponse(['success' => true, 'message' => "Ticket for {$order['table_number']} moved to {$newStatus}", 'status' => $newStatus]);
}

// -------------------------------------------------------------
// 4c. GET /api/endpoints/hospitality.php?action=order_details
// One tab with its lines, for loading into the counter's cart.
// -------------------------------------------------------------
if ($method === 'GET' && $action === 'order_details') {
    $user = requireAuth();
    [$branchCode, $isManager] = hospitalityScope($user);

    $tab = hospitalityFindTab($db, trim((string)($_GET['order_id'] ?? '')), $branchCode, $isManager);
    if ($tab === null) {
        jsonResponse(['success' => false, 'message' => 'No such tab.'], 404);
    }
    if (isset($tab['error'])) {
        jsonResponse(['success' => false, 'message' => $tab['error']], (int)$tab['status']);
    }

    // Tax is the counter's business, so the till needs the shop's rate to show the same
    // figure the receipt will print. The tab itself stays a pre-tax ticket.
    $rate = 0.0;
    try {
        $rate = round(floatval($db->query("SELECT tax_rate FROM store_profile WHERE id = 1")->fetchColumn()), 4);
    } catch (Exception $e) {
        $rate = 0.0;
    }

    jsonResponse(['success' => true, 'order' => $tab, 'tax_rate' => $rate]);
}

// -------------------------------------------------------------
// 4d. POST /api/endpoints/hospitality.php?action=void_line
// A dish the table sent back, taken off the ticket.
// -------------------------------------------------------------
if ($method === 'POST' && $action === 'void_line') {
    $user = requirePermission('manage_sales');
    $data = getJsonInput();
    [$branchCode, $isManager] = hospitalityScope($user, $data);

    $itemId = trim((string)($data['item_id'] ?? ''));
    $reason = mb_substr(trim((string)($data['reason'] ?? '')), 0, 200);
    if ($reason === '') {
        // The kitchen has already made this plate and the shop is about to stop charging for it.
        // That is the one write on the floor with no receipt behind it, so it carries a reason.
        jsonResponse(['success' => false,
            'message' => 'Say why the dish is coming off the ticket. Nothing has been changed.'], 400);
    }

    $iStmt = $db->prepare("SELECT i.*, o.status AS tab_status, o.branch_code AS tab_branch, o.table_number,
                                  o.subtotal AS tab_subtotal
                           FROM table_order_items i
                           JOIN table_orders o ON o.id = i.order_id
                           WHERE i.id = ?");
    $iStmt->execute([$itemId]);
    $line = $iStmt->fetch();
    if (!$line) {
        jsonResponse(['success' => false, 'message' => 'That line is not on any ticket.'], 404);
    }
    if (!$isManager && strtoupper((string)$line['tab_branch']) !== $branchCode) {
        jsonResponse(['success' => false, 'message' => "That line is at branch {$line['tab_branch']}, not at {$branchCode}."], 403);
    }
    if (in_array(strtoupper((string)$line['tab_status']), ['SETTLED', 'CANCELLED'], true)) {
        jsonResponse(['success' => false,
            'message' => "That tab is already {$line['tab_status']}. A dish charged and paid for is taken back through a return at the counter, not by editing the ticket."], 409);
    }
    // The tab still being open is not the same as this line still being unpaid: at a shared counter
    // one party pays and leaves while the rest of the tab is still running. Taking a paid line off
    // the ticket would put a bottle back on the shelf beside the receipt that already sold it.
    if (strtoupper((string)($line['kitchen_status'] ?? '')) === 'SETTLED') {
        jsonResponse(['success' => false, 'message' => sprintf(
            '%s has already paid for this line (%g x %s, %s). Take it back through a return at the counter, where the money moves with the dish.',
            trim((string)($line['seat_number'] ?? '')) !== '' ? $line['seat_number'] : 'This seat',
            (float)$line['quantity'], $line['product_name'], number_format((float)$line['subtotal'], 2)
        )], 409);
    }

    try {
        if ($db->inTransaction()) { $db->rollBack(); }
        $db->beginTransaction();

        $db->prepare("DELETE FROM table_order_items WHERE id = ?")->execute([$itemId]);
        // The ticket's own total is re-counted from the lines rather than nudged down by the
        // line's stored subtotal, so a tab cannot drift from what it actually holds.
        $db->prepare("UPDATE table_orders SET subtotal = COALESCE((SELECT SUM(subtotal) FROM table_order_items WHERE order_id = ?), 0),
                                             total_amount = COALESCE((SELECT SUM(subtotal) FROM table_order_items WHERE order_id = ?), 0),
                                             updated_at = datetime('now')
                     WHERE id = ?")->execute([$line['order_id'], $line['order_id'], $line['order_id']]);

        $db->commit();
    } catch (Exception $e) {
        if ($db->inTransaction()) { $db->rollBack(); }
        jsonResponse(['success' => false, 'message' => 'Failed to void that line: ' . $e->getMessage()], 500);
    }

    logActivity($db, $user['id'], $user['full_name'], $user['role_name'], 'HOSPITALITY_LINE_VOIDED',
        "Voided {$line['quantity']} x {$line['product_name']} on {$line['table_number']}" . ($reason !== '' ? ": {$reason}" : '.'));
    storeflow_do_action('hospitality_line_voided', $line['order_id'], $itemId, $line['product_name']);

    $recalc = $db->prepare("SELECT subtotal FROM table_orders WHERE id = ?");
    $recalc->execute([$line['order_id']]);
    jsonResponse(['success' => true, 'message' => 'Line taken off the ticket.',
                  'order_id' => $line['order_id'], 'tab_subtotal' => round(floatval($recalc->fetchColumn()), 2)]);
}

// -------------------------------------------------------------
// 4e. POST /api/endpoints/hospitality.php?action=cancel_tab
// Call the whole ticket off - the party walked out, or the table was seated in error.
// -------------------------------------------------------------
if ($method === 'POST' && $action === 'cancel_tab') {
    $user = requirePermission('manage_sales');
    $data = getJsonInput();
    [$branchCode, $isManager] = hospitalityScope($user, $data);

    $orderId = trim((string)($data['order_id'] ?? ''));
    $reason = mb_substr(trim((string)($data['reason'] ?? '')), 0, 300);
    if ($reason === '') {
        jsonResponse(['success' => false,
            'message' => 'Say why the tab is being called off. Nothing has been charged, but the shop has just lost the bill for whatever the kitchen made.'], 400);
    }

    $oStmt = $db->prepare("SELECT * FROM table_orders WHERE id = ?");
    $oStmt->execute([$orderId]);
    $order = $oStmt->fetch();
    if (!$order) {
        jsonResponse(['success' => false, 'message' => 'No such tab.'], 404);
    }
    if (!$isManager && strtoupper((string)($order['branch_code'] ?? '')) !== $branchCode) {
        jsonResponse(['success' => false, 'message' => "That tab is at branch {$order['branch_code']}, not at {$branchCode}."], 403);
    }
    if (strtoupper((string)$order['status']) === 'SETTLED') {
        jsonResponse(['success' => false, 'message' => 'That tab has already been paid. Take a return at the counter instead.'], 409);
    }
    if (strtoupper((string)$order['status']) === 'CANCELLED') {
        // It has been called off once and the reason is already written on it. A second pass
        // would append another reason under the first and log the same lost bill twice, which is
        // how a double-tapped button turns one walk-out into two in the shop's own record.
        jsonResponse(['success' => false, 'message' => 'That tab has already been called off.'], 409);
    }

    try {
        if ($db->inTransaction()) { $db->rollBack(); }
        $db->beginTransaction();

        $db->prepare("UPDATE table_orders SET status = 'CANCELLED', settled_at = datetime('now'),
                             notes = COALESCE(NULLIF(notes, '') || ' | ', '') || ?, updated_at = datetime('now')
                     WHERE id = ? AND status != 'SETTLED'")->execute([$reason, $orderId]);
        $db->prepare("UPDATE dining_tables SET status = 'VACANT', active_order_id = NULL, updated_at = datetime('now')
                      WHERE id = ? AND active_order_id = ?")->execute([$order['table_id'], $orderId]);

        $db->commit();
    } catch (Exception $e) {
        if ($db->inTransaction()) { $db->rollBack(); }
        jsonResponse(['success' => false, 'message' => 'Failed to call that tab off: ' . $e->getMessage()], 500);
    }

    logActivity($db, $user['id'], $user['full_name'], $user['role_name'], 'HOSPITALITY_TAB_CANCELLED',
        "Called off the tab for {$order['table_number']} (ticket subtotal {$order['subtotal']}): {$reason}");
    storeflow_do_action('hospitality_tab_cancelled', $orderId, $reason, $order['table_number']);

    jsonResponse(['success' => true, 'message' => "Tab for {$order['table_number']} called off and the table released."]);
}

// -------------------------------------------------------------
// 5. settle_order is deliberately not here.
// The till used to settle a tab by posting here after the receipt, which meant the module
// wrote its own sales rows: no cost, no profit, no lot, no branch, no tax, and stock driven
// below zero without a floor check. A bill is taken at the counter, and the checkout that
// carries table_order_id closes the tab.
// -------------------------------------------------------------
if ($method === 'POST' && $action === 'settle_order') {
    jsonResponse(['success' => false, 'message' =>
        'A tab is not settled from the floor screen. Load the tab into the counter\'s cart and ring it up there; '
        . 'the table frees itself the moment the receipt is booked, online or from the till\'s queue.'], 400);
}

// -------------------------------------------------------------
// 6. GET /api/endpoints/hospitality.php?action=kot_ticket
// The ticket as the kitchen printer wants it: one round, not the running total.
// -------------------------------------------------------------
if ($method === 'GET' && $action === 'kot_ticket') {
    // A thermal printer behind this URL used to have no key at all on it, so anything that
    // could reach the till could read the floor - and reprint a ticket for a table that had
    // already been paid.
    $user = requireAuth();
    [$branchCode, $isManager] = hospitalityScope($user);

    $orderId = trim((string)($_GET['order_id'] ?? ''));
    $ticketNumber = trim((string)($_GET['ticket_number'] ?? ''));

    $oStmt = $db->prepare("SELECT * FROM table_orders WHERE id = ?");
    $oStmt->execute([$orderId]);
    $order = $oStmt->fetch();
    if (!$order) {
        jsonResponse(['success' => false, 'message' => 'No such tab.'], 404);
    }
    if (!$isManager && strtoupper((string)($order['branch_code'] ?? '')) !== $branchCode) {
        jsonResponse(['success' => false, 'message' => "That tab is at branch {$order['branch_code']}, not at {$branchCode}."], 403);
    }

    $args = [$orderId];
    $ticketFilter = '';
    if ($ticketNumber !== '') {
        $ticketFilter = ' AND ticket_number = ?';
        $args[] = $ticketNumber;
    }
    $iStmt = $db->prepare("SELECT * FROM table_order_items WHERE order_id = ?{$ticketFilter} ORDER BY created_at ASC");
    $iStmt->execute($args);
    $items = $iStmt->fetchAll();

    $kotText  = "================================\n";
    $kotText .= "       KITCHEN ORDER TICKET     \n";
    $kotText .= "================================\n";
    $kotText .= "TICKET #: " . ($ticketNumber !== '' ? $ticketNumber : (string)$order['kot_number']) . "\n";
    $kotText .= "TABLE   : {$order['table_number']}\n";
    $kotText .= "GUESTS  : {$order['guest_count']}\n";
    $kotText .= "SERVER  : {$order['server_name']}\n";
    $kotText .= "TIME    : {$order['opened_at']}\n";
    $kotText .= "--------------------------------\n";
    foreach ($items as $it) {
        $qtyLabel = rtrim(rtrim(number_format(floatval($it['quantity']), 3, '.', ''), '0'), '.') . ' x ' . $it['product_name'];
        $kotText .= sprintf("%-24s %6s\n", mb_substr($qtyLabel, 0, 24), $it['unit']);
        if (!empty($it['prep_notes'])) {
            $kotText .= "  >> NOTE: " . $it['prep_notes'] . "\n";
        }
    }
    $kotText .= "================================\n";
    $kotText .= "ITEMS: " . count($items) . "   TABLE: {$order['table_number']}\n";

    jsonResponse([
        'success' => true,
        'ticket_number' => $ticketNumber !== '' ? $ticketNumber : $order['kot_number'],
        'ticket_text' => $kotText
    ]);
}

jsonResponse(['success' => false, 'message' => 'Unsupported hospitality action'], 400);
