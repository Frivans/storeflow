<?php
// api/endpoints/activity_logs.php
// System Activity & Audit Trail Handler
require_once __DIR__ . '/../config/db.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET') {
    $authUser = requirePermission('manage_settings');
    $actionType = trim($_GET['action_type'] ?? '');
    $userId = intval($_GET['user_id'] ?? 0);
    $limit = intval($_GET['limit'] ?? 100);
    if ($limit <= 0 || $limit > 500) $limit = 100;

    $sql = "SELECT * FROM activity_logs WHERE 1=1";
    $params = [];

    if (!empty($actionType) && $actionType !== 'ALL') {
        $sql .= " AND action_type = ?";
        $params[] = $actionType;
    }
    if ($userId > 0) {
        $sql .= " AND user_id = ?";
        $params[] = $userId;
    }

    $sql .= " ORDER BY created_at DESC LIMIT ?";
    $params[] = $limit;

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $logs = $stmt->fetchAll();

    jsonResponse([
        'success' => true,
        'logs' => $logs,
        'total_count' => count($logs)
    ]);
}

if ($method === 'POST') {
    $authUser = requireAuth();
    $data = getJsonInput();

    $actionType = strtoupper(mb_substr(trim($data['action_type'] ?? 'GENERAL'), 0, 40));
    // The audit trail is kept on the shop's own disk. One field from one browser tab
    // used to be written verbatim and without a length, so a till could fill the
    // database with a single request and take every endpoint down with it.
    $details = mb_substr(trim($data['details'] ?? ''), 0, 500);

    if (empty($details)) {
        jsonResponse(['success' => false, 'message' => 'Details are required for activity log'], 400);
    }

    // Always use authenticated user's credentials to prevent spoofed logs
    logActivity($db, $authUser['id'], $authUser['full_name'], $authUser['role_name'], $actionType, $details);

    jsonResponse([
        'success' => true,
        'message' => 'Activity logged successfully'
    ], 201);
}

jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
