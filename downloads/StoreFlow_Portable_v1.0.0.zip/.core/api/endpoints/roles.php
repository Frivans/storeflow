<?php
// api/endpoints/roles.php
// User Roles and Permissions Endpoint — the Access Map
require_once __DIR__ . '/../config/db.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET') {
    $user = requireAuth();

    $canManageUsers = strtolower(trim($user['role_name'] ?? '')) === 'administrator'
        || intval($user['role_id'] ?? 0) === 1
        || hasPermission($user, 'manage_users');

    if ($canManageUsers) {
        $stmt = $db->query("SELECT * FROM user_roles ORDER BY id ASC");
    } else {
        // The full role table is the map of which account can be promoted to what. Only the
        // staff roster screen needs it, so everyone else gets the one role they already hold.
        $stmt = $db->prepare("SELECT * FROM user_roles WHERE id = ?");
        $stmt->execute([intval($user['role_id'] ?? 0)]);
    }
    $roles = $stmt->fetchAll();

    $countStmt = $db->prepare("SELECT COUNT(*) FROM users WHERE role_id = ?");
    foreach ($roles as &$role) {
        $role['permissions'] = json_decode($role['permissions'] ?? '[]', true);
        $role['max_discount_pct'] = round(floatval($role['max_discount_pct'] ?? 10), 2);
        $role['is_system'] = intval($role['id'] ?? 0) === 1;
        $countStmt->execute([intval($role['id'] ?? 0)]);
        $role['user_count'] = intval($countStmt->fetchColumn());
    }
    unset($role);

    jsonResponse([
        'success' => true,
        'roles' => $roles,
        'catalogue' => $canManageUsers ? storeflowPermissionCatalogue() : null,
        'can_manage' => $canManageUsers
    ]);
}

if ($method === 'POST') {
    $actor = requirePermission('manage_users');
    $data = getJsonInput();
    $action = trim((string)($data['action'] ?? 'save'));

    if (!in_array($action, ['save', 'delete'], true)) {
        jsonResponse(['success' => false, 'message' => 'Unrecognized role action.'], 400);
    }

    $roleId = intval($data['id'] ?? 0);

    if ($roleId === 1) {
        jsonResponse([
            'success' => false,
            'message' => 'The Administrator role is fixed. It already holds every permission, so editing it can only ever remove rights the owner cannot regain through the Access Map. Create a second role instead.'
        ], 400);
    }

    try {
        if ($action === 'delete') {
            $find = $db->prepare("SELECT id, role_name FROM user_roles WHERE id = ? AND id != 1");
            $find->execute([$roleId]);
            $victim = $find->fetch();
            if (!$victim) {
                jsonResponse(['success' => false, 'message' => 'No such role to delete.'], 404);
            }

            $staffStmt = $db->prepare("SELECT COUNT(*) FROM users WHERE role_id = ?");
            $staffStmt->execute([$roleId]);
            $holding = intval($staffStmt->fetchColumn());
            if ($holding > 0) {
                jsonResponse([
                    'success' => false,
                    'message' => "This role still has {$holding} staff account" . ($holding === 1 ? '' : 's') . " on it. Move them to another role in the staff roster first, or the deletion would leave them signing in with no permissions at all."
                ], 400);
            }

            $db->prepare("DELETE FROM user_roles WHERE id = ?")->execute([$roleId]);

            logActivity($db, $actor['id'], $actor['full_name'], $actor['role_name'], 'ROLE_DELETED',
                "Deleted the role '{$victim['role_name']}' from the Access Map.");
            jsonResponse(['success' => true, 'message' => 'Role removed.']);
        }

        $roleName = trim((string)($data['role_name'] ?? ''));
        $description = trim((string)($data['description'] ?? ''));
        if ($roleName === '' || strlen($roleName) > 60) {
            jsonResponse(['success' => false, 'message' => 'A role needs a name of 1 to 60 characters.'], 400);
        }

        $catalogue = storeflowPermissionCatalogue();
        $rawPerms = $data['permissions'] ?? [];
        if (!is_array($rawPerms)) {
            jsonResponse(['success' => false, 'message' => 'Permissions must arrive as a list.'], 400);
        }
        $permissions = array_values(array_unique(array_map(function ($p) {
            return strtolower(trim((string)$p));
        }, $rawPerms)));
        $unknown = array_diff($permissions, array_keys($catalogue));
        if ($permissions === []) {
            jsonResponse(['success' => false, 'message' => "A role with no permissions cannot open anything, so it cannot be saved. Tick at least one right, or delete the role."], 400);
        }
        if (!empty($unknown)) {
            jsonResponse([
                'success' => false,
                'message' => 'Unknown permission requested: ' . implode(', ', $unknown) . '. Only the rights listed in the Access Map can be granted.'
            ], 400);
        }

        // 0 is a real answer here, not a missing value: it means this role may not discount
        // at all. Only a field the owner never sent falls back to the historical 10%.
        if (!isset($data['max_discount_pct']) || $data['max_discount_pct'] === '' || $data['max_discount_pct'] === null) {
            $maxPct = 10.0;
        } else {
            if (!is_numeric($data['max_discount_pct'])) {
                jsonResponse(['success' => false, 'message' => 'The discount ceiling must be a number of percent.'], 400);
            }
            $maxPct = round(floatval($data['max_discount_pct']), 2);
            if ($maxPct < 0 || $maxPct > 100) {
                jsonResponse(['success' => false, 'message' => 'The discount ceiling must be between 0% and 100%.'], 400);
            }
        }

        $dupe = $db->prepare("SELECT id, role_name FROM user_roles WHERE LOWER(role_name) = LOWER(?) AND id != ?");
        $dupe->execute([$roleName, $roleId]);
        if ($dupe->fetch()) {
            jsonResponse([
                'success' => false,
                'message' => "There is already a role called '{$roleName}'. Two roles of the same name cannot be told apart on the staff roster."
            ], 400);
        }

        if ($roleId > 0) {
            $stmt = $db->prepare("UPDATE user_roles SET role_name = ?, description = ?, permissions = ?, max_discount_pct = ? WHERE id = ? AND id != 1");
            $stmt->execute([$roleName, $description, json_encode($permissions), $maxPct, $roleId]);
            if ($stmt->rowCount() === 0) {
                jsonResponse(['success' => false, 'message' => 'No such role to change.'], 404);
            }
            $savedId = $roleId;
            logActivity($db, $actor['id'], $actor['full_name'], $actor['role_name'], 'ROLE_UPDATED',
                "Updated the role '{$roleName}' in the Access Map: " . implode(', ', $permissions) . "; discount ceiling {$maxPct}%.");
        } else {
            $stmt = $db->prepare("INSERT INTO user_roles (role_name, description, permissions, max_discount_pct) VALUES (?, ?, ?, ?)");
            $stmt->execute([$roleName, $description, json_encode($permissions), $maxPct]);
            $savedId = intval($db->lastInsertId());
            logActivity($db, $actor['id'], $actor['full_name'], $actor['role_name'], 'ROLE_CREATED',
                "Created the role '{$roleName}' in the Access Map: " . implode(', ', $permissions) . "; discount ceiling {$maxPct}%.");
        }

        jsonResponse(['success' => true, 'message' => 'Role saved.', 'id' => $savedId]);
    } catch (Throwable $e) {
        safeRollback($db);
        error_log('StoreFlow Access Map save failed: ' . $e->getMessage());
        jsonResponse(['success' => false, 'message' => 'The role could not be saved. The change was not made.'], 500);
    }
}

jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
