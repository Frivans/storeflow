<?php
/**
 * api/endpoints/rentals.php
 *
 * Equipment & Event Rentals & Hire Engine (Chairs, Canopies, Sound Systems, Machinery)
 * - Time-based daily duration pricing
 * - Upfront caution security deposit tracking
 * - Automatic overdue tracking & daily penalty fees
 * - Check-in return inspection (Good condition vs. Damaged vs. Missing / Stolen)
 * - Deposit forfeiture, deductions, refunds & customer replacement billing
 * - Inventory availability dispatch & restoration
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json; charset=UTF-8');

try {
    $authUser = requireAuth();
    global $db;
    if (!$db && function_exists('getDB')) {
        $db = getDB();
    }

    // Ensure balance_paid column exists in rentals table
    try {
        $rCols = $db->query("PRAGMA table_info(rentals)")->fetchAll(PDO::FETCH_COLUMN, 1);
        if (!in_array('balance_paid', $rCols)) {
            $db->exec("ALTER TABLE rentals ADD COLUMN balance_paid REAL DEFAULT 0.0");
        }
    } catch (Throwable $te) {}

    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

    if ($method === 'GET') {
        $rentalId = $_GET['id'] ?? null;
        $statusFilter = strtolower(trim((string)($_GET['status'] ?? 'all')));
        $search = trim((string)($_GET['search'] ?? ''));
        $branchCode = trim((string)($_GET['branch_code'] ?? ''));

        if ($rentalId) {
            // Single rental detail
            $stmt = $db->prepare("SELECT * FROM rentals WHERE id = ?");
            $stmt->execute([$rentalId]);
            $rental = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$rental) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Rental record not found.']);
                exit;
            }

            // Fetch items
            $itemStmt = $db->prepare("SELECT * FROM rental_items WHERE rental_id = ? ORDER BY id ASC");
            $itemStmt->execute([$rentalId]);
            $rental['items'] = $itemStmt->fetchAll(PDO::FETCH_ASSOC);

            // Compute live overdue if dispatched and past due date
            $today = date('Y-m-d');
            if ($rental['status'] === 'DISPATCHED' && $today > $rental['return_due_date']) {
                $rental['is_overdue'] = true;
                $daysOverdue = (int)ceil((strtotime($today) - strtotime($rental['return_due_date'])) / 86400);
                $rental['days_overdue'] = max(1, $daysOverdue);
                $rental['accrued_late_fee'] = $rental['days_overdue'] * floatval($rental['late_fee_per_day'] ?? 0);
            } else {
                $rental['is_overdue'] = ($rental['status'] === 'OVERDUE');
                $rental['days_overdue'] = 0;
                $rental['accrued_late_fee'] = 0;
            }

            echo json_encode(['success' => true, 'rental' => $rental]);
            exit;
        }

        // List rentals
        $today = date('Y-m-d');
        $query = "SELECT * FROM rentals WHERE 1=1";
        $params = [];

        if ($branchCode !== '') {
            $query .= " AND branch_code = ?";
            $params[] = $branchCode;
        }

        if ($statusFilter !== 'all' && $statusFilter !== '') {
            if ($statusFilter === 'active') {
                $query .= " AND status IN ('DISPATCHED', 'OVERDUE', 'BOOKED')";
            } elseif ($statusFilter === 'overdue') {
                $today = date('Y-m-d');
                $query .= " AND (status = 'OVERDUE' OR (status = 'DISPATCHED' AND return_due_date < ?))";
                $params[] = $today;
            } else {
                $query .= " AND LOWER(status) = ?";
                $params[] = $statusFilter;
            }
        }

        if ($search !== '') {
            $query .= " AND (rental_number LIKE ? OR customer_name LIKE ? OR customer_phone LIKE ? OR event_location LIKE ?)";
            $term = "%{$search}%";
            $params[] = $term;
            $params[] = $term;
            $params[] = $term;
            $params[] = $term;
        }

        $query .= " ORDER BY created_at DESC LIMIT 200";
        $stmt = $db->prepare($query);
        $stmt->execute($params);
        $rentals = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Fetch items for each rental in current query result
        $itemsStmt = $db->prepare("SELECT * FROM rental_items WHERE rental_id = ?");

        foreach ($rentals as &$r) {
            $itemsStmt->execute([$r['id']]);
            $r['items'] = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);

            // Compute live overdue
            if ($r['status'] === 'DISPATCHED' && $today > $r['return_due_date']) {
                $r['status'] = 'OVERDUE';
                $r['is_overdue'] = true;
                $daysOverdue = (int)ceil((strtotime($today) - strtotime($r['return_due_date'])) / 86400);
                $r['days_overdue'] = max(1, $daysOverdue);
                $r['accrued_late_fee'] = $r['days_overdue'] * floatval($r['late_fee_per_day'] ?? 0);
            } else {
                $r['is_overdue'] = ($r['status'] === 'OVERDUE');
                $r['days_overdue'] = 0;
                $r['accrued_late_fee'] = 0;
            }
        }
        unset($r);

        // Compute global summary metrics across the whole store/branch (independent of current tab filter)
        $branchClause = ($branchCode !== '') ? " AND branch_code = ?" : "";
        $branchParams = ($branchCode !== '') ? [$branchCode] : [];

        $summaryStmt = $db->prepare("
            SELECT 
                COUNT(*) as total_records,
                COALESCE(SUM(CASE WHEN status IN ('DISPATCHED', 'OVERDUE') THEN 1 ELSE 0 END), 0) as active_rentals,
                COALESCE(SUM(CASE WHEN status = 'OVERDUE' OR (status = 'DISPATCHED' AND return_due_date < ?) THEN 1 ELSE 0 END), 0) as overdue_rentals,
                COALESCE(SUM(CASE WHEN status IN ('DISPATCHED', 'OVERDUE') AND caution_deposit_status = 'HELD' THEN caution_deposit ELSE 0 END), 0.0) as caution_deposits_held
            FROM rentals WHERE 1=1 {$branchClause}
        ");
        $summaryStmt->execute(array_merge([$today], $branchParams));
        $globSummary = $summaryStmt->fetch(PDO::FETCH_ASSOC) ?: [];

        $hireStmt = $db->prepare("
            SELECT COALESCE(SUM(ri.quantity_dispatched), 0)
            FROM rental_items ri
            JOIN rentals r ON ri.rental_id = r.id
            WHERE r.status IN ('DISPATCHED', 'OVERDUE') {$branchClause}
        ");
        $hireStmt->execute($branchParams);
        $totalItemsOnHire = floatval($hireStmt->fetchColumn() ?: 0);

        // Damaged and missing counts
        $dmgStmt = $db->prepare("
            SELECT 
                COALESCE(SUM(ri.quantity_damaged), 0) as damaged_count,
                COALESCE(SUM(ri.quantity_missing), 0) as missing_count
            FROM rental_items ri
        ");
        $dmgStmt->execute();
        $dmgStats = $dmgStmt->fetch(PDO::FETCH_ASSOC) ?: [];

        // Check inventory movements for repaired and found/replaced
        $movStmt = $db->prepare("
            SELECT 
                COALESCE(SUM(CASE WHEN movement_type = 'REPAIRED' THEN quantity ELSE 0 END), 0) as repaired_count,
                COALESCE(SUM(CASE WHEN movement_type = 'FOUND_REPLACED' THEN quantity ELSE 0 END), 0) as found_replaced_count
            FROM inventory_movements
        ");
        $movStmt->execute();
        $movStats = $movStmt->fetch(PDO::FETCH_ASSOC) ?: [];

        $netInRepair = max(0, floatval($dmgStats['damaged_count'] ?? 0) - floatval($movStats['repaired_count'] ?? 0));
        $netMissing = max(0, floatval($dmgStats['missing_count'] ?? 0) - floatval($movStats['found_replaced_count'] ?? 0));

        // Per-product damage, missing, repaired, and restored stats for equipment fleet management
        $itemStatsStmt = $db->query("
            SELECT 
                p.id as product_id,
                COALESCE(dmg.damaged_sum, 0) as total_damaged,
                COALESCE(dmg.missing_sum, 0) as total_missing,
                COALESCE(mvt.repaired_sum, 0) as total_repaired,
                COALESCE(mvt.restored_sum, 0) as total_restored
            FROM products p
            LEFT JOIN (
                SELECT product_id, SUM(quantity_damaged) as damaged_sum, SUM(quantity_missing) as missing_sum
                FROM rental_items GROUP BY product_id
            ) dmg ON p.id = dmg.product_id
            LEFT JOIN (
                SELECT product_id, 
                       SUM(CASE WHEN movement_type = 'REPAIRED' THEN quantity ELSE 0 END) as repaired_sum,
                       SUM(CASE WHEN movement_type = 'FOUND_REPLACED' THEN quantity ELSE 0 END) as restored_sum
                FROM inventory_movements 
                WHERE movement_type IN ('REPAIRED', 'FOUND_REPLACED')
                GROUP BY product_id
            ) mvt ON p.id = mvt.product_id
            WHERE dmg.damaged_sum > 0 OR dmg.missing_sum > 0 OR mvt.repaired_sum > 0 OR mvt.restored_sum > 0
        ");
        $itemDamageStats = [];
        if ($itemStatsStmt) {
            while ($row = $itemStatsStmt->fetch(PDO::FETCH_ASSOC)) {
                $totalDmg = floatval($row['total_damaged']);
                $totalRep = floatval($row['total_repaired']);
                $totalMis = floatval($row['total_missing']);
                $totalRes = floatval($row['total_restored']);
                $itemDamageStats[$row['product_id']] = [
                    'product_id' => $row['product_id'],
                    'total_damaged' => $totalDmg,
                    'total_repaired' => $totalRep,
                    'net_damaged' => max(0, $totalDmg - $totalRep),
                    'total_missing' => $totalMis,
                    'total_restored' => $totalRes,
                    'net_missing' => max(0, $totalMis - $totalRes)
                ];
            }
        }

        echo json_encode([
            'success' => true,
            'rentals' => $rentals,
            'item_damage_stats' => $itemDamageStats,
            'summary' => [
                'total_records' => intval($globSummary['total_records'] ?? count($rentals)),
                'filtered_count' => count($rentals),
                'active_rentals' => intval($globSummary['active_rentals'] ?? 0),
                'overdue_rentals' => intval($globSummary['overdue_rentals'] ?? 0),
                'items_on_hire' => $totalItemsOnHire,
                'caution_deposits_held' => floatval($globSummary['caution_deposits_held'] ?? 0.0),
                'damaged_count' => $netInRepair,
                'missing_count' => $netMissing
            ]
        ]);
        exit;
    }

    if ($method === 'POST') {
        $input = getJsonInput();
        $action = strtolower(trim((string)($input['action'] ?? 'create')));

        // -------------------------------------------------------------
        // ACTION: CREATE / DISPATCH RENTAL OR ADVANCE QUOTATION BOOKING
        // -------------------------------------------------------------
        if ($action === 'create' || $action === 'dispatch' || $action === 'book' || $action === 'quote') {
            requirePermission('manage_sales');

            $isBooking = ($action === 'book' || $action === 'quote' || strtoupper(trim((string)($input['status'] ?? ''))) === 'BOOKED');
            $rentalStatus = $isBooking ? 'BOOKED' : 'DISPATCHED';

            $customerName = trim((string)($input['customer_name'] ?? ''));
            if ($customerName === '') {
                http_response_code(422);
                echo json_encode(['success' => false, 'error' => 'Customer name is required for rental contract.']);
                exit;
            }

            $customerId = trim((string)($input['customer_id'] ?? 'cust-walkin'));
            $customerPhone = trim((string)($input['customer_phone'] ?? ''));
            $customerIdCard = trim((string)($input['customer_id_card'] ?? ''));
            $eventLocation = trim((string)($input['event_location'] ?? ''));
            $branchCode = trim((string)($input['branch_code'] ?? 'MAIN-01'));
            if ($branchCode === '') $branchCode = 'MAIN-01';
            $terminalId = strtoupper(trim((string)($input['terminal_id'] ?? 'REG-01')));
            if ($terminalId === '') $terminalId = 'REG-01';

            $pickupDate = trim((string)($input['pickup_date'] ?? date('Y-m-d')));
            $durationDays = max(1, (int)($input['duration_days'] ?? 1));
            $returnDueDate = trim((string)($input['return_due_date'] ?? date('Y-m-d', strtotime("+$durationDays days", strtotime($pickupDate)))));

            $cautionDeposit = max(0.0, floatval($input['caution_deposit'] ?? 0.0));
            $lateFeePerDay = max(0.0, floatval($input['late_fee_per_day'] ?? 0.0));
            $paymentMethod = strtoupper(trim((string)($input['payment_method'] ?? 'CASH')));
            $paymentStatus = strtoupper(trim((string)($input['payment_status'] ?? 'PAID')));
            if (!in_array($paymentStatus, ['PAID', 'PENDING', 'DEPOSIT_ONLY'], true)) {
                $paymentStatus = 'PAID';
            }
            $cautionDepositStatus = ($paymentStatus === 'PENDING') ? 'PENDING' : 'HELD';
            $notes = trim((string)($input['notes'] ?? ''));

            $items = $input['items'] ?? [];
            if (!is_array($items) || count($items) === 0) {
                http_response_code(422);
                echo json_encode(['success' => false, 'error' => 'At least one rental equipment item is required.']);
                exit;
            }

            $db->beginTransaction();

            $subtotal = 0.0;
            $validatedItems = [];

            $binvStmt = $db->prepare("SELECT current_quantity FROM branch_inventory WHERE branch_code = ? AND product_id = ?");
            $prodStmt = $db->prepare("SELECT id, name, unit, selling_price, product_type FROM products WHERE id = ?");

            foreach ($items as $item) {
                $prodId = trim((string)($item['product_id'] ?? ''));
                $qty = max(1.0, floatval($item['quantity'] ?? 1.0));
                $dailyRate = floatval($item['daily_rate'] ?? 0.0);
                $damageUnit = floatval($item['damage_charge_unit'] ?? ($dailyRate * 2.0));
                $replaceUnit = floatval($item['replacement_charge_unit'] ?? ($dailyRate * 10.0));

                $prodStmt->execute([$prodId]);
                $prod = $prodStmt->fetch(PDO::FETCH_ASSOC);
                if (!$prod) {
                    $db->rollBack();
                    http_response_code(404);
                    echo json_encode(['success' => false, 'error' => "Equipment product '{$prodId}' does not exist."]);
                    exit;
                }

                $isService = (($prod['product_type'] ?? 'standard') === 'service');

                // If dailyRate <= 0, fallback to product selling price
                if ($dailyRate <= 0.0) {
                    $dailyRate = floatval($prod['selling_price'] ?? 0.0);
                }

                // Check stock availability if store profile restricts negative stock (only for physical items and live dispatches)
                if (!$isService && !$isBooking) {
                    $binvStmt->execute([$branchCode, $prodId]);
                    $availableStock = floatval($binvStmt->fetchColumn() ?: 0.0);

                    $allowNeg = (int)($db->query("SELECT allow_negative_stock FROM store_profile LIMIT 1")->fetchColumn() ?: 0);
                    if ($availableStock < $qty && $allowNeg !== 1) {
                        $db->rollBack();
                        http_response_code(422);
                        echo json_encode([
                            'success' => false,
                            'error' => "Insufficient stock for '{$prod['name']}': Only {$availableStock} available for hire, requested {$qty}."
                        ]);
                        exit;
                    }
                }

                $lineTotal = $qty * $dailyRate * $durationDays;
                $subtotal += $lineTotal;

                $validatedItems[] = [
                    'product_id' => $prodId,
                    'product_name' => $prod['name'],
                    'quantity' => $qty,
                    'daily_rate' => $dailyRate,
                    'line_total' => $lineTotal,
                    'damage_charge_unit' => $damageUnit,
                    'replacement_charge_unit' => $replaceUnit,
                    'is_service' => $isService,
                    'notes' => trim((string)($item['notes'] ?? ''))
                ];
            }

            $discount = max(0.0, floatval($input['discount'] ?? 0.0));
            $totalRentalAmount = max(0.0, $subtotal - $discount);

            // Generate unique rental number
            $rentalNum = 'RNT-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
            $rentalId = 'rnt-' . bin2hex(random_bytes(8));

            // Insert Rental Header
            $insRental = $db->prepare("INSERT INTO rentals (
                id, rental_number, customer_id, customer_name, customer_phone, customer_id_card, event_location,
                branch_code, terminal_id, pickup_date, return_due_date, duration_days, subtotal, discount, total_rental_amount,
                caution_deposit, caution_deposit_status, late_fee_per_day, payment_method, payment_status,
                status, notes, created_by, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))");

            $insRental->execute([
                $rentalId, $rentalNum, $customerId, $customerName, $customerPhone, $customerIdCard, $eventLocation,
                $branchCode, $terminalId, $pickupDate, $returnDueDate, $durationDays, $subtotal, $discount, $totalRentalAmount,
                $cautionDeposit, $cautionDepositStatus, $lateFeePerDay, $paymentMethod, $paymentStatus, $rentalStatus, $notes, $authUser['id'] ?? null
            ]);

            // Insert Items & Deduct Inventory
            $insItem = $db->prepare("INSERT INTO rental_items (
                id, rental_id, product_id, product_name, quantity_dispatched, daily_rate, line_total,
                damage_charge_unit, replacement_charge_unit, notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            $deductBinv = $db->prepare("UPDATE branch_inventory SET current_quantity = current_quantity - ?, updated_at = datetime('now')
                                        WHERE branch_code = ? AND product_id = ?");
            $deductInv = $db->prepare("UPDATE inventory SET current_quantity = current_quantity - ?, updated_at = datetime('now')
                                       WHERE product_id = ?");
            $movStmt = $db->prepare("INSERT INTO inventory_movements (id, product_id, movement_type, quantity, reference_id, unit_price, notes, branch_code, created_at)
                                     VALUES (?, ?, 'SALE', ?, ?, ?, ?, ?, datetime('now'))");

            foreach ($validatedItems as $vItem) {
                $itemId = 'rnti-' . bin2hex(random_bytes(6));
                $insItem->execute([
                    $itemId, $rentalId, $vItem['product_id'], $vItem['product_name'], $vItem['quantity'],
                    $vItem['daily_rate'], $vItem['line_total'], $vItem['damage_charge_unit'],
                    $vItem['replacement_charge_unit'], $vItem['notes']
                ]);

                // Deduct inventory only for physical assets on live dispatches (bookings do not lock current stock until dispatch date)
                if (empty($vItem['is_service']) && !$isBooking) {
                    $deductBinv->execute([$vItem['quantity'], $branchCode, $vItem['product_id']]);
                    $deductInv->execute([$vItem['quantity'], $vItem['product_id']]);

                    // Movement record
                    $movStmt->execute([
                        'mov-' . bin2hex(random_bytes(6)),
                        $vItem['product_id'],
                        -$vItem['quantity'],
                        $rentalId,
                        $vItem['daily_rate'],
                        "Rental Dispatch: {$vItem['quantity']} on {$rentalNum} to {$customerName}",
                        $branchCode
                    ]);
                }
            }

            $db->commit();

            $logLabel = $isBooking ? 'RENTAL_BOOKING' : 'RENTAL_DISPATCH';
            $logMsg = $isBooking
                ? "Created rental quotation & advance booking {$rentalNum} for {$customerName} (Estimated Total: GH₵{$totalRentalAmount})"
                : "Dispatched rental {$rentalNum} for {$customerName} (Deposit: GH₵{$cautionDeposit}, Total: GH₵{$totalRentalAmount})";
            logActivity($db, $authUser['id'] ?? 0, $authUser['full_name'] ?? 'User', $authUser['role_name'] ?? 'Cashier', $logLabel, $logMsg);

            echo json_encode([
                'success' => true,
                'message' => $isBooking ? "Rental quotation & booking {$rentalNum} saved successfully." : "Rental dispatch {$rentalNum} successfully created and equipment allocated.",
                'rental_id' => $rentalId,
                'rental_number' => $rentalNum,
                'status' => $rentalStatus,
                'total_rental_amount' => $totalRentalAmount,
                'caution_deposit' => $cautionDeposit
            ]);
            exit;
        }

        // -------------------------------------------------------------
        // ACTION: DISPATCH ADVANCE BOOKING
        // -------------------------------------------------------------
        if ($action === 'dispatch_booking' || $action === 'activate') {
            requirePermission('manage_sales');

            $rentalId = trim((string)($input['rental_id'] ?? $input['id'] ?? ''));
            if ($rentalId === '') {
                http_response_code(422);
                echo json_encode(['success' => false, 'error' => 'Rental ID is required.']);
                exit;
            }

            $stmt = $db->prepare("SELECT * FROM rentals WHERE id = ?");
            $stmt->execute([$rentalId]);
            $rental = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$rental) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Rental booking not found.']);
                exit;
            }

            if ($rental['status'] !== 'BOOKED') {
                http_response_code(422);
                echo json_encode(['success' => false, 'error' => "Only bookings with status 'BOOKED' can be dispatched. Current status is '{$rental['status']}'."]);
                exit;
            }

            $branchCode = $rental['branch_code'] ?: 'MAIN-01';

            $itemsStmt = $db->prepare("
                SELECT ri.*, p.id AS live_product_id, p.product_type
                FROM rental_items ri
                LEFT JOIN products p ON ri.product_id = p.id
                WHERE ri.rental_id = ?
            ");
            $itemsStmt->execute([$rentalId]);
            $items = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);

            $db->beginTransaction();

            $resolveByNameStmt = $db->prepare("SELECT id, product_type FROM products WHERE LOWER(TRIM(name)) = LOWER(TRIM(?)) ORDER BY is_active DESC, updated_at DESC LIMIT 1");
            $relinkItemStmt = $db->prepare("UPDATE rental_items SET product_id = ? WHERE id = ?");
            foreach ($items as &$itRef) {
                if (empty($itRef['live_product_id']) && !empty($itRef['product_name'])) {
                    $resolveByNameStmt->execute([$itRef['product_name']]);
                    $foundProd = $resolveByNameStmt->fetch(PDO::FETCH_ASSOC);
                    $resolveByNameStmt->closeCursor();
                    if ($foundProd) {
                        $itRef['product_id'] = $foundProd['id'];
                        $itRef['live_product_id'] = $foundProd['id'];
                        $itRef['product_type'] = $foundProd['product_type'] ?? 'standard';
                        $relinkItemStmt->execute([$foundProd['id'], $itRef['id']]);
                    }
                }
            }
            unset($itRef);

            $binvStmt = $db->prepare("SELECT current_quantity FROM branch_inventory WHERE branch_code = ? AND product_id = ?");
            $allowNeg = (int)($db->query("SELECT allow_negative_stock FROM store_profile LIMIT 1")->fetchColumn() ?: 0);

            // Verify stock for physical items
            foreach ($items as $it) {
                $isService = (($it['product_type'] ?? 'standard') === 'service');
                if (!$isService) {
                    $binvStmt->execute([$branchCode, $it['product_id']]);
                    $avail = floatval($binvStmt->fetchColumn() ?: 0.0);
                    $qty = floatval($it['quantity_dispatched']);
                    if ($avail < $qty && $allowNeg !== 1) {
                        $db->rollBack();
                        http_response_code(422);
                        echo json_encode([
                            'success' => false,
                            'error' => "Cannot dispatch booking: Insufficient stock for '{$it['product_name']}'. Only {$avail} currently in warehouse, {$qty} required."
                        ]);
                        exit;
                    }
                }
            }

            $deductBinv = $db->prepare("UPDATE branch_inventory SET current_quantity = current_quantity - ?, updated_at = datetime('now') WHERE branch_code = ? AND product_id = ?");
            $deductInv = $db->prepare("UPDATE inventory SET current_quantity = current_quantity - ?, updated_at = datetime('now') WHERE product_id = ?");
            $movStmt = $db->prepare("INSERT INTO inventory_movements (id, product_id, movement_type, quantity, reference_id, unit_price, notes, branch_code, created_at)
                                     VALUES (?, ?, 'SALE', ?, ?, ?, ?, ?, datetime('now'))");

            foreach ($items as $it) {
                $isService = (($it['product_type'] ?? 'standard') === 'service');
                if (!$isService) {
                    $qty = floatval($it['quantity_dispatched']);
                    $deductBinv->execute([$qty, $branchCode, $it['product_id']]);
                    $deductInv->execute([$qty, $it['product_id']]);
                    $movStmt->execute([
                        'mov-' . bin2hex(random_bytes(6)),
                        $it['product_id'],
                        -$qty,
                        $rentalId,
                        $it['daily_rate'],
                        "Rental Booking Dispatched: {$qty} on {$rental['rental_number']} to {$rental['customer_name']}",
                        $branchCode
                    ]);
                }
            }

            $upd = $db->prepare("UPDATE rentals SET status = 'DISPATCHED', pickup_date = date('Y-m-d'), updated_at = datetime('now') WHERE id = ?");
            $upd->execute([$rentalId]);

            logActivity($db, $authUser['id'] ?? 1, $authUser['full_name'] ?? 'Staff', $authUser['role_name'] ?? 'Staff',
                'RENTAL_DISPATCH', "Dispatched booked rental {$rental['rental_number']} for customer '{$rental['customer_name']}'.");

            $db->commit();

            echo json_encode([
                'success' => true,
                'message' => "Rental booking {$rental['rental_number']} successfully dispatched and equipment allocated!",
                'rental_id' => $rentalId
            ]);
            exit;
        }

        // -------------------------------------------------------------
        // ACTION: CHECK-IN / RETURN INSPECTION & SETTLEMENT
        // -------------------------------------------------------------
        if ($action === 'checkin' || $action === 'return' || $action === 'settle') {
            requirePermission('manage_sales');

            $rentalId = trim((string)($input['rental_id'] ?? ''));
            if ($rentalId === '') {
                http_response_code(422);
                echo json_encode(['success' => false, 'error' => 'Rental ID is required.']);
                exit;
            }

            $stmt = $db->prepare("SELECT * FROM rentals WHERE id = ?");
            $stmt->execute([$rentalId]);
            $rental = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$rental) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Rental contract not found.']);
                exit;
            }

            if ($rental['status'] === 'RETURNED' || $rental['status'] === 'CANCELLED') {
                http_response_code(422);
                echo json_encode(['success' => false, 'error' => "This rental is already {$rental['status']} and settled."]);
                exit;
            }

            $returnedItems = $input['returned_items'] ?? [];
            if (!is_array($returnedItems) || count($returnedItems) === 0) {
                http_response_code(422);
                echo json_encode(['success' => false, 'error' => 'Return inspection items are required.']);
                exit;
            }

            $typedReturnDate = trim((string)($input['actual_return_date'] ?? ''));
            $returnNotes = trim((string)($input['notes'] ?? ''));

            $db->beginTransaction();

            // Fetch stored rental items
            $itemStmt = $db->prepare("SELECT * FROM rental_items WHERE rental_id = ?");
            $itemStmt->execute([$rentalId]);
            $existingItems = [];
            foreach ($itemStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $existingItems[$row['id']] = $row;
            }

            $totalDamageFee = 0.0;
            $totalMissingFee = 0.0;
            $clampedLines = 0;

            $updateItemStmt = $db->prepare("UPDATE rental_items SET
                quantity_returned_good = ?, quantity_damaged = ?, quantity_missing = ?, notes = ?
                WHERE id = ?");

            $restoreBinv = $db->prepare("UPDATE branch_inventory SET current_quantity = current_quantity + ?, updated_at = datetime('now')
                                         WHERE branch_code = ? AND product_id = ?");
            $restoreInv = $db->prepare("UPDATE inventory SET current_quantity = current_quantity + ?, updated_at = datetime('now')
                                        WHERE product_id = ?");
            $movStmt = $db->prepare("INSERT INTO inventory_movements (id, product_id, movement_type, quantity, reference_id, unit_price, notes, branch_code, created_at)
                                     VALUES (?, ?, 'RETURN', ?, ?, 0.0, ?, ?, datetime('now'))");

            foreach ($returnedItems as $retItem) {
                $itemId = trim((string)($retItem['item_id'] ?? ''));
                if (!isset($existingItems[$itemId])) continue;

                $orig = $existingItems[$itemId];
                $dispatched = floatval($orig['quantity_dispatched']);

                $good = max(0.0, floatval($retItem['quantity_returned_good'] ?? $dispatched));
                $damaged = max(0.0, floatval($retItem['quantity_damaged'] ?? 0.0));
                $missing = max(0.0, floatval($retItem['quantity_missing'] ?? 0.0));

                // The inspection says what came back out of what went out, and nothing beyond it.
                // Good chairs counted above the chairs dispatched would put furniture on a shelf
                // the shop does not own, and a damaged or missing claim above the dispatch would
                // bill a hirer for equipment that was never lent.
                $damaged = min($damaged, $dispatched);
                $missing = min($missing, $dispatched - $damaged);
                if ($good + $damaged + $missing > $dispatched + 0.0001) $clampedLines++;
                $good = min($good, $dispatched - $damaged - $missing);

                // The charges are the rates on the contract the hirer signed. The form shows them
                // so the counter can see what a chair in pieces costs; taking the figure that
                // arrived with the return would let the return price itself.
                $damageUnitRate = floatval($orig['damage_charge_unit'] ?? 0.0);
                $replaceUnitRate = floatval($orig['replacement_charge_unit'] ?? 0.0);

                $lineDamage = $damaged * $damageUnitRate;
                $lineMissing = $missing * $replaceUnitRate;

                $totalDamageFee += $lineDamage;
                $totalMissingFee += $lineMissing;

                $itemNotes = trim((string)($retItem['notes'] ?? ''));
                $updateItemStmt->execute([$good, $damaged, $missing, $itemNotes, $itemId]);

                // Check if product is physical before restoring inventory (relink by name if product_id was re-imported)
                $prodTypeStmt = $db->prepare("SELECT id, product_type FROM products WHERE id = ?");
                $prodTypeStmt->execute([$orig['product_id']]);
                $prodRow = $prodTypeStmt->fetch(PDO::FETCH_ASSOC);
                $prodTypeStmt->closeCursor();
                if (!$prodRow && !empty($orig['product_name'])) {
                    $byNameStmt = $db->prepare("SELECT id, product_type FROM products WHERE LOWER(TRIM(name)) = LOWER(TRIM(?)) ORDER BY is_active DESC, updated_at DESC LIMIT 1");
                    $byNameStmt->execute([$orig['product_name']]);
                    $prodRow = $byNameStmt->fetch(PDO::FETCH_ASSOC);
                    $byNameStmt->closeCursor();
                    if ($prodRow) {
                        $orig['product_id'] = $prodRow['id'];
                        $db->prepare("UPDATE rental_items SET product_id = ? WHERE id = ?")->execute([$prodRow['id'], $itemId]);
                    }
                }
                $hasLiveProduct = !empty($prodRow['id']);
                $pType = $prodRow['product_type'] ?? 'standard';

                // Restore good equipment into branch inventory (only physical goods that still exist in products)
                if ($hasLiveProduct && $pType !== 'service' && $good > 0) {
                    $restoreBinv->execute([$good, $rental['branch_code'], $orig['product_id']]);
                    $restoreInv->execute([$good, $orig['product_id']]);
                    $movStmt->execute([
                        'mov-' . bin2hex(random_bytes(6)),
                        $orig['product_id'],
                        $good,
                        $rentalId,
                        "Returned Good: {$good} pcs from rental {$rental['rental_number']}",
                        $rental['branch_code']
                    ]);
                }

                if ($hasLiveProduct && $damaged > 0) {
                    $movStmt->execute([
                        'mov-' . bin2hex(random_bytes(6)),
                        $orig['product_id'],
                        0,
                        $rentalId,
                        "Returned Damaged: {$damaged} pcs from rental {$rental['rental_number']} (Fee: GH₵{$lineDamage})",
                        $rental['branch_code']
                    ]);
                }

                if ($hasLiveProduct && $missing > 0) {
                    $movStmt->execute([
                        'mov-' . bin2hex(random_bytes(6)),
                        $orig['product_id'],
                        0,
                        $rentalId,
                        "Missing / Lost: {$missing} pcs from rental {$rental['rental_number']} (Fee: GH₵{$lineMissing})",
                        $rental['branch_code']
                    ]);
                }
            }

            // The penalty is the contract's own daily rate against the days the contract says the
            // equipment was late, and the server works it out. A hire back four days after its due
            // date on a GH₵50/day agreement is GH₵200 whatever the till typed - both when the
            // counter zeroed it to keep a customer happy and when a hand named a larger figure
            // than the shop agreed to charge.
            $dueDate = (string)$rental['return_due_date'];
            $lateRatePerDay = max(0.0, floatval($rental['late_fee_per_day'] ?? 0.0));

            // The day the kit came back is written on the desk's own paper, so the form asks and
            // the answer is not nonsense - but that day is also what the late fee is counted
            // against, and a check-in dated back to the due date erases a penalty the contract
            // earned. Nothing about typing yesterday looks like a write-down, so nothing here used
            // to ask who was allowed to. The question is what the date is worth in money: a date
            // that charges the same or more is the desk's record of a fact, and any hand may file
            // it; a date that charges less is a write-down, and is a manager's act with a name on
            // it. A date the shop has not reached yet is neither, and is held at today.
            $shopToday = date('Y-m-d');
            $whoDated = trim((string)($authUser['full_name'] ?? $authUser['username'] ?? 'an attendant'));
            $actualReturnDate = $shopToday;
            $returnDateNote = '';
            $returnDateTold = '';
            $dueStamp = strtotime($dueDate);
            $lateDaysFor = static function (int $stamp) use ($dueStamp, $lateRatePerDay): float {
                if ($dueStamp === false || $stamp <= $dueStamp) return 0.0;
                return max(0, (int)ceil(($stamp - $dueStamp) / 86400)) * $lateRatePerDay;
            };
            $typedStamp = ($typedReturnDate !== '') ? strtotime($typedReturnDate) : false;
            if ($typedStamp === false) {
                if ($typedReturnDate !== '') {
                    $returnDateTold = sprintf(" '%s' is not a date the shop can read, so the check-in is booked on %s.",
                        $typedReturnDate, $shopToday);
                }
            } elseif ($typedStamp > strtotime($shopToday)) {
                $returnDateNote = "\n[Return Dated Forward]: held at {$shopToday} by {$whoDated}, and a check-in cannot be booked on a day the shop has not reached";
                $returnDateTold = sprintf(" The check-in is booked on %s, not forward - the shop cannot charge for days that have not passed.", $shopToday);
            } elseif ($lateDaysFor($typedStamp) < $lateDaysFor(strtotime($shopToday)) - 0.009) {
                if (hasPermission($authUser, 'manage_settings')) {
                    $pickupStamp = strtotime((string)($rental['pickup_date'] ?? ''));
                    $heldAtPickup = ($pickupStamp !== false && $typedStamp < $pickupStamp);
                    $actualReturnDate = date('Y-m-d', $heldAtPickup ? $pickupStamp : $typedStamp);
                    $returnDateNote = "\n[Return Dated Back]: booked on " . $actualReturnDate
                        . " instead of {$shopToday} by {$whoDated}"
                        . ($heldAtPickup ? ', held at the day it went out' : '');
                } else {
                    $returnDateTold = sprintf(" The return is booked on %s, the day the shop's clock says. Dating a check-in back moves the late fee with it, and needs the Manage Settings right.", $shopToday);
                }
            } else {
                $actualReturnDate = date('Y-m-d', $typedStamp);
            }

            $daysLate = 0;
            if ($actualReturnDate > $dueDate) {
                $daysLate = max(0, (int)ceil((strtotime($actualReturnDate) - strtotime($dueDate)) / 86400));
            }
            $lateFeeCharged = $daysLate * $lateRatePerDay;
            $lateFeeWaived = 0.0;
            if (isset($input['late_fee_charged']) && $lateFeeCharged > 0.009) {
                $typedFee = max(0.0, floatval($input['late_fee_charged']));
                // Writing a penalty down is a manager's act. A shop that lets any counter do it
                // quietly loses the only record of why the hirer paid less than the paper says.
                if ($typedFee < $lateFeeCharged - 0.009 && hasPermission($authUser, 'manage_settings')) {
                    $lateFeeWaived = $lateFeeCharged - $typedFee;
                    $lateFeeCharged = $typedFee;
                }
            }

            // Total Deductions & Caution Deposit Settlement (Supports Pay on Return / Postpaid)
            $cautionDepositHeld = ($rental['caution_deposit_status'] === 'HELD') ? floatval($rental['caution_deposit'] ?? 0.0) : 0.0;
            $unpaidRental = (strtoupper($rental['payment_status'] ?? 'PAID') !== 'PAID') ? floatval($rental['total_rental_amount'] ?? 0.0) : 0.0;
            $totalPenalties = $totalDamageFee + $totalMissingFee + $lateFeeCharged;
            $totalCustomerObligation = $unpaidRental + $totalPenalties;

            $depositRefunded = 0.0;
            $additionalOwed = 0.0;
            $depositStatus = 'REFUNDED';

            if ($cautionDepositHeld >= $totalCustomerObligation) {
                $depositRefunded = $cautionDepositHeld - $totalCustomerObligation;
                $additionalOwed = 0.0;
                $depositStatus = ($depositRefunded == $cautionDepositHeld) ? 'REFUNDED' : 'PARTIALLY_REFUNDED';
            } else {
                $depositRefunded = 0.0;
                $additionalOwed = $totalCustomerObligation - $cautionDepositHeld;
                $depositStatus = ($cautionDepositHeld > 0) ? 'FORFEITED' : 'N/A';
            }

            // What the deposit did not reach is still owed. Stamping every settled hire 'PAID'
            // here turned an uncollected balance into a card that read Paid Upfront, which is the
            // one thing a shopkeeper cannot argue with a customer over afterwards.
            $paymentStatus = ($additionalOwed > 0.009) ? 'BALANCE_OWED' : 'PAID';

            // Update Rental Header
            $updRental = $db->prepare("UPDATE rentals SET
                actual_return_date = ?,
                damage_fee_charged = ?,
                missing_fee_charged = ?,
                late_fee_charged = ?,
                deposit_refunded = ?,
                additional_amount_owed = ?,
                caution_deposit_status = ?,
                payment_status = ?,
                status = 'RETURNED',
                notes = ?,
                updated_at = datetime('now')
                WHERE id = ?");

            $waiverNote = $lateFeeWaived > 0.009
                ? "\n[Late Fee Waived]: GH₵" . number_format($lateFeeWaived, 2) . " of GH₵"
                  . number_format($lateFeeCharged + $lateFeeWaived, 2) . " written down by "
                  . trim((string)($authUser['full_name'] ?? $authUser['username'] ?? 'an attendant'))
                : '';
            $countNote = $clampedLines > 0
                ? "\n[Return Inspection]: counted against the quantity dispatched on {$clampedLines} line(s)"
                : '';
            $combinedNotes = trim($rental['notes']
                . ($returnNotes !== '' ? "\n[Return Notes]: " . $returnNotes : '')
                . $countNote . $waiverNote . $returnDateNote);

            $updRental->execute([
                $actualReturnDate,
                $totalDamageFee,
                $totalMissingFee,
                $lateFeeCharged,
                $depositRefunded,
                $additionalOwed,
                $depositStatus,
                $paymentStatus,
                $combinedNotes,
                $rentalId
            ]);

            $db->commit();

            logActivity($db, $authUser['id'] ?? 0, $authUser['full_name'] ?? 'User', $authUser['role_name'] ?? 'Cashier', 'RENTAL_RETURN',
                "Processed return for {$rental['rental_number']} (Refunded: GH₵{$depositRefunded}, Penalties: GH₵{$totalPenalties}, Additional Owed: GH₵{$additionalOwed})");

            $returnMessage = "Rental check-in completed. Caution deposit settled.";
            if ($additionalOwed > 0.009) {
                $returnMessage = "Rental returned and settled on the book. GH₵" . number_format($additionalOwed, 2)
                    . " is still owed - the deposit did not reach what was charged.";
            }
            if (isset($input['late_fee_charged']) && $lateFeeWaived === 0.0
                && abs(max(0.0, floatval($input['late_fee_charged'])) - $lateFeeCharged) > 0.009) {
                $returnMessage .= " The late fee stands at GH₵" . number_format($lateFeeCharged, 2)
                    . " ({$daysLate} day(s) at the agreed GH₵" . number_format($lateRatePerDay, 2)
                    . "/day); writing it down needs Manage Settings.";
            }
            $returnMessage .= $returnDateTold;

            echo json_encode([
                'success' => true,
                'message' => $returnMessage,
                'rental_number' => $rental['rental_number'],
                'actual_return_date' => $actualReturnDate,
                'payment_status' => $paymentStatus,
                'days_overdue_charged' => $daysLate,
                'late_fee_expected' => $daysLate * $lateRatePerDay,
                'late_fee_waived' => $lateFeeWaived,
                'caution_deposit_held' => $cautionDepositHeld,
                'total_penalties' => $totalPenalties,
                'damage_fee' => $totalDamageFee,
                'missing_fee' => $totalMissingFee,
                'late_fee' => $lateFeeCharged,
                'deposit_refunded' => $depositRefunded,
                'additional_amount_owed' => $additionalOwed,
                'caution_deposit_status' => $depositStatus
            ]);
            exit;
        }

        // Action: Settle outstanding rental balance / penalties owed
        if ($action === 'settle_balance' || $action === 'pay_balance') {
            $rentalId = trim((string)($input['rental_id'] ?? ''));
            if ($rentalId === '') {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Rental ID is required.']);
                exit;
            }

            $stmt = $db->prepare("SELECT * FROM rentals WHERE id = ?");
            $stmt->execute([$rentalId]);
            $rental = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$rental) {
                http_response_code(404);
                echo json_encode(['success' => false, 'error' => 'Rental record not found.']);
                exit;
            }

            $totalAdditionalOwed = round(floatval($rental['additional_amount_owed'] ?? 0.0), 2);
            $alreadyPaid = round(floatval($rental['balance_paid'] ?? 0.0), 2);
            $currentNetOwed = max(0.0, round($totalAdditionalOwed - $alreadyPaid, 2));

            if ($currentNetOwed <= 0.009 && strtoupper(trim((string)$rental['payment_status'])) === 'PAID') {
                echo json_encode([
                    'success' => true,
                    'message' => "Rental #{$rental['rental_number']} balance is already fully settled.",
                    'rental' => $rental
                ]);
                exit;
            }

            if ($currentNetOwed <= 0.009 && $totalAdditionalOwed > 0) {
                $currentNetOwed = $totalAdditionalOwed;
            }

            $amountPaid = round(floatval($input['amount_paid'] ?? $currentNetOwed), 2);
            if ($amountPaid <= 0.0) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Payment amount must be greater than zero.']);
                exit;
            }

            if ($amountPaid > $currentNetOwed + 0.05) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => "Amount paid (GH₵" . number_format($amountPaid, 2) . ") cannot exceed outstanding balance (GH₵" . number_format($currentNetOwed, 2) . ")."]);
                exit;
            }

            $paymentMethod = strtoupper(trim((string)($input['payment_method'] ?? 'CASH')));
            if (!in_array($paymentMethod, ['CASH', 'MOMO', 'CARD', 'BANK', 'ACCOUNT'])) {
                $paymentMethod = 'CASH';
            }

            $settlementNotes = trim((string)($input['notes'] ?? ''));
            $newBalancePaid = round($alreadyPaid + $amountPaid, 2);
            $remainingOwed = max(0.0, round($currentNetOwed - $amountPaid, 2));
            $newPaymentStatus = ($remainingOwed <= 0.009) ? 'PAID' : 'BALANCE_OWED';

            $auditNote = "\n[Balance Settled " . date('Y-m-d H:i') . "]: Received GH₵" . number_format($amountPaid, 2)
                . " via {$paymentMethod}" . ($settlementNotes !== '' ? " ({$settlementNotes})" : "")
                . " by " . ($authUser['full_name'] ?? 'Staff') . ". Outstanding balance remaining: GH₵" . number_format($remainingOwed, 2);

            $mergedNotes = ($rental['notes'] ?? '') . $auditNote;

            $upd = $db->prepare("UPDATE rentals SET
                balance_paid = ?,
                payment_status = ?,
                payment_method = ?,
                notes = ?,
                updated_at = datetime('now')
                WHERE id = ?");
            $upd->execute([$newBalancePaid, $newPaymentStatus, $paymentMethod, $mergedNotes, $rentalId]);

            // If customer has a linked account in customers table, record payment ledger row
            if (!empty($rental['customer_id']) && $rental['customer_id'] !== 'cust-walkin') {
                try {
                    $custCheck = $db->prepare("SELECT id FROM customers WHERE id = ?");
                    $custCheck->execute([$rental['customer_id']]);
                    if ($custCheck->fetch()) {
                        $pStmt = $db->prepare("INSERT INTO customer_payments (id, customer_id, user_id, amount, payment_method, notes, created_at) VALUES (?, ?, ?, ?, ?, ?, datetime('now'))");
                        $pStmt->execute([
                            'pay_' . bin2hex(random_bytes(6)),
                            $rental['customer_id'],
                            $authUser['id'] ?? 1,
                            $amountPaid,
                            $paymentMethod,
                            "Settlement for Rental #{$rental['rental_number']}"
                        ]);
                    }
                } catch (Throwable $pe) {}
            }

            // Re-fetch updated rental
            $stmt->execute([$rentalId]);
            $updatedRental = $stmt->fetch(PDO::FETCH_ASSOC);

            logActivity($db, $authUser['id'] ?? 1, $authUser['full_name'] ?? 'System', $authUser['role_name'] ?? 'Staff',
                'RENTAL_SETTLEMENT', "Collected GH₵" . number_format($amountPaid, 2) . " balance for rental #{$rental['rental_number']} ('{$rental['customer_name']}'). Remaining owed: GH₵" . number_format($remainingOwed, 2));

            echo json_encode([
                'success' => true,
                'message' => ($remainingOwed <= 0.009)
                    ? "Rental #{$rental['rental_number']} balance settled in full!"
                    : "Received GH₵" . number_format($amountPaid, 2) . ". Remaining balance: GH₵" . number_format($remainingOwed, 2),
                'amount_paid' => $amountPaid,
                'remaining_owed' => $remainingOwed,
                'payment_status' => $newPaymentStatus,
                'rental' => $updatedRental
            ]);
            exit;
        }

        http_response_code(400);
        echo json_encode(['success' => false, 'error' => "Unknown action '{$action}'."]);
        exit;
    }

    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed.']);
} catch (Throwable $e) {
    if (isset($db) && $db instanceof PDO && $db->inTransaction()) {
        $db->rollBack();
    }
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
