// sw.js - Service Worker for StoreFlow
const CACHE_NAME = 'storeflow-cache-v206';

const STATIC_ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './favicon.ico',
  './assets/icons/favicon.ico',
  './assets/css/style.css',
  './assets/fontawesome/css/all.min.css',
  './assets/fontawesome/webfonts/fa-solid-900.woff2',
  './assets/fontawesome/webfonts/fa-regular-400.woff2',
  './assets/fontawesome/webfonts/fa-brands-400.woff2',
  './assets/js/html5-qrcode.min.js',
  './assets/js/qrcode.min.js',
  './assets/js/jsbarcode.all.min.js',
  './assets/js/dexie.min.js',
  './assets/js/nacl-fast.min.js',
  './assets/js/mobile-license.js',
  './assets/js/db.js',
  './assets/js/google-cloud.js',
  './assets/js/store-utils.js',
  './assets/js/app-session.js',
  './assets/js/app-shell.js',
  './assets/js/app-data.js',
  './assets/js/app.js',
  './assets/js/app-pos.js',
  './assets/js/app-products.js',
  './assets/js/app-batches.js',
  './assets/js/app-sales.js',
  './assets/js/app-returns.js',
  './assets/js/app-expenses.js',
  './assets/js/app-dashboard.js',
  './assets/js/app-purchases.js',
  './assets/js/app-vendors.js',
  './assets/js/app-customers.js',
  './assets/js/app-estimates.js',
  './assets/js/app-enterprise.js',
  './assets/js/app-rentals.js',
  './assets/icons/favicon-32.png',
  './assets/icons/apple-touch-icon.png',
  './assets/icons/icon-192.png',
  './assets/icons/icon-512.png',
  './assets/images/products/placeholder.svg',
  './assets/images/products/rice.svg',
  './assets/images/products/oil.svg',
  './assets/images/products/flour.svg',
  './assets/images/products/sugar.svg',
  './assets/images/products/pasta.svg',
  './assets/images/products/soap.svg'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('[ServiceWorker] Pre-caching static assets offline shell');
      return cache.addAll(STATIC_ASSETS);
    }).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            console.log('[ServiceWorker] Removing old cache', key);
            return caches.delete(key);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  // Only handle standard HTTP/HTTPS requests (ignore chrome-extension://, moz-extension://, etc.)
  if (!event.request.url.startsWith('http://') && !event.request.url.startsWith('https://')) {
    return;
  }

  const url = new URL(event.request.url);

  // If request is to API endpoints, try network first; if offline, return fallback
  if (url.pathname.includes('/api/')) {
    event.respondWith(
      fetch(event.request).catch(() => {
        // 503, not 200. The till decides whether a money move has to be re-tried by
        // looking at the response, and an answer that arrives with a success status
        // makes "nobody was there" indistinguishable from "the server agreed".
        return new Response(
          JSON.stringify({
            success: false,
            offline: true,
            message: 'Server currently offline. Data stored locally in IndexedDB.'
          }),
          {
            status: 503,
            statusText: 'Service Unavailable',
            headers: {
              'Content-Type': 'application/json',
              'Cache-Control': 'no-store'
            }
          }
        );
      })
    );
    return;
  }

  // Static Assets: Network First, fallback to Cache with ignoreSearch
  event.respondWith(
    fetch(event.request)
      .then((networkResponse) => {
        if (event.request.method === 'GET' && networkResponse.status === 200) {
          const responseToCache = networkResponse.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseToCache);
          });
        }
        return networkResponse;
      })
      .catch(() => caches.match(event.request, { ignoreSearch: true }))
  );
});
