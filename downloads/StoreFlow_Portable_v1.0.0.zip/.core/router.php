<?php
// router.php - Zero-Trust Allowlist Security Router for StoreFlow Built-in Server
// Enforces strict allowlisting: blocks all unauthorized access to databases, configs, and system files.

$rawUri = $_SERVER['REQUEST_URI'] ?? '/';
$uriPath = parse_url($rawUri, PHP_URL_PATH) ?: '/';

// 1. Normalize Path: Decode URL, replace backslashes, collapse repeated slashes
$path = rawurldecode($uriPath);

// A decoded NUL byte must be refused here, not later: realpath() raises an
// uncaught ValueError on it, and that fatal printed the document root, the PHP
// version and a stack trace to the browser - with HTTP 200 - even on the packaged
// build whose bundled php.ini sets display_errors=Off.
if (strpos($path, "\0") !== false) {
    http_response_code(403);
    header('Content-Type: text/plain');
    exit('403 Forbidden: Malformed path.');
}

$path = str_replace('\\', '/', $path);
$path = preg_replace('#/+#', '/', $path);

// 2. Strict Traversal Guard
if (strpos($path, '..') !== false) {
    http_response_code(403);
    header('Content-Type: text/plain');
    exit('403 Forbidden: Path traversal prohibited.');
}

// 3. Resolve Root & Target Real Paths
$rootDir = realpath(__DIR__);

// Handing a file out is not just a read: the till's own update has to reach the
// counter. The built-in server's static handler sends no validator at all - no
// ETag, no Last-Modified, no Cache-Control - so a browser is free to serve a
// cached copy for as long as it likes and never ask again. A tablet that visited
// a shop's till last year can therefore still be running last year's shell after
// the owner updates the machine, and the owner has no way to see that from the
// counter. Revalidation is a 304 round-trip on a LAN, which is close to free, so
// every asset here is stamped and must revalidate.
$serveStatic = function (string $file, string $cacheControl = 'no-cache, must-revalidate') {
    $mtime = filemtime($file) ?: time();
    $size = (int)filesize($file);
    $etag = '"' . md5($file . '|' . $mtime . '|' . $size) . '"';
    $lastModified = gmdate('D, d M Y H:i:s', $mtime) . ' GMT';

    $clientEtag = trim($_SERVER['HTTP_IF_NONE_MATCH'] ?? '');
    $clientDate = trim($_SERVER['HTTP_IF_MODIFIED_SINCE'] ?? '');
    if ($clientEtag === $etag || ($clientDate !== '' && @strtotime($clientDate) === $mtime)) {
        http_response_code(304);
        header('ETag: ' . $etag);
        header('Last-Modified: ' . $lastModified);
        header('Cache-Control: ' . $cacheControl);
        exit;
    }

    $types = [
        'html' => 'text/html; charset=UTF-8',
        'js' => 'application/javascript; charset=UTF-8',
        'css' => 'text/css; charset=UTF-8',
        'json' => 'application/json; charset=UTF-8',
        'webmanifest' => 'application/manifest+json',
        'svg' => 'image/svg+xml',
        'png' => 'image/png',
        'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'gif' => 'image/gif',
        'ico' => 'image/x-icon',
        'woff' => 'font/woff',
        'woff2' => 'font/woff2',
        'ttf' => 'font/ttf',
        'otf' => 'font/otf',
        'eot' => 'application/vnd.ms-fontobject',
        'map' => 'application/json',
        'txt' => 'text/plain; charset=UTF-8',
    ];
    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
    header('Content-Type: ' . ($types[$ext] ?? 'application/octet-stream'));
    header('ETag: ' . $etag);
    header('Last-Modified: ' . $lastModified);
    header('Cache-Control: ' . $cacheControl);
    header('Content-Length: ' . $size);
    readfile($file);
    exit;
};

if ($path === '/' || $path === '') {
    $serveStatic($rootDir . DIRECTORY_SEPARATOR . 'index.html');
}

$rawTarget = $rootDir . str_replace('/', DIRECTORY_SEPARATOR, $path);
$targetFile = realpath($rawTarget);

// If file does not exist on disk
if (!$targetFile || !file_exists($targetFile) || is_dir($targetFile)) {
    http_response_code(404);
    header('Content-Type: text/plain');
    exit('404 Not Found');
}

// Ensure target sits strictly within the root directory. The separator matters: a
// document root of /htdocs/storemgt would otherwise accept a sibling project at
// /htdocs/storemgt-public, because one real path is a string prefix of the other.
if (strpos($targetFile, $rootDir . DIRECTORY_SEPARATOR) !== 0) {
    http_response_code(403);
    header('Content-Type: text/plain');
    exit('403 Forbidden: Access out of root.');
}

// 4. Strict Allowlist Definition
// ONLY these exact root files and subdirectories may ever be served over HTTP:
$allowedExactFiles = [
    $rootDir . DIRECTORY_SEPARATOR . 'index.html',
    $rootDir . DIRECTORY_SEPARATOR . 'sw.js',
    $rootDir . DIRECTORY_SEPARATOR . 'manifest.json',
    $rootDir . DIRECTORY_SEPARATOR . 'favicon.ico'
];

$allowedDirs = [
    $rootDir . DIRECTORY_SEPARATOR . 'assets',
    $rootDir . DIRECTORY_SEPARATOR . 'api' . DIRECTORY_SEPARATOR . 'endpoints'
];

$isAllowed = in_array($targetFile, $allowedExactFiles, true);

if (!$isAllowed) {
    foreach ($allowedDirs as $allowedDir) {
        if (strpos($targetFile, $allowedDir . DIRECTORY_SEPARATOR) === 0) {
            $isAllowed = true;
            break;
        }
    }
}

// If resource is not on the Allowlist, immediately drop with 403
// (Guarantees /data, /api/config, /installer, /tools, /php, .db, .cache, .log, .zip are 100% blocked)
if (!$isAllowed) {
    http_response_code(403);
    header('Content-Type: text/plain');
    exit('403 Forbidden: Direct access to this resource is prohibited.');
}

// 5. Allowed PHP Script Execution
if (substr($targetFile, -4) === '.php') {
    $endpointsDir = $rootDir . DIRECTORY_SEPARATOR . 'api' . DIRECTORY_SEPARATOR . 'endpoints';
    if (strpos($targetFile, $endpointsDir . DIRECTORY_SEPARATOR) === 0) {
        chdir(dirname($targetFile));
        require $targetFile;
        exit;
    }
    http_response_code(403);
    exit('403 Forbidden');
}

// 6. Allowed Static Assets (CSS, JS, Fonts, Images, Icons)
// The service worker is the one file that must never be reused from a cache: a
// stale worker keeps serving the stale shell it was written to protect.
$swNoStore = basename($targetFile) === 'sw.js';
$serveStatic($targetFile, $swNoStore ? 'no-store, must-revalidate' : 'no-cache, must-revalidate');
