class StoreAppShell {
  constructor() {
    this.storage = new StoreFlowStorage();
    this.sessionManager = new StoreAppSession();
    this.currentView = localStorage.getItem('storeflow_active_view') || 'dashboard';
    this.isStandaloneOffline = (window.location.hostname === 'storeflow.local' || window.location.protocol === 'file:' || !!window.StoreFlowStandalone);
    this.isOnline = this.isStandaloneOffline ? false : navigator.onLine;
    this.storeProfile = {
      id: 1,
      store_name: 'Apex Wholesale & Retail Mart',
      tagline: 'Your Trusted Quality Goods Supplier',
      phone: '+1 (555) 234-5678',
      email: 'contact@apexstore.local',
      address: '104 Commerce Boulevard, Suite 2B',
      tax_number: 'TAX-89472190-TX',
      tax_rate: 0,
      currency_symbol: '$',
      currency_code: 'USD',
      receipt_header: 'Thank you for shopping with us!',
      receipt_footer: 'Goods received in good condition cannot be returned. We appreciate your patronage!',
      receipt_momo_note: '',
      show_tax_on_receipt: 1,
      show_cashier_on_receipt: 1,
      receipt_font_size: 'medium',
      receipt_font_weight: 'normal',
      receipt_font_family: 'monospace',
      receipt_paper_width: '80mm',
      receipt_spacing: 'ultra_compact',
      auto_backup_hours: 2,
      allow_negative_stock: 0
    };

    this.products = [];
    this.categories = [];
    this.customers = [];
    this.cart = [];
    this.sales = [];
    this.purchases = [];
    this.inventory = [];
    this.backups = [];
    this.users = [];
    this.roles = [];
    // Filled by fetchUsers() from the server's own answers; see getRolesAccessMapHTML().
    this.permissionCatalogue = null;
    this.canManageRoles = false;
    this.showNewRoleRow = false;
    this.activityLogs = [];

    this.currentUser = null;
    this.selectedPaymentMethod = 'CASH';
    this.pendingOosProductId = null;
    this.pendingOosUnitLabel = null;

    this.terminalId = this.normalizeTerminalId(localStorage.getItem('storeflow_terminal_id'));
    this.branchCode = this.storage.readText(localStorage, 'storeflow_branch_code', 'MAIN-01') || 'MAIN-01';
    this.branches = [];
    this.selectedBranchFilter = 'ALL';
    this.salesBranchFilter = 'ALL';
    this.inventoryBranchFilter = 'ALL';
    this.isMultiBranch = false;
    this.transfers = [];
    this.selectedStockModalProduct = null;
    this.currentTransferForWaybill = null;
    this.transferRowCounter = 0;

    this.printerMode = this.storage.readText(localStorage, 'storeflow_printer_mode', 'BROWSER') || 'BROWSER';
    this.serialPort = null;
    this.isPrinterConnected = false;
    this.currentSaleForReceipt = null;

    this.shifts = [];

    this.analyticsPreset = 'this_month';
    this.analyticsStartDate = '';
    this.analyticsEndDate = '';
    this.analyticsUserFilter = 'ALL';
    this.analyticsCompareWithPrior = true;

    this.vendors = [];
    this.vendorSearchTerm = '';
    this.vendorFilter = 'ALL';
    this.currentVendorForStatement = null;

    this._tabSessionId = 'tab_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
    this.syncChannel = null;
    this._pendingViewRefresh = null;

    this.isScreenLocked = false;
    this.lastUserActivity = Date.now();
    this.idleTimeoutMs = 30 * 60 * 1000; // 30 minutes inactivity timeout

    this._lastDeltaSyncTimestamp = null;
    this._deltaPollTimer = null;
    this._isDeltaPolling = false;

    this.init();
  }

  escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  async hashCredentials(username, password) {
    const encoder = new TextEncoder();
    const data = encoder.encode(`storeflow_salt:${String(username).toLowerCase().trim()}:${String(password)}`);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  safeJsonParse(value, fallback = {}) {
    return this.storage.parseJson(value, fallback);
  }

  // For embedding a value as a JS string literal inside an inline event attribute
  // (onclick="app.foo(HERE)"). escapeHtml alone is NOT enough: the HTML parser
  // decodes &#39; back to a quote before the JS is compiled, so a stored value
  // containing ' still terminates the string and injects a handler.
  // The literal is written with double quotes, so every call site puts it inside a
  // double-quoted attribute. The apostrophe is folded to a \u0027 escape as well: it is
  // the same character to the JS parser and it means the emitted literal can never
  // terminate a single-quoted attribute either, if one is ever written.
  jsStr(value) {
    return this.escapeHtml(JSON.stringify(String(value ?? '')).replace(/'/g, '\\u0027'));
  }

  // Register IDs reach DOM ids, storage keys, print headers and inline handlers, and one
  // of them arrives straight from a ?term= link. Keeping them to a shape that cannot carry
  // markup or a path means no consumer has to remember to escape.
  normalizeTerminalId(raw, fallback = 'REG-01') {
    const clean = String(raw ?? '').trim().toUpperCase().replace(/[^A-Z0-9_-]/g, '');
    return clean ? clean.slice(0, 16) : fallback;
  }

  // Offline sign-in is a stopgap for a till that cannot reach the server, not a parallel
  // account store. A grant records when it was issued, so a snapshot left behind for staff
  // who have since been deleted or moved on stops opening the till after a month offline.
  // The clock also bounds how long a captured snapshot stays usable.
  getOfflineHashes() {
    const ttlMs = 30 * 24 * 60 * 60 * 1000;
    const now = Date.now();
    const stored = this.safeJsonParse(localStorage.getItem('storeflow_offline_hashes'), {});
    const live = {};
    let pruned = false;
    Object.keys(stored).forEach((key) => {
      const grant = stored[key];
      const issuedAt = Number(grant && grant.granted_at) || 0;
      if (grant && issuedAt > 0 && now - issuedAt < ttlMs) {
        live[key] = grant;
      } else {
        pruned = true;
      }
    });
    if (pruned) localStorage.setItem('storeflow_offline_hashes', JSON.stringify(live));

    // Standalone fallback: If no offline account exists yet (e.g. fresh standalone Android APK launch),
    // seed the default admin account so store owners can log in and ring sales immediately offline!
    if (!live['admin']) {
      live['admin'] = {
        user: {
          id: 1,
          username: 'admin',
          full_name: 'Store Administrator',
          role_id: 1,
          role_name: 'Administrator',
          branch_code: 'MAIN-01',
          must_change_password: 1,
          permissions: {
            manage_inventory: true,
            manage_sales: true,
            view_reports: true,
            manage_users: true,
            system_settings: true,
            access_pos: true,
            delete_records: true
          }
        },
        hash: '624eb76c63b50f0d05e0dff94f3f904501b0ff3063a8978b32ea962968cd472b',
        granted_at: now
      };
      localStorage.setItem('storeflow_offline_hashes', JSON.stringify(live));
    } else if (live['admin'].hash === '624eb76c63b50f0d05e0dff94f3f904501b0ff3063a8978b32ea962968cd472b' && !live['admin'].user.has_pin) {
      // Default credentials are still in use; mandate initial password & PIN setup
      live['admin'].user.must_change_password = 1;
      localStorage.setItem('storeflow_offline_hashes', JSON.stringify(live));
    }

    return live;
  }

  saveOfflineGrant(username, user, hash) {
    const key = String(username || '').toLowerCase().trim();
    if (!key) return;
    const grants = this.getOfflineHashes();
    grants[key] = { user, hash, granted_at: Date.now() };
    localStorage.setItem('storeflow_offline_hashes', JSON.stringify(grants));
  }

  async apiFetch(url, options = {}) {
    if (this.isStandaloneOffline || window.location.hostname === 'storeflow.local' || window.location.protocol === 'file:') {
      // In Standalone Offline Mobile APK, relative PHP endpoints are unavailable.
      // Return a clean offline synthetic envelope so local caller routines resolve cleanly.
      return new Response(JSON.stringify({ success: true, offline: true, data: [] }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' }
      });
    }
    options.credentials = 'same-origin';
    const res = await fetch(url, options);
    if (res.status === 401 && !url.includes('action=login') && !url.includes('action=current')) {
      const wasActiveSession = !!this.currentUser;
      this.currentUser = null;
      localStorage.removeItem('storeflow_active_user');
      sessionStorage.removeItem('storeflow_active_user');
      await this.clearPrivilegedCaches();
      if (wasActiveSession) {
        this.showLogin();
        this.showToast('Session expired or unauthorized. Please sign in.', 'warning');
      }
    }
    if (res.status === 402) {
      // The server now refuses work on an unactivated terminal instead of only
      // letting the browser hide the UI; bring the paywall back up to match.
      this._sessionScope = 'expired';
      if (typeof this._showPaywall === 'function') this._showPaywall();
      this.showToast('StoreFlow is not activated on this terminal.', 'warning');
      return res;
    }
    if (!res.ok && res.status !== 401 && !(await this.isOfflineEnvelope(res))) {
      // A till holding the wrong book has been answered with a decision about whose records go
      // where, not with an outage - and syncOutbox puts the owner-facing question on the screen
      // for it. A generic "server error" toast over the top of that is how a shop learns the
      // wrong lesson from a refusal.
      if (!(await this.isBookMismatch(res))) {
        this.announceApiFailure(url, res);
      }
    }
    return res;
  }

  // The service worker answers an unreachable API with a 503 so callers can tell an
  // outage from a refusal. That shape must not raise the "server error" alarm on a till
  // that simply has no cable in — it is the offline mode working as designed.
  isOfflineEnvelope(res) {
    if (!res || res.status !== 503) return Promise.resolve(false);
    return res.clone().json()
      .then(body => !!(body && body.offline === true))
      .catch(() => false);
  }

  // 409 from sync.php with this code is the book saying "those records are not mine". It is
  // the one refusal the till handles by asking the owner rather than by raising an alarm, so it
  // has to be recognisable before anything else gets to describe it.
  isBookMismatch(res) {
    if (!res || res.status !== 409) return Promise.resolve(false);
    return res.clone().json()
      .then(body => !!(body && body.code === 'book_mismatch'))
      .catch(() => false);
  }

  // A 500 from an endpoint used to look like "no records" (on read) or a completed
  // save (on write), because every caller only inspected json.success. Surface it.
  announceApiFailure(url, res) {
    const endpoint = String(url).split('/').pop().split('?')[0];
    console.error(`API ${res.status} from ${url}`);
    if (Date.now() - (this._lastApiNoticeAt || 0) < 5000) return;
    this._lastApiNoticeAt = Date.now();
    let detail = `server error ${res.status}`;
    res.clone().json()
      .then(body => { if (body && typeof body.message === 'string' && body.message) detail = body.message; })
      .catch(() => { })
      .finally(() => this.showToast(`${endpoint}: ${detail}`, 'error'));
  }

  // Two very different things look the same to a cashier if the till does not separate
  // them: the server said no, and nobody was there to say anything. The first is a
  // decision about money that has to be read out loud; the second is the reason the
  // outbox exists. sw.js answers an unreachable API with 503 + offline:true, so an
  // envelope carrying that flag is the browser talking, not the shop's rules.
  async classifyApiResponse(res) {
    let body = null;
    try {
      body = await res.json();
    } catch (e) {
      body = null;
    }
    if (!body || typeof body !== 'object' || body.offline === true) {
      return { verdict: 'unreachable', body, status: res.status };
    }
    if (body.success) {
      return { verdict: 'accepted', body, status: res.status };
    }
    return {
      verdict: 'refused',
      body,
      status: res.status,
      message: typeof body.message === 'string' && body.message
        ? body.message
        : `The server refused this (HTTP ${res.status}).`
    };
  }

  getUserRoleName() {
    return (this.currentUser?.role_name || '').trim();
  }

  isCashier() {
    const role = this.getUserRoleName().toLowerCase();
    return role.includes('cashier') || (this.currentUser && Number(this.currentUser.role_id) === 3);
  }

  isStoreManager() {
    const role = this.getUserRoleName().toLowerCase();
    return role.includes('manager') || (this.currentUser && Number(this.currentUser.role_id) === 2);
  }

  isAdmin() {
    if (!this.currentUser) return false;
    const role = this.getUserRoleName().toLowerCase();
    return role.includes('admin') || Number(this.currentUser.role_id) === 1;
  }

  // Whether this till user may see what the goods cost the shop and what it made on
  // them, and so whether the screens draw those columns at all. It is api/config/db.php's
  // maySeeProductCost() restated in the till, field for field, because that function is what
  // decides whether the ledger row, the printed receipt, the return slip and the sync state
  // arrive with total_cost and gross_profit in them at all. Hiding the columns by role *name*
  // did not agree with that strip: an "Assistant Manager" or a "Supervisor" is not a Cashier
  // to this screen, so it drew both columns over rows the server had already emptied - a
  // factory cost of zero beside the day's takings, which reads as a shop that sells at cost.
  maySeeProductCost() {
    const user = this.currentUser || {};
    const role = String(user.role_name || '').trim().toLowerCase();
    if (role === 'administrator' || Number(user.role_id) === 1) return true;
    // Deliberately stricter than hasPerm(), and the other way round on purpose: no list, empty
    // or absent, is enough to draw a margin. The server has already stripped the fields in that
    // case, and a "Factory Cost" column over a row that holds none reads as a shop selling at
    // cost. The menu errs the other way, because an empty menu stops a shop working.
    const perms = user.permissions;
    if (!Array.isArray(perms)) return false;
    return perms.includes('manage_inventory') || perms.includes('manage_purchases');
  }

  // Whether this session holds one of the seven rights the Access Map edits
  // (api/config/db.php storeflowPermissionCatalogue). The tick list travels inside the session
  // the server hands back, so it is the same list that decides whether the API answers a
  // request - which is the whole point of asking the till the same question the shop asks.
  hasPerm(right) {
    const user = this.currentUser || {};
    // An absent list and an empty one are different facts. Absent means this copy was written
    // before the list travelled with the session - store-utils.js deliberately leaves it out
    // rather than defaulting it - and the answer is the role name, which is what decided access
    // before the ticks existed. Empty means somebody unticked every box.
    if (Array.isArray(user.permissions)) return user.permissions.includes(right);
    return this.legacyRoleRights().includes(right);
  }

  // A session holding no tick list is one stored on this machine before the list reached the
  // browser, or one made at the counter while the line was down. It gets the access its role
  // name used to buy it, and no more, so upgrading the till does not sign a working shop into an
  // empty shell. The list arrives with the next sign-in.
  legacyRoleRights() {
    const user = this.currentUser || {};
    const role = String(user.role_name || '').trim().toLowerCase();
    const id = Number(user.role_id || 0);
    if (id === 1 || role.includes('admin')) {
      return ['manage_inventory', 'manage_sales', 'manage_purchases', 'view_reports',
              'manage_users', 'manage_settings', 'manage_backups'];
    }
    if (id === 2 || role.includes('manager')) {
      return ['manage_inventory', 'manage_sales', 'manage_purchases', 'view_reports'];
    }
    if (id === 3 || role.includes('cashier')) return ['manage_sales'];
    return [];
  }

  // One table answers both questions the till used to answer separately, and badly: which
  // screens the menu shows, and which screens the router will open. Each entry names the door
  // the server itself puts on that screen's data, so a screen on the menu is a screen the API
  // will actually answer, and the right behind it is a tick the owner can see.
  //
  // A name the table does not hold is not offered to anybody. That is the safe direction to
  // fail in: a screen nobody can reach is noticed the same morning, a screen everybody can
  // reach is noticed by whoever reads the ledger they were not meant to.
  navRights() {
    return {
      // The counter. Ringing the sale, taking the return, logging what left the drawer, and
      // reading the takings back when the shift balances - all one right, manage_sales, which
      // is what rentals.php, returns.php and estimates.php already ask for.
      pos:          ['manage_sales'],
      sales:        ['manage_sales', 'view_reports'],
      returns:      ['manage_sales'],
      expenses:     ['manage_sales'],
      customers:    ['manage_sales'],
      estimates:    ['manage_sales'],
      rentals:      ['manage_sales'],
      hospitality:  ['manage_sales'],
      phone_scanner: ['manage_sales'],

      // The shelf. products.php hands its catalogue to anyone, so this door is the screen's
      // own purpose rather than a leak: editing what the shop stocks. Barcode Studio used to
      // sit outside every branch of the old code and was open to any signed-in till; it prints
      // shelf tags, so it follows the shelf now.
      products:        ['manage_inventory'],
      inventory:       ['manage_inventory'],
      batches:         ['manage_inventory'],
      barcode_studio:  ['manage_inventory'],

      // What the shop pays. purchases.php and vendors.php refuse these reads outright without
      // cost rights, so the menu asks the identical question instead of offering a screen
      // that only ever shows an error.
      purchases: ['manage_inventory', 'manage_purchases'],
      vendors:   ['manage_inventory', 'manage_purchases'],

      // The shop's figures, summed. This is the tick view_reports was sold on: the two screens
      // that are nothing but rollups.
      dashboard: ['view_reports'],
      analytics: ['view_reports'],

      // The back office. activity_logs.php and the write actions on profile.php, users.php and
      // backups.php already require these, per screen.
      profile:       ['manage_settings'],
      // The mobile quick-actions grid calls openModule('settings'), which asks for a view the
      // router has no case for. It gets the same door as the Store Profile screen it means, so
      // the owner is not refused a screen they own; the view itself still falls through to the
      // router's default, which is a separate thing to fix.
      settings:      ['manage_settings'],
      users:         ['manage_users'],
      backups:       ['manage_backups'],
      activity_logs: ['manage_settings'],
      ecommerce:     ['manage_settings'],
    };
  }

  // A nav item is keyed by the view it opens; the items that open a modal instead have no view
  // name, so their id carries the key.
  navKeyFor(el) {
    const view = el.getAttribute && el.getAttribute('data-view');
    if (view) return view;
    const id = String((el.id || '').replace(/^(nav|bnav)-/, ''));
    return id ? id.replace(/-/g, '_') : '';
  }

  canAccessView(viewName) {
    if (!this.currentUser) return false;
    const rights = this.navRights()[String(viewName || '')];
    if (!rights) return false;
    return rights.some(right => this.hasPerm(right));
  }

  // The menu is drawn from the table the router consults, so an item can no longer sit on the
  // menu while the router refuses to open it. The two disagreed by construction: three hard
  // branches matched the role's *name*, and a role whose name matched none of them fell through
  // to a branch that showed every item while canAccessView() bounced every click on it.
  applyRolePermissions() {
    const rights = this.navRights();
    const gate = (el) => {
      const key = this.navKeyFor(el);
      if (!rights[key]) return null;   // the till's own furniture: shift drawer, printer, sign out
      const allowed = this.canAccessView(key);
      el.classList.toggle('sf-role-locked', !allowed);
      return allowed;
    };

    const sidebar = document.querySelector('.sidebar-nav');
    if (sidebar) {
      // A heading follows its items. "Inventory & Stock" over an empty section is a divider
      // that tells the counter what they are not allowed to open.
      let heading = null;
      let headingHasGated = false;
      let headingAnyVisible = false;
      const flush = () => {
        if (heading && headingHasGated) heading.classList.toggle('sf-role-locked', !headingAnyVisible);
        heading = null;
        headingHasGated = false;
        headingAnyVisible = false;
      };
      Array.from(sidebar.children).forEach(el => {
        if (el.classList.contains('nav-section-title')) {
          flush();
          heading = el;
          return;
        }
        const verdict = gate(el);
        if (verdict === null) return;
        headingHasGated = true;
        if (verdict) headingAnyVisible = true;
      });
      flush();
    }

    // The phone's bottom bar is four of the same screens, so it answers to the same table.
    document.querySelectorAll('.mobile-bottom-nav [data-view]').forEach(el => {
      el.classList.toggle('sf-role-locked', !this.canAccessView(el.getAttribute('data-view')));
    });

    // A signed-in till has to land somewhere it is allowed to stand. The branches this
    // replaced chose 'pos' for a cashier and 'dashboard' for a manager out of the role's name;
    // this takes the first screen the table actually offers, which is the same answer for both
    // and no longer a "Access Restricted" toast for a third.
    if (this.currentView && !this.canAccessView(this.currentView)) {
      const landing = ['pos', 'dashboard', 'analytics', 'users'].find(v => this.canAccessView(v));
      if (landing) this.switchView(landing);
    }
  }

  async init() {
    this.bindNetworkEvents();
    this.bindNavigation();
    this.initSidebarState();
    this.bindBarcodeScanner();
    this.bindGlobalShortcuts();
    this.registerServiceWorker();
    this.initCrossTabSync();
    this.initIdleLockTracker();

    if (typeof this.updateMobileTableUI === 'function') {
      this.updateMobileTableUI();
    }
    window.addEventListener('resize', () => {
      if (window.innerWidth <= 768 && typeof this.applyMobileTableLabels === 'function') {
        this.applyMobileTableLabels();
      }
    });

    if (this.isOnline) {
      try {
        const res = await this.apiFetch('api/endpoints/users.php?action=current');
        const data = await res.json();
        // The service worker answers an outage with a 503 envelope, which resolves
        // normally here. Without this guard "nobody was reachable" fell into the
        // else branch below and cleared the local session, so a router blip signed
        // the till out and locked a shop owner out of their own offline data.
        if (data && data.offline === true) throw new Error('server unreachable');
        if (data.success && data.user) {
          this.currentUser = data.user;
          this.sessionManager.persistActiveUser(data.user, true);
        } else {
          // Explicit server response: session inactive or user deleted
          if (typeof this.stopWirelessScannerPolling === 'function') {
      this.stopWirelessScannerPolling();
    }
    if (typeof this.stopCrossDeviceDeltaSync === 'function') {
      this.stopCrossDeviceDeltaSync();
    }
    this.sessionManager.clearActiveUser();
          this.currentUser = null;
        }
      } catch (e) {
        // Network error / ngrok unreachable: preserve local user session
        const restoredUser = this.sessionManager.restoreActiveUser();
        this.currentUser = restoredUser || null;
      }
    } else {
      const restoredUser = this.sessionManager.restoreActiveUser();
      this.currentUser = restoredUser || null;
    }

    // A stand-off with the shop's book outlives a reload, or the owner only has to close the
    // app to be rid of the warning. Restored before the first load because that load can sync.
    if (typeof this.restoreBookHoldState === 'function') {
      await this.restoreBookHoldState();
    }

    if (typeof this.loadInitialData === 'function') {
      await this.loadInitialData();
    }

    // Always check license / session entitlement on load
    if (typeof this.syncHeartbeat === 'function') {
      await this.syncHeartbeat();
    }
    if (this._sessionScope === 'expired') {
      if (typeof this._showPaywall === 'function') this._showPaywall();
      return;
    }

    const urlParams = (typeof window !== 'undefined' && window.location && window.location.search) 
      ? new URLSearchParams(window.location.search) 
      : new URLSearchParams();
    if (urlParams.get('mode') === 'scanner' && typeof this.startCompanionScannerMode === 'function') {
      const targetTerm = this.normalizeTerminalId(urlParams.get('term'));
      this.startCompanionScannerMode(targetTerm);
      return;
    }

    if (this.currentUser) {
      if (this.isMultiBranch && this.currentUser.branch_code && this.currentUser.branch_code !== 'ALL') {
        this.branchCode = this.currentUser.branch_code;
        localStorage.setItem('storeflow_branch_code', this.currentUser.branch_code);
      }
      this.showApp();
      if (this.currentUser.must_change_password) {
        setTimeout(() => this.promptMandatoryPasswordChange(), 500);
      }
    } else {
      this.showLogin();
    }
  }

  registerServiceWorker() {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('./sw.js').then((reg) => {
        console.log('[PWA] Service Worker registered:', reg.scope);
      }).catch((err) => {
        console.warn('[PWA] Service Worker registration failed:', err);
      });
    }
  }

  bindNetworkEvents() {
    window.addEventListener('online', () => {
      if (this.isStandaloneOffline) {
        this.isOnline = false;
        return;
      }
      this.isOnline = true;
      this.updateNetworkStatusUI();
      this.updateLoginNetworkStatus();
      // Coming back up does not make a stale queue belong to the shop's current book. The
      // replay a connection normally starts has to wait for the owner's answer, or the
      // warning would be dismissed by the next cable being plugged in.
      if (this._bookHold) {
        this.renderBookMismatchBanner(this._bookHold);
        this.showToast('Back online. This till is still holding records from a book the shop no longer uses - nothing has been sent.', 'warning', 12000);
        return;
      }
      this.showToast('Internet connection restored. Synchronizing...', 'info');
      this.syncOutbox();
    });

    window.addEventListener('offline', () => {
      this.isOnline = false;
      this.updateNetworkStatusUI();
      this.updateLoginNetworkStatus();
      this.showToast('Offline mode active. All data saved locally to IndexedDB.', 'warning');
    });

    const syncBtn = document.getElementById('btn-manual-sync');
    if (syncBtn) {
      syncBtn.addEventListener('click', () => this.syncOutbox());
    }

    const topbarSyncBtn = document.getElementById('btn-topbar-sync');
    if (topbarSyncBtn) {
      topbarSyncBtn.addEventListener('click', () => this.syncOutbox());
    }

    // Auto-retry periodic sync when online every 45 seconds if pending changes exist
    if (!this._syncInterval) {
      this._syncInterval = setInterval(() => {
        // A held batch is not a retryable failure: the next beat would send the same records
        // to the same book that already refused them, forever.
        if (this.isOnline && this.currentUser && !this._isSyncing && !this._bookHold) {
          if (typeof localDB !== 'undefined' && localDB.sync_outbox) {
            localDB.sync_outbox.where('synced').equals(0).count().then(count => {
              if (count > 0) {
                this.syncOutbox();
              } else {
                this.updateNetworkStatusUI();
              }
            }).catch(() => {});
          }
        }
      }, 45000);
    }

    // 2-Hour Automated Native SQLite Backup to Public Documents on Android
    if (window.StoreFlowAndroid && typeof window.StoreFlowAndroid.backupDatabaseToDocuments === 'function') {
      const twoHoursMs = 2 * 60 * 60 * 1000;
      setInterval(() => {
        try {
          window.StoreFlowAndroid.backupDatabaseToDocuments();
        } catch (e) {
          console.warn('[StoreFlow SQLite] 2-Hour automated backup notice:', e);
        }
      }, twoHoursMs);
    }

    this.updateNetworkStatusUI();
    this.updateLoginNetworkStatus();
  }

  bindBarcodeScanner() {
    this.barcodeBuffer = '';
    this.lastBarcodeKeyTime = 0;

    window.addEventListener('keydown', (e) => {
      if (this.currentView !== 'pos') return;

      const activeEl = document.activeElement;
      const isInput = activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA' || activeEl.tagName === 'SELECT');
      if (isInput && activeEl.id !== 'pos-search') return;

      const now = Date.now();
      if (now - this.lastBarcodeKeyTime > 120) {
        this.barcodeBuffer = '';
      }
      this.lastBarcodeKeyTime = now;

      if (e.key === 'Enter') {
        const code = (this.barcodeBuffer || '').trim();
        if (code.length >= 2) {
          e.preventDefault();
          this.handleBarcodeScan(code);
          this.barcodeBuffer = '';
          if (activeEl && activeEl.id === 'pos-search') {
            activeEl.value = '';
            this.posSearchTerm = '';
            this.renderCurrentView();
          }
        }
        return;
      }

      if (e.key.length === 1) {
        this.barcodeBuffer += e.key;
      }
    });
  }

  /**
   * Universal Modal Dismissal Helper:
   * Gracefully closes the active modal (or passed modal) via its native close/cancel handler.
   */
  closeTopmostModal(targetModal = null) {
    let modal = targetModal;
    if (!modal) {
      const activeModals = Array.from(document.querySelectorAll('.modal-overlay.active'));
      if (!activeModals.length) return false;
      modal = activeModals[activeModals.length - 1];
    }
    if (!modal) return false;

    // 1. If camera scanner modal, gracefully stop video/torch streams first
    if (modal.id === 'camera-scanner-modal') {
      this.closeCameraScanner();
      return true;
    }

    // 2. Click native close or cancel button inside the modal if present
    const closeBtn = modal.querySelector('.btn-close-modal') ||
      modal.querySelector('.modal-footer button.btn-outline') ||
      modal.querySelector('.modal-footer button.btn-secondary') ||
      modal.querySelector('button[data-dismiss="modal"]');
    if (closeBtn && typeof closeBtn.click === 'function') {
      closeBtn.click();
      return true;
    }

    // 3. Fallback to mapped controller close methods
    const modalId = modal.id;
    const modalMap = {
      'product-modal': () => this.closeProductModal(),
      'purchase-modal': () => this.closePurchaseModal(),
      'customer-modal': () => this.closeCustomerModal(),
      'stock-adj-modal': () => this.closeStockAdjustmentModal(),
      'user-modal': () => this.closeUserModal(),
      'checkout-modal': () => this.closeCheckoutModal(),
      'outofstock-modal': () => this.closeOutOfStockModal(),
      'debt-payment-modal': () => this.closeDebtPaymentModal(),
      'receipt-modal': () => this.closeReceiptModal(),
      'logout-modal': () => this.closeLogoutModal(),
      'confirm-delete-modal': () => this.closeDeleteModal(),
      'customer-statement-modal': () => this.closeCustomerStatementModal(),
      'vendor-modal': () => this.closeVendorModal(),
      'vendor-payment-modal': () => this.closeVendorPaymentModal(),
      'vendor-statement-modal': () => this.closeVendorStatementModal(),
      'shift-report-modal': () => this.closeShiftReportModal(),
      'shift-history-modal': () => this.closeShiftHistoryModal(),
      'analytics-report-modal': () => this.closeAnalyticsReportModal(),
      'branch-management-modal': () => this.closeBranchModal(),
      'branch-form-modal': () => this.closeBranchFormModal(),
      'stock-transfer-modal': () => this.closeTransferModal(),
      'transfer-waybill-modal': () => this.closeTransferWaybillModal(),
      'branch-stock-modal': () => this.closeBranchStockModal(),
      'product-detail-modal': () => this.closeProductDetailModal(),
      'barcode-label-modal': () => this.closeBarcodeLabelModal(),
      'stock-audit-modal': () => this.closeStockAuditModal(),
      'sales-return-modal': () => this.closeSalesReturnModal(),
      'expense-modal': () => this.closeExpenseModal(),
      'wireless-scanner-modal': () => this.closeWirelessScannerModal(),
      'pos-cart-modal-overlay': () => this.closeMobileCartModal(),
      'license-modal': () => this.closeLicenseModal()
    };

    if (modalId && modalMap[modalId]) {
      try { modalMap[modalId](); return true; } catch (e) { }
    }

    // 4. Default fallback: remove active class
    modal.classList.remove('active');
    if (this._pendingViewRefresh) {
      const pending = this._pendingViewRefresh;
      this._pendingViewRefresh = null;
      if (this.currentView === pending && typeof this.renderCurrentView === 'function') {
        this.renderCurrentView();
      }
    }
    return true;
  }

  /**
   * Global Keyboard & UX Shortcuts:
   * - Esc: Close active modal / cancel form / dismiss camera / blur inputs
   * - Backdrop click: Click outside modal dialog to dismiss
   * - F2 or Ctrl+K or /: Quick focus search bar
   * - F4 or Ctrl+Enter: Quick Checkout when in POS
   * - Alt+N: Quick "Add New" for active module
   */
  bindGlobalShortcuts() {
    this.focusedProductIndex = -1;
    window.addEventListener('keydown', (e) => {
      // 0. POS UI Integrity: Intercept DevTools shortcuts on cashier terminal unless dev mode is active
      if (
        e.key === 'F12' ||
        ((e.ctrlKey || e.metaKey) && e.shiftKey && ['I', 'i', 'J', 'j', 'C', 'c'].includes(e.key)) ||
        ((e.ctrlKey || e.metaKey) && (e.key === 'u' || e.key === 'U'))
      ) {
        if (typeof localStorage !== 'undefined' && localStorage.getItem('storeflow_dev_mode') !== '1') {
          e.preventDefault();
          e.stopPropagation();
          return false;
        }
      }

      // 0b. Screen Lock Guard: If terminal is locked, only allow Enter to unlock
      if (this.isScreenLocked) {
        if (e.key === 'Enter') {
          e.preventDefault();
          this.unlockScreen();
        }
        return;
      }

      // 0c. Manual Lock Shortcut: Alt+L or Ctrl+Shift+L
      if ((e.altKey && (e.key === 'l' || e.key === 'L')) || ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'l' || e.key === 'L'))) {
        e.preventDefault();
        this.lockScreen('manual');
        return;
      }

      // 1. ESCAPE: Close active modals / forms / camera viewfinder
      if (e.key === 'Escape' || e.key === 'Esc') {
        const activeModals = Array.from(document.querySelectorAll('.modal-overlay.active'));
        if (activeModals.length > 0) {
          e.preventDefault();
          this.closeTopmostModal(activeModals[activeModals.length - 1]);
          return;
        }

        // Clear card keyboard highlight in POS
        if (this.currentView === 'pos' && this.focusedProductIndex >= 0) {
          this.focusedProductIndex = -1;
          document.querySelectorAll('.pos-product-card.keyboard-highlighted').forEach(c => c.classList.remove('keyboard-highlighted'));
          const searchInput = document.getElementById('pos-search');
          if (searchInput) searchInput.focus();
          return;
        }

        // Close mobile sidebar if open
        const container = document.getElementById('app-container');
        if (container && container.classList.contains('sidebar-mobile-open')) {
          e.preventDefault();
          this.closeSidebarMobile();
          return;
        }

        // If an input is focused, Esc blurs it
        const activeEl = document.activeElement;
        if (activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA' || activeEl.tagName === 'SELECT')) {
          activeEl.blur();
        }
        return;
      }

      // Check if user is actively typing in an input
      const activeEl = document.activeElement;
      const isInput = activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA' || activeEl.tagName === 'SELECT');

      // 2. SHORTCUTS HELP MODAL: F1 or '?' (when not typing in an input)
      if (e.key === 'F1' || (e.key === '?' && !isInput)) {
        e.preventDefault();
        this.openShortcutsModal();
        return;
      }

      // 3. CHECKOUT MODAL KEYBOARD NAVIGATION (when checkout modal is active)
      const checkoutModal = document.getElementById('checkout-modal');
      if (checkoutModal && checkoutModal.classList.contains('active')) {
        if (!isInput || activeEl.id === 'checkout-amount-paid') {
          const keyLower = (e.key || '').toLowerCase();
          if (e.key === '1' || (keyLower === 'c' && activeEl.id !== 'checkout-card-ref')) {
            if (!isInput) { e.preventDefault(); this.setPaymentMethod('CASH'); return; }
          } else if (e.key === '2' || (keyLower === 'k' && activeEl.id !== 'checkout-card-ref')) {
            if (!isInput) { e.preventDefault(); this.setPaymentMethod('CARD'); return; }
          } else if (e.key === '3' || ((keyLower === 'm' || keyLower === 't') && activeEl.id !== 'checkout-card-ref')) {
            if (!isInput) { e.preventDefault(); this.setPaymentMethod('TRANSFER'); return; }
          } else if (e.key === '4' || (keyLower === 'd' && activeEl.id !== 'checkout-card-ref')) {
            if (!isInput) { e.preventDefault(); this.setPaymentMethod('CREDIT'); return; }
          } else if (e.key === '5' || (keyLower === 's' && activeEl.id !== 'checkout-card-ref')) {
            if (!isInput) { e.preventDefault(); this.setPaymentMethod('SPLIT'); return; }
          }
        }

        if (e.key === 'Enter') {
          e.preventDefault();
          this.confirmFinalCheckout();
          return;
        }
      }

      // 4. ALT + [1-9, 0]: Instant Module Navigation
      if (e.altKey && !e.ctrlKey && !e.metaKey && !e.shiftKey) {
        const keyMap = {
          '1': 'dashboard',
          '2': 'pos',
          '3': 'products',
          '4': 'inventory',
          '5': 'batches',
          '6': 'sales',
          '7': 'returns',
          '8': 'purchases',
          '9': 'customers',
          '0': 'profile'
        };
        if (keyMap[e.key]) {
          e.preventDefault();
          this.switchView(keyMap[e.key]);
          return;
        }

        // Alt + N: Quick New Item / Action
        if (e.key.toLowerCase() === 'n') {
          e.preventDefault();
          if (this.currentView === 'products' && typeof this.openNewProductModal === 'function') {
            this.openNewProductModal();
          } else if (this.currentView === 'purchases' && typeof this.openNewPurchaseModal === 'function') {
            this.openNewPurchaseModal();
          } else if (this.currentView === 'customers' && typeof this.openNewCustomerModal === 'function') {
            this.openNewCustomerModal();
          } else if (this.currentView === 'vendors' && typeof this.openNewVendorModal === 'function') {
            this.openNewVendorModal();
          } else if (this.currentView === 'batches' && typeof this.openNewBatchModal === 'function') {
            this.openNewBatchModal();
          } else if (this.currentView === 'pos' && typeof this.openNewProductModal === 'function') {
            this.openNewProductModal();
          }
          return;
        }
      }

      // 5. F2 or Ctrl+K: Quick Focus Search
      if (e.key === 'F2' || ((e.ctrlKey || e.metaKey) && (e.key.toLowerCase() === 'k' || e.key === '/'))) {
        e.preventDefault();
        const searchInput = (this.currentView === 'pos' ? document.getElementById('pos-search') : null) ||
          document.getElementById('products-search-input') ||
          document.getElementById('returns-search') ||
          document.getElementById('sales-filter-search') ||
          document.getElementById('pos-search');
        if (searchInput) {
          searchInput.focus();
          if (searchInput.select) searchInput.select();
        }
        return;
      }

      // 6. F3: Add New Product / Item
      if (e.key === 'F3') {
        e.preventDefault();
        if (typeof this.openNewProductModal === 'function') this.openNewProductModal();
        return;
      }

      // 7. F4 or Ctrl+Enter: Quick Checkout in POS
      if (e.key === 'F4' || ((e.ctrlKey || e.metaKey) && e.key === 'Enter')) {
        if (this.currentView === 'pos' && this.cart && this.cart.length > 0) {
          if (!checkoutModal || !checkoutModal.classList.contains('active')) {
            e.preventDefault();
            this.openCheckoutModal();
            return;
          }
        }
      }

      // 8. F6: Select Customer in POS
      if (e.key === 'F6') {
        if (this.currentView === 'pos') {
          e.preventDefault();
          const custSelect = document.getElementById('pos-customer-select');
          if (custSelect) custSelect.focus();
          return;
        }
      }

      // 9. F7: Clear Current POS Cart
      if (e.key === 'F7') {
        if (this.currentView === 'pos' && this.cart && this.cart.length > 0) {
          e.preventDefault();
          this.clearCart();
          return;
        }
      }

      // 10. F8: Open Cashier Shift / Daily Balancing
      if (e.key === 'F8') {
        e.preventDefault();
        this.openShiftReportModal();
        return;
      }

      // 11. F9: Fast Exact Cash Checkout
      if (e.key === 'F9') {
        if (this.currentView === 'pos') {
          e.preventDefault();
          this.fastCashCheckout();
          return;
        }
      }

      // 12. POS GRID ARROW KEY NAVIGATION & CART QUANTITY ADJUSTMENTS
      if (this.currentView === 'pos' && !isInput) {
        // Arrow Keys for Product Grid
        if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
          e.preventDefault();
          const dir = e.key.replace('Arrow', '').toLowerCase();
          this.navigatePosGrid(dir);
          return;
        }

        // Enter or Space: Add highlighted product to cart
        if ((e.key === 'Enter' || e.key === ' ') && this.focusedProductIndex >= 0) {
          e.preventDefault();
          const cards = Array.from(document.querySelectorAll('#pos-product-grid .pos-product-card:not([style*="display: none"])'));
          if (cards[this.focusedProductIndex]) {
            cards[this.focusedProductIndex].click();
          }
          return;
        }

        // '+' or '=': Increment last cart item
        if (e.key === '+' || e.key === '=') {
          if (this.cart && this.cart.length > 0) {
            e.preventDefault();
            this.updateCartQty(this.cart.length - 1, 1);
            return;
          }
        }

        // '-': Decrement last cart item
        if (e.key === '-') {
          if (this.cart && this.cart.length > 0) {
            e.preventDefault();
            this.updateCartQty(this.cart.length - 1, -1);
            return;
          }
        }
      }
    });

    // 5. Backdrop click: Clicking outside modal-content closes active modal
    document.addEventListener('click', (e) => {
      if (e.target && e.target.classList && e.target.classList.contains('modal-overlay') && e.target.classList.contains('active')) {
        this.closeTopmostModal(e.target);
      }
    });

    // 6. POS UI Integrity: Prevent right-click context menu ("Inspect Element") unless dev mode is active
    document.addEventListener('contextmenu', (e) => {
      if (typeof localStorage !== 'undefined' && localStorage.getItem('storeflow_dev_mode') !== '1') {
        if (!['INPUT', 'TEXTAREA'].includes(e.target?.tagName)) {
          e.preventDefault();
        }
      }
    });
  }

  openShortcutsModal(tab = 'shortcuts') {
    const modal = document.getElementById('shortcuts-modal');
    if (modal) {
      modal.classList.add('active');
      this.switchHelpTab(tab);
    }
  }

  closeShortcutsModal() {
    document.getElementById('shortcuts-modal')?.classList.remove('active');
  }

  switchHelpTab(tabName, btnEl = null) {
    const modal = document.getElementById('shortcuts-modal');
    if (!modal) return;

    modal.querySelectorAll('.help-tab-btn').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-tab') === tabName);
    });

    modal.querySelectorAll('.help-tab-pane').forEach(pane => {
      pane.style.display = (pane.id === `help-pane-${tabName}`) ? 'block' : 'none';
    });

    if (tabName === 'about') {
      this.populateAboutDiagnostics();
    }
  }

  populateAboutDiagnostics() {
    const midEl = document.getElementById('about-machine-id');
    const statusEl = document.getElementById('about-license-status');
    const branchEl = document.getElementById('about-branch-code');
    const storageEl = document.getElementById('about-storage-usage');
    const versionEl = document.getElementById('about-release-version');

    if (branchEl) {
      branchEl.textContent = this.currentUser?.branch_code || 'MAIN-01';
    }

    if (storageEl && navigator.storage && navigator.storage.estimate) {
      navigator.storage.estimate().then(estimate => {
        const usedMb = ((estimate.usage || 0) / (1024 * 1024)).toFixed(2);
        storageEl.textContent = `${usedMb} MB used (Local Client Cache)`;
      }).catch(() => {
        if (storageEl) storageEl.textContent = 'Local IndexedDB Active';
      });
    }

    const cacheEl = document.getElementById('about-cache-version');
    if (cacheEl) {
      // Read the stamp this page actually loaded instead of naming one. The release
      // builder refuses a build whose service worker cache is older than the newest
      // asset stamp, so this is the same number the customer's browser really holds.
      const appTag = document.querySelector('script[src*="app.js"]');
      const stamp = appTag ? /[?&]v=(\d+)/.exec(appTag.getAttribute('src') || '') : null;
      cacheEl.textContent = stamp ? 'storeflow-cache-v' + stamp[1] : 'not cached';
    }

    fetch('api/endpoints/system.php?action=heartbeat')
      .then(r => r.json())
      .then(d => {
        if (versionEl && d && d.version) {
          versionEl.textContent = 'Release v' + d.version;
        }
        if (midEl && d && d.ref) {
          midEl.textContent = d.ref;
        }
        if (statusEl && d) {
          if (d.status === 'active') {
            statusEl.className = 'badge badge-success';
            statusEl.innerHTML = '<i class="fa-solid fa-circle-check"></i> Enterprise Commercial License';
          } else if (d.status === 'trial') {
            statusEl.className = 'badge badge-warning';
            statusEl.innerHTML = `<i class="fa-solid fa-clock"></i> Free Evaluation (${Number(d.quota) || 0} days remaining)`;
          } else {
            statusEl.className = 'badge badge-danger';
            statusEl.innerHTML = '<i class="fa-solid fa-lock"></i> Unlicensed / Expired';
          }
        }
      })
      .catch(() => {
        if (midEl && (!midEl.textContent || midEl.textContent === 'Fetching...')) {
          midEl.textContent = 'SF-STANDALONE-OFFLINE';
        }
      });
  }

  setManualCategory(category, pillEl) {
    this.activeManualCategory = category;
    document.querySelectorAll('.manual-cat-pill').forEach(p => p.classList.remove('active'));
    if (pillEl) pillEl.classList.add('active');
    const query = document.getElementById('manual-search-input')?.value || '';
    this.filterHelpManual(query, category);
  }

  filterHelpManual(query = '', category = null) {
    const q = (query || '').toLowerCase().trim();
    const cat = category !== null ? category : (this.activeManualCategory || 'all');
    
    const cards = document.querySelectorAll('.manual-topic-card');
    let visibleCount = 0;

    cards.forEach(card => {
      const cardCat = card.getAttribute('data-category') || '';
      const text = (card.innerText || '').toLowerCase();
      const matchesCat = (cat === 'all' || cardCat === cat);
      const matchesQuery = !q || text.includes(q);

      if (matchesCat && matchesQuery) {
        card.style.display = 'block';
        visibleCount++;
      } else {
        card.style.display = 'none';
      }
    });

    const emptyMsg = document.getElementById('manual-no-results');
    if (emptyMsg) {
      emptyMsg.style.display = visibleCount === 0 ? 'block' : 'none';
    }
  }

  toggleFaqAccordion(headerEl) {
    if (!headerEl) return;
    const item = headerEl.closest('.faq-accordion-item');
    if (!item) return;
    item.classList.toggle('active');
  }

  jumpToModuleFromHelp(moduleName) {
    this.closeShortcutsModal();
    if (moduleName === 'pos') {
      this.switchView('pos');
    } else if (moduleName === 'barcode-studio') {
      if (typeof this.openBarcodeLabelStudio === 'function') {
        this.openBarcodeLabelStudio();
      } else {
        this.switchView('products');
      }
    } else if (moduleName === 'stock-audit') {
      if (typeof this.openStockAuditModal === 'function') {
        this.openStockAuditModal();
      } else {
        this.switchView('inventory');
      }
    } else if (moduleName === 'batches') {
      this.switchView('batches');
    } else if (moduleName === 'purchases') {
      this.switchView('purchases');
    } else if (moduleName === 'returns') {
      this.switchView('returns');
    } else if (moduleName === 'rentals') {
      this.switchView('rentals');
    } else if (moduleName === 'estimates') {
      this.switchView('estimates');
    } else if (moduleName === 'phone-gun') {
      if (typeof this.openScannerPairingModal === 'function') {
        this.openScannerPairingModal();
      }
    } else if (moduleName === 'hospitality') {
      this.switchView('hospitality');
    } else if (moduleName === 'profile') {
      this.switchView('profile');
    } else if (moduleName === 'customers') {
      this.switchView('customers');
    } else if (moduleName === 'vendors') {
      this.switchView('vendors');
    } else if (moduleName === 'transfers') {
      if (typeof this.openTransferModal === 'function') {
        this.openTransferModal();
      } else {
        this.switchView('inventory');
      }
    } else if (moduleName === 'shifts') {
      if (typeof this.openShiftReportModal === 'function') {
        this.openShiftReportModal();
      }
    } else if (moduleName === 'settings') {
      this.switchView('profile');
    } else if (moduleName === 'analytics') {
      this.switchView('analytics');
    } else if (moduleName === 'backups') {
      this.switchView('backups');
    } else if (moduleName === 'ecommerce') {
      this.switchView('ecommerce');
    } else if (moduleName === 'sync') {
      if (typeof this.syncOutbox === 'function') {
        this.syncOutbox();
      }
    } else {
      this.switchView(moduleName);
    }
  }

  handleBarcodeScan(code) {
    if (!code) return;
    const rawClean = code.trim().toLowerCase();
    const compactCode = rawClean.replace(/[\s\-_]/g, '');

    // A pack's own code is looked up before the product's, and it decides the size as
    // well as the product. Left to the chain below, a crate EAN that a shop printed and
    // stuck on the crate would match nothing, and the same number written as the
    // product's barcode would ring up one egg at the egg price.
    let scannedSized = null;
    for (const p of this.products) {
      const sized = this.productUnitOfBarcode(p, rawClean);
      if (sized) {
        scannedSized = { product: p, unit: sized };
        break;
      }
    }

    // Find match: barcode -> sku -> id -> name (resilient to whitespace, hyphens, and digit-grouping)
    const product = scannedSized ? scannedSized.product : this.products.find(p => {
      const pBarcode = (p.barcode || '').trim().toLowerCase();
      const pBarcodeCompact = pBarcode.replace(/[\s\-_]/g, '');
      const pSku = (p.sku || '').trim().toLowerCase();
      const pSkuCompact = pSku.replace(/[\s\-_]/g, '');
      const pId = (p.id || '').trim().toLowerCase();
      const pName = (p.name || '').trim().toLowerCase();

      return (
        pBarcode === rawClean ||
        (compactCode && pBarcodeCompact === compactCode) ||
        pSku === rawClean ||
        (compactCode && pSkuCompact === compactCode) ||
        pId === rawClean ||
        pName === rawClean
      );
    });

    if (product) {
      this.handleProductCardClick(product.id, scannedSized ? scannedSized.unit.unit_name : null);
      this.showToast(`Scanned & Added: ${product.name}${scannedSized ? ` (${scannedSized.unit.unit_name})` : ''}`, 'success');

      // Subtle cashier confirmation audio feedback
      try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.frequency.value = 1400;
        gain.gain.value = 0.1;
        osc.start();
        setTimeout(() => { osc.stop(); ctx.close(); }, 80);
      } catch (e) { }
    } else {
      this.showToast(`Barcode / SKU not found: "${code}"`, 'warning');
    }
  }

  // --- Camera Barcode Scanner (Mobile PWA & Desktop WebCam) ---

  // The owner-facing half of a refused batch. A toast would be gone in six seconds with the
  // records still sitting underneath it, so this stays on screen until somebody says where
  // they should go.
  renderBookMismatchBanner(held) {
    const banner = document.getElementById('book-mismatch-banner');
    if (!banner) return;
    if (!held) {
      banner.style.display = 'none';
      this._bookMismatchDismissed = false;
      return;
    }
    const count = document.getElementById('book-mismatch-count');
    if (count) count.innerText = Number(held.records) > 0 ? String(Number(held.records)) : 'some';
    if (!this._bookMismatchDismissed) banner.style.display = 'block';
  }

  // Hiding the bar is not the same as answering the question: the hold stays, the records
  // stay on the device, and the retry stays stopped.
  dismissBookMismatchBanner() {
    this._bookMismatchDismissed = true;
    const banner = document.getElementById('book-mismatch-banner');
    if (banner) banner.style.display = 'none';
    this.showToast('Kept on this till. Nothing has been sent to the shop\'s book.', 'info', 9000);
  }

  async updateNetworkStatusUI() {
    const pill = document.getElementById('network-status-pill');
    const topbarSyncBtn = document.getElementById('btn-topbar-sync');
    const topbarIcon = document.getElementById('topbar-sync-icon');
    const topbarLabel = document.getElementById('topbar-sync-label');
    const topbarCount = document.getElementById('topbar-sync-count');

    let pendingCount = 0;
    try {
      if (typeof localDB !== 'undefined' && localDB.sync_outbox) {
        pendingCount = await localDB.sync_outbox.where('synced').equals(0).count();
      }
    } catch (e) {}

    if (pill) {
      if (this._bookHold) {
        // The records are waiting on the device and nothing will take them, so "Online (7)"
        // would describe the opposite of what is happening on this till.
        pill.className = 'status-pill status-offline';
        pill.innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i> <span>Held: ${pendingCount} not in this book</span>`;
        pill.title = 'Taken against a book the shop no longer uses. Choose what to do with them on the warning above.';
      } else if (this.isOnline) {
        pill.className = 'status-pill status-online';
        pill.innerHTML = `<i class="fa-solid fa-wifi"></i> <span>Online Mode${pendingCount > 0 ? ` (${pendingCount})` : ''}</span>`;
      } else {
        pill.className = 'status-pill status-offline';
        pill.innerHTML = `<i class="fa-solid fa-plane-slash"></i> <span>Offline (Local)${pendingCount > 0 ? ` (${pendingCount})` : ''}</span>`;
      }
    }

    if (topbarSyncBtn) {
      if (this._isSyncing) {
        topbarSyncBtn.style.display = 'inline-flex';
        topbarSyncBtn.disabled = true;
        if (topbarIcon) topbarIcon.className = 'fa-solid fa-arrows-rotate fa-spin';
        if (topbarLabel) topbarLabel.innerText = 'Syncing...';
        if (topbarCount) topbarCount.style.display = 'none';
      } else if (pendingCount > 0) {
        topbarSyncBtn.style.display = 'inline-flex';
        topbarSyncBtn.disabled = false;
        if (this._syncFailed) {
          topbarSyncBtn.className = 'btn btn-sm btn-danger';
          if (topbarIcon) topbarIcon.className = 'fa-solid fa-triangle-exclamation';
          if (topbarLabel) topbarLabel.innerText = 'Retry Sync';
        } else {
          topbarSyncBtn.className = 'btn btn-sm btn-warning';
          if (topbarIcon) topbarIcon.className = 'fa-solid fa-arrows-rotate';
          if (topbarLabel) topbarLabel.innerText = 'Sync Now';
        }
        if (topbarCount) {
          topbarCount.style.display = 'inline-block';
          topbarCount.innerText = pendingCount;
        }
      } else {
        topbarSyncBtn.disabled = false;
        if (!this.isOnline) {
          topbarSyncBtn.style.display = 'inline-flex';
          topbarSyncBtn.className = 'btn btn-sm btn-outline';
          if (topbarIcon) topbarIcon.className = 'fa-solid fa-plane-slash';
          if (topbarLabel) topbarLabel.innerText = 'Offline';
          if (topbarCount) topbarCount.style.display = 'none';
        } else {
          topbarSyncBtn.style.display = 'inline-flex';
          topbarSyncBtn.className = 'btn btn-sm btn-outline';
          if (topbarIcon) topbarIcon.className = 'fa-solid fa-arrows-rotate';
          if (topbarLabel) topbarLabel.innerText = 'Sync';
          if (topbarCount) topbarCount.style.display = 'none';
        }
      }
    }
  }

  bindNavigation() {
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        const targetView = item.getAttribute('data-view');
        if (targetView) {
          navItems.forEach(n => n.classList.remove('active'));
          item.classList.add('active');
          this.switchView(targetView);
          this.closeSidebarMobile();
        }
      });
    });
  }

  toggleSidebar() {
    const isMobile = window.innerWidth <= 992;
    const container = document.getElementById('app-container');
    if (!container) return;

    if (isMobile) {
      container.classList.toggle('sidebar-mobile-open');
    } else {
      const isCollapsed = container.classList.toggle('sidebar-collapsed');
      localStorage.setItem('storeflow_sidebar_collapsed', isCollapsed ? '1' : '0');
    }
  }

  closeSidebarMobile() {
    const container = document.getElementById('app-container');
    if (container) {
      container.classList.remove('sidebar-mobile-open');
    }
  }

  initSidebarState() {
    if (window.innerWidth > 992) {
      const saved = localStorage.getItem('storeflow_sidebar_collapsed');
      if (saved === '1') {
        const container = document.getElementById('app-container');
        if (container) container.classList.add('sidebar-collapsed');
      }
    }
  }

  getStoreLogo() {
    if (this.storeProfile && this.storeProfile.logo_url && this.storeProfile.logo_url.trim()) {
      return this.storeProfile.logo_url;
    }
    return 'assets/icons/icon-192.png';
  }

  shouldPrintReceiptLogo() {
    if (!this.storeProfile) return true;
    return this.storeProfile.print_logo_on_receipts !== 0 && this.storeProfile.print_logo_on_receipts !== '0';
  }

  updateStoreBrandUI() {
    const logo = this.getStoreLogo();
    const storeName = (this.storeProfile && this.storeProfile.store_name) ? this.storeProfile.store_name : 'Apex Wholesale & Retail Mart';
    const tagline = (this.storeProfile && this.storeProfile.tagline) ? this.storeProfile.tagline : 'Store Management';

    // 1. Sidebar Brand
    const brandName = document.getElementById('sidebar-store-name');
    if (brandName) brandName.innerText = storeName;
    const brandTagline = document.getElementById('sidebar-store-tagline');
    if (brandTagline) brandTagline.innerText = tagline;
    const sidebarLogoImg = document.querySelector('.sidebar-logo-img');
    if (sidebarLogoImg) sidebarLogoImg.src = logo;

    // 2. Login Screen Brand
    const loginName = document.getElementById('login-store-name');
    if (loginName) loginName.innerText = storeName;
    const loginTagline = document.getElementById('login-store-tagline');
    if (loginTagline) loginTagline.innerText = tagline;
    const loginLogoImg = document.querySelector('.login-brand-img');
    if (loginLogoImg) loginLogoImg.src = logo;

    // 3. Document Window Title
    document.title = `${storeName} - POS & Inventory Management`;

    // 4. Update receipts & profile live preview logos
    const receiptLogos = document.querySelectorAll('.receipt-logo');
    receiptLogos.forEach(img => {
      img.src = logo;
      img.style.display = this.shouldPrintReceiptLogo() ? 'block' : 'none';
    });
  }


  showLogin() {
    if (this._sessionScope === 'expired') {
      if (typeof this._showPaywall === 'function') this._showPaywall();
      return;
    }
    const loginScreen = document.getElementById('login-screen');
    const appContainer = document.getElementById('app-container');
    if (loginScreen) loginScreen.style.display = 'flex';
    if (appContainer) appContainer.style.display = 'none';

    const nameEl = document.getElementById('login-store-name');
    const tagEl = document.getElementById('login-store-tagline');
    if (nameEl) nameEl.innerText = this.storeProfile.store_name;
    if (tagEl) tagEl.innerText = this.storeProfile.tagline || 'Store Management';

    this.updateLoginNetworkStatus();

    const pwInput = document.getElementById('login-password');
    const uInput = document.getElementById('login-username');
    const activeEl = document.activeElement;

    // Never erase credentials or hijack focus if the operator is already interacting with the login inputs
    const isInteractingWithLogin = activeEl && (activeEl === pwInput || activeEl === uInput);

    if (pwInput && !isInteractingWithLogin) {
      pwInput.value = '';
    }

    const alertBanner = document.getElementById('login-alert-banner');
    if (alertBanner && !isInteractingWithLogin) {
      alertBanner.style.display = 'none';
    }

    if (!isInteractingWithLogin) {
      setTimeout(() => {
        const currentActive = document.activeElement;
        // If operator has clicked or focused into password or username during timeout, leave them alone
        if (currentActive === pwInput || currentActive === uInput) return;
        if (uInput && !uInput.value.trim()) {
          uInput.focus();
        } else if (pwInput && (!currentActive || currentActive === document.body)) {
          pwInput.focus();
        }
      }, 150);
    }
  }

  showApp() {
    if (this._sessionScope === 'expired') {
      if (typeof this._showPaywall === 'function') this._showPaywall();
      return;
    }
    const loginScreen = document.getElementById('login-screen');
    const appContainer = document.getElementById('app-container');
    if (loginScreen) loginScreen.style.display = 'none';
    if (appContainer) appContainer.style.display = 'flex';

    if (this._sessionScope === 'trial' && typeof this._showTrialBanner === 'function') {
      this._showTrialBanner(this._quotaDays, this._quotaTotal);
    } else if (this._sessionScope === 'active' && typeof this.updateLicenseBadge === 'function') {
      this.updateLicenseBadge('active');
    }

    this.updateUserUI();
    this.applyRolePermissions();
    const savedView = localStorage.getItem('storeflow_active_view');
    if (savedView && this.canAccessView(savedView)) {
      this.switchView(savedView);
    } else {
      this.switchView(this.currentView || 'dashboard');
    }
    if (typeof this.startWirelessScannerPolling === 'function') {
      this.startWirelessScannerPolling();
    }
  }

  updateUserUI() {
    const nameEl = document.getElementById('topbar-user-name');
    const roleEl = document.getElementById('topbar-user-role');
    const logoutNameEl = document.getElementById('logout-user-name');
    const termBadge = document.getElementById('topbar-terminal-badge');
    const drawerNameEl = document.getElementById('drawer-user-name');
    const drawerRoleEl = document.getElementById('drawer-user-role');
    const drawerTermBadge = document.getElementById('drawer-terminal-badge');
    const branchBadge = document.getElementById('topbar-branch-badge');
    const drawerBranchBadge = document.getElementById('drawer-branch-badge');
    const branchBtn = document.getElementById('btn-topbar-branches');

    if (this.currentUser) {
      const name = this.currentUser.full_name || this.currentUser.username || 'Staff User';
      const role = this.currentUser.role_name || 'Administrator';
      if (nameEl) nameEl.innerText = name;
      if (roleEl) roleEl.innerText = role;
      if (logoutNameEl) logoutNameEl.innerText = `${name} (${role})`;
      if (drawerNameEl) drawerNameEl.innerText = name;
      if (drawerRoleEl) drawerRoleEl.innerText = role;
    }

    if (termBadge) {
      termBadge.innerHTML = `<i class="fa-solid fa-desktop"></i> ${this.escapeHtml(this.terminalId || 'REG-01')}`;
    }
    if (drawerTermBadge) {
      drawerTermBadge.innerHTML = `<i class="fa-solid fa-desktop"></i> ${this.escapeHtml(this.terminalId || 'REG-01')}`;
    }

    if (branchBadge) {
      branchBadge.style.display = this.isMultiBranch ? 'inline-flex' : 'none';
      branchBadge.innerHTML = `<i class="fa-solid fa-store"></i> ${this.escapeHtml(this.branchCode || 'MAIN-01')}`;
    }
    if (drawerBranchBadge) {
      drawerBranchBadge.style.display = this.isMultiBranch ? 'inline-flex' : 'none';
      drawerBranchBadge.innerHTML = `<i class="fa-solid fa-store"></i> ${this.escapeHtml(this.branchCode || 'MAIN-01')}`;
    }
    if (branchBtn) {
      branchBtn.style.display = (this.isMultiBranch && this.isAdmin()) ? 'inline-flex' : 'none';
    }

    this.updatePrinterUI();
  }

  updateLoginNetworkStatus() {
    const pill = document.getElementById('login-offline-pill');
    if (!pill) return;
    if (this.isOnline) {
      pill.className = 'badge badge-success';
      pill.innerHTML = '<i class="fa-solid fa-wifi"></i> Online';
    } else {
      pill.className = 'badge badge-warning';
      pill.innerHTML = '<i class="fa-solid fa-plane-slash"></i> Offline (Local Mode)';
    }
  }

  async handleLogin() {
    const usernameInput = document.getElementById('login-username');
    const passwordInput = document.getElementById('login-password');
    const rememberMe = document.getElementById('login-remember-me')?.checked;
    const alertBanner = document.getElementById('login-alert-banner');
    const alertMsg = document.getElementById('login-alert-message');
    const submitBtn = document.getElementById('btn-login-submit');

    const username = usernameInput ? usernameInput.value.trim() : '';
    const password = passwordInput ? passwordInput.value : '';

    if (!username || !password) {
      if (alertBanner) {
        alertBanner.style.display = 'flex';
        if (alertMsg) alertMsg.innerText = 'Please enter both username and password.';
      }
      return;
    }

    if (alertBanner) alertBanner.style.display = 'none';
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Authenticating...';
    }

    let authUser = null;

    if (this.isOnline) {
      try {
        const res = await this.apiFetch('api/endpoints/users.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'login', username, password })
        });
        const data = await res.json();
        if (data && data.offline === true) {
          // Nobody answered - the service worker spoke for a server that is not there.
          // Reading that as "the shop says no" deletes the offline grant and leaves a
          // till holding a cached account unable to open at all until the network returns.
          // Throwing falls through to the offline verification below, which is the point.
          throw new Error('server unreachable');
        }
        if (data.success && data.user) {
          authUser = data.user;
          const credHash = await this.hashCredentials(username, password);
          this.saveOfflineGrant(username, authUser, credHash);
        } else {
          // Explicit server rejection: credentials invalid or user deleted on DB
          let offlineHashes = this.safeJsonParse(localStorage.getItem('storeflow_offline_hashes'), {});
          if (offlineHashes[username.toLowerCase()]) {
            delete offlineHashes[username.toLowerCase()];
            localStorage.setItem('storeflow_offline_hashes', JSON.stringify(offlineHashes));
          }
          if (typeof this.stopCrossDeviceDeltaSync === 'function') {
      this.stopCrossDeviceDeltaSync();
    }
    this.sessionManager.clearActiveUser();
          this.currentUser = null;
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fa-solid fa-arrow-right-to-bracket"></i> <span>Sign In to Store</span>';
          }
          if (alertBanner) {
            alertBanner.style.display = 'flex';
            if (alertMsg) alertMsg.innerText = data.message || 'Invalid username or password.';
          }
          return;
        }
      } catch (err) {
        // True network / offline error
        const credHash = await this.hashCredentials(username, password);
        const offlineHashes = this.getOfflineHashes();
        const matched = offlineHashes[username.toLowerCase()];
        if (matched && matched.hash === credHash) {
          authUser = matched.user;
        } else {
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fa-solid fa-arrow-right-to-bracket"></i> <span>Sign In to Store</span>';
          }
          if (alertBanner) {
            alertBanner.style.display = 'flex';
            if (alertMsg) alertMsg.innerText = 'Server unreachable and offline credentials not found. Please connect to authenticate.';
          }
          return;
        }
      }
    } else {
      const credHash = await this.hashCredentials(username, password);
      const offlineHashes = this.getOfflineHashes();
      const matched = offlineHashes[username.toLowerCase()];
      if (matched && matched.hash === credHash) {
        authUser = matched.user;
      } else {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.innerHTML = '<i class="fa-solid fa-arrow-right-to-bracket"></i> <span>Sign In to Store</span>';
        }
        if (alertBanner) {
          alertBanner.style.display = 'flex';
          if (alertMsg) alertMsg.innerText = 'Invalid credentials for offline login. Please sign in online once to enable offline access.';
        }
        return;
      }
    }

    if (submitBtn) {
      submitBtn.disabled = false;
      submitBtn.innerHTML = '<i class="fa-solid fa-arrow-right-to-bracket"></i> <span>Sign In to Store</span>';
    }

    this.currentUser = authUser;
    if (this.isMultiBranch && authUser.branch_code && authUser.branch_code !== 'ALL') {
      this.branchCode = authUser.branch_code;
      localStorage.setItem('storeflow_branch_code', authUser.branch_code);
    }
    this.sessionManager.persistActiveUser(authUser, !!rememberMe);

    await this.loadInitialData();
    if (typeof this.syncHeartbeat === 'function') {
      await this.syncHeartbeat();
    }
    this.showApp();
    this.showToast(`Welcome back, ${authUser.full_name}!`, 'success');

    // Security Guard: Force password change on first run if using default credentials
    if (authUser.must_change_password) {
      setTimeout(() => this.promptMandatoryPasswordChange(), 500);
    }
  }

  promptMandatoryPasswordChange() {
    const modal = document.getElementById('mandatory-password-modal');
    if (!modal) return;
    const alertBox = document.getElementById('mandatory-pw-alert');
    if (alertBox) alertBox.style.display = 'none';

    const p1 = document.getElementById('mandatory-new-password');
    const p2 = document.getElementById('mandatory-confirm-password');
    const pin = document.getElementById('mandatory-new-pin');
    if (p1) p1.value = '';
    if (p2) p2.value = '';
    if (pin) pin.value = '';

    modal.classList.add('active');
  }

  async submitMandatoryPasswordChange() {
    const p1 = (document.getElementById('mandatory-new-password')?.value || '').trim();
    const p2 = (document.getElementById('mandatory-confirm-password')?.value || '').trim();
    const pin = (document.getElementById('mandatory-new-pin')?.value || '').trim();
    const alertBox = document.getElementById('mandatory-pw-alert');
    const btn = document.getElementById('btn-save-mandatory-pw');

    const showAlert = (msg) => {
      if (alertBox) {
        alertBox.innerText = msg;
        alertBox.style.display = 'block';
      }
    };

    if (!p1 || p1.length < 6) {
      return showAlert('Password must be at least 6 characters long.');
    }
    if (p1 === 'admin123') {
      return showAlert('You cannot reuse the default password admin123.');
    }
    if (p1 !== p2) {
      return showAlert('Passwords do not match. Please re-enter.');
    }
    if (!pin || pin.length !== 4 || !/^\d{4}$/.test(pin)) {
      return showAlert('Quick PIN must be exactly 4 digits (e.g. 5821).');
    }
    if (pin === '1234' || pin === '0000') {
      return showAlert('Please choose a more secure PIN than 1234 or 0000.');
    }

    if (btn) {
      btn.disabled = true;
      btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Securing Account...';
    }

    try {
      if (this.isStandaloneOffline || !this.isOnline || window.location.hostname === 'storeflow.local' || window.location.protocol === 'file:') {
        // Pure Standalone Offline Mode: Secure account immediately in local offline grant
        if (this.currentUser) {
          this.currentUser.must_change_password = false;
          this.currentUser.has_pin = true;
          this.sessionManager.persistActiveUser(this.currentUser, true);
        }
        const credHash = await this.hashCredentials(this.currentUser.username, p1);
        this.saveOfflineGrant(this.currentUser.username, this.currentUser, credHash);
        document.getElementById('mandatory-password-modal')?.classList.remove('active');
        this.showToast('Account secured! Your new password and PIN are now active.', 'success');
        return;
      }

      const res = await this.apiFetch('api/endpoints/users.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'change_initial_password',
          new_password: p1,
          new_pin: pin
        })
      });
      const data = await res.json();
      // An unreachable server is not a refused password change. Falling through to
      // the else branch would report a network outage as a validation failure while
      // the operator still sits on the default credentials.
      if (data && data.offline === true) throw new Error('server unreachable');
      if (data.success) {
        if (this.currentUser) {
          this.currentUser.must_change_password = false;
          this.currentUser.has_pin = true;
          this.sessionManager.persistActiveUser(this.currentUser, true);
        }
        // Update offline hash with new password
        const credHash = await this.hashCredentials(this.currentUser.username, p1);
        this.saveOfflineGrant(this.currentUser.username, this.currentUser, credHash);

        document.getElementById('mandatory-password-modal')?.classList.remove('active');
        this.showToast('Account secured! Your new password and PIN are now active.', 'success');
      } else {
        showAlert(data.message || 'Failed to update credentials.');
      }
    } catch (err) {
      showAlert('Network error updating credentials: ' + err.message);
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-lock"></i> Save & Secure Account';
      }
    }
  }

  toggleLoginPasswordVisibility() {
    const pwInput = document.getElementById('login-password');
    const icon = document.getElementById('toggle-pw-icon');
    const text = document.getElementById('toggle-pw-text');
    if (!pwInput) return;

    if (pwInput.type === 'password') {
      pwInput.type = 'text';
      if (icon) icon.className = 'fa-solid fa-eye-slash';
      if (text) text.innerText = 'Hide';
    } else {
      pwInput.type = 'password';
      if (icon) icon.className = 'fa-solid fa-eye';
      if (text) text.innerText = 'Show';
    }
  }

  fillDemoLogin(username, password) {
    const uInput = document.getElementById('login-username');
    const pInput = document.getElementById('login-password');
    if (uInput) uInput.value = username;
    if (pInput) pInput.value = password;
  }

  promptLogout() {
    this.updateUserUI();
    const modal = document.getElementById('logout-modal');
    if (modal) modal.classList.add('active');
  }

  closeLogoutModal() {
    const modal = document.getElementById('logout-modal');
    if (modal) modal.classList.remove('active');
  }

  // Sign-out leaves the till's IndexedDB mirror on the machine. Most of it is what the
  // next operator legitimately needs to ring up a sale, so it stays. What must not
  // outlive the session that was allowed to read it is the supplier and debt ledger:
  // a cashier is refused those tables online, and a shared browser holding a manager's
  // cached copy would hand them over with no request and no audit entry at all.
  async clearPrivilegedCaches() {
    const ledgers = ['purchases', 'vendors', 'vendor_payments', 'customer_payments', 'activity_logs'];
    for (const name of ledgers) {
      try {
        if (typeof localDB !== 'undefined' && localDB[name]) await localDB[name].clear();
      } catch (e) {
        console.warn(`Could not clear cached ${name}:`, e);
      }
    }
  }

  async performLogout() {
    if (this.isOnline) {
      try {
        await this.apiFetch('api/endpoints/users.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'logout' })
        });
      } catch (e) {}
    }
    if (typeof this.stopCrossDeviceDeltaSync === 'function') {
      this.stopCrossDeviceDeltaSync();
    }
    this.sessionManager.clearActiveUser();
    await this.clearPrivilegedCaches();
    this.currentUser = null;
    // A shared till signs the next operator in in the same tab, so anything cached in
    // memory stays reachable - in the UI and in DevTools - after sign-out. The next
    // sign-in re-reads everything from the server.
    this.products = [];
    this.categories = [];
    this.customers = [];
    this.cart = [];
    this.sales = [];
    this.purchases = [];
    this.inventory = [];
    this.backups = [];
    this.users = [];
    this.roles = [];
    this.permissionCatalogue = null;
    this.canManageRoles = false;
    this.showNewRoleRow = false;
    this.activityLogs = [];
    this.expenses = [];
    this.vendors = [];
    this.estimates = [];
    this.currentShiftData = null;
    this._activeCustomerStatementLedger = null;
    this.closeLogoutModal();
    this.showLogin();
    this.showToast('You have signed out of StoreFlow.', 'info');
  }

  /* ==========================================================================
     Inactivity & Manual Terminal Lock Screen (Shift Safety)
     ========================================================================== */
  initIdleLockTracker() {
    this.lastUserActivity = Date.now();
    let throttleTimeout = null;

    const onUserActivity = () => {
      if (this.isScreenLocked) return;
      if (!throttleTimeout) {
        this.lastUserActivity = Date.now();
        throttleTimeout = setTimeout(() => {
          throttleTimeout = null;
        }, 3000);
      }
    };

    ['mousemove', 'mousedown', 'keydown', 'touchstart', 'scroll'].forEach(evt => {
      window.addEventListener(evt, onUserActivity, { passive: true });
    });

    // Check inactivity every 15 seconds
    setInterval(() => {
      if (this.currentUser && !this.isScreenLocked) {
        const elapsed = Date.now() - this.lastUserActivity;
        if (elapsed >= this.idleTimeoutMs) {
          this.lockScreen('inactivity');
        }
      }
    }, 15000);
  }

  lockScreen(reason = 'manual') {
    if (!this.currentUser) return;
    this.isScreenLocked = true;

    const lockEl = document.getElementById('idle-lock-screen');
    const nameEl = document.getElementById('lock-screen-user-name');
    const roleEl = document.getElementById('lock-screen-user-role');
    const branchEl = document.getElementById('lock-screen-branch-badge');
    const reasonEl = document.getElementById('lock-screen-reason');
    const inputEl = document.getElementById('lock-screen-input');
    const alertEl = document.getElementById('lock-screen-alert');

    if (nameEl) nameEl.textContent = this.currentUser.full_name || this.currentUser.username || 'Staff Member';
    if (roleEl) roleEl.textContent = this.currentUser.role_name || 'Staff';
    if (branchEl) branchEl.innerHTML = `<i class="fa-solid fa-store"></i> ${this.escapeHtml(this.currentUser.branch_code || this.branchCode || 'MAIN-01')}`;

    if (reasonEl) {
      if (reason === 'inactivity') {
        reasonEl.innerHTML = '<i class="fa-solid fa-clock-rotate-left"></i> Register locked due to 30 minutes of inactivity';
      } else {
        reasonEl.innerHTML = '<i class="fa-solid fa-lock"></i> Register locked by staff';
      }
    }

    if (inputEl) {
      inputEl.value = '';
      inputEl.type = 'password';
    }
    const icon = document.getElementById('lock-toggle-pw-icon');
    if (icon) icon.className = 'fa-solid fa-eye';

    if (alertEl) alertEl.style.display = 'none';

    if (lockEl) {
      lockEl.style.display = 'flex';
      setTimeout(() => {
        if (inputEl) inputEl.focus();
      }, 100);
    }
  }

  async unlockScreen() {
    const inputEl = document.getElementById('lock-screen-input');
    const alertEl = document.getElementById('lock-screen-alert');
    const alertMsg = document.getElementById('lock-screen-alert-msg');
    const unlockBtn = document.getElementById('btn-lock-unlock');
    const val = inputEl ? inputEl.value.trim() : '';

    if (!val) {
      if (alertEl) {
        alertEl.style.display = 'flex';
        if (alertMsg) alertMsg.innerText = 'Please enter your password or PIN.';
      }
      if (inputEl) inputEl.focus();
      return;
    }

    if (unlockBtn) {
      unlockBtn.disabled = true;
      unlockBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Unlocking...';
    }

    if (this.isOnline) {
      try {
        const res = await this.apiFetch('api/endpoints/users.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'unlock', pin_or_password: val })
        });
        const data = await res.json();

        // The service worker answering for an absent server is not the server saying the
        // PIN is wrong: say so, and let the offline check below run.
        if (data && data.offline === true) throw new Error('server unreachable');

        if (data.session_expired) {
          // Session expired on backend (14 hours elapsed): force full login
          this.isScreenLocked = false;
          const lockEl = document.getElementById('idle-lock-screen');
          if (lockEl) lockEl.style.display = 'none';
          if (typeof this.stopCrossDeviceDeltaSync === 'function') {
      this.stopCrossDeviceDeltaSync();
    }
    this.sessionManager.clearActiveUser();
          this.currentUser = null;
          this.showLogin();
          this.showToast('Your 14-hour session has expired. Please sign in again.', 'warning');
          return;
        }

        if (data.success) {
          this._finalizeUnlock();
          return;
        } else {
          if (alertEl) {
            alertEl.style.display = 'flex';
            if (alertMsg) alertMsg.innerText = data.message || 'Incorrect password or PIN.';
          }
        }
      } catch (err) {
        // Network error while online: fallback to offline verification
        await this._unlockOffline(val, alertEl, alertMsg);
      }
    } else {
      await this._unlockOffline(val, alertEl, alertMsg);
    }

    if (unlockBtn) {
      unlockBtn.disabled = false;
      unlockBtn.innerHTML = '<i class="fa-solid fa-unlock"></i> <span>Unlock Register</span>';
    }
    if (inputEl) {
      inputEl.select();
      inputEl.focus();
    }
  }

  async _unlockOffline(val, alertEl, alertMsg) {
    if (!this.currentUser) return false;
    const username = (this.currentUser.username || '').toLowerCase();
    const offlineHashes = this.getOfflineHashes();
    const matched = offlineHashes[username];

    const blockedFor = this.offlineUnlockLockoutMs();
    if (blockedFor > 0) {
      if (alertEl) {
        alertEl.style.display = 'flex';
        if (alertMsg) alertMsg.innerText = `Too many incorrect attempts. Unlock again in ${Math.ceil(blockedFor / 1000)}s, or connect the till to the server.`;
      }
      return false;
    }

    const inputHash = await this.hashCredentials(username, val);
    if (matched && matched.hash === inputHash) {
      this._finalizeUnlock();
      return true;
    }

    // There is no master PIN. Anyone standing at a locked till - a customer, a
    // cleaner, a colleague the account is not theirs - could type 1234 and be
    // signed in as the last user, with their name on every sale afterwards.
    this.recordOfflineUnlockAttempt();
    if (alertEl) {
      alertEl.style.display = 'flex';
      if (alertMsg) alertMsg.innerText = 'Incorrect password or PIN.';
    }
    return false;
  }

  // The offline check runs in the browser against a hash the browser can compute in
  // microseconds, so nothing there stops a person standing at the till from walking
  // through all 10,000 PINs. users.php throttles its own unlock endpoint; this is the
  // same rule applied where the server cannot see the attempts. The lockout escalates
  // and clears itself once the till reaches the server again.
  offlineUnlockLockoutMs() {
    const st = this.safeJsonParse(localStorage.getItem('storeflow_offline_unlock'), {});
    const blockedUntil = Number(st.blocked_until) || 0;
    return Math.max(0, blockedUntil - Date.now());
  }

  recordOfflineUnlockAttempt() {
    const st = this.safeJsonParse(localStorage.getItem('storeflow_offline_unlock'), {});
    const fails = (Number(st.fails) || 0) + 1;
    const rounds = (Number(st.rounds) || 0);
    const next = fails >= 5
      ? { fails: 0, rounds: rounds + 1, blocked_until: Date.now() + Math.min(600000, 30000 * (2 ** rounds)) }
      : { fails, rounds, blocked_until: Number(st.blocked_until) || 0 };
    localStorage.setItem('storeflow_offline_unlock', JSON.stringify(next));
    return next;
  }

  clearOfflineUnlockAttempts() {
    localStorage.removeItem('storeflow_offline_unlock');
  }

  _finalizeUnlock() {
    this.clearOfflineUnlockAttempts();
    this.isScreenLocked = false;
    this.lastUserActivity = Date.now();
    const lockEl = document.getElementById('idle-lock-screen');
    if (lockEl) lockEl.style.display = 'none';
    const unlockBtn = document.getElementById('btn-lock-unlock');
    if (unlockBtn) {
      unlockBtn.disabled = false;
      unlockBtn.innerHTML = '<i class="fa-solid fa-unlock"></i> <span>Unlock Register</span>';
    }
    this.showToast(`Register unlocked. Welcome back, ${this.currentUser.full_name || this.currentUser.username}!`, 'success');
  }

  appendLockPin(digit) {
    const inputEl = document.getElementById('lock-screen-input');
    if (inputEl) {
      inputEl.value += digit;
      inputEl.focus();
    }
  }

  clearLockPin() {
    const inputEl = document.getElementById('lock-screen-input');
    if (inputEl) {
      inputEl.value = '';
      inputEl.focus();
    }
  }

  backspaceLockPin() {
    const inputEl = document.getElementById('lock-screen-input');
    if (inputEl && inputEl.value.length > 0) {
      inputEl.value = inputEl.value.slice(0, -1);
      inputEl.focus();
    }
  }

  toggleLockPasswordVisibility() {
    const inputEl = document.getElementById('lock-screen-input');
    const icon = document.getElementById('lock-toggle-pw-icon');
    if (!inputEl) return;
    if (inputEl.type === 'password') {
      inputEl.type = 'text';
      if (icon) icon.className = 'fa-solid fa-eye-slash';
    } else {
      inputEl.type = 'password';
      if (icon) icon.className = 'fa-solid fa-eye';
    }
  }

  switchAccountFromLock() {
    this.isScreenLocked = false;
    const lockEl = document.getElementById('idle-lock-screen');
    if (lockEl) lockEl.style.display = 'none';
    this.performLogout();
  }

  switchView(viewName) {
    if (viewName === 'settings') viewName = 'profile';
    if (!this.canAccessView(viewName)) {
      this.showToast(`Access Restricted: Your role (${this.getUserRoleName() || 'Staff'}) cannot access this module.`, 'warning');
      return;
    }

    this.currentView = viewName;
    try {
      localStorage.setItem('storeflow_active_view', viewName);
    } catch (e) {}
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(n => {
      if (n.getAttribute('data-view') === viewName) {
        n.classList.add('active');
      } else {
        n.classList.remove('active');
      }
    });

    const mobileNavBtns = document.querySelectorAll('.mobile-nav-btn');
    mobileNavBtns.forEach(b => {
      if (b.getAttribute('data-view') === viewName) {
        b.classList.add('active');
      } else {
        b.classList.remove('active');
      }
    });

    this.closeSidebarMobile();
    if (viewName !== 'pos' && typeof this.closePosCartModal === 'function') {
      this.closePosCartModal();
    }

    const titleEl = document.getElementById('page-title');
    if (titleEl) {
      const titles = {
        dashboard: 'Dashboard Overview',
        pos: 'Point of Sale (POS)',
        products: 'Products Catalog',
        inventory: 'Inventory & Stock Control',
        batches: 'Product Batches & Expiry Date Management',
        purchases: 'Factory Purchase Orders',
        vendors: 'Factory Suppliers & Accounts Payable',
        sales: 'Sales History & Profit Reports',
        returns: 'Customer Returns & Merchandise Refunds',
        expenses: 'Store Operating Expenses & Cash Drawer Payouts',
        customers: 'Customers Directory',
        users: 'Store Managers & Staff',
        backups: 'Database & 2-Hour Backups',
        profile: 'Store Profile & Receipts',
        activity_logs: 'Activity & Audit Trail',
        analytics: 'Analytics & Comparative Reports',
        estimates: 'Quotations & Proforma Estimates',
        rentals: 'Event & Equipment Rentals',
        hospitality: 'Dining Floor & Kitchen Tabs',
        ecommerce: 'Omnichannel E-Commerce Sync'
      };
      titleEl.innerText = titles[viewName] || 'StoreFlow';
    }
    this.renderCurrentView();

    // Re-visiting modules immediately refreshes fresh authoritative data from server
    if (this.isOnline && typeof this.refreshViewDataOnVisit === 'function') {
      this.refreshViewDataOnVisit(viewName);
    }
  }

  async refreshViewDataOnVisit(viewName) {
    if (this.isStandaloneOffline || !this.isOnline || this._isRefreshingView) return;
    this._isRefreshingView = true;

    try {
      if (viewName === 'dashboard') {
        await Promise.all([
          typeof this.fetchSales === 'function' ? this.fetchSales() : Promise.resolve(),
          typeof this.fetchExpenses === 'function' ? this.fetchExpenses() : Promise.resolve(),
          typeof this.fetchProducts === 'function' ? this.fetchProducts() : Promise.resolve()
        ]);
        if (this.currentView === 'dashboard') {
          this.renderCurrentView();
        }
      } else if (viewName === 'sales') {
        if (typeof this.fetchSales === 'function') {
          await this.fetchSales();
          if (this.currentView === 'sales') {
            this.renderCurrentView();
          }
        }
      } else if (viewName === 'inventory' || viewName === 'products') {
        if (typeof this.fetchProducts === 'function') {
          await this.fetchProducts();
          if (this.currentView === viewName) {
            this.renderCurrentView();
          }
        }
      } else if (viewName === 'expenses') {
        if (typeof this.fetchExpenses === 'function') {
          await this.fetchExpenses();
          if (this.currentView === 'expenses') {
            this.renderCurrentView();
          }
        }
      } else if (viewName === 'returns') {
        // The slip a cashier just printed is not in this array until somebody fetches it, and
        // re-opening the ledger used to show an empty one over a drawer already paid out of.
        if (typeof this.fetchReturns === 'function') {
          await this.fetchReturns();
          if (this.currentView === 'returns') {
            this.renderCurrentView();
          }
        }
      } else if (viewName === 'customers') {
        if (typeof this.fetchCustomers === 'function') {
          await this.fetchCustomers();
          if (this.currentView === 'customers') {
            this.renderCurrentView();
          }
        }
      } else if (viewName === 'pos') {
        if (typeof this.fetchProducts === 'function') {
          await this.fetchProducts();
          if (this.currentView === 'pos' && typeof this._safePosProductStockRefresh === 'function') {
            this._safePosProductStockRefresh();
          }
        }
      } else if (viewName === 'activity_logs') {
        if (typeof this.fetchActivityLogs === 'function') {
          await this.fetchActivityLogs();
          if (this.currentView === 'activity_logs') {
            this.renderCurrentView();
          }
        }
      } else if (viewName === 'rentals') {
        if (typeof this.fetchRentals === 'function') {
          await this.fetchRentals();
          if (this.currentView === 'rentals') {
            this.renderCurrentView();
          }
        }
      }

      if (typeof this.pollCrossDeviceDelta === 'function') {
        this.pollCrossDeviceDelta();
      }
    } catch (err) {
      console.warn('Silent view refresh failed:', err);
    } finally {
      this._isRefreshingView = false;
    }
  }

  // --- Multi-Tab & Cross-Window Live Synchronization (BroadcastChannel) ---

  initCrossTabSync() {
    if (typeof BroadcastChannel !== 'undefined') {
      try {
        this.syncChannel = new BroadcastChannel('storeflow_cross_tab_sync');
        this.syncChannel.onmessage = (event) => {
          if (event && event.data) {
            this.handleCrossTabEvent(event.data);
          }
        };
      } catch (e) {
        console.warn('BroadcastChannel unavailable:', e);
      }
    }

    if (typeof window !== 'undefined' && typeof window.addEventListener === 'function') {
      window.addEventListener('storage', (e) => {
        if (e.key === 'storeflow_cross_tab_event' && e.newValue) {
          try {
            const data = JSON.parse(e.newValue);
            this.handleCrossTabEvent(data);
          } catch (err) {}
        }
      });

      window.addEventListener('beforeunload', () => {
        if (this.syncChannel) {
          try { this.syncChannel.close(); } catch (e) {}
        }
      });
    }
  }

  broadcastSyncEvent(type, payload = {}) {
    const eventData = {
      type,
      payload,
      senderId: this._tabSessionId,
      timestamp: Date.now()
    };

    if (this.syncChannel) {
      try {
        this.syncChannel.postMessage(eventData);
      } catch (e) {
        console.warn('BroadcastChannel post error:', e);
      }
    }

    try {
      localStorage.setItem('storeflow_cross_tab_event', JSON.stringify(eventData));
    } catch (e) {}
  }

  async handleCrossTabEvent(data) {
    if (!data || data.senderId === this._tabSessionId) {
      return;
    }

    const { type, payload } = data;

    switch (type) {
      case 'SALE_COMPLETED':
        if (payload && payload.sale) {
          this.sales = [payload.sale, ...(this.sales || []).filter(s => s.id !== payload.sale.id)];
        } else if (typeof localDB !== 'undefined' && localDB.sales) {
          try {
            const allSales = await localDB.sales.toArray();
            this.sales = allSales.sort((a, b) => (b.created_at || '').localeCompare(a.created_at || '')).slice(0, 100);
          } catch (e) {}
        }

        if (typeof localDB !== 'undefined') {
          try {
            if (localDB.products) this.products = await localDB.products.toArray();
            if (localDB.inventory) this.inventory = await localDB.inventory.toArray();
          } catch (e) {}
        }

        if (this.currentView === 'dashboard' || this.currentView === 'sales' || this.currentView === 'inventory') {
          this._safeViewRefresh(this.currentView);
        } else if (this.currentView === 'pos') {
          this._safePosProductStockRefresh(payload ? payload.items : null);
        }
        this.showToast('Sale recorded in another tab. Stock & reports synced.', 'info');
        break;

      case 'EXPENSE_MUTATED':
        if (payload && payload.action === 'DELETE') {
          this.expenses = (this.expenses || []).filter(e => e.id !== payload.id);
        } else if (payload && payload.expense) {
          this.expenses = [payload.expense, ...(this.expenses || []).filter(e => e.id !== payload.expense.id)];
        } else if (typeof localDB !== 'undefined' && localDB.expenses) {
          try {
            const allExp = await localDB.expenses.toArray();
            this.expenses = allExp.sort((a, b) => (b.created_at || b.expense_date || '').localeCompare(a.created_at || a.expense_date || ''));
          } catch (e) {}
        }

        if (this.currentView === 'dashboard' || this.currentView === 'expenses') {
          this._safeViewRefresh(this.currentView);
        }
        this.showToast('Operating expense updated in another tab.', 'info');
        break;

      case 'PRODUCT_MUTATED':
      case 'STOCK_ADJUSTED':
        if (typeof localDB !== 'undefined') {
          try {
            if (localDB.products) this.products = await localDB.products.toArray();
            if (localDB.inventory) this.inventory = await localDB.inventory.toArray();
          } catch (e) {}
        }
        if (['pos', 'products', 'inventory', 'dashboard'].includes(this.currentView)) {
          this._safeViewRefresh(this.currentView);
        }
        this.showToast('Catalog & inventory updated in another tab.', 'info');
        break;

      case 'CUSTOMER_MUTATED':
        if (typeof localDB !== 'undefined' && localDB.customers) {
          try {
            this.customers = await localDB.customers.toArray();
          } catch (e) {}
        }
        if (this.currentView === 'customers' || this.currentView === 'pos') {
          this._safeViewRefresh(this.currentView);
        }
        break;

      case 'BATCH_MUTATED':
        if (typeof this.fetchBatches === 'function') {
          try { await this.fetchBatches(); } catch (e) {}
        }
        if (this.currentView === 'batches' || this.currentView === 'inventory' || this.currentView === 'pos') {
          this._safeViewRefresh(this.currentView);
        }
        break;

      case 'RETURN_RECORDED':
        if (typeof localDB !== 'undefined') {
          try {
            if (localDB.sales_returns) this.salesReturns = await localDB.sales_returns.toArray();
            if (localDB.products) this.products = await localDB.products.toArray();
          } catch (e) {}
        }
        if (['returns', 'dashboard', 'sales', 'pos'].includes(this.currentView)) {
          this._safeViewRefresh(this.currentView);
        }
        this.showToast('Customer return recorded in another tab.', 'info');
        break;

      case 'SALE_VOIDED':
        // A void moves three things another till is looking at: the shelf (the goods went
        // straight back), the customer's account (the charge the bill made is undone) and the
        // receipts ledger. Reload all three from the shared book rather than leaving a second
        // counter showing a receipt that is already cancelled.
        if (typeof localDB !== 'undefined') {
          try {
            if (localDB.sales) this.sales = await localDB.sales.toArray();
            if (localDB.products) this.products = await localDB.products.toArray();
            if (localDB.customers) this.customers = await localDB.customers.toArray();
          } catch (e) {}
        }
        if (['sales', 'dashboard', 'pos', 'customers'].includes(this.currentView)) {
          this._safeViewRefresh(this.currentView);
        }
        this.showToast('A receipt was voided in another tab.', 'info');
        break;

      case 'SYNC_COMPLETED':
        if (typeof this.updateNetworkStatusUI === 'function') {
          await this.updateNetworkStatusUI();
        }
        break;
    }
  }

  _safeViewRefresh(viewName) {
    if (this.currentView !== viewName) return;

    const hasActiveModal = (typeof document !== 'undefined') && document.querySelector('.modal-overlay.active');
    const activeEl = (typeof document !== 'undefined') ? document.activeElement : null;
    const isTyping = activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA' || activeEl.tagName === 'SELECT');

    if (hasActiveModal || isTyping) {
      this._pendingViewRefresh = viewName;
      return;
    }

    if (typeof this.renderCurrentView === 'function') {
      this.renderCurrentView();
    }
  }

  _safePosProductStockRefresh(affectedItems = null) {
    if (this.currentView !== 'pos') return;

    const searchInput = (typeof document !== 'undefined') ? document.getElementById('pos-search') : null;
    const isSearchFocused = searchInput && document.activeElement === searchInput;

    if (!isSearchFocused && !document.querySelector('.modal-overlay.active')) {
      if (typeof this.renderCurrentView === 'function') {
        this.renderCurrentView();
      }
      return;
    }

    if (typeof document !== 'undefined') {
      const cards = document.querySelectorAll('.pos-product-card');
      cards.forEach(card => {
        const prodId = card.getAttribute('data-product-id');
        if (prodId) {
          const rawP = (this.products || []).find(p => p.id === prodId);
          if (rawP) {
            const eff = typeof this.getEffectiveProductForBranch === 'function' ? this.getEffectiveProductForBranch(rawP) : rawP;
            const inStock = Number((eff && eff.effectiveStock !== undefined) ? eff.effectiveStock : (rawP.current_quantity || 0));
            const isOut = inStock <= 0;
            const isLow = inStock > 0 && inStock <= Number((eff && eff.min_stock_alert) || 5);

            // Targeted by class, not by ".price-row .badge": the pack-price chip now
            // shares that row, and the old fallback quietly overwrote a crate price with
            // "12 left" the moment a card was re-rendered after a sale.
            const stockNote = card.querySelector('.pos-stock-note');
            if (stockNote) {
              stockNote.innerText = isOut ? 'Out' : inStock + ' left';
              stockNote.className = `pos-stock-note ${isOut ? 'out' : (isLow ? 'low' : '')}`;
            }

            if (isOut) {
              card.classList.add('out-of-stock');
              if (!card.querySelector('.out-of-stock-ribbon')) {
                const ribbon = document.createElement('div');
                ribbon.className = 'out-of-stock-ribbon';
                ribbon.innerText = 'Out of Stock';
                card.prepend(ribbon);
              }
            } else {
              card.classList.remove('out-of-stock');
              const ribbon = card.querySelector('.out-of-stock-ribbon');
              if (ribbon) ribbon.remove();
            }
          }
        }
      });
    }
  }

  // A voided receipt is on the book and took nothing. Its stored figures stay as the customer
  // was quoted, because the paper cannot be re-issued at another number; the nil is said here,
  // where every board in the shop works out what a receipt contributed.
  isVoidedSale(s) {
    // Trimmed the way the server trims it: a padded status is counted as a void on the book, and
    // a till that reads it as a live sale would book money the shop handed back.
    return String(s?.status || '').trim().toUpperCase() === 'VOID';
  }

  getSaleProfitMetrics(s) {
    const totalAmount = Number(s?.total_amount || 0);
    const refundedAmount = Number(s?.refunded_amount || 0);
    const grossProfit = Number(s?.net_profit !== undefined ? s.net_profit : s?.gross_profit || 0);
    const totalCost = Number(s?.total_cost !== undefined ? s.total_cost : Math.max(0, totalAmount - grossProfit));

    // Ahead of the refund tests, because a void that somehow also carries a credit note is still
    // a receipt worth nothing, and reading it as merely refunded would keep its money in.
    if (this.isVoidedSale(s)) {
      return {
        netRevenue: 0,
        netCost: 0,
        netProfit: 0,
        isVoided: true,
        isFullyRefunded: false,
        isPartiallyRefunded: false
      };
    }

    const isFullyRefunded = (s?.status === 'REFUNDED') || (totalAmount > 0 && refundedAmount >= (totalAmount - 0.01));

    if (isFullyRefunded) {
      return {
        netRevenue: 0,
        netCost: 0,
        netProfit: 0,
        isFullyRefunded: true,
        isPartiallyRefunded: false
      };
    }

    if (refundedAmount > 0 && totalAmount > 0) {
      const retainedRatio = Math.max(0, (totalAmount - refundedAmount) / totalAmount);
      return {
        netRevenue: Math.max(0, totalAmount - refundedAmount),
        netCost: Math.max(0, totalCost * retainedRatio),
        netProfit: Math.max(0, grossProfit * retainedRatio),
        isFullyRefunded: false,
        isPartiallyRefunded: true
      };
    }

    return {
      netRevenue: totalAmount,
      netCost: totalCost,
      netProfit: grossProfit,
      isFullyRefunded: false,
      isPartiallyRefunded: false
    };
  }

  getCartTotals() {
    const totalLineDiscounts = (this.cart || []).reduce((sum, item) => sum + Number(item.line_discount || 0), 0);
    const subtotal = (this.cart || []).reduce((sum, item) => sum + (Number(item.quantity || 0) * Number(item.selling_price || 0)), 0);
    const totalCost = (this.cart || []).reduce((sum, item) => {
      const baseUnits = Number(item.quantity || 0) * Number(item.multiplier || 1);
      return sum + (baseUnits * Number(item.unit_cost_price || 0));
    }, 0);
    const cartDiscount = Number(this.cartDiscount || 0);
    const discount = Number((cartDiscount + totalLineDiscounts).toFixed(2));
    const taxableAmount = Math.max(0, subtotal - discount);
    const taxRate = Number(this.storeProfile?.tax_rate || 0);
    const tax = taxRate > 0 ? Number(((taxableAmount * taxRate) / 100).toFixed(2)) : 0;
    this.cartTax = tax;
    // Points and the member's tier perk come off the goods, after the cashier's discount and
    // before tax - the same order the server prices them in. They are NOT folded into
    // cartDiscount: that figure is the cashier's own and is what the role's discount ceiling is
    // measured against, and a member's points are the shop's promise, not a cashier's discretion.
    const reward = (typeof this.loyaltyPreview === 'function')
      ? this.loyaltyPreview(taxableAmount)
      : { loyalty: 0, tier: 0 };
    const loyaltyValue = Number(reward.loyalty || 0);
    const tierValue = Number(reward.tier || 0);
    const moneyOff = Number((discount + loyaltyValue + tierValue).toFixed(2));
    const totalAmount = Number((Math.max(0, taxableAmount - loyaltyValue - tierValue) + tax).toFixed(2));
    const grossProfit = Number((Math.max(0, subtotal - moneyOff) - totalCost).toFixed(2));

    return {
      subtotal,
      totalCost,
      discount,
      cartDiscount,
      totalLineDiscounts,
      loyaltyValue,
      tierValue,
      moneyOff,
      taxableAmount,
      taxRate,
      tax,
      totalAmount,
      grossProfit
    };
  }

  // Every size this product can be sold in, biggest-of-one included. The catalogue table
  // is the authority; the two pack columns are read only for a product whose shop has not
  // opened the till since the table arrived, so the same screen works either way.
  productUnitsOf(product) {
    if (!product) return [];
    const rows = (product.units || [])
      .map(u => ({
        id: u.id || '',
        unit_name: String(u.unit_name || '').trim(),
        size_in_base: Number(u.size_in_base || 1),
        selling_price: (u.selling_price === null || u.selling_price === undefined || u.selling_price === '')
          ? null : Number(u.selling_price),
        barcode: String(u.barcode || '').trim(),
        is_base: Number(u.is_base || 0) === 1,
      }))
      .filter(u => u.unit_name !== '' && u.size_in_base > 0);
    if (rows.length > 0) return rows;

    const baseUnit = product.unit || 'pcs';
    const packUnit = String(product.pack_unit || '').trim();
    const packSize = Number(product.pack_size || 1);
    const rows2 = [{ id: '', unit_name: baseUnit, size_in_base: 1, selling_price: null, barcode: '', is_base: true }];
    if (packUnit !== '' && packSize > 1 && packUnit.toLowerCase() !== baseUnit.toLowerCase()) {
      rows2.push({
        id: '', unit_name: packUnit, size_in_base: packSize,
        selling_price: Number(product.pack_price || 0) > 0 ? Number(product.pack_price) : null,
        barcode: '', is_base: false,
      });
    }
    return rows2;
  }

  productUnitOf(product, label) {
    const units = this.productUnitsOf(product);
    const wanted = String(label || '').trim().toLowerCase();
    if (wanted !== '') {
      const hit = units.find(u => u.unit_name.toLowerCase() === wanted);
      if (hit) return hit;
    }
    return units.find(u => u.is_base) || units[0] || null;
  }

  // The size a printed code belongs to. A crate with an EAN of its own is not the same
  // thing as the egg inside it, so the size-level code has to be consulted before the
  // product-level one - otherwise the shop sticks a crate talker on the shelf and the
  // till rings up one egg and takes one egg off.
  productUnitOfBarcode(product, code) {
    const wanted = String(code || '').trim().toLowerCase();
    if (wanted === '') return null;
    const wantedCompact = wanted.replace(/[\s\-_]/g, '');
    return this.productUnitsOf(product).find(u => {
      const unitCode = String(u.barcode || '').trim().toLowerCase();
      if (unitCode === '') return false;
      return unitCode === wanted || unitCode.replace(/[\s\-_]/g, '') === wantedCompact;
    }) || null;
  }

  // A size with no price of its own sells at the loose price times how many it holds,
  // which is what a shop that never typed a pack price means.
  productUnitPrice(unit, basePrice) {
    if (!unit) return Number(basePrice || 0);
    if (unit.selling_price !== null && Number.isFinite(unit.selling_price)) return Number(unit.selling_price);
    return Number((Number(basePrice || 0) * Number(unit.size_in_base || 1)).toFixed(2));
  }

  // One rule for every way a cart line can grow: a tap on a card, a click on a size pill,
  // the +/- buttons or a typed quantity. The shelf is counted in loose units and each line
  // in its own size, so the two only become comparable after every line is converted - and
  // the other lines for the same product have to be counted with it, or a tray holding
  // 4 crates and an egg line lets a third crate in because it only looked at itself.
  cartRoomInBase(product, exceptIndex = -1) {
    if ((product.product_type || '').toLowerCase() === 'service') {
      return { inStock: 999999, committed: 0, room: 999999 };
    }
    const inStock = Number(product.effectiveStock || 0);
    let committed = 0;
    this.cart.forEach((i, idx) => {
      if (idx === exceptIndex || i.product_id !== product.id) return;
      committed += Number(i.quantity || 0) * Number(i.multiplier || 1);
    });
    return { inStock, committed, room: inStock - committed };
  }

  setCartItemUnit(index, unitLabel) {
    const item = this.cart[index];
    if (!item) return;
    const rawProduct = this.products.find(p => p.id === item.product_id);
    if (!rawProduct) return;
    const product = this.getEffectiveProductForBranch(rawProduct);

    const unit = this.productUnitOf(product, unitLabel);
    if (!unit) return;
    if (String(unit.unit_name).toLowerCase() === String(item.selected_unit || item.unit || '').toLowerCase()) return;
    const basePrice = Number(product.effectivePrice || product.selling_price || 0);

    // The pill used to rewrite the line's multiplier without asking the shelf, so six
    // loose eggs on a 490-egg counter became six boxes of four hundred and twenty on a
    // click - 2,520 eggs, no warning, and the customer at the till with a receipt.
    const newMultiplier = Number(unit.size_in_base || 1);
    const wanted = Number(item.quantity || 0) * newMultiplier;
    const room = this.cartRoomInBase(product, index);
    if (wanted > room.room && this.storeProfile.allow_negative_stock != 1) {
      this.showToast(`Cannot switch ${item.name} to ${unit.unit_name}: ${wanted} ${item.unit} needed, ${room.room} left on the shelf once the cart is counted.`, 'warning');
      return;
    }

    item.selected_unit = unit.unit_name;
    item.unit = (this.productUnitsOf(product).find(u => u.is_base) || { unit_name: product.unit || 'pcs' }).unit_name;
    item.multiplier = newMultiplier;
    item.selling_price = this.productUnitPrice(unit, basePrice);
    item.base_selling_price = basePrice;

    if (wanted > room.room) {
      this.showToast(`Warning: ${item.name} is now ${wanted} ${item.unit} against ${room.inStock} on the shelf. Stock is going negative.`, 'warning');
    }
    this.renderCurrentView();
  }

  openBarcodeLabelStudio(targetProductId = null) {
    if (typeof this.openBarcodeLabelModal === 'function') {
      return this.openBarcodeLabelModal(targetProductId);
    }
  }

}

if (typeof window !== 'undefined') {
  window.StoreAppShell = StoreAppShell;
}
