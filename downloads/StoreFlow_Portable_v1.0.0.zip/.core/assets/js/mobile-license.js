// assets/js/mobile-license.js
// ============================================================
//  The Standalone phone edition has no PHP behind it, so this file is the only
//  thing that can decide whether a paid key is genuine. It verifies the same
//  Ed25519 signature the PC verifies in api/config/sys_integrity.php, over the
//  same canonical payload, against the same public key.
//
//  A key is bound to the machine reference the paywall displays, so a key minted
//  for one phone cannot open another, and typing something long enough means nothing.
//
//  Ed25519 comes from nacl-fast.min.js (tweetnacl, public domain) rather than
//  WebCrypto: the cheap Android phones this edition targets ship WebViews old
//  enough to lack Ed25519 in SubtleCrypto, and a licence that works on one handset
//  and not another is a refund, not a licence.
// ============================================================
(function (global) {
  'use strict';

  // Must equal STOREFLOW_LICENSE_PUBKEY in api/config/sys_integrity.php.
  // tests/mobile_license_test.js fails if the two drift apart.
  var PUBLIC_KEY_HEX =
    '954F0E514BBFDECF95DF11C720A40B5859246C67FBECE6D675BBC355' +
    '3DD2B064';

  // Mirrors _SYS_LICENSE_REGEX on the PC: 16 groups of 8 hex characters.
  var TOKEN_RE = /^SFLOW2-(LIFE|T\d{1,3})-([0-9A-F]{8}(?:-[0-9A-F]{8}){15})$/;

  var DAY_MS = 24 * 60 * 60 * 1000;
  var TRIAL_DAYS = 14;

  function parseToken(token) {
    if (typeof token !== 'string') return null;
    var cleaned = token.toUpperCase().replace(/\s+/g, '');
    var m = TOKEN_RE.exec(cleaned);
    if (!m) return null;
    return {
      kindTag: m[1],
      days: m[1] === 'LIFE' ? 0 : parseInt(m[1].slice(1), 10),
      signatureHex: m[2].replace(/-/g, '')
    };
  }

  // Exactly the string _sysLicensePayload() signs on the PC.
  function payloadFor(machineRef, kindTag) {
    var kind = kindTag === 'LIFE' ? 'LIFE' : 'TRIAL-' + parseInt(kindTag.slice(1), 10);
    return 'SFLOW2|' + String(machineRef).toLowerCase().trim() + '|' + kind;
  }

  function hexToBytes(hex) {
    var out = new Uint8Array(hex.length / 2);
    for (var i = 0; i < out.length; i++) out[i] = parseInt(hex.substr(i * 2, 2), 16);
    return out;
  }

  function verifySignature(token, machineRef) {
    var parsed = parseToken(token);
    if (!parsed) return null;
    var nacl = global.nacl;
    if (!nacl || !nacl.sign || typeof nacl.sign.detached.verify !== 'function') return null;
    var ok = false;
    try {
      ok = nacl.sign.detached.verify(
        new Uint8Array(utf8Bytes(payloadFor(machineRef, parsed.kindTag))),
        hexToBytes(parsed.signatureHex),
        hexToBytes(PUBLIC_KEY_HEX)
      );
    } catch (e) {
      ok = false;
    }
    return ok ? parsed : null;
  }

  function utf8Bytes(str) {
    var out = [];
    for (var i = 0; i < str.length; i++) {
      var c = str.charCodeAt(i);
      if (c < 128) out.push(c);
      else if (c < 2048) out.push(192 | (c >> 6), 128 | (c & 63));
      else out.push(224 | (c >> 12), 128 | ((c >> 6) & 63), 128 | (c & 63));
    }
    return out;
  }

  function defaultBridge() {
    var a = global.StoreFlowAndroid;
    return (a && typeof a.licenceRead === 'function' && typeof a.licenceWrite === 'function') ? a : null;
  }

  function readAnchors(bridge) {
    try {
      var raw = bridge.licenceRead();
      var obj = raw ? JSON.parse(raw) : {};
      return (obj && typeof obj === 'object') ? obj : {};
    } catch (e) {
      return {};
    }
  }

  function daysBetween(ms) {
    return Math.floor(ms / DAY_MS);
  }

  // The clock the owner sets is not trusted for counting days: the highest
  // timestamp ever seen is the one that moves, so winding the handset back
  // cannot hand anybody an extra day. Same reasoning as the PC throttle anchor.
  function evaluate(machineRef, opts) {
    opts = opts || {};
    var bridge = Object.prototype.hasOwnProperty.call(opts, 'bridge') ? opts.bridge : defaultBridge();
    var now = typeof opts.now === 'function' ? opts.now() : Date.now();

    if (!bridge) return { ok: false, reason: 'no-native-storage', ref: machineRef || '' };
    if (!machineRef) return { ok: false, reason: 'no-device-reference', ref: '' };

    var anchors = readAnchors(bridge);
    var changed = false;
    var storedHighWater = Number(anchors.highWater) || 0;

    // Seeded once, at install, and never rewritten. The trial is highWater - trialStart,
    // so anything that pushes the start forward gives days back: set the clock ahead,
    // open the app once, put it right again, and the 14 days are endless. A start that
    // only moves backwards locks out the owner instead, so the rule is that it never moves.
    var startedAt = Number(anchors.trialStart) || 0;
    if (startedAt <= 0) {
      startedAt = Math.max(now, storedHighWater);
      anchors.trialStart = startedAt;
      changed = true;
    }
    var highWater = Math.max(storedHighWater, startedAt, now);
    if (highWater !== storedHighWater) {
      anchors.highWater = highWater;
      changed = true;
    }
    if (changed) {
      try { bridge.licenceWrite(JSON.stringify(anchors)); } catch (e) { /* still decide from what we read */ }
    }

    var base = { ok: true, ref: machineRef, quotaTotal: TRIAL_DAYS };

    if (anchors.token) {
      var parsed = verifySignature(anchors.token, machineRef);
      if (!parsed) {
        // Either the key was minted for a different handset (factory reset changes
        // the reference) or the stored value is not a signature at all.
        base.status = 'expired';
        base.quota = 0;
        base.reason = anchors.tokenRef && anchors.tokenRef !== machineRef ? 'device-mismatch' : 'key-not-valid-for-this-device';
        return base;
      }
      if (parsed.kindTag === 'LIFE') {
        base.status = 'active';
        base.quota = 0;
        base.reason = 'lifetime';
        return base;
      }
      var grantedFrom = Number(anchors.keyActivatedAt) || startedAt;
      var left = parsed.days - daysBetween(Math.max(0, highWater - grantedFrom));
      base.status = left > 0 ? 'trial' : 'expired';
      base.quota = Math.max(0, left);
      base.quotaTotal = parsed.days;
      base.reason = base.status === 'trial' ? 'key-days-remaining' : 'key-days-used-up';
      return base;
    }

    var remaining = TRIAL_DAYS - daysBetween(Math.max(0, highWater - startedAt));
    base.status = remaining > 0 ? 'trial' : 'expired';
    base.quota = Math.max(0, remaining);
    base.reason = base.status === 'trial' ? 'evaluation-trial' : 'trial-elapsed';
    return base;
  }

  // Called by the paywall when the owner presses Unlock. Nothing is stored unless
  // the signature opens this exact device reference.
  function activate(token, machineRef, opts) {
    opts = opts || {};
    var bridge = Object.prototype.hasOwnProperty.call(opts, 'bridge') ? opts.bridge : defaultBridge();
    var now = typeof opts.now === 'function' ? opts.now() : Date.now();

    if (!bridge) return { ok: false, reason: 'no-native-storage' };
    var parsed = verifySignature(token, machineRef);
    if (!parsed) return { ok: false, reason: 'key-not-valid-for-this-device' };

    var anchors = readAnchors(bridge);
    anchors.token = token.toUpperCase().replace(/\s+/g, '');
    anchors.tokenRef = machineRef;
    anchors.keyActivatedAt = now;
    if ((Number(anchors.trialStart) || 0) <= 0) anchors.trialStart = now;
    anchors.highWater = Math.max(Number(anchors.highWater) || 0, now);
    try {
      bridge.licenceWrite(JSON.stringify(anchors));
    } catch (e) {
      return { ok: false, reason: 'native-storage-refused' };
    }
    return { ok: true, kind: parsed.kindTag, days: parsed.days };
  }

  var api = {
    PUBLIC_KEY_HEX: PUBLIC_KEY_HEX,
    TRIAL_DAYS: TRIAL_DAYS,
    parseToken: parseToken,
    payloadFor: payloadFor,
    verifySignature: verifySignature,
    evaluate: evaluate,
    activate: activate
  };

  global.StoreFlowMobileLicense = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
