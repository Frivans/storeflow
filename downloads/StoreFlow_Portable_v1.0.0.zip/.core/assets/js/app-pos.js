Object.assign(StoreApp.prototype, {
  getPosHTML() {
    const activeCategory = this.posSelectedCategory || 'All';
    let filteredProducts = (this.products || []).filter(p => !this.isRentalProduct(p));

    if (activeCategory !== 'All') {
      filteredProducts = filteredProducts.filter(p => p.category === activeCategory);
    }

    if (this.posSearchTerm) {
      const searchTerm = (this.posSearchTerm || '').trim().toLowerCase();
      const compactSearch = searchTerm.replace(/[\s\-_]/g, '');
      filteredProducts = filteredProducts.filter(p => {
        const name = (p.name || '').toLowerCase();
        const sku = (p.sku || '').toLowerCase();
        const skuCompact = sku.replace(/[\s\-_]/g, '');
        const barcode = (p.barcode || '').toLowerCase();
        const barcodeCompact = barcode.replace(/[\s\-_]/g, '');
        return (
          name.includes(searchTerm) ||
          sku.includes(searchTerm) ||
          (compactSearch && skuCompact.includes(compactSearch)) ||
          barcode.includes(searchTerm) ||
          (compactSearch && barcodeCompact.includes(compactSearch))
        );
      });
    }

    if (this.isMultiBranch) {
      // Filter out products that have been explicitly disabled for sales at this branch
      filteredProducts = filteredProducts.filter(rawP => {
        const eff = this.getEffectiveProductForBranch(rawP);
        return eff.isAvailable;
      });
    }

    const { subtotal, discount, cartDiscount = 0, totalLineDiscounts = 0, taxRate, tax, totalAmount: total, loyaltyValue = 0, tierValue = 0 } = this.getCartTotals();

    return `
      <div class="pos-container">
        ${(this.getOperatingMode && (this.getOperatingMode() === "HOSPITALITY" || this.getOperatingMode() === "HYBRID")) ? `
          <div class="pos-table-banner" style="grid-column: 1 / -1; display: flex; flex-direction: column; gap: 0.5rem; background: #ecfdf5; border: 1.5px solid #6ee7b7; border-radius: var(--radius-md); padding: 0.65rem 1rem; margin-bottom: 0.75rem; box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
            <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 0.5rem;">
              <div style="display: flex; align-items: center; gap: 0.75rem; flex-wrap: wrap;">
                <div style="display: flex; align-items: center; gap: 0.4rem; background: #059669; color: #ffffff; padding: 0.3rem 0.75rem; border-radius: 8px; font-weight: 800; font-size: 0.88rem;">
                  <i class="fa-solid fa-utensils"></i>
                  <span>${this.activeTable ? this.escapeHtml(this.activeTable.number) : "Walk-in / Counter"}</span>
                </div>
                <div style="font-size: 0.82rem; color: #065f46; font-weight: 600;">
                  ${this.activeTable ? (() => {
                    const hasTab = !!this.activeTable.orderId;
                    const soFar = (hasTab && typeof this.activeTable.tabSubtotal === 'number')
                      ? ` &bull; Tab so far: <strong>${this.formatCurrency(this.activeTable.tabSubtotal)}</strong> before tax${this.activeTable.ticketCount > 1 ? ` (${this.activeTable.ticketCount} tickets)` : ''}`
                      : '';
                    const state = hasTab
                      ? `<span class="badge badge-warning" style="font-size:0.7rem;">Tab open</span>${soFar}`
                      : '<span class="badge" style="font-size:0.7rem;background:#fef3c7;color:#b45309;">No ticket fired yet</span>';
                    return `Zone: <strong>${this.escapeHtml(this.activeTable.zone || 'Main Area')}</strong> &bull; Seated: <strong>${Number(this.activeTable.guests) || 1} guests</strong> &bull; Status: ${state}`;
                  })() : "Takeaway / Quick Counter (No table assigned)"}
                </div>
              </div>
              <div style="display: flex; gap: 0.5rem; align-items: center;">
                <button type="button" class="btn btn-sm" onclick="app.openHospitalityModal()" style="background: #ffffff; border: 1.5px solid #059669; color: #047857; font-weight: 700; display: flex; align-items: center; gap: 0.35rem;">
                  <i class="fa-solid fa-chair"></i> ${this.activeTable ? "Switch Space" : "Assign Table / Bar"}
                </button>
                ${this.activeTable ? `<button type="button" class="btn btn-sm btn-outline" onclick="app.clearActiveTable()" style="border-color: #f87171; color: #dc2626; background: #fff;" title="Release table context"><i class="fa-solid fa-xmark"></i></button>` : ""}
                <button type="button" class="btn btn-sm" onclick="app.openKDSModal()" style="background: #0f172a; border: 1px solid #334155; color: #f8fafc; font-weight: 700; display: flex; align-items: center; gap: 0.35rem;" title="Open the kitchen order board">
                  <i class="fa-solid fa-tv" style="color: #38bdf8;"></i> Kitchen Board
                </button>
              </div>
            </div>

            ${this.activeTable ? `
              <div style="display: flex; align-items: center; gap: 0.4rem; flex-wrap: wrap; border-top: 1px dashed #a7f3d0; padding-top: 0.45rem;">
                <span style="font-size: 0.74rem; font-weight: 800; color: #065f46;"><i class="fa-solid fa-user-tag"></i> Active Diner:</span>
                <button type="button" class="btn btn-sm" onclick="app.setActiveSeat('Shared')" style="padding: 0.15rem 0.55rem; font-size: 0.72rem; border-radius: 999px; background: ${(this.activeSeat === 'Shared' || !this.activeSeat) ? '#059669' : '#ffffff'}; color: ${(this.activeSeat === 'Shared' || !this.activeSeat) ? '#ffffff' : '#065f46'}; border: 1.5px solid #059669; font-weight: 700;">
                  <i class="fa-solid fa-utensils"></i> Entire Table (Shared)
                </button>
                ${(() => {
                  const knownSeats = new Set(['Seat 1', 'Seat 2']);
                  const cap = Math.min(20, Math.max(2, Number(this.activeTable.capacity || this.activeTable.guests || 2)));
                  for (let s = 1; s <= cap; s++) knownSeats.add(`Seat ${s}`);
                  (this.cart || []).forEach(it => { if (it.seat_number && it.seat_number !== 'Shared') knownSeats.add(it.seat_number); });
                  return Array.from(knownSeats).map(s => `
                    <button type="button" class="btn btn-sm" data-seat="${this.escapeHtml(s)}" onclick="app.setActiveSeat(this.dataset.seat)" style="padding: 0.15rem 0.55rem; font-size: 0.72rem; border-radius: 999px; background: ${this.activeSeat === s ? '#0284c7' : '#ffffff'}; color: ${this.activeSeat === s ? '#ffffff' : '#0369a1'}; border: 1.5px solid ${this.activeSeat === s ? '#0284c7' : '#bae6fd'}; font-weight: 700;">
                      <i class="fa-solid fa-chair"></i> ${this.escapeHtml(s)}
                    </button>
                  `).join('');
                })()}
                <button type="button" class="btn btn-sm btn-outline" onclick="app.addNewCustomSeat()" style="padding: 0.15rem 0.55rem; font-size: 0.72rem; border-radius: 999px; border-color: #059669; color: #059669; background: #fff; font-weight: 600;" title="Add custom seat/guest name (e.g. John, Bar-3)">
                  <i class="fa-solid fa-plus"></i> Add Seat / Guest
                </button>
              </div>
            ` : ''}
          </div>
        ` : ""}
        <!-- Left: Product Grid with Photos & Out-of-Stock handling -->
        <div class="pos-products-panel">
          <div class="pos-shortcuts-strip hide-mobile" style="display: flex; gap: 0.65rem; align-items: center; margin-bottom: 0.65rem; padding: 0.4rem 0.75rem; background: #ffffff; border: 1px solid var(--slate-200); border-radius: var(--radius-md); font-size: 0.76rem; color: var(--slate-600); overflow-x: auto; box-shadow: 0 1px 2px rgba(0,0,0,0.03);">
            <span style="font-weight: 700; color: var(--slate-700);"><i class="fa-solid fa-keyboard" style="color: var(--primary);"></i> Hotkeys:</span>
            <span><kbd class="kbd-badge">F2</kbd> Search</span>
            <span><kbd class="kbd-badge">↑↓←→</kbd> Grid</span>
            <span><kbd class="kbd-badge">Enter</kbd> Add</span>
            <span><kbd class="kbd-badge">+ / -</kbd> Qty</span>
            <span><kbd class="kbd-badge">F4</kbd> Pay</span>
            <span><kbd class="kbd-badge">F9</kbd> Fast Cash</span>
            <span style="margin-left: auto; cursor: pointer; color: var(--primary); font-weight: 600;" onclick="app.openShortcutsModal()" title="View full keyboard cheat sheet"><kbd class="kbd-badge">F1</kbd>Help</span>
          </div>

          <div class="pos-filter-bar">
            <div style="display: flex; gap: 0.5rem; flex: 1;">
              <div class="pos-search-input" style="flex: 1;">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" id="pos-search" class="form-control" placeholder="Search product name, SKU, or scan barcode... (F2 or ↓)" value="${this.escapeHtml(this.posSearchTerm || '')}">
              </div>
              <button type="button" class="btn btn-outline" id="btn-pos-camera-scan" onclick="app.openCameraScanner('pos')" title="Scan barcode with phone/webcam camera" style="display: flex; align-items: center; gap: 0.45rem; padding: 0.6rem 0.95rem; font-weight: 700; border-color: var(--slate-300); color: var(--slate-700); background: #ffffff; flex-shrink: 0;">
                <i class="fa-solid fa-camera" style="color: var(--primary); font-size: 1.05rem;"></i>
                <span class="pos-scan-btn-text">Scan</span>
              </button>
              <button type="button" class="btn btn-outline" id="btn-pos-wireless-scan" onclick="app.openWirelessScannerModal()" title="Pair phone as wireless cordless barcode scanner gun" style="display: flex; align-items: center; gap: 0.45rem; padding: 0.6rem 0.95rem; font-weight: 700; border-color: #c7d2fe; color: #4338ca; background: #f5f3ff; flex-shrink: 0; position: relative;">
                <i class="fa-solid fa-mobile-screen-button" style="color: #6366f1; font-size: 1.05rem;"></i>
                <span class="pos-companion-btn-text">Phone Scanner</span>
                <span class="wireless-bridge-dot" title="Wireless Bridge Ready"></span>
              </button>
            </div>
            <select id="pos-category-filter" class="form-control" style="width: 170px;">
              <option value="All">All Categories</option>
              ${this.categories.filter(c => !String(c).toLowerCase().includes('rental') && !String(c).toLowerCase().includes('hire')).map(c => `<option value="${this.escapeHtml(c)}" ${activeCategory === c ? 'selected' : ''}>${this.escapeHtml(c)}</option>`).join('')}
            </select>
          </div>

          <div class="pos-grid" id="pos-product-grid">
            ${filteredProducts.length > 0 ? filteredProducts.map(rawP => {
      const eff = this.getEffectiveProductForBranch(rawP);
      const prodType = String(rawP.product_type || 'standard').toLowerCase();
      const isService = prodType === 'service';
      const isCombo = prodType === 'combo';

      let inStock = Number(eff.effectiveStock || 0);
      if (isCombo && Array.isArray(rawP.combo_items) && rawP.combo_items.length > 0) {
        let maxBundles = Infinity;
        for (const ci of rawP.combo_items) {
          const compRaw = this.products.find(p => p.id === ci.component_product_id);
          const compStock = compRaw ? Number(this.getEffectiveProductForBranch(compRaw).effectiveStock || 0) : 0;
          const req = Number(ci.quantity || 1);
          const canMake = req > 0 ? Math.floor(compStock / req) : 0;
          if (canMake < maxBundles) maxBundles = canMake;
        }
        inStock = maxBundles === Infinity ? 0 : maxBundles;
      }

      const isOut = isService ? false : (inStock <= 0);
      const isLow = !isService && inStock > 0 && inStock <= Number(eff.min_stock_alert || 5);
      const hasPhoto = !!eff.image_url && eff.image_url.indexOf('placeholder.svg') === -1;
      const imgUrl = hasPhoto ? eff.image_url : 'assets/images/products/placeholder.svg';
      const thumbLetter = this.escapeHtml(String(eff.name || '?').trim().charAt(0).toUpperCase() || '?');

      // An expiry date four years out is not a checkout decision, but it occupied the
      // same space on every card as one that is weeks away. The chip earns its room only
      // once the batch is inside its own alert window.
      const expiryAt = (!isService && rawP.has_expiry == 1 && rawP.expiry_date)
        ? new Date(rawP.expiry_date + 'T00:00:00').getTime() : 0;
      const alertDays = Math.max(1, Number(rawP.alert_before_days || 30));
      const expiringSoon = !isService && expiryAt > 0 && expiryAt <= Date.now() + alertDays * 86400000;
      const isExpired = !isService && expiryAt > 0 && expiryAt < Date.now();

      const packUnits = isService ? [] : this.productUnitsOf(rawP).filter(u => !u.is_base);

      return `
                <div class="pos-product-card ${isOut ? 'out-of-stock' : ''} ${hasPhoto ? 'has-photo' : 'no-photo'}" data-product-id="${this.escapeHtml(eff.id)}" onclick="app.handleProductCardClick(${this.jsStr(eff.id)})">
                  ${isOut ? '<div class="out-of-stock-ribbon">Out of Stock</div>' : ''}
                  ${isService ? '<div class="pos-type-badge-service" style="position: absolute; top: 6px; right: 6px; background: #e0f2fe; color: #0369a1; border: 1px solid #bae6fd; font-size: 0.65rem; font-weight: 700; padding: 2px 6px; border-radius: 4px; z-index: 2;"><i class="fa-solid fa-bell-concierge"></i> Service</div>' : ''}
                  ${isCombo ? '<div class="pos-type-badge-combo" style="position: absolute; top: 6px; right: 6px; background: #f3e8ff; color: #6b21a8; border: 1px solid #e9d5ff; font-size: 0.65rem; font-weight: 700; padding: 2px 6px; border-radius: 4px; z-index: 2;"><i class="fa-solid fa-boxes-stacked"></i> Combo</div>' : ''}
                  
                  <div class="product-img-wrapper">
                    <span class="pos-thumb-letter" aria-hidden="true">${thumbLetter}</span>
                    <img src="${this.escapeHtml(imgUrl)}" alt="${this.escapeHtml(eff.name)}" loading="lazy" onerror="this.remove()">
                  </div>

                  <div class="pos-card-body">
                    <h4>${this.escapeHtml(eff.name)}</h4>
                    <div class="pos-card-meta">
                      <span class="sku-text">${this.escapeHtml(eff.sku || 'No SKU')} · ${this.escapeHtml(eff.unit || 'pcs')}</span>
                      ${isService ? `
                        <span class="pos-stock-note" style="color: #0369a1; background: #e0f2fe; border: 1px solid #bae6fd; font-weight: 700;">Unlimited</span>
                      ` : (isCombo ? `
                        <span class="pos-stock-note ${isOut ? 'out' : (isLow ? 'low' : '')}">${isOut ? 'Out' : `${inStock} bundles`}</span>
                      ` : `
                        <span class="pos-stock-note ${isOut ? 'out' : (isLow ? 'low' : '')}">${isOut ? 'Out' : `${inStock} left`}</span>
                      `)}
                      ${expiringSoon ? `
                        <span class="pos-expiry-chip ${isExpired ? 'expired' : ''}">
                          <i class="fa-solid fa-clock-rotate-left"></i> ${isExpired ? 'Expired' : `Exp: ${this.escapeHtml(rawP.expiry_date)}`}
                        </span>
                      ` : ''}
                    </div>
                    ${isCombo && Array.isArray(rawP.combo_items) && rawP.combo_items.length > 0 ? `
                      <div style="font-size: 0.69rem; color: #7c3aed; margin-top: 0.25rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${rawP.combo_items.map(ci => `${ci.quantity}x ${ci.component_name || 'Item'}`).join(', ')}">
                        <i class="fa-solid fa-layer-group"></i> ${rawP.combo_items.map(ci => `${ci.quantity}x ${ci.component_name || 'Item'}`).join(', ')}
                      </div>
                    ` : ''}
                  </div>

                  <div class="price-row">
                    <span class="price-tag">${this.formatCurrency(eff.effectivePrice)}</span>
                    ${packUnits.length > 0 ? `
                      <div class="pos-pack-chips">
                        ${packUnits.slice(0, 2).map(u => `
                          <span class="badge pos-pack-chip" style="background: #eef2ff; color: #4338ca; border: 1px solid #c7d2fe;" title="1 ${this.escapeHtml(u.unit_name)} = ${u.size_in_base} ${this.escapeHtml(eff.unit || 'pcs')}">
                            <i class="fa-solid fa-boxes-packing"></i> ${this.escapeHtml(u.unit_name)}: ${this.formatCurrency(this.productUnitPrice(u, eff.effectivePrice))}
                          </span>`).join('')}
                        ${packUnits.length > 2 ? `
                          <span class="badge pos-pack-chip" style="background: #eef2ff; color: #4338ca; border: 1px solid #c7d2fe;" title="${packUnits.slice(2).map(u => this.escapeHtml(u.unit_name)).join(', ')}">
                            +${packUnits.length - 2}
                          </span>` : ''}
                      </div>
                    ` : ''}
                  </div>
                </div>
              `;
    }).join('') : `
              <div style="grid-column: 1/-1; text-align: center; padding: 3rem; color: var(--slate-400);">
                <i class="fa-solid fa-box-open" style="font-size: 2.5rem; margin-bottom: 0.75rem; display: block;"></i>
                <p>No products match your search.</p>
              </div>
            `}
          </div>
        </div>

        <!-- Right: Cart & Checkout -->
        <div class="pos-cart-panel">
          <div class="cart-header">
            <div style="display: flex; align-items: center; gap: 0.5rem;">
              <button class="btn btn-outline btn-sm show-mobile-only" onclick="app.closePosCartModal()" style="padding: 0.25rem 0.55rem;" title="Close Cart Modal">
                <i class="fa-solid fa-arrow-left"></i>
              </button>
              <h3 style="font-size: 1.05rem; font-weight: 700; color: var(--slate-800); margin: 0;">
                <i class="fa-solid fa-cart-shopping"></i> Checkout Cart (${this.cart.reduce((c, i) => c + i.quantity, 0)})
              </h3>
            </div>
            <div style="display: flex; gap: 0.4rem; align-items: center;">
              <button class="btn btn-outline btn-sm" onclick="app.clearCart()" style="color: var(--danger); border-color: var(--danger-border);" title="Clear Cart (F7)">
                <i class="fa-solid fa-trash-can"></i> Clear <kbd class="kbd-badge hide-mobile" style="font-size: 0.65rem; margin-left: 2px;">F7</kbd>
              </button>
              <button class="btn btn-outline btn-sm show-mobile-only" onclick="app.closePosCartModal()" style="border: none; padding: 0.25rem 0.55rem; color: var(--slate-400);" title="Close">
                <i class="fa-solid fa-xmark" style="font-size: 1.1rem;"></i>
              </button>
            </div>
          </div>

          <!-- Customer Selection -->
          <div style="padding: 0.75rem 1.25rem; border-bottom: 1px solid var(--slate-200); background: #ffffff;">
            <label class="form-label" style="font-size: 0.75rem;">Customer (Buyer)</label>
            <div style="display: flex; gap: 0.5rem;">
              <select id="pos-customer-select" class="form-control" style="font-size: 0.85rem;">
                <option value="cust-walkin">Walk-in Customer</option>
                ${this.customers.filter(c => c.id !== 'cust-walkin').map(c => `
                  <option value="${this.escapeHtml(c.id)}" ${this.selectedCustomerId === c.id ? 'selected' : ''}>${this.escapeHtml(c.name)} (${this.escapeHtml(c.phone || 'No phone')})</option>
                `).join('')}
              </select>
              <button class="btn btn-outline btn-sm" onclick="app.openNewCustomerModal()" title="Add Customer">
                <i class="fa-solid fa-user-plus"></i>
              </button>
            </div>
            ${(() => {
              const selCust = this.customers.find(c => c.id === this.selectedCustomerId);
              return this.renderCartLoyaltyWidget ? this.renderCartLoyaltyWidget(selCust) : "";
            })()}
          </div>

          <!-- Cart Item List -->
          <div class="cart-items-list" id="pos-cart-items">
            ${this.cart.length > 0 ? this.cart.map((item, idx) => {
              const rawProd = this.products.find(p => p.id === item.product_id);
              const prodType = String(item.product_type || (rawProd && rawProd.product_type) || 'standard').toLowerCase();
              const isService = prodType === 'service';
              const isCombo = prodType === 'combo';
              const cartUnits = isService ? [] : this.productUnitsOf(rawProd);
              const multiplier = Number(item.multiplier || 1);
              const lineUnit = String(item.selected_unit || item.unit || '').toLowerCase();
              const comboItems = (item.combo_items && item.combo_items.length > 0) ? item.combo_items : (rawProd && rawProd.combo_items ? rawProd.combo_items : []);

              const lineDisc = Number(item.line_discount || 0);
              const rawLineSubtotal = Number(item.quantity || 0) * Number(item.selling_price || 0);
              const netLineSubtotal = Math.max(0, rawLineSubtotal - lineDisc);

              return `
              <div class="cart-item-row" style="flex-direction: column; align-items: stretch; gap: 0.35rem; padding: 0.55rem 0.65rem;">
                <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 0.5rem;">
                  <div class="cart-item-info" style="flex: 1;">
                    <div style="display: flex; align-items: center; gap: 0.35rem; flex-wrap: wrap;">
                      <h5 style="margin: 0; font-size: 0.88rem; font-weight: 700; color: var(--slate-800);">${this.escapeHtml(item.name)}</h5>
                      ${isService ? `<span class="badge" style="background:#e0f2fe; color:#0369a1; font-size:0.65rem; padding: 1px 5px; font-weight:700;"><i class="fa-solid fa-bell-concierge"></i> Service</span>` : ''}
                      ${isCombo ? `<span class="badge" style="background:#f3e8ff; color:#6b21a8; font-size:0.65rem; padding: 1px 5px; font-weight:700;"><i class="fa-solid fa-boxes-stacked"></i> Combo</span>` : ''}
                      ${cartUnits.length > 1 ? `
                        <div class="uom-toggle-pills" style="display: inline-flex; flex-wrap: wrap; border: 1px solid #cbd5e1; border-radius: 4px; overflow: hidden; font-size: 0.68rem; margin-left: 0.25rem;">
                          ${cartUnits.map((u, ui) => {
                            const isOn = u.unit_name.toLowerCase() === lineUnit;
                            return `
                            <button type="button" onclick="app.setCartItemUnit(${idx}, ${this.jsStr(u.unit_name)})" style="border: none;${ui > 0 ? ' border-left: 1px solid #cbd5e1;' : ''} padding: 0.15rem 0.4rem; cursor: pointer; font-weight: 600; background: ${isOn ? 'var(--primary)' : '#f1f5f9'}; color: ${isOn ? '#ffffff' : '#475569'};" title="1 ${this.escapeHtml(u.unit_name)} = ${u.size_in_base} ${this.escapeHtml(item.unit || 'pcs')}">${this.escapeHtml(u.unit_name)}${u.size_in_base > 1 ? ` (${u.size_in_base}x)` : ''}</button>`;
                          }).join('')}
                        </div>
                      ` : ''}
                    </div>
                    ${comboItems.length > 0 ? `
                      <div style="font-size: 0.72rem; color: #7c3aed; margin-top: 0.2rem; display: flex; align-items: center; gap: 0.25rem; flex-wrap: wrap;">
                        <i class="fa-solid fa-layer-group"></i> <strong>Includes:</strong> ${comboItems.map(ci => `${ci.quantity}x ${ci.component_name || 'Item'}`).join(', ')}
                      </div>
                    ` : ''}
                    <div style="font-size: 0.76rem; color: var(--slate-500); margin-top: 0.15rem;">
                      <span>${this.formatCurrency(item.selling_price)} / ${this.escapeHtml(item.selected_unit || item.unit || 'pcs')}</span>
                      ${multiplier > 1 ? `
                        <span style="color: #6366f1; font-weight: 600;"> &bull; = ${item.quantity * multiplier} ${this.escapeHtml(item.unit || 'pcs')}</span>
                      ` : ''}
                    </div>
                  </div>

                  <div class="cart-item-qty" style="align-items: center; gap: 0.25rem;">
                    <button class="btn-qty" onclick="app.updateCartQty(${idx}, -1)"><i class="fa-solid fa-minus"></i></button>
                    <input type="number" class="cart-qty-input" value="${item.quantity}" min="1" step="1" inputmode="numeric"
                           aria-label="Quantity of ${this.escapeHtml(item.name)}"
                           onchange="app.setCartQty(${idx}, this.value)"
                           onkeydown="if (event.key === 'Enter') { this.blur(); }"
                           style="width: 46px; text-align: center; font-weight: 700; font-size: 0.88rem; padding: 0.1rem 0.15rem; border: 1px solid var(--slate-300); border-radius: 4px; background: #fff;">
                    <button class="btn-qty" onclick="app.updateCartQty(${idx}, 1)"><i class="fa-solid fa-plus"></i></button>
                    <button class="btn-qty" onclick="app.removeFromCart(${idx})" style="color: var(--danger); margin-left: 0.25rem;"><i class="fa-solid fa-xmark"></i></button>
                  </div>
                </div>

                <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px dashed var(--slate-200); padding-top: 0.25rem; font-size: 0.80rem;">
                  <div style="display: flex; align-items: center; gap: 0.35rem; flex-wrap: wrap;">
                    ${(this.getOperatingMode && (this.getOperatingMode() === 'HOSPITALITY' || this.getOperatingMode() === 'HYBRID')) ? `
                      <button type="button" class="btn btn-sm" onclick="app.editCartItemSeat(${idx})" style="padding: 0.1rem 0.45rem; font-size: 0.72rem; border-radius: 4px; background: ${(item.seat_number && item.seat_number !== 'Shared') ? '#e0f2fe' : '#f1f5f9'}; color: ${(item.seat_number && item.seat_number !== 'Shared') ? '#0369a1' : '#64748b'}; border: 1px solid ${(item.seat_number && item.seat_number !== 'Shared') ? '#bae6fd' : '#e2e8f0'}; font-weight: 700;" title="Assign to specific seat or guest">
                        <i class="fa-solid fa-chair"></i> ${this.escapeHtml(item.seat_number || 'Shared')}
                      </button>
                      <button type="button" class="btn btn-sm" onclick="app.editCartItemNote(${idx})" style="padding: 0.1rem 0.4rem; font-size: 0.72rem; border-radius: 4px; background: ${item.prep_notes ? '#fef3c7' : '#f1f5f9'}; color: ${item.prep_notes ? '#b45309' : '#64748b'}; border: 1px solid ${item.prep_notes ? '#fcd34d' : '#e2e8f0'};" title="Add special kitchen preparation note">
                        <i class="fa-solid fa-pen-to-square"></i> ${item.prep_notes ? this.escapeHtml(item.prep_notes) : 'Kitchen Note'}
                      </button>
                    ` : ''}
                    ${this.storeProfile?.enable_line_discounts == 1 ? `
                      <button type="button" class="btn btn-sm" onclick="app.openCartItemDiscountModal(${idx})" style="padding: 0.1rem 0.45rem; font-size: 0.72rem; border-radius: 4px; background: ${lineDisc > 0 ? '#fef2f2' : '#f8fafc'}; color: ${lineDisc > 0 ? '#b91c1c' : '#475569'}; border: 1px solid ${lineDisc > 0 ? '#fca5a5' : '#cbd5e1'}; font-weight: 700;" title="Apply item line discount">
                        <i class="fa-solid fa-tag"></i> ${lineDisc > 0 ? `-${this.formatCurrency(lineDisc)}` : 'Disc'}
                      </button>
                    ` : ''}
                    <span style="color: var(--slate-500); font-size: 0.75rem;">Line Total:</span>
                  </div>
                  <div style="text-align: right;">
                    ${lineDisc > 0 ? `<span style="font-size: 0.72rem; text-decoration: line-through; color: var(--slate-400); margin-right: 4px;">${this.formatCurrency(rawLineSubtotal)}</span>` : ''}
                    <span style="font-weight: 700; color: ${lineDisc > 0 ? '#b91c1c' : 'var(--slate-800)'};">${this.formatCurrency(netLineSubtotal)}</span>
                  </div>
                </div>
              </div>
            `;
            }).join('') : `
              <div style="text-align: center; padding: 3rem 1rem; color: var(--slate-400);">
                <i class="fa-solid fa-cart-arrow-down" style="font-size: 2rem; margin-bottom: 0.5rem; display: block;"></i>
                <p style="font-size: 0.9rem;">Cart is empty.</p>
                <span style="font-size: 0.75rem;">Click any product on the left to add.</span>
              </div>
            `}
          </div>

          <!-- Cart Footer & Totals -->
          <div class="cart-footer">
            <div class="cart-summary-line">
              <span>Subtotal</span>
              <span>${this.formatCurrency(subtotal)}</span>
            </div>
            <div class="cart-summary-line">
              <span>Discount ${totalLineDiscounts > 0 ? `<small style="font-size:0.7rem; color:var(--slate-500);">(Cart + Lines: -${this.formatCurrency(totalLineDiscounts)})</small>` : ''}</span>
              <input type="number" id="pos-cart-discount" style="width: 70px; text-align: right; padding: 0.2rem; font-size: 0.8rem;" value="${this.cartDiscount || 0}" min="0" step="any">
            </div>
            ${(loyaltyValue + tierValue) > 0 ? `
              ${tierValue > 0 ? `
                <div class="cart-summary-line" style="color: #7c3aed; font-size: 0.82rem;">
                  <span>Tier perk</span>
                  <span>-${this.formatCurrency(tierValue)}</span>
                </div>
              ` : ''}
              ${loyaltyValue > 0 ? `
                <div class="cart-summary-line" style="color: #7c3aed; font-size: 0.82rem;">
                  <span>Points offered (${this.redeemedLoyaltyPoints || 0})</span>
                  <span>-${this.formatCurrency(loyaltyValue)}</span>
                </div>
              ` : ''}
            ` : ''}
            ${taxRate > 0 ? `
              <div class="cart-summary-line" style="color: #64748b; font-size: 0.82rem;">
                <span>Tax / VAT (${taxRate}%)</span>
                <span>+${this.formatCurrency(tax)}</span>
              </div>
            ` : ''}
            <div class="cart-summary-line total">
              <span>Total Payable</span>
              <span>${this.formatCurrency(total)}</span>
            </div>

            <div style="display: flex; gap: 0.5rem; margin-top: 0.85rem;">
              ${(this.getOperatingMode && (this.getOperatingMode() === "HOSPITALITY" || this.getOperatingMode() === "HYBRID")) ? `
                <button type="button" class="btn btn-lg" onclick="app.sendCartToKitchen()" style="background: #059669; color: #ffffff; border: none; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 0.4rem; padding: 0.6rem 0.9rem;" ${this.cart.length === 0 ? "disabled" : ""} title="Send items to kitchen cooks">
                  <i class="fa-solid fa-fire-burner"></i> Send KOT
                </button>
                <button type="button" class="btn btn-outline btn-lg" onclick="app.openSplitBillModal()" style="border-color: #0284c7; color: #0284c7; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 0.35rem; padding: 0.6rem 0.85rem;" ${this.cart.length === 0 ? "disabled" : ""} title="Split bill by seat or diner">
                  <i class="fa-solid fa-scissors"></i> Split
                </button>
              ` : ""}
              <button class="btn btn-success btn-lg" onclick="app.openCheckoutModal()" style="flex: 1; display: flex; align-items: center; justify-content: center; gap: 0.4rem;" ${this.cart.length === 0 ? 'disabled' : ''}>
                <i class="fa-solid fa-cash-register"></i> Pay <kbd class="kbd-badge hide-mobile" style="background: rgba(255,255,255,0.25); color: #fff; border-color: rgba(255,255,255,0.4); margin-left: 3px;">F4</kbd>
              </button>
              <button class="btn btn-outline btn-lg" onclick="app.fastCashCheckout()" style="background: #ffffff; border-color: var(--emerald-500); color: var(--emerald-600); font-weight: 700; white-space: nowrap; display: flex; align-items: center; gap: 0.35rem;" ${this.cart.length === 0 ? 'disabled' : ''} title="Instant Exact Cash Checkout (F9)">
                <i class="fa-solid fa-bolt"></i> Fast Cash <kbd class="kbd-badge hide-mobile" style="font-size: 0.7rem;">F9</kbd>
              </button>
            </div>

            <div style="display: flex; gap: 0.4rem; margin-top: 0.45rem;">
              <button type="button" class="btn btn-outline btn-sm" onclick="app.saveCartAsEstimate()" style="flex: 1; display: flex; align-items: center; justify-content: center; gap: 0.35rem; font-weight: 700; color: #0284c7; border-color: #bae6fd; background: #f0f9ff; padding: 0.4rem 0.5rem; font-size: 0.78rem;" ${this.cart.length === 0 ? 'disabled' : ''} title="Create Price Quotation / Proforma Invoice (Does not deduct stock)">
                <i class="fa-solid fa-file-invoice"></i> Proforma / Estimate
              </button>
              <button type="button" class="btn btn-outline btn-sm" onclick="app.openEstimatesModal()" style="display: flex; align-items: center; gap: 0.3rem; font-weight: 600; color: var(--slate-700); border-color: var(--slate-300); padding: 0.4rem 0.65rem; font-size: 0.78rem;" title="View & Load Saved Quotations">
                <i class="fa-solid fa-clock-rotate-left"></i> Quotations
              </button>
            </div>
          </div>
        </div>

        <div class="mobile-cart-float show-mobile-flex" id="pos-floating-cart-pill" onclick="app.openPosCartModal()" style="${this.cart.length > 0 ? '' : 'background: #334155; opacity: 0.9;'}">
          <div style="display: flex; align-items: center; gap: 0.6rem;">
            <span class="badge ${this.cart.length > 0 ? 'badge-success' : 'badge-secondary'}" style="padding: 0.2rem 0.55rem; font-size: 0.8rem;">
              <i class="fa-solid fa-cart-shopping"></i> ${this.cart.reduce((s, i) => s + i.quantity, 0)}
            </span>
            <span style="font-weight: 700; font-size: 0.95rem;">${this.formatCurrency(total)}</span>
          </div>
          <span style="font-weight: 600; font-size: 0.82rem; display: flex; align-items: center; gap: 0.35rem;">
            ${this.cart.length > 0 ? 'View Cart & Pay <i class="fa-solid fa-chevron-up"></i>' : 'Open Cart <i class="fa-solid fa-chevron-up"></i>'}
          </span>
        </div>
      </div>
    `;
  },

  bindPosEvents() {
    this.setupPosCartScrollObserver();
    const searchInput = document.getElementById('pos-search');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        this.posSearchTerm = e.target.value;
        this.renderCurrentView();
        const freshInput = document.getElementById('pos-search');
        if (freshInput) {
          freshInput.focus();
          freshInput.setSelectionRange(freshInput.value.length, freshInput.value.length);
        }
      });

      searchInput.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowDown') {
          e.preventDefault();
          searchInput.blur();
          this.navigatePosGrid('down');
          return;
        }
        if (e.key === 'Enter') {
          e.preventDefault();
          const val = (searchInput.value || '').trim();
          if (val) {
            this.handleBarcodeScan(val);
            searchInput.value = '';
            this.posSearchTerm = '';
            this.renderCurrentView();
          }
        }
      });
    }

    const catSelect = document.getElementById('pos-category-filter');
    if (catSelect) {
      catSelect.addEventListener('change', (e) => {
        this.posSelectedCategory = e.target.value;
        this.renderCurrentView();
      });
    }

    const custSelect = document.getElementById('pos-customer-select');
    if (custSelect) {
      custSelect.addEventListener('change', (e) => {
        this.selectedCustomerId = e.target.value;
      });
    }

    const discountInput = document.getElementById('pos-cart-discount');
    if (discountInput) {
      discountInput.addEventListener('input', (e) => {
        this.cartDiscount = Number(e.target.value) || 0;
        this.renderCurrentView();
      });
    }
  },

  handleProductCardClick(productId, unitLabel = null) {
    const rawProduct = this.products.find(p => p.id === productId);
    if (!rawProduct) return;
    if (this.isRentalProduct(rawProduct)) {
      this.showToast(`"${rawProduct.name}" is equipment for hire and not for retail sale. Dispatch it from Rentals & Hire.`, 'warning');
      return;
    }
    const product = this.getEffectiveProductForBranch(rawProduct);

    if (!product.isAvailable) {
      this.showToast(`"${product.name}" is not enabled for sales at branch ${this.branchCode || 'MAIN-01'}.`, 'warning');
      return;
    }

    const prodType = (rawProduct.product_type || 'standard').toLowerCase();

    // Service items: non-inventory / labor, bypass stock verification
    if (prodType === 'service') {
      this.addToCart(productId, unitLabel);
      return;
    }

    // Combo items: verify constituent items' availability
    if (prodType === 'combo' && Array.isArray(rawProduct.combo_items) && rawProduct.combo_items.length > 0) {
      let missing = null;
      let maxBundles = Infinity;
      for (const ci of rawProduct.combo_items) {
        const compRaw = this.products.find(p => p.id === ci.component_product_id);
        const compEff = compRaw ? this.getEffectiveProductForBranch(compRaw) : null;
        const compStock = compEff ? Number(compEff.effectiveStock || 0) : 0;
        const req = Number(ci.quantity || 1);
        const canMake = req > 0 ? Math.floor(compStock / req) : 0;
        if (canMake < 1 && !missing) {
          missing = { name: ci.component_name || (compRaw ? compRaw.name : 'Ingredient'), stock: compStock, req };
        }
        if (canMake < maxBundles) maxBundles = canMake;
      }
      if (maxBundles < 1) {
        if (this.storeProfile.allow_negative_stock == 1) {
          this.addToCart(productId, unitLabel);
          this.showToast(`Warning: Combo "${product.name}" ingredient (${missing ? missing.name : 'item'}) is out of stock. Stock is now negative.`, 'warning');
        } else {
          this.showToast(`Cannot add combo: Ingredient "${missing ? missing.name : 'Item'}" is out of stock (${missing ? missing.stock : 0} left, need ${missing ? missing.req : 1}).`, 'warning');
        }
        return;
      }
    }

    const inStock = Number(product.effectiveStock || 0);
    const unit = this.productUnitOf(product, unitLabel);
    const multiplier = Number((unit && unit.size_in_base) || 1);

    // If out of stock
    if (inStock <= 0) {
      // Check if store allows negative stock sales
      if (this.storeProfile.allow_negative_stock == 1) {
        this.addToCart(productId, unitLabel);
        this.showToast(`Warning: "${product.name}" is out of stock. Stock is now negative.`, 'warning');
      } else {
        // Open Out-of-Stock dialog
        this.openOutOfStockModal(product, unitLabel);
      }
      return;
    }

    // Check if adding exceeds stock. The shelf is counted in loose units and every cart
    // line is counted in its own size, so the two are only comparable after each line is
    // converted: one crate on a 30-egg shelf is full, and the egg line already in the
    // tray has to be counted with it rather than ignored.
    const room = this.cartRoomInBase(product);
    if (multiplier > room.room) {
      if (this.storeProfile.allow_negative_stock == 1) {
        this.addToCart(productId, unitLabel);
      } else {
        this.showToast(`Cannot add more: Only ${room.room} ${product.unit || 'pcs'} available at ${this.branchCode || 'this branch'}.`, 'warning');
      }
      return;
    }

    this.addToCart(productId, unitLabel);
  },

  openPosCartModal() {
    const cartPanel = document.querySelector('.pos-cart-panel');
    if (!cartPanel) return;

    let overlay = document.getElementById('pos-cart-modal-overlay');
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = 'pos-cart-modal-overlay';
      overlay.className = 'pos-cart-backdrop';
      overlay.onclick = () => this.closePosCartModal();
      document.body.appendChild(overlay);
    }
    overlay.classList.add('active');
    cartPanel.classList.add('pos-cart-modal-open');
    document.body.classList.add('pos-cart-locked');
  },

  closePosCartModal() {
    const cartPanel = document.querySelector('.pos-cart-panel');
    if (cartPanel) {
      cartPanel.classList.remove('pos-cart-modal-open');
    }
    const overlay = document.getElementById('pos-cart-modal-overlay');
    if (overlay) {
      overlay.classList.remove('active');
    }
    document.body.classList.remove('pos-cart-locked');
  },

  addToCart(productId, selectedUnit = null) {
    const rawProduct = this.products.find(p => p.id === productId);
    if (!rawProduct) return;
    if (this.isRentalProduct(rawProduct)) {
      this.showToast(`"${rawProduct.name}" is equipment for hire and not for retail sale. Dispatch it from Rentals & Hire.`, 'warning');
      return;
    }
    const product = this.getEffectiveProductForBranch(rawProduct);

    const baseUnit = this.productUnitOf(product, null);
    const unit = this.productUnitOf(product, selectedUnit);
    if (!unit) return;

    const basePrice = Number(product.effectivePrice || product.selling_price || 0);
    const sellingPrice = this.productUnitPrice(unit, basePrice);

    const targetSeat = this.activeSeat || 'Shared';
    const existingIndex = this.cart.findIndex(i => i.product_id === productId
      && String(i.selected_unit || i.unit || '').toLowerCase() === unit.unit_name.toLowerCase()
      && String(i.seat_number || 'Shared') === targetSeat);
    if (existingIndex >= 0) {
      this.cart[existingIndex].quantity += 1;
    } else {
      this.cart.push({
        product_id: product.id,
        name: product.name,
        product_type: rawProduct.product_type || 'standard',
        combo_items: rawProduct.combo_items || [],
        unit_cost_price: Number(product.cost_price || 0),
        base_selling_price: basePrice,
        selling_price: sellingPrice,
        unit: (baseUnit && baseUnit.unit_name) || product.unit || 'pcs',
        selected_unit: unit.unit_name,
        multiplier: Number(unit.size_in_base || 1),
        quantity: 1,
        seat_number: targetSeat,
        prep_notes: '',
        branch_code: this.branchCode || 'MAIN-01'
      });
    }
    this.renderCurrentView();
  },

  setCartQty(index, rawValue, isStep = false) {
    const item = this.cart[index];
    if (!item) return;

    if (rawValue === '' || rawValue === null || rawValue === undefined) return;
    const typed = Number(rawValue);
    if (!Number.isFinite(typed)) return;
    const newQty = Math.floor(typed);
    if (newQty <= 0) {
      this.cart.splice(index, 1);
      this.renderCurrentView();
      return;
    }
    if (newQty === Number(item.quantity || 0)) {
      this.renderCurrentView();
      return;
    }

    const rawProd = this.products.find(p => p.id === item.product_id);
    const pType = String((rawProd && rawProd.product_type) || item.product_type || 'standard').toLowerCase();
    if (rawProd && pType !== 'service' && pType !== 'combo' && newQty > Number(item.quantity || 0)) {
      const prod = this.getEffectiveProductForBranch(rawProd);
      const multiplier = Number(item.multiplier || 1);
      const room = this.cartRoomInBase(prod, index);
      const wanted = newQty * multiplier;
      if (wanted > room.room && this.storeProfile.allow_negative_stock != 1) {
        this.showToast(isStep
          ? `Maximum available stock reached (${room.room} ${prod.unit || 'pcs'} left at ${this.branchCode || 'this branch'}).`
          : `Cannot put ${newQty} ${item.selected_unit || item.unit} of ${item.name} in the cart: that is ${wanted} ${prod.unit || 'pcs'} and ${room.room} are left on the shelf.`,
          'warning');
        this.renderCurrentView();
        return;
      }
    }

    item.quantity = newQty;
    if (item.discount_percent) {
      const rawLineTotal = Number(item.quantity || 1) * Number(item.selling_price || 0);
      item.line_discount = Math.round(((rawLineTotal * item.discount_percent) / 100) * 100) / 100;
    }
    this.renderCurrentView();
  },

  setCartItemDiscount(index, val) {
    const item = this.cart[index];
    if (!item) return;
    const rawLineTotal = Number(item.quantity || 1) * Number(item.selling_price || 0);
    val = String(val || '').trim();
    if (val === '' || val === '0') {
      delete item.line_discount;
      delete item.discount_input;
      delete item.discount_percent;
    } else if (val.endsWith('%')) {
      const pct = Math.max(0, Math.min(100, parseFloat(val) || 0));
      item.discount_percent = pct;
      item.line_discount = Math.round(((rawLineTotal * pct) / 100) * 100) / 100;
      item.discount_input = `${pct}%`;
    } else {
      const amt = Math.max(0, Math.min(rawLineTotal, parseFloat(val) || 0));
      delete item.discount_percent;
      item.line_discount = Math.round(amt * 100) / 100;
      item.discount_input = amt > 0 ? amt.toFixed(2) : '';
    }
    this.renderCurrentView();
  },

  async openCartItemDiscountModal(index) {
    const item = this.cart[index];
    if (!item) return;
    const rawLineTotal = Number(item.quantity || 1) * Number(item.selling_price || 0);
    const curVal = item.discount_input || (item.line_discount ? item.line_discount.toFixed(2) : '');

    let entered = null;
    if (typeof this.showPromptModal === 'function') {
      entered = await this.showPromptModal({
        title: `Item Line Discount: ${item.name}`,
        desc: `Line total is ${this.formatCurrency(rawLineTotal)} (${item.quantity}x @ ${this.formatCurrency(item.selling_price)}). Enter discount percentage or cash amount:`,
        defaultValue: curVal,
        placeholder: 'e.g. 5 or 10%',
        label: 'Discount Value (Amount or %)',
        hint: 'Enter percentage e.g. 10% or fixed deduction e.g. 5. Enter 0 to remove discount.',
        icon: 'fa-tag',
        confirmText: 'Apply Discount'
      });
    } else {
      entered = prompt(`Discount for "${item.name}" (Total ${this.formatCurrency(rawLineTotal)}). Enter amount (e.g. 5) or percentage (e.g. 10%):`, curVal);
    }

    if (entered !== null) {
      this.setCartItemDiscount(index, entered);
      const disc = Number(item.line_discount || 0);
      if (disc > 0) {
        this.showToast(`Applied ${this.formatCurrency(disc)} discount to ${item.name}`, 'info');
      } else {
        this.showToast(`Cleared line discount on ${item.name}`, 'info');
      }
    }
  }
});
