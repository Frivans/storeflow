// assets/js/app-enterprise.js
// StoreFlow Commercial Enterprise Suite:
// 1. Business Operating Mode Toggler (Retail vs Hospitality vs Hybrid)
// 2. POS Deep Table & Multi-Seat Integration & KOT Firing
// 3. Dynamic Dining Spaces, Unlimited Tables & Live Capacity Adjuster
// 4. Per-Seat Ordering & Split Bill Settle Workflows
// 5. High-Contrast Kitchen Display System (KDS) Chef Screen
// 6. In-Cart Interactive Customer Loyalty Rewards
// 7. Omnichannel E-Commerce Bridge Dashboard

(function(window) {
  'use strict';

  const enterpriseExt = {
    activeTable: null,
    activeSeat: 'Shared',
    activeCheckoutSeat: null,
    selectedFloorZone: 'ALL',
    kdsRefreshTimer: null,
    redeemedLoyaltyPoints: 0,
    _floorTables: [],
    _kdsLines: {},
    _originalCart: null,

    escapeHtml(str) {
      if (str === null || str === undefined) return '';
      return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
    },

    floorOfflineNote(data, consequence) {
      return (data && data.offline === true)
        ? `The server is not reachable, so ${consequence || 'that order could not be placed.'}`
        : null;
    },

    // =========================================================================
    // 1. BUSINESS OPERATING MODE TOGGLER (SETTINGS & UI ADAPTATION)
    // =========================================================================
    getOperatingMode() {
      return (window.app?.storeProfile?.operating_mode || localStorage.getItem('storeflow_operating_mode') || 'RETAIL').toUpperCase();
    },

    async setOperatingMode(mode) {
      mode = mode.toUpperCase();
      if (!['RETAIL', 'HOSPITALITY', 'HYBRID'].includes(mode)) mode = 'RETAIL';

      localStorage.setItem('storeflow_operating_mode', mode);
      if (window.app.storeProfile) {
        window.app.storeProfile.operating_mode = mode;
      }

      this.applyOperatingModeUI(mode);

      // Save to server
      try {
        await fetch('api/endpoints/profile.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'set_mode', operating_mode: mode })
        });
      } catch (e) {
        console.warn('Mode save deferred:', e);
      }

      const modeNames = {
        'RETAIL': '🛒 Retail & Wholesale Mode',
        'HOSPITALITY': '🍽️ Restaurant, Cafe & Dining Mode',
        'HYBRID': '🌐 Hybrid Omnichannel Mode'
      };

      if (window.app.showToast) {
        window.app.showToast(`Switched to ${modeNames[mode]}! Interface adapted.`, 'success');
      }

      // Re-render current view if on profile or pos
      if (window.app.currentView === 'profile' || window.app.currentView === 'pos') {
        window.app.renderCurrentView();
      }
    },

    applyOperatingModeUI(mode) {
      mode = mode || this.getOperatingMode();
      const navHosp = document.getElementById('nav-hospitality');
      const navEcom = document.getElementById('nav-ecommerce');
      const navRentals = document.getElementById('nav-rentals');

      if (navHosp) {
        navHosp.style.display = (mode === 'RETAIL') ? 'none' : 'flex';
      }

      if (navEcom) {
        navEcom.style.display = (mode === 'HOSPITALITY') ? 'none' : 'flex';
      }

      const isRentalsEnabled = (window.app?.storeProfile?.enable_rentals !== 0 && localStorage.getItem('storeflow_enable_rentals') !== '0');
      if (navRentals) {
        navRentals.style.display = isRentalsEnabled ? 'flex' : 'none';
      }
    },

    async toggleRentalsModule(enable) {
      const flag = enable ? 1 : 0;
      localStorage.setItem('storeflow_enable_rentals', String(flag));
      if (window.app && window.app.storeProfile) {
        window.app.storeProfile.enable_rentals = flag;
      }
      this.applyOperatingModeUI();
      try {
        await fetch('api/endpoints/profile.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'toggle_rentals', enable_rentals: flag })
        });
      } catch (e) {
        console.warn('Rentals toggle save deferred:', e);
      }
      if (window.app && window.app.showToast) {
        window.app.showToast(enable ? 'Rentals & Equipment Hire module enabled!' : 'Rentals & Hire module disabled. Sidebar updated.', 'info');
      }
      if (window.app && window.app.currentView === 'profile') {
        window.app.renderCurrentView();
      }
    },

    toggleRentalsAction() {
      const isEnabled = (window.app?.storeProfile?.enable_rentals !== 0 && localStorage.getItem('storeflow_enable_rentals') !== '0');
      this.toggleRentalsModule(!isEnabled);
    },

    getOperatingModeSelectorHTML() {
      const currentMode = this.getOperatingMode();
      const isRentalsEnabled = (window.app?.storeProfile?.enable_rentals !== 0 && localStorage.getItem('storeflow_enable_rentals') !== '0');

      return `
        <div style="background: #ffffff; border: 1.5px solid var(--slate-200); border-radius: var(--radius-md); padding: 1.25rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.03);">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 1rem; flex-wrap: wrap; gap: 0.5rem;">
            <div style="display: flex; align-items: center; gap: 0.75rem;">
              <div style="width: 40px; height: 40px; border-radius: 10px; background: #4f46e5; color: #ffffff; display: flex; align-items: center; justify-content: center; font-size: 1.2rem;">
                <i class="fa-solid fa-sliders"></i>
              </div>
              <div>
                <h4 style="margin: 0; font-size: 1rem; font-weight: 700; color: var(--slate-900);">Business Purpose & Operating Mode</h4>
                <p style="margin: 0; font-size: 0.78rem; color: var(--slate-500);">Adapt StoreFlow interface, POS workflow, and features to your trade</p>
              </div>
            </div>
            <span class="badge badge-info" style="font-size: 0.75rem; text-transform: uppercase; font-weight: 700;">
              Active: ${currentMode}
            </span>
          </div>

          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 0.85rem;">
            <!-- Option 1: Retail & Wholesale -->
            <div onclick="app.setOperatingMode('RETAIL')" style="cursor: pointer; border: 2px solid ${currentMode === 'RETAIL' ? '#4f46e5' : 'var(--slate-200)'}; background: ${currentMode === 'RETAIL' ? '#f5f3ff' : '#ffffff'}; border-radius: 10px; padding: 1rem; transition: all 0.15s ease;">
              <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.5rem;">
                <span style="font-weight: 700; font-size: 0.95rem; color: ${currentMode === 'RETAIL' ? '#4338ca' : 'var(--slate-800)'};">
                  <i class="fa-solid fa-cart-shopping"></i> Retail & Wholesale
                </span>
                ${currentMode === 'RETAIL' ? '<i class="fa-solid fa-circle-check" style="color: #4f46e5; font-size: 1.1rem;"></i>' : '<i class="fa-regular fa-circle" style="color: var(--slate-400);"></i>'}
              </div>
              <p style="margin: 0; font-size: 0.76rem; color: var(--slate-600); line-height: 1.4;">
                Optimized for Supermarkets, Groceries, Boutiques, Pharmacies & Wholesale. Focuses on speed-scan barcode checkout, bulk packs, and stock ledger.
              </p>
            </div>

            <!-- Option 2: Hospitality & Restaurant -->
            <div onclick="app.setOperatingMode('HOSPITALITY')" style="cursor: pointer; border: 2px solid ${currentMode === 'HOSPITALITY' ? '#059669' : 'var(--slate-200)'}; background: ${currentMode === 'HOSPITALITY' ? '#ecfdf5' : '#ffffff'}; border-radius: 10px; padding: 1rem; transition: all 0.15s ease;">
              <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.5rem;">
                <span style="font-weight: 700; font-size: 0.95rem; color: ${currentMode === 'HOSPITALITY' ? '#065f46' : 'var(--slate-800)'};">
                  <i class="fa-solid fa-utensils"></i> Restaurant, Cafe & Eatery
                </span>
                ${currentMode === 'HOSPITALITY' ? '<i class="fa-solid fa-circle-check" style="color: #059669; font-size: 1.1rem;"></i>' : '<i class="fa-regular fa-circle" style="color: var(--slate-400);"></i>'}
              </div>
              <p style="margin: 0; font-size: 0.76rem; color: var(--slate-600); line-height: 1.4;">
                Tables, bar counters and private rooms, each holding its own tab. Bill one seat at a time, and every round goes out to the kitchen as a ticket.
              </p>
            </div>

            <!-- Option 3: Hybrid Omnichannel -->
            <div onclick="app.setOperatingMode('HYBRID')" style="cursor: pointer; border: 2px solid ${currentMode === 'HYBRID' ? '#0284c7' : 'var(--slate-200)'}; background: ${currentMode === 'HYBRID' ? '#f0f9ff' : '#ffffff'}; border-radius: 10px; padding: 1rem; transition: all 0.15s ease;">
              <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.5rem;">
                <span style="font-weight: 700; font-size: 0.95rem; color: ${currentMode === 'HYBRID' ? '#0369a1' : 'var(--slate-800)'};">
                  <i class="fa-solid fa-arrows-split-up-and-left"></i> Hybrid Omnichannel
                </span>
                ${currentMode === 'HYBRID' ? '<i class="fa-solid fa-circle-check" style="color: #0284c7; font-size: 1.1rem;"></i>' : '<i class="fa-regular fa-circle" style="color: var(--slate-400);"></i>'}
              </div>
              <p style="margin: 0; font-size: 0.76rem; color: var(--slate-600); line-height: 1.4;">
                Combines Retail barcode scanning, Dining floor spaces & table seating, plus physical store synchronization with WooCommerce & Shopify webhooks.
              </p>
            </div>
          </div>

          <!-- Specialized Business Modules Toggles -->
          <div style="margin-top: 1.15rem; padding-top: 1rem; border-top: 1px solid var(--slate-200);">
            <div style="font-size: 0.78rem; font-weight: 700; color: var(--slate-600); text-transform: uppercase; margin-bottom: 0.65rem; letter-spacing: 0.5px;">
              Specialized Business Add-On Modules
            </div>
            <div>
              <!-- Rentals Module Toggle -->
              <div style="display: flex; align-items: center; justify-content: space-between; background: ${isRentalsEnabled ? '#faf5ff' : '#f8fafc'}; border: 1.5px solid ${isRentalsEnabled ? '#d8b4fe' : 'var(--slate-200)'}; border-radius: 8px; padding: 0.75rem 1rem;">
                <div style="display: flex; align-items: center; gap: 0.65rem;">
                  <div style="width: 34px; height: 34px; border-radius: 8px; background: ${isRentalsEnabled ? '#7c3aed' : '#94a3b8'}; color: #ffffff; display: flex; align-items: center; justify-content: center; font-size: 1rem;">
                    <i class="fa-solid fa-boxes-packing"></i>
                  </div>
                  <div>
                    <div style="font-weight: 700; font-size: 0.88rem; color: ${isRentalsEnabled ? '#581c87' : 'var(--slate-700)'};">Rentals & Equipment Hire</div>
                    <div style="font-size: 0.72rem; color: var(--slate-500);">Canopies, chairs, sound systems, caution security deposits & gate passes</div>
                  </div>
                </div>
                <button type="button" class="btn btn-sm ${isRentalsEnabled ? 'btn-primary' : 'btn-outline'}" onclick="app.toggleRentalsAction()" style="font-weight: 700; font-size: 0.75rem; padding: 0.25rem 0.65rem; ${isRentalsEnabled ? 'background: #7c3aed; border-color: #6d28d9;' : ''}">
                  ${isRentalsEnabled ? '<i class=\"fa-solid fa-check\"></i> Enabled' : 'Disabled'}
                </button>
              </div>
            </div>
          </div>
        </div>
      `;
    },

    // =========================================================================
    // 2. POS TABLE INTEGRATION, MULTI-SEAT ORDERING & KOT FIRING
    // =========================================================================
    async selectTableForPOS(tableId, tableNumber, zoneName, activeOrderId, guestCount, capacity, selectedSeat) {
      if (activeOrderId && window.app.cart && window.app.cart.length > 0
          && (!this.activeTable || this.activeTable.orderId !== activeOrderId)) {
        let replace = false;
        if (typeof window.app.showConfirmModal === 'function') {
          replace = await window.app.showConfirmModal({
            title: 'Load Table Tab?',
            message: `${tableNumber} has an active tab with fired dishes. Load that tab into the register and replace the current basket?`,
            icon: 'fa-utensils',
            confirmText: 'Load Tab',
            confirmBtnClass: 'btn-primary'
          });
        } else {
          replace = confirm(`${tableNumber} has a tab. Replace the current cart lines with this tab?`);
        }
        if (!replace) return;
      }

      this.activeTable = {
        id: tableId,
        number: tableNumber,
        zone: zoneName || 'Main Dining',
        orderId: activeOrderId || null,
        guests: guestCount || 1,
        capacity: Number(capacity) || 0,
        tabSubtotal: 0,
        ticketCount: 1
      };

      this.activeSeat = selectedSeat || 'Shared';
      this.closeHospitalityModal();

      if (activeOrderId) {
        await this.loadTableOrderIntoCart(activeOrderId);
      } else {
        if (window.app.switchView) window.app.switchView('pos');
        if (window.app.renderCurrentView) window.app.renderCurrentView();
        if (window.app.showToast) {
          window.app.showToast(`Selected ${tableNumber} (${zoneName || 'Main Dining'}). Ready to take order.`, 'info');
        }
      }
    },

    clearActiveTable() {
      this.activeTable = null;
      this.activeSeat = 'Shared';
      this.activeCheckoutSeat = null;
      if (window.app.currentView === 'pos' && window.app.renderCurrentView) {
        window.app.renderCurrentView();
      }
    },

    setActiveSeat(seatName) {
      this.activeSeat = seatName || 'Shared';
      if (window.app.currentView === 'pos' && window.app.renderCurrentView) {
        window.app.renderCurrentView();
      }
      if (window.app.showToast) {
        window.app.showToast(`Active Ordering Seat: ${this.activeSeat}`, 'info', 2000);
      }
    },

    async addNewCustomSeat() {
      const seat = await window.app.showPromptModal({
        title: 'Add Seat or Diner Tag',
        desc: 'Enter a custom seat number or guest name for this space:',
        label: 'Seat / Diner Label',
        placeholder: 'e.g. Seat 3, T1S3, John, Bar-04',
        defaultValue: '',
        icon: 'fa-chair'
      });

      if (seat && seat.trim()) {
        this.setActiveSeat(seat.trim());
      }
    },

    async editCartItemSeat(idx) {
      if (!window.app.cart || !window.app.cart[idx]) return;
      const current = window.app.cart[idx].seat_number || this.activeSeat || 'Shared';
      const seat = await window.app.showPromptModal({
        title: 'Assign Seat / Guest',
        desc: `Which seat or guest is ordering "${window.app.cart[idx].name}"?`,
        label: 'Seat or Guest Tag',
        placeholder: 'e.g. Seat 1, Seat 2, T1S1, Bar-A, Shared',
        defaultValue: current,
        icon: 'fa-chair'
      });

      if (seat !== null && seat !== undefined && seat.trim()) {
        window.app.cart[idx].seat_number = seat.trim();
        window.app.renderCurrentView();
      }
    },

    async editCartItemNote(idx) {
      if (!window.app.cart || !window.app.cart[idx]) return;
      const current = window.app.cart[idx].prep_notes || '';
      const note = await window.app.showPromptModal({
        title: 'Kitchen Prep Note',
        desc: `Add special kitchen instructions for "${window.app.cart[idx].name}":`,
        label: 'Chef Note / Instruction',
        placeholder: 'e.g. No onions, Medium rare, Extra spicy, Less sugar',
        defaultValue: current,
        icon: 'fa-kitchen-set'
      });

      if (note !== null && note !== undefined) {
        window.app.cart[idx].prep_notes = note.trim();
        window.app.renderCurrentView();
      }
    },

    async loadTableOrderIntoCart(orderId) {
      let data = null;
      try {
        const res = await fetch(`api/endpoints/hospitality.php?action=order_details&order_id=${encodeURIComponent(orderId)}`);
        data = await res.json();
      } catch (e) {
        if (window.app.showToast) window.app.showToast('The floor could not be reached: ' + e.message, 'danger');
        return;
      }
      if (!data || !data.success || !data.order) {
        if (window.app.showToast) window.app.showToast((data && data.message) || 'That tab could not be opened.', 'danger');
        return;
      }

      const byLine = new Map();
      (data.order.items || []).forEach(it => {
        // Skip already settled items if partially split
        if (String(it.kitchen_status || '').toUpperCase() === 'SETTLED') return;

        const unit = it.unit || 'pcs';
        const seat = it.seat_number || 'Shared';
        const key = `${it.product_id}|${unit.toLowerCase()}|${seat}`;
        const seen = byLine.get(key);
        if (seen) {
          const addQty = parseFloat(it.quantity) || 0;
          seen.quantity += addQty;
          seen.fired_quantity += addQty;
          return;
        }
        const raw = (window.app.products || []).find(p => p.id === it.product_id);
        const eff = raw && window.app.getEffectiveProductForBranch
          ? window.app.getEffectiveProductForBranch(raw) : null;
        const multiplier = parseFloat(it.multiplier || 1) || 1;
        const price = parseFloat(it.unit_price) || 0;
        byLine.set(key, {
          product_id: it.product_id,
          name: it.product_name,
          unit_cost_price: eff ? Number(eff.cost_price || 0) : 0,
          base_selling_price: eff ? Number(eff.effectivePrice || eff.selling_price || price) : price / multiplier,
          selling_price: price,
          unit: (eff && eff.unit) || unit,
          selected_unit: unit,
          multiplier: multiplier,
          quantity: parseFloat(it.quantity) || 0,
          fired_quantity: parseFloat(it.quantity) || 0,
          branch_code: window.app.branchCode || 'MAIN-01',
          seat_number: seat,
          prep_notes: it.prep_notes || ''
        });
      });

      window.app.cart = [...byLine.values()];
      if (this.activeTable) {
        this.activeTable.orderId = data.order.id;
        this.activeTable.number = data.order.table_number;
        this.activeTable.guests = data.order.guest_count;
        this.activeTable.tabSubtotal = parseFloat(data.order.subtotal) || 0;
        this.activeTable.ticketCount = parseInt(data.order.ticket_count, 10) || 1;
      }

      if (window.app.switchView) window.app.switchView('pos');
      if (window.app.renderCurrentView) window.app.renderCurrentView();
      if (window.app.showToast) {
        window.app.showToast(
          `Loaded ${data.order.table_number}'s active tab into cart (${window.app.formatCurrency ? window.app.formatCurrency(data.order.subtotal || 0) : data.order.subtotal}).`,
          'info');
      }
    },

    async sendCartToKitchen() {
      if (!this.activeTable) {
        if (window.app.showToast) window.app.showToast('Please select a space or table first before firing an order.', 'warning');
        this.openHospitalityModal();
        return;
      }
      if (!window.app.cart || window.app.cart.length === 0) {
        if (window.app.showToast) window.app.showToast('Cart is empty. Select dishes or drinks first.', 'warning');
        return;
      }

      const items = [];
      let hasFiredLines = false;
      window.app.cart.forEach(i => {
        const qty = parseFloat(i.quantity) || 0;
        const fired = parseFloat(i.fired_quantity) || 0;
        if (fired > 0) hasFiredLines = true;
        const toFire = Math.round((qty - fired) * 1000) / 1000;
        if (toFire > 0) {
          items.push({
            product_id: i.product_id,
            product_name: i.name,
            quantity: toFire,
            unit: i.selected_unit || i.unit || 'pcs',
            seat_number: i.seat_number || 'Shared',
            prep_notes: i.prep_notes || ''
          });
        }
      });

      if (items.length === 0) {
        if (window.app.showToast) {
          window.app.showToast(
            hasFiredLines
              ? 'All items in cart have already been fired to the kitchen. Add new dishes to fire a new round.'
              : 'Nothing to fire. Add dishes or drinks to the cart.',
            'warning');
        }
        return;
      }

      try {
        const res = await fetch('api/endpoints/hospitality.php?action=open_order', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            table_id: this.activeTable.id,
            guest_count: this.activeTable.guests || 2,
            items: items,
            notes: ''
          })
        });
        const data = await res.json();
        if (!data.success) {
          if (window.app.showToast) window.app.showToast(data.message || 'The kitchen did not take that order.', 'danger');
          return;
        }
        this.activeTable.orderId = data.order_id;
        this.activeTable.tabSubtotal = parseFloat(data.tab_subtotal) || 0;
        this.activeTable.ticketCount = this.activeTable.ticketCount ? this.activeTable.ticketCount + 1 : 1;

        if (window.app.showToast) {
          window.app.showToast(
            `Fired ${data.ticket_number} to kitchen for ${this.activeTable.number}!`,
            'success');
        }
        window.app.clearCart();
        if (typeof window.app.broadcastSyncEvent === 'function') {
          window.app.broadcastSyncEvent('KOT_FIRED', { table: this.activeTable.number, ticket: data.ticket_number });
        }
      } catch (e) {
        if (window.app.showToast) window.app.showToast('The kitchen could not be reached: ' + e.message, 'danger');
      }
    },

    // =========================================================================
    // 3. DYNAMIC SPACES & UNLIMITED TABLES SETUP
    // =========================================================================
    openTableFormModal(tableId) {
      const modal = document.getElementById('table-form-modal');
      if (!modal) return;

      const titleEl = document.getElementById('table-form-title');
      const idEl = document.getElementById('table-form-id');
      const numEl = document.getElementById('table-form-number');
      const zoneEl = document.getElementById('table-form-zone');
      const capEl = document.getElementById('table-form-capacity');
      const delBtn = document.getElementById('table-form-delete-btn');

      if (tableId) {
        const table = (this._floorTables || []).find(t => t.id === tableId);
        if (table) {
          if (titleEl) titleEl.textContent = `Edit ${table.table_number}`;
          if (idEl) idEl.value = table.id;
          if (numEl) numEl.value = table.table_number;
          if (zoneEl) zoneEl.value = table.zone_name || 'Main Dining';
          if (capEl) capEl.value = table.seating_capacity || 4;

          // Only allow deletion if table is vacant
          const isVacant = (!table.active_order_id && table.status === 'VACANT');
          if (delBtn) delBtn.style.display = isVacant ? 'block' : 'none';
        }
      } else {
        if (titleEl) titleEl.textContent = 'Create New Space / Table';
        if (idEl) idEl.value = '';
        if (numEl) numEl.value = '';
        if (zoneEl) zoneEl.value = (this.selectedFloorZone !== 'ALL' ? this.selectedFloorZone : 'Main Dining');
        if (capEl) capEl.value = 4;
        if (delBtn) delBtn.style.display = 'none';
      }

      modal.classList.add('active');
      setTimeout(() => { if (numEl) numEl.focus(); }, 60);
    },

    closeTableFormModal() {
      const modal = document.getElementById('table-form-modal');
      if (modal) modal.classList.remove('active');
    },

    async saveTableForm() {
      const id = document.getElementById('table-form-id')?.value.trim();
      const num = document.getElementById('table-form-number')?.value.trim();
      const zone = document.getElementById('table-form-zone')?.value.trim() || 'Main Dining';
      const capacity = parseInt(document.getElementById('table-form-capacity')?.value, 10) || 4;

      if (!num) {
        if (window.app.showToast) window.app.showToast('Please enter a name or number for the space (e.g. Table 5, Bar 1).', 'warning');
        return;
      }
      if (capacity < 1 || capacity > 200) {
        if (window.app.showToast) window.app.showToast('Capacity must be between 1 and 200 seats.', 'warning');
        return;
      }

      try {
        const payload = {
          id: id || undefined,
          table_number: num,
          zone_name: zone,
          seating_capacity: capacity,
          branch_code: window.app.branchCode || 'MAIN-01'
        };

        const res = await fetch('api/endpoints/hospitality.php?action=create_table', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        const data = await res.json();
        if (!data.success) {
          if (window.app.showToast) window.app.showToast(data.message || 'Could not save space.', 'danger');
          return;
        }

        this.closeTableFormModal();
        if (window.app.showToast) window.app.showToast(`Saved space "${num}" with capacity for ${capacity} guests.`, 'success');
        await this.loadHospitalityTables();
      } catch (err) {
        if (window.app.showToast) window.app.showToast('Network error saving space: ' + err.message, 'danger');
      }
    },

    async deleteTableFromForm() {
      const id = document.getElementById('table-form-id')?.value.trim();
      const num = document.getElementById('table-form-number')?.value.trim();
      if (!id) return;

      let confirmed = false;
      if (typeof window.app.showConfirmModal === 'function') {
        confirmed = await window.app.showConfirmModal({
          title: `Delete Space "${num}"?`,
          message: `Are you sure you want to remove ${num} from the floor? This cannot be undone.`,
          icon: 'fa-trash',
          confirmText: 'Delete Space',
          confirmBtnClass: 'btn-danger'
        });
      } else {
        confirmed = confirm(`Delete ${num}?`);
      }
      if (!confirmed) return;

      try {
        const res = await fetch('api/endpoints/hospitality.php?action=delete_table', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ table_id: id })
        });
        const data = await res.json();
        if (!data.success) {
          if (window.app.showToast) window.app.showToast(data.message || 'Could not delete space.', 'danger');
          return;
        }

        this.closeTableFormModal();
        if (window.app.showToast) window.app.showToast(`Removed "${num}" from the floor plan.`, 'success');
        await this.loadHospitalityTables();
      } catch (err) {
        if (window.app.showToast) window.app.showToast('Network error deleting space: ' + err.message, 'danger');
      }
    },

    // =========================================================================
    // 4. SPLIT BILL & SEAT CHECKOUT WORKFLOW
    // =========================================================================
    openSplitBillModal() {
      const modal = document.getElementById('split-bill-modal');
      const list = document.getElementById('split-bill-seats-list');
      if (!modal || !list) return;

      if (!window.app.cart || window.app.cart.length === 0) {
        if (window.app.showToast) window.app.showToast('No items currently in cart to split.', 'warning');
        return;
      }

      // Group items by seat_number
      const seatGroups = {};
      window.app.cart.forEach(item => {
        const s = item.seat_number || 'Shared';
        if (!seatGroups[s]) {
          seatGroups[s] = { items: [], subtotal: 0 };
        }
        seatGroups[s].items.push(item);
        seatGroups[s].subtotal += (item.quantity * item.selling_price);
      });

      const money = (v) => (window.app.formatCurrency ? window.app.formatCurrency(v) : `$${v.toFixed(2)}`);

      let html = '';
      const seatKeys = Object.keys(seatGroups);

      seatKeys.forEach(sName => {
        const g = seatGroups[sName];
        html += `
          <div style="background: #ffffff; border: 1.5px solid var(--slate-200); border-radius: 10px; padding: 0.9rem; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 1px 2px rgba(0,0,0,0.03);">
            <div>
              <div style="display: flex; align-items: center; gap: 0.4rem;">
                <span style="font-weight: 800; font-size: 1rem; color: #0284c7;"><i class="fa-solid fa-chair"></i> ${this.escapeHtml(sName)}</span>
                <span class="badge" style="background: #e0f2fe; color: #0369a1; font-size: 0.72rem; font-weight: 700;">${g.items.length} item(s)</span>
              </div>
              <div style="font-size: 0.76rem; color: var(--slate-500); margin-top: 0.2rem;">
                ${g.items.map(it => `${it.quantity}x ${this.escapeHtml(it.name)}`).join(', ')}
              </div>
              <div style="font-size: 0.92rem; font-weight: 800; color: var(--slate-900); margin-top: 0.35rem;">
                Seat Total: ${money(g.subtotal)}
              </div>
            </div>
            <button class="btn btn-primary btn-sm" data-seat="${this.escapeHtml(sName)}" onclick="app.checkoutSeatOnly(this.dataset.seat)" style="font-weight: 700; white-space: nowrap; display: flex; align-items: center; gap: 0.35rem;">
              <i class="fa-solid fa-cash-register"></i> Pay This Seat
            </button>
          </div>
        `;
      });

      list.innerHTML = html;
      modal.classList.add('active');
    },

    closeSplitBillModal() {
      const modal = document.getElementById('split-bill-modal');
      if (modal) modal.classList.remove('active');
    },

    checkoutSeatOnly(seatName) {
      this.activeCheckoutSeat = seatName;
      this._originalCart = [...window.app.cart];

      // Filter cart to only items for this seat
      window.app.cart = window.app.cart.filter(i => (i.seat_number || 'Shared') === seatName);
      this.closeSplitBillModal();

      if (window.app.showToast) {
        window.app.showToast(`Checking out ${seatName}. Remaining seats will stay on table tab.`, 'info');
      }

      // Open standard checkout modal
      if (typeof window.app.openCheckoutModal === 'function') {
        window.app.openCheckoutModal();
      }
    },

    checkoutEntireTableCombined() {
      this.activeCheckoutSeat = 'ALL';
      this.closeSplitBillModal();
      if (typeof window.app.openCheckoutModal === 'function') {
        window.app.openCheckoutModal();
      }
    },

    // =========================================================================
    // 5. KITCHEN DISPLAY SYSTEM (KDS) CHEF SCREEN
    // =========================================================================
    async openKDSModal() {
      const modal = document.getElementById('kds-modal');
      if (!modal) return;
      modal.classList.add('active');
      await this.loadKDSOrders();

      if (this.kdsRefreshTimer) clearInterval(this.kdsRefreshTimer);
      this.kdsRefreshTimer = setInterval(() => this.loadKDSOrders(), 10000);
    },

    closeKDSModal() {
      const modal = document.getElementById('kds-modal');
      if (modal) modal.classList.remove('active');
      if (this.kdsRefreshTimer) clearInterval(this.kdsRefreshTimer);
    },

    async loadKDSOrders() {
      const grid = document.getElementById('kds-orders-grid');
      if (!grid) return;

      try {
        const res = await fetch('api/endpoints/hospitality.php?action=active_orders');
        const data = await res.json();
        if (!data.success) {
          grid.innerHTML = `<div style="grid-column: 1/-1; color: #ef4444; padding: 2rem; text-align: center;">${this.escapeHtml(data.message || 'Error loading KDS')}</div>`;
          return;
        }
        if (!data.orders || data.orders.length === 0) {
          grid.innerHTML = `
            <div style="grid-column: 1/-1; text-align: center; padding: 4rem 1rem; color: #94a3b8;">
              <i class="fa-solid fa-bell-concierge fa-3x" style="opacity: 0.4; margin-bottom: 0.75rem;"></i>
              <h3 style="margin: 0; color: #e2e8f0;">No Pending Kitchen Orders</h3>
              <p style="margin: 0.25rem 0 0; font-size: 0.85rem;">All tables are served and up to date.</p>
            </div>
          `;
          return;
        }

        let html = '';
        const now = Date.now();
        this._kdsLines = {};

        data.orders.forEach(o => {
          (o.items || []).forEach(it => {
            this._kdsLines[it.id] = { name: it.product_name, table: o.table_number, orderId: o.id };
          });

          const openedTime = new Date(String(o.opened_at || '').replace(' ', 'T') + 'Z').getTime();
          const elapsedMins = Number.isFinite(openedTime) ? Math.max(0, Math.floor((now - openedTime) / 60000)) : 0;

          let timerBg = '#166534'; // green
          if (elapsedMins >= 20) timerBg = '#991b1b'; // red
          else if (elapsedMins >= 10) timerBg = '#b45309'; // yellow

          html += `
            <div style="background: #1e293b; border: 1.5px solid #334155; border-radius: 12px; display: flex; flex-direction: column; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.3);">
              <!-- Card Header -->
              <div style="background: #0f172a; padding: 0.85rem 1rem; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #334155;">
                <div>
                  <div style="font-weight: 800; font-size: 1.2rem; color: #f8fafc;">${this.escapeHtml(o.table_number)}</div>
                  <div style="font-size: 0.72rem; color: #94a3b8;">#${this.escapeHtml(o.kot_number || 'KOT')} &middot; ${this.escapeHtml(o.server_name || 'Counter')} &middot; ${Number(o.guest_count) || 1} guests</div>
                </div>
                <div style="background: ${timerBg}; color: #ffffff; padding: 0.25rem 0.6rem; border-radius: 999px; font-weight: 700; font-size: 0.78rem;">
                  <i class="fa-solid fa-clock"></i> ${elapsedMins}m
                </div>
              </div>

              <!-- Item List -->
              <div style="padding: 1rem; flex: 1; display: flex; flex-direction: column; gap: 0.65rem;">
                ${(o.items || []).map(it => `
                  <div style="background: #334155; border-radius: 8px; padding: 0.6rem 0.75rem;">
                    <div style="display: flex; justify-content: space-between; align-items: center; gap: 0.5rem;">
                      <div style="display: flex; align-items: center; gap: 0.35rem; flex-wrap: wrap;">
                        ${it.seat_number && it.seat_number !== 'Shared' ? `
                          <span style="background: #0284c7; color: #ffffff; padding: 0.12rem 0.45rem; border-radius: 4px; font-size: 0.72rem; font-weight: 800;">
                            <i class="fa-solid fa-chair"></i> ${this.escapeHtml(it.seat_number)}
                          </span>
                        ` : ''}
                        <span style="font-weight: 700; font-size: 1rem; color: #f1f5f9;">${Number(it.quantity) || 0}x ${this.escapeHtml(it.product_name)}${it.unit && it.unit !== 'pcs' ? ` <span style="font-size:0.72rem;color:#cbd5e1;">(${this.escapeHtml(it.unit)})</span>` : ''}</span>
                      </div>
                      <button type="button" class="btn btn-sm" title="Take dish off ticket" onclick="app.voidFloorLine(this.dataset.itemId)" data-item-id="${this.escapeHtml(it.id)}" style="background: transparent; border: 1px solid #7f1d1d; color: #fca5a5; padding: 0.1rem 0.4rem; font-size: 0.7rem; border-radius: 6px;">
                        <i class="fa-solid fa-xmark"></i>
                      </button>
                    </div>
                    <div style="font-size: 0.68rem; color: #94a3b8; margin-top: 0.2rem;">${this.escapeHtml(it.ticket_number || o.kot_number || '')}</div>
                    ${it.prep_notes ? `
                      <div style="color: #fbbf24; font-size: 0.78rem; font-weight: 600; margin-top: 0.25rem;">
                        <i class="fa-solid fa-triangle-exclamation"></i> ${this.escapeHtml(it.prep_notes)}
                      </div>
                    ` : ''}
                  </div>
                `).join('')}
              </div>

              <!-- Chef Action Footer -->
              <div style="padding: 0.85rem 1rem; background: #0f172a; border-top: 1px solid #334155; display: flex; gap: 0.5rem;">
                ${o.status === 'IN_KITCHEN' ? `
                  <button class="btn btn-sm" style="flex: 1; background: #d97706; color: #fff; border: none; font-weight: 700;" data-order-id="${this.escapeHtml(o.id)}" onclick="app.updateKDSStatus(this.dataset.orderId, 'PREPARING')">
                    <i class="fa-solid fa-fire-burner"></i> Start Cooking
                  </button>
                ` : o.status === 'PREPARING' ? `
                  <button class="btn btn-sm" style="flex: 1; background: #16a34a; color: #fff; border: none; font-weight: 700;" data-order-id="${this.escapeHtml(o.id)}" onclick="app.updateKDSStatus(this.dataset.orderId, 'READY')">
                    <i class="fa-solid fa-bell"></i> Mark Ready
                  </button>
                ` : `
                  <button class="btn btn-sm" style="flex: 1; background: #2563eb; color: #fff; border: none; font-weight: 700;" data-order-id="${this.escapeHtml(o.id)}" onclick="app.updateKDSStatus(this.dataset.orderId, 'SERVED')">
                    <i class="fa-solid fa-check-double"></i> Bump (Served)
                  </button>
                `}
              </div>
            </div>
          `;
        });

        grid.innerHTML = html;
      } catch (err) {
        grid.innerHTML = `<div style="grid-column: 1/-1; color: #ef4444; padding: 2rem; text-align: center;">Error loading KDS: ${this.escapeHtml(err.message)}</div>`;
      }
    },

    async updateKDSStatus(orderId, newStatus) {
      try {
        const res = await fetch('api/endpoints/hospitality.php?action=update_order_status', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ order_id: orderId, status: newStatus })
        });
        const data = await res.json();
        if (!data.success) {
          if (window.app.showToast) window.app.showToast(data.message || 'The ticket did not move.', 'danger');
          return;
        }
        await this.loadKDSOrders();
      } catch (e) {
        if (window.app.showToast) window.app.showToast('The kitchen board could not be reached: ' + e.message, 'danger');
      }
    },

    async voidFloorLine(itemId) {
      const line = (this._kdsLines || {})[itemId] || {};
      const reason = await window.app.showPromptModal({
        title: 'Void Dish from Ticket',
        desc: `Take ${line.name ? '"' + line.name + '"' : 'this dish'} off ${line.table || 'the ticket'}? It will not be charged to the table.`,
        label: 'Reason for Voiding *',
        placeholder: 'e.g. Sent back, Incorrect order, Customer changed mind',
        defaultValue: '',
        icon: 'fa-ban'
      });

      if (reason === null || reason === undefined) return;
      if (!reason.trim()) {
        if (window.app.showToast) window.app.showToast('Please specify a reason to void this dish.', 'warning');
        return;
      }

      try {
        const res = await fetch('api/endpoints/hospitality.php?action=void_line', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ item_id: itemId, reason: reason.trim() })
        });
        const data = await res.json();
        if (!data.success) {
          if (window.app.showToast) window.app.showToast(data.message || 'The line could not be taken off.', 'danger');
          return;
        }
        if (this.activeTable && this.activeTable.orderId === line.orderId) {
          this.activeTable.tabSubtotal = parseFloat(data.tab_subtotal) || 0;
        }
        if (window.app.showToast) {
          window.app.showToast(`${data.message}. Tab subtotal is now ${window.app.formatCurrency ? window.app.formatCurrency(data.tab_subtotal || 0) : data.tab_subtotal}.`, 'success');
        }
        await this.loadKDSOrders();
      } catch (e) {
        if (window.app.showToast) window.app.showToast('Error voiding line: ' + e.message, 'danger');
      }
    },

    // =========================================================================
    // 6. DINING FLOOR PLAN & SEATING GRID
    // =========================================================================
    async openHospitalityModal() {
      const modal = document.getElementById('hospitality-modal');
      if (!modal) return;
      modal.classList.add('active');
      await this.loadHospitalityTables();
    },

    closeHospitalityModal() {
      const modal = document.getElementById('hospitality-modal');
      if (modal) modal.classList.remove('active');
    },

    setFloorZoneFilter(zone) {
      this.selectedFloorZone = zone || 'ALL';
      this.renderFloorGrid();
    },

    async loadHospitalityTables() {
      const container = document.getElementById('hospitality-tables-grid');
      if (!container) return;
      container.innerHTML = '<div style="padding: 2rem; text-align: center; color: var(--slate-500);"><i class="fa-solid fa-spinner fa-spin fa-2x"></i><p style="margin-top:0.5rem;">Loading dining spaces...</p></div>';

      try {
        const res = await fetch('api/endpoints/hospitality.php?action=tables');
        const data = await res.json();
        if (!data.success || !data.tables) {
          container.innerHTML = `<div style="padding: 1.5rem; text-align: center; color: #ef4444;"><i class="fa-solid fa-circle-exclamation fa-2x"></i><p>${this.escapeHtml(data.message || 'Floor spaces could not be loaded.')}</p></div>`;
          return;
        }

        this._floorTables = data.tables;
        this.renderFloorGrid();
      } catch (err) {
        container.innerHTML = `<div style="padding: 1.5rem; text-align: center; color: #ef4444;"><p>Error fetching spaces: ${this.escapeHtml(err.message)}</p></div>`;
      }
    },

    renderFloorGrid() {
      const container = document.getElementById('hospitality-tables-grid');
      const filterContainer = document.getElementById('hospitality-zone-filters');
      if (!container) return;

      const tables = this._floorTables || [];
      const zones = ['ALL'];
      tables.forEach(t => {
        const z = t.zone_name || 'Main Dining';
        if (!zones.includes(z)) zones.push(z);
      });

      // Render Zone Filters
      if (filterContainer) {
        filterContainer.innerHTML = zones.map(z => {
          const isActive = (this.selectedFloorZone === z);
          return `
            <button type="button" class="btn btn-sm" data-zone="${this.escapeHtml(z)}" onclick="app.setFloorZoneFilter(this.dataset.zone)" style="padding: 0.25rem 0.65rem; font-size: 0.76rem; border-radius: 999px; background: ${isActive ? 'var(--primary)' : '#ffffff'}; color: ${isActive ? '#ffffff' : 'var(--slate-700)'}; border: 1.5px solid ${isActive ? 'var(--primary)' : 'var(--slate-300)'}; font-weight: 700;">
              ${z === 'ALL' ? 'All Spaces' : this.escapeHtml(z)}
            </button>
          `;
        }).join('');
      }

      // Filter tables by active zone
      const filtered = (this.selectedFloorZone === 'ALL')
        ? tables
        : tables.filter(t => (t.zone_name || 'Main Dining') === this.selectedFloorZone);

      if (filtered.length === 0) {
        container.innerHTML = `
          <div style="text-align: center; padding: 3rem 1rem; color: var(--slate-400);">
            <i class="fa-solid fa-chair fa-3x" style="opacity: 0.4; margin-bottom: 0.75rem;"></i>
            <h4 style="margin: 0; color: var(--slate-700);">No Spaces Found</h4>
            <p style="margin: 0.25rem 0 1rem; font-size: 0.85rem;">Click "+ Add Space" above to create tables, bar counters, or VIP rooms.</p>
            <button class="btn btn-primary btn-sm" onclick="app.openTableFormModal()"><i class="fa-solid fa-plus"></i> Add Space Now</button>
          </div>
        `;
        return;
      }

      const money = (v) => (window.app.formatCurrency ? window.app.formatCurrency(Number(v) || 0) : `$${Number(v || 0).toFixed(2)}`);

      let html = '<div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 1rem;">';
      filtered.forEach(t => {
        const isOccupied = (t.status === 'OCCUPIED' && t.active_order_id);
        const statusBg = isOccupied ? '#fee2e2' : '#dcfce7';
        const statusColor = isOccupied ? '#991b1b' : '#166534';
        const statusIcon = isOccupied ? 'fa-solid fa-utensils' : 'fa-solid fa-chair';

        html += `
          <div style="background: #ffffff; border: 1.5px solid ${isOccupied ? '#fca5a5' : 'var(--slate-200)'}; border-radius: 12px; padding: 1.1rem; box-shadow: 0 1px 3px rgba(0,0,0,0.05); display: flex; flex-direction: column; justify-content: space-between;">
            <div>
              <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.65rem;">
                <div>
                  <div style="font-weight: 800; font-size: 1.15rem; color: var(--slate-800); display: flex; align-items: center; gap: 0.35rem;">
                    <span>${this.escapeHtml(t.table_number)}</span>
                    <button type="button" class="btn btn-sm btn-outline" onclick="app.openTableFormModal(this.dataset.tableId)" data-table-id="${this.escapeHtml(t.id)}" style="padding: 0.1rem 0.35rem; font-size: 0.68rem; border-color: var(--slate-300); color: var(--slate-500); background: #fff;" title="Edit space name, zone, or capacity">
                      <i class="fa-solid fa-gear"></i>
                    </button>
                  </div>
                  <div style="font-size: 0.75rem; color: var(--slate-500); margin-top: 0.1rem;">
                    <i class="fa-solid fa-map-pin"></i> ${this.escapeHtml(t.zone_name || 'Main Dining')}
                  </div>
                </div>
                <span style="background: ${statusBg}; color: ${statusColor}; font-size: 0.7rem; font-weight: 800; padding: 0.2rem 0.55rem; border-radius: 999px; text-transform: uppercase;">
                  <i class="${statusIcon}"></i> ${this.escapeHtml(t.status)}
                </span>
              </div>

              <div style="font-size: 0.82rem; color: var(--slate-600); margin-bottom: 0.9rem;">
                <div style="display: flex; align-items: center; justify-content: space-between;">
                  <span><i class="fa-solid fa-users"></i> Capacity: <strong>${Number(t.seating_capacity) || 0} seats</strong></span>
                  <button type="button" class="btn btn-sm" onclick="app.openTableFormModal(this.dataset.tableId)" data-table-id="${this.escapeHtml(t.id)}" style="padding: 0.05rem 0.35rem; font-size: 0.68rem; color: #0284c7; background: #e0f2fe; border: none; font-weight: 700; border-radius: 4px;">
                    Adjust
                  </button>
                </div>
                ${isOccupied ? `
                  <div style="margin-top: 0.35rem; background: #fef2f2; border: 1px solid #fecaca; border-radius: 6px; padding: 0.4rem 0.6rem;">
                    <div style="font-size: 0.72rem; color: #991b1b;"><i class="fa-solid fa-receipt"></i> Tab Total: <strong style="font-size: 0.92rem;">${money(t.current_bill_total)}</strong></div>
                    <div style="font-size: 0.7rem; color: #b91c1c; margin-top: 0.1rem;">Server: ${this.escapeHtml(t.server_name || 'Counter')} &middot; ${Number(t.guest_count) || 1} guests</div>
                  </div>
                ` : `
                  <div style="color: #166534; margin-top: 0.35rem; font-size: 0.76rem;"><i class="fa-solid fa-check"></i> Ready to seat guests</div>
                `}
              </div>
            </div>

            <div style="display: flex; gap: 0.4rem; flex-direction: column;">
              ${isOccupied ? `
                <div style="display: flex; gap: 0.4rem;">
                  <button class="btn btn-sm btn-primary" style="flex: 1; font-weight: 700;" onclick="app.openFloorTable(this.dataset.tableId)" data-table-id="${this.escapeHtml(t.id)}">
                    <i class="fa-solid fa-cart-shopping"></i> Open Tab
                  </button>
                  <button class="btn btn-sm btn-outline" style="border-color: #0284c7; color: #0284c7; font-weight: 700;" onclick="app.openFloorTable(this.dataset.tableId); setTimeout(() => app.openSplitBillModal(), 250);" data-table-id="${this.escapeHtml(t.id)}" title="Split by seat or diner">
                    <i class="fa-solid fa-scissors"></i> Split
                  </button>
                </div>
                <button class="btn btn-sm btn-outline" style="width: 100%; border-color: #f87171; color: #dc2626;" onclick="app.cancelFloorTab(this.dataset.tableId)" data-table-id="${this.escapeHtml(t.id)}">
                  <i class="fa-solid fa-ban"></i> Call Tab Off
                </button>
              ` : `
                <button class="btn btn-sm btn-primary" style="width: 100%; font-weight: 700;" onclick="app.openFloorTable(this.dataset.tableId)" data-table-id="${this.escapeHtml(t.id)}">
                  <i class="fa-solid fa-user-plus"></i> Seat Space
                </button>
              `}
            </div>
          </div>
        `;
      });
      html += '</div>';
      container.innerHTML = html;
    },

    openFloorTable(tableId) {
      const table = (this._floorTables || []).find(t => t.id === tableId);
      if (!table) {
        if (window.app.showToast) window.app.showToast('That table is no longer on the floor. Refreshing.', 'warning');
        return;
      }
      this.selectTableForPOS(table.id, table.table_number, table.zone_name, table.active_order_id || null, table.guest_count || 1, table.seating_capacity || 0);
    },

    async cancelFloorTab(tableId) {
      const table = (this._floorTables || []).find(t => t.id === tableId);
      if (!table || !table.active_order_id) {
        if (window.app.showToast) window.app.showToast('That table is not holding a tab.', 'info');
        return;
      }

      const reason = await window.app.showPromptModal({
        title: 'Cancel Dining Tab',
        desc: `Call off tab for "${table.table_number}"? The tab will be cancelled and space freed.`,
        label: 'Cancellation Reason *',
        placeholder: 'e.g. Party walked out, Table seated in error',
        defaultValue: '',
        icon: 'fa-ban'
      });

      if (reason === null || reason === undefined) return;
      if (!reason.trim()) {
        if (window.app.showToast) window.app.showToast('Please specify a reason to cancel the tab.', 'warning');
        return;
      }

      try {
        const res = await fetch('api/endpoints/hospitality.php?action=cancel_tab', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ order_id: table.active_order_id, reason: reason.trim() })
        });
        const data = await res.json();
        if (!data.success) {
          if (window.app.showToast) window.app.showToast(data.message || 'The tab could not be called off.', 'danger');
          return;
        }
        if (this.activeTable && this.activeTable.orderId === table.active_order_id) {
          this.clearActiveTable();
        }
        if (window.app.showToast) window.app.showToast(data.message, 'success');
        await this.loadHospitalityTables();
      } catch (e) {
        if (window.app.showToast) window.app.showToast('Error calling off tab: ' + e.message, 'danger');
      }
    },

    // =========================================================================
    // 7. IN-CART CUSTOMER LOYALTY REWARDS
    // =========================================================================
    renderCartLoyaltyWidget(customer) {
      if (!customer || customer.id === 'cust-walkin') return '';

      const settings = this.loyaltySettings();
      if (!settings.enabled) return '';

      const points = parseFloat(customer.loyalty_points || 0);
      const tier = (customer.loyalty_tier || 'BRONZE').toUpperCase();
      const money = (v) => (window.app && window.app.formatCurrency)
        ? window.app.formatCurrency(Number(v) || 0)
        : `GH₵${(Number(v) || 0).toFixed(2)}`;
      // What the whole balance would buy at the shop's own rate - not at a rate this file used to
      // carry as a literal, which is how a till in Accra came to price points like a shop in
      // dollars.
      const value = points * settings.rate;

      const tierColors = {
        'PLATINUM': { bg: '#ede9fe', text: '#5b21b6', border: '#c4b5fd' },
        'GOLD':     { bg: '#fef3c7', text: '#92400e', border: '#fcd34d' },
        'SILVER':   { bg: '#f1f5f9', text: '#334155', border: '#cbd5e1' },
        'BRONZE':   { bg: '#ffedd5', text: '#9a3412', border: '#fdba74' },
      };
      const tStyle = tierColors[tier] || tierColors.BRONZE;
      const isRedeemed = this.redeemedLoyaltyPoints > 0;
      const perk = settings.tierPerks ? this.tierPct(tier) : 0;

      return `
        <div style="margin-top: 0.5rem; background: ${tStyle.bg}; border: 1px solid ${tStyle.border}; border-radius: 8px; padding: 0.5rem 0.75rem; display: flex; align-items: center; justify-content: space-between; font-size: 0.78rem;">
          <div style="display: flex; align-items: center; gap: 0.4rem; flex-wrap: wrap;">
            <span style="font-weight: 800; color: ${tStyle.text};"><i class="fa-solid fa-crown"></i> ${tier}</span>
            <span style="color: var(--slate-600);">&bull; ${points.toLocaleString()} pts (${money(value)})${perk > 0 ? ` &bull; ${Math.round(perk * 100)}% off` : ''}</span>
          </div>
          ${points > 0 && settings.redeemAtCounter ? `
            <button type="button" class="btn btn-sm" onclick="app.toggleLoyaltyRedemption(${points})" style="background: ${isRedeemed ? '#dc2626' : '#16a34a'}; color: #fff; border: none; padding: 0.2rem 0.55rem; font-size: 0.72rem; font-weight: 700;">
              ${isRedeemed ? '<i class="fa-solid fa-xmark"></i> Remove' : '<i class="fa-solid fa-tag"></i> Offer points'}
            </button>
          ` : points > 0 ? `
            <span style="font-size: 0.7rem; color: var(--slate-500);">Shop does not take points at the counter</span>
          ` : `<span style="font-size: 0.7rem; color: var(--slate-500);">Earns ${settings.perUnit} pt${settings.perUnit === 1 ? '' : 's'} per ${money(1)}</span>`}
        </div>
      `;
    },

    // The shop's loyalty policy as the server last told us it. Read from the profile the till was
    // given, never from a number written into this file: a shop that pays one point per GH₵5 and
    // values a point at GH₵0.05 used to see the widget say something else entirely, and the sale
    // it sent agreed with the widget.
    loyaltySettings() {
      const p = (window.app && window.app.storeProfile) || {};
      const num = (value, fallback) => {
        if (value === null || value === undefined || value === '') return fallback;
        const n = Number(value);
        return Number.isFinite(n) ? n : fallback;
      };
      return {
        enabled: num(p.loyalty_enabled, 1) === 1,
        redeemAtCounter: num(p.loyalty_redeem_at_counter, 1) === 1,
        tierPerks: num(p.loyalty_tier_perks, 0) === 1,
        perUnit: num(p.loyalty_points_per_currency, 1),
        rate: num(p.loyalty_redemption_rate, 0.01),
      };
    },

    tierPct(tier) {
      switch ((tier || 'BRONZE').toUpperCase()) {
        case 'PLATINUM': return 0.15;
        case 'GOLD': return 0.10;
        case 'SILVER': return 0.05;
        default: return 0;
      }
    },

    // A preview, and nothing more. The counter's receipt is priced by the server from these same
    // settings; this only lets the cashier tell the customer a figure before they ring it, and
    // keeps the total on the screen equal to the total that will be booked.
    loyaltyPreview(goodsValue) {
      const out = { loyalty: 0, tier: 0 };
      const settings = this.loyaltySettings();
      if (!settings.enabled) return out;
      const customer = (window.app && window.app.selectedCustomerId)
        ? (window.app.customers || []).find(c => c.id === window.app.selectedCustomerId)
        : null;
      if (!customer || customer.id === 'cust-walkin') return out;

      const payable = Math.max(0, Number(goodsValue) || 0);
      if (settings.tierPerks) {
        out.tier = Math.round(payable * this.tierPct(customer.loyalty_tier) * 100) / 100;
      }

      const offered = Number(this.redeemedLoyaltyPoints || 0);
      if (offered > 0 && settings.redeemAtCounter && settings.rate > 0) {
        const balance = Number(customer.loyalty_points || 0);
        const affordable = Math.max(0, payable - out.tier);
        const byMoney = Math.floor((affordable / settings.rate) * 100) / 100;
        const used = Math.min(offered, balance, byMoney);
        out.loyalty = Math.min(Math.round(used * settings.rate * 100) / 100, affordable);
      }
      return out;
    },

    toggleLoyaltyRedemption(availablePoints) {
      if (this.redeemedLoyaltyPoints > 0) {
        this.redeemedLoyaltyPoints = 0;
        if (window.app) {
          // The cashier's own discount is left exactly where it was. This used to overwrite it,
          // so offering points quietly deleted a discount the shop had already agreed to.
          window.app.renderCurrentView();
          window.app.showToast('Points offer removed.', 'info');
        }
        return;
      }

      const settings = this.loyaltySettings();
      const { taxableAmount } = window.app.getCartTotals();
      const cap = settings.rate > 0 ? Math.floor(taxableAmount / settings.rate) : 0;
      const offered = Math.min(Number(availablePoints) || 0, cap);

      this.redeemedLoyaltyPoints = offered;
      if (window.app) {
        window.app.renderCurrentView();
        const preview = window.app.loyaltyPreview ? window.app.loyaltyPreview(taxableAmount) : { loyalty: 0 };
        window.app.showToast(`Offering ${offered} points - the shop will price them at ${(preview.loyalty || 0).toFixed ? (preview.loyalty || 0).toFixed(2) : preview.loyalty}.`, 'success');
      }
    },

    // The shop's own loyalty rules, on the settings page, because "should points cut the bill?"
    // is a question for the owner and not for the software. A festive-gift shop and a shop that
    // only wants a spend-and-earn card both get what they wrote here.
    getLoyaltyPolicyCardHTML() {
      const s = this.loyaltySettings();
      const money = (v) => (window.app && window.app.formatCurrency)
        ? window.app.formatCurrency(Number(v) || 0)
        : `GH₵${(Number(v) || 0).toFixed(2)}`;
      // What the scheme actually gives back, stated as a percentage, because "1 point per GH₵1
      // at GH₵0.01 a point" is a sentence nobody reasons with. This is the number the owner is
      // really setting.
      const returnPct = Math.round(s.perUnit * s.rate * 1000) / 10;
      const esc = (v) => window.app.escapeHtml(String(v));

      const row = (label, hint, control) => `
        <div style="display: flex; align-items: center; justify-content: space-between; gap: 1rem; padding: 0.6rem 0; border-bottom: 1px solid var(--slate-100); flex-wrap: wrap;">
          <div>
            <div style="font-weight: 700; font-size: 0.85rem; color: var(--slate-800);">${label}</div>
            <div style="font-size: 0.73rem; color: var(--slate-500);">${hint}</div>
          </div>
          ${control}
        </div>`;

      const numberBox = (id, value, step, min, max) => `
        <input type="number" id="${id}" value="${esc(value)}" step="${step}" min="${min}" max="${max}"
          style="width: 110px; text-align: right; font-weight: 700;" class="form-control">`;

      const checkbox = (id, checked) => `
        <input type="checkbox" id="${id}" ${checked ? 'checked' : ''} style="width: 18px; height: 18px; cursor: pointer;">`;

      return `
        <div style="background: #ffffff; border: 1.5px solid var(--slate-200); border-radius: var(--radius-md); padding: 1.25rem; margin-bottom: 1.5rem;">
          <div style="display: flex; align-items: center; gap: 0.75rem; margin-bottom: 0.85rem;">
            <div style="width: 40px; height: 40px; border-radius: 10px; background: #f59e0b; color: #ffffff; display: flex; align-items: center; justify-content: center; font-size: 1.1rem;">
              <i class="fa-solid fa-gift"></i>
            </div>
            <div style="flex: 1;">
              <h4 style="margin: 0; font-size: 1rem; font-weight: 700; color: var(--slate-900);">Loyalty &amp; Rewards Policy</h4>
              <p style="margin: 0; font-size: 0.78rem; color: var(--slate-500);">You set what points are worth. The server prices every receipt off these figures - the till cannot change them.</p>
            </div>
            <span style="font-size: 0.78rem; font-weight: 700; color: var(--slate-600);">Giving back ${returnPct}%</span>
          </div>

          ${row('Run a loyalty scheme', 'Switched off, no member earns or spends points and the counter stops showing the widget.', checkbox('lp-enabled', s.enabled))}
          ${row('Points earned per ' + money(1) + ' of goods', 'A GH₵100 receipt at 1 point earns 100 points. Zero pauses earning without wiping anybody&rsquo;s balance.', numberBox('lp-per-unit', s.perUnit, '0.01', '0', '1000'))}
          ${row('Value of one point off the bill', 'Points come off the goods only, never off the tax the shop holds for the revenue authority.', numberBox('lp-rate', s.rate, '0.001', '0', '1'))}
          ${row('Let points be handed in at the counter', 'Off, a member keeps accumulating and the till will not offer the redemption.', checkbox('lp-counter', s.redeemAtCounter))}
          ${row('Honour a tier&rsquo;s percentage off', 'Silver 5%, Gold 10%, Platinum 15% - applied by the server from the tier the member already holds, off what is left after your discount.', checkbox('lp-perks', s.tierPerks))}

          <div style="display: flex; align-items: center; justify-content: space-between; gap: 1rem; margin-top: 0.9rem; flex-wrap: wrap;">
            <span style="font-size: 0.73rem; color: var(--slate-500);">Tiers are reached on points held: 500 Silver, 2,000 Gold, 5,000 Platinum.</span>
            <button type="button" class="btn btn-primary btn-sm" onclick="app.saveLoyaltyPolicy(this)">
              <i class="fa-solid fa-floppy-disk"></i> Save loyalty policy
            </button>
          </div>
        </div>
      `;
    },

    async saveLoyaltyPolicy(btn) {
      const val = (id) => document.getElementById(id);
      const read = (id) => {
        const el = val(id);
        return el ? el.value : '';
      };
      const perUnit = Number(read('lp-per-unit'));
      const rate = Number(read('lp-rate'));
      if (!Number.isFinite(perUnit) || perUnit < 0 || perUnit > 1000) {
        window.app.showToast('Points per cedi must be a number between 0 and 1000.', 'warning');
        return;
      }
      if (!Number.isFinite(rate) || rate < 0 || rate > 1) {
        window.app.showToast('A point can be worth between 0 and 1 of your currency.', 'warning');
        return;
      }

      const payload = {
        action: 'set_loyalty_policy',
        loyalty_enabled: val('lp-enabled').checked ? 1 : 0,
        loyalty_points_per_currency: perUnit,
        loyalty_redemption_rate: rate,
        loyalty_redeem_at_counter: val('lp-counter').checked ? 1 : 0,
        loyalty_tier_perks: val('lp-perks').checked ? 1 : 0
      };

      if (btn) { btn.disabled = true; }
      try {
        const res = await fetch('api/endpoints/profile.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || !data.success) {
          throw new Error((data && data.message) || 'The server refused the policy (HTTP ' + res.status + ')');
        }
        // Keep the till's copy of the profile in step with what the server just stored, so the
        // widget and the cart preview price the next customer off the new rule.
        if (window.app.storeProfile) {
          Object.assign(window.app.storeProfile, {
            loyalty_enabled: payload.loyalty_enabled,
            loyalty_points_per_currency: payload.loyalty_points_per_currency,
            loyalty_redemption_rate: payload.loyalty_redemption_rate,
            loyalty_redeem_at_counter: payload.loyalty_redeem_at_counter,
            loyalty_tier_perks: payload.loyalty_tier_perks
          });
        }
        window.app.showToast('Loyalty policy saved.', 'success');
        window.app.renderCurrentView();
      } catch (e) {
        window.app.showToast('Could not save the loyalty policy: ' + e.message, 'danger');
        if (btn) { btn.disabled = false; }
      }
    },

    // A shop that promises "500 points for signing up", or that rung a redemption twice, needs
    // somewhere to say so. The server writes it to the points ledger with the owner's name and
    // this note against it, which is what makes a disputed balance answerable later.
    async adjustCustomerLoyalty(customerId) {
      const cust = (window.app.customers || []).find(c => c.id === customerId);
      if (!cust) return;
      if (!window.app.isOnline) {
        window.app.showToast('The till is offline. Points are a promise the shop keeps on its book, so they move only when the server can write the note.', 'warning');
        return;
      }

      const held = Number(cust.loyalty_points || 0);
      const entered = await window.app.showPromptModal({
        title: 'Gift or correct points',
        desc: `${cust.name} holds ${held.toLocaleString()} points (${cust.loyalty_tier || 'BRONZE'}). A positive number adds, a negative one takes off.`,
        label: 'Points to add or remove',
        placeholder: 'e.g. 500 or -50',
        icon: 'fa-gift',
        confirmText: 'Continue'
      });
      if (entered === null) return;
      const points = Number(String(entered).replace(/[^0-9.\-]/g, ''));
      if (!Number.isFinite(points) || points === 0) {
        window.app.showToast('Give a number of points, positive or negative.', 'warning');
        return;
      }

      const note = await window.app.showPromptModal({
        title: 'Why are these points moving?',
        desc: 'Kept on the ledger next to the balance. "Welcome bonus", "rung twice last Saturday" - whatever a member would accept as the reason.',
        label: 'Note',
        icon: 'fa-pen',
        confirmText: 'Write to the ledger'
      });
      if (!note) { window.app.showToast('Nothing was changed - the note is what makes the gift explainable.', 'info'); return; }

      try {
        const res = await window.app.apiFetch('api/endpoints/customers.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'adjust_loyalty', customer_id: customerId, points, note })
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok || !data.success) {
          throw new Error((data && data.message) || 'The server refused the adjustment (HTTP ' + res.status + ')');
        }
        const idx = window.app.customers.findIndex(c => c.id === customerId);
        if (idx >= 0) {
          window.app.customers[idx] = {
            ...window.app.customers[idx],
            loyalty_points: data.loyalty.points_balance,
            loyalty_tier: data.loyalty.tier
          };
          await localDB.customers.put(window.app.customers[idx]);
        }
        window.app.showToast(`${points > 0 ? 'Gave' : 'Took'} ${Math.abs(points).toLocaleString()} points. ${cust.name} now holds ${Number(data.loyalty.points_balance).toLocaleString()} (${data.loyalty.tier}).`, 'success');
        window.app.renderCurrentView();
      } catch (e) {
        window.app.showToast('Points not adjusted: ' + e.message, 'danger');
      }
    },

    // =========================================================================
    // 8. OMNICHANNEL E-COMMERCE BRIDGE MODAL
    // =========================================================================
    async openEcommerceModal() {
      const modal = document.getElementById('ecommerce-modal');
      if (!modal) return;
      modal.classList.add('active');

      const origin = window.location.origin;
      const path = window.location.pathname.replace(/\/index\.html.*$/, '').replace(/\/+$/, '');
      const baseApi = `${origin}${path}/api/endpoints/ecommerce_sync.php`;

      const webhookUrlInput = document.getElementById('ec-webhook-url');
      if (webhookUrlInput) {
        webhookUrlInput.value = `${baseApi}?action=webhook&channel=woocommerce`;
      }

      const stockFeedInput = document.getElementById('ec-export-url');
      if (stockFeedInput) {
        stockFeedInput.value = `${baseApi}?action=export_stock&token=PASTE-YOUR-STOREFLOW_ECOMMERCE_SECRET`;
      }

      const statContainer = document.getElementById('ec-stats-summary');
      if (!statContainer) return;

      statContainer.innerHTML = '<span style="color: var(--slate-500);"><i class="fa-solid fa-spinner fa-spin"></i> Checking sync status...</span>';

      const money = (v) => (window.app.formatCurrency ? window.app.formatCurrency(Number(v) || 0) : `GH₵${(Number(v) || 0).toFixed(2)}`);

      try {
        const res = await fetch('api/endpoints/ecommerce_sync.php?action=status');
        const data = await res.json();
        if (!res.ok || !data.success) throw new Error('bridge');
        const stats = data.stats || {};
        const open = data.secret_configured === true;
        statContainer.innerHTML = `
          ${open ? '' : `<div style="background: #fffbeb; border: 1px solid #fcd34d; border-radius: 8px; padding: 0.75rem 0.9rem; margin-bottom: 0.75rem; font-size: 0.8rem; color: #92400e; line-height: 1.45;">
            <i class="fa-solid fa-triangle-exclamation"></i> <strong>This till is not taking online orders yet.</strong>
            It has no webhook secret, so it refuses every order a storefront sends. Set
            <code style="font-size: 0.75rem;">STOREFLOW_ECOMMERCE_SECRET</code> in <code style="font-size: 0.75rem;">api/config/config.php</code>
            to a long random string and put the same string in WooCommerce or Shopify.
          </div>`}
          <div style="display: flex; gap: 1rem; align-items: center; justify-content: space-around; background: #f8fafc; border: 1px solid var(--slate-200); border-radius: 8px; padding: 0.9rem;">
            <div style="text-align: center;">
              <div style="font-size: 0.75rem; color: var(--slate-500); text-transform: uppercase; font-weight: 700;">Bridge</div>
              <div style="font-size: 1.1rem; font-weight: 700; color: ${open ? '#166534' : '#b45309'};">
                <i class="fa-solid ${open ? 'fa-circle-check' : 'fa-circle-minus'}"></i> ${open ? 'Open' : 'Closed'}
              </div>
            </div>
            <div style="text-align: center;">
              <div style="font-size: 0.75rem; color: var(--slate-500); text-transform: uppercase; font-weight: 700;">Orders waiting</div>
              <div style="font-size: 1.1rem; font-weight: 700; color: var(--slate-800);">${Number(stats.orders_waiting) || 0}</div>
            </div>
            <div style="text-align: center;">
              <div style="font-size: 0.75rem; color: var(--slate-500); text-transform: uppercase; font-weight: 700;">Waiting, at shelf prices</div>
              <div style="font-size: 1.1rem; font-weight: 700; color: #4338ca;">${money(stats.orders_waiting_value || 0)}</div>
            </div>
            <div style="text-align: center;">
              <div style="font-size: 0.75rem; color: var(--slate-500); text-transform: uppercase; font-weight: 700;">Rung up</div>
              <div style="font-size: 1.1rem; font-weight: 700; color: var(--slate-800);">${Number(stats.orders_collected) || 0}</div>
            </div>
          </div>
          <p style="margin: 0.6rem 0 0 0; font-size: 0.75rem; color: var(--slate-600); line-height: 1.45;">
            <i class="fa-solid fa-circle-info" style="color: #0284c7;"></i>
            An online order arrives on the <strong>Quotations</strong> page as a request for goods. It is not a sale, and it has
            not taken anything off the shelf - open it there, check the lines against your own prices, then ring it at the
            register when the money changes hands.
          </p>
        `;
      } catch (e) {
        statContainer.innerHTML = '<span style="color: #ef4444;"><i class="fa-solid fa-circle-exclamation"></i> Bridge offline</span>';
      }
    },

    closeEcommerceModal() {
      const modal = document.getElementById('ecommerce-modal');
      if (modal) modal.classList.remove('active');
    },

    copyInputText(inputId, btn) {
      const el = document.getElementById(inputId);
      if (!el) return;
      el.select();
      navigator.clipboard.writeText(el.value).then(() => {
        const orig = btn.innerHTML;
        btn.innerHTML = '<i class="fa-solid fa-check"></i> Copied!';
        setTimeout(() => btn.innerHTML = orig, 1800);
      });
    }
  };

  function attachEnterprise() {
    if (window.app) {
      Object.assign(window.app, enterpriseExt);
      enterpriseExt.applyOperatingModeUI();
    } else {
      setTimeout(attachEnterprise, 100);
    }
  }
  attachEnterprise();

})(window);
