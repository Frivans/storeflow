Object.assign(StoreApp.prototype, {
  // The sizes a purchase order was actually bought in. Deliberately not one total number:
  // 120 eggs and 10 bags of rice add up to "130" of nothing, so each line keeps its own
  // size and the loose count inside it. A purchase the till saved offline has the lines
  // under `items`, a purchase from the server has them under `lines`.
  purchaseSummaryLines(p) {
    const raw = Array.isArray(p.lines) && p.lines.length ? p.lines : (Array.isArray(p.items) ? p.items : []);
    return raw.map(l => {
      const qty = Math.max(0, Number(l.quantity || 0));
      // A line that carries no size at all is one taken before the till stamped the pack onto
      // the order. Ask its product's own catalogue rather than reading it as one loose unit:
      // counting 15 crates as 15 eggs is what left a delivery a thirtieth short on the shelf,
      // at a cost per egg thirty times the invoice.
      let mult = Math.max(1, Number(l.multiplier || 0));
      let loose = Number(l.base_quantity || 0);
      if (mult <= 1 && loose <= 0) {
        const lineProduct = (this.products || []).find(x => String(x.id) === String(l.product_id || ''));
        mult = Math.max(1, Number(this.productUnitOf(lineProduct, l.unit || l.base_unit || '')?.size_in_base || 1));
      }
      if (loose <= 0) loose = qty * mult;
      const size = String(l.unit || l.base_unit || p.base_unit || 'pcs').trim() || 'pcs';
      // null means nobody has stood at the back door and counted this line. It is not zero:
      // zero is a delivery that arrived empty, and the shopkeeper needs to tell the two apart.
      const counted = (l.counted_quantity === null || l.counted_quantity === undefined || l.counted_quantity === '')
        ? null : Math.max(0, Number(l.counted_quantity));
      return {
        id: String(l.id || ''),
        productId: String(l.product_id || ''),
        name: l.product_name || l.name || 'Stock item',
        qty: parseFloat(qty.toFixed(3)),
        size,
        loose: parseFloat(loose.toFixed(3)),
        baseUnit: String(l.base_unit || size).trim() || size,
        packed: mult > 1,
        multiplier: mult,
        cost: Math.max(0, Number(l.cost_price || (qty > 0 ? (l.subtotal || 0) / qty : 0))),
        counted,
        countedLoose: counted === null ? null : parseFloat((counted * mult).toFixed(3)),
        // The lot travels with the order, not with the count: the shop says at ordering what
        // batch it expects, and the delivery books that same batch for however many arrived.
        batchNumber: String(l.batch_number || '').trim(),
        expiryDate: String(l.expiry_date || '').trim(),
        mfgDate: String(l.mfg_date || '').trim(),
      };
    });
  },

  // Whether an order's delivery has been answered. A purchase the till saved itself keeps the
  // status the server would give it; a row straight out of the books has it already.
  purchaseOrderState(p) {
    const st = String(p.status || 'PENDING').toUpperCase();
    if (st === 'COUNTED' || st === 'RECEIVED') return 'COUNTED';
    if (st === 'CANCELLED') return 'CANCELLED';
    return 'PENDING';
  },

  purchaseStatusBadge(p) {
    const state = this.purchaseOrderState(p);
    if (state === 'CANCELLED') {
      return '<span class="badge badge-danger"><i class="fa-solid fa-ban"></i> Cancelled</span>';
    }
    if (state === 'COUNTED') {
      return '<span class="badge badge-success"><i class="fa-solid fa-check"></i> Counted in</span>';
    }
    return '<span class="badge badge-warning"><i class="fa-solid fa-truck-fast"></i> Awaiting delivery</span>';
  },

  purchaseSummaryHtml(p, maxLines = 3) {
    const lines = this.purchaseSummaryLines(p);
    if (lines.length === 0) {
      // Nothing itemised behind this order. Say so rather than invent a product name, and
      // rather than the bare "N products" that told the shopkeeper nothing.
      return `<span style="color: var(--slate-400); font-size: 0.8rem;">${Number(p.total_products_count || 0)} line(s) &mdash; open the voucher for the items</span>`;
    }
    // Once a person has counted the delivery, the screen says what came rather than what was
    // asked for - the two are different numbers whenever the truck went short, and the shop
    // pays, stocks and owes off the first one.
    const shown = lines.slice(0, maxLines).map(l => {
      const asked = `${l.qty} ${this.escapeHtml(l.size)}`;
      const short = l.counted !== null && l.counted !== l.qty;
      const main = l.counted === null
        ? asked
        : (short ? `${l.counted} came / ${l.qty} ordered ${this.escapeHtml(l.size)}` : `${l.counted} ${this.escapeHtml(l.size)}`);
      const loose = l.counted === null ? l.loose : (l.counted * Math.max(1, l.multiplier));
      return `
      <div style="line-height: 1.35;">
        <span style="font-weight: 600;">${this.escapeHtml(l.name)}</span>
        <span style="color: var(--slate-600); font-size: 0.8rem;">
          &nbsp;${main}${l.packed ? ` <span style="color: var(--slate-400);">(= ${parseFloat(loose.toFixed(3))} ${this.escapeHtml(l.baseUnit)})</span>` : ''}
        </span>
      </div>`;
    }).join('');
    const rest = lines.length > maxLines
      ? `<div style="color: var(--slate-500); font-size: 0.78rem;">+ ${lines.length - maxLines} more on the voucher</div>`
      : '';
    return shown + rest;
  },

  resetPurchasesFilters() {
    this.purchaseSearchQuery = '';
    this.purchaseDateFilter = 'ALL';
    this.purchaseFromDate = '';
    this.purchaseToDate = '';
    this.purchaseDeliveryFilter = 'ALL';
    this.purchasePaymentFilter = 'ALL';
    this.purchaseSupplierFilter = 'ALL';
    this.purchaseSortFilter = 'DATE_DESC';
    this.render();
  },

  getPurchasesHTML() {
    const allPurchases = this.purchases || [];
    const totalOrders = allPurchases.length;
    const totalSpend = allPurchases.reduce((s, p) => s + Number(p.total_cost || 0), 0);
    const waitingOrders = allPurchases.filter(p => this.purchaseOrderState(p) === 'PENDING');
    const waitingValue = waitingOrders.reduce((s, p) => s + Number(p.total_cost || 0), 0);
    const countedOrders = allPurchases.filter(p => this.purchaseOrderState(p) === 'COUNTED');
    const unpaidPurchases = allPurchases.filter(p => {
      const st = String(p.payment_status || '').toUpperCase();
      return st === 'CREDIT' || st === 'UNPAID' || st === 'PARTIAL';
    });
    const unpaidAmount = unpaidPurchases.reduce((s, p) => s + Number(p.total_cost || 0), 0);

    // Extract unique supplier names for filter
    const supplierNames = Array.from(new Set(
      allPurchases.map(p => (p.supplier_name || '').trim()).filter(Boolean)
    )).sort();

    // ── Apply Filtering ────────────────────────────────────────────────────────
    let filtered = [...allPurchases];

    const q = (this.purchaseSearchQuery || '').trim().toLowerCase();
    if (q) {
      filtered = filtered.filter(p => {
        const orderNum = (p.order_number || '').toLowerCase();
        const supName = (p.supplier_name || '').toLowerCase();
        const lines = this.purchaseLines(p);
        const itemNames = lines.map(l => (l.name || '').toLowerCase()).join(' ');
        return orderNum.includes(q) || supName.includes(q) || itemNames.includes(q);
      });
    }

    // Date filtering
    const datePreset = this.purchaseDateFilter || 'ALL';
    if (datePreset !== 'ALL') {
      const today = new Date();
      const todayStr = today.toISOString().split('T')[0];

      if (datePreset === 'TODAY') {
        filtered = filtered.filter(p => (p.order_date || '').startsWith(todayStr));
      } else if (datePreset === 'YESTERDAY') {
        const y = new Date(today);
        y.setDate(y.getDate() - 1);
        const yStr = y.toISOString().split('T')[0];
        filtered = filtered.filter(p => (p.order_date || '').startsWith(yStr));
      } else if (datePreset === 'LAST_7_DAYS') {
        const d7 = new Date(today);
        d7.setDate(d7.getDate() - 7);
        const d7Str = d7.toISOString().split('T')[0];
        filtered = filtered.filter(p => (p.order_date || '').split(' ')[0] >= d7Str && (p.order_date || '').split(' ')[0] <= todayStr);
      } else if (datePreset === 'THIS_MONTH') {
        const ym = todayStr.substring(0, 7);
        filtered = filtered.filter(p => (p.order_date || '').startsWith(ym));
      } else if (datePreset === 'CUSTOM') {
        if (this.purchaseFromDate) {
          filtered = filtered.filter(p => (p.order_date || '').split(' ')[0] >= this.purchaseFromDate);
        }
        if (this.purchaseToDate) {
          filtered = filtered.filter(p => (p.order_date || '').split(' ')[0] <= this.purchaseToDate);
        }
      }
    }

    // Delivery Status Filter
    const deliveryFilter = this.purchaseDeliveryFilter || 'ALL';
    if (deliveryFilter !== 'ALL') {
      filtered = filtered.filter(p => this.purchaseOrderState(p) === deliveryFilter);
    }

    // Payment Status Filter
    const paymentFilter = this.purchasePaymentFilter || 'ALL';
    if (paymentFilter === 'PAID') {
      filtered = filtered.filter(p => {
        const st = String(p.payment_status || 'PAID').toUpperCase();
        return st === 'PAID';
      });
    } else if (paymentFilter === 'CREDIT') {
      filtered = filtered.filter(p => {
        const st = String(p.payment_status || '').toUpperCase();
        return st === 'CREDIT' || st === 'UNPAID';
      });
    } else if (paymentFilter === 'PARTIAL') {
      filtered = filtered.filter(p => String(p.payment_status || '').toUpperCase() === 'PARTIAL');
    }

    // Supplier Filter
    const supplierFilter = this.purchaseSupplierFilter || 'ALL';
    if (supplierFilter !== 'ALL') {
      filtered = filtered.filter(p => (p.supplier_name || '').trim().toLowerCase() === supplierFilter.toLowerCase());
    }

    // Sorting Filter
    const sortFilter = this.purchaseSortFilter || 'DATE_DESC';
    if (sortFilter === 'DATE_ASC') {
      filtered.sort((a, b) => (a.order_date || '').localeCompare(b.order_date || ''));
    } else if (sortFilter === 'COST_DESC') {
      filtered.sort((a, b) => Number(b.total_cost || 0) - Number(a.total_cost || 0));
    } else if (sortFilter === 'COST_ASC') {
      filtered.sort((a, b) => Number(a.total_cost || 0) - Number(b.total_cost || 0));
    } else if (sortFilter === 'ORDER_NUM') {
      filtered.sort((a, b) => (a.order_number || '').localeCompare(b.order_number || ''));
    } else {
      // Default: DATE_DESC
      filtered.sort((a, b) => (b.order_date || '').localeCompare(a.order_date || ''));
    }

    const hasActiveFilters = Boolean(
      (this.purchaseSearchQuery && this.purchaseSearchQuery.trim()) ||
      (this.purchaseDateFilter && this.purchaseDateFilter !== 'ALL') ||
      (this.purchaseDeliveryFilter && this.purchaseDeliveryFilter !== 'ALL') ||
      (this.purchasePaymentFilter && this.purchasePaymentFilter !== 'ALL') ||
      (this.purchaseSupplierFilter && this.purchaseSupplierFilter !== 'ALL') ||
      (this.purchaseSortFilter && this.purchaseSortFilter !== 'DATE_DESC')
    );

    return `
      <!-- Top KPI Summary Cards for Factory Purchases -->
      <div class="kpi-grid" style="grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); margin-bottom: 1.5rem;">
        <div class="kpi-card">
          <div class="kpi-icon-wrapper" style="background: #e0f2fe; color: #0284c7;">
            <i class="fa-solid fa-truck-ramp-box"></i>
          </div>
          <div class="kpi-content">
            <div class="kpi-label">Total Purchase Orders</div>
            <div class="kpi-value">${Number(totalOrders).toLocaleString()}</div>
            <div class="kpi-subtext" style="color: var(--slate-500);">${countedOrders.length} Counted &bull; ${waitingOrders.length} Pending</div>
          </div>
        </div>

        <div class="kpi-card">
          <div class="kpi-icon-wrapper" style="background: #ecfdf5; color: #16a34a;">
            <i class="fa-solid fa-file-invoice-dollar"></i>
          </div>
          <div class="kpi-content">
            <div class="kpi-label">Total Stock-In Spend</div>
            <div class="kpi-value" style="color: #16a34a;">${this.formatCurrency(totalSpend)}</div>
            <div class="kpi-subtext" style="color: var(--slate-500);">Gross factory invoice value</div>
          </div>
        </div>

        <div class="kpi-card ${waitingOrders.length > 0 ? 'kpi-alert-pulse' : ''}">
          <div class="kpi-icon-wrapper" style="background: #fffbeb; color: #d97706;">
            <i class="fa-solid fa-truck-fast"></i>
          </div>
          <div class="kpi-content">
            <div class="kpi-label">Pending Deliveries</div>
            <div class="kpi-value" style="color: ${waitingOrders.length > 0 ? '#d97706' : 'inherit'};">
              ${waitingOrders.length} <span style="font-size: 0.85rem; font-weight: 600;">order(s)</span>
            </div>
            <div class="kpi-subtext" style="color: #b45309; font-weight: 600;">
              ${waitingOrders.length > 0 ? `${this.formatCurrency(waitingValue)} on the road` : 'All deliveries counted in'}
            </div>
          </div>
        </div>

        <div class="kpi-card">
          <div class="kpi-icon-wrapper" style="background: ${unpaidAmount > 0 ? '#fef2f2' : '#f8fafc'}; color: ${unpaidAmount > 0 ? '#dc2626' : '#64748b'};">
            <i class="fa-solid fa-hand-holding-dollar"></i>
          </div>
          <div class="kpi-content">
            <div class="kpi-label">Supplier Payables (Unpaid)</div>
            <div class="kpi-value" style="color: ${unpaidAmount > 0 ? '#dc2626' : 'inherit'};">${this.formatCurrency(unpaidAmount)}</div>
            <div class="kpi-subtext" style="color: var(--slate-500);">${unpaidPurchases.length} order(s) on credit / partial</div>
          </div>
        </div>
      </div>

      <div class="panel">
        <div class="panel-header">
          <h3><i class="fa-solid fa-truck-ramp-box"></i> Factory Purchase Orders (Stock In)</h3>
          <button class="btn btn-success" onclick="app.openNewPurchaseModal()">
            <i class="fa-solid fa-plus"></i> Record Factory Purchase
          </button>
        </div>
        <div class="panel-body">
          <p style="font-size: 0.85rem; color: var(--slate-600); margin-bottom: 1rem;">
            Recording an order tells the factory what to send and books the money. It does not put anything on the shelf &mdash;
            <strong>Count In</strong> is where a person writes down what actually came, and only that reaches stock.
          </p>

          ${waitingOrders.length > 0 ? `
            <div style="display:flex;align-items:center;gap:0.5rem;flex-wrap:wrap;background:#fffbeb;border:1px solid #fde68a;border-radius:6px;padding:0.5rem 0.75rem;margin-bottom:1rem;font-size:0.83rem;color:#92400e;">
              <i class="fa-solid fa-truck-fast"></i>
              <strong>${waitingOrders.length}</strong> order(s) not yet counted in &mdash; ${this.formatCurrency(waitingValue)} of goods still at the factory and nothing of it on your shelf.
            </div>
          ` : ''}

          <!-- Comprehensive Factory Purchase Orders Filter Bar -->
          <div style="background: var(--slate-50); border: 1px solid var(--slate-200); border-radius: 8px; padding: 0.85rem 1rem; margin-bottom: 1.25rem; display: flex; flex-wrap: wrap; gap: 0.75rem; align-items: center; justify-content: space-between;">
            <div style="display: flex; gap: 0.65rem; flex-wrap: wrap; align-items: center; flex: 1;">
              <!-- Search Input -->
              <div style="position: relative; min-width: 240px; flex: 1;">
                <i class="fa-solid fa-magnifying-glass" style="position: absolute; left: 0.75rem; top: 50%; transform: translateY(-50%); color: var(--slate-400); font-size: 0.85rem;"></i>
                <input type="text" id="purchase-search-input" class="form-control" placeholder="Search order #, supplier, or product..." style="padding-left: 2.1rem;" value="${this.escapeHtml(this.purchaseSearchQuery || '')}">
              </div>

              <!-- Date Filter Preset -->
              <select id="purchase-date-filter" class="form-control" style="width: auto; min-width: 140px; font-weight: 600;">
                <option value="ALL" ${(!this.purchaseDateFilter || this.purchaseDateFilter === 'ALL') ? 'selected' : ''}>All Dates</option>
                <option value="TODAY" ${this.purchaseDateFilter === 'TODAY' ? 'selected' : ''}>Today</option>
                <option value="YESTERDAY" ${this.purchaseDateFilter === 'YESTERDAY' ? 'selected' : ''}>Yesterday</option>
                <option value="LAST_7_DAYS" ${this.purchaseDateFilter === 'LAST_7_DAYS' ? 'selected' : ''}>Last 7 Days</option>
                <option value="THIS_MONTH" ${this.purchaseDateFilter === 'THIS_MONTH' ? 'selected' : ''}>This Month</option>
                <option value="CUSTOM" ${this.purchaseDateFilter === 'CUSTOM' ? 'selected' : ''}>Custom Range...</option>
              </select>

              <!-- Custom Date Pickers -->
              <div id="purchase-custom-date-container" style="display: ${this.purchaseDateFilter === 'CUSTOM' ? 'flex' : 'none'}; gap: 0.4rem; align-items: center;">
                <input type="date" id="purchase-from-date" class="form-control" style="width: auto; padding: 0.35rem 0.6rem; font-size: 0.85rem;" value="${this.escapeHtml(this.purchaseFromDate || '')}" title="From purchase date">
                <span style="color: var(--slate-400); font-size: 0.8rem;">to</span>
                <input type="date" id="purchase-to-date" class="form-control" style="width: auto; padding: 0.35rem 0.6rem; font-size: 0.85rem;" value="${this.escapeHtml(this.purchaseToDate || '')}" title="To purchase date">
              </div>

              <!-- Delivery Status Filter -->
              <select id="purchase-delivery-filter" class="form-control" style="width: auto; min-width: 155px; font-weight: 600;">
                <option value="ALL" ${(!this.purchaseDeliveryFilter || this.purchaseDeliveryFilter === 'ALL') ? 'selected' : ''}>All Deliveries</option>
                <option value="COUNTED" ${this.purchaseDeliveryFilter === 'COUNTED' ? 'selected' : ''}>Counted In (Stocked)</option>
                <option value="PENDING" ${this.purchaseDeliveryFilter === 'PENDING' ? 'selected' : ''}>Pending (On Road)</option>
                <option value="CANCELLED" ${this.purchaseDeliveryFilter === 'CANCELLED' ? 'selected' : ''}>Cancelled</option>
              </select>

              <!-- Payment Status Filter -->
              <select id="purchase-payment-filter" class="form-control" style="width: auto; min-width: 145px; font-weight: 600;">
                <option value="ALL" ${(!this.purchasePaymentFilter || this.purchasePaymentFilter === 'ALL') ? 'selected' : ''}>All Payments</option>
                <option value="PAID" ${this.purchasePaymentFilter === 'PAID' ? 'selected' : ''}>Paid in Full</option>
                <option value="CREDIT" ${this.purchasePaymentFilter === 'CREDIT' ? 'selected' : ''}>Credit / Unpaid</option>
                <option value="PARTIAL" ${this.purchasePaymentFilter === 'PARTIAL' ? 'selected' : ''}>Partially Paid</option>
              </select>

              <!-- Supplier Filter -->
              ${supplierNames.length > 0 ? `
                <select id="purchase-supplier-filter" class="form-control" style="width: auto; min-width: 160px; font-weight: 600;">
                  <option value="ALL" ${(!this.purchaseSupplierFilter || this.purchaseSupplierFilter === 'ALL') ? 'selected' : ''}>All Suppliers</option>
                  ${supplierNames.map(name => `
                    <option value="${this.escapeHtml(name)}" ${this.purchaseSupplierFilter === name ? 'selected' : ''}>${this.escapeHtml(name)}</option>
                  `).join('')}
                </select>
              ` : ''}

              <!-- Sorting Filter -->
              <select id="purchase-sort-filter" class="form-control" style="width: auto; min-width: 155px; font-weight: 600;">
                <option value="DATE_DESC" ${(!this.purchaseSortFilter || this.purchaseSortFilter === 'DATE_DESC') ? 'selected' : ''}>Newest First</option>
                <option value="DATE_ASC" ${this.purchaseSortFilter === 'DATE_ASC' ? 'selected' : ''}>Oldest First</option>
                <option value="COST_DESC" ${this.purchaseSortFilter === 'COST_DESC' ? 'selected' : ''}>Highest Cost</option>
                <option value="COST_ASC" ${this.purchaseSortFilter === 'COST_ASC' ? 'selected' : ''}>Lowest Cost</option>
                <option value="ORDER_NUM" ${this.purchaseSortFilter === 'ORDER_NUM' ? 'selected' : ''}>Order # (A &rarr; Z)</option>
              </select>
            </div>

            ${hasActiveFilters ? `
              <button type="button" class="btn btn-outline btn-sm" onclick="app.resetPurchasesFilters()" style="color: var(--slate-600); font-weight: 600;" title="Clear all active purchase filters">
                <i class="fa-solid fa-xmark"></i> Clear Filters
              </button>
            ` : ''}
          </div>

          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Order #</th>
                  <th>Factory / Supplier</th>
                  <th>Purchase Date</th>
                  <th>What Came In</th>
                  <th>Total Cost</th>
                  <th>Status</th>
                  <th style="text-align: right;">Voucher</th>
                </tr>
              </thead>
              <tbody>
                ${filtered.length > 0 ? filtered.map(p => `
                  <tr>
                    <td style="font-weight: 600; font-family: monospace;">${this.escapeHtml(p.order_number)}</td>
                    <td style="font-weight: 600;">${this.escapeHtml(p.supplier_name)}</td>
                    <td>${this.escapeHtml(p.order_date)}</td>
                    <td style="font-size: 0.82rem;">${this.purchaseSummaryHtml(p)}</td>
                    <td style="font-weight: 700; color: var(--slate-900);">${this.formatCurrency(p.total_cost)}</td>
                    <td>
                      ${this.purchaseStatusBadge(p)}
                      ${(() => {
                        const st = String(p.payment_status || 'PAID').toUpperCase();
                        if (st === 'PARTIAL') return '<span class="badge badge-warning" style="margin-left: 0.25rem;"><i class="fa-solid fa-clock-rotate-left"></i> Partial</span>';
                        if (st === 'CREDIT' || st === 'UNPAID') return '<span class="badge badge-danger" style="margin-left: 0.25rem;"><i class="fa-solid fa-clock"></i> Credit</span>';
                        return '<span class="badge badge-success" style="margin-left: 0.25rem;"><i class="fa-solid fa-circle-check"></i> Paid</span>';
                      })()}
                    </td>
                    <td style="text-align: right; white-space: nowrap;">
                      ${this.purchaseOrderState(p) === 'PENDING' ? `
                      <button type="button" class="btn btn-sm btn-success" style="padding: 0.3rem 0.6rem; font-size: 0.76rem;" title="The delivery is here: write down what actually came"
                        onclick="event.stopPropagation(); app.openPurchaseCountInModal(${this.jsStr(p.id)})">
                        <i class="fa-solid fa-clipboard-list"></i> Count In
                      </button>
                      <button type="button" class="btn btn-sm btn-outline" style="padding: 0.3rem 0.5rem; font-size: 0.76rem; color: var(--danger); border-color: #fca5a5;" title="Call this order off"
                        onclick="event.stopPropagation(); app.openPurchaseCancelModal(${this.jsStr(p.id)})">
                        <i class="fa-solid fa-ban"></i>
                      </button>` : ''}
                      <button type="button" class="btn btn-sm btn-primary" style="padding: 0.3rem 0.6rem; font-size: 0.76rem;" title="Open, print or save this order's supplier voucher"
                        onclick="event.stopPropagation(); app.openPurchaseVoucherModal(${this.jsStr(p.id)})">
                        <i class="fa-solid fa-file-invoice-dollar"></i> Receipt
                      </button>
                    </td>
                  </tr>
                `).join('') : `
                  <tr>
                    <td colspan="7" style="text-align: center; padding: 3rem; color: var(--slate-500);">
                      <i class="fa-solid fa-truck-ramp-box" style="font-size: 2rem; margin-bottom: 0.5rem; color: var(--slate-400); display: block;"></i>
                      <div style="font-weight: 600; font-size: 1rem; color: var(--slate-700);">No factory purchase orders match your filters</div>
                      <div style="font-size: 0.85rem; margin-top: 0.25rem;">Try modifying your search or resetting filters.</div>
                      ${hasActiveFilters ? `
                        <button class="btn btn-primary btn-sm" style="margin-top: 0.85rem;" onclick="app.resetPurchasesFilters()">Reset All Filters</button>
                      ` : ''}
                    </td>
                  </tr>
                `}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  },

  bindPurchasesEvents() {
    const searchInput = document.getElementById('purchase-search-input');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        clearTimeout(this._purchSearchTimer);
        const val = e.target.value;
        const cursorStart = e.target.selectionStart;
        const cursorEnd = e.target.selectionEnd;
        this._purchSearchTimer = setTimeout(() => {
          this.purchaseSearchQuery = val;
          this.render();
          const nextInput = document.getElementById('purchase-search-input');
          if (nextInput) {
            nextInput.focus();
            if (cursorStart !== null && cursorEnd !== null) {
              nextInput.setSelectionRange(cursorStart, cursorEnd);
            }
          }
        }, 220);
      });
    }

    const dateFilter = document.getElementById('purchase-date-filter');
    if (dateFilter) {
      dateFilter.addEventListener('change', (e) => {
        this.purchaseDateFilter = e.target.value;
        this.render();
      });
    }

    const fromDate = document.getElementById('purchase-from-date');
    if (fromDate) {
      fromDate.addEventListener('change', (e) => {
        this.purchaseFromDate = e.target.value;
        this.render();
      });
    }

    const toDate = document.getElementById('purchase-to-date');
    if (toDate) {
      toDate.addEventListener('change', (e) => {
        this.purchaseToDate = e.target.value;
        this.render();
      });
    }

    const deliveryFilter = document.getElementById('purchase-delivery-filter');
    if (deliveryFilter) {
      deliveryFilter.addEventListener('change', (e) => {
        this.purchaseDeliveryFilter = e.target.value;
        this.render();
      });
    }

    const paymentFilter = document.getElementById('purchase-payment-filter');
    if (paymentFilter) {
      paymentFilter.addEventListener('change', (e) => {
        this.purchasePaymentFilter = e.target.value;
        this.render();
      });
    }

    const supplierFilter = document.getElementById('purchase-supplier-filter');
    if (supplierFilter) {
      supplierFilter.addEventListener('change', (e) => {
        this.purchaseSupplierFilter = e.target.value;
        this.render();
      });
    }

    const sortFilter = document.getElementById('purchase-sort-filter');
    if (sortFilter) {
      sortFilter.addEventListener('change', (e) => {
        this.purchaseSortFilter = e.target.value;
        this.render();
      });
    }
  },

  openNewPurchaseModal(preselectedProductId = null) {
    const vendorSelect = document.getElementById('purchase-vendor-select');
    if (vendorSelect) {
      vendorSelect.innerHTML = `
        <option value="">-- Select Registered Vendor or Type Name --</option>
        ${this.vendors.map(v => {
          // A supplier can hold our money, not only owe us goods. Showing only the debt side
          // is how a factory with a GH₵40,000 advance in hand looked identical to one the
          // shop had never paid, right at the moment the next deposit is being typed in.
          const bal = Number(v.balance || 0);
          const hint = bal > 0 ? `(Owed: ${this.formatCurrency(bal)})`
            : bal < 0 ? `(They hold: ${this.formatCurrency(Math.abs(bal))})` : '';
          return `
          <option value="${this.escapeHtml(v.id)}">${this.escapeHtml(v.name)} ${hint}</option>
        `; }).join('')}
        <option value="__custom__">+ Enter Custom Factory / One-Off Supplier</option>
      `;
      vendorSelect.value = '';
    }
    const customGrp = document.getElementById('grp-purchase-supplier-custom');
    if (customGrp) customGrp.style.display = 'none';

    const supNameInput = document.getElementById('purchase-supplier-name');
    if (supNameInput) supNameInput.value = '';

    const supContact = document.getElementById('purchase-supplier-contact');
    if (supContact) supContact.value = '';

    const payStatus = document.getElementById('purchase-payment-status');
    if (payStatus) payStatus.value = 'PAID';

    const partRow = document.getElementById('purchase-partial-row');
    if (partRow) partRow.style.display = 'none';

    const amtPaidInput = document.getElementById('purchase-amount-paid');
    if (amtPaidInput) amtPaidInput.value = '0.00';

    document.getElementById('purchase-date').value = new Date().toISOString().slice(0, 10);
    document.getElementById('purchase-notes').value = '';

    const targetProd = (preselectedProductId && this.products.find(p => p.id === preselectedProductId)) || this.products[0];
    const defaultExp = targetProd?.has_expiry == 1 && targetProd?.expiry_date ? targetProd.expiry_date : '';

    this.purchaseModalItems = [
      {
        product_id: targetProd?.id || '',
        quantity: 10,
        cost_price: targetProd?.cost_price || 0,
        unit: this.productUnitsOf(targetProd)[0]?.unit_name || targetProd?.unit || 'pcs',
        batch_number: '',
        expiry_date: defaultExp
      }
    ];
    this.renderPurchaseModalItems();
    this.updatePurchaseModalBalanceBadge();

    document.getElementById('purchase-modal').classList.add('active');
  },

  closePurchaseModal() {
    document.getElementById('purchase-modal').classList.remove('active');
  },

  handlePurchaseVendorSelect(vendorId) {
    const customGrp = document.getElementById('grp-purchase-supplier-custom');
    const nameInput = document.getElementById('purchase-supplier-name');
    const contactInput = document.getElementById('purchase-supplier-contact');

    if (vendorId === '__custom__') {
      if (customGrp) customGrp.style.display = 'block';
      if (nameInput) { nameInput.value = ''; nameInput.focus(); }
      if (contactInput) contactInput.value = '';
    } else if (vendorId) {
      if (customGrp) customGrp.style.display = 'none';
      const vendor = this.vendors.find(v => String(v.id) === String(vendorId));
      if (vendor) {
        if (nameInput) nameInput.value = vendor.name;
        if (contactInput) contactInput.value = vendor.phone || vendor.contact_person || '';
      }
    } else {
      if (customGrp) customGrp.style.display = 'none';
      if (nameInput) nameInput.value = '';
      if (contactInput) contactInput.value = '';
    }
    // Changing the supplier changes what the order costs the drawer: the shop may already
    // have money sitting with the one just picked, and the badge has to say so before the
    // cashier reaches for cash it does not need to spend.
    this.updatePurchaseModalBalanceBadge();
  },

  handlePurchasePaymentModeChange(mode) {
    const partRow = document.getElementById('purchase-partial-row');
    const amtPaidInput = document.getElementById('purchase-amount-paid');

    if (mode === 'CREDIT') {
      if (partRow) partRow.style.display = 'flex';
      if (amtPaidInput) {
        amtPaidInput.disabled = false;
        if (!amtPaidInput.value || parseFloat(amtPaidInput.value) <= 0) {
          amtPaidInput.value = '0.00';
        }
      }
    } else {
      if (partRow) partRow.style.display = 'none';
      if (amtPaidInput) {
        amtPaidInput.disabled = false;
        amtPaidInput.value = '0.00';
      }
    }
    this.updatePurchaseModalBalanceBadge();
  },

  // What this order costs, what leaves the drawer, and what the shop already has sitting
  // with the supplier it is about to pay. A negative vendor balance is the shop's own money
  // left at the factory - it handed over GH₵200 for a GH₵180 order and did not take the
  // change - and until now the next GH₵180 order cost GH₵180 of cash again, because nothing
  // in the till knew the change was still there. Everything the badge, the balance row and
  // the saved order report is worked out here, from one set of figures.
  purchaseBalanceState() {
    const r2 = n => Math.round((Number(n) || 0) * 100) / 100;
    const totalCost = r2(this.purchaseModalItems.reduce((sum, item) => sum + ((item.quantity || 0) * (item.cost_price || 0)), 0));
    const mode = document.getElementById('purchase-payment-status')?.value || 'PAID';
    const vendorId = document.getElementById('purchase-vendor-select')?.value || '';
    const vendor = (vendorId && vendorId !== '__custom__')
      ? (this.vendors || []).find(v => String(v.id) === String(vendorId))
      : null;

    const paid = mode === 'PAID'
      ? totalCost
      : r2(Math.max(0, parseFloat(document.getElementById('purchase-amount-paid')?.value) || 0));
    // The supplier holds whatever the account reads in the negative, and only that much:
    // a draw can never exceed the balance, nor what the order still needs.
    const held = r2(Math.max(0, -(Number(vendor?.balance || 0))));
    const stillToSettle = r2(Math.max(0, totalCost - paid));
    const creditApplied = r2(Math.min(held, stillToSettle));
    const remainingDebt = r2(stillToSettle - creditApplied);
    const advance = r2(Math.max(0, paid - totalCost));

    return { vendor, vendorId, totalCost, mode, paid, held, stillToSettle, creditApplied, remainingDebt, advance };
  },

  applyPurchaseCreditFromBalance() {
    const st = this.purchaseBalanceState();
    if (!st.vendor || st.held <= 0.005 || st.stillToSettle <= 0.005) return;

    // "Paid in full" means the whole invoice is covered, not that the whole invoice came
    // out of the drawer today. Reveal the cash box so the split is written down, not just
    // implied, and put in it the amount the shop actually hands over.
    const modeSel = document.getElementById('purchase-payment-status');
    if (modeSel && modeSel.value !== 'CREDIT') {
      modeSel.value = 'CREDIT';
      this.handlePurchasePaymentModeChange('CREDIT');
    }
    const cash = Math.max(0, Math.round((st.totalCost - Math.min(st.held, st.totalCost)) * 100) / 100);
    const box = document.getElementById('purchase-amount-paid');
    if (box) box.value = cash.toFixed(2);
    this.updatePurchaseModalBalanceBadge();
    this.showToast(`${this.formatCurrency(st.creditApplied)} drawn off the balance ${st.vendor.name} is holding; ${this.formatCurrency(cash)} out of the drawer.`, 'success', 6000);
  },

  renderPurchaseCreditRow(st) {
    const row = document.getElementById('purchase-credit-row');
    const note = document.getElementById('purchase-credit-note');
    const btn = document.getElementById('purchase-credit-apply');
    if (!row || !note || !btn) return;

    if (!st.vendor || st.held <= 0.005) {
      row.style.display = 'none';
      return;
    }
    row.style.display = 'flex';
    const who = this.escapeHtml(String(st.vendor.name || 'this supplier'));
    if (st.stillToSettle <= 0.005) {
      note.innerHTML = `<i class="fa-solid fa-wallet"></i> ${this.formatCurrency(st.held)} of the shop's own money is sitting with ${who}. Cash covers this order, so none of it is touched.`;
      btn.style.display = 'none';
    } else {
      note.innerHTML = `<i class="fa-solid fa-wallet"></i> ${this.formatCurrency(st.held)} of the shop's own money is sitting with ${who}. This order still needs ${this.formatCurrency(st.stillToSettle)} &mdash; ${this.formatCurrency(st.creditApplied)} of it can come off that balance instead of the drawer.`;
      btn.style.display = '';
      btn.innerHTML = st.creditApplied >= st.stillToSettle - 0.005
        ? '<i class="fa-solid fa-scale-balanced"></i> Settle it from the balance'
        : `<i class="fa-solid fa-scale-balanced"></i> Take ${this.formatCurrency(st.creditApplied)} off the balance`;
    }
  },

  updatePurchaseModalBalanceBadge() {
    const st = this.purchaseBalanceState();
    this.renderPurchaseCreditRow(st);
    const badge = document.getElementById('purchase-balance-badge');
    if (!badge) return;

    if (st.mode === 'PAID') {
      badge.style.display = 'none';
      return;
    }

    badge.style.display = 'inline-block';
    if (st.advance > 0.01) {
      badge.className = 'badge badge-success';
      badge.innerHTML = `<i class="fa-solid fa-boxes-packing"></i> Covered, with <strong>${this.formatCurrency(st.advance)}</strong> held as an advance`;
    } else if (st.creditApplied > 0.005 && st.remainingDebt <= 0.005) {
      badge.className = 'badge badge-success';
      badge.innerHTML = `<i class="fa-solid fa-circle-check"></i> Settled &mdash; <strong>${this.formatCurrency(st.paid)}</strong> from the drawer, <strong>${this.formatCurrency(st.creditApplied)}</strong> off the balance they hold`;
    } else if (st.creditApplied > 0.005) {
      badge.className = 'badge badge-warning';
      badge.innerHTML = `<i class="fa-solid fa-scale-balanced"></i> <strong>${this.formatCurrency(st.creditApplied)}</strong> off the balance &middot; <strong>${this.formatCurrency(st.remainingDebt)}</strong> still owed`;
    } else if (st.paid > 0) {
      badge.className = 'badge badge-warning';
      badge.innerHTML = `<i class="fa-solid fa-clock-rotate-left"></i> Partial Debt: <strong>${this.formatCurrency(st.remainingDebt)}</strong>`;
    } else {
      badge.className = 'badge badge-danger';
      badge.innerHTML = `<i class="fa-solid fa-clock"></i> 100% Credit Debt: <strong>${this.formatCurrency(st.remainingDebt)}</strong>`;
    }
  },

  addPurchaseModalItemRow() {
    const first = this.products[0];
    this.purchaseModalItems.push({
      product_id: first?.id || '',
      quantity: 1,
      cost_price: first?.cost_price || 0,
      unit: this.productUnitsOf(first)[0]?.unit_name || 'pcs'
    });
    this.renderPurchaseModalItems();
  },

  removePurchaseModalItemRow(index) {
    this.purchaseModalItems.splice(index, 1);
    this.renderPurchaseModalItems();
  },

  setPurchaseRowUnit(index, unitLabel) {
    if (!this.purchaseModalItems[index]) return;
    this.purchaseModalItems[index].unit = unitLabel;
    this.renderPurchaseModalItems();
  },

  // What the shop is about to hand over, said back in the units the shelf is counted in.
  purchaseRowUnitChoice(index) {
    const row = this.purchaseModalItems[index] || {};
    const prod = this.products.find(p => p.id === row.product_id);
    const units = this.productUnitsOf(prod || {});
    // A stale line can name a size the catalogue no longer carries; the loose unit is the
    // only answer that is always available, so the row falls back to it rather than
    // sending a size the server will refuse the moment the shop takes delivery.
    const chosen = units.find(u => u.unit_name.toLowerCase() === String(row.unit || '').trim().toLowerCase())
      || units.find(u => u.is_base) || units[0] || { unit_name: prod?.unit || 'pcs', size_in_base: 1 };
    return { row, prod, units, chosen };
  },

  purchaseRowHintHtml(index) {
    const { row, prod, chosen } = this.purchaseRowUnitChoice(index);
    const looseCount = (Number(row.quantity) || 0) * Number(chosen.size_in_base || 1);
    return `
      <i class="fa-solid fa-scale-balanced" style="color: var(--slate-400);"></i>
      ${this.escapeHtml(String(row.quantity || 0))} &times; ${this.escapeHtml(chosen.unit_name)} = <strong>${this.escapeHtml(String(parseFloat(looseCount.toFixed(3))))}</strong> ${this.escapeHtml(prod?.unit || chosen.unit_name)} onto the shelf, at <strong>${this.formatCurrency(Number(((row.cost_price || 0) / Math.max(1, chosen.size_in_base || 1)).toFixed(4)))}</strong> each
    `;
  },

  // Typed numbers reach the model through oninput and the total beside them refreshes, but
  // the line under the row only redrew when a dropdown changed - so the shop took delivery
  // against a number that stopped being true at the second digit.
  refreshPurchaseRowHint(index) {
    const el = document.getElementById(`purchase-row-hint-${index}`);
    if (el) el.innerHTML = this.purchaseRowHintHtml(index);
  },

  renderPurchaseModalItems() {
    const container = document.getElementById('purchase-items-rows');
    if (!container) return;

    container.innerHTML = this.purchaseModalItems.map((row, idx) => {
      const { units, chosen } = this.purchaseRowUnitChoice(idx);

      return `
        <div style="background: #ffffff; border: 1px solid var(--slate-200); border-radius: var(--radius-sm); padding: 0.5rem 0.65rem; margin-bottom: 0.5rem;">
          <div style="display: grid; grid-template-columns: 2fr 1fr 1fr 1fr 36px; gap: 0.4rem; align-items: center; margin-bottom: 0.35rem;">
            <select class="form-control" onchange="app.updatePurchaseRowProduct(${idx}, this.value)">
              ${this.products.map(p => `
                <option value="${this.escapeHtml(p.id)}" ${row.product_id === p.id ? 'selected' : ''}>
                  ${this.escapeHtml(p.name)} (${this.formatCurrency(p.cost_price)})${p.has_expiry == 1 ? ' [Perishable]' : ''}
                </option>
              `).join('')}
            </select>
            <input type="number" class="form-control" placeholder="Qty" value="${row.quantity}" min="1" oninput="app.purchaseModalItems[${idx}].quantity = parseFloat(this.value) || 0; app.updatePurchaseModalTotal(); app.refreshPurchaseRowHint(${idx});">
            <select class="form-control" onchange="app.setPurchaseRowUnit(${idx}, this.value)" title="The size the supplier is handing over">
              ${units.map(u => `
                <option value="${this.escapeHtml(u.unit_name)}" ${u.unit_name === chosen.unit_name ? 'selected' : ''}>
                  ${this.escapeHtml(u.unit_name)}${u.size_in_base > 1 ? ' (x' + u.size_in_base + ')' : ''}
                </option>
              `).join('')}
            </select>
            <input type="number" class="form-control" placeholder="Cost each" value="${row.cost_price}" step="any" oninput="app.purchaseModalItems[${idx}].cost_price = parseFloat(this.value) || 0; app.updatePurchaseModalTotal(); app.refreshPurchaseRowHint(${idx});">
            <button class="btn btn-outline btn-sm" onclick="app.removePurchaseModalItemRow(${idx})" style="color: var(--danger);"><i class="fa-solid fa-xmark"></i></button>
          </div>
          <div style="display: flex; align-items: center; gap: 0.4rem; margin-bottom: 0.35rem; padding-left: 0.15rem;">
            <span id="purchase-row-hint-${idx}" style="font-size: 0.72rem; color: var(--slate-500);">${this.purchaseRowHintHtml(idx)}</span>
          </div>
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.4rem; background: var(--slate-50); padding: 0.35rem 0.5rem; border-radius: 4px; border: 1px dashed var(--slate-200);">
            <div style="display: flex; align-items: center; gap: 0.35rem;">
              <span style="font-size: 0.72rem; color: var(--slate-500); white-space: nowrap;"><i class="fa-solid fa-boxes-packing" style="color: #6366f1;"></i> Lot #:</span>
              <input type="text" class="form-control" placeholder="Batch / Lot # (optional)" value="${this.escapeHtml(row.batch_number || '')}" oninput="app.purchaseModalItems[${idx}].batch_number = this.value;" style="font-size: 0.76rem; padding: 0.2rem 0.4rem;">
            </div>
            <div style="display: flex; align-items: center; gap: 0.35rem;">
              <span style="font-size: 0.72rem; color: var(--slate-500); white-space: nowrap;"><i class="fa-solid fa-calendar-xmark" style="color: #ea580c;"></i> Exp:</span>
              <input type="date" class="form-control" value="${this.escapeHtml(row.expiry_date || '')}" oninput="app.purchaseModalItems[${idx}].expiry_date = this.value;" style="font-size: 0.76rem; padding: 0.2rem 0.4rem;">
            </div>
          </div>
        </div>
      `;
    }).join('');

    this.updatePurchaseModalTotal();
  },

  updatePurchaseRowProduct(index, productId) {
    const prod = this.products.find(p => p.id === productId);
    if (prod && this.purchaseModalItems[index]) {
      this.purchaseModalItems[index].product_id = prod.id;
      this.purchaseModalItems[index].cost_price = Number(prod.cost_price || 0);
      this.purchaseModalItems[index].unit = this.productUnitsOf(prod)[0]?.unit_name || prod.unit || 'pcs';
      this.renderPurchaseModalItems();
    }
  },

  updatePurchaseModalTotal() {
    const totalEl = document.getElementById('purchase-modal-total');
    if (!totalEl) return;
    const total = this.purchaseModalItems.reduce((sum, item) => sum + ((item.quantity || 0) * (item.cost_price || 0)), 0);
    totalEl.innerText = this.formatCurrency(total);
    this.updatePurchaseModalBalanceBadge();
  },

  async savePurchaseOrder() {
    const vendorSelect = document.getElementById('purchase-vendor-select');
    const selectedVendorId = vendorSelect ? vendorSelect.value : '';
    let supplierName = '';

    if (selectedVendorId && selectedVendorId !== '__custom__') {
      const matchedVendor = this.vendors.find(v => String(v.id) === String(selectedVendorId));
      supplierName = matchedVendor ? matchedVendor.name : '';
    } else {
      supplierName = (document.getElementById('purchase-supplier-name')?.value || '').trim();
    }

    if (!supplierName) {
      this.showToast('Please select or specify a Supplier / Factory name.', 'warning');
      return;
    }

    if (this.purchaseModalItems.length === 0) {
      this.showToast('Add at least one product to the purchase order.', 'warning');
      return;
    }

    const orderNumber = 'PO-' + new Date().toISOString().slice(0, 10).replace(/-/g, '') + '-' + Math.floor(1000 + Math.random() * 9000);
    const orderDate = document.getElementById('purchase-date').value || new Date().toISOString().slice(0, 10);
    const totalCost = this.purchaseModalItems.reduce((sum, item) => sum + ((item.quantity || 0) * (item.cost_price || 0)), 0);
    const paymentMode = document.getElementById('purchase-payment-status')?.value || 'PAID';
    const amtPaidInput = document.getElementById('purchase-amount-paid');

    let amountPaid = 0;
    if (paymentMode === 'PAID') {
      amountPaid = totalCost;
    } else {
      // Not capped at the order total. A deposit larger than the invoice is the shop
      // paying ahead for goods still at the factory, and the old Math.min(...) rounded
      // the cashier's own figure down to the invoice and told nobody where the rest went.
      amountPaid = Math.max(0, parseFloat(amtPaidInput?.value) || 0);
    }

    // Signed: positive is what the shop still owes, negative is an advance it holds. The
    // credit draw does not get subtracted here - the supplier's account is one signed
    // number, and GH₵180 of goods settled with GH₵160 of cash is a +20 move onto a balance
    // already reading -20, which lands on zero. Subtracting the draw as well would move it
    // to -40 and hand the shop a fresh GH₵20 of credit on every order after it.
    const balanceDelta = Math.round((totalCost - amountPaid) * 100) / 100;
    // Same clamp the server applies, so the number on the till's copy of the order matches
    // the number the books will hold once it syncs.
    const creditUsed = this.purchaseBalanceState().creditApplied;
    const paymentStatus = (amountPaid + creditUsed >= totalCost - 0.005)
      ? 'PAID'
      : (amountPaid > 0 ? 'PARTIAL' : 'UNPAID');

    // Every line carries the till's own id from the moment it is ordered. The count-in has to
    // name the lines it is answering, and a delivery counted while the cable is out cannot
    // point at rows that only exist on the shop's server - so the ids are made here and the
    // books keep them (recordPurchaseOrderLines honours a well-formed, unused one).
    //
    // The line also carries how many loose units its size holds. The books resolve the size
    // from the catalogue and store multiplier + base_quantity; a till row that only says
    // "Crate" leaves the count-in no way to convert it, so an offline count falls back to one
    // crate = one egg: 15 crates of 30 land 15 eggs on the shelf at GH₵26.50 apiece, and the
    // weighted average cost is then rebuilt from those numbers for every sale that follows.
    const orderedLines = this.purchaseModalItems.map(item => {
      const lineProduct = this.products.find(p => String(p.id) === String(item.product_id));
      const size = this.productUnitOf(lineProduct, item.unit);
      const multiplier = Math.max(1, Number(size?.size_in_base || 1));
      return {
        ...item,
        id: /^pi_[A-Za-z0-9_\-]{4,48}$/.test(String(item.id || ''))
          ? item.id
          : 'pi_' + Math.random().toString(36).substring(2, 10) + Date.now().toString(36).slice(-4),
        unit: size?.unit_name || item.unit,
        multiplier,
        base_quantity: parseFloat((Math.max(0, Number(item.quantity || 0)) * multiplier).toFixed(4)),
      };
    });

    const purchasePayload = {
      id: 'po_' + Math.random().toString(36).substring(2, 10),
      order_number: orderNumber,
      supplier_name: supplierName,
      supplier_contact: document.getElementById('purchase-supplier-contact').value.trim(),
      vendor_id: (selectedVendorId && selectedVendorId !== '__custom__') ? selectedVendorId : null,
      amount_paid: amountPaid,
      credit_used: creditUsed,
      payment_status: paymentStatus,
      branch_code: this.currentUser?.branch_code || 'MAIN-01',
      order_date: orderDate,
      // An order is not a delivery. It is filed PENDING and total_cost is what was asked for;
      // the count-in replaces both with what came. CANCELLED rows are excluded from every
      // money figure the shop reports, so a called-off order must never look like stock.
      status: 'PENDING',
      total_cost: totalCost,
      ordered_cost: totalCost,
      shipping_cost: 0,
      notes: document.getElementById('purchase-notes').value.trim(),
      items: orderedLines
    };

    // The server is asked before the till writes anything down. This used to be the other
    // way round: the goods were added to local stock, the order was put in the list and the
    // cashier was told it was recorded, and only then came the POST. A refusal - a size the
    // product is not stocked in, a catalogue row that has gone, a schema the shop has not
    // been migrated to - produced a second toast under the first, so the owner was left
    // looking at GH₵420,000 of stock that existed only in the till's browser while the
    // books held nothing, and because a refusal is not a network failure the order was not
    // even queued to retry at sync.
    let offline = !this.isOnline;
    let refusal = null;

    if (!offline) {
      let res = null;
      try {
        res = await this.apiFetch('api/endpoints/purchases.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(purchasePayload)
        });
      } catch (err) {
        res = null;
      }
      if (res === null) {
        offline = true;
      } else {
        const verdict = await this.classifyApiResponse(res);
        if (verdict.verdict === 'refused') refusal = verdict.message;
        else if (verdict.verdict === 'unreachable') offline = true;
      }
    }

    if (refusal) {
      this.showToast(`Factory purchase ${orderNumber} was NOT recorded: ${refusal} Nothing was added to stock and no money was booked. Fix the line and send it again.`, 'danger', 14000);
      return;
    }

    await this.applyPurchaseLocally(purchasePayload, balanceDelta);

    if (offline) {
      await localDB.sync_outbox.add({ entity: 'purchase', action: 'CREATE', data: purchasePayload, timestamp: new Date().toISOString(), synced: 0 });
    }

    this.closePurchaseModal();
    this.renderCurrentView();
    this.showToast(offline
      ? `Order ${orderNumber} is saved on this till and the money is booked here. It goes to the books at the next sync. Nothing is on the shelf until it is counted in.`
      : `Factory purchase ${orderNumber} recorded as an order. Count it in when the delivery arrives - the shelf has not moved yet.`,
      offline ? 'warning' : 'info', offline ? 9000 : 6000);
  },

  // Everything the till keeps locally for an order the server accepted, or that it is holding
  // until the cable comes back: the order row and the supplier's running balance. Not the
  // shelf. Stocking on the strength of an order is how a shop ended up selling crates the
  // factory never sent, and re-costing the product on them put a false average on every later
  // sale. applyCountInLocally is where the shelf moves, and only for what was counted.
  async applyPurchaseLocally(purchasePayload, balanceDelta) {
    if (purchasePayload.vendor_id && Math.abs(balanceDelta) >= 0.005) {
      const targetVendor = this.vendors.find(v => String(v.id) === String(purchasePayload.vendor_id));
      if (targetVendor) {
        targetVendor.balance = Number((Number(targetVendor.balance || 0) + balanceDelta).toFixed(2));
        if (localDB.vendors) await localDB.vendors.put(targetVendor);
      }
    }

    // The deposit is its own line on the supplier's ledger, exactly as purchases.php
    // writes it server-side. Without it the statement bills the gross and shows no
    // payment against it, so the till's own copy of the account disagreed with the shop's.
    // The id is built from the order, not rolled at random: the server now keeps whatever
    // id the till sends, so resending this payout is a collision it can refuse instead of
    // a second payment of the same money.
    if (purchasePayload.vendor_id && Number(purchasePayload.amount_paid) > 0 && localDB.vendor_payments) {
      await localDB.vendor_payments.put({
        id: 'vpay_' + purchasePayload.id + '_cash',
        vendor_id: purchasePayload.vendor_id,
        purchase_id: purchasePayload.id,
        user_id: this.currentUser?.id || 1,
        amount: Number(purchasePayload.amount_paid),
        payment_method: 'CASH',
        reference_no: purchasePayload.order_number,
        payment_date: purchasePayload.order_date,
        notes: 'Down payment on order #' + purchasePayload.order_number,
        created_at: new Date().toISOString()
      });
    }

    // The draw is written as its own line for the same reason the server writes it: it is
    // not cash that left the drawer today, but it did settle this invoice. A statement that
    // shows GH₵180 billed against GH₵160 paid leaves the shopkeeper hunting for GH₵20 that
    // is already spent, and the till's own copy of the account then disagrees with the
    // supplier's balance by exactly the money the shop chose not to take back as change.
    if (purchasePayload.vendor_id && Number(purchasePayload.credit_used) > 0 && localDB.vendor_payments) {
      await localDB.vendor_payments.put({
        id: 'vpay_' + purchasePayload.id + '_balance',
        vendor_id: purchasePayload.vendor_id,
        purchase_id: purchasePayload.id,
        user_id: this.currentUser?.id || 1,
        amount: Number(purchasePayload.credit_used),
        payment_method: 'BALANCE',
        reference_no: purchasePayload.order_number,
        payment_date: purchasePayload.order_date,
        notes: 'Credit balance drawn on order #' + purchasePayload.order_number,
        created_at: new Date().toISOString()
      });
    }

    this.purchases.unshift(purchasePayload);
    await localDB.purchases.put(purchasePayload);
  },

  // ── The delivery is at the back door: count what came ─────────────────────────────
  //
  // An order says what the shop asked for; this says what arrived. The shelf, the average
  // cost, the lots, the voucher and what the shop owes are all taken from the numbers typed
  // here, because a truck is allowed to come short and the books have to follow the truck.
  // The same rules run server-side (countInPurchaseOrder in db.php); this is the till's own
  // copy of them, for the counter's screen and for a delivery counted with the cable out.
  countInDraft: null,

  openPurchaseCountInModal(purchaseId) {
    const po = (this.purchases || []).find(p => String(p.id) === String(purchaseId));
    if (!po) {
      this.showToast('That order is not on this till, so its delivery cannot be counted here. Sync with the shop\'s books first.', 'warning', 8000);
      return;
    }
    const state = this.purchaseOrderState(po);
    if (state !== 'PENDING') {
      this.showToast(state === 'CANCELLED'
        ? `Order ${po.order_number} was called off, so its delivery cannot be counted in. Raise it as a new order if the goods did arrive after all.`
        : `Order ${po.order_number} has already been counted in. Nothing was added to the shelf a second time.`, 'warning', 9000);
      return;
    }
    const lines = this.purchaseSummaryLines(po);
    // A line the till cannot name is a line it cannot answer, and counting against a guessed
    // id is how goods end up on somebody else's order.
    if (lines.length === 0 || lines.some(l => !l.id)) {
      this.showToast(`Order ${po.order_number} has no itemised lines on this till. Sync it with the shop's books, then count the delivery in.`, 'danger', 10000);
      return;
    }
    this.countInDraft = {
      purchaseId: po.id,
      orderNumber: po.order_number,
      supplierName: po.supplier_name || 'the supplier',
      vendorId: po.vendor_id || null,
      branchCode: po.branch_code || this.currentUser?.branch_code || 'MAIN-01',
      shipping: Number(po.shipping_cost || 0),
      amountPaid: Number(po.amount_paid || 0),
      creditUsed: Number(po.credit_used || 0),
      // The till's own key for this count-in. The server keeps it as the event id, so a
      // double tap or a queue replayed twice collides there instead of stocking the shelf
      // twice - the same lesson the supplier payouts learned the hard way.
      eventId: 'pev_' + Math.random().toString(36).substring(2, 10) + Date.now().toString(36).slice(-4),
      lines: lines.map(l => {
        const p = (this.products || []).find(x => String(x.id) === String(l.productId || l.product_id));
        const hasExpiry = (p && (p.has_expiry == 1 || p.has_expiry === true)) || !!(l.batchNumber || l.expiryDate);
        return {
          ...l,
          hasExpiry: !!hasExpiry,
          counted: l.qty,
          batchNumber: l.batchNumber || (p && p.batch_number) || '',
          expiryDate: l.expiryDate || (p && p.expiry_date) || '',
          mfgDate: l.mfgDate || (p && p.mfg_date) || ''
        };
      })
    };
    const title = document.getElementById('countin-modal-title');
    if (title) {
      title.innerHTML = `<i class="fa-solid fa-clipboard-list"></i> Count in delivery &mdash; ${this.escapeHtml(String(po.order_number))}`;
    }
    const sub = document.getElementById('countin-modal-sub');
    if (sub) {
      sub.innerHTML = `Ordered from <strong>${this.escapeHtml(String(po.supplier_name || 'the supplier'))}</strong> on ${this.escapeHtml(String(po.order_date || ''))}. Write what actually came, in the size the order was bought in. Only this reaches your shelf.`;
    }
    const noteEl = document.getElementById('countin-note');
    if (noteEl) noteEl.value = '';
    this.renderPurchaseCountInRows();
    document.getElementById('purchase-countin-modal')?.classList.add('active');
  },

  closePurchaseCountInModal() {
    this.countInDraft = null;
    document.getElementById('purchase-countin-modal')?.classList.remove('active');
  },

  purchaseCountInTotals() {
    const d = this.countInDraft;
    if (!d) return null;
    const r2 = n => Math.round((Number(n) || 0) * 100) / 100;
    const ordered = r2(d.lines.reduce((s, l) => s + (l.qty * l.cost), 0));
    const arrived = r2(d.lines.reduce((s, l) => s + ((Number(l.counted) || 0) * l.cost), 0));
    const loose = d.lines.reduce((s, l) => s + ((Number(l.counted) || 0) * Math.max(1, l.multiplier)), 0);
    return { ordered, arrived, delta: r2(ordered - arrived), loose: parseFloat(loose.toFixed(3)) };
  },

  renderPurchaseCountInRows() {
    const container = document.getElementById('countin-items-rows');
    if (!container || !this.countInDraft) return;
    container.innerHTML = this.countInDraft.lines.map((l, idx) => {
      const counted = Number(l.counted) || 0;
      const expiryBlock = l.hasExpiry ? `
        <div style="margin-top:0.45rem;padding:0.45rem 0.65rem;background:#fff7ed;border:1px solid #fed7aa;border-radius:var(--radius-sm);">
          <div style="font-size:0.75rem;font-weight:600;color:#9a3412;margin-bottom:0.35rem;display:flex;align-items:center;gap:0.4rem;">
            <i class="fa-solid fa-calendar-xmark" style="color:#ea580c;"></i>
            <span>Perishable Batch & Expiry (from delivery package)</span>
          </div>
          <div style="display:grid;grid-template-columns:1.2fr 1fr 1fr;gap:0.5rem;align-items:center;">
            <div>
              <label style="font-size:0.7rem;color:#7c2d12;margin:0 0 2px 0;display:block;">Batch / Lot #</label>
              <div style="display:flex;gap:3px;">
                <input type="text" id="countin-batch-${idx}" class="form-control" style="font-size:0.78rem;padding:0.25rem 0.4rem;height:30px;"
                  placeholder="e.g. LOT-2026-A1" value="${this.escapeHtml(l.batchNumber || '')}"
                  oninput="app.setPurchaseCountInBatch(${idx}, this.value)">
                <button type="button" class="btn btn-outline btn-sm" style="padding:0 0.4rem;height:30px;background:#fff;" title="Auto-Generate Lot #"
                  onclick="app.generateCountInBatch(${idx})">
                  <i class="fa-solid fa-wand-magic-sparkles" style="color:#ea580c;font-size:0.75rem;"></i>
                </button>
              </div>
            </div>
            <div>
              <label style="font-size:0.7rem;color:#7c2d12;margin:0 0 2px 0;display:block;">Expiry Date *</label>
              <input type="date" id="countin-expiry-${idx}" class="form-control" style="font-size:0.78rem;padding:0.25rem 0.4rem;height:30px;"
                value="${this.escapeHtml(l.expiryDate || '')}"
                oninput="app.setPurchaseCountInExpiry(${idx}, this.value)">
            </div>
            <div>
              <label style="font-size:0.7rem;color:#7c2d12;margin:0 0 2px 0;display:block;">Mfg Date (optional)</label>
              <input type="date" id="countin-mfg-${idx}" class="form-control" style="font-size:0.78rem;padding:0.25rem 0.4rem;height:30px;"
                value="${this.escapeHtml(l.mfgDate || '')}"
                oninput="app.setPurchaseCountInMfg(${idx}, this.value)">
            </div>
          </div>
        </div>` : '';

      return `
        <div style="background:#fff;border:1px solid var(--slate-200);border-radius:var(--radius-sm);padding:0.5rem 0.65rem;margin-bottom:0.5rem;" id="countin-row-${idx}">
          <div style="display:grid;grid-template-columns:1fr auto 96px;gap:0.5rem;align-items:center;">
            <div>
              <div style="font-weight:600;">${this.escapeHtml(l.name)}</div>
              <div style="font-size:0.75rem;color:var(--slate-500);">
                Ordered <strong>${l.qty}</strong> ${this.escapeHtml(l.size)}${l.packed ? ` (= ${l.loose} ${this.escapeHtml(l.baseUnit)})` : ''} &middot; ${this.formatCurrency(l.cost)} each
              </div>
            </div>
            <span style="font-size:0.78rem;color:var(--slate-500);">came in</span>
            <input type="number" id="countin-input-${idx}" class="form-control" min="0" step="any" value="${counted}"
              oninput="app.setPurchaseCountIn(${idx}, this.value)" style="text-align:right;font-weight:700;">
          </div>
          ${expiryBlock}
          <div id="countin-hint-${idx}" style="font-size:0.72rem;margin-top:0.3rem;">${this.purchaseCountInHintHtml(idx)}</div>
        </div>`;
    }).join('');
    this.updatePurchaseCountInTotals();
  },

  setPurchaseCountInBatch(idx, val) {
    if (this.countInDraft?.lines?.[idx]) {
      this.countInDraft.lines[idx].batchNumber = String(val || '').trim();
    }
  },

  setPurchaseCountInExpiry(idx, val) {
    if (this.countInDraft?.lines?.[idx]) {
      this.countInDraft.lines[idx].expiryDate = String(val || '').trim();
    }
  },

  setPurchaseCountInMfg(idx, val) {
    if (this.countInDraft?.lines?.[idx]) {
      this.countInDraft.lines[idx].mfgDate = String(val || '').trim();
    }
  },

  generateCountInBatch(idx) {
    const l = this.countInDraft?.lines?.[idx];
    if (!l) return;
    const d = new Date();
    const dateStr = d.toISOString().slice(0, 10).replace(/-/g, '');
    const rand = Math.random().toString(36).substring(2, 6).toUpperCase();
    const cleanName = (l.name || 'LOT').replace(/[^a-zA-Z0-9]/g, '').substring(0, 3).toUpperCase();
    const bNo = `LOT-${cleanName}-${dateStr}-${rand}`;
    l.batchNumber = bNo;
    const input = document.getElementById(`countin-batch-${idx}`);
    if (input) input.value = bNo;
  },

  // What one line's count means for the shelf and for the invoice, said back while the
  // cashier is still typing it. A hint that only refreshes when the box loses focus is a hint
  // that stops being true at the second digit.
  purchaseCountInHintHtml(idx) {
    const l = this.countInDraft?.lines?.[idx];
    if (!l) return '';
    const counted = Math.max(0, Number(l.counted) || 0);
    const short = counted < l.qty;
    const over = counted > l.qty;
    const loose = parseFloat((counted * Math.max(1, l.multiplier)).toFixed(3));
    const colour = short ? '#9a3412' : over ? '#1e40af' : 'var(--slate-500)';
    const border = short ? '#fdba74' : over ? '#bfdbfe' : 'var(--slate-200)';
    const row = document.getElementById(`countin-row-${idx}`);
    if (row) row.style.borderColor = border;
    return `<span style="color:${colour};">
      <i class="fa-solid ${short ? 'fa-triangle-exclamation' : over ? 'fa-boxes-packing' : 'fa-check'}"></i>
      ${loose} ${this.escapeHtml(l.baseUnit)} onto the shelf
      ${short ? `&mdash; ${parseFloat((l.qty - counted).toFixed(3))} ${this.escapeHtml(l.size)} did not come, and ${this.formatCurrency((l.qty - counted) * l.cost)} comes off what you owe` : ''}
      ${over ? `&mdash; more than the order; the shop owes ${this.formatCurrency((counted - l.qty) * l.cost)} more` : ''}
    </span>`;
  },

  setPurchaseCountIn(idx, value) {
    const l = this.countInDraft?.lines?.[idx];
    if (!l) return;
    l.counted = Math.max(0, Number(value) || 0);
    // Only the hint and the money strip are redrawn. Re-rendering the inputs themselves on
    // every keystroke throws away the caret, so the cashier cannot finish typing the number.
    const hint = document.getElementById(`countin-hint-${idx}`);
    if (hint) hint.innerHTML = this.purchaseCountInHintHtml(idx);
    this.updatePurchaseCountInTotals();
  },

  updatePurchaseCountInTotals() {
    const t = this.purchaseCountInTotals();
    const box = document.getElementById('countin-totals');
    if (!box || !t) return;
    const d = this.countInDraft;
    const settled = t.arrived;
    const paid = Math.round(((d?.amountPaid || 0) + (d?.creditUsed || 0)) * 100) / 100;
    let moneyLine = '';
    if (t.delta > 0.005) {
      moneyLine = paid >= settled - 0.005
        ? `You had already paid in full, so <strong>${this.formatCurrency(t.delta)}</strong> stays with ${this.escapeHtml(String(d?.supplierName || 'the supplier'))} as the shop's own money.`
        : `<strong>${this.formatCurrency(t.delta)}</strong> comes off what the shop owes.`;
    } else if (t.delta < -0.005) {
      moneyLine = `The supplier sent more than the order, so the shop owes <strong>${this.formatCurrency(-t.delta)}</strong> more.`;
    } else {
      moneyLine = `Everything ordered arrived &mdash; the invoice stands as it was written.`;
    }
    box.innerHTML = `
      <div style="display:flex;gap:1.25rem;flex-wrap:wrap;align-items:baseline;">
        <span style="font-size:0.82rem;color:var(--slate-600);">Ordered <strong>${this.formatCurrency(t.ordered)}</strong></span>
        <span style="font-size:0.82rem;color:var(--slate-900);">Arrived <strong style="color:var(--primary);">${this.formatCurrency(t.arrived)}</strong></span>
        <span style="font-size:0.82rem;color:var(--slate-600);">Loose units onto the shelf <strong>${t.loose}</strong></span>
      </div>
      <div style="font-size:0.8rem;color:var(--slate-700);margin-top:0.35rem;">${moneyLine}</div>`;
  },

  async savePurchaseCountIn() {
    const d = this.countInDraft;
    if (!d) return;

    for (let i = 0; i < d.lines.length; i++) {
      const l = d.lines[i];
      const counted = Math.max(0, Number(l.counted) || 0);
      if (l.hasExpiry && counted > 0 && !l.expiryDate) {
        this.showToast(`Please enter the Expiry Date for "${l.name}" as printed on the delivery package.`, 'warning', 8000);
        document.getElementById(`countin-expiry-${i}`)?.focus();
        return;
      }
    }

    const movement = {
      id: d.eventId,
      action: 'COUNT_IN',
      purchase_id: d.purchaseId,
      lines: d.lines.map(l => ({
        purchase_item_id: l.id,
        counted_quantity: Math.max(0, Number(l.counted) || 0),
        batch_number: (l.batchNumber || '').trim(),
        expiry_date: (l.expiryDate || '').trim(),
        mfg_date: (l.mfgDate || '').trim() || null
      })),
      reason_code: document.getElementById('countin-reason')?.value || '',
      note: (document.getElementById('countin-note')?.value || '').trim(),
      counted_at: new Date().toISOString()
    };

    let offline = !this.isOnline;
    let refusal = null;
    let serverLines = null;

    if (!offline) {
      let res = null;
      try {
        res = await this.apiFetch('api/endpoints/purchases.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(movement)
        });
      } catch (err) {
        res = null;
      }
      if (res === null) {
        offline = true;
      } else {
        const verdict = await this.classifyApiResponse(res);
        if (verdict.verdict === 'refused') refusal = verdict.message;
        else if (verdict.verdict === 'unreachable') offline = true;
        else serverLines = verdict.body?.booked || null;
      }
    }

    // A refused count-in moves nothing anywhere. The shelf keeps the old number and the order
    // stays awaiting delivery, which is the only answer that lets the shopkeeper fix the line
    // and count it again.
    if (refusal) {
      this.showToast(`Delivery for ${d.orderNumber} was NOT counted in: ${refusal} The shelf and the invoice are unchanged.`, 'danger', 14000);
      return;
    }

    await this.applyCountInLocally(d, movement.lines, serverLines);

    if (offline) {
      await localDB.sync_outbox.add({ entity: 'purchase_movement', action: 'COUNT_IN', data: movement, timestamp: new Date().toISOString(), synced: 0 });
    }

    this.closePurchaseCountInModal();
    if (typeof this.fetchBatches === 'function') this.fetchBatches();
    this.renderCurrentView();
    const t = this.purchaseCountInTotalsFromRows(movement.lines, d);
    this.showToast(offline
      ? `${d.orderNumber}: ${this.formatCurrency(t.arrived)} of goods counted onto this till's shelf. The books catch up at the next sync.`
      : `${d.orderNumber} counted in. ${this.formatCurrency(t.arrived)} of goods reached the shelf${t.delta ? `, and ${this.formatCurrency(Math.abs(t.delta))} ${t.delta > 0 ? 'came off what you owe' : 'was added to what you owe'}` : ''}.`,
      offline ? 'warning' : 'success', offline ? 9000 : 6000);
  },

  // The money strip has to say the same thing after the count as it did while typing it, and
  // the figures come from the rows that were actually booked.
  purchaseCountInTotalsFromRows(rows, d) {
    const r2 = n => Math.round((Number(n) || 0) * 100) / 100;
    const arrived = r2(d.lines.reduce((s, l) => s + ((Number(l.counted) || 0) * l.cost), 0));
    const ordered = r2(d.lines.reduce((s, l) => s + (l.qty * l.cost), 0));
    return { arrived, ordered, delta: r2(ordered - arrived) };
  },

  // The till's own copy of a count-in: the shelf in loose units, the weighted average cost,
  // the lot, the order row and the supplier's signed balance. Mirrors
  // bookCountedPurchaseLines() line for line so the counter and the books never disagree
  // about what one delivery was worth.
  async applyCountInLocally(d, rows, serverLines) {
    const byLine = {};
    (rows || []).forEach(r => { byLine[String(r.purchase_item_id)] = Math.max(0, Number(r.counted_quantity) || 0); });
    const fromServer = {};
    (serverLines || []).forEach(b => { fromServer[String(b.purchase_item_id)] = b; });

    let receivedValue = 0;
    let orderedValue = 0;

    for (const l of d.lines) {
      const counted = Math.max(0, Number(byLine[l.id]) || 0);
      const multiplier = Math.max(1, Number(l.multiplier || 1));
      const cost = Math.max(0, Number(l.cost) || 0);
      receivedValue = Math.round((receivedValue + counted * cost) * 100) / 100;
      orderedValue = Math.round((orderedValue + l.qty * cost) * 100) / 100;

      const booked = fromServer[l.id];
      const baseQty = booked ? Math.max(0, Number(booked.base_quantity) || 0) : counted * multiplier;
      const perBaseCost = booked ? Number(booked.cost_price ?? cost) / multiplier : cost / multiplier;

      if (baseQty <= 0) continue;

      const prod = this.products.find(p => String(p.id) === String(l.productId));
      if (!prod) continue;

      const curQty = Number(prod.current_quantity || 0);
      const oldCost = Number(prod.cost_price || 0);
      const weighted = booked && booked.average_cost !== undefined
        ? Number(booked.average_cost)
        : (curQty > 0
          ? (((curQty * oldCost) + (baseQty * perBaseCost)) / (curQty + baseQty))
          : perBaseCost);

      prod.current_quantity = parseFloat((curQty + baseQty).toFixed(3));
      prod.cost_price = Number(weighted.toFixed(2));

      const isPerishable = prod.has_expiry == 1 || !!l.expiryDate || !!l.batchNumber;
      if (isPerishable) {
        const bNo = l.batchNumber || ('LOT-' + new Date().toISOString().slice(0, 10).replace(/-/g, '') + '-' + Math.floor(100 + Math.random() * 900));
        const finalExp = l.expiryDate || new Date(Date.now() + 365 * 86400000).toISOString().slice(0, 10);
        prod.has_expiry = 1;
        prod.batch_number = bNo;
        prod.expiry_date = finalExp;

        if (window.localDB && localDB.product_batches) {
          const batchRecord = {
            id: 'batch_' + Math.random().toString(36).substring(2, 10),
            product_id: prod.id,
            product_name: prod.name,
            product_sku: prod.sku,
            product_unit: prod.unit,
            batch_number: bNo,
            expiry_date: finalExp,
            manufacture_date: l.mfgDate || null,
            initial_quantity: baseQty,
            current_quantity: baseQty,
            cost_price: Number(perBaseCost.toFixed(4)),
            supplier_id: d.vendorId || null,
            supplier_name: d.supplierName,
            branch_code: d.branchCode || 'MAIN-01',
            status: 'ACTIVE',
            notes: `Counted in from Order #${d.orderNumber} (${d.supplierName}) — ${counted} ${l.size}`,
            created_at: new Date().toISOString()
          };
          await localDB.product_batches.put(batchRecord);
          if (Array.isArray(this.batches)) this.batches.unshift(batchRecord);
        }
      }

      await localDB.products.put(prod);
    }

    const valueDelta = Math.round((orderedValue - receivedValue) * 100) / 100;
    const newTotal = Math.round((receivedValue + (Number(d.shipping) || 0)) * 100) / 100;
    const paid = Math.round(((Number(d.amountPaid) || 0) + (Number(d.creditUsed) || 0)) * 100) / 100;
    const paymentStatus = paid >= newTotal - 0.005 ? 'PAID' : ((Number(d.amountPaid) || 0) > 0 ? 'PARTIAL' : 'UNPAID');

    const po = (this.purchases || []).find(p => String(p.id) === String(d.purchaseId));
    if (po) {
      po.status = 'COUNTED';
      po.total_cost = newTotal;
      po.payment_status = paymentStatus;
      po.counted_at = new Date().toISOString();
      po.counted_by = this.currentUser?.id || null;
      if (Array.isArray(po.items)) po.items.forEach(l => { l.counted_quantity = Math.max(0, Number(byLine[String(l.id)]) || 0); });
      if (Array.isArray(po.lines)) po.lines.forEach(l => { l.counted_quantity = Math.max(0, Number(byLine[String(l.id)]) || 0); });
      po.updated_at = new Date().toISOString();
      await localDB.purchases.put(po);
    }

    // What did not arrive comes off what the shop owes, and if the shop had already paid the
    // difference stays with the factory as its own money. One signed number carries both, so
    // this is a subtraction of the shortfall and nothing else.
    if (d.vendorId && Math.abs(valueDelta) >= 0.005) {
      const vendor = (this.vendors || []).find(v => String(v.id) === String(d.vendorId));
      if (vendor) {
        vendor.balance = Number(((Number(vendor.balance || 0) - valueDelta)).toFixed(2));
        if (localDB.vendors) await localDB.vendors.put(vendor);
      }
    }
  },

  // ── Calling an order off ───────────────────────────────────────────────────────────
  //
  // The till offers this for orders that have not been counted. Cancelling a delivery that
  // already came means taking it back off the shelf, lot by lot, and only the shop's books
  // can do that honestly - they know whether any of it has already been sold. A counted order
  // is cancelled from the server (cancelPurchaseOrder), which refuses unless the goods are
  // still there.
  openPurchaseCancelModal(purchaseId) {
    const po = (this.purchases || []).find(p => String(p.id) === String(purchaseId));
    if (!po) {
      this.showToast('That order is not on this till.', 'warning');
      return;
    }
    if (this.purchaseOrderState(po) !== 'PENDING') {
      this.showToast(`Order ${po.order_number} is not awaiting delivery, so it is not cancelled from here. Ask the shop's manager to handle a delivery that already came.`, 'warning', 9000);
      return;
    }
    const head = document.getElementById('cancel-po-title');
    if (head) {
      head.innerHTML = `Call off order <strong>${this.escapeHtml(String(po.order_number))}</strong> &mdash; ${this.escapeHtml(String(po.supplier_name || ''))}, ${this.formatCurrency(po.total_cost)}`;
    }
    document.getElementById('cancel-po-id').value = po.id;
    document.getElementById('cancel-po-reason').value = '';
    document.getElementById('cancel-po-note').value = '';
    document.getElementById('purchase-cancel-modal')?.classList.add('active');
  },

  closePurchaseCancelModal() {
    document.getElementById('purchase-cancel-modal')?.classList.remove('active');
  },

  async savePurchaseCancel() {
    const purchaseId = document.getElementById('cancel-po-id')?.value || '';
    const po = (this.purchases || []).find(p => String(p.id) === String(purchaseId));
    const reasonCode = (document.getElementById('cancel-po-reason')?.value || '').trim();
    const note = (document.getElementById('cancel-po-note')?.value || '').trim();
    if (!po) { this.showToast('That order is not on this till.', 'warning'); return; }
    if (!reasonCode) {
      this.showToast('Say why the order is being called off. The reason is kept on the order and read back to you in six weeks.', 'warning', 8000);
      return;
    }

    const movement = {
      id: 'pev_' + Math.random().toString(36).substring(2, 10) + Date.now().toString(36).slice(-4),
      action: 'CANCEL',
      purchase_id: po.id,
      reason_code: reasonCode,
      note,
      cancelled_at: new Date().toISOString()
    };

    let offline = !this.isOnline;
    let refusal = null;
    if (!offline) {
      let res = null;
      try {
        res = await this.apiFetch('api/endpoints/purchases.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(movement)
        });
      } catch (err) { res = null; }
      if (res === null) offline = true;
      else {
        const verdict = await this.classifyApiResponse(res);
        if (verdict.verdict === 'refused') refusal = verdict.message;
        else if (verdict.verdict === 'unreachable') offline = true;
      }
    }
    if (refusal) {
      this.showToast(`Order ${po.order_number} was NOT called off: ${refusal}`, 'danger', 12000);
      return;
    }

    // The whole invoice comes off what the shop owes. That one rule is right in every case:
    // an unpaid order goes from debt to nothing, a paid one goes to a negative balance, which
    // is the shop's own money sitting at the factory waiting to be collected.
    const invoice = Math.round(Number(po.total_cost || 0) * 100) / 100;
    po.status = 'CANCELLED';
    po.cancelled_at = new Date().toISOString();
    po.cancel_reason = reasonCode;
    po.cancel_note = note;
    po.updated_at = new Date().toISOString();
    await localDB.purchases.put(po);

    if (po.vendor_id && invoice >= 0.005) {
      const vendor = (this.vendors || []).find(v => String(v.id) === String(po.vendor_id));
      if (vendor) {
        vendor.balance = Number(((Number(vendor.balance || 0) - invoice)).toFixed(2));
        if (localDB.vendors) await localDB.vendors.put(vendor);
      }
    }

    if (offline) {
      await localDB.sync_outbox.add({ entity: 'purchase_movement', action: 'CANCEL', data: movement, timestamp: new Date().toISOString(), synced: 0 });
    }

    this.closePurchaseCancelModal();
    this.renderCurrentView();
    this.showToast(offline
      ? `Order ${po.order_number} is called off on this till. The books catch up at the next sync.`
      : `Order ${po.order_number} called off. ${this.formatCurrency(invoice)} taken off what the shop owes${invoice > 0 && Number(po.amount_paid) >= invoice - 0.005 ? ' and held with the supplier as your money' : ''}.`,
      offline ? 'warning' : 'info', offline ? 9000 : 7000);
  },

  // A settlement pays off invoices, not just a running number. Until this, a payout taken
  // from the Suppliers page moved vendors.balance and left every order it had actually paid
  // for at its old amount_paid and its PARTIAL badge - which is how a shop ends up showing
  // all its suppliers at GH₵0.00 while the dashboard still reports over a million owed.
  // The server does the same walk (allocateVendorPaymentToOrders) and this is its mirror for
  // the payout a till holds until the line comes back, so the counter's own copy of the
  // supplier's account shows the same invoices closed that the shop's books will.
  //
  // Oldest invoice first, and never further than what that invoice still owes, because the
  // figures a supplier is owed are counted per order and never netted: an order paid twice
  // over can hide an order nobody has paid at all.
  allocatePayoutToOrdersLocally(vendorId, amount, linkedPurchaseId = '') {
    let remaining = Math.round(Number(amount || 0) * 100) / 100;
    if (!vendorId || remaining <= 0.005) return [];

    const open = (this.purchases || [])
      .filter(p => String(p.vendor_id) === String(vendorId))
      .map(p => ({
        po: p,
        left: Math.round((Number(p.total_cost || 0) - Number(p.amount_paid || 0) - Number(p.credit_used || 0)) * 100) / 100
      }))
      .filter(x => x.left > 0.005)
      .sort((a, b) => {
        if (linkedPurchaseId) {
          const aLinked = String(a.po.id) === String(linkedPurchaseId) ? 0 : 1;
          const bLinked = String(b.po.id) === String(linkedPurchaseId) ? 0 : 1;
          if (aLinked !== bLinked) return aLinked - bLinked;
        }
        return String(a.po.order_date || '').localeCompare(String(b.po.order_date || ''));
      });

    const applied = [];
    for (const x of open) {
      if (remaining <= 0.005) break;
      const take = Math.round(Math.min(x.left, remaining) * 100) / 100;
      const paid = Math.round((Number(x.po.amount_paid || 0) + take) * 100) / 100;
      const settled = Math.round((paid + Number(x.po.credit_used || 0)) * 100) / 100 >= Number(x.po.total_cost) - 0.005;
      applied.push({ id: x.po.id, order_number: x.po.order_number, amount: take, amount_paid: paid, payment_status: settled ? 'PAID' : 'PARTIAL' });
      remaining = Math.round((remaining - take) * 100) / 100;
    }
    return applied;
  },

  // Writes the settlements the shop's books decided on into the till's own copy of the
  // orders, so a payout settled at the counter does not stay PARTIAL on the till until the
  // next full refresh - and the purchases list, the statement and the dashboard all read
  // the same closed orders off the same rows.
  async applyPayoutOrderSettlements(settlements) {
    if (!Array.isArray(settlements) || settlements.length === 0) return [];
    for (const s of settlements) {
      const po = (this.purchases || []).find(p => String(p.id) === String(s.id));
      if (!po) continue;
      po.amount_paid = Number(s.amount_paid || 0);
      po.payment_status = String(s.payment_status || 'PARTIAL').toUpperCase();
      po.updated_at = new Date().toISOString();
      if (localDB.purchases) {
        try { await localDB.purchases.put(po); } catch (e) { }
      }
    }
    return settlements;
  }
});
