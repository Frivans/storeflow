// assets/js/app-batches.js
// Enterprise Perishable Goods, Batch/Lot Tracking, Expiry Monitoring & Write-Off Engine

Object.assign(StoreApp.prototype, {
  activeBatchFilter: 'all',
  batches: [],
  batchesSummary: {
    expired_count: 0,
    expired_units: 0,
    expired_cost: 0,
    expiring_30_count: 0,
    expiring_30_units: 0,
    expiring_30_cost: 0,
    expiring_90_count: 0,
    expiring_90_units: 0,
    active_batches_count: 0,
    active_units: 0,
    active_cost: 0
  },

  async fetchBatches(filter = null) {
    if (filter) this.activeBatchFilter = filter;
    const branch = this.isMultiBranch ? (this.inventoryBranchFilter || 'ALL') : 'MAIN-01';

    if (this.isOnline) {
      try {
        const res = await this.apiFetch(`api/endpoints/batches.php?branch_code=${encodeURIComponent(branch)}&filter=${encodeURIComponent(this.activeBatchFilter)}`);
        // apiFetch hands back the Response, not the JSON. Reading .success off it is
        // always undefined, so this used to fall through to the Dexie cache on every
        // online load - and because only the branch below ever fills that cache, the
        // expiry board came up empty while the server was holding plenty of lots.
        const verdict = await this.classifyApiResponse(res);
        if (verdict.verdict === 'accepted') {
          this.batches = verdict.body.batches || [];
          if (verdict.body.summary) this.batchesSummary = verdict.body.summary;
          if (window.localDB && localDB.product_batches) {
            await localDB.product_batches.clear();
            await localDB.product_batches.bulkPut(this.batches.map(b => ({ ...b, synced: 1 })));
          }
          return;
        }
        if (verdict.verdict === 'refused') {
          this.showToast(`Could not read the lot ledger: ${verdict.message}`, 'danger');
          return;
        }
      } catch (err) {
        console.warn('Batches API offline fallback:', err);
      }
    }

    // Offline Dexie fallback
    if (window.localDB && localDB.product_batches) {
      const allBatches = await localDB.product_batches.toArray();
      const today = new Date().toISOString().slice(0, 10);
      const thirtyDays = new Date(Date.now() + 30 * 86400000).toISOString().slice(0, 10);
      const ninetyDays = new Date(Date.now() + 90 * 86400000).toISOString().slice(0, 10);

      this.batches = allBatches.filter(b => {
        if (branch !== 'ALL' && (b.branch_code || 'MAIN-01') !== branch) return false;
        if (this.activeBatchFilter === 'expired') return b.expiry_date < today && Number(b.current_quantity || 0) > 0;
        if (this.activeBatchFilter === 'expiring_30') return b.expiry_date >= today && b.expiry_date <= thirtyDays && Number(b.current_quantity || 0) > 0;
        if (this.activeBatchFilter === 'expiring_90') return b.expiry_date >= today && b.expiry_date <= ninetyDays && Number(b.current_quantity || 0) > 0;
        if (this.activeBatchFilter === 'active') return Number(b.current_quantity || 0) > 0 && b.status === 'ACTIVE';
        if (this.activeBatchFilter === 'depleted') return Number(b.current_quantity || 0) <= 0 || b.status === 'DEPLETED';
        return true;
      });
    }
  },

  getBatchesHTML() {
    const s = this.batchesSummary || {};
    const isFilteredBranch = this.isMultiBranch && this.inventoryBranchFilter && this.inventoryBranchFilter !== 'ALL';
    const activeBranchName = isFilteredBranch
      ? (this.branches.find(b => b.branch_code === this.inventoryBranchFilter)?.name || this.inventoryBranchFilter)
      : 'All Branches (Consolidated)';

    return `
      <div class="panel">
        <div class="panel-header" style="flex-wrap: wrap; gap: 0.75rem;">
          <div>
            <h3><i class="fa-solid fa-boxes-packing" style="color: #ea580c;"></i> Product Batches & Expiry Date Management</h3>
            <p style="font-size: 0.8rem; color: var(--slate-500); margin: 0.2rem 0 0 0;">
              Track perishable lots, inspect best-before dates, and write off spoiled stock · Active View: <strong>${this.escapeHtml(activeBranchName)}</strong>
            </p>
          </div>
          <div style="display: flex; gap: 0.5rem; align-items: center; flex-wrap: wrap;">
            ${this.isMultiBranch ? `
              <div style="display: flex; align-items: center; gap: 0.4rem; background: var(--slate-100); padding: 0.3rem 0.6rem; border-radius: 6px; border: 1px solid var(--slate-200);">
                <i class="fa-solid fa-store" style="color: var(--primary); font-size: 0.85rem;"></i>
                <label style="font-size: 0.8rem; font-weight: 600; color: var(--slate-700); margin: 0;">Branch:</label>
                <select class="form-control" style="width: auto; padding: 0.25rem 0.5rem; font-size: 0.85rem; font-weight: 600;" onchange="app.setInventoryBranchFilter(this.value); app.fetchBatches().then(() => app.renderCurrentView());">
                  <option value="ALL" ${this.inventoryBranchFilter === 'ALL' ? 'selected' : ''}>All Branches (Consolidated)</option>
                  ${this.branches.map(b => `
                    <option value="${this.escapeHtml(b.branch_code)}" ${this.inventoryBranchFilter === b.branch_code ? 'selected' : ''}>
                      ${this.escapeHtml(b.name)} (${this.escapeHtml(b.branch_code)})
                    </option>
                  `).join('')}
                </select>
              </div>
            ` : ''}

            <button class="btn btn-outline" onclick="app.switchView('inventory')" style="font-size: 0.85rem;">
              <i class="fa-solid fa-boxes-stacked"></i> Live Stock
            </button>
            <button class="btn btn-outline" onclick="app.openNewBatchModal()" style="font-size: 0.85rem;" title="Initialize pre-existing legacy shelf stock (Opening Balance)">
              <i class="fa-solid fa-boxes-packing"></i> Log Opening Lot
            </button>
            <button class="btn btn-success" onclick="app.openNewPurchaseModal()" style="font-size: 0.85rem; font-weight: 700;">
              <i class="fa-solid fa-truck-ramp-box"></i> + Restock / Receive Factory Batch
            </button>
          </div>
        </div>

        <div class="panel-body">
          <!-- Critical Urgent Alert Banners -->
          ${s.expired_count > 0 ? `
            <div style="background: #fef2f2; border: 1.5px solid #fecaca; border-radius: 8px; padding: 0.85rem 1.15rem; margin-bottom: 1rem; display: flex; align-items: center; justify-content: space-between; gap: 1rem; flex-wrap: wrap;">
              <div style="display: flex; align-items: center; gap: 0.75rem;">
                <div style="width: 38px; height: 38px; border-radius: 50%; background: #fee2e2; display: flex; align-items: center; justify-content: center; color: #dc2626; font-size: 1.2rem; flex-shrink: 0;">
                  <i class="fa-solid fa-triangle-exclamation"></i>
                </div>
                <div>
                  <h4 style="margin: 0; font-size: 0.95rem; font-weight: 800; color: #991b1b;">
                    CRITICAL: ${s.expired_count} Perishable ${s.expired_count === 1 ? 'Batch has' : 'Batches have'} EXPIRED on shelves!
                  </h4>
                  <p style="margin: 0.15rem 0 0 0; font-size: 0.8rem; color: #b91c1c;">
                    Total expired quantity: <strong>${s.expired_units} units</strong> · Estimated at-risk inventory loss: <strong>${this.formatCurrency(s.expired_cost)}</strong>.
                  </p>
                </div>
              </div>
              <button class="btn btn-danger btn-sm" onclick="app.setBatchFilter('expired')" style="font-weight: 700; white-space: nowrap;">
                <i class="fa-solid fa-filter"></i> View & Quarantine Expired
              </button>
            </div>
          ` : ''}

          ${s.expiring_30_count > 0 ? `
            <div style="background: #fffbeb; border: 1.5px solid #fde68a; border-radius: 8px; padding: 0.85rem 1.15rem; margin-bottom: 1rem; display: flex; align-items: center; justify-content: space-between; gap: 1rem; flex-wrap: wrap;">
              <div style="display: flex; align-items: center; gap: 0.75rem;">
                <div style="width: 38px; height: 38px; border-radius: 50%; background: #fef3c7; display: flex; align-items: center; justify-content: center; color: #d97706; font-size: 1.1rem; flex-shrink: 0;">
                  <i class="fa-solid fa-clock"></i>
                </div>
                <div>
                  <h4 style="margin: 0; font-size: 0.92rem; font-weight: 800; color: #92400e;">
                    WARNING: ${s.expiring_30_count} ${s.expiring_30_count === 1 ? 'Batch is' : 'Batches are'} EXPIRING within 30 days!
                  </h4>
                  <p style="margin: 0.15rem 0 0 0; font-size: 0.78rem; color: #b45309;">
                    ${s.expiring_30_units} units approaching expiration (${this.formatCurrency(s.expiring_30_cost)} valuation). Prioritize sales or clearance pricing.
                  </p>
                </div>
              </div>
              <button class="btn btn-warning btn-sm" onclick="app.setBatchFilter('expiring_30')" style="font-weight: 700; color: #78350f; white-space: nowrap;">
                <i class="fa-solid fa-bolt"></i> Inspect 30-Day Batches
              </button>
            </div>
          ` : ''}

          <!-- Filter Navigation Pills -->
          <div style="display: flex; gap: 0.5rem; margin-bottom: 1.25rem; flex-wrap: wrap; border-bottom: 1px solid var(--slate-200); padding-bottom: 0.75rem;">
            <button class="btn btn-sm ${this.activeBatchFilter === 'all' ? 'btn-primary' : 'btn-outline'}" onclick="app.setBatchFilter('all')">
              All Tracked Batches (${s.active_batches_count || this.batches.length})
            </button>
            <button class="btn btn-sm ${this.activeBatchFilter === 'expired' ? 'btn-danger' : 'btn-outline'}" onclick="app.setBatchFilter('expired')" style="${this.activeBatchFilter !== 'expired' && s.expired_count > 0 ? 'color: #dc2626; border-color: #fca5a5;' : ''}">
              <i class="fa-solid fa-triangle-exclamation"></i> Expired (${s.expired_count || 0})
            </button>
            <button class="btn btn-sm ${this.activeBatchFilter === 'expiring_30' ? 'btn-warning' : 'btn-outline'}" onclick="app.setBatchFilter('expiring_30')" style="${this.activeBatchFilter !== 'expiring_30' && s.expiring_30_count > 0 ? 'color: #d97706; border-color: #fde68a;' : ''}">
              <i class="fa-solid fa-clock"></i> Expiring &le; 30 Days (${s.expiring_30_count || 0})
            </button>
            <button class="btn btn-sm ${this.activeBatchFilter === 'expiring_90' ? 'btn-primary' : 'btn-outline'}" onclick="app.setBatchFilter('expiring_90')">
              <i class="fa-solid fa-calendar-week"></i> Expiring &le; 90 Days (${s.expiring_90_count || 0})
            </button>
            <button class="btn btn-sm ${this.activeBatchFilter === 'depleted' ? 'btn-primary' : 'btn-outline'}" onclick="app.setBatchFilter('depleted')">
              Depleted / Written-Off
            </button>
          </div>

          <!-- Batches Data Table -->
          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Product</th>
                  <th>Batch / Lot #</th>
                  <th>Manufactured</th>
                  <th>Expiry Date</th>
                  <th>Urgency Status</th>
                  <th>Stock on Hand</th>
                  <th>Cost Valuation</th>
                  ${this.isMultiBranch ? '<th>Branch</th>' : ''}
                  <th style="text-align: center; width: 140px;">Actions</th>
                </tr>
              </thead>
              <tbody>
                ${this.batches.length > 0 ? this.batches.map(b => {
                  const daysLeft = parseInt(b.days_left !== undefined ? b.days_left : Math.round((new Date(b.expiry_date) - new Date()) / 86400000));
                  const isExpired = daysLeft < 0;
                  const isCritical = daysLeft >= 0 && daysLeft <= 30;
                  const isSoon = daysLeft > 30 && daysLeft <= 90;
                  const currentQty = Number(b.current_quantity || 0);
                  const isDepleted = currentQty <= 0 || b.status === 'DEPLETED';

                  let badgeHTML = '';
                  if (isDepleted) {
                    badgeHTML = `<span class="badge badge-neutral"><i class="fa-solid fa-check"></i> Depleted</span>`;
                  } else if (isExpired) {
                    badgeHTML = `<span class="badge badge-danger" style="font-weight: 700;"><i class="fa-solid fa-triangle-exclamation"></i> EXPIRED (${Math.abs(daysLeft)}d ago)</span>`;
                  } else if (isCritical) {
                    badgeHTML = `<span class="badge badge-warning" style="font-weight: 700;"><i class="fa-solid fa-clock"></i> Critical (${daysLeft}d left)</span>`;
                  } else if (isSoon) {
                    badgeHTML = `<span class="badge" style="background: #e0f2fe; color: #0369a1; border: 1px solid #bae6fd; font-weight: 700;"><i class="fa-solid fa-hourglass-half"></i> ${daysLeft}d left</span>`;
                  } else {
                    badgeHTML = `<span class="badge badge-success"><i class="fa-solid fa-circle-check"></i> Fresh (${daysLeft}d)</span>`;
                  }

                  const costVal = currentQty * Number(b.cost_price || 0);

                  return `
                    <tr style="${isExpired && !isDepleted ? 'background: #fff5f5;' : ''}">
                      <td>
                        <div style="font-weight: 700; color: var(--slate-900); font-size: 0.88rem;">${this.escapeHtml(b.product_name || 'Product')}</div>
                        <span style="font-family: monospace; font-size: 0.72rem; color: var(--slate-500);">${this.escapeHtml(b.product_sku || '')}</span>
                      </td>
                      <td>
                        <span style="font-family: monospace; font-weight: 700; background: var(--slate-100); padding: 0.2rem 0.45rem; border-radius: 4px; border: 1px solid var(--slate-200); font-size: 0.82rem;">
                          ${this.escapeHtml(b.batch_number)}
                        </span>
                      </td>
                      <td style="font-size: 0.82rem; color: var(--slate-600);">${this.escapeHtml(b.manufacture_date || 'N/A')}</td>
                      <td style="font-weight: 700; font-size: 0.85rem; color: ${isExpired ? '#dc2626' : (isCritical ? '#d97706' : 'var(--slate-800)')};">
                        ${this.escapeHtml(b.expiry_date)}
                      </td>
                      <td>${badgeHTML}</td>
                      <td style="font-weight: 700; font-size: 0.95rem;">
                        ${currentQty} <span style="font-size: 0.75rem; font-weight: 400; color: var(--slate-500);">${this.escapeHtml(b.product_unit || 'pcs')}</span>
                        <div style="font-size: 0.72rem; color: var(--slate-400);">Init: ${b.initial_quantity || currentQty}</div>
                      </td>
                      <td style="font-weight: 600;">${this.formatCurrency(costVal)}</td>
                      ${this.isMultiBranch ? `
                        <td><span class="badge badge-neutral">${this.escapeHtml(b.branch_name || b.branch_code || 'MAIN-01')}</span></td>
                      ` : ''}
                      <td style="text-align: center;">
                        <div style="display: flex; gap: 0.35rem; justify-content: center;">
                          ${!isDepleted ? `
                            <button class="btn btn-outline btn-sm" onclick="app.openWriteOffModal(${this.jsStr(b.id)})" title="Quarantine / Write Off Expired or Damaged Stock" style="color: #dc2626; border-color: #fca5a5; background: #fff5f5; padding: 0.25rem 0.5rem; font-size: 0.75rem; font-weight: 700;">
                              <i class="fa-solid fa-dumpster-fire"></i> Write-Off
                            </button>
                          ` : ''}
                          <button class="btn btn-outline btn-sm" onclick="app.openNewPurchaseModal(${this.jsStr(b.product_id)})" title="Restock this item from supplier (Factory PO)" style="color: var(--primary); padding: 0.25rem 0.45rem; font-size: 0.75rem;">
                            <i class="fa-solid fa-truck-ramp-box"></i> Reorder
                          </button>
                          <button class="btn btn-outline btn-sm" onclick="app.printBatchExpiryTag(${this.jsStr(b.id)})" title="Print Shelf Expiry Tag" style="padding: 0.25rem 0.45rem; font-size: 0.75rem;">
                            <i class="fa-solid fa-print"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  `;
                }).join('') : `
                  <tr>
                    <td colspan="${this.isMultiBranch ? 9 : 8}" style="text-align: center; padding: 3rem; color: var(--slate-400);">
                      <i class="fa-solid fa-boxes-packing" style="font-size: 2.2rem; margin-bottom: 0.6rem; display: block; color: var(--slate-300);"></i>
                      No batches found matching the selected filter.
                    </td>
                  </tr>
                `}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  },

  async setBatchFilter(filterName) {
    this.activeBatchFilter = filterName;
    await this.fetchBatches(filterName);
    this.renderCurrentView();
  },

  openWriteOffModal(batchId) {
    const b = this.batches.find(item => item.id === batchId);
    if (!b) return;

    document.getElementById('wo-batch-id').value = b.id;
    document.getElementById('wo-product-name').innerText = b.product_name || 'Perishable Product';
    
    const daysLeft = parseInt(b.days_left !== undefined ? b.days_left : Math.round((new Date(b.expiry_date) - new Date()) / 86400000));
    const expiryStatus = daysLeft < 0 ? `EXPIRED ${Math.abs(daysLeft)} days ago` : `Expires in ${daysLeft} days`;
    document.getElementById('wo-batch-info').innerText = `Batch #${b.batch_number} · ${expiryStatus} · Available: ${b.current_quantity} ${b.product_unit || 'units'}`;
    
    const maxQtyEl = document.getElementById('wo-max-qty');
    if (maxQtyEl) maxQtyEl.innerText = `${b.current_quantity} ${b.product_unit || 'units'}`;
    
    const qtyInput = document.getElementById('wo-quantity');
    if (qtyInput) {
      qtyInput.max = b.current_quantity;
      qtyInput.value = b.current_quantity; // Default to full write-off of expired stock
    }

    const reasonSelect = document.getElementById('wo-reason');
    if (reasonSelect) {
      reasonSelect.value = daysLeft < 0 ? 'EXPIRED' : 'DAMAGED';
    }

    document.getElementById('wo-notes').value = '';
    document.getElementById('write-off-modal').classList.add('active');
  },

  closeWriteOffModal() {
    document.getElementById('write-off-modal').classList.remove('active');
  },

  async confirmWriteOffBatch() {
    const batchId = document.getElementById('wo-batch-id').value;
    const qty = parseFloat(document.getElementById('wo-quantity').value) || 0;
    const reason = document.getElementById('wo-reason').value;
    const notes = document.getElementById('wo-notes').value.trim();

    if (!batchId || qty <= 0) {
      this.showToast('Please specify a valid write-off quantity greater than 0.', 'warning');
      return;
    }

    const payload = {
      action: 'write_off',
      batch_id: batchId,
      quantity: qty,
      reason,
      notes
    };

    if (this.isOnline) {
      try {
        const res = await this.apiFetch('api/endpoints/batches.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        const verdict = await this.classifyApiResponse(res);
        if (verdict.verdict === 'accepted') {
          this.showToast(`Wrote off ${qty} units (${reason}).`, 'success');
          this.closeWriteOffModal();
          await this.fetchBatches();
          await this.fetchProducts();
          await this.fetchInventory();
          this.renderCurrentView();
          return;
        }
        if (verdict.verdict === 'refused') {
          this.showToast(`The shop's books refused that write-off: ${verdict.message}`, 'danger');
          return;
        }
        this.showToast('Could not reach the server, so nothing was written off. Write off again once you are online.', 'warning');
        return;
      } catch (err) {
        this.showToast('Error writing off batch stock: ' + err.message, 'danger');
        return;
      }
    } else {
      this.showToast('Online connection required to record authoritative stock write-off audit.', 'warning');
    }
  },

  openNewBatchModal(productId = null) {
    document.getElementById('batch-modal-title').innerHTML = '<i class="fa-solid fa-boxes-packing"></i> Record Product Batch / Lot';
    document.getElementById('batch-form-id').value = '';
    
    const prodSelect = document.getElementById('batch-form-product-id');
    if (prodSelect) {
      prodSelect.innerHTML = this.products.map(p => `
        <option value="${this.escapeHtml(p.id)}" ${p.id === productId ? 'selected' : ''}>
          ${this.escapeHtml(p.name)} (${this.escapeHtml(p.sku || 'No SKU')})${p.has_expiry == 1 ? ' [Perishable]' : ''}
        </option>
      `).join('');
    }

    this.generateBatchFormLotNumber();
    
    // Default expiry 6 months from today
    const sixMonths = new Date(Date.now() + 180 * 86400000).toISOString().slice(0, 10);
    document.getElementById('batch-form-expiry').value = sixMonths;
    document.getElementById('batch-form-mfg').value = new Date().toISOString().slice(0, 10);
    document.getElementById('batch-form-qty').value = '10';
    
    const activeProd = this.products.find(p => p.id === (productId || this.products[0]?.id));
    document.getElementById('batch-form-cost').value = activeProd?.cost_price || '0.00';
    document.getElementById('batch-form-notes').value = '';

    const branchGrp = document.getElementById('batch-form-branch-group');
    const branchSel = document.getElementById('batch-form-branch');
    if (this.isMultiBranch && branchGrp && branchSel) {
      branchGrp.style.display = 'block';
      branchSel.innerHTML = this.branches.map(b => `
        <option value="${this.escapeHtml(b.branch_code)}">${this.escapeHtml(b.name)} (${this.escapeHtml(b.branch_code)})</option>
      `).join('');
    } else if (branchGrp) {
      branchGrp.style.display = 'none';
    }

    document.getElementById('batch-modal').classList.add('active');
  },

  closeBatchModal() {
    document.getElementById('batch-modal').classList.remove('active');
  },

  generateBatchFormLotNumber() {
    const d = new Date();
    const dateStr = d.toISOString().slice(0, 10).replace(/-/g, '');
    const rand = Math.floor(100 + Math.random() * 900);
    const bInput = document.getElementById('batch-form-number');
    if (bInput) bInput.value = `LOT-${dateStr}-${rand}`;
  },

  async saveBatchForm() {
    const id = document.getElementById('batch-form-id').value;
    const productId = document.getElementById('batch-form-product-id').value;
    const batchNumber = document.getElementById('batch-form-number').value.trim();
    const expiryDate = document.getElementById('batch-form-expiry').value;
    const mfgDate = document.getElementById('batch-form-mfg').value || null;
    const quantity = parseFloat(document.getElementById('batch-form-qty').value) || 0;
    const costPrice = parseFloat(document.getElementById('batch-form-cost').value) || 0;
    const notes = document.getElementById('batch-form-notes').value.trim();
    const branchCode = this.isMultiBranch ? (document.getElementById('batch-form-branch')?.value || 'MAIN-01') : 'MAIN-01';

    if (!productId || !batchNumber || !expiryDate) {
      this.showToast('Product, Batch Number, and Expiry Date are required.', 'warning');
      return;
    }

    const payload = {
      action: 'save',
      id: id || undefined,
      product_id: productId,
      batch_number: batchNumber,
      expiry_date: expiryDate,
      manufacture_date: mfgDate,
      initial_quantity: quantity,
      current_quantity: quantity,
      cost_price: costPrice,
      branch_code: branchCode,
      notes
    };

    if (this.isOnline) {
      try {
        const res = await this.apiFetch('api/endpoints/batches.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        const verdict = await this.classifyApiResponse(res);
        if (verdict.verdict === 'accepted') {
          this.showToast(`Batch #${batchNumber} recorded.`, 'success');
          this.closeBatchModal();
          await this.fetchBatches();
          await this.fetchProducts();
          await this.fetchInventory();
          this.renderCurrentView();
        } else if (verdict.verdict === 'refused') {
          this.showToast(`The shop's books refused that lot: ${verdict.message}`, 'danger');
        } else {
          this.showToast('Could not reach the server, so the lot was not recorded. Try again once you are online.', 'warning');
        }
      } catch (err) {
        this.showToast('Error saving batch: ' + err.message, 'danger');
      }
    } else {
      this.showToast('Online connection required to record new batch lots.', 'warning');
    }
  },

  printBatchExpiryTag(batchId) {
    const b = this.batches.find(item => item.id === batchId);
    if (!b) return;

    const daysLeft = parseInt(b.days_left !== undefined ? b.days_left : Math.round((new Date(b.expiry_date) - new Date()) / 86400000));
    const isExpired = daysLeft < 0;

    const printWin = window.open('', '_blank', 'width=420,height=520');
    if (!printWin) {
      this.showToast('Popup blocker prevented opening the print label.', 'warning');
      return;
    }

    printWin.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Batch Expiry Tag - ${this.escapeHtml(b.batch_number)}</title>
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; padding: 1.5rem; text-align: center; color: #1e293b; }
          .tag-card { border: 2px dashed #94a3b8; border-radius: 8px; padding: 1.25rem; background: #ffffff; }
          .store-name { font-size: 0.85rem; font-weight: 700; text-transform: uppercase; color: #64748b; letter-spacing: 0.05em; }
          .prod-name { font-size: 1.2rem; font-weight: 800; margin: 0.5rem 0; color: #0f172a; }
          .lot-box { background: #f1f5f9; border: 1px solid #cbd5e1; border-radius: 4px; padding: 0.4rem; font-family: monospace; font-size: 1rem; font-weight: 800; margin: 0.6rem 0; }
          .exp-box { background: ${isExpired ? '#fef2f2' : '#fffbeb'}; border: 1.5px solid ${isExpired ? '#fca5a5' : '#fde68a'}; color: ${isExpired ? '#991b1b' : '#92400e'}; border-radius: 6px; padding: 0.6rem; margin: 0.75rem 0; font-size: 1.1rem; font-weight: 800; }
          .meta { font-size: 0.75rem; color: #64748b; margin-top: 0.5rem; }
          @media print { body { padding: 0; } }
        </style>
      </head>
      <body>
        <div class="tag-card">
          <div class="store-name">${this.escapeHtml(this.storeProfile?.store_name || 'StoreFlow Inventory')}</div>
          <div class="prod-name">${this.escapeHtml(b.product_name)}</div>
          <div class="lot-box">LOT #${this.escapeHtml(b.batch_number)}</div>
          <div class="exp-box">BEST BEFORE: ${this.escapeHtml(b.expiry_date)}</div>
          <div class="meta">
            ${b.manufacture_date ? `<div>Mfg Date: ${this.escapeHtml(b.manufacture_date)}</div>` : ''}
            <div>Branch: ${this.escapeHtml(b.branch_name || b.branch_code || 'MAIN-01')} · Stock: ${b.current_quantity} ${this.escapeHtml(b.product_unit || 'pcs')}</div>
            <div style="margin-top: 0.4rem; font-size: 0.7rem; color: #94a3b8;">Printed: ${new Date().toLocaleString()}</div>
          </div>
        </div>
        <script>
          window.onload = function() { window.print(); };
        </script>
      </body>
      </html>
    `);
    printWin.document.close();
  }
});
