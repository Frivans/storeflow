// assets/js/app-rentals.js
// Equipment & Event Rentals & Hire Engine (Chairs, Canopies, Sound Systems, Machinery)
// Offline-first ready, live overdue calculation, caution deposits, check-in inspection & gate passes.

Object.assign(StoreApp.prototype, {
  rentals: [],
  rentalsFilter: 'all',
  rentalsSearch: '',
  rentalsSummary: {
    total_records: 0,
    active_rentals: 0,
    overdue_rentals: 0,
    items_on_hire: 0,
    caution_deposits_held: 0
  },
  activeReturnRental: null,

  isRentalsEnabled() {
    if (this.storeProfile && this.storeProfile.enable_rentals === 0) return false;
    const ls = localStorage.getItem('storeflow_enable_rentals');
    if (ls === '0') return false;
    return true;
  },

  async fetchRentals() {
    if (!this.isRentalsEnabled()) return;
    try {
      let url = 'api/endpoints/rentals.php?';
      if (this.rentalsFilter && this.rentalsFilter !== 'all' && this.rentalsFilter !== 'analytics') {
        url += `status=${encodeURIComponent(this.rentalsFilter)}&`;
      }
      if (this.rentalsSearch) {
        url += `search=${encodeURIComponent(this.rentalsSearch)}&`;
      }
      if (this.branchCode) {
        url += `branch_code=${encodeURIComponent(this.branchCode)}&`;
      }

      const res = await fetch(url);
      const data = await res.json();
      if (data.success) {
        this.rentals = data.rentals || [];
        this.rentalsSummary = data.summary || this.rentalsSummary;
        this.itemDamageStats = data.item_damage_stats || {};
        this.rentalsLoaded = true;
      } else {
        this.showToast(data.error || 'Failed to load rentals.', 'danger');
      }
    } catch (err) {
      console.warn('Rentals fetch error:', err);
    }
  },

  getRentalsHTML() {
    if (!this.isRentalsEnabled()) {
      return `
        <div style="padding: 3.5rem 1.5rem; text-align: center; background: #ffffff; border-radius: 12px; border: 1.5px dashed var(--slate-300); margin: 2rem auto; max-width: 620px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
          <div style="width: 64px; height: 64px; border-radius: 16px; background: #f3e8ff; color: #7c3aed; display: flex; align-items: center; justify-content: center; font-size: 2rem; margin: 0 auto 1.25rem;">
            <i class="fa-solid fa-boxes-packing"></i>
          </div>
          <h3 style="font-size: 1.35rem; font-weight: 800; color: #0f172a; margin: 0 0 0.5rem;">Rentals & Equipment Hire is Disabled</h3>
          <p style="font-size: 0.9rem; color: #64748b; line-height: 1.5; margin: 0 0 1.5rem;">
            The Event & Equipment Rentals module is currently toggled off in store settings. To hire out chairs, canopies, sound systems, and track caution security deposits, enable the module in Settings.
          </p>
          <button type="button" class="btn btn-primary" onclick="app.switchView('profile')" style="background: #7c3aed; border-color: #6d28d9; font-weight: 700; padding: 0.65rem 1.5rem;">
            <i class="fa-solid fa-sliders"></i> Open Settings & Enable Rentals
          </button>
        </div>
      `;
    }

    if (!this.rentalsLoaded && (!this.rentals || this.rentals.length === 0) && !this._fetchingRentals) {
      this._fetchingRentals = true;
      this.fetchRentals().then(() => {
        this._fetchingRentals = false;
        if (this.currentView === 'rentals') {
          this.renderCurrentView();
        }
      });
    }

    const s = this.rentalsSummary || {};

    // Compute fleet capacity from catalog products and items currently on hire (#/# KPI)
    const rentalProducts = (this.products || []).filter(p => this.isRentalProduct && this.isRentalProduct(p));
    const warehouseFleetStock = rentalProducts.reduce((sum, p) => {
      if (p.product_type === 'service') return sum;
      const eff = typeof this.getEffectiveProductForBranch === 'function' ? this.getEffectiveProductForBranch(p) : p;
      const stock = Number(eff && eff.effectiveStock !== undefined ? eff.effectiveStock : (p.current_quantity || 0));
      return sum + Math.max(0, stock);
    }, 0);

    const itemsOnHire = Number(s.items_on_hire || 0);
    const inRepairCount = Number(s.damaged_count || 0);
    const missingCount = Number(s.missing_count || 0);
    const totalFleetCapacity = warehouseFleetStock + itemsOnHire + inRepairCount + missingCount;
    const fleetRatioStr = totalFleetCapacity > 0 ? `${itemsOnHire} / ${totalFleetCapacity}` : `${itemsOnHire}`;
    const fleetUtilizationPercent = totalFleetCapacity > 0 ? Math.round((itemsOnHire / totalFleetCapacity) * 100) : 0;

    return `
      <div class="view-header" style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 1rem; margin-bottom: 1.25rem;">
        <div>
          <h2 style="font-size: 1.4rem; font-weight: 800; color: var(--slate-900); margin: 0; display: flex; align-items: center; gap: 0.5rem;">
            <i class="fa-solid fa-boxes-packing" style="color: #8b5cf6;"></i> Event & Equipment Rentals
          </h2>
          <p style="color: var(--slate-500); font-size: 0.85rem; margin-top: 0.2rem;">
            Track party hire, chairs, canopies & sound gear, security deposits, overdue penalties & check-in inspections.
          </p>
        </div>
        <div style="display: flex; gap: 0.5rem; align-items: center; flex-wrap: wrap;">
          <button type="button" class="btn btn-outline btn-sm" onclick="app.refreshRentalsView()" title="Refresh List" style="padding: 0.45rem 0.75rem;">
            <i class="fa-solid fa-rotate"></i> Refresh
          </button>
          <button type="button" class="btn btn-outline btn-sm" onclick="app.openRentalFleetRestockModal()" title="Restock repaired or recovered gear back into fleet" style="padding: 0.45rem 0.75rem; color: #16a34a; border-color: #86efac; font-weight: 700; background: #f0fdf4;">
            <i class="fa-solid fa-screwdriver-wrench"></i> Restock Repaired Gear ${((s.damaged_count || 0) > 0 || (s.missing_count || 0) > 0) ? `(${(s.damaged_count || 0) + (s.missing_count || 0)})` : ''}
          </button>
          <button type="button" class="btn btn-primary" onclick="app.openNewRentalModal()" style="display: flex; align-items: center; gap: 0.45rem; font-weight: 700; background: #7c3aed; border-color: #6d28d9;">
            <i class="fa-solid fa-truck-ramp-box"></i> + New Rental Dispatch
          </button>
        </div>
      </div>

      <!-- Stat Cards -->
      <div class="metrics-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 1.5rem;">
        <div class="stat-card" style="background: #ffffff; padding: 1.1rem; border-radius: 10px; border: 1px solid var(--slate-200); box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <span style="font-size: 0.8rem; font-weight: 700; color: var(--slate-500); text-transform: uppercase;">Active Dispatches</span>
            <span class="badge" style="background: #e0e7ff; color: #4338ca; padding: 3px 7px; border-radius: 6px;"><i class="fa-solid fa-truck"></i></span>
          </div>
          <div style="font-size: 1.6rem; font-weight: 800; color: var(--slate-900); margin-top: 0.35rem;">
            ${s.active_rentals || 0}
          </div>
          <div style="font-size: 0.75rem; color: #64748b; margin-top: 0.25rem;">Contracts out in the field</div>
        </div>

        <div class="stat-card" style="background: #ffffff; padding: 1.1rem; border-radius: 10px; border: 1px solid var(--slate-200); box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <span style="font-size: 0.8rem; font-weight: 700; color: var(--slate-500); text-transform: uppercase;">Items on Hire</span>
            <span class="badge" style="background: #ede9fe; color: #7c3aed; padding: 3px 7px; border-radius: 6px;"><i class="fa-solid fa-chair"></i></span>
          </div>
          <div style="font-size: 1.6rem; font-weight: 800; color: #7c3aed; margin-top: 0.35rem;">
            ${fleetRatioStr}
          </div>
          <div style="font-size: 0.75rem; color: #64748b; margin-top: 0.25rem;">
            ${totalFleetCapacity > 0 ? `${fleetUtilizationPercent}% deployed (${warehouseFleetStock} in warehouse${inRepairCount > 0 ? ` &middot; ${inRepairCount} in repair` : ''}${missingCount > 0 ? ` &middot; ${missingCount} missing` : ''})` : 'Chairs, canopies & gear deployed'}
          </div>
        </div>

        <div class="stat-card" style="background: #ffffff; padding: 1.1rem; border-radius: 10px; border: 1px solid ${(s.overdue_rentals > 0) ? '#fecdd3' : 'var(--slate-200)'}; box-shadow: 0 1px 3px rgba(0,0,0,0.04); background: ${(s.overdue_rentals > 0) ? '#fff1f2' : '#ffffff'};">
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <span style="font-size: 0.8rem; font-weight: 700; color: ${(s.overdue_rentals > 0) ? '#be123c' : 'var(--slate-500)'}; text-transform: uppercase;">Overdue Returns</span>
            <span class="badge" style="background: ${(s.overdue_rentals > 0) ? '#ffe4e6' : '#f1f5f9'}; color: ${(s.overdue_rentals > 0) ? '#e11d48' : '#64748b'}; padding: 3px 7px; border-radius: 6px;"><i class="fa-solid fa-clock-rotate-left"></i></span>
          </div>
          <div style="font-size: 1.6rem; font-weight: 800; color: ${(s.overdue_rentals > 0) ? '#e11d48' : 'var(--slate-900)'}; margin-top: 0.35rem;">
            ${s.overdue_rentals || 0}
          </div>
          <div style="font-size: 0.75rem; color: ${(s.overdue_rentals > 0) ? '#9f1239' : '#64748b'}; margin-top: 0.25rem;">Accumulating daily late fees</div>
        </div>

        <div class="stat-card" style="background: #ffffff; padding: 1.1rem; border-radius: 10px; border: 1px solid var(--slate-200); box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <span style="font-size: 0.8rem; font-weight: 700; color: var(--slate-500); text-transform: uppercase;">Caution Deposits Held</span>
            <span class="badge" style="background: #e0f2fe; color: #0369a1; padding: 3px 7px; border-radius: 6px;"><i class="fa-solid fa-vault"></i></span>
          </div>
          <div style="font-size: 1.6rem; font-weight: 800; color: #0284c7; margin-top: 0.35rem;">
            ${this.formatCurrency(s.caution_deposits_held || 0)}
          </div>
          <div style="font-size: 0.75rem; color: #64748b; margin-top: 0.25rem;">Security deposits held in drawer</div>
        </div>
      </div>

      <!-- Filter & Search Toolbar -->
      <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.75rem; background: #ffffff; padding: 0.85rem 1rem; border-radius: 8px; border: 1px solid var(--slate-200); margin-bottom: 1rem;">
        <div style="display: flex; gap: 0.4rem; flex-wrap: wrap;">
          <button type="button" class="btn btn-sm ${(this.rentalsFilter === 'all') ? 'btn-primary' : 'btn-outline'}" onclick="app.setRentalsFilter('all')">All</button>
          <button type="button" class="btn btn-sm ${(this.rentalsFilter === 'active') ? 'btn-primary' : 'btn-outline'}" onclick="app.setRentalsFilter('active')">Active / Dispatched</button>
          <button type="button" class="btn btn-sm ${(this.rentalsFilter === 'booked') ? 'btn-primary' : 'btn-outline'}" onclick="app.setRentalsFilter('booked')" style="${this.rentalsFilter === 'booked' ? 'background:#0284c7; border-color:#0369a1;' : ''}">
            <i class="fa-solid fa-file-invoice"></i> Booked / Quotes
          </button>
          <button type="button" class="btn btn-sm ${(this.rentalsFilter === 'overdue') ? 'btn-danger' : 'btn-outline'}" onclick="app.setRentalsFilter('overdue')">
            <i class="fa-solid fa-triangle-exclamation"></i> Overdue
          </button>
          <button type="button" class="btn btn-sm ${(this.rentalsFilter === 'returned') ? 'btn-primary' : 'btn-outline'}" onclick="app.setRentalsFilter('returned')">Returned / Settled</button>
          <button type="button" class="btn btn-sm ${(this.rentalsFilter === 'analytics') ? 'btn-primary' : 'btn-outline'}" onclick="app.setRentalsFilter('analytics')" style="${this.rentalsFilter === 'analytics' ? 'background:#6d28d9; border-color:#5b21b6;' : ''}">
            <i class="fa-solid fa-chart-pie"></i> Fleet Analytics & Rankings
          </button>
        </div>

        <div style="position: relative; min-width: 260px;">
          <input type="text" id="rentals-search-input" class="form-control" placeholder="Search rental #, customer, phone, location..." value="${this.escapeHtml(this.rentalsSearch || '')}" style="padding-left: 2.1rem; font-size: 0.85rem;">
          <i class="fa-solid fa-magnifying-glass" style="position: absolute; left: 0.75rem; top: 50%; transform: translateY(-50%); color: var(--slate-400); font-size: 0.85rem;"></i>
        </div>
      </div>

      ${(this.rentalsFilter === 'analytics') ? this.getRentalAnalyticsHTML() : `
      <!-- Rentals Table -->
      <div class="card" style="background: #ffffff; border-radius: 8px; border: 1px solid var(--slate-200); overflow: hidden;">
        <div class="table-responsive">
          <table class="table" style="width: 100%; border-collapse: collapse; text-align: left; font-size: 0.85rem;">
            <thead style="background: #f8fafc; border-bottom: 1px solid var(--slate-200); color: var(--slate-600); font-size: 0.75rem; text-transform: uppercase;">
              <tr>
                <th style="padding: 0.75rem 1rem;">Rental # / Dates</th>
                <th style="padding: 0.75rem 1rem;">Customer & Venue</th>
                <th style="padding: 0.75rem 1rem;">Equipment & Duration</th>
                <th style="padding: 0.75rem 1rem;">Charges & Caution</th>
                <th style="padding: 0.75rem 1rem;">Status</th>
                <th style="padding: 0.75rem 1rem; text-align: right;">Actions</th>
              </tr>
            </thead>
            <tbody>
              ${(this.rentals && this.rentals.length > 0) ? this.rentals.map(r => {
                const isOverdue = !!r.is_overdue || r.status === 'OVERDUE';
                const isReturned = r.status === 'RETURNED';
                const isDispatched = r.status === 'DISPATCHED';
                const isBooked = r.status === 'BOOKED';
                const netOwed = Math.max(0, Number(r.additional_amount_owed || 0) - Number(r.balance_paid || 0));
                const hasBalanceOwed = (isReturned && netOwed > 0.009 && r.payment_status !== 'PAID');

                let statusBadge = '';
                if (isReturned) {
                  if (hasBalanceOwed) {
                    statusBadge = `<span class="badge" style="background:#fee2e2; color:#b91c1c; border:1px solid #fca5a5; padding:3px 8px; font-weight:700;"><i class="fa-solid fa-triangle-exclamation"></i> Balance Owed (${this.formatCurrency(netOwed)})</span>`;
                  } else {
                    statusBadge = '<span class="badge" style="background:#dcfce7; color:#15803d; border:1px solid #86efac; padding:3px 8px; font-weight:700;"><i class="fa-solid fa-circle-check"></i> Returned &amp; Settled</span>';
                  }
                } else if (isOverdue) {
                  statusBadge = `<span class="badge" style="background:#fee2e2; color:#b91c1c; border:1px solid #fca5a5; padding:3px 8px; font-weight:700;"><i class="fa-solid fa-clock-rotate-left"></i> Overdue (${r.days_overdue || 1}d late)</span>`;
                } else if (isDispatched) {
                  statusBadge = '<span class="badge" style="background:#e0f2fe; color:#0369a1; border:1px solid #bae6fd; padding:3px 8px;"><i class="fa-solid fa-truck-fast"></i> Out on Hire</span>';
                } else if (isBooked) {
                  statusBadge = '<span class="badge" style="background:#f0f9ff; color:#0284c7; border:1px solid #7dd3fc; padding:3px 8px; font-weight:700;"><i class="fa-solid fa-calendar-check"></i> Booked / Quote</span>';
                } else {
                  statusBadge = `<span class="badge badge-secondary">${this.escapeHtml(r.status)}</span>`;
                }

                const itemsSummary = (r.items && r.items.length > 0)
                  ? r.items.map(it => `${it.quantity_dispatched}x ${it.product_name}`).join(', ')
                  : 'Equipment';

                return `
                  <tr style="border-bottom: 1px solid var(--slate-100); ${isOverdue ? 'background: #fffdfd;' : ''}">
                    <td style="padding: 0.75rem 1rem; vertical-align: top;">
                      <div style="font-weight: 700; color: var(--slate-900); font-family: monospace;">${this.escapeHtml(r.rental_number)}</div>
                      <div style="font-size: 0.74rem; color: var(--slate-500); margin-top: 2px;">
                        <span>Out: ${this.escapeHtml(r.pickup_date)}</span> &bull; 
                        <strong style="color: ${isOverdue ? '#e11d48' : '#475569'};">Due: ${this.escapeHtml(r.return_due_date)}</strong>
                      </div>
                    </td>

                    <td style="padding: 0.75rem 1rem; vertical-align: top;">
                      <div style="font-weight: 700; color: var(--slate-800);">${this.escapeHtml(r.customer_name)}</div>
                      <div style="font-size: 0.74rem; color: var(--slate-500); margin-top: 2px;">
                        ${r.customer_phone ? `<span><i class="fa-solid fa-phone"></i> ${this.escapeHtml(r.customer_phone)}</span>` : ''}
                        ${r.customer_id_card ? ` &bull; <span title="Ghana Card / ID"><i class="fa-solid fa-id-card"></i> ${this.escapeHtml(r.customer_id_card)}</span>` : ''}
                      </div>
                      ${r.event_location ? `<div style="font-size: 0.72rem; color: #6366f1; margin-top: 2px;"><i class="fa-solid fa-location-dot"></i> ${this.escapeHtml(r.event_location)}</div>` : ''}
                    </td>

                    <td style="padding: 0.75rem 1rem; vertical-align: top;">
                      <div style="font-weight: 600; color: var(--slate-700); max-width: 280px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${this.escapeHtml(itemsSummary)}">
                        ${this.escapeHtml(itemsSummary)}
                      </div>
                      <div style="font-size: 0.74rem; color: var(--slate-500); margin-top: 2px;">
                        Duration: <strong>${r.duration_days} day(s)</strong>
                      </div>
                    </td>

                    <td style="padding: 0.75rem 1rem; vertical-align: top;">
                      <div style="font-weight: 700; color: var(--slate-900);">Rental: ${this.formatCurrency(r.total_rental_amount)}</div>
                      <div style="margin-top: 2px;">
                        ${r.payment_status === 'PENDING' ? '<span class="badge" style="font-size:0.65rem; padding:1px 6px; background:#fef3c7; color:#b45309; font-weight:700;">Pay on Return</span>' : (r.payment_status === 'DEPOSIT_ONLY' ? '<span class="badge" style="font-size:0.65rem; padding:1px 6px; background:#e0e7ff; color:#4338ca; font-weight:700;">Deposit Only</span>' : (r.payment_status === 'BALANCE_OWED' ? `<span class="badge" style="font-size:0.65rem; padding:1px 6px; background:#fee2e2; color:#b91c1c; font-weight:700;">${this.formatCurrency(netOwed)} owed</span>` : '<span class="badge" style="font-size:0.65rem; padding:1px 6px; background:#dcfce7; color:#15803d; font-weight:700;">Paid Upfront</span>'))}
                      </div>
                      <div style="font-size: 0.74rem; color: #0369a1; margin-top: 2px;">
                        Caution: <strong>${this.formatCurrency(r.caution_deposit)}</strong> 
                        <span class="badge" style="font-size:0.65rem; padding: 1px 4px; background: #e0f2fe; color: #0369a1;">${this.escapeHtml(r.caution_deposit_status || 'HELD')}</span>
                      </div>
                      ${hasBalanceOwed ? `
                        <div style="font-size: 0.72rem; color: #b91c1c; font-weight: 800; margin-top: 2px;">
                          Owed: ${this.formatCurrency(netOwed)}
                        </div>
                      ` : (Number(r.balance_paid || 0) > 0 ? `
                        <div style="font-size: 0.72rem; color: #15803d; font-weight: 700; margin-top: 2px;">
                          Settled: ${this.formatCurrency(r.balance_paid)}
                        </div>
                      ` : '')}
                    </td>

                    <td style="padding: 0.75rem 1rem; vertical-align: top;">
                      ${statusBadge}
                      ${r.actual_return_date ? `
                        <div style="font-size: 0.72rem; color: var(--slate-400); margin-top: 3px;">
                          Ret: ${this.escapeHtml(r.actual_return_date)}
                        </div>
                      ` : ''}
                    </td>

                    <td style="padding: 0.75rem 1rem; vertical-align: top; text-align: right; white-space: nowrap;">
                      <div style="display: flex; gap: 0.35rem; justify-content: flex-end; align-items: center;">
                        ${isBooked ? `
                          <button type="button" class="btn btn-sm btn-primary" onclick="app.dispatchRentalBooking(${this.jsStr(r.id)})" style="padding: 0.25rem 0.55rem; font-size: 0.75rem; font-weight: 700; background:#7c3aed; border-color:#6d28d9;" title="Allocate equipment and dispatch out to client">
                            <i class="fa-solid fa-truck-ramp-box"></i> Dispatch
                          </button>
                          <button type="button" class="btn btn-sm btn-outline" onclick="app.printRentalGatePass(${this.jsStr(r.id)})" style="padding: 0.25rem 0.5rem; font-size: 0.75rem; color:#0284c7; border-color:#7dd3fc; background:#f0f9ff;" title="Print Rental Quotation / Advance Booking">
                            <i class="fa-solid fa-file-invoice"></i> Quotation
                          </button>
                        ` : `
                          ${!isReturned ? `
                            <button type="button" class="btn btn-sm btn-success" onclick="app.openRentalReturnModal(${this.jsStr(r.id)})" style="padding: 0.25rem 0.55rem; font-size: 0.75rem; font-weight: 700;" title="Check-in return & settle caution deposit">
                              <i class="fa-solid fa-clipboard-check"></i> Check-In
                            </button>
                          ` : ''}
                          ${hasBalanceOwed ? `
                            <button type="button" class="btn btn-sm btn-primary" onclick="app.openRentalSettlementModal(${this.jsStr(r.id)})" style="padding: 0.25rem 0.55rem; font-size: 0.75rem; font-weight: 700; background:#0284c7; border-color:#0369a1; color:#ffffff;" title="Accept payment and reconcile customer balance">
                              <i class="fa-solid fa-hand-holding-dollar"></i> Settle Balance
                            </button>
                          ` : ''}
                          ${isReturned && (Number(r.balance_paid || 0) > 0 || (r.additional_amount_owed > 0 && r.payment_status === 'PAID')) ? `
                            <button type="button" class="btn btn-sm btn-outline" onclick="app.printRentalSettlementSlip(${this.jsStr(r.id)})" style="padding: 0.25rem 0.5rem; font-size: 0.75rem; color:#15803d; border-color:#86efac; background:#f0fdf4;" title="Print Rental Settlement Receipt / Clearance Slip">
                              <i class="fa-solid fa-receipt"></i> Settlement Slip
                            </button>
                          ` : ''}
                          <button type="button" class="btn btn-sm btn-outline" onclick="app.printRentalGatePass(${this.jsStr(r.id)})" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" title="Print Rental Gate Pass / Contract">
                            <i class="fa-solid fa-print"></i> Gate Pass
                          </button>
                        `}
                      </div>
                    </td>
                  </tr>
                `;
              }).join('') : `
                <tr>
                  <td colspan="6" style="text-align: center; padding: 3rem 1rem; color: var(--slate-400);">
                    ${!this.rentalsLoaded ? `
                      <i class="fa-solid fa-spinner fa-spin" style="font-size: 2rem; color: #8b5cf6; margin-bottom: 0.75rem; display: block;"></i>
                      <p style="font-size: 0.95rem; font-weight: 600; margin: 0; color: var(--slate-700);">Loading equipment rentals...</p>
                    ` : `
                      <i class="fa-solid fa-truck-ramp-box" style="font-size: 2.5rem; margin-bottom: 0.75rem; display: block; opacity: 0.5;"></i>
                      <p style="font-size: 0.95rem; font-weight: 600; margin: 0;">No equipment rentals found.</p>
                      <span style="font-size: 0.8rem;">Click "+ New Rental Dispatch" above to create an event hire contract.</span>
                    `}
                  </td>
                </tr>
              `}
            </tbody>
          </table>
        </div>
      </div>
      `}
    `;
  },

  bindRentalsEvents() {
    const searchInput = document.getElementById('rentals-search-input');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        this.rentalsSearch = e.target.value.trim();
        clearTimeout(this._rentalSearchTimer);
        this._rentalSearchTimer = setTimeout(() => {
          this.fetchRentals().then(() => this.renderCurrentView());
        }, 300);
      });
    }
  },

  setRentalsFilter(filter) {
    this.rentalsFilter = filter;
    this.fetchRentals().then(() => this.renderCurrentView());
  },

  refreshRentalsView() {
    this.fetchRentals().then(() => {
      this.renderCurrentView();
      this.showToast('Rentals list refreshed.', 'info');
    });
  },

  getRentalAnalyticsHTML() {
    const allRentals = this.rentals || [];
    
    // 1. Aggregate Equipment Performance
    const itemMap = {};
    let totalRevenue = 0;
    let totalDispatchedAllTime = 0;
    let totalDamagedAllTime = 0;
    let totalMissingAllTime = 0;

    allRentals.forEach(r => {
      totalRevenue += parseFloat(r.total_rental_amount || 0);
      const isCurrentlyActive = (r.status === 'DISPATCHED' || r.status === 'OVERDUE');
      
      (r.items || []).forEach(it => {
        const key = it.product_id || it.product_name;
        if (!itemMap[key]) {
          const prod = (this.products || []).find(p => p.id === it.product_id);
          const inWarehouse = prod ? (prod.product_type === 'service' ? 'Unlimited' : Math.max(0, parseFloat(prod.current_quantity || 0))) : 0;
          
          itemMap[key] = {
            id: it.product_id,
            name: it.product_name,
            sku: prod ? prod.sku : '',
            category: prod ? prod.category : 'Rental',
            in_warehouse: inWarehouse,
            contracts_count: 0,
            units_dispatched: 0,
            currently_on_hire: 0,
            revenue: 0,
            units_damaged: 0,
            units_missing: 0
          };
        }

        const rec = itemMap[key];
        rec.contracts_count += 1;
        const qDispatched = parseFloat(it.quantity_dispatched || 0);
        rec.units_dispatched += qDispatched;
        totalDispatchedAllTime += qDispatched;
        rec.revenue += parseFloat(it.line_total || 0);

        if (isCurrentlyActive) {
          rec.currently_on_hire += qDispatched;
        }

        const qDmg = parseFloat(it.quantity_damaged || 0);
        const qMis = parseFloat(it.quantity_missing || 0);
        rec.units_damaged += qDmg;
        rec.units_missing += qMis;
        totalDamagedAllTime += qDmg;
        totalMissingAllTime += qMis;
      });
    });

    // Ranked by units dispatched descending
    const rankedItems = Object.values(itemMap).sort((a, b) => b.units_dispatched - a.units_dispatched);
    const maxDispatched = rankedItems.length > 0 ? Math.max(1, rankedItems[0].units_dispatched) : 1;

    // 2. Aggregate Demographics & Venues
    const venueMap = {};
    const customerMap = {};
    let totalDurationDays = 0;

    allRentals.forEach(r => {
      totalDurationDays += parseInt(r.duration_days || 1, 10);
      
      const venue = (r.event_location || '').trim() || 'Unspecified Venue';
      if (!venueMap[venue]) {
        venueMap[venue] = { name: venue, count: 0, totalAmount: 0 };
      }
      venueMap[venue].count += 1;
      venueMap[venue].totalAmount += parseFloat(r.total_rental_amount || 0);

      const cust = (r.customer_name || '').trim() || 'Walk-in Hirer';
      if (!customerMap[cust]) {
        customerMap[cust] = { name: cust, phone: r.customer_phone || '', count: 0, totalAmount: 0, activeCount: 0 };
      }
      customerMap[cust].count += 1;
      customerMap[cust].totalAmount += parseFloat(r.total_rental_amount || 0);
      if (r.status === 'DISPATCHED' || r.status === 'OVERDUE') {
        customerMap[cust].activeCount += 1;
      }
    });

    const rankedVenues = Object.values(venueMap).sort((a, b) => b.totalAmount - a.totalAmount).slice(0, 5);
    const rankedCustomers = Object.values(customerMap).sort((a, b) => b.totalAmount - a.totalAmount).slice(0, 5);
    const avgDuration = allRentals.length > 0 ? (totalDurationDays / allRentals.length).toFixed(1) : '0.0';
    const safetyRate = totalDispatchedAllTime > 0 
      ? (((totalDispatchedAllTime - (totalDamagedAllTime + totalMissingAllTime)) / totalDispatchedAllTime) * 100).toFixed(1)
      : '100.0';

    return `
      <div style="display: flex; flex-direction: column; gap: 1.25rem;">
        <!-- Demographic & Velocity KPI Cards -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 1rem;">
          <div style="background: #ffffff; padding: 1.1rem; border-radius: 10px; border: 1px solid var(--slate-200); box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
            <div style="font-size: 0.75rem; font-weight: 700; color: #64748b; text-transform: uppercase;">Total Rental Revenue</div>
            <div style="font-size: 1.5rem; font-weight: 800; color: #16a34a; margin-top: 0.35rem;">
              ${this.formatCurrency(totalRevenue)}
            </div>
            <div style="font-size: 0.75rem; color: #64748b; margin-top: 0.25rem;">Across ${allRentals.length} hire contract(s)</div>
          </div>

          <div style="background: #ffffff; padding: 1.1rem; border-radius: 10px; border: 1px solid var(--slate-200); box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
            <div style="font-size: 0.75rem; font-weight: 700; color: #64748b; text-transform: uppercase;">Average Event Duration</div>
            <div style="font-size: 1.5rem; font-weight: 800; color: #7c3aed; margin-top: 0.35rem;">
              ${avgDuration} Day(s)
            </div>
            <div style="font-size: 0.75rem; color: #64748b; margin-top: 0.25rem;">Average customer event turnaround</div>
          </div>

          <div style="background: #ffffff; padding: 1.1rem; border-radius: 10px; border: 1px solid var(--slate-200); box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
            <div style="font-size: 0.75rem; font-weight: 700; color: #64748b; text-transform: uppercase;">Fleet Return Integrity</div>
            <div style="font-size: 1.5rem; font-weight: 800; color: #0284c7; margin-top: 0.35rem;">
              ${safetyRate}%
            </div>
            <div style="font-size: 0.75rem; color: #64748b; margin-top: 0.25rem;">${totalDamagedAllTime} damaged &bull; ${totalMissingAllTime} missing</div>
          </div>

          <div style="background: #ffffff; padding: 1.1rem; border-radius: 10px; border: 1px solid var(--slate-200); box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
            <div style="font-size: 0.75rem; font-weight: 700; color: #64748b; text-transform: uppercase;">Unique Event Venues</div>
            <div style="font-size: 1.5rem; font-weight: 800; color: #d97706; margin-top: 0.35rem;">
              ${Object.keys(venueMap).length}
            </div>
            <div style="font-size: 0.75rem; color: #64748b; margin-top: 0.25rem;">Delivery locations & destinations served</div>
          </div>
        </div>

        <!-- Visual Utilization & Deployment Bar Chart -->
        <div style="background: #ffffff; border-radius: 10px; border: 1px solid var(--slate-200); padding: 1.25rem; box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
            <div>
              <h3 style="margin: 0; font-size: 1rem; font-weight: 800; color: #0f172a; display: flex; align-items: center; gap: 0.5rem;">
                <i class="fa-solid fa-chart-simple" style="color: #7c3aed;"></i> Fleet Deployment & Volume Distribution
              </h3>
              <p style="margin: 2px 0 0; font-size: 0.75rem; color: #64748b;">Visualizing cumulative units deployed across all event dispatches.</p>
            </div>
          </div>

          <div style="display: flex; flex-direction: column; gap: 0.85rem;">
            ${rankedItems.length === 0 ? `
              <div style="text-align: center; padding: 2rem; color: var(--slate-400);">No rental equipment dispatched yet.</div>
            ` : rankedItems.slice(0, 6).map(it => {
              const pct = Math.round((it.units_dispatched / maxDispatched) * 100);
              return `
                <div>
                  <div style="display: flex; justify-content: space-between; font-size: 0.82rem; margin-bottom: 0.25rem;">
                    <span style="font-weight: 700; color: var(--slate-800);">${this.escapeHtml(it.name)}</span>
                    <span style="color: #64748b;"><strong>${it.units_dispatched} units</strong> (${it.contracts_count} contracts &bull; ${this.formatCurrency(it.revenue)})</span>
                  </div>
                  <div style="background: #f1f5f9; border-radius: 999px; height: 12px; overflow: hidden; display: flex;">
                    <div style="width: ${pct}%; background: linear-gradient(90deg, #7c3aed, #a855f7); border-radius: 999px; transition: width 0.3s ease;"></div>
                  </div>
                </div>
              `;
            }).join('')}
          </div>
        </div>

        <!-- Table of Best Performing Rental Items -->
        <div class="card" style="background: #ffffff; border-radius: 10px; border: 1px solid var(--slate-200); overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
          <div style="padding: 1rem 1.25rem; border-bottom: 1px solid var(--slate-200); background: #faf5ff; display: flex; justify-content: space-between; align-items: center;">
            <h3 style="margin: 0; font-size: 0.95rem; font-weight: 800; color: #581c87; display: flex; align-items: center; gap: 0.45rem;">
              <i class="fa-solid fa-trophy" style="color: #eab308;"></i> Best Performing Rental Items (Ranked Breakdown)
            </h3>
            <span class="badge" style="background: #ede9fe; color: #7c3aed; font-weight: 700; font-size: 0.75rem;">${rankedItems.length} Rental Fleet Assets</span>
          </div>

          <div class="table-responsive">
            <table class="table" style="width: 100%; border-collapse: collapse; text-align: left; font-size: 0.85rem;">
              <thead style="background: #f8fafc; border-bottom: 1px solid var(--slate-200); color: var(--slate-600); font-size: 0.72rem; text-transform: uppercase;">
                <tr>
                  <th style="padding: 0.65rem 0.85rem; width: 60px; text-align: center;">Rank</th>
                  <th style="padding: 0.65rem 0.85rem;">Equipment Item</th>
                  <th style="padding: 0.65rem 0.85rem; text-align: center;">Times Hired</th>
                  <th style="padding: 0.65rem 0.85rem; text-align: center;">Total Units Out</th>
                  <th style="padding: 0.65rem 0.85rem; text-align: center; color: #7c3aed;">In Field Now</th>
                  <th style="padding: 0.65rem 0.85rem; text-align: center;">In Warehouse</th>
                  <th style="padding: 0.65rem 0.85rem; text-align: right; color: #16a34a;">Rental Revenue</th>
                  <th style="padding: 0.65rem 0.85rem; text-align: center;">Damage / Loss</th>
                </tr>
              </thead>
              <tbody>
                ${rankedItems.length === 0 ? `
                  <tr><td colspan="8" style="text-align: center; padding: 2.5rem; color: var(--slate-400);">No equipment rental records available yet.</td></tr>
                ` : rankedItems.map((it, idx) => {
                  let medal = `<strong style="color: var(--slate-500); font-size: 0.85rem;">#${idx + 1}</strong>`;
                  if (idx === 0) medal = '<span style="font-size: 1.1rem;" title="1st Place">🥇</span>';
                  else if (idx === 1) medal = '<span style="font-size: 1.1rem;" title="2nd Place">🥈</span>';
                  else if (idx === 2) medal = '<span style="font-size: 1.1rem;" title="3rd Place">🥉</span>';

                  const stats = (this.itemDamageStats && (this.itemDamageStats[it.id] || this.itemDamageStats[it.product_id])) || {};
                  const netDamaged = stats.net_damaged !== undefined ? Number(stats.net_damaged) : Math.max(0, it.units_damaged);
                  const netMissing = stats.net_missing !== undefined ? Number(stats.net_missing) : Math.max(0, it.units_missing);
                  const totalDmgEver = (it.units_damaged || 0) + (it.units_missing || 0);
                  const awaitingResolution = netDamaged + netMissing;
                  return `
                    <tr style="border-bottom: 1px solid var(--slate-100);">
                      <td style="padding: 0.65rem 0.85rem; text-align: center;">${medal}</td>
                      <td style="padding: 0.65rem 0.85rem;">
                        <strong>${this.escapeHtml(it.name)}</strong>
                        ${it.sku ? `<div style="font-size: 0.72rem; color: var(--slate-400); font-family: monospace;">${this.escapeHtml(it.sku)}</div>` : ''}
                      </td>
                      <td style="padding: 0.65rem 0.85rem; text-align: center; font-weight: 700; color: var(--slate-700);">${it.contracts_count}</td>
                      <td style="padding: 0.65rem 0.85rem; text-align: center; font-weight: 800; color: #7c3aed;">${it.units_dispatched}</td>
                      <td style="padding: 0.65rem 0.85rem; text-align: center; font-weight: 700; color: #0284c7;">
                        ${it.currently_on_hire > 0 ? `<span class="badge" style="background:#e0f2fe; color:#0369a1; padding:2px 6px;">${it.currently_on_hire} in field</span>` : '<span style="color:#94a3b8;">0</span>'}
                      </td>
                      <td style="padding: 0.65rem 0.85rem; text-align: center; color: var(--slate-600);">${it.in_warehouse}</td>
                      <td style="padding: 0.65rem 0.85rem; text-align: right; font-weight: 800; color: #16a34a;">${this.formatCurrency(it.revenue)}</td>
                      <td style="padding: 0.65rem 0.85rem; text-align: center;">
                        ${awaitingResolution > 0 ? `
                          <div style="display: flex; align-items: center; justify-content: center; gap: 4px; flex-wrap: wrap;">
                            <span class="badge" style="background:#fee2e2; color:#b91c1c; font-weight:700;">${awaitingResolution} awaiting (${netDamaged}d / ${netMissing}m)</span>
                            ${netDamaged > 0 ? `
                              <button type="button" class="btn btn-sm btn-outline" onclick="app.openRentalFleetRestockModal(${this.jsStr(it.id)}, 'REPAIRED');" style="padding: 1px 6px; font-size: 0.68rem; color: #16a34a; border-color: #86efac; background: #f0fdf4; font-weight: 700;" title="Restock repaired units to warehouse fleet (max ${netDamaged})">
                                <i class="fa-solid fa-screwdriver-wrench"></i> Repaired (${netDamaged})
                              </button>
                            ` : ''}
                            ${netMissing > 0 ? `
                              <button type="button" class="btn btn-sm btn-outline" onclick="app.openRentalFleetRestockModal(${this.jsStr(it.id)}, 'FOUND_REPLACED');" style="padding: 1px 6px; font-size: 0.68rem; color: #0284c7; border-color: #7dd3fc; background: #f0f9ff; font-weight: 700;" title="Restore recovered missing items or customer replacement (max ${netMissing})">
                                <i class="fa-solid fa-rotate-left"></i> Restored (${netMissing})
                              </button>
                            ` : ''}
                          </div>
                        ` : (totalDmgEver > 0 ? `
                          <span class="badge" style="background:#f0fdf4; color:#15803d; border:1px solid #bbf7d0; font-weight:700;" title="All damaged and missing items have been fully repaired or replaced into warehouse">
                            <i class="fa-solid fa-check-double"></i> 100% Restored (${totalDmgEver} fixed)
                          </span>
                        ` : '<span style="color:#16a34a; font-size:0.75rem;">✓ 0 Issues</span>')}
                      </td>
                    </tr>
                  `;
                }).join('')}
              </tbody>
            </table>
          </div>
        </div>

        <!-- Venue Demographics & Top Hiring Customers -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 1rem;">
          <!-- Top Venues Card -->
          <div style="background: #ffffff; border-radius: 10px; border: 1px solid var(--slate-200); padding: 1.1rem; box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
            <h4 style="margin: 0 0 0.75rem; font-size: 0.9rem; font-weight: 800; color: var(--slate-800); display: flex; align-items: center; gap: 0.4rem;">
              <i class="fa-solid fa-location-dot" style="color: #6366f1;"></i> Top Event Venues & Destinations
            </h4>
            <div style="display: flex; flex-direction: column; gap: 0.5rem;">
              ${rankedVenues.length === 0 ? `
                <div style="font-size: 0.82rem; color: var(--slate-400); text-align: center; padding: 1rem;">No venue data recorded yet.</div>
              ` : rankedVenues.map((v, i) => `
                <div style="display: flex; justify-content: space-between; align-items: center; padding: 0.5rem 0.7rem; background: #f8fafc; border-radius: 6px; font-size: 0.82rem;">
                  <div>
                    <strong style="color: var(--slate-900);">${this.escapeHtml(v.name)}</strong>
                    <div style="font-size: 0.72rem; color: var(--slate-500);">${v.count} contract(s)</div>
                  </div>
                  <strong style="color: #4338ca;">${this.formatCurrency(v.totalAmount)}</strong>
                </div>
              `).join('')}
            </div>
          </div>

          <!-- Top Hirers Card -->
          <div style="background: #ffffff; border-radius: 10px; border: 1px solid var(--slate-200); padding: 1.1rem; box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
            <h4 style="margin: 0 0 0.75rem; font-size: 0.9rem; font-weight: 800; color: var(--slate-800); display: flex; align-items: center; gap: 0.4rem;">
              <i class="fa-solid fa-users" style="color: #ec4899;"></i> Top Rental Clients & Event Planners
            </h4>
            <div style="display: flex; flex-direction: column; gap: 0.5rem;">
              ${rankedCustomers.length === 0 ? `
                <div style="font-size: 0.82rem; color: var(--slate-400); text-align: center; padding: 1rem;">No customer booking data recorded yet.</div>
              ` : rankedCustomers.map((c, i) => `
                <div style="display: flex; justify-content: space-between; align-items: center; padding: 0.5rem 0.7rem; background: #f8fafc; border-radius: 6px; font-size: 0.82rem;">
                  <div>
                    <strong style="color: var(--slate-900);">${this.escapeHtml(c.name)}</strong>
                    <div style="font-size: 0.72rem; color: var(--slate-500);">
                      ${c.count} hire(s) ${c.activeCount > 0 ? `&bull; <span style="color:#0284c7; font-weight:700;">${c.activeCount} active</span>` : ''}
                    </div>
                  </div>
                  <strong style="color: #16a34a;">${this.formatCurrency(c.totalAmount)}</strong>
                </div>
              `).join('')}
            </div>
          </div>
        </div>
      </div>
    `;
  },

  // -------------------------------------------------------------
  // MODAL: NEW RENTAL DISPATCH
  // -------------------------------------------------------------
  openNewRentalModal() {
    let overlay = document.getElementById('modal-new-rental');
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = 'modal-new-rental';
      overlay.className = 'modal-overlay';
      overlay.style.cssText = 'display:none; position:fixed; inset:0; background:rgba(15,23,42,0.6); backdrop-filter:blur(3px); z-index:9999; align-items:center; justify-content:center; padding:1rem;';
      document.body.appendChild(overlay);
    }

    const availableProducts = (this.products || []).filter(p => this.isRentalProduct && this.isRentalProduct(p)).map(p => {
      const eff = typeof this.getEffectiveProductForBranch === 'function' ? this.getEffectiveProductForBranch(p) : p;
      return {
        ...p,
        fleetStock: Number(eff && eff.effectiveStock !== undefined ? eff.effectiveStock : (p.current_quantity || 0))
      };
    });

    const todayStr = new Date().toISOString().split('T')[0];
    const defaultReturnStr = new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0]; // +2 days default

    overlay.innerHTML = `
      <div class="modal-content" style="background:#ffffff; border-radius:12px; max-width:840px; width:100%; max-height:92vh; overflow-y:auto; box-shadow:0 25px 50px -12px rgba(0,0,0,0.25); display:flex; flex-direction:column;">
        <div style="padding:1.1rem 1.4rem; border-bottom:1px solid var(--slate-200); display:flex; justify-content:space-between; align-items:center; background:#faf5ff;">
          <div>
            <h3 style="margin:0; font-size:1.15rem; font-weight:800; color:#581c87; display:flex; align-items:center; gap:0.45rem;">
              <i class="fa-solid fa-truck-ramp-box" style="color:#7c3aed;"></i> New Equipment Rental Dispatch
            </h3>
            <p style="margin:2px 0 0; font-size:0.78rem; color:#7e22ce;">Create customer hire agreement, set caution deposit & allocate stock.</p>
          </div>
          <button type="button" class="btn btn-outline btn-sm" onclick="app.closeNewRentalModal()" style="border:none; color:var(--slate-400); font-size:1.2rem; cursor:pointer;">
            <i class="fa-solid fa-xmark"></i>
          </button>
        </div>

        <form id="new-rental-form" onsubmit="event.preventDefault(); app.saveRentalDispatch();" style="padding:1.25rem 1.4rem; display:flex; flex-direction:column; gap:1.1rem;">
          <!-- Customer Details Section -->
          <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:0.9rem;">
            <h4 style="margin:0 0 0.65rem; font-size:0.85rem; font-weight:700; color:var(--slate-700); text-transform:uppercase;">1. Customer & Venue Details</h4>
            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(200px, 1fr)); gap:0.75rem;">
              <div>
                <label class="form-label" style="font-size:0.75rem; font-weight:700;">Customer Name *</label>
                <input type="text" id="rental-cust-name" class="form-control" required placeholder="e.g. Kwame Mensah / Church Committee" style="font-size:0.85rem;">
              </div>
              <div>
                <label class="form-label" style="font-size:0.75rem; font-weight:700;">Phone Number</label>
                <input type="tel" id="rental-cust-phone" class="form-control" placeholder="e.g. 0244123456" style="font-size:0.85rem;">
              </div>
              <div>
                <label class="form-label" style="font-size:0.75rem; font-weight:700;">Ghana Card / ID #</label>
                <input type="text" id="rental-cust-idcard" class="form-control" placeholder="e.g. GHA-71283912-1" style="font-size:0.85rem;">
              </div>
              <div>
                <label class="form-label" style="font-size:0.75rem; font-weight:700;">Event Venue / Delivery Location</label>
                <input type="text" id="rental-event-venue" class="form-control" placeholder="e.g. East Legon Event Grounds / Home" style="font-size:0.85rem;">
              </div>
            </div>
          </div>

          <!-- Schedule & Duration Section -->
          <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:0.9rem;">
            <h4 style="margin:0 0 0.65rem; font-size:0.85rem; font-weight:700; color:var(--slate-700); text-transform:uppercase;">2. Rental Schedule & Duration</h4>
            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:0.75rem;">
              <div>
                <label class="form-label" style="font-size:0.75rem; font-weight:700;">Pickup / Dispatch Date</label>
                <input type="date" id="rental-pickup-date" class="form-control" value="${todayStr}" onchange="app.recalcRentalDates()" style="font-size:0.85rem;">
              </div>
              <div>
                <label class="form-label" style="font-size:0.75rem; font-weight:700;">Duration (Days)</label>
                <input type="number" id="rental-duration-days" class="form-control" min="1" step="1" value="2" onchange="app.recalcRentalDates()" style="font-size:0.85rem; font-weight:700;">
              </div>
              <div>
                <label class="form-label" style="font-size:0.75rem; font-weight:700;">Return Due Date</label>
                <input type="date" id="rental-return-date" class="form-control" value="${defaultReturnStr}" style="font-size:0.85rem; font-weight:700; color:#b91c1c;">
              </div>
            </div>
          </div>

          <!-- Equipment Items Table -->
          <div>
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.45rem;">
              <h4 style="margin:0; font-size:0.85rem; font-weight:700; color:var(--slate-700); text-transform:uppercase;">3. Equipment to Dispatch</h4>
              <button type="button" class="btn btn-outline btn-sm" onclick="app.addRentalItemRow()" style="padding:0.25rem 0.6rem; font-size:0.75rem; color:#7c3aed; border-color:#c4b5fd;">
                <i class="fa-solid fa-plus"></i> Add Equipment Item
              </button>
            </div>

            ${availableProducts.length === 0 ? `
              <div style="background:#fffbeb; border:1px solid #fcd34d; border-radius:8px; padding:0.75rem 1rem; margin-bottom:0.75rem; font-size:0.8rem; color:#92400e; display:flex; align-items:center; gap:0.6rem;">
                <i class="fa-solid fa-circle-exclamation" style="font-size:1.1rem; color:#d97706; flex-shrink:0;"></i>
                <div>
                  <strong>No equipment registered for rental yet.</strong>
                  <div style="margin-top:2px; font-size:0.74rem;">Retail inventory goods (flour, rice, soap) are excluded from hire dispatch. To register rental fleet (chairs, canopies, sound systems), go to <strong>Products Catalog &rarr; + Add New Product</strong> and check <em>[✓] Rental & Equipment Hire Asset</em> or set Category to <em>Rentals</em>.</div>
                </div>
              </div>
            ` : ''}

            <div style="border:1px solid #e2e8f0; border-radius:8px; overflow-x:auto; -webkit-overflow-scrolling:touch; background:#ffffff; box-shadow:0 1px 3px rgba(0,0,0,0.03);">
              <div style="padding:0.4rem 0.75rem; background:#f8fafc; border-bottom:1px solid #e2e8f0; font-size:0.72rem; color:var(--slate-500); display:flex; justify-content:space-between; align-items:center;">
                <span><i class="fa-solid fa-arrows-left-right" style="color:#7c3aed; margin-right:4px;"></i> Swipe horizontally on mobile to view &amp; edit all fields</span>
                <span style="font-weight:700; color:#7c3aed; font-size:0.70rem; text-transform:uppercase;">Fleet Dispatch</span>
              </div>
              <table style="min-width:680px; width:100%; border-collapse:collapse; font-size:0.82rem;">
                <thead style="background:#f1f5f9; color:#475569; text-transform:uppercase; font-size:0.72rem;">
                  <tr>
                    <th style="padding:0.6rem; text-align:left; min-width:220px;">Equipment Asset</th>
                    <th style="padding:0.6rem; width:80px; min-width:75px; text-align:center;">Qty</th>
                    <th style="padding:0.6rem; width:100px; min-width:95px; text-align:right;">Daily Rate</th>
                    <th style="padding:0.6rem; width:100px; min-width:95px; text-align:right;" title="Agreed repair charge if unit returned damaged">Damage Fee</th>
                    <th style="padding:0.6rem; width:100px; min-width:95px; text-align:right;" title="Agreed replacement charge if unit lost or missing">Loss Fee</th>
                    <th style="padding:0.6rem; width:105px; min-width:95px; text-align:right;">Line Total</th>
                    <th style="padding:0.6rem; width:40px; min-width:35px; text-align:center;"></th>
                  </tr>
                </thead>
                <tbody id="rental-items-table-body">
                  <!-- Row 1 default -->
                  <tr class="rental-item-row" style="border-top:1px solid #e2e8f0;">
                    <td style="padding:0.5rem; min-width:220px;">
                      <select class="form-control rental-item-select" onchange="app.onRentalItemSelect(this)" required style="font-size:0.82rem; min-width:200px; width:100%;">
                        ${availableProducts.length === 0 ? `
                          <option value="">-- No Rental Equipment Registered --</option>
                        ` : `
                          <option value="">-- Choose Equipment --</option>
                          ${availableProducts.map(p => `
                            <option value="${this.escapeHtml(p.id)}" data-price="${p.selling_price || 0}" data-cost="${p.cost_price || 0}" data-stock="${p.product_type === 'service' ? 999999 : (p.fleetStock || 0)}" data-service="${p.product_type === 'service' ? '1' : '0'}">
                              ${this.escapeHtml(p.name)} (${p.product_type === 'service' ? 'Unlimited / Service' : `${p.fleetStock || 0} in warehouse`}) - ${this.formatCurrency(p.selling_price)}/day
                            </option>
                          `).join('')}
                        `}
                      </select>
                    </td>
                    <td style="padding:0.5rem; text-align:center; min-width:75px;">
                      <input type="number" class="form-control rental-item-qty" value="10" min="1" step="1" oninput="app.recalcRentalTotals()" required style="text-align:center; font-weight:700; font-size:0.82rem; width:100%;">
                    </td>
                    <td style="padding:0.5rem; text-align:right; min-width:95px;">
                      <input type="number" class="form-control rental-item-rate" value="5.00" min="0" step="any" oninput="app.recalcRentalTotals()" required style="text-align:right; font-weight:700; font-size:0.82rem; width:100%;">
                    </td>
                    <td style="padding:0.5rem; text-align:right; min-width:95px;">
                      <input type="number" class="form-control rental-item-damage" value="15.00" min="0" step="any" style="text-align:right; font-weight:700; font-size:0.80rem; width:100%;" title="Agreed penalty if damaged">
                    </td>
                    <td style="padding:0.5rem; text-align:right; min-width:95px;">
                      <input type="number" class="form-control rental-item-replace" value="80.00" min="0" step="any" style="text-align:right; font-weight:700; font-size:0.80rem; width:100%;" title="Agreed penalty if lost or missing">
                    </td>
                    <td style="padding:0.5rem; text-align:right; font-weight:700; color:var(--slate-800); min-width:95px;" class="rental-item-subtotal">
                      GH₵100.00
                    </td>
                    <td style="padding:0.5rem; text-align:center; min-width:35px;">
                      <button type="button" class="btn btn-sm" onclick="this.closest('tr').remove(); app.recalcRentalTotals();" style="border:none; color:var(--danger); padding:0.2rem;" title="Remove Item">
                        <i class="fa-solid fa-trash-can"></i>
                      </button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <!-- Financials & Caution Deposit Section -->
          <div style="background:#fdf4ff; border:1px solid #f0abfc; border-radius:8px; padding:0.9rem; display:grid; grid-template-columns:repeat(auto-fit, minmax(190px, 1fr)); gap:1rem; align-items:center;">
            <div>
              <label class="form-label" style="font-size:0.75rem; font-weight:700; color:#86198f;">
                Caution Security Deposit (GH₵) *
              </label>
              <input type="number" id="rental-caution-deposit" class="form-control" value="150.00" min="0" step="any" oninput="app.recalcRentalTotals()" required style="font-weight:700; font-size:0.95rem; border-color:#e879f9; color:#86198f;">
              <span style="font-size:0.7rem; color:#a21caf;">Refundable security held against damage, theft, or late return.</span>
            </div>

            <div>
              <label class="form-label" style="font-size:0.75rem; font-weight:700; color:var(--slate-700);">Daily Late Fee Penalty (GH₵/Day)</label>
              <input type="number" id="rental-late-fee" class="form-control" value="50.00" min="0" step="any" style="font-size:0.85rem; font-weight:700;">
              <span style="font-size:0.7rem; color:var(--slate-500);">Auto-charged per day if customer delays return.</span>
            </div>

            <div>
              <label class="form-label" style="font-size:0.75rem; font-weight:700; color:var(--slate-700);">Payment Terms / Timing</label>
              <select id="rental-payment-status" class="form-control" onchange="app.recalcRentalTotals()" style="font-size:0.85rem; font-weight:700;">
                <option value="PAID">Paid Upfront (Full Payment Now)</option>
                <option value="PENDING">Pay on Return (Postpaid / Settle on Return)</option>
                <option value="DEPOSIT_ONLY">Deposit Only Upfront (Rental Fee on Return)</option>
              </select>
              <span style="font-size:0.7rem; color:var(--slate-500);">Choose when the customer will pay.</span>
            </div>

            <div>
              <label class="form-label" style="font-size:0.75rem; font-weight:700;">Payment Method</label>
              <select id="rental-payment-method" class="form-control" style="font-size:0.85rem; font-weight:700;">
                <option value="CASH">Cash</option>
                <option value="MOMO">Mobile Money (MoMo)</option>
                <option value="CARD">Bank Card</option>
                <option value="BANK_TRANSFER">Bank Transfer</option>
              </select>
              <span style="font-size:0.7rem; color:var(--slate-500);">Mode of settlement.</span>
            </div>
          </div>

          <!-- Totals Summary Box -->
          <div style="background:#ffffff; border:2px dashed #c084fc; border-radius:8px; padding:0.85rem 1.1rem; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:0.75rem;">
            <div>
              <span style="font-size:0.8rem; color:var(--slate-500);">Rental Fee Subtotal:</span>
              <strong id="rental-summary-subtotal" style="font-size:0.95rem; color:var(--slate-800); margin-left:4px;">GH₵100.00</strong>
              <span style="font-size:0.8rem; color:var(--slate-400); margin:0 8px;">+</span>
              <span style="font-size:0.8rem; color:#86198f;">Caution Deposit:</span>
              <strong id="rental-summary-deposit" style="font-size:0.95rem; color:#86198f; margin-left:4px;">GH₵150.00</strong>
              <div id="rental-summary-due-on-return" style="display:none; font-size:0.82rem; color:#b91c1c; font-weight:700; margin-top:3px;">
                <i class="fa-solid fa-clock"></i> Balance Due at Return: <span id="rental-summary-return-balance">GH₵0.00</span>
              </div>
            </div>
            <div style="display:flex; align-items:center; gap:0.6rem;">
              <span id="rental-summary-due-label" style="font-size:0.88rem; font-weight:700; color:var(--slate-700);">Total Due Now:</span>
              <span id="rental-summary-grandtotal" style="font-size:1.35rem; font-weight:800; color:#7c3aed;">GH₵250.00</span>
            </div>
          </div>

          <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:0.5rem; margin-top:0.5rem;">
            <button type="button" class="btn btn-outline" onclick="app.closeNewRentalModal()">Cancel</button>
            <div style="display:flex; gap:0.5rem; align-items:center; flex-wrap:wrap;">
              <button type="button" class="btn btn-outline" onclick="app.saveRentalDispatch(true)" style="color:#0284c7; border-color:#7dd3fc; background:#f0f9ff; font-weight:700; padding:0.65rem 1.2rem;">
                <i class="fa-solid fa-file-invoice"></i> Save as Quotation / Booking
              </button>
              <button type="button" class="btn btn-primary" onclick="app.saveRentalDispatch(false)" style="background:#7c3aed; border-color:#6d28d9; font-weight:800; padding:0.65rem 1.3rem;">
                <i class="fa-solid fa-truck-ramp-box"></i> Confirm Dispatch & Allocate Now
              </button>
            </div>
          </div>
        </form>
      </div>
    `;

    overlay.classList.add('active');
    overlay.style.display = 'flex';
    this.recalcRentalTotals();
  },

  closeNewRentalModal() {
    const overlay = document.getElementById('modal-new-rental');
    if (overlay) {
      overlay.classList.remove('active');
      overlay.style.display = 'none';
    }
  },

  recalcRentalDates() {
    const pickupInput = document.getElementById('rental-pickup-date');
    const durationInput = document.getElementById('rental-duration-days');
    const returnInput = document.getElementById('rental-return-date');
    if (pickupInput && durationInput && returnInput) {
      const days = Math.max(1, parseInt(durationInput.value || 1, 10));
      const pickupDate = new Date(pickupInput.value || new Date());
      const returnDate = new Date(pickupDate.getTime() + days * 86400000);
      returnInput.value = returnDate.toISOString().split('T')[0];
    }
    this.recalcRentalTotals();
  },

  addRentalItemRow() {
    const tbody = document.getElementById('rental-items-table-body');
    if (!tbody) return;

    const availableProducts = (this.products || []).filter(p => this.isRentalProduct && this.isRentalProduct(p)).map(p => {
      const eff = typeof this.getEffectiveProductForBranch === 'function' ? this.getEffectiveProductForBranch(p) : p;
      return {
        ...p,
        fleetStock: Number(eff && eff.effectiveStock !== undefined ? eff.effectiveStock : (p.current_quantity || 0))
      };
    });

    const tr = document.createElement('tr');
    tr.className = 'rental-item-row';
    tr.style.cssText = 'border-top:1px solid #e2e8f0;';
    tr.innerHTML = `
      <td style="padding:0.5rem; min-width:220px;">
        <select class="form-control rental-item-select" onchange="app.onRentalItemSelect(this)" required style="font-size:0.82rem; min-width:200px; width:100%;">
          ${availableProducts.length === 0 ? `
            <option value="">-- No Rental Equipment Registered --</option>
          ` : `
            <option value="">-- Choose Equipment --</option>
            ${availableProducts.map(p => `
              <option value="${this.escapeHtml(p.id)}" data-price="${p.selling_price || 0}" data-cost="${p.cost_price || 0}" data-stock="${p.product_type === 'service' ? 999999 : (p.fleetStock || 0)}" data-service="${p.product_type === 'service' ? '1' : '0'}">
                ${this.escapeHtml(p.name)} (${p.product_type === 'service' ? 'Unlimited / Service' : `${p.fleetStock || 0} in warehouse`}) - ${this.formatCurrency(p.selling_price)}/day
              </option>
            `).join('')}
          `}
        </select>
      </td>
      <td style="padding:0.5rem; text-align:center; min-width:75px;">
        <input type="number" class="form-control rental-item-qty" value="10" min="1" step="1" oninput="app.recalcRentalTotals()" required style="text-align:center; font-weight:700; font-size:0.82rem; width:100%;">
      </td>
      <td style="padding:0.5rem; text-align:right; min-width:95px;">
        <input type="number" class="form-control rental-item-rate" value="5.00" min="0" step="any" oninput="app.recalcRentalTotals()" required style="text-align:right; font-weight:700; font-size:0.82rem; width:100%;">
      </td>
      <td style="padding:0.5rem; text-align:right; min-width:95px;">
        <input type="number" class="form-control rental-item-damage" value="15.00" min="0" step="any" style="text-align:right; font-weight:700; font-size:0.80rem; width:100%;" title="Agreed penalty if damaged">
      </td>
      <td style="padding:0.5rem; text-align:right; min-width:95px;">
        <input type="number" class="form-control rental-item-replace" value="80.00" min="0" step="any" style="text-align:right; font-weight:700; font-size:0.80rem; width:100%;" title="Agreed penalty if lost or missing">
      </td>
      <td style="padding:0.5rem; text-align:right; font-weight:700; color:var(--slate-800); min-width:95px;" class="rental-item-subtotal">
        GH₵0.00
      </td>
      <td style="padding:0.5rem; text-align:center; min-width:35px;">
        <button type="button" class="btn btn-sm" onclick="this.closest('tr').remove(); app.recalcRentalTotals();" style="border:none; color:var(--danger); padding:0.2rem;" title="Remove Item">
          <i class="fa-solid fa-trash-can"></i>
        </button>
      </td>
    `;
    tbody.appendChild(tr);
    this.recalcRentalTotals();
  },

  onRentalItemSelect(selectEl) {
    const opt = selectEl.selectedOptions[0];
    if (opt && opt.dataset.price) {
      const row = selectEl.closest('tr');
      const rateInput = row.querySelector('.rental-item-rate');
      const dmgInput = row.querySelector('.rental-item-damage');
      const replInput = row.querySelector('.rental-item-replace');
      const dailyPrice = parseFloat(opt.dataset.price) || 0;
      if (rateInput && (!rateInput.value || parseFloat(rateInput.value) <= 0)) {
        rateInput.value = dailyPrice.toFixed(2);
      }
      if (dmgInput && (!dmgInput.value || parseFloat(dmgInput.value) <= 0)) {
        dmgInput.value = (dailyPrice * 2.0).toFixed(2);
      }
      if (replInput && (!replInput.value || parseFloat(replInput.value) <= 0)) {
        replInput.value = (dailyPrice * 8.0).toFixed(2);
      }
    }
    this.recalcRentalTotals();
  },

  recalcRentalTotals() {
    const durationInput = document.getElementById('rental-duration-days');
    const days = Math.max(1, parseInt((durationInput && durationInput.value) || 1, 10));

    let subtotal = 0.0;
    const rows = document.querySelectorAll('.rental-item-row');
    rows.forEach(r => {
      const qty = parseFloat(r.querySelector('.rental-item-qty')?.value || 0);
      const rate = parseFloat(r.querySelector('.rental-item-rate')?.value || 0);
      const line = qty * rate * days;
      subtotal += line;
      const subtotalEl = r.querySelector('.rental-item-subtotal');
      if (subtotalEl) subtotalEl.innerText = this.formatCurrency(line);
    });

    const depositInput = document.getElementById('rental-caution-deposit');
    const deposit = Math.max(0, parseFloat((depositInput && depositInput.value) || 0));

    const pStatus = document.getElementById('rental-payment-status')?.value || 'PAID';
    let dueNow = 0.0;
    let dueReturn = 0.0;

    if (pStatus === 'PAID') {
      dueNow = subtotal + deposit;
      dueReturn = 0.0;
    } else if (pStatus === 'PENDING') {
      dueNow = 0.0;
      dueReturn = subtotal + deposit;
    } else if (pStatus === 'DEPOSIT_ONLY') {
      dueNow = deposit;
      dueReturn = subtotal;
    }

    const subtotalEl = document.getElementById('rental-summary-subtotal');
    if (subtotalEl) subtotalEl.innerText = this.formatCurrency(subtotal);

    const depositEl = document.getElementById('rental-summary-deposit');
    if (depositEl) depositEl.innerText = this.formatCurrency(deposit);

    const grandTotalEl = document.getElementById('rental-summary-grandtotal');
    if (grandTotalEl) grandTotalEl.innerText = this.formatCurrency(dueNow);

    const dueLabel = document.getElementById('rental-summary-due-label');
    if (dueLabel) {
      dueLabel.innerText = (pStatus === 'PENDING') ? 'Total Due Now (Postpaid):' : 'Total Due Now:';
    }

    const returnBalRow = document.getElementById('rental-summary-due-on-return');
    const returnBalEl = document.getElementById('rental-summary-return-balance');
    if (returnBalRow && returnBalEl) {
      if (dueReturn > 0) {
        returnBalRow.style.display = 'block';
        returnBalEl.innerText = this.formatCurrency(dueReturn);
      } else {
        returnBalRow.style.display = 'none';
      }
    }
  },

  async saveRentalDispatch(isBooking = false) {
    const custName = document.getElementById('rental-cust-name')?.value.trim();
    if (!custName) {
      this.showToast('Please provide a customer name.', 'warning');
      return;
    }

    const durationDays = parseInt(document.getElementById('rental-duration-days')?.value || 1, 10);
    const pickupDate = document.getElementById('rental-pickup-date')?.value;
    const returnDate = document.getElementById('rental-return-date')?.value;
    const cautionDeposit = parseFloat(document.getElementById('rental-caution-deposit')?.value || 0);
    const lateFeePerDay = parseFloat(document.getElementById('rental-late-fee')?.value || 0);
    const paymentMethod = document.getElementById('rental-payment-method')?.value || 'CASH';

    const items = [];
    const rows = document.querySelectorAll('.rental-item-row');
    for (const r of rows) {
      const prodId = r.querySelector('.rental-item-select')?.value;
      const qty = parseFloat(r.querySelector('.rental-item-qty')?.value || 0);
      const rate = parseFloat(r.querySelector('.rental-item-rate')?.value || 0);
      const dmg = parseFloat(r.querySelector('.rental-item-damage')?.value || 0) || (rate * 2.0);
      const repl = parseFloat(r.querySelector('.rental-item-replace')?.value || 0) || (rate * 8.0);
      if (prodId && qty > 0) {
        items.push({
          product_id: prodId,
          quantity: qty,
          daily_rate: rate,
          damage_charge_unit: dmg,
          replacement_charge_unit: repl
        });
      }
    }

    if (items.length === 0) {
      this.showToast(isBooking ? 'Please select at least one equipment item for the quote.' : 'Please select at least one equipment item to dispatch.', 'warning');
      return;
    }

    const paymentStatus = document.getElementById('rental-payment-status')?.value || 'PAID';

    const payload = {
      action: isBooking ? 'book' : 'dispatch',
      status: isBooking ? 'BOOKED' : 'DISPATCHED',
      customer_name: custName,
      customer_phone: document.getElementById('rental-cust-phone')?.value.trim(),
      customer_id_card: document.getElementById('rental-cust-idcard')?.value.trim(),
      event_location: document.getElementById('rental-event-venue')?.value.trim(),
      branch_code: this.branchCode || 'MAIN-01',
      terminal_id: this.terminalId || 'REG-01',
      pickup_date: pickupDate,
      return_due_date: returnDate,
      duration_days: durationDays,
      caution_deposit: cautionDeposit,
      late_fee_per_day: lateFeePerDay,
      payment_method: paymentMethod,
      payment_status: paymentStatus,
      items: items
    };

    try {
      const res = await fetch('api/endpoints/rentals.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const text = await res.text();
      let data;
      try {
        data = JSON.parse(text);
      } catch (parseErr) {
        console.error('Non-JSON response from rentals endpoint:', text);
        this.showToast('Server response error: ' + (text.substring(0, 100) || 'Empty response from server'), 'danger');
        return;
      }
      if (data.success) {
        this.showToast(data.message || (isBooking ? 'Rental quotation saved!' : 'Rental dispatch confirmed!'), 'success');
        this.closeNewRentalModal();
        await this.fetchRentals();
        if (typeof this.fetchProducts === 'function') await this.fetchProducts();
        this.renderCurrentView();

        // Print gate pass or quotation proforma
        if (data.rental_id) {
          this.printRentalGatePass(data.rental_id);
        }
      } else {
        this.showToast(data.error || (isBooking ? 'Failed to save quotation.' : 'Failed to dispatch rental.'), 'danger');
      }
    } catch (err) {
      this.showToast('Error creating rental: ' + err.message, 'danger');
    }
  },

  async dispatchRentalBooking(rentalId) {
    if (!rentalId) return;
    const r = (this.rentals || []).find(it => it.id === rentalId);
    const rNum = r ? r.rental_number : rentalId;
    const custName = r ? r.customer_name : 'Customer';

    const confirmed = typeof this.showConfirmModal === 'function'
      ? await this.showConfirmModal({
          title: 'Dispatch Booked Equipment?',
          message: `Are you ready to dispatch equipment for ${custName} (${rNum})? This will allocate and deduct items from warehouse inventory.`,
          confirmText: 'Dispatch & Allocate Gear',
          confirmClass: 'btn-primary'
        })
      : confirm(`Dispatch booked equipment for ${custName} (${rNum}) now? This will allocate and deduct warehouse inventory.`);

    if (!confirmed) return;

    try {
      const res = await fetch('api/endpoints/rentals.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'dispatch_booking', rental_id: rentalId })
      });
      const data = await res.json();
      if (data.success) {
        this.showToast(data.message || `Rental ${rNum} dispatched!`, 'success');
        await this.fetchRentals();
        if (typeof this.fetchProducts === 'function') await this.fetchProducts();
        this.renderCurrentView();
        this.printRentalGatePass(rentalId);
      } else {
        this.showToast(data.error || 'Failed to dispatch booking.', 'danger');
      }
    } catch (err) {
      this.showToast('Dispatch error: ' + err.message, 'danger');
    }
  },

  // -------------------------------------------------------------
  // MODAL: CHECK-IN / RETURN INSPECTION & SETTLEMENT
  // -------------------------------------------------------------
  async openRentalReturnModal(rentalId) {
    try {
      const res = await fetch(`api/endpoints/rentals.php?id=${encodeURIComponent(rentalId)}`);
      const data = await res.json();
      if (!data.success || !data.rental) {
        this.showToast(data.error || 'Rental not found.', 'danger');
        return;
      }

      const r = data.rental;
      this.activeReturnRental = r;

      let overlay = document.getElementById('modal-rental-return');
      if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'modal-rental-return';
        overlay.className = 'modal-overlay';
        overlay.style.cssText = 'display:none; position:fixed; inset:0; background:rgba(15,23,42,0.6); backdrop-filter:blur(3px); z-index:9999; align-items:center; justify-content:center; padding:1rem;';
        document.body.appendChild(overlay);
      }

      const todayStr = new Date().toISOString().split('T')[0];
      const isOverdue = !!r.is_overdue || (todayStr > r.return_due_date);
      const daysOverdue = isOverdue ? Math.max(1, Math.ceil((new Date(todayStr) - new Date(r.return_due_date)) / 86400000)) : 0;
      const autoLateFee = daysOverdue * parseFloat(r.late_fee_per_day || 0);

      const isPostpaid = (r.payment_status === 'PENDING');
      const isDepositOnly = (r.payment_status === 'DEPOSIT_ONLY');
      const unpaidRental = (isPostpaid || isDepositOnly) ? parseFloat(r.total_rental_amount || 0) : 0;
      const cautionHeld = (r.caution_deposit_status === 'HELD') ? parseFloat(r.caution_deposit || 0) : 0;

      overlay.innerHTML = `
        <div class="modal-content" style="background:#ffffff; border-radius:12px; max-width:820px; width:100%; max-height:92vh; overflow-y:auto; box-shadow:0 25px 50px -12px rgba(0,0,0,0.25); display:flex; flex-direction:column;">
          <div style="padding:1.1rem 1.4rem; border-bottom:1px solid var(--slate-200); display:flex; justify-content:space-between; align-items:center; background:#f0fdf4;">
            <div>
              <h3 style="margin:0; font-size:1.15rem; font-weight:800; color:#14532d; display:flex; align-items:center; gap:0.45rem;">
                <i class="fa-solid fa-clipboard-check" style="color:#16a34a;"></i> Return Inspection & Caution Settlement
              </h3>
              <p style="margin:2px 0 0; font-size:0.78rem; color:#15803d;">
                Rental: <strong>${this.escapeHtml(r.rental_number)}</strong> &bull; Customer: <strong>${this.escapeHtml(r.customer_name)}</strong>
                &bull; Terms: <span class="badge" style="background:#e0e7ff; color:#4338ca; font-weight:700;">${isPostpaid ? 'Pay on Return (Postpaid)' : (isDepositOnly ? 'Deposit Held / Balance Due' : 'Paid Upfront')}</span>
              </p>
            </div>
            <button type="button" class="btn btn-outline btn-sm" onclick="app.closeRentalReturnModal()" style="border:none; color:var(--slate-400); font-size:1.2rem; cursor:pointer;">
              <i class="fa-solid fa-xmark"></i>
            </button>
          </div>

          <form id="rental-return-form" onsubmit="event.preventDefault(); app.submitRentalReturn();" style="padding:1.25rem 1.4rem; display:flex; flex-direction:column; gap:1.1rem;">
            <!-- Return Date & Late Days Auto-Calculator -->
            <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:0.85rem 1rem;">
              <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:0.85rem; align-items:flex-end;">
                <div>
                  <label class="form-label" style="font-size:0.75rem; font-weight:700; margin-bottom:0.25rem;">Actual Return Date</label>
                  <input type="date" id="return-actual-date" class="form-control" value="${todayStr}" onchange="app.onReturnDateChanged()" style="font-size:0.85rem; font-weight:700;">
                  <span style="font-size:0.70rem; color:var(--slate-500);">Agreed Due Date: <strong>${this.escapeHtml(r.return_due_date)}</strong></span>
                </div>
                <div>
                  <label class="form-label" style="font-size:0.75rem; font-weight:700; margin-bottom:0.25rem;">Days Overdue / Late</label>
                  <div style="display:flex; align-items:center; gap:0.4rem;">
                    <input type="number" id="return-days-overdue" class="form-control" value="${daysOverdue}" min="0" step="1" oninput="app.onReturnDaysOverdueChanged()" style="font-size:0.85rem; font-weight:700; color:${daysOverdue > 0 ? '#b91c1c' : '#166534'};">
                    <span style="font-size:0.78rem; font-weight:700; color:var(--slate-600); white-space:nowrap;">Day(s)</span>
                  </div>
                  <span style="font-size:0.70rem; color:var(--slate-500);">Agreed Rate: <strong>${this.formatCurrency(r.late_fee_per_day)}/day</strong></span>
                </div>
                <div>
                  <label class="form-label" style="font-size:0.75rem; font-weight:700; margin-bottom:0.25rem; color:#b91c1c;">Late Return Penalty (GH₵)</label>
                  <input type="number" id="return-late-fee" class="form-control" value="${autoLateFee.toFixed(2)}" min="0" step="any" oninput="app.recalcReturnSettlement()" style="text-align:right; font-weight:800; font-size:0.95rem; color:#b91c1c;">
                  <span style="font-size:0.70rem; color:var(--slate-500);">(Auto-calculated: Days &times; Rate. Editable)</span>
                </div>
              </div>
            </div>

            <!-- Equipment Return Count Table -->
            <div>
              <h4 style="margin:0 0 0.45rem; font-size:0.85rem; font-weight:700; color:var(--slate-700); text-transform:uppercase;">
                Check-in Equipment Count
              </h4>
              <div style="border:1px solid #e2e8f0; border-radius:8px; overflow:hidden;">
                <table style="width:100%; border-collapse:collapse; font-size:0.82rem;">
                  <thead style="background:#f8fafc; color:#475569; text-transform:uppercase; font-size:0.72rem;">
                    <tr>
                      <th style="padding:0.6rem; text-align:left;">Equipment Item</th>
                      <th style="padding:0.6rem; text-align:center; width:65px;">Dispatched</th>
                      <th style="padding:0.6rem; text-align:center; width:95px; color:#15803d;">Good Condition</th>
                      <th style="padding:0.6rem; text-align:center; width:95px; color:#b45309;">Damaged</th>
                      <th style="padding:0.6rem; text-align:center; width:95px; color:#b91c1c;">Missing / Lost</th>
                      <th style="padding:0.6rem; text-align:center; width:100px;">Audit Check</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${(r.items || []).map((it, idx) => `
                      <tr class="return-checkin-row" data-item-id="${this.escapeHtml(it.id)}" data-dispatched="${it.quantity_dispatched}" style="border-top:1px solid #e2e8f0;">
                        <td style="padding:0.6rem;">
                          <strong>${this.escapeHtml(it.product_name)}</strong>
                          <div style="font-size:0.72rem; color:var(--slate-500); display:flex; gap:0.4rem; align-items:center; flex-wrap:wrap; margin-top:2px;">
                            <span>Agreed Damage: GH₵<input type="number" class="return-dmg-rate-input" value="${parseFloat(it.damage_charge_unit || 15).toFixed(2)}" style="width:60px; padding:1px 3px; font-size:0.72rem; text-align:right;" oninput="app.recalcReturnSettlement()"></span>
                            <span>&bull;</span>
                            <span>Agreed Lost: GH₵<input type="number" class="return-replace-rate-input" value="${parseFloat(it.replacement_charge_unit || 80).toFixed(2)}" style="width:60px; padding:1px 3px; font-size:0.72rem; text-align:right;" oninput="app.recalcReturnSettlement()"></span>
                          </div>
                        </td>
                        <td style="padding:0.6rem; text-align:center; font-weight:700; color:var(--slate-700);">
                          ${it.quantity_dispatched}
                        </td>
                        <td style="padding:0.6rem; text-align:center;">
                          <input type="number" class="form-control return-good-qty" value="${it.quantity_dispatched}" min="0" max="${it.quantity_dispatched}" step="1" oninput="app.onReturnItemQtyChanged(this, 'good')" required style="text-align:center; font-weight:700; font-size:0.85rem; color:#15803d; border-color:#86efac;">
                        </td>
                        <td style="padding:0.6rem; text-align:center;">
                          <input type="number" class="form-control return-damage-qty" value="0" min="0" max="${it.quantity_dispatched}" step="1" oninput="app.onReturnItemQtyChanged(this, 'damage')" style="text-align:center; font-weight:700; font-size:0.85rem; color:#b45309; border-color:#fde047;">
                        </td>
                        <td style="padding:0.6rem; text-align:center;">
                          <input type="number" class="form-control return-missing-qty" value="0" min="0" max="${it.quantity_dispatched}" step="1" oninput="app.onReturnItemQtyChanged(this, 'missing')" style="text-align:center; font-weight:700; font-size:0.85rem; color:#b91c1c; border-color:#fca5a5;">
                        </td>
                        <td style="padding:0.6rem; text-align:center;" class="return-row-audit">
                          <span class="badge" style="background:#dcfce7; color:#15803d; font-weight:700;"><i class="fa-solid fa-check"></i> 100% OK</span>
                        </td>
                      </tr>
                    `).join('')}
                  </tbody>
                </table>
              </div>
            </div>

            <!-- Caution Deposit Settlement Calculation Box -->
            <div style="background:#ffffff; border:2px solid #86efac; border-radius:10px; padding:1.1rem; box-shadow:0 4px 6px -1px rgba(0,0,0,0.05);">
              <h4 style="margin:0 0 0.65rem; font-size:0.85rem; font-weight:700; color:#14532d; text-transform:uppercase; display:flex; justify-content:space-between; flex-wrap:wrap; gap:0.5rem;">
                <span>Settlement Breakdown</span>
                <span id="settle-deposit-badge" style="color:#86198f;">Caution Deposit Held: ${this.formatCurrency(cautionHeld)}</span>
              </h4>

              <div style="display:flex; flex-direction:column; gap:0.35rem; font-size:0.82rem; border-bottom:1px dashed #cbd5e1; padding-bottom:0.65rem; margin-bottom:0.65rem;">
                ${unpaidRental > 0 ? `
                  <div style="display:flex; justify-content:space-between; color:#4338ca; font-weight:700;">
                    <span>Unpaid Rental Contract Fee:</span>
                    <span>${this.formatCurrency(unpaidRental)}</span>
                  </div>
                ` : ''}
                <div style="display:flex; justify-content:space-between; color:#b45309;">
                  <span>Damage Deductions:</span>
                  <strong id="settle-damage-fee">GH₵0.00</strong>
                </div>
                <div style="display:flex; justify-content:space-between; color:#b91c1c;">
                  <span>Missing Replacement Charges:</span>
                  <strong id="settle-missing-fee">GH₵0.00</strong>
                </div>
                <div style="display:flex; justify-content:space-between; color:#b91c1c;">
                  <span>Late Return Penalty:</span>
                  <strong id="settle-late-fee">${this.formatCurrency(autoLateFee)}</strong>
                </div>
                <div style="display:flex; justify-content:space-between; font-weight:700; color:var(--slate-800); border-top:1px dotted #e2e8f0; padding-top:0.25rem;">
                  <span>Total Charges & Obligations:</span>
                  <span id="settle-total-penalties">${this.formatCurrency(unpaidRental + autoLateFee)}</span>
                </div>
                ${cautionHeld > 0 ? `
                  <div style="display:flex; justify-content:space-between; color:#86198f;">
                    <span>Less Caution Deposit Held:</span>
                    <span>-${this.formatCurrency(cautionHeld)}</span>
                  </div>
                ` : ''}
              </div>

              <!-- Net Outcome -->
              <div id="settle-outcome-box" style="display:flex; justify-content:space-between; align-items:center; padding:0.65rem 0.85rem; border-radius:6px; background:#dcfce7;">
                <div>
                  <strong id="settle-outcome-title" style="font-size:0.95rem; color:#15803d;">Refund Caution Deposit to Customer:</strong>
                  <div id="settle-outcome-desc" style="font-size:0.75rem; color:#166534;">Payable back to customer in cash / MoMo</div>
                </div>
                <span id="settle-outcome-amount" style="font-size:1.4rem; font-weight:800; color:#15803d;">
                  ${this.formatCurrency(Math.max(0, cautionHeld - (unpaidRental + autoLateFee)))}
                </span>
              </div>
            </div>

            <div style="display:flex; justify-content:flex-end; gap:0.5rem; margin-top:0.5rem;">
              <button type="button" class="btn btn-outline" onclick="app.closeRentalReturnModal()">Cancel</button>
              <button type="submit" class="btn btn-success" style="font-weight:800; padding:0.65rem 1.3rem;">
                <i class="fa-solid fa-check-double"></i> Complete Check-In & Settle
              </button>
            </div>
          </form>
        </div>
      `;

      overlay.classList.add('active');
      overlay.style.display = 'flex';
      this.recalcReturnSettlement();
    } catch (err) {
      this.showToast('Error opening return modal: ' + err.message, 'danger');
    }
  },

  onReturnItemQtyChanged(inputEl, fieldType) {
    const row = inputEl.closest('.return-checkin-row');
    if (!row) return;

    const dispatched = parseFloat(row.dataset.dispatched || 0);
    const goodInput = row.querySelector('.return-good-qty');
    const dmgInput = row.querySelector('.return-damage-qty');
    const missInput = row.querySelector('.return-missing-qty');
    const auditEl = row.querySelector('.return-row-audit');

    let good = Math.max(0, parseFloat(goodInput?.value || 0));
    let damaged = Math.max(0, parseFloat(dmgInput?.value || 0));
    let missing = Math.max(0, parseFloat(missInput?.value || 0));

    if (fieldType === 'damage' || fieldType === 'missing') {
      // Clamping: Damaged + Missing cannot exceed total dispatched
      if (damaged + missing > dispatched) {
        if (fieldType === 'damage') {
          damaged = Math.max(0, dispatched - missing);
          if (dmgInput) dmgInput.value = damaged;
        } else {
          missing = Math.max(0, dispatched - damaged);
          if (missInput) missInput.value = missing;
        }
      }
      // Auto-compute Good Condition: Good = Dispatched - (Damaged + Missing)
      good = Math.max(0, dispatched - (damaged + missing));
      if (goodInput) goodInput.value = good;
    } else if (fieldType === 'good') {
      if (good > dispatched) {
        good = dispatched;
        if (goodInput) goodInput.value = good;
      }
      if (good + damaged + missing > dispatched) {
        const remainder = dispatched - good;
        if (damaged > remainder) {
          damaged = remainder;
          missing = 0;
        } else {
          missing = remainder - damaged;
        }
        if (dmgInput) dmgInput.value = damaged;
        if (missInput) missInput.value = missing;
      }
    }

    if (auditEl) {
      const sum = good + damaged + missing;
      if (sum === dispatched) {
        if (damaged === 0 && missing === 0) {
          auditEl.innerHTML = '<span class="badge" style="background:#dcfce7; color:#15803d; font-weight:700;"><i class="fa-solid fa-check"></i> 100% OK</span>';
        } else {
          auditEl.innerHTML = `<span class="badge" style="background:#fef3c7; color:#b45309; font-weight:700;">✓ ${sum}/${dispatched} Resolved</span>`;
        }
      } else {
        auditEl.innerHTML = `<span class="badge" style="background:#fee2e2; color:#b91c1c; font-weight:700;">⚠️ ${sum}/${dispatched}</span>`;
      }
    }

    this.recalcReturnSettlement();
  },

  onReturnDateChanged() {
    if (!this.activeReturnRental) return;
    const r = this.activeReturnRental;
    const actual = document.getElementById('return-actual-date')?.value || new Date().toISOString().split('T')[0];
    const due = r.return_due_date;
    const days = (actual > due) ? Math.max(0, Math.ceil((new Date(actual) - new Date(due)) / 86400000)) : 0;
    const daysInput = document.getElementById('return-days-overdue');
    if (daysInput) {
      daysInput.value = days;
      daysInput.style.color = (days > 0) ? '#b91c1c' : '#166534';
    }
    const rate = parseFloat(r.late_fee_per_day || 0);
    const feeInput = document.getElementById('return-late-fee');
    if (feeInput) feeInput.value = (days * rate).toFixed(2);
    this.recalcReturnSettlement();
  },

  onReturnDaysOverdueChanged() {
    if (!this.activeReturnRental) return;
    const r = this.activeReturnRental;
    const days = Math.max(0, parseInt(document.getElementById('return-days-overdue')?.value || 0, 10));
    const rate = parseFloat(r.late_fee_per_day || 0);
    const feeInput = document.getElementById('return-late-fee');
    if (feeInput) feeInput.value = (days * rate).toFixed(2);
    this.recalcReturnSettlement();
  },

  closeRentalReturnModal() {
    const overlay = document.getElementById('modal-rental-return');
    if (overlay) {
      overlay.classList.remove('active');
      overlay.style.display = 'none';
    }
  },

  recalcReturnSettlement() {
    if (!this.activeReturnRental) return;
    const r = this.activeReturnRental;
    const isPostpaid = (r.payment_status === 'PENDING');
    const isDepositOnly = (r.payment_status === 'DEPOSIT_ONLY');
    const unpaidRental = (isPostpaid || isDepositOnly) ? parseFloat(r.total_rental_amount || 0) : 0;
    const cautionHeld = (r.caution_deposit_status === 'HELD') ? parseFloat(r.caution_deposit || 0) : 0;

    let totalDamage = 0.0;
    let totalMissing = 0.0;

    const rows = document.querySelectorAll('.return-checkin-row');
    rows.forEach(row => {
      const dmgRateInput = row.querySelector('.return-dmg-rate-input');
      const replaceRateInput = row.querySelector('.return-replace-rate-input');
      const damageRate = dmgRateInput ? Math.max(0, parseFloat(dmgRateInput.value || 0)) : parseFloat(row.dataset.damageRate || 15);
      const replaceRate = replaceRateInput ? Math.max(0, parseFloat(replaceRateInput.value || 0)) : parseFloat(row.dataset.replaceRate || 80);

      const damaged = Math.max(0, parseFloat(row.querySelector('.return-damage-qty')?.value || 0));
      const missing = Math.max(0, parseFloat(row.querySelector('.return-missing-qty')?.value || 0));

      totalDamage += (damaged * damageRate);
      totalMissing += (missing * replaceRate);
    });

    const lateFeeInput = document.getElementById('return-late-fee');
    const lateFee = Math.max(0, parseFloat((lateFeeInput && lateFeeInput.value) || 0));

    const totalPenalties = totalDamage + totalMissing + lateFee;
    const totalObligations = unpaidRental + totalPenalties;

    const dmgEl = document.getElementById('settle-damage-fee');
    if (dmgEl) dmgEl.innerText = this.formatCurrency(totalDamage);

    const misEl = document.getElementById('settle-missing-fee');
    if (misEl) misEl.innerText = this.formatCurrency(totalMissing);

    const lateEl = document.getElementById('settle-late-fee');
    if (lateEl) lateEl.innerText = this.formatCurrency(lateFee);

    const penEl = document.getElementById('settle-total-penalties');
    if (penEl) penEl.innerText = this.formatCurrency(totalObligations);

    const outcomeBox = document.getElementById('settle-outcome-box');
    const outcomeTitle = document.getElementById('settle-outcome-title');
    const outcomeDesc = document.getElementById('settle-outcome-desc');
    const outcomeAmount = document.getElementById('settle-outcome-amount');

    if (outcomeBox && outcomeTitle && outcomeDesc && outcomeAmount) {
      if (cautionHeld >= totalObligations) {
        const refund = cautionHeld - totalObligations;
        outcomeBox.style.background = '#dcfce7';
        outcomeTitle.style.color = '#15803d';
        outcomeTitle.innerText = 'Refund Caution Deposit to Customer:';
        outcomeDesc.innerText = 'Payable back to customer in cash / MoMo';
        outcomeAmount.style.color = '#15803d';
        outcomeAmount.innerText = this.formatCurrency(refund);
      } else {
        const owed = totalObligations - cautionHeld;
        outcomeBox.style.background = '#fee2e2';
        outcomeTitle.style.color = '#b91c1c';
        if (unpaidRental > 0) {
          outcomeTitle.innerText = 'Collect Balance Due from Customer:';
          outcomeDesc.innerText = 'Includes unpaid hire contract fee and damages/penalties minus caution deposit.';
        } else {
          outcomeTitle.innerText = 'Caution Forfeited & Customer Owes Balance:';
          outcomeDesc.innerText = 'Penalties exceed deposit. Collect additional cash from customer.';
        }
        outcomeAmount.style.color = '#b91c1c';
        outcomeAmount.innerText = this.formatCurrency(owed);
      }
    }
  },

  async submitRentalReturn() {
    if (!this.activeReturnRental) return;
    const r = this.activeReturnRental;

    const returnedItems = [];
    const rows = document.querySelectorAll('.return-checkin-row');
    rows.forEach(row => {
      const itemId = row.dataset.itemId;
      const good = parseFloat(row.querySelector('.return-good-qty')?.value || 0);
      const damaged = parseFloat(row.querySelector('.return-damage-qty')?.value || 0);
      const missing = parseFloat(row.querySelector('.return-missing-qty')?.value || 0);
      const dmgRate = parseFloat(row.querySelector('.return-dmg-rate-input')?.value || 0);
      const replaceRate = parseFloat(row.querySelector('.return-replace-rate-input')?.value || 0);
      returnedItems.push({
        item_id: itemId,
        quantity_returned_good: good,
        quantity_damaged: damaged,
        quantity_missing: missing,
        damage_charge_unit: dmgRate,
        replacement_charge_unit: replaceRate
      });
    });

    const actualDate = document.getElementById('return-actual-date')?.value || new Date().toISOString().split('T')[0];
    const lateFee = parseFloat(document.getElementById('return-late-fee')?.value || 0);

    const payload = {
      action: 'checkin',
      rental_id: r.id,
      actual_return_date: actualDate,
      late_fee_charged: lateFee,
      terminal_id: this.terminalId || 'REG-01',
      returned_items: returnedItems
    };

    try {
      const res = await fetch('api/endpoints/rentals.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const text = await res.text();
      let data;
      try {
        data = JSON.parse(text);
      } catch (parseErr) {
        console.error('Non-JSON response from rentals endpoint:', text);
        this.showToast('Server response error: ' + (text.substring(0, 100) || 'Empty response from server'), 'danger');
        return;
      }
      if (data.success) {
        this.showToast(data.message || 'Rental return completed successfully!', 'success');
        this.closeRentalReturnModal();
        await this.fetchRentals();
        if (typeof this.fetchProducts === 'function') await this.fetchProducts();
        this.renderCurrentView();

        const outcomeMsg = data.deposit_refunded > 0
          ? `Refund of ${this.formatCurrency(data.deposit_refunded)} handed back to customer.`
          : (data.additional_amount_owed > 0 ? `Customer billed additional balance of ${this.formatCurrency(data.additional_amount_owed)}.` : 'Caution deposit fully reconciled.');
        this.showToast(outcomeMsg, 'info');
      } else {
        this.showToast(data.error || 'Failed to complete return.', 'danger');
      }
    } catch (err) {
      this.showToast('Error submitting return: ' + err.message, 'danger');
    }
  },

  // -------------------------------------------------------------
  // DEDICATED MODAL: RESTOCK REPAIRED & RECOVERED FLEET GEAR
  // -------------------------------------------------------------
  openRentalFleetRestockModal(preselectedProductId = null, preselectedType = 'REPAIRED') {
    let overlay = document.getElementById('modal-rental-fleet-restock');
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = 'modal-rental-fleet-restock';
      overlay.className = 'modal-overlay';
      overlay.style.cssText = 'position:fixed; inset:0; background:rgba(15,23,42,0.6); backdrop-filter:blur(3px); z-index:9999; align-items:center; justify-content:center; padding:1rem;';
      document.body.appendChild(overlay);
    }

    // Filter strictly to rental products
    const rentalProducts = (this.products || []).filter(p => this.isRentalProduct && this.isRentalProduct(p));
    
    // Determine default selected product
    let activeProdId = preselectedProductId;
    if (!activeProdId && rentalProducts.length > 0) {
      const candidate = rentalProducts.find(p => {
        const st = (this.itemDamageStats && this.itemDamageStats[p.id]) || {};
        return (Number(st.net_damaged || 0) > 0 || Number(st.net_missing || 0) > 0);
      });
      activeProdId = candidate ? candidate.id : rentalProducts[0].id;
    }

    const defaultBranch = this.branchCode || 'MAIN-01';

    overlay.innerHTML = `
      <div class="modal-content" style="background:#ffffff; border-radius:12px; max-width:580px; width:100%; max-height:92vh; overflow-y:auto; box-shadow:0 25px 50px -12px rgba(0,0,0,0.25); display:flex; flex-direction:column;">
        <div style="padding:1.1rem 1.4rem; border-bottom:1px solid var(--slate-200); display:flex; justify-content:space-between; align-items:center; background:#f5f3ff;">
          <div>
            <h3 style="margin:0; font-size:1.15rem; font-weight:800; color:#581c87; display:flex; align-items:center; gap:0.45rem;">
              <i class="fa-solid fa-boxes-packing" style="color:#7c3aed;"></i> Restock Equipment to Warehouse Fleet
            </h3>
            <p style="margin:2px 0 0; font-size:0.78rem; color:#6b21a8;">
              Put repaired units or customer replacements back into active rental inventory.
            </p>
          </div>
          <button type="button" class="btn btn-outline btn-sm" onclick="app.closeRentalFleetRestockModal()" style="border:none; color:var(--slate-400); font-size:1.2rem; cursor:pointer;">
            <i class="fa-solid fa-xmark"></i>
          </button>
        </div>

        <div style="padding:1.25rem 1.4rem; display:flex; flex-direction:column; gap:1.1rem;">
          <!-- Equipment Item Selection -->
          <div class="form-group">
            <label style="font-weight:700; font-size:0.85rem; color:var(--slate-700); margin-bottom:0.35rem; display:block;">
              Equipment Asset *
            </label>
            <select id="fleet-restock-product-id" class="form-control" onchange="app.updateRentalFleetRestockPreview()" style="font-weight:600;">
              ${rentalProducts.length === 0 ? `
                <option value="">No rental products found</option>
              ` : rentalProducts.map(p => {
                const st = (this.itemDamageStats && this.itemDamageStats[p.id]) || {};
                const d = Number(st.net_damaged || 0);
                const m = Number(st.net_missing || 0);
                const statusTag = (d > 0 || m > 0) ? `⚠️ ${d} in repair, ${m} missing` : '✓ 100% Ready';
                return `<option value="${this.escapeHtml(p.id)}" ${p.id === activeProdId ? 'selected' : ''}>${this.escapeHtml(p.name)} [Stock: ${p.current_quantity || 0}] &bull; ${statusTag}</option>`;
              }).join('')}
            </select>
          </div>

          <!-- Restock Type Toggle -->
          <div class="form-group">
            <label style="font-weight:700; font-size:0.85rem; color:var(--slate-700); margin-bottom:0.35rem; display:block;">
              Restock Category
            </label>
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:0.6rem;">
              <label id="fleet-type-repair-card" style="border:1.5px solid #86efac; background:#f0fdf4; border-radius:8px; padding:0.65rem 0.85rem; cursor:pointer; display:flex; align-items:center; gap:0.5rem;">
                <input type="radio" name="fleet-restock-type" value="REPAIRED" ${preselectedType === 'REPAIRED' ? 'checked' : ''} onchange="app.updateRentalFleetRestockPreview()">
                <div>
                  <div style="font-weight:700; font-size:0.85rem; color:#15803d;"><i class="fa-solid fa-screwdriver-wrench"></i> Repaired Gear</div>
                  <div style="font-size:0.72rem; color:#166534;" id="fleet-restock-repair-badge">Restoring fixed units</div>
                </div>
              </label>

              <label id="fleet-type-found-card" style="border:1.5px solid var(--slate-200); background:#ffffff; border-radius:8px; padding:0.65rem 0.85rem; cursor:pointer; display:flex; align-items:center; gap:0.5rem;">
                <input type="radio" name="fleet-restock-type" value="FOUND_REPLACED" ${preselectedType === 'FOUND_REPLACED' ? 'checked' : ''} onchange="app.updateRentalFleetRestockPreview()">
                <div>
                  <div style="font-weight:700; font-size:0.85rem; color:#0369a1;"><i class="fa-solid fa-rotate-left"></i> Found / Replaced</div>
                  <div style="font-size:0.72rem; color:#0284c7;" id="fleet-restock-missing-badge">Recovered / customer buy-in</div>
                </div>
              </label>
            </div>
          </div>

          <!-- Quantity to Restock -->
          <div style="display:grid; grid-template-columns: 1fr 1fr; gap:0.85rem;">
            <div class="form-group">
              <label style="font-weight:700; font-size:0.85rem; color:var(--slate-700); margin-bottom:0.35rem; display:block;">
                Quantity to Restock *
              </label>
              <input type="number" id="fleet-restock-qty" class="form-control" min="1" value="1" oninput="app.updateRentalFleetRestockPreview()" style="font-weight:800; font-size:1.1rem; color:#7c3aed;">
              <div id="fleet-restock-cap-hint" style="font-size:0.72rem; color:#64748b; margin-top:0.25rem;">Max allowable: 1</div>
            </div>

            <!-- Branch Warehouse -->
            <div class="form-group">
              <label style="font-weight:700; font-size:0.85rem; color:var(--slate-700); margin-bottom:0.35rem; display:block;">
                Receiving Branch Location
              </label>
              <select id="fleet-restock-branch" class="form-control" onchange="app.updateRentalFleetRestockPreview()">
                ${(this.branches || [{ branch_code: 'MAIN-01', name: 'Main Branch' }]).map(b => `
                  <option value="${this.escapeHtml(b.branch_code)}" ${b.branch_code === defaultBranch ? 'selected' : ''}>
                    ${this.escapeHtml(b.name)} (${this.escapeHtml(b.branch_code)})
                  </option>
                `).join('')}
              </select>
            </div>
          </div>

          <!-- Live Impact Preview Box -->
          <div id="fleet-restock-preview-box" style="background:#f8fafc; border:1px solid var(--slate-200); border-radius:8px; padding:0.75rem 1rem;">
            <div style="font-size:0.8rem; font-weight:700; color:var(--slate-700); margin-bottom:0.25rem;">Fleet Warehouse Projection:</div>
            <div id="fleet-restock-preview-text" style="font-size:0.92rem; font-weight:800; color:#15803d;">Current Stock: 0 &rarr; New Stock: 0</div>
          </div>

          <!-- Fleet Note -->
          <div class="form-group">
            <label style="font-weight:700; font-size:0.85rem; color:var(--slate-700); margin-bottom:0.35rem; display:block;">
              Restock Log / Reason Note
            </label>
            <input type="text" id="fleet-restock-notes" class="form-control" placeholder="e.g. Canopy repaired by welding vendor and verified ready">
          </div>
        </div>

        <div style="padding:1rem 1.4rem; border-top:1px solid var(--slate-200); display:flex; justify-content:flex-end; gap:0.6rem; background:#f8fafc;">
          <button type="button" class="btn btn-outline" onclick="app.closeRentalFleetRestockModal()">Cancel</button>
          <button type="button" id="fleet-restock-submit-btn" class="btn btn-primary" onclick="app.submitRentalFleetRestock()" style="background:#7c3aed; border-color:#6d28d9; font-weight:700;">
            <i class="fa-solid fa-circle-check"></i> Put Back Into Fleet
          </button>
        </div>
      </div>
    `;

    overlay.classList.add('active');
    overlay.style.display = 'flex';
    this.updateRentalFleetRestockPreview();
  },

  closeRentalFleetRestockModal() {
    const overlay = document.getElementById('modal-rental-fleet-restock');
    if (overlay) {
      overlay.classList.remove('active');
      overlay.style.display = 'none';
    }
  },

  updateRentalFleetRestockPreview() {
    const prodId = document.getElementById('fleet-restock-product-id')?.value;
    const typeRadio = document.querySelector('input[name="fleet-restock-type"]:checked');
    const type = typeRadio ? typeRadio.value : 'REPAIRED';
    const qtyInput = document.getElementById('fleet-restock-qty');
    const previewText = document.getElementById('fleet-restock-preview-text');
    const previewBox = document.getElementById('fleet-restock-preview-box');
    const submitBtn = document.getElementById('fleet-restock-submit-btn');
    const capHint = document.getElementById('fleet-restock-cap-hint');
    const notesInput = document.getElementById('fleet-restock-notes');
    const repairCard = document.getElementById('fleet-type-repair-card');
    const foundCard = document.getElementById('fleet-type-found-card');

    if (repairCard && foundCard) {
      if (type === 'REPAIRED') {
        repairCard.style.border = '1.5px solid #86efac';
        repairCard.style.background = '#f0fdf4';
        foundCard.style.border = '1.5px solid var(--slate-200)';
        foundCard.style.background = '#ffffff';
      } else {
        foundCard.style.border = '1.5px solid #7dd3fc';
        foundCard.style.background = '#f0f9ff';
        repairCard.style.border = '1.5px solid var(--slate-200)';
        repairCard.style.background = '#ffffff';
      }
    }

    if (!prodId) {
      if (previewText) previewText.textContent = 'Select an equipment asset.';
      if (submitBtn) submitBtn.disabled = true;
      return;
    }

    const prod = (this.products || []).find(p => p.id === prodId);
    const prodName = prod ? prod.name : 'Equipment';
    const stats = (this.itemDamageStats && this.itemDamageStats[prodId]) || {};
    const netDamaged = stats.net_damaged !== undefined ? Number(stats.net_damaged) : 0;
    const netMissing = stats.net_missing !== undefined ? Number(stats.net_missing) : 0;

    const repairBadge = document.getElementById('fleet-restock-repair-badge');
    if (repairBadge) repairBadge.textContent = `${netDamaged} unit(s) awaiting repair`;

    const missingBadge = document.getElementById('fleet-restock-missing-badge');
    if (missingBadge) missingBadge.textContent = `${netMissing} unit(s) missing/lost`;

    const capMax = type === 'REPAIRED' ? netDamaged : netMissing;

    if (qtyInput) {
      qtyInput.max = String(Math.max(1, capMax));
      if (!qtyInput.dataset.userEdited) {
        qtyInput.value = String(Math.max(1, capMax));
      }
    }

    if (capHint) {
      capHint.textContent = `Awaiting restock: ${capMax} unit(s)`;
    }

    if (notesInput && !notesInput.dataset.userEdited) {
      notesInput.value = type === 'REPAIRED'
        ? `Repaired ${prodName} restored to active warehouse fleet`
        : `Recovered missing ${prodName} / customer replacement returned to fleet`;
    }

    const curStock = Number(prod ? prod.current_quantity || 0 : 0);
    const qty = parseFloat(qtyInput?.value || 0);

    if (capMax <= 0) {
      if (previewBox) {
        previewBox.style.background = '#fef3c7';
        previewBox.style.borderColor = '#fde68a';
      }
      if (previewText) {
        previewText.style.color = '#92400e';
        previewText.textContent = `✓ All ${type === 'REPAIRED' ? 'damaged' : 'missing'} units of ${prodName} are already 100% restocked!`;
      }
      if (submitBtn) submitBtn.disabled = true;
      return;
    }

    if (qty > capMax) {
      if (previewBox) {
        previewBox.style.background = '#fee2e2';
        previewBox.style.borderColor = '#fecaca';
      }
      if (previewText) {
        previewText.style.color = '#b91c1c';
        previewText.textContent = `⚠️ Quantity (${qty}) exceeds the ${capMax} units currently awaiting ${type === 'REPAIRED' ? 'repair' : 'recovery'}!`;
      }
      if (submitBtn) submitBtn.disabled = true;
      return;
    }

    if (qty <= 0) {
      if (submitBtn) submitBtn.disabled = true;
      return;
    }

    if (submitBtn) submitBtn.disabled = false;
    if (previewBox) {
      previewBox.style.background = '#f0fdf4';
      previewBox.style.borderColor = '#bbf7d0';
    }
    if (previewText) {
      previewText.style.color = '#15803d';
      previewText.textContent = `Warehouse Stock: ${curStock} + ${qty} &rarr; New Stock: ${curStock + qty} pcs`;
    }
  },

  async submitRentalFleetRestock() {
    const prodId = document.getElementById('fleet-restock-product-id')?.value;
    const typeRadio = document.querySelector('input[name="fleet-restock-type"]:checked');
    const type = typeRadio ? typeRadio.value : 'REPAIRED';
    const qty = parseFloat(document.getElementById('fleet-restock-qty')?.value || 0);
    const branchCode = document.getElementById('fleet-restock-branch')?.value || (this.branchCode || 'MAIN-01');
    const notes = (document.getElementById('fleet-restock-notes')?.value || '').trim() ||
      (type === 'REPAIRED' ? 'Repaired equipment restored to warehouse fleet' : 'Recovered missing equipment restored to fleet');

    if (!prodId || qty <= 0) {
      this.showToast('Please specify a valid equipment item and quantity.', 'warning');
      return;
    }

    const prod = (this.products || []).find(p => p.id === prodId);
    const prodName = prod ? prod.name : 'Equipment';

    const submitBtn = document.getElementById('fleet-restock-submit-btn');
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Restocking...';
    }

    try {
      const res = await this.apiFetch('api/endpoints/inventory.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          product_id: prodId,
          branch_code: branchCode,
          type: type,
          quantity: qty,
          reason: notes
        })
      });
      const data = await res.json();
      if (data.success) {
        this.showToast(`✓ Successfully restocked ${qty} unit(s) of '${prodName}' back to fleet!`, 'success');
        this.closeRentalFleetRestockModal();
        await this.fetchProducts();
        await this.fetchInventory();
        await this.fetchRentals();
        this.renderCurrentView();
      } else {
        this.showToast(data.message || 'Failed to restock equipment.', 'danger');
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.innerHTML = '<i class="fa-solid fa-circle-check"></i> Put Back Into Fleet';
        }
      }
    } catch (err) {
      this.showToast('Error restocking equipment: ' + err.message, 'danger');
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="fa-solid fa-circle-check"></i> Put Back Into Fleet';
      }
    }
  },

  // -------------------------------------------------------------
  // PRINT RENTAL GATE PASS & CONTRACT
  // -------------------------------------------------------------
  async printRentalGatePass(rentalId) {
    try {
      const res = await fetch(`api/endpoints/rentals.php?id=${encodeURIComponent(rentalId)}`);
      const data = await res.json();
      if (!data.success || !data.rental) {
        this.showToast('Could not load contract for printing.', 'danger');
        return;
      }

      const r = data.rental;
      const prof = this.storeProfile || {};
      const isBooked = (r.status === 'BOOKED');
      const docTitle = isBooked ? `Rental Quotation - ${this.escapeHtml(r.rental_number)}` : `Rental Gate Pass - ${this.escapeHtml(r.rental_number)}`;
      const contractTitle = isBooked ? `EVENT EQUIPMENT HIRE QUOTATION & ADVANCE BOOKING` : `EQUIPMENT RENTAL AGREEMENT & GATE PASS`;

      const isPostpaid = (r.payment_status === 'PENDING');
      const isDepositOnly = (r.payment_status === 'DEPOSIT_ONLY');
      const cautionHeld = (r.caution_deposit_status === 'HELD') ? parseFloat(r.caution_deposit || 0) : 0;
      const rentalTotal = parseFloat(r.total_rental_amount || 0);
      const paidUpfront = isPostpaid ? 0 : (isDepositOnly ? cautionHeld : (rentalTotal + cautionHeld));
      const balanceDueOnReturn = (isPostpaid || isDepositOnly) ? rentalTotal : 0;

      const printWin = window.open('', '_blank', 'width=800,height=900');
      if (!printWin) {
        this.showToast('Popup blocker prevented printing. Please allow popups for StoreFlow.', 'warning');
        return;
      }

      printWin.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>${docTitle}</title>
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; padding: 2rem; color: #1e293b; max-width: 750px; margin: auto; }
            .header { text-align: center; border-bottom: 2px solid #e2e8f0; padding-bottom: 1rem; margin-bottom: 1.5rem; }
            .header h1 { margin: 0; font-size: 1.6rem; color: #0f172a; }
            .header p { margin: 3px 0; font-size: 0.85rem; color: #64748b; }
            .contract-title { text-align: center; font-size: 1.1rem; font-weight: 800; text-transform: uppercase; color: ${isBooked ? '#0284c7' : '#7c3aed'}; margin: 1rem 0; letter-spacing: 1px; }
            .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1.5rem; font-size: 0.85rem; line-height: 1.5; }
            .info-block { background: #f8fafc; padding: 0.85rem; border-radius: 6px; border: 1px solid #e2e8f0; }
            .info-block strong { color: #0f172a; }
            table { width: 100%; border-collapse: collapse; margin-bottom: 1.5rem; font-size: 0.85rem; }
            th, td { border: 1px solid #cbd5e1; padding: 0.55rem; }
            th { background: #f1f5f9; text-transform: uppercase; font-size: 0.72rem; }
            .totals { margin-left: auto; width: 340px; margin-bottom: 2rem; font-size: 0.88rem; line-height: 1.6; }
            .totals-line { display: flex; justify-content: space-between; }
            .totals-line.grand { font-size: 1.1rem; font-weight: 800; color: ${isBooked ? '#0284c7' : '#7c3aed'}; border-top: 2px solid ${isBooked ? '#0284c7' : '#7c3aed'}; padding-top: 0.4rem; margin-top: 0.4rem; }
            .signatures { display: grid; grid-template-columns: 1fr 1fr; gap: 3rem; margin-top: 3.5rem; }
            .sign-line { border-top: 1px dashed #64748b; text-align: center; padding-top: 0.4rem; font-size: 0.82rem; font-weight: 600; }
            .terms { font-size: 0.72rem; color: #64748b; line-height: 1.45; border-top: 1px solid #e2e8f0; padding-top: 1rem; margin-top: 2rem; }
            @media print {
              body { padding: 0; }
              .no-print { display: none; }
            }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>${this.escapeHtml(prof.store_name || 'StoreFlow Equipment Rentals')}</h1>
            <p>${this.escapeHtml(prof.address || 'Event & Logistics Hire')}</p>
            <p>Phone: ${this.escapeHtml(prof.phone || '0244000000')}</p>
          </div>

          <div class="contract-title">${contractTitle}</div>

          ${isBooked ? `
            <div style="background:#f0f9ff; border:1.5px dashed #7dd3fc; color:#0369a1; padding:0.75rem 1rem; border-radius:6px; margin-bottom:1.25rem; font-size:0.82rem; line-height:1.45;">
              <strong><i class="fa-solid fa-file-invoice"></i> Official Price Quotation & Advance Reservation:</strong>
              This quotation secures your equipment pricing and schedule. Warehouse inventory will be allocated and verified upon formal dispatch confirmation.
            </div>
          ` : ''}

          <div class="info-grid">
            <div class="info-block">
              <div><strong>${isBooked ? 'Quotation / Booking #:' : 'Rental Agreement #:'}</strong> ${this.escapeHtml(r.rental_number)}</div>
              <div><strong>${isBooked ? 'Reserved Pickup Date:' : 'Dispatch Date:'}</strong> ${this.escapeHtml(r.pickup_date)}</div>
              <div><strong>${isBooked ? 'Planned Return Date:' : 'Expected Return Date:'}</strong> <span style="color:#b91c1c; font-weight:700;">${this.escapeHtml(r.return_due_date)}</span></div>
              <div><strong>Duration:</strong> ${r.duration_days} Day(s)</div>
              <div><strong>Payment Status:</strong> <span style="font-weight:700; color:#4338ca;">${isBooked ? 'Quotation / Advance Booking' : (isPostpaid ? 'Pay on Return (Postpaid)' : (isDepositOnly ? 'Deposit Held / Balance Due' : 'Paid Upfront'))}</span></div>
            </div>

            <div class="info-block">
              <div><strong>Customer Name:</strong> ${this.escapeHtml(r.customer_name)}</div>
              <div><strong>Contact Phone:</strong> ${this.escapeHtml(r.customer_phone || 'N/A')}</div>
              <div><strong>National ID / Ghana Card:</strong> ${this.escapeHtml(r.customer_id_card || 'N/A')}</div>
              <div><strong>Event Location / Venue:</strong> ${this.escapeHtml(r.event_location || 'N/A')}</div>
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th style="text-align:left;">Equipment Asset Description</th>
                <th style="text-align:center; width:55px;">Qty</th>
                <th style="text-align:right; width:80px;">Daily Rate</th>
                <th style="text-align:right; width:95px;">Agreed Damage</th>
                <th style="text-align:right; width:95px;">Agreed Loss</th>
                <th style="text-align:right; width:95px;">Line Total</th>
              </tr>
            </thead>
            <tbody>
              ${(r.items || []).map(it => `
                <tr>
                  <td>
                    <strong>${this.escapeHtml(it.product_name)}</strong>
                  </td>
                  <td style="text-align:center; font-weight:700;">${it.quantity_dispatched}</td>
                  <td style="text-align:right;">${this.formatCurrency(it.daily_rate)}</td>
                  <td style="text-align:right; color:#b45309;">${this.formatCurrency(it.damage_charge_unit || 15)}</td>
                  <td style="text-align:right; color:#b91c1c;">${this.formatCurrency(it.replacement_charge_unit || 80)}</td>
                  <td style="text-align:right; font-weight:700;">${this.formatCurrency(it.line_total)}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>

          <div class="totals">
            <div class="totals-line">
              <span>Rental Equipment Subtotal:</span>
              <strong>${this.formatCurrency(r.total_rental_amount)}</strong>
            </div>
            <div class="totals-line" style="color:#86198f;">
              <span>Caution Security Deposit:</span>
              <strong>${this.formatCurrency(r.caution_deposit)} (${this.escapeHtml(r.caution_deposit_status || (isBooked ? 'RESERVED' : 'HELD'))})</strong>
            </div>
            <div class="totals-line grand">
              <span>${isBooked ? 'Total Estimated Hire Cost:' : 'Total Paid at Dispatch:'}</span>
              <span>${this.formatCurrency(isBooked ? (rentalTotal + cautionHeld) : paidUpfront)}</span>
            </div>
            ${!isBooked && balanceDueOnReturn > 0 ? `
              <div class="totals-line" style="color:#b45309; font-weight:800; border-top:1px dashed #cbd5e1; margin-top:4px; padding-top:4px;">
                <span>Balance Due on Return:</span>
                <span>${this.formatCurrency(balanceDueOnReturn)}</span>
              </div>
            ` : ''}
          </div>

          <div class="terms">
            <strong>${isBooked ? 'ESTIMATE & RESERVATION TERMS:' : 'RENTAL AGREEMENT TERMS:'}</strong>
            <ol style="margin: 0.3rem 0; padding-left: 1.2rem;">
              ${isBooked ? `
                <li>This proforma estimate is valid for 14 days from date of issue.</li>
                <li>Equipment reservation is confirmed upon dispatch approval or advance deposit.</li>
                <li>Expected hire period: <strong>${r.duration_days} Day(s)</strong> (${this.escapeHtml(r.pickup_date)} to ${this.escapeHtml(r.return_due_date)}).</li>
                <li>Caution Security Deposit of <strong>${this.formatCurrency(r.caution_deposit)}</strong> is required prior to equipment release and refundable upon return in original condition.</li>
              ` : `
                <li>All items listed above have been inspected and released in good, undamaged condition.</li>
                <li>The hirer agrees to return all items on or before <strong>${this.escapeHtml(r.return_due_date)}</strong>. A late penalty of <strong>${this.formatCurrency(r.late_fee_per_day)} per day</strong> will be charged for unreturned equipment.</li>
                <li>The Caution Security Deposit is held as security against delay, damage, or loss.</li>
                <li><strong>Agreed Damage & Loss Fees:</strong> The hirer explicitly agrees to the per-unit damage rates (for burns, cuts, bent frames, or breakage) and replacement loss rates (for missing items) stipulated in the table above.</li>
                <li>${isPostpaid || isDepositOnly ? '<strong>Payment Settlement:</strong> The outstanding hire balance will be paid in full upon return inspection together with any applicable penalties.' : 'Full hire charges paid in advance.'}</li>
              `}
            </ol>
          </div>

          <div class="signatures">
            <div class="sign-line">
              ${isBooked ? 'Customer / Representative Acceptance & Date' : 'Hirer / Customer Signature & Date'}
            </div>
            <div class="sign-line">
              ${this.escapeHtml(prof.store_name || 'Store')} ${isBooked ? 'Authorized Agent Signature & Date' : 'Warehouse Dispatcher Signature & Date'}
            </div>
          </div>

          <div style="text-align:center; margin-top:2.5rem;" class="no-print">
            <button onclick="window.print()" style="background:${isBooked ? '#0284c7' : '#7c3aed'}; color:#fff; border:none; padding:0.6rem 1.4rem; font-size:0.95rem; font-weight:700; border-radius:6px; cursor:pointer;">
              ${isBooked ? 'Print Quotation / Booking' : 'Print Agreement / Gate Pass'}
            </button>
          </div>
        </body>
        </html>
      `);
      printWin.document.close();
    } catch (err) {
      this.showToast('Print error: ' + err.message, 'danger');
    }
  },

  // -------------------------------------------------------------
  // MODAL: SETTLE OUTSTANDING RENTAL BALANCE
  // -------------------------------------------------------------
  async openRentalSettlementModal(rentalId) {
    try {
      const res = await fetch(`api/endpoints/rentals.php?id=${encodeURIComponent(rentalId)}`);
      const data = await res.json();
      if (!data.success || !data.rental) {
        this.showToast(data.error || 'Rental record not found.', 'danger');
        return;
      }

      const r = data.rental;
      this.activeSettlementRental = r;

      const totalAdditionalOwed = Math.max(0, Number(r.additional_amount_owed || 0));
      const alreadyPaid = Math.max(0, Number(r.balance_paid || 0));
      let netOwed = Math.max(0, totalAdditionalOwed - alreadyPaid);
      if (netOwed <= 0.009 && totalAdditionalOwed > 0 && r.payment_status !== 'PAID') {
        netOwed = totalAdditionalOwed;
      }

      let overlay = document.getElementById('modal-rental-settlement');
      if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'modal-rental-settlement';
        overlay.className = 'modal-overlay';
        overlay.style.cssText = 'position:fixed; inset:0; background:rgba(15,23,42,0.6); backdrop-filter:blur(3px); z-index:9999; align-items:center; justify-content:center; padding:1rem; display:flex;';
        document.body.appendChild(overlay);
      } else {
        overlay.style.display = 'flex';
      }

      const damageFee = Number(r.damage_fee_charged || 0);
      const missingFee = Number(r.missing_fee_charged || 0);
      const lateFee = Number(r.late_fee_charged || 0);
      const cautionHeld = Number(r.caution_deposit || 0);

      overlay.innerHTML = `
        <div class="modal-content" style="background:#ffffff; border-radius:12px; max-width:540px; width:100%; max-height:92vh; overflow-y:auto; box-shadow:0 25px 50px -12px rgba(0,0,0,0.25); display:flex; flex-direction:column;">
          <div style="padding:1.1rem 1.4rem; border-bottom:1px solid var(--slate-200); display:flex; justify-content:space-between; align-items:center; background:#f0f9ff;">
            <div>
              <h3 style="margin:0; font-size:1.15rem; font-weight:800; color:#0369a1; display:flex; align-items:center; gap:0.45rem;">
                <i class="fa-solid fa-hand-holding-dollar" style="color:#0284c7;"></i> Settle Outstanding Rental Balance
              </h3>
              <p style="margin:2px 0 0; font-size:0.78rem; color:#075985;">
                Contract: <strong>${this.escapeHtml(r.rental_number)}</strong> &bull; Customer: <strong>${this.escapeHtml(r.customer_name)}</strong>
              </p>
            </div>
            <button type="button" class="btn btn-outline btn-sm" onclick="app.closeRentalSettlementModal()" style="border:none; color:var(--slate-400); font-size:1.2rem; cursor:pointer;">
              <i class="fa-solid fa-xmark"></i>
            </button>
          </div>

          <form id="rental-settlement-form" onsubmit="event.preventDefault(); app.confirmRentalSettlement('${this.escapeHtml(r.id)}');" style="padding:1.25rem 1.4rem; display:flex; flex-direction:column; gap:1.1rem;">
            <!-- Customer & Outstanding Debt Card -->
            <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:0.9rem 1rem;">
              <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.6rem; font-size:0.85rem;">
                <span style="color:var(--slate-600);"><i class="fa-solid fa-user"></i> Customer:</span>
                <strong style="color:var(--slate-900);">${this.escapeHtml(r.customer_name)} ${r.customer_phone ? `(${this.escapeHtml(r.customer_phone)})` : ''}</strong>
              </div>

              <div style="border-top:1px dashed #cbd5e1; padding-top:0.6rem; font-size:0.8rem; display:flex; flex-direction:column; gap:0.3rem;">
                ${damageFee > 0 ? `
                  <div style="display:flex; justify-content:space-between;">
                    <span style="color:#b91c1c;">Broken / Damaged Equipment Fee:</span>
                    <strong>${this.formatCurrency(damageFee)}</strong>
                  </div>
                ` : ''}
                ${missingFee > 0 ? `
                  <div style="display:flex; justify-content:space-between;">
                    <span style="color:#b91c1c;">Missing / Replacement Fee:</span>
                    <strong>${this.formatCurrency(missingFee)}</strong>
                  </div>
                ` : ''}
                ${lateFee > 0 ? `
                  <div style="display:flex; justify-content:space-between;">
                    <span style="color:#b45309;">Overdue Return Penalty:</span>
                    <strong>${this.formatCurrency(lateFee)}</strong>
                  </div>
                ` : ''}
                ${cautionHeld > 0 ? `
                  <div style="display:flex; justify-content:space-between; color:#475569;">
                    <span>Caution Security Deposit (Forfeited):</span>
                    <span>- ${this.formatCurrency(cautionHeld)}</span>
                  </div>
                ` : ''}
                ${alreadyPaid > 0 ? `
                  <div style="display:flex; justify-content:space-between; color:#15803d;">
                    <span>Previously Settled / Paid:</span>
                    <span>- ${this.formatCurrency(alreadyPaid)}</span>
                  </div>
                ` : ''}
              </div>

              <div style="border-top:1.5px solid #cbd5e1; margin-top:0.6rem; padding-top:0.6rem; display:flex; justify-content:space-between; align-items:center;">
                <span style="font-weight:700; font-size:0.95rem; color:#0f172a;">Active Balance Owed:</span>
                <span style="font-weight:800; font-size:1.25rem; color:#b91c1c;">${this.formatCurrency(netOwed)}</span>
              </div>
            </div>

            <!-- Payment Input -->
            <div>
              <label class="form-label" style="font-size:0.82rem; font-weight:700; margin-bottom:0.35rem; display:block;">Amount Paying (GH₵) *</label>
              <input type="number" id="settlement-amount-input" class="form-control" step="0.01" min="0.01" max="${netOwed.toFixed(2)}" value="${netOwed.toFixed(2)}" required style="font-size:1.1rem; font-weight:800; color:#0f172a; padding:0.5rem 0.75rem;">
              <small style="color:var(--slate-500); font-size:0.74rem;">Default is full balance. Partial payments are accepted and keep balance tracked.</small>
            </div>

            <!-- Payment Method -->
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:0.75rem;">
              <div>
                <label class="form-label" style="font-size:0.82rem; font-weight:700; margin-bottom:0.35rem; display:block;">Payment Method *</label>
                <select id="settlement-payment-method" class="form-control" style="font-size:0.85rem; font-weight:600;">
                  <option value="CASH" selected>💵 Cash (Active Till)</option>
                  <option value="MOMO">📱 Mobile Money (MoMo)</option>
                  <option value="CARD">💳 POS Card Terminal</option>
                  <option value="BANK">🏛️ Bank Transfer</option>
                </select>
              </div>
              <div>
                <label class="form-label" style="font-size:0.82rem; font-weight:700; margin-bottom:0.35rem; display:block;">Reference / Note</label>
                <input type="text" id="settlement-payment-notes" class="form-control" placeholder="e.g. MoMo Ref / Cash receipt" style="font-size:0.85rem;">
              </div>
            </div>

            <!-- Footer actions -->
            <div style="display:flex; justify-content:flex-end; gap:0.6rem; margin-top:0.75rem; border-top:1px solid #e2e8f0; padding-top:1rem;">
              <button type="button" class="btn btn-outline" onclick="app.closeRentalSettlementModal()" style="padding:0.6rem 1.2rem; font-weight:600;">
                Cancel
              </button>
              <button type="submit" id="btn-submit-settlement" class="btn btn-primary" style="background:#0284c7; border-color:#0369a1; padding:0.6rem 1.4rem; font-weight:700;">
                <i class="fa-solid fa-check-circle"></i> Confirm Settlement & Print Slip
              </button>
            </div>
          </form>
        </div>
      `;
    } catch (err) {
      this.showToast('Error opening settlement modal: ' + err.message, 'danger');
    }
  },

  closeRentalSettlementModal() {
    const overlay = document.getElementById('modal-rental-settlement');
    if (overlay) {
      overlay.style.display = 'none';
    }
    this.activeSettlementRental = null;
  },

  async confirmRentalSettlement(rentalId) {
    const amountInput = document.getElementById('settlement-amount-input');
    const methodSelect = document.getElementById('settlement-payment-method');
    const notesInput = document.getElementById('settlement-payment-notes');
    const submitBtn = document.getElementById('btn-submit-settlement');

    const amountPaid = parseFloat(amountInput ? amountInput.value : 0);
    if (isNaN(amountPaid) || amountPaid <= 0) {
      this.showToast('Please enter a valid payment amount greater than 0.', 'warning');
      return;
    }

    const paymentMethod = methodSelect ? methodSelect.value : 'CASH';
    const notes = notesInput ? notesInput.value.trim() : '';

    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processing Payment...';
    }

    try {
      const res = await fetch('api/endpoints/rentals.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'settle_balance',
          rental_id: rentalId,
          amount_paid: amountPaid,
          payment_method: paymentMethod,
          notes: notes
        })
      });

      const data = await res.json();
      if (!data.success) {
        this.showToast(data.error || 'Failed to settle rental balance.', 'danger');
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.innerHTML = '<i class="fa-solid fa-check-circle"></i> Confirm Settlement & Print Slip';
        }
        return;
      }

      this.showToast(data.message || 'Rental balance settled successfully!', 'success');
      this.closeRentalSettlementModal();
      await this.fetchRentals();
      if (this.currentView === 'rentals') {
        this.renderCurrentView();
      }

      // Print clearance settlement receipt
      this.printRentalSettlementSlip(rentalId);

    } catch (err) {
      this.showToast('Settlement error: ' + err.message, 'danger');
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="fa-solid fa-check-circle"></i> Confirm Settlement & Print Slip';
      }
    }
  },

  // -------------------------------------------------------------
  // PRINT RENTAL SETTLEMENT & CLEARANCE SLIP
  // -------------------------------------------------------------
  async printRentalSettlementSlip(rentalId) {
    try {
      const res = await fetch(`api/endpoints/rentals.php?id=${encodeURIComponent(rentalId)}`);
      const data = await res.json();
      if (!data.success || !data.rental) {
        this.showToast('Could not load contract details for settlement slip.', 'danger');
        return;
      }

      const r = data.rental;
      const prof = this.storeProfile || {};
      const totalAdditionalOwed = Math.max(0, Number(r.additional_amount_owed || 0));
      const alreadyPaid = Math.max(0, Number(r.balance_paid || 0));
      const remainingOwed = Math.max(0, totalAdditionalOwed - alreadyPaid);
      const isPaidInFull = (remainingOwed <= 0.009) || (r.payment_status === 'PAID');

      const printWin = window.open('', '_blank', 'width=800,height=900');
      if (!printWin) {
        this.showToast('Popup blocker prevented printing. Please allow popups for StoreFlow.', 'warning');
        return;
      }

      printWin.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>Rental Settlement Slip - ${this.escapeHtml(r.rental_number)}</title>
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; padding: 2rem; color: #1e293b; max-width: 680px; margin: auto; }
            .header { text-align: center; border-bottom: 2px solid #e2e8f0; padding-bottom: 1rem; margin-bottom: 1.5rem; }
            .header h1 { margin: 0; font-size: 1.5rem; color: #0f172a; }
            .header p { margin: 3px 0; font-size: 0.85rem; color: #64748b; }
            .receipt-title { text-align: center; font-size: 1.05rem; font-weight: 800; text-transform: uppercase; color: #0284c7; margin: 1.2rem 0; letter-spacing: 0.5px; }
            .badge-cleared { display: inline-block; padding: 4px 12px; border-radius: 9999px; font-weight: 800; font-size: 0.85rem; text-transform: uppercase; }
            .cleared { background: #dcfce7; color: #15803d; border: 1px solid #86efac; }
            .partial { background: #fef3c7; color: #b45309; border: 1px solid #fde68a; }
            .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1.5rem; font-size: 0.85rem; line-height: 1.5; }
            .info-block { background: #f8fafc; padding: 0.85rem; border-radius: 6px; border: 1px solid #e2e8f0; }
            .info-block strong { color: #0f172a; }
            table { width: 100%; border-collapse: collapse; margin-bottom: 1.5rem; font-size: 0.85rem; }
            th, td { border: 1px solid #cbd5e1; padding: 0.55rem; }
            th { background: #f1f5f9; text-transform: uppercase; font-size: 0.72rem; }
            .totals { margin-left: auto; width: 340px; margin-bottom: 2rem; font-size: 0.88rem; line-height: 1.6; }
            .totals-line { display: flex; justify-content: space-between; }
            .totals-line.grand { font-size: 1.1rem; font-weight: 800; color: #0f172a; border-top: 2px solid #0284c7; padding-top: 0.4rem; margin-top: 0.4rem; }
            .signatures { display: grid; grid-template-columns: 1fr 1fr; gap: 3rem; margin-top: 3.5rem; }
            .sign-line { border-top: 1px dashed #64748b; text-align: center; padding-top: 0.4rem; font-size: 0.82rem; font-weight: 600; }
            .clearance-stamp { text-align: center; margin: 1.5rem 0; }
            @media print {
              body { padding: 0; }
              .no-print { display: none; }
            }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>${this.escapeHtml(prof.store_name || 'StoreFlow Equipment Rentals')}</h1>
            <p>${this.escapeHtml(prof.address || 'Event & Logistics Hire')}</p>
            <p>Phone: ${this.escapeHtml(prof.phone || '0244000000')}</p>
          </div>

          <div class="receipt-title">
            RENTAL SETTLEMENT & CLEARANCE RECEIPT
          </div>

          <div class="clearance-stamp">
            <span class="badge-cleared ${isPaidInFull ? 'cleared' : 'partial'}">
              ${isPaidInFull ? '✓ OBLIGATIONS CLEARED - PAID IN FULL' : '⚠ PARTIAL PAYMENT - BALANCE DUE'}
            </span>
          </div>

          <div class="info-grid">
            <div class="info-block">
              <strong>Rental Details:</strong><br>
              Contract #: <strong>${this.escapeHtml(r.rental_number)}</strong><br>
              Out Date: ${this.escapeHtml(r.pickup_date)}<br>
              Return Date: ${this.escapeHtml(r.actual_return_date || r.return_due_date)}<br>
              Terminal / Register: ${this.escapeHtml(this.terminalId || 'REG-01')}
            </div>
            <div class="info-block">
              <strong>Customer / Hirer:</strong><br>
              Name: <strong>${this.escapeHtml(r.customer_name)}</strong><br>
              Phone: ${this.escapeHtml(r.customer_phone || 'N/A')}<br>
              Settlement Method: <strong>${this.escapeHtml(r.payment_method || 'CASH')}</strong><br>
              Date Settled: <strong>${new Date().toLocaleString()}</strong>
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th>Inspection & Obligation Item</th>
                <th style="text-align:right;">Charge / Penalty</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Broken / Damaged Equipment Fees</td>
                <td style="text-align:right;">${this.formatCurrency(r.damage_fee_charged || 0)}</td>
              </tr>
              <tr>
                <td>Missing Equipment Replacement Charges</td>
                <td style="text-align:right;">${this.formatCurrency(r.missing_fee_charged || 0)}</td>
              </tr>
              <tr>
                <td>Overdue Days Penalty Fees</td>
                <td style="text-align:right;">${this.formatCurrency(r.late_fee_charged || 0)}</td>
              </tr>
              <tr style="background:#f8fafc; font-weight:700;">
                <td>Less Caution Security Deposit (${this.escapeHtml(r.caution_deposit_status || 'FORFEITED')})</td>
                <td style="text-align:right; color:#b91c1c;">- ${this.formatCurrency(r.caution_deposit || 0)}</td>
              </tr>
            </tbody>
          </table>

          <div class="totals">
            <div class="totals-line">
              <span>Total Penalties Billed:</span>
              <strong>${this.formatCurrency(totalAdditionalOwed)}</strong>
            </div>
            <div class="totals-line" style="color:#0284c7; font-weight:700;">
              <span>Total Settlement Received:</span>
              <strong>${this.formatCurrency(alreadyPaid)}</strong>
            </div>
            <div class="totals-line grand" style="color:${isPaidInFull ? '#15803d' : '#b91c1c'};">
              <span>Remaining Balance:</span>
              <span>${this.formatCurrency(remainingOwed)} ${isPaidInFull ? '(CLEARED)' : ''}</span>
            </div>
          </div>

          <div class="signatures">
            <div class="sign-line">
              Customer / Hirer Signature & Date
            </div>
            <div class="sign-line">
              Store Cashier / Receiving Officer Signature & Date
            </div>
          </div>

          <div style="text-align:center; margin-top:2.5rem;" class="no-print">
            <button onclick="window.print()" style="background:#0284c7; color:#fff; border:none; padding:0.6rem 1.4rem; font-size:0.95rem; font-weight:700; border-radius:6px; cursor:pointer;">
              Print Clearance Slip
            </button>
          </div>
        </body>
        </html>
      `);
      printWin.document.close();
    } catch (err) {
      this.showToast('Print error: ' + err.message, 'danger');
    }
  }
});

// Hook into StoreApp renderCurrentView so navigation to 'rentals' renders seamlessly
(function() {
  const origRenderCurrentView = StoreApp.prototype.renderCurrentView;
  StoreApp.prototype.renderCurrentView = function() {
    if (this.currentView === 'rentals') {
      const container = document.getElementById('view-content-container');
      if (container) {
        container.innerHTML = this.getRentalsHTML();
        if (typeof this.bindRentalsEvents === 'function') {
          this.bindRentalsEvents();
        }
        if (typeof this.updateActiveNavState === 'function') {
          this.updateActiveNavState('rentals');
        }
        return;
      }
    }
    return origRenderCurrentView.apply(this, arguments);
  };

  if (typeof window !== 'undefined' && window.app) {
    window.app.openRentalFleetRestockModal = StoreApp.prototype.openRentalFleetRestockModal;
    window.app.closeRentalFleetRestockModal = StoreApp.prototype.closeRentalFleetRestockModal;
    window.app.updateRentalFleetRestockPreview = StoreApp.prototype.updateRentalFleetRestockPreview;
    window.app.submitRentalFleetRestock = StoreApp.prototype.submitRentalFleetRestock;
    window.app.dispatchRentalBooking = StoreApp.prototype.dispatchRentalBooking;
    window.app.saveRentalDispatch = StoreApp.prototype.saveRentalDispatch;
    window.app.openRentalSettlementModal = StoreApp.prototype.openRentalSettlementModal;
    window.app.closeRentalSettlementModal = StoreApp.prototype.closeRentalSettlementModal;
    window.app.confirmRentalSettlement = StoreApp.prototype.confirmRentalSettlement;
    window.app.printRentalSettlementSlip = StoreApp.prototype.printRentalSettlementSlip;
  }
})();
