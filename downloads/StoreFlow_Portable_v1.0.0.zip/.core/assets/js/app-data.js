class StoreAppData extends StoreAppShell {
  constructor() {
    super();
    this.salesReturns = [];
  }

  async loadInitialData() {
    try {
      const localProfile = await localDB.store_profile.get(1);
      if (localProfile) {
        this.storeProfile = localProfile;
        this.isMultiBranch = (Number(localProfile.is_multi_branch) === 1);
        this.updateStoreBrandUI();
        if (typeof this.applyOperatingModeUI === 'function') {
          this.applyOperatingModeUI(localProfile.operating_mode);
        }
      }

      const cachedProducts = await localDB.products.toArray();
      if (cachedProducts && cachedProducts.length > 0) {
        this.products = cachedProducts;
      }

      const cachedCustomers = await localDB.customers.toArray();
      if (cachedCustomers && cachedCustomers.length > 0) {
        this.customers = cachedCustomers;
      }

      const cachedLogs = await localDB.activity_logs.reverse().sortBy('created_at');
      if (cachedLogs && cachedLogs.length > 0) {
        this.activityLogs = cachedLogs;
      }

      if (localDB.branches) {
        const cachedBranches = await localDB.branches.toArray();
        if (cachedBranches && cachedBranches.length > 0) {
          this.branches = cachedBranches;
        }
      }

      if (localDB.vendors) {
        const cachedVendors = await localDB.vendors.toArray();
        if (cachedVendors && cachedVendors.length > 0) {
          this.vendors = cachedVendors;
        }
      }

      if (localDB.sales_returns) {
        const cachedReturns = await localDB.sales_returns.toArray();
        if (cachedReturns && cachedReturns.length > 0) {
          this.salesReturns = cachedReturns;
        }
      }

      if (localDB.expenses) {
        const cachedExpenses = await localDB.expenses.toArray();
        if (cachedExpenses && cachedExpenses.length > 0) {
          this.expenses = cachedExpenses;
        }
      }
    } catch (err) {
      console.warn('Error reading from IndexedDB:', err);
    }

    if (this.isOnline && this.currentUser && !this.isStandaloneOffline) {
      // First attempt to sync pending offline records before fetching server state
      try {
        if (typeof localDB !== 'undefined' && localDB.sync_outbox) {
          const pendingCount = await localDB.sync_outbox.where('synced').equals(0).count();
          if (pendingCount > 0) {
            await this.syncOutbox();
          }
        }
      } catch (e) {
        console.warn('Initial syncOutbox attempt failed, continuing with merged load:', e);
      }

      await Promise.all([
        this.fetchProfile(),
        this.fetchBranches(),
        this.fetchProducts(),
        this.fetchCustomers(),
        this.fetchInventory(),
        (typeof this.fetchBatches === 'function' ? this.fetchBatches() : Promise.resolve()),
        this.fetchSales(),
        this.fetchReturns(),
        this.fetchExpenses(),
        this.fetchPurchases(),
        this.fetchVendors(),
        this.fetchBackups(),
        this.fetchUsers(),
        this.fetchActivityLogs(),
        this.fetchTransfers(),
        (typeof this.fetchRentals === 'function' && (!this.isRentalsEnabled || this.isRentalsEnabled()) ? this.fetchRentals() : Promise.resolve())
      ]);

      if (typeof this.startCrossDeviceDeltaSync === 'function') {
        this.startCrossDeviceDeltaSync();
        // Immediately trigger initial delta poll to establish SQLite baseline
        setTimeout(() => this.pollCrossDeviceDelta(), 100);
      }
    }
  }

  async fetchBranches() {
    try {
      const res = await this.apiFetch('api/endpoints/branches.php');
      const data = await res.json();
      if (data.success && data.branches) {
        this.branches = data.branches;
        if (localDB.branches) {
          await localDB.branches.clear();
          await localDB.branches.bulkPut(this.branches);
        }
      }
    } catch (err) {
      console.log('Using cached branches');
    }
  }

  async fetchTransfers() {
    try {
      const res = await this.apiFetch('api/endpoints/transfers.php');
      const data = await res.json();
      if (data.success && data.transfers) {
        this.transfers = data.transfers;
        if (localDB.stock_transfers) {
          await localDB.stock_transfers.clear();
          await localDB.stock_transfers.bulkPut(this.transfers);
        }
      }
    } catch (err) {
      if (localDB.stock_transfers) {
        this.transfers = await localDB.stock_transfers.toArray();
      }
    }
  }

  async fetchProfile() {
    try {
      const res = await this.apiFetch('api/endpoints/profile.php');
      const data = await res.json();
      if (data.success && data.profile) {
        this.storeProfile = data.profile;
        this.isMultiBranch = (Number(data.profile.is_multi_branch) === 1);
        await localDB.store_profile.put(this.storeProfile);
        this.updateStoreBrandUI();
        this.updateUserUI();
        if (typeof this.applyOperatingModeUI === 'function') {
          this.applyOperatingModeUI(data.profile.operating_mode);
        }
      }
    } catch (err) {
      console.log('Using offline store profile');
    }
  }

  async fetchProducts() {
    try {
      const res = await this.apiFetch('api/endpoints/products.php');
      const data = await res.json();
      if (data.success && data.products) {
        // Preserve any pending offline products created locally that server does not yet have
        let unsyncedToKeep = [];
        try {
          if (typeof localDB !== 'undefined' && localDB.sync_outbox) {
            const pendingOutbox = await localDB.sync_outbox.where('entity').equals('product').toArray();
            const pendingNew = pendingOutbox.filter(i => i.action === 'CREATE').map(i => i.data);
            const serverIds = new Set(data.products.map(p => p.id));
            unsyncedToKeep = pendingNew.filter(p => p && p.id && !serverIds.has(p.id));
          }
        } catch (e) {}

        this.products = [...data.products, ...unsyncedToKeep];
        this.categories = data.categories || [];
        await localDB.products.clear();
        await localDB.products.bulkPut(this.products);
      }
    } catch (err) {
      console.log('Using cached products');
      this.products = await localDB.products.toArray();
    }
  }

  async fetchCustomers() {
    try {
      const res = await this.apiFetch('api/endpoints/customers.php');
      const data = await res.json();
      if (data.success && data.customers) {
        let unsyncedToKeep = [];
        try {
          if (typeof localDB !== 'undefined' && localDB.sync_outbox) {
            const pendingOutbox = await localDB.sync_outbox.where('entity').equals('customer').toArray();
            const pendingNew = pendingOutbox.filter(i => i.action === 'CREATE').map(i => i.data);
            const serverIds = new Set(data.customers.map(c => c.id));
            unsyncedToKeep = pendingNew.filter(c => c && c.id && !serverIds.has(c.id));
          }
        } catch (e) {}

        this.customers = [...data.customers, ...unsyncedToKeep];
        await localDB.customers.clear();
        await localDB.customers.bulkPut(this.customers);
      }
    } catch (err) {
      this.customers = await localDB.customers.toArray();
    }
  }

  async fetchInventory() {
    try {
      const branchParam = (this.isMultiBranch && this.inventoryBranchFilter) ? `?branch_code=${encodeURIComponent(this.inventoryBranchFilter)}` : '';
      const res = await this.apiFetch(`api/endpoints/inventory.php${branchParam}`);
      const data = await res.json();
      if (data.success && data.inventory) {
        this.inventory = data.inventory;
        this.inventorySummary = data.summary;
      }
    } catch (err) {
      this.inventory = this.products.map(p => ({
        product_id: p.id,
        product_name: p.name,
        sku: p.sku,
        category: p.category,
        unit: p.unit,
        cost_price: p.cost_price,
        selling_price: p.selling_price,
        current_quantity: p.current_quantity || 0,
        min_stock_alert: p.min_stock_alert || 5,
        total_cost_value: (p.current_quantity || 0) * (p.cost_price || 0),
        total_retail_value: (p.current_quantity || 0) * (p.selling_price || 0)
      }));
    }
  }

  async fetchSales() {
    try {
      const res = await this.apiFetch('api/endpoints/sales.php');
      const data = await res.json();
      if (data.success && data.sales) {
        // Preserve any pending offline sales stored locally in IndexedDB
        let unsyncedToKeep = [];
        try {
          if (typeof localDB !== 'undefined' && localDB.sales) {
            const unsyncedSales = await localDB.sales.filter(s => Number(s.synced) === 0).toArray();
            const serverIds = new Set(data.sales.map(s => s.id));
            unsyncedToKeep = unsyncedSales.filter(s => s && s.id && !serverIds.has(s.id));
          }
        } catch (e) {}

        this.sales = [...unsyncedToKeep, ...data.sales];
        this.salesSummary = data.summary;
        if (typeof localDB !== 'undefined' && localDB.sales) {
          try {
            await localDB.sales.clear();
            await localDB.sales.bulkPut(this.sales);
          } catch (e) {}
        }
      }
    } catch (err) {
      this.sales = await localDB.sales.toArray();
    }
  }

  // The analytics boards rank products and categories, and both of those live on a
  // receipt's lines. The list endpoint answers with headers alone unless they are asked
  // for, so a till that had only ever read headers had nothing to rank: the top-products
  // board went blank, the category board went blank, and dead stock flagged every product
  // on the shelf as never sold because no line had ever named it. Ask for the lines of the
  // window being displayed and merge them onto the headers already loaded - merged, not
  // reloaded, because this.sales also carries the receipts this till wrote while the
  // cable was out and a range fetch would drop them.
  async ensureSaleLinesForAnalytics() {
    if (!this.isOnline) return;
    const dates = this.getAnalyticsDates();
    const from = (this.analyticsCompareWithPrior && dates.priorStart < dates.start) ? dates.priorStart : dates.start;
    const to = dates.end;
    // The dead-stock panel asks a thirty-day question whatever the picker is set to, so the
    // lines have to cover that too: loading only "Today" would leave every product not sold
    // today without a single recorded sale inside its own window, and the till would report
    // the shop's whole working capital as dead.
    const thirtyOneDaysAgo = new Date(Date.now() - 31 * 86400000);
    const lineFrom = from < thirtyOneDaysAgo ? from : thirtyOneDaysAgo;
    const dayKey = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    const windowKey = `${dayKey(lineFrom)}_${dayKey(to)}`;
    if (this._saleLinesWindow === windowKey || this._loadingSaleLines) return;
    this._loadingSaleLines = true;
    try {
      const res = await this.apiFetch(`api/endpoints/sales.php?with_items=1&start_date=${dayKey(lineFrom)}&end_date=${dayKey(to)}`);
      const data = await res.json();
      if (!data || !data.success || !Array.isArray(data.sales)) return;
      const linesById = new Map(data.sales.map(s => [String(s.id), Array.isArray(s.items) ? s.items : []]));
      const enriched = [];
      (this.sales || []).forEach(s => {
        const lines = linesById.get(String(s.id));
        if (!lines) return;
        if ((s.items || []).length !== lines.length) {
          s.items = lines;
          enriched.push(s);
        }
      });
      if (enriched.length > 0) {
        if (typeof localDB !== 'undefined' && localDB.sales) {
          try { await localDB.sales.bulkPut(enriched); } catch (e) {}
        }
        this._saleLinesWindow = windowKey;
        if (this.currentView === 'analytics') this.renderCurrentView();
      } else {
        this._saleLinesWindow = windowKey;
      }
    } catch (err) {
      console.warn('Could not load receipt lines for analytics:', err);
    } finally {
      this._loadingSaleLines = false;
    }
  }

  async fetchReturns() {
    try {
      const res = await this.apiFetch('api/endpoints/returns.php?limit=500');
      const data = await res.json();
      if (data.success && data.returns) {
        let unsyncedToKeep = [];
        try {
          if (typeof localDB !== 'undefined' && localDB.sales_returns) {
            const unsyncedReturns = await localDB.sales_returns.filter(r => Number(r.synced) === 0).toArray();
            const serverIds = new Set(data.returns.map(r => r.id));
            unsyncedToKeep = unsyncedReturns.filter(r => r && r.id && !serverIds.has(r.id));
          }
        } catch (e) {}
        this.salesReturns = [...unsyncedToKeep, ...data.returns];
        if (typeof localDB !== 'undefined' && localDB.sales_returns) {
          try {
            await localDB.sales_returns.clear();
            await localDB.sales_returns.bulkPut(this.salesReturns);
          } catch (e) {}
        }
      }
    } catch (err) {
      if (typeof localDB !== 'undefined' && localDB.sales_returns) {
        try {
          this.salesReturns = await localDB.sales_returns.toArray();
        } catch (e) {}
      }
    }
  }

  async fetchExpenses(filters = {}) {
    try {
      const q = new URLSearchParams(filters).toString();
      const url = `api/endpoints/expenses.php${q ? '?' + q : ''}`;
      const res = await this.apiFetch(url);
      const data = await res.json();
      if (data.success && data.expenses) {
        this.expenses = data.expenses;
        this.expensesSummary = data.summary || null;
        if (typeof localDB !== 'undefined' && localDB.expenses) {
          try {
            await localDB.expenses.clear();
            await localDB.expenses.bulkPut(this.expenses);
          } catch (e) { }
        }
      }
    } catch (e) {
      if (typeof localDB !== 'undefined' && localDB.expenses) {
        try {
          this.expenses = await localDB.expenses.toArray();
        } catch (dbErr) { }
      }
    }
  }

  async recordExpense(expenseData) {
    if (!expenseData.title || !expenseData.title.trim()) {
      this.showToast('Please provide an expense title or purpose', 'warning');
      return false;
    }
    const amt = Number(expenseData.amount || 0);
    if (amt <= 0) {
      this.showToast('Expense amount must be greater than zero', 'warning');
      return false;
    }

    const id = expenseData.id || ('exp_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7));
    const now = new Date();
    const dateStr = expenseData.expense_date || now.toISOString().slice(0, 10);
    const expNum = expenseData.expense_number || ('EXP-' + dateStr.replace(/-/g, '') + '-' + Math.floor(1000 + Math.random() * 9000));

    const newExpense = {
      id,
      expense_number: expNum,
      title: expenseData.title.trim(),
      category: expenseData.category || 'General',
      amount: amt,
      payment_source: (expenseData.payment_source || 'CASH_DRAWER').toUpperCase(),
      paid_to: (expenseData.paid_to || '').trim(),
      receipt_ref: (expenseData.receipt_ref || '').trim(),
      notes: (expenseData.notes || '').trim(),
      branch_code: expenseData.branch_code || this.branchCode || 'MAIN-01',
      terminal_id: expenseData.terminal_id || this.terminalId || 'REG-01',
      shift_id: expenseData.shift_id || null,
      user_id: this.currentUser?.id || 1,
      recorded_by: this.currentUser?.full_name || this.currentUser?.username || 'Staff',
      expense_date: dateStr,
      created_at: now.toISOString().slice(0, 19).replace('T', ' '),
      synced: this.isOnline ? 1 : 0
    };

    if (this.isOnline && this.currentUser && !this.isStandaloneOffline) {
      try {
        const res = await this.apiFetch('api/endpoints/expenses.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(newExpense)
        });
        const result = await res.json();
        if (!result.success) {
          throw new Error(result.message || 'Server rejected expense');
        }
        if (result.expense) {
          Object.assign(newExpense, result.expense);
        }
        newExpense.synced = 1;
        if (typeof this.logClientActivity === 'function') {
          await this.logClientActivity(
            'RECORD_EXPENSE',
            `Recorded expense '${newExpense.title}' for ${this.formatCurrency(newExpense.amount)} (${newExpense.category}, Source: ${newExpense.payment_source}).`,
            false
          );
        }
      } catch (err) {
        console.warn('Online expense creation failed, queueing offline:', err);
        newExpense.synced = 0;
        if (typeof this.logClientActivity === 'function') {
          await this.logClientActivity(
            'RECORD_EXPENSE',
            `Recorded offline expense '${newExpense.title}' for ${this.formatCurrency(newExpense.amount)} (${newExpense.category}, Source: ${newExpense.payment_source}).`,
            true
          );
        }
        if (typeof localDB !== 'undefined' && localDB.sync_outbox) {
          try {
            await localDB.sync_outbox.add({
              entity: 'expense',
              action: 'CREATE',
              data: newExpense,
              timestamp: new Date().toISOString(),
              synced: 0
            });
          } catch (syncErr) {
            console.error('Failed to queue expense in sync_outbox:', syncErr);
          }
        }
      }
    } else {
      newExpense.synced = 0;
      if (typeof localDB !== 'undefined' && localDB.sync_outbox) {
        try {
          await localDB.sync_outbox.add({
            entity: 'expense',
            action: 'CREATE',
            data: newExpense,
            timestamp: new Date().toISOString(),
            synced: 0
          });
        } catch (syncErr) {
          console.error('Failed to queue expense in sync_outbox:', syncErr);
        }
      }
    }

    // Save locally
    if (typeof localDB !== 'undefined' && localDB.expenses) {
      try {
        await localDB.expenses.put(newExpense);
      } catch (e) {
        console.warn('Failed to save expense locally in localDB:', e);
      }
    }

    this.expenses = [newExpense, ...(this.expenses || []).filter(e => e.id !== newExpense.id)];
    if (typeof this.broadcastSyncEvent === 'function') {
      this.broadcastSyncEvent('EXPENSE_MUTATED', { action: 'UPSERT', expense: newExpense });
    }
    this.showToast(`Recorded expense: ${newExpense.title} (${this.formatCurrency(newExpense.amount)})`, 'success');
    return newExpense;
  }

  async deleteExpense(id) {
    if (!id) return false;
    let serverDeleted = false;
    if (this.isOnline && this.currentUser && !this.isStandaloneOffline) {
      try {
        const res = await this.apiFetch(`api/endpoints/expenses.php?id=${encodeURIComponent(id)}`, {
          method: 'DELETE'
        });
        const result = await res.json();
        if (result.success) {
          serverDeleted = true;
        } else {
          this.showToast(result.message || 'Could not delete expense', 'danger');
        }
      } catch (err) {
        console.warn('Online expense delete failed, queueing offline:', err);
      }
    }

    if (!serverDeleted && typeof localDB !== 'undefined' && localDB.sync_outbox) {
      try {
        await localDB.sync_outbox.add({
          entity: 'expense',
          action: 'DELETE',
          data: { id },
          timestamp: new Date().toISOString(),
          synced: 0
        });
      } catch (syncErr) {}
    }

    if (typeof this.logClientActivity === 'function') {
      await this.logClientActivity(
        'DELETE_EXPENSE',
        `Deleted expense #${id}.`,
        !serverDeleted
      );
    }

    if (typeof localDB !== 'undefined' && localDB.expenses) {
      try { await localDB.expenses.delete(id); } catch (e) { }
    }
    this.expenses = (this.expenses || []).filter(e => e.id !== id);
    if (typeof this.broadcastSyncEvent === 'function') {
      this.broadcastSyncEvent('EXPENSE_MUTATED', { action: 'DELETE', id });
    }
    this.showToast('Expense record deleted', 'info');
    return true;
  }

  async fetchPurchases() {
    try {
      const res = await this.apiFetch('api/endpoints/purchases.php');
      const data = await res.json();
      if (data.success && data.purchases) {
        this.purchases = data.purchases;
        // What came in, over the whole ledger rather than the rows on screen: the dashboard
        // and the analytics boards ask how much the shop put into stock, and the list above
        // is only what this till happens to have loaded.
        this.purchasesSummary = data.summary || null;
      }
    } catch (err) {
      this.purchases = await localDB.purchases.toArray();
    }
  }

  async fetchVendors() {
    try {
      const res = await this.apiFetch('api/endpoints/vendors.php');
      const data = await res.json();
      if (data.success && data.vendors) {
        this.vendors = data.vendors;
        if (localDB.vendors) {
          await localDB.vendors.clear();
          await localDB.vendors.bulkPut(this.vendors);
        }
      }
    } catch (err) {
      if (localDB.vendors) {
        this.vendors = await localDB.vendors.toArray();
      }
    }
  }

  async fetchBackups() {
    if (window.StoreFlowAndroid && typeof window.StoreFlowAndroid.listDocumentBackups === 'function') {
      try {
        const jsonStr = window.StoreFlowAndroid.listDocumentBackups();
        if (jsonStr) {
          const files = JSON.parse(jsonStr);
          this.backups = files.map(f => ({
            filename: f.filename,
            size: f.size,
            size_formatted: (f.size / 1024).toFixed(1) + ' KB',
            created_at: new Date(f.modified).toISOString().replace('T', ' ').substring(0, 19),
            filepath: f.filepath
          }));
          if (this.backups.length > 0) {
            this.lastBackup = this.backups[0].created_at;
          }
          return;
        }
      } catch (e) {
        console.warn('Error reading Android document backups:', e);
      }
    }
    try {
      const res = await this.apiFetch('api/endpoints/backups.php');
      const data = await res.json();
      if (data.success && data.backups) {
        this.backups = data.backups;
        this.lastBackup = data.last_backup;
      }
    } catch (err) {
      console.log('Backups info unavailable offline');
    }
  }

  async fetchUsers() {
    try {
      const [uRes, rRes] = await Promise.all([
        this.apiFetch('api/endpoints/users.php'),
        this.apiFetch('api/endpoints/roles.php')
      ]);
      const uData = await uRes.json();
      const rData = await rRes.json();
      if (uData.success) this.users = uData.users;
      if (rData.success) {
        this.roles = rData.roles;
        // The Access Map's columns are named from the server's own catalogue rather than a
        // list kept in this file, so a right added in api/config/db.php appears here the
        // moment it exists there. Both travel only to a session the server let see the whole
        // map, so the pair says "this is every role" rather than "this is one role".
        this.permissionCatalogue = rData.catalogue || null;
        this.canManageRoles = !!rData.can_manage;
      }
    } catch (err) {
      console.log('Users info unavailable offline');
    }
  }

  /* ==========================================================================
     Book identity: which set of the shop's records this queue belongs to
     ========================================================================== */

  // The name of the book is kept in IndexedDB, beside the queue it guards, rather than in
  // localStorage: the two are cleared separately, and a till that lost only the name would
  // walk in looking like a new counter and be handed the book to replay into.
  async getBookEpoch() {
    try {
      const row = await localDB.book_meta.get('epoch');
      return (row && row.value) || '';
    } catch (e) {
      return '';
    }
  }

  async setBookEpoch(value) {
    const epoch = String(value || '');
    if (!epoch) return;
    try {
      await localDB.book_meta.put({ key: 'epoch', value: epoch });
    } catch (e) {}
  }

  // A refused batch is not repaired by retrying it. The till holds every record, says so to
  // the owner, and stops the 45-second loop: left alone, that loop would re-push a stale day
  // forever, and an owner who dismissed the warning would come back to find the old book
  // merged into the new one anyway.
  async enterBookHold(info) {
    const serverEpoch = String((info && info.server_book_epoch) || '');
    const records = Number((info && info.held_records) || 0);
    const isNew = !this._bookHold || this._bookHold.serverEpoch !== serverEpoch;

    this._bookHold = {
      serverEpoch,
      records,
      terminal: this.terminalId || '',
      since: (this._bookHold && this._bookHold.since) || new Date().toISOString()
    };
    try {
      await localDB.book_meta.put({ key: 'hold', value: JSON.stringify(this._bookHold) });
    } catch (e) {}

    // The delta poll runs every few seconds, so the shop's log gets one entry per stand-off,
    // not one per heartbeat.
    if (isNew) {
      await this.logClientActivity(
        'BOOK_MISMATCH',
        `${this._bookHold.records} queued record(s) on till ${this.terminalId || 'this device'} belong to a book `
        + 'this shop no longer uses. Nothing was saved to the server and the till is not retrying them. '
        + 'The owner has to choose to load them into this book or discard them.',
        true
      );
    }
    this.renderBookMismatchBanner(this._bookHold);
    this.updateNetworkStatusUI();
  }

  async clearBookHold() {
    this._bookHold = null;
    try {
      await localDB.book_meta.delete('hold');
    } catch (e) {}
    this.renderBookMismatchBanner(null);
  }

  // The stand-off outlives a reload: an owner who closes the phone and comes back the next
  // morning must find the same warning, not a till that quietly started retrying.
  async restoreBookHoldState() {
    try {
      const row = await localDB.book_meta.get('hold');
      if (row && row.value) {
        this._bookHold = JSON.parse(row.value);
        this.renderBookMismatchBanner(this._bookHold);
      }
    } catch (e) {}
  }

  // A till with nothing waiting follows the shop onto the new book by itself - that is the
  // ordinary case after a reset, and making every counter wait for a manager would only teach
  // staff to ignore the warning. A till with records held is a different thing entirely: those
  // records were taken against a book that no longer exists, and moving them is a decision
  // about the shop's money, so it belongs to the owner.
  async checkBookEpoch(incomingEpoch) {
    const serverEpoch = String(incomingEpoch || '');
    if (!serverEpoch) return;
    const mine = await this.getBookEpoch();
    if (!mine) {
      await this.setBookEpoch(serverEpoch);
      return;
    }
    if (mine === serverEpoch) {
      if (this._bookHold) await this.clearBookHold();
      return;
    }
    let pending = 0;
    try {
      pending = await localDB.sync_outbox.where('synced').equals(0).count();
    } catch (e) {}
    if (pending > 0) {
      await this.enterBookHold({ server_book_epoch: serverEpoch, held_records: pending });
      return;
    }
    await this.purgeLocalTradeBookCache();
    await this.setBookEpoch(serverEpoch);
    if (this._bookHold) await this.clearBookHold();
  }

  async purgeLocalTradeBookCache() {
    const tradeStores = [
      'products', 'inventory', 'branch_inventory', 'product_batches',
      'purchases', 'sales', 'sales_returns', 'customers', 'customer_payments',
      'register_shifts', 'vendors', 'vendor_payments', 'stock_transfers',
      'expenses', 'estimates'
    ];
    if (typeof localDB !== 'undefined') {
      for (const storeName of tradeStores) {
        if (localDB[storeName] && typeof localDB[storeName].clear === 'function') {
          try { await localDB[storeName].clear(); } catch (e) {}
        }
      }
      if (localDB.sync_outbox) {
        try { await localDB.sync_outbox.where('synced').equals(1).delete(); } catch (e) {}
      }
    }
    try {
      localStorage.removeItem('sf_held_orders');
      localStorage.removeItem('storeflow_active_cart');
    } catch (e) {}
    this.cart = [];
    this.products = [];
    this.inventory = [];
    this.batches = [];
    this.purchases = [];
    this.vendors = [];
    this.sales = [];
    this.salesReturns = [];
    this.expenses = [];
    this.currentEstimates = [];
    this.rentals = [];
    this.transfers = [];
  }

  // The owner's two answers. Both are written into the shop's log, because a day of takings
  // either arriving in a book or being destroyed on a till is a fact the books have to carry.
  async loadStaleQueueIntoThisBook() {
    if (!this._bookHold) return;
    const held = this._bookHold;
    await this.setBookEpoch(held.serverEpoch);
    await this.clearBookHold();
    await this.logClientActivity(
      'BOOK_LOADED',
      `The owner chose to load ${held.records || 'the'} queued record(s) held on till ${held.terminal || this.terminalId || 'this device'} `
      + 'into the book this shop uses now. Check the shelf and the takings for anything that was already recorded twice.',
      true
    );
    this.showToast('Loading those records into this book...', 'info');
    await this.syncOutbox();
  }

  async discardStaleQueue() {
    if (!this._bookHold) return;
    const held = this._bookHold;
    let dropped = 0;
    try {
      dropped = await localDB.sync_outbox.where('synced').equals(0).delete();
    } catch (e) {}
    await this.setBookEpoch(held.serverEpoch);
    await this.clearBookHold();
    await this.logClientActivity(
      'BOOK_DISCARDED',
      `The owner discarded ${dropped} queued record(s) held on till ${held.terminal || this.terminalId || 'this device'}, `
      + 'which belonged to a book this shop no longer uses. Their own receipts stay on this device as history.',
      true
    );
    this.showToast('Those records will no longer be sent. They stay on this till as history.', 'warning', 11000);
    this.updateNetworkStatusUI();
  }

  async syncOutbox() {
    if (this._isSyncing) return;
    this._isSyncing = true;
    this._setSyncButtonLoading(true);

    try {
      const pendingItems = await localDB.sync_outbox.where('synced').equals(0).toArray();

      if (pendingItems.length === 0) {
        this._syncFailed = false;
        this.showToast('All local data is already up-to-date with server.', 'info');
        return;
      }

      const salesPayload = [];
      const purchasesPayload = [];
      const purchaseMovementsPayload = [];
      const productsPayload = [];
      const customersPayload = [];
      const paymentsPayload = [];
      const shiftsPayload = [];
      const logsPayload = [];
      const returnsPayload = [];
      const expensesPayload = [];
      const vendorsPayload = [];
      const vendorPaymentsPayload = [];
      const transfersPayload = [];
      const deletedProducts = [];
      const deletedCustomers = [];
      const deletedExpenses = [];
      const deletedVendors = [];

      pendingItems.forEach(item => {
        if (item.action === 'DELETE') {
          if (item.entity === 'product') deletedProducts.push(item.data?.id || item.data);
          if (item.entity === 'customer') deletedCustomers.push(item.data?.id || item.data);
          if (item.entity === 'expense') deletedExpenses.push(item.data?.id || item.data);
          if (item.entity === 'vendor') deletedVendors.push(item.data?.id || item.data);
        } else {
          if (item.entity === 'sale') salesPayload.push(item.data);
          if (item.entity === 'purchase') purchasesPayload.push(item.data);
          if (item.entity === 'purchase_movement') purchaseMovementsPayload.push(item.data);
          if (item.entity === 'product') productsPayload.push(item.data);
          if (item.entity === 'customer') customersPayload.push(item.data);
          if (item.entity === 'customer_payment' || item.entity === 'payment') paymentsPayload.push(item.data);
          if (item.entity === 'shift') shiftsPayload.push(item.data);
          if (item.entity === 'activity_log') logsPayload.push(item.data);
          if (item.entity === 'sales_return') returnsPayload.push(item.data);
          if (item.entity === 'expense') expensesPayload.push(item.data);
          if (item.entity === 'vendor') vendorsPayload.push(item.data);
          if (item.entity === 'vendor_payment') vendorPaymentsPayload.push(item.data);
          if (item.entity === 'transfer') transfersPayload.push(item.data);
        }
      });

      // Which book these records were taken against. The server files every one of them under
      // the id this device chose, so without the name it cannot tell a current till from one
      // holding a day the shop has already replaced - and a receipt names its own goods, so
      // the products the shop deleted would come back with it.
      const bookEpoch = await this.getBookEpoch();
      const res = await this.apiFetch('api/endpoints/sync.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sync_id: 'sync_' + Date.now(),
          user_id: this.currentUser?.id || 1,
          terminal_id: this.terminalId || '',
          book_epoch: bookEpoch,
          sales: salesPayload,
          purchases: purchasesPayload,
          purchase_movements: purchaseMovementsPayload,
          products: productsPayload,
          customers: customersPayload,
          payments: paymentsPayload,
          shifts: shiftsPayload,
          activity_logs: logsPayload,
          returns: returnsPayload,
          expenses: expensesPayload,
          vendors: vendorsPayload,
          vendor_payments: vendorPaymentsPayload,
          transfers: transfersPayload,
          deleted_product_ids: deletedProducts,
          deleted_customer_ids: deletedCustomers,
          deleted_expense_ids: deletedExpenses,
          deleted_vendor_ids: deletedVendors
        })
      });

      const result = await res.json();

      // The whole batch is refused, so nothing in it is consumed and nothing in it is fetched
      // back over the till's own copy. The queue stays exactly as it was and the owner is
      // asked; retrying cannot change whose book these records belong to.
      if (result && result.code === 'book_mismatch') {
        await this.enterBookHold(result);
        return;
      }

      if (result.success) {
        // A till that has never been handed a name takes the one the book it just wrote into
        // gave back. This is the one-time hand-off, and it is also every existing till's first
        // sync after this shipped.
        if (result.book_epoch && !bookEpoch) {
          await this.setBookEpoch(result.book_epoch);
        }
        this._syncFailed = false;

        // An outbox row is only consumed once the server confirms it took that record.
        // Dropping the whole batch used to discard rows the server skipped on validation
        // or permission grounds; the local copy stayed unsynced with nothing left to retry,
        // so the change was silently lost. Deletions are consumed either way: the server
        // either applied them or refused them by policy, and retrying cannot change that.
        const processedLists = Object.values(result.processed || {});
        const processedIds = new Set([].concat(...processedLists.map(list => (Array.isArray(list) ? list : []))));
        const rejectedLists = Object.values(result.rejected || {});
        const rejectedIds = new Set([].concat(...rejectedLists.map(list => (Array.isArray(list) ? list : []))));
        const processedKeyByEntity = {
          sale: 'sales',
          purchase: 'purchases',
          purchase_movement: 'purchase_movements',
          product: 'products',
          customer: 'customers',
          customer_payment: 'payments',
          payment: 'payments',
          shift: 'shifts',
          sales_return: 'returns',
          expense: 'expenses',
          vendor: 'vendors',
          vendor_payment: 'vendor_payments',
          transfer: 'transfers'
        };
        const rowId = item => (item.data && item.data.id !== undefined && item.data.id !== null) ? item.data.id : item.data;
        const neverDispatched = [];
        const consumedIds = pendingItems.filter(item => {
          // A row the server rolled back is not synced. Deleting it here is how a receipt
          // disappears from the till as well as from the shop's books.
          if (rejectedIds.has(rowId(item))) return false;
          if (item.action === 'DELETE' || item.entity === 'activity_log') return true;
          const bucket = processedKeyByEntity[item.entity];
          // An entity with no bucket was never put in the sync body at all. Returning true
          // here used to consume it anyway, which is how a queued supplier payout or a
          // dispatched waybill left the till with a green "synced" and reached no book.
          if (!bucket) {
            neverDispatched.push(item.entity);
            return false;
          }
          return processedIds.has(rowId(item));
        }).map(item => item.id);
        if (neverDispatched.length > 0) {
          const kinds = [...new Set(neverDispatched)].join(', ');
          this.logClientActivity?.('SYNC_UNSUPPORTED',
            `${neverDispatched.length} queued record(s) of type [${kinds}] are not sent by this till and remain on it.`,
            !this.isOnline);
          this.showToast(`${neverDispatched.length} queued record(s) (${kinds}) cannot be sent by this version of the till. They are still on this device - do not clear its data.`, 'danger', 14000);
        }
        if (consumedIds.length > 0) {
          await localDB.sync_outbox.where('id').anyOf(consumedIds).delete();
        }

        // A rejected row stays queued and retries. The common cause is ordering - a credit
        // note that reaches the server before the receipt it refunds - and the next pass
        // succeeds once the receipt lands. Telling the shopkeeper is what makes a stuck
        // queue visible instead of looking like a sync that worked.
        if (rejectedIds.size > 0) {
          this.logClientActivity?.(
            'SYNC_REJECTED',
            `${rejectedIds.size} queued record(s) were refused by the server and remain on this till: `
              + [...rejectedIds].slice(0, 12).join(', '),
            !this.isOnline
          );
          this.showToast(`${rejectedIds.size} queued sale(s)/record(s) could not be saved and will be retried. They are still on this till.`, 'warning', 9000);
        }

        // Mark synced sales in localDB.sales
        if (result.processed && result.processed.sales && result.processed.sales.length > 0) {
          for (const sId of result.processed.sales) {
            try {
              const localSale = await localDB.sales.get(sId);
              if (localSale) {
                localSale.synced = 1;
                await localDB.sales.put(localSale);
              }
            } catch (e) {}
          }
        }

        // Mark synced expenses in localDB.expenses
        if (result.processed && result.processed.expenses && result.processed.expenses.length > 0) {
          for (const expId of result.processed.expenses) {
            try {
              if (localDB.expenses) {
                const localExp = await localDB.expenses.get(expId);
                if (localExp) {
                  localExp.synced = 1;
                  await localDB.expenses.put(localExp);
                }
              }
              const inMemExp = (this.expenses || []).find(e => e.id === expId);
              if (inMemExp) inMemExp.synced = 1;
            } catch (e) {}
          }
        }

        if (result.server_state) {
          if (result.server_state.products) {
            this.products = result.server_state.products;
            await localDB.products.clear();
            await localDB.products.bulkPut(this.products);
          }
          if (result.server_state.customers) {
            this.customers = result.server_state.customers;
            await localDB.customers.clear();
            await localDB.customers.bulkPut(this.customers);
          }
          if (result.server_state.profile) {
            this.storeProfile = result.server_state.profile;
            await localDB.store_profile.put(this.storeProfile);
            this.updateStoreBrandUI();
          }
          if (result.server_state.branches) {
            this.branches = result.server_state.branches;
            if (localDB.branches) {
              await localDB.branches.clear();
              await localDB.branches.bulkPut(this.branches);
            }
          }
        }

        // Refresh sales ledger, returns, and expenses
        await this.fetchSales();
        await this.fetchReturns();
        await this.fetchExpenses();

        this.showToast(`Sync complete! ${pendingItems.length} offline records updated to server.`, 'success');
        this.renderCurrentView();
        if (typeof this.broadcastSyncEvent === 'function') {
          this.broadcastSyncEvent('SYNC_COMPLETED', { count: pendingItems.length });
        }
      } else {
        this._syncFailed = true;
        this.showToast(`Sync warning: ${result.message}`, 'danger');
      }
    } catch (err) {
      console.warn('Sync failed:', err);
      this._syncFailed = true;
      this.showToast('Unable to reach server. Changes remain safely stored offline. Tap "Retry Sync" to try again.', 'warning');
    } finally {
      this._isSyncing = false;
      this._setSyncButtonLoading(false);
      this.updateNetworkStatusUI();
    }
  }

  _setSyncButtonLoading(isLoading) {
    const syncBtn = document.getElementById('btn-manual-sync');
    const topbarSyncBtn = document.getElementById('btn-topbar-sync');
    const topbarIcon = document.getElementById('topbar-sync-icon');
    const topbarLabel = document.getElementById('topbar-sync-label');

    if (isLoading) {
      if (syncBtn) {
        syncBtn.disabled = true;
        syncBtn.innerHTML = '<i class="fa-solid fa-arrows-rotate fa-spin"></i> <span>Syncing...</span>';
      }
      if (topbarSyncBtn) {
        topbarSyncBtn.disabled = true;
        if (topbarIcon) topbarIcon.className = 'fa-solid fa-arrows-rotate fa-spin';
        if (topbarLabel) topbarLabel.innerText = 'Syncing...';
      }
    } else {
      if (syncBtn) syncBtn.disabled = false;
      if (topbarSyncBtn) topbarSyncBtn.disabled = false;
    }
  }

  /* ==========================================================================
     Cross-Device Live Delta Polling (5-Second Heartbeat)
     ========================================================================== */
  startCrossDeviceDeltaSync() {
    if (this._deltaPollTimer) return;
    this._deltaPollTimer = setInterval(() => {
      this.pollCrossDeviceDelta();
    }, 2500); // 2.5-second brisk polling for snappy multi-terminal awareness

    if (typeof document !== 'undefined' && !this._visibilitySyncBound) {
      this._visibilitySyncBound = true;
      document.addEventListener('visibilitychange', () => {
        if (!document.hidden) {
          this.pollCrossDeviceDelta();
        }
      });
      window.addEventListener('focus', () => {
        this.pollCrossDeviceDelta();
      });
    }
  }

  stopCrossDeviceDeltaSync() {
    if (this._deltaPollTimer) {
      clearInterval(this._deltaPollTimer);
      this._deltaPollTimer = null;
    }
  }

  async pollCrossDeviceDelta() {
    if (!this.isOnline || !this.currentUser || this.isScreenLocked || this._isDeltaPolling || this._isSyncing) {
      return;
    }
    this._isDeltaPolling = true;

    try {
      const since = this._lastDeltaSyncTimestamp || '';
      const branch = this.branchCode || 'MAIN-01';
      const url = `api/endpoints/sync.php?action=delta&since=${encodeURIComponent(since)}&branch_code=${encodeURIComponent(branch)}`;

      const res = await this.apiFetch(url);
      if (res.status === 200) {
        const data = await res.json();
        if (data && data.success) {
          // A till with nothing queued never calls the sync endpoint, so this heartbeat is the
          // only place it can find out that the shop's book underneath it has been replaced.
          if (data.book_epoch) await this.checkBookEpoch(data.book_epoch);
          if (!this._lastDeltaSyncTimestamp) {
            this._lastDeltaSyncTimestamp = data.server_time;
          } else if (data.has_changes && data.changes) {
            await this.applyDeltaChanges(data.changes, data.server_time);
          } else if (data.server_time) {
            this._lastDeltaSyncTimestamp = data.server_time;
          }
        }
      }
    } catch (err) {
      // Fail silently on network drops — offline first
    } finally {
      this._isDeltaPolling = false;
    }
  }

  async applyDeltaChanges(changes, serverTime) {
    if (!changes) return;
    let didChangeInventory = false;
    let didChangeSales = false;
    let didChangeExpenses = false;
    let didChangeCustomers = false;

    // 1. Products
    if (Array.isArray(changes.products) && changes.products.length > 0) {
      for (const p of changes.products) {
        const idx = (this.products || []).findIndex(item => item.id === p.id);
        if (idx >= 0) {
          this.products[idx] = { ...this.products[idx], ...p };
        } else {
          this.products.unshift(p);
        }
        if (typeof localDB !== 'undefined' && localDB.products) {
          // Merged, not replaced. This record carries a handful of columns, and putting it
          // over the cached row threw away everything it did not mention - the image, the
          // branch settings, and the sizes the till needs to ring a crate as a crate.
          const cachedProduct = await localDB.products.get(p.id);
          await localDB.products.put(cachedProduct ? { ...cachedProduct, ...p } : p);
        }
      }
      didChangeInventory = true;
    }

    // 2. Branch Inventory / Stock Levels
    if (Array.isArray(changes.inventory) && changes.inventory.length > 0) {
      const activeBranch = (this.branchCode || 'MAIN-01').toUpperCase();
      for (const inv of changes.inventory) {
        const prod = (this.products || []).find(p => p.id === inv.product_id);
        if (prod) {
          const newQty = Number(inv.current_quantity || 0);
          prod.current_quantity = newQty;
          if (inv.custom_selling_price !== null && inv.custom_selling_price !== undefined) {
            prod.branch_selling_price = Number(inv.custom_selling_price);
          }

          // Keep branch_settings aligned so getEffectiveProductForBranch picks up the new stock
          if (Array.isArray(prod.branch_settings)) {
            const bSetting = prod.branch_settings.find(bs => (bs.branch_code || '').toUpperCase() === activeBranch);
            if (bSetting) {
              bSetting.current_quantity = newQty;
              if (inv.custom_selling_price !== null && inv.custom_selling_price !== undefined) {
                bSetting.custom_selling_price = Number(inv.custom_selling_price);
              }
            } else {
              prod.branch_settings.push({
                branch_code: activeBranch,
                current_quantity: newQty,
                custom_selling_price: inv.custom_selling_price !== null && inv.custom_selling_price !== undefined ? Number(inv.custom_selling_price) : null
              });
            }
          }
        }
        if (typeof localDB !== 'undefined' && localDB.inventory) {
          await localDB.inventory.put({
            product_id: inv.product_id,
            current_quantity: Number(inv.current_quantity || 0),
            updated_at: inv.updated_at
          });
        }
      }
      didChangeInventory = true;
    }

    // 3. Sales
    if (Array.isArray(changes.sales) && changes.sales.length > 0) {
      for (const sale of changes.sales) {
        const exists = (this.sales || []).some(s => s.id === sale.id);
        if (!exists) {
          this.sales.unshift(sale);
          if (typeof localDB !== 'undefined' && localDB.sales) {
            await localDB.sales.put(sale);
          }
          didChangeSales = true;
        }
      }
    }

    // 4. Customers
    if (Array.isArray(changes.customers) && changes.customers.length > 0) {
      for (const cust of changes.customers) {
        const idx = (this.customers || []).findIndex(c => c.id === cust.id);
        if (idx >= 0) {
          this.customers[idx] = { ...this.customers[idx], ...cust };
        } else {
          this.customers.push(cust);
        }
        if (typeof localDB !== 'undefined' && localDB.customers) {
          await localDB.customers.put(cust);
        }
      }
      didChangeCustomers = true;
    }

    // 5. Expenses
    if (Array.isArray(changes.expenses) && changes.expenses.length > 0) {
      for (const exp of changes.expenses) {
        const exists = (this.expenses || []).some(e => e.id === exp.id);
        if (!exists) {
          this.expenses.unshift(exp);
          if (typeof localDB !== 'undefined' && localDB.expenses) {
            await localDB.expenses.put(exp);
          }
          didChangeExpenses = true;
        }
      }
      didChangeExpenses = true;
    }

    // Advance baseline timestamp
    if (serverTime) {
      this._lastDeltaSyncTimestamp = serverTime;
    }

    // Safe, non-interruptive UI view refreshing:
    if (didChangeInventory || didChangeSales) {
      if (typeof this._safePosProductStockRefresh === 'function') {
        this._safePosProductStockRefresh();
      }
      if (['products', 'inventory', 'batches'].includes(this.currentView)) {
        if (typeof this._safeViewRefresh === 'function') {
          this._safeViewRefresh(this.currentView);
        }
      }
    }
    if (didChangeSales) {
      if (typeof this.showToast === 'function') {
        this.showToast('Remote sale synced. Stock & sales updated.', 'info');
      }
      if (this.syncChannel) {
        try {
          this.syncChannel.postMessage({ type: 'SALE_RECORDED', payload: { sales: changes.sales } });
        } catch (e) {}
      }
      if (['sales', 'dashboard'].includes(this.currentView)) {
        if (typeof this._safeViewRefresh === 'function') {
          this._safeViewRefresh(this.currentView);
        }
      }
    }
    if (didChangeExpenses && ['expenses', 'dashboard'].includes(this.currentView)) {
      if (typeof this._safeViewRefresh === 'function') {
        this._safeViewRefresh(this.currentView);
      }
    }
    if (didChangeCustomers && ['customers', 'pos'].includes(this.currentView)) {
      if (typeof this._safeViewRefresh === 'function') {
        this._safeViewRefresh(this.currentView);
      }
    }
  }
}

if (typeof window !== 'undefined') {
  window.StoreAppData = StoreAppData;
}
