// assets/js/app-dashboard.js - StoreFlow Dashboard Overview Controller

Object.assign(StoreApp.prototype, {
  getFilteredDashboardData() {
    const branch = this.dashFilterBranch || 'ALL';
    const period = this.dashFilterPeriod || 'all';
    const dateVal = this.dashFilterDate || new Date().toISOString().slice(0, 10);
    const monthVal = this.dashFilterMonth || new Date().toISOString().slice(0, 7);
    const yearVal = this.dashFilterYear || new Date().getFullYear().toString();
    const todayStr = new Date().toISOString().slice(0, 10);

    // 1. Filter Sales
    const filteredSales = (this.sales || []).filter(s => {
      if (branch !== 'ALL' && (s.branch_code || 'MAIN-01').toUpperCase() !== branch.toUpperCase()) {
        return false;
      }
      const sDate = (s.sale_date || s.created_at || '').slice(0, 10);
      if (period === 'today') return sDate === todayStr;
      if (period === 'day') return sDate === dateVal;
      if (period === 'month') return sDate.startsWith(monthVal);
      if (period === 'year') return sDate.startsWith(yearVal);
      return true;
    });

    // 2. Filter Returns
    const filteredReturns = (this.salesReturns || []).filter(r => {
      if (branch !== 'ALL' && (r.branch_code || 'MAIN-01').toUpperCase() !== branch.toUpperCase()) {
        return false;
      }
      const rDate = (r.return_date || r.created_at || '').slice(0, 10);
      if (period === 'today') return rDate === todayStr;
      if (period === 'day') return rDate === dateVal;
      if (period === 'month') return rDate.startsWith(monthVal);
      if (period === 'year') return rDate.startsWith(yearVal);
      return true;
    });

    // 3. Filter Products & Inventory
    const filteredProducts = (this.products || []).map(p => {
      let qty = Number(p.current_quantity || 0);
      if (branch !== 'ALL' && p.branch_settings && Array.isArray(p.branch_settings)) {
        const bs = p.branch_settings.find(b => (b.branch_code || '').toUpperCase() === branch.toUpperCase());
        if (bs) {
          qty = Number(bs.current_quantity || 0);
        }
      }
      return { ...p, effective_quantity: qty };
    });

    // 4. Calculate Aggregate Metrics
    // A voided receipt is not in any of these sums. The money was handed back and the goods went
    // back on the shelf, so ringed totals only count here when the receipt is still live. They are
    // reported beside the revenue rather than hidden, so a shopkeeper who counted slips in the
    // drawer can reconcile the two.
    const voidedSales = filteredSales.filter(s => this.isVoidedSale(s));
    const billableSales = filteredSales.filter(s => !this.isVoidedSale(s));
    const voidedValue = voidedSales.reduce((sum, s) => sum + Number(s.total_amount || 0), 0);

    const grossRevenue = billableSales.reduce((sum, s) => sum + Number(s.total_amount || 0), 0);
    const totalRefunded = filteredReturns.reduce((sum, r) => sum + Number(r.total_refund_amount || 0), 0);
    const netRevenue = Math.max(0, grossRevenue - totalRefunded);

    const salesMetrics = billableSales.map(s => ({
      sale: s,
      metrics: this.getSaleProfitMetrics(s)
    }));

    const grossProfitRaw = salesMetrics.reduce((sum, item) => sum + item.metrics.netProfit, 0);
    const grossProfit = Math.max(0, grossProfitRaw);

    // 5. Operating Expenses & Cash Drawer Payouts
    const filteredExpenses = (this.expenses || []).filter(exp => {
      if (branch !== 'ALL' && exp.branch_code && exp.branch_code !== 'ALL' && exp.branch_code !== branch) return false;
      const expDate = (exp.expense_date || exp.created_at || '').slice(0, 10);
      if (period === 'today' && expDate !== todayStr) return false;
      if (period === 'day' && expDate !== dateVal) return false;
      if (period === 'month' && !expDate.startsWith(monthVal)) return false;
      if (period === 'year' && !expDate.startsWith(yearVal)) return false;
      return true;
    });

    const totalOperatingExpenses = filteredExpenses.reduce((sum, e) => sum + Number(e.amount || 0), 0);
    const drawerPayouts = filteredExpenses.filter(e => (e.payment_source || 'CASH_DRAWER').toUpperCase() === 'CASH_DRAWER')
                                         .reduce((sum, e) => sum + Number(e.amount || 0), 0);

    // 5b. Stock bought in. The dashboard showed every cedi that left the drawer for rent and
    //     airtime and not one cedi that went to the factory, so the biggest outflow a shop
    //     has was the one it could not see without opening the supplier book. Buying stock is
    //     not an expense - it is cash turning into goods - which is why it is reported beside
    //     net profit and never subtracted from it.
    const filteredPurchases = (this.purchases || []).filter(p => {
      if (branch !== 'ALL' && (p.branch_code || 'MAIN-01').toUpperCase() !== branch.toUpperCase()) return false;
      const pDate = (p.order_date || p.created_at || '').slice(0, 10);
      if (period === 'today' && pDate !== todayStr) return false;
      if (period === 'day' && pDate !== dateVal) return false;
      if (period === 'month' && !pDate.startsWith(monthVal)) return false;
      if (period === 'year' && !pDate.startsWith(yearVal)) return false;
      return true;
    });
    const totalStockPurchased = filteredPurchases.reduce((sum, p) => sum + Number(p.total_cost || 0), 0);
    const totalPaidToSuppliers = filteredPurchases.reduce((sum, p) => sum + Number(p.amount_paid || 0), 0);
    // Per order, never netted across orders: an overpayment on one delivery is not a licence
    // to call a different delivery paid, and a draw on a balance the shop holds settles an
    // order without any cash moving today. Credit already spent is taken back off the
    // advance it was drawn from, or the card reports money at the factory that was collected
    // by the next order.
    let intakeUnsettled = 0;
    let intakeAdvanced = 0;
    let intakeDrawn = 0;
    filteredPurchases.forEach(p => {
      const paid = Number(p.amount_paid || 0);
      const drawn = Number(p.credit_used || 0);
      const left = Math.round((Number(p.total_cost || 0) - paid - drawn) * 100) / 100;
      if (left > 0.005) intakeUnsettled += left;
      else if (left < -0.005) intakeAdvanced += -left;
      intakeDrawn += drawn;
    });
    const totalUnsettledIntake = Math.round(Math.max(0, intakeUnsettled) * 100) / 100;
    const totalHeldWithFactory = Math.round(Math.max(0, intakeAdvanced - intakeDrawn) * 100) / 100;
    // Goods and carriage apart, because total_cost already has the delivery folded into it
    // (purchases.php adds shipping_cost to the line totals). Quoting the order total as
    // "into stock" and the delivery beside it makes the shop look like it paid both twice.
    const totalIntakeDelivery = filteredPurchases.reduce((sum, p) => sum + Number(p.shipping_cost || 0), 0);
    const totalIntakeGoods = Math.round((totalStockPurchased - totalIntakeDelivery) * 100) / 100;

    // 5c. Who the shop is standing, ranked. Deliberately NOT filtered by the period or the
    //     branch above: a supplier's balance is the whole book as it stands this minute, and
    //     showing "Owed in October" would let a till that only restocks in September report
    //     a debt-free shop while it owes six months of rent to a factory. The panel says so.
    //     The two directions are kept apart, never netted: GH₵1,000 owed to A and GH₵400
    //     sitting with B are a GH₵1,000 debt and a GH₵400 asset, not a GH₵600 debt.
    const openOrdersByVendor = {};
    (this.purchases || []).forEach(p => {
      const vid = String(p.vendor_id || '');
      if (!vid) return;
      if (!openOrdersByVendor[vid]) openOrdersByVendor[vid] = { orders: 0, lastDate: '' };
      const rec = openOrdersByVendor[vid];
      rec.orders++;
      const d = (p.order_date || p.created_at || '').slice(0, 10);
      if (d > rec.lastDate) rec.lastDate = d;
    });
    const rankRow = v => {
      const bal = Math.round(Number(v.balance || 0) * 100) / 100;
      const rec = openOrdersByVendor[String(v.id)] || { orders: 0, lastDate: '' };
      return {
        id: v.id, name: String(v.name || 'Unnamed supplier').trim() || 'Unnamed supplier',
        phone: String(v.phone || '').trim(), balance: bal,
        amount: Math.abs(bal), orders: rec.orders, lastDate: rec.lastDate,
      };
    };
    const ranked = (this.vendors || []).map(rankRow);
    const supplierDebts = ranked.filter(v => v.balance > 0.005).sort((a, b) => b.balance - a.balance);
    const supplierAdvances = ranked.filter(v => v.balance < -0.005).sort((a, b) => b.amount - a.amount);
    const totalSupplierDebt = Math.round(supplierDebts.reduce((sum, v) => sum + v.balance, 0) * 100) / 100;
    const totalSupplierAdvance = Math.round(supplierAdvances.reduce((sum, v) => sum + v.amount, 0) * 100) / 100;
    // A purchase recorded against a typed-in name has no vendor row, so nothing carries its
    // balance. Left out, the ranking would tell the shopkeeper he owes less than he does.
    const oneOffSupplierDebt = Math.round((this.purchases || [])
      .filter(p => !p.vendor_id && (Number(p.total_cost || 0) - Number(p.amount_paid || 0)) > 0.005)
      .reduce((sum, p) => sum + (Number(p.total_cost || 0) - Number(p.amount_paid || 0)), 0) * 100) / 100;

    const netProfit = grossProfit - totalOperatingExpenses;

    const totalCOGS = billableSales.reduce((sum, s) => {
      const cogs = Number(s.cost_of_goods !== undefined ? s.cost_of_goods : ((s.total_amount || 0) - (s.gross_profit || 0)));
      return sum + cogs;
    }, 0);

    const profitMargin = netRevenue > 0 ? ((grossProfit / netRevenue) * 100).toFixed(1) : '0.0';

    const totalProductsCount = filteredProducts.length;
    const lowStockCount = filteredProducts.filter(p => p.effective_quantity <= Number(p.min_stock_alert || 5) && p.effective_quantity > 0).length;
    const outOfStockCount = filteredProducts.filter(p => p.effective_quantity <= 0).length;
    const healthyStockCount = filteredProducts.filter(p => p.effective_quantity > Number(p.min_stock_alert || 5)).length;

    const inventoryValuationCost = filteredProducts.reduce((sum, p) => sum + (p.effective_quantity * Number(p.cost_price || 0)), 0);
    const inventoryValuationRetail = filteredProducts.reduce((sum, p) => sum + (p.effective_quantity * Number(p.selling_price || 0)), 0);
    // What the shelf would make if it sold out. Signed, because a shop carrying anything below
    // its own cost has a real number to look at, and clamping at zero hides which lines are
    // the cause. This is NOT profit: none of it is earned until the goods leave the counter,
    // which is why it sits on the stock card and never near Net Profit.
    const unrealizedProfit = Math.round((inventoryValuationRetail - inventoryValuationCost) * 100) / 100;
    // Products priced at or under what they cost the shop - the lines dragging on the figure
    // above, and the ones to look at before the next order goes in.
    const soldBelowCostCount = filteredProducts.filter(p =>
      p.effective_quantity > 0 && Number(p.selling_price || 0) <= Number(p.cost_price || 0)).length;

    // Human-readable active filter label
    let periodLabel = 'All Time';
    if (period === 'today') periodLabel = `Today (${todayStr})`;
    else if (period === 'day') periodLabel = `Day: ${dateVal}`;
    else if (period === 'month') {
      const [y, m] = monthVal.split('-');
      const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      periodLabel = `${monthNames[parseInt(m, 10) - 1] || m} ${y}`;
    } else if (period === 'year') {
      periodLabel = `Year: ${yearVal}`;
    }

    let branchLabel = 'All Branches (Consolidated)';
    if (branch !== 'ALL') {
      const bObj = (this.branches || []).find(b => (b.branch_code || '').toUpperCase() === branch.toUpperCase());
      branchLabel = bObj ? `${bObj.branch_code} - ${bObj.name}` : branch;
    }

    return {
      filteredSales,
      billableSales,
      voidedSales,
      voidedValue,
      filteredReturns,
      filteredProducts,
      filteredExpenses,
      totalOperatingExpenses,
      drawerPayouts,
      filteredPurchases,
      totalStockPurchased,
      totalPaidToSuppliers,
      totalUnsettledIntake,
      totalHeldWithFactory,
      totalIntakeGoods,
      totalIntakeDelivery,
      supplierDebts,
      supplierAdvances,
      totalSupplierDebt,
      totalSupplierAdvance,
      oneOffSupplierDebt,
      netProfit,
      grossRevenue,
      totalRefunded,
      netRevenue,
      grossProfit,
      totalCOGS,
      profitMargin,
      totalProductsCount,
      lowStockCount,
      outOfStockCount,
      healthyStockCount,
      inventoryValuationCost,
      inventoryValuationRetail,
      unrealizedProfit,
      soldBelowCostCount,
      branch,
      period,
      dateVal,
      monthVal,
      yearVal,
      periodLabel,
      branchLabel,
      activeFilterLabel: (this.isMultiBranch && branch !== 'ALL') ? `${periodLabel} • ${branchLabel}` : periodLabel
    };
  },

  setDashboardBranchFilter(branchCode) {
    this.dashFilterBranch = branchCode || 'ALL';
    this.renderCurrentView();
  },

  setDashboardPeriodFilter(period) {
    this.dashFilterPeriod = period || 'all';
    this.renderCurrentView();
  },

  setDashboardDateFilter(dateVal) {
    this.dashFilterDate = dateVal;
    this.dashFilterPeriod = 'day';
    this.renderCurrentView();
  },

  setDashboardMonthFilter(monthVal) {
    this.dashFilterMonth = monthVal;
    this.dashFilterPeriod = 'month';
    this.renderCurrentView();
  },

  setDashboardYearFilter(yearVal) {
    this.dashFilterYear = yearVal;
    this.dashFilterPeriod = 'year';
    this.renderCurrentView();
  },

  resetDashboardFilters() {
    this.dashFilterBranch = 'ALL';
    this.dashFilterPeriod = 'all';
    this.dashFilterDate = new Date().toISOString().slice(0, 10);
    this.dashFilterMonth = new Date().toISOString().slice(0, 7);
    this.dashFilterYear = new Date().getFullYear().toString();
    this.renderCurrentView();
  },

  getDashboardHTML() {
    const data = this.getFilteredDashboardData();
    const recentSales = data.filteredSales.slice(0, 5);
    const isFiltered = ((this.isMultiBranch && data.branch !== 'ALL') || data.period !== 'all');

    const curYear = new Date().getFullYear();
    const yearsList = [];
    for (let y = curYear; y >= curYear - 5; y--) {
      yearsList.push(y);
    }

    return `
      <!-- Dashboard Multi-Dimensional Filter Bar -->
      <div class="panel" style="margin-bottom: 1.25rem; background: var(--surface); border: 1px solid var(--slate-200); border-radius: 12px; padding: 0.85rem 1.25rem; box-shadow: 0 1px 3px rgba(0,0,0,0.03);">
        <div style="display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 0.75rem;">
          <div style="display: flex; align-items: center; gap: 0.6rem; flex-wrap: wrap;">
            <div style="display: flex; align-items: center; gap: 0.4rem; font-size: 0.85rem; font-weight: 700; color: var(--slate-700);">
              <i class="fa-solid fa-sliders" style="color: var(--primary);"></i>
              <span>Dashboard Filters:</span>
            </div>

            ${this.isMultiBranch ? `
              <!-- Branch Selector -->
              <div style="display: flex; align-items: center; gap: 0.35rem;">
                <select id="dash-filter-branch" class="form-control" style="font-size: 0.82rem; padding: 0.35rem 0.65rem; width: auto; font-weight: 600;" onchange="app.setDashboardBranchFilter(this.value)">
                  <option value="ALL" ${data.branch === 'ALL' ? 'selected' : ''}>🏢 All Branches (Consolidated)</option>
                  ${(this.branches || []).map(b => `
                    <option value="${this.escapeHtml(b.branch_code)}" ${data.branch.toUpperCase() === b.branch_code.toUpperCase() ? 'selected' : ''}>
                      ${this.escapeHtml(b.branch_code)} - ${this.escapeHtml(b.name)}
                    </option>
                  `).join('')}
                </select>
              </div>
            ` : ''}

            <!-- Period Range Selector -->
            <div style="display: flex; align-items: center; gap: 0.35rem;">
              <select id="dash-filter-period" class="form-control" style="font-size: 0.82rem; padding: 0.35rem 0.65rem; width: auto; font-weight: 600;" onchange="app.setDashboardPeriodFilter(this.value)">
                <option value="all" ${data.period === 'all' ? 'selected' : ''}>📅 All Time</option>
                <option value="today" ${data.period === 'today' ? 'selected' : ''}>⚡ Today</option>
                <option value="day" ${data.period === 'day' ? 'selected' : ''}>📆 Specific Day</option>
                <option value="month" ${data.period === 'month' ? 'selected' : ''}>🗓️ In a Month of a Year</option>
                <option value="year" ${data.period === 'year' ? 'selected' : ''}>📊 Specific Year</option>
              </select>
            </div>

            <!-- Dynamic Specific Day Picker -->
            ${data.period === 'day' ? `
              <div style="display: flex; align-items: center; gap: 0.35rem;">
                <input type="date" id="dash-filter-date" class="form-control" style="font-size: 0.82rem; padding: 0.35rem 0.65rem; width: auto; font-weight: 600;" value="${data.dateVal}" onchange="app.setDashboardDateFilter(this.value)">
              </div>
            ` : ''}

            <!-- Dynamic Specific Month Picker -->
            ${data.period === 'month' ? `
              <div style="display: flex; align-items: center; gap: 0.35rem;">
                <input type="month" id="dash-filter-month" class="form-control" style="font-size: 0.82rem; padding: 0.35rem 0.65rem; width: auto; font-weight: 600;" value="${data.monthVal}" onchange="app.setDashboardMonthFilter(this.value)">
              </div>
            ` : ''}

            <!-- Dynamic Specific Year Picker -->
            ${data.period === 'year' ? `
              <div style="display: flex; align-items: center; gap: 0.35rem;">
                <select id="dash-filter-year" class="form-control" style="font-size: 0.82rem; padding: 0.35rem 0.65rem; width: auto; font-weight: 600;" onchange="app.setDashboardYearFilter(this.value)">
                  ${yearsList.map(y => `
                    <option value="${y}" ${data.yearVal === y.toString() ? 'selected' : ''}>${y}</option>
                  `).join('')}
                </select>
              </div>
            ` : ''}
          </div>

          <!-- Active Filter Pill & Reset & Live Refresh -->
          <div style="display: flex; align-items: center; gap: 0.6rem; flex-wrap: wrap;">
            <span class="badge ${isFiltered ? 'badge-primary' : 'badge-neutral'}" style="font-size: 0.78rem; padding: 0.35rem 0.75rem;">
              <i class="fa-solid fa-filter"></i> ${this.escapeHtml(data.activeFilterLabel)}
            </span>
            ${isFiltered ? `
              <button class="btn btn-outline btn-sm" onclick="app.resetDashboardFilters()" title="Reset all filters to All Time & All Branches">
                <i class="fa-solid fa-rotate-left"></i> Reset
              </button>
            ` : ''}
            <button class="btn btn-outline btn-sm" onclick="app.refreshViewDataOnVisit('dashboard')" title="Refresh latest sales & financial metrics">
              <i class="fa-solid fa-arrows-rotate"></i> Refresh
            </button>
          </div>
        </div>
      </div>

           <!-- Row 1: Income Statement (4 Cards — Revenue → Gross Profit → Expenses → Net Profit) -->
      <div class="kpi-grid" style="grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 1rem; margin-bottom: 1rem;">

        <!-- 1. Total Net Revenue -->
        <div class="kpi-card interactive-kpi" onclick="app.switchView('sales')" title="Click to open full Sales History &amp; Ledger">
          <div class="kpi-icon-wrapper kpi-blue">
            <i class="fa-solid fa-chart-line"></i>
          </div>
          <div class="kpi-info" style="flex: 1; min-width: 0;">
            <div style="display: flex; justify-content: space-between; align-items: baseline;">
              <h4>Total Revenue</h4>
              <i class="fa-solid fa-chevron-right" style="font-size: 0.75rem; color: var(--slate-400);"></i>
            </div>
            <p style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${this.formatCurrency(data.netRevenue)}">${this.formatCurrency(data.netRevenue)}</p>
            <span>${data.billableSales.length} sale(s)${data.totalRefunded > 0 ? ` &bull; ${this.formatCurrency(data.totalRefunded)} refunded` : ''}${data.voidedSales.length > 0 ? ` &bull; <span style="color:#b91c1c;font-weight:700;">${data.voidedSales.length} voided</span> (${this.formatCurrency(data.voidedValue)}) not counted` : ''}</span>
            <div class="kpi-drilldown-hint">
              <i class="fa-solid fa-arrow-right"></i> View Sales Ledger &rarr;
            </div>
          </div>
        </div>

        <!-- 2. Gross Profit -->
        <div class="kpi-card interactive-kpi" onclick="app.switchView('sales')" title="Click to view Sales &amp; Profit Report">
          <div class="kpi-icon-wrapper kpi-green">
            <i class="fa-solid fa-arrow-trend-up"></i>
          </div>
          <div class="kpi-info" style="flex: 1; min-width: 0;">
            <div style="display: flex; justify-content: space-between; align-items: baseline;">
              <h4>Gross Profit</h4>
              <i class="fa-solid fa-chevron-right" style="font-size: 0.75rem; color: var(--slate-400);"></i>
            </div>
            <p style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${this.formatCurrency(data.grossProfit)}">${this.formatCurrency(data.grossProfit)}</p>
            <span>Margin: ${data.profitMargin}% &bull; COGS: ${this.formatCurrency(data.totalCOGS)}</span>
            <div class="kpi-drilldown-hint">
              <i class="fa-solid fa-arrow-right"></i> View Profit Report &rarr;
            </div>
          </div>
        </div>

        <!-- 3. Store Operating Expenses -->
        <div class="kpi-card interactive-kpi" onclick="app.switchView('expenses')" title="Click to open Expenses &amp; Cash Drawer Payouts Ledger">
          <div class="kpi-icon-wrapper" style="background: #fff7ed; color: #ea580c;">
            <i class="fa-solid fa-file-invoice-dollar"></i>
          </div>
          <div class="kpi-info" style="flex: 1; min-width: 0;">
            <div style="display: flex; justify-content: space-between; align-items: baseline;">
              <h4>Store Expenses</h4>
              <i class="fa-solid fa-chevron-right" style="font-size: 0.75rem; color: var(--slate-400);"></i>
            </div>
            <p style="color: ${data.totalOperatingExpenses > 0 ? '#ea580c' : 'inherit'}; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${this.formatCurrency(data.totalOperatingExpenses)}">${this.formatCurrency(data.totalOperatingExpenses)}</p>
            <span>${data.filteredExpenses.length} record(s)${data.drawerPayouts > 0 ? ` &bull; ${this.formatCurrency(data.drawerPayouts)} drawer` : ''}</span>
            <div class="kpi-drilldown-hint">
              <i class="fa-solid fa-arrow-right"></i> View Expenses Ledger &rarr;
            </div>
          </div>
        </div>

        <!-- 4. Net Operating Profit — the bottom line of the income statement -->
        <div class="kpi-card interactive-kpi" onclick="app.switchView('expenses')" title="Click to view Expenses &amp; Net Profit Breakdown">
          <div class="kpi-icon-wrapper" style="background: ${data.netProfit >= 0 ? '#ecfdf5' : '#fef2f2'}; color: ${data.netProfit >= 0 ? '#059669' : '#dc2626'};">
            <i class="fa-solid fa-scale-balanced"></i>
          </div>
          <div class="kpi-info" style="flex: 1; min-width: 0;">
            <div style="display: flex; justify-content: space-between; align-items: baseline;">
              <h4>Net Profit</h4>
              <i class="fa-solid fa-chevron-right" style="font-size: 0.75rem; color: var(--slate-400);"></i>
            </div>
            <p style="color: ${data.netProfit >= 0 ? '#059669' : '#dc2626'}; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${this.formatCurrency(data.netProfit)}">${this.formatCurrency(data.netProfit)}</p>
            <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; display: block;" title="Gross: ${this.formatCurrency(data.grossProfit)} minus Expenses: ${this.formatCurrency(data.totalOperatingExpenses)}">Gross ${this.formatCurrency(data.grossProfit)} &minus; Exp ${this.formatCurrency(data.totalOperatingExpenses)}</span>
            <div class="kpi-drilldown-hint">
              <i class="fa-solid fa-arrow-right"></i> View Profit &amp; Loss &rarr;
            </div>
          </div>
        </div>
      </div>

      <!-- Row 2: Inventory & Operations (4 Cards)
           The three original cards that all showed the same inventory numbers
           (Total Products, Expected Stock Outcome, Shelf Margin) are merged into two:
             A. "Live Stock"        — SKU count, cost basis, total retail value on shelf.
             B. "Stock Opportunity" — the unrealised gain if everything sold, plus a
                pricing-health flag for items sitting below cost.
           Stock Intakes moves here from Row 1 so Row 1 stays a clean P&L income statement.
           Returns & Refunds is visible in the sales table below and accessible from the
           Quick Actions bar; it does not need a dedicated summary card. -->
      <div class="kpi-grid" style="grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 1rem; margin-bottom: 1.5rem;">

        <!-- 5. Live Stock — SKU count + full cost / retail valuation combined -->
        <div class="kpi-card interactive-kpi" onclick="app.switchView('inventory')" title="Click to view Live Inventory: SKU count, cost basis, and total retail sell-through value on the shelf.">
          <div class="kpi-icon-wrapper kpi-purple">
            <i class="fa-solid fa-boxes-stacked"></i>
          </div>
          <div class="kpi-info" style="flex: 1; min-width: 0;">
            <div style="display: flex; justify-content: space-between; align-items: baseline;">
              <h4>Live Stock</h4>
              <i class="fa-solid fa-chevron-right" style="font-size: 0.75rem; color: var(--slate-400);"></i>
            </div>
            <!-- Headline: the retail value — what the shelf would ring if every unit sold -->
            <p style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;"
               title="Retail value of all stock on hand: ${this.formatCurrency(data.inventoryValuationRetail)}">${this.formatCurrency(data.inventoryValuationRetail)}</p>
            <!-- Sub-line: SKU count + what was paid to put that stock on the shelf -->
            <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; display: block;"
                  title="${data.totalProductsCount} product line(s) on shelf &bull; Cost basis: ${this.formatCurrency(data.inventoryValuationCost)}">
              ${data.totalProductsCount} SKU(s) &bull; Cost in: ${this.formatCurrency(data.inventoryValuationCost)}
            </span>
            <div class="kpi-drilldown-hint">
              <i class="fa-solid fa-arrow-right"></i> View Live Inventory &rarr;
            </div>
          </div>
        </div>

        <!-- 6. Stock Opportunity — unrealised margin + pricing health flag.
             The old "Expected Stock Outcome" (led with retail total) and the old "Shelf Margin"
             (led with the gain) were saying the same thing twice. Here the gain is the headline
             — it is the interesting number for the owner — and the retail total is the supporting
             line shown once. The below-cost flag is preserved because it is actionable. -->
        <div class="kpi-card interactive-kpi" onclick="app.switchView('inventory')" title="Unrealised margin: how much the shop stands to gain if every unit on the shelf sells at its current till price. Not earned yet — none of it is profit until it leaves the counter.">
          <div class="kpi-icon-wrapper" style="background: ${data.unrealizedProfit >= 0 ? '#fef3c7' : '#fee2e2'}; color: ${data.unrealizedProfit >= 0 ? '#b45309' : '#b91c1c'};">
            <i class="fa-solid fa-sack-dollar"></i>
          </div>
          <div class="kpi-info" style="flex: 1; min-width: 0;">
            <div style="display: flex; justify-content: space-between; align-items: baseline;">
              <h4>Shelf Margin</h4>
              <i class="fa-solid fa-chevron-right" style="font-size: 0.75rem; color: var(--slate-400);"></i>
            </div>
            <!-- Headline: the unrealised gain waiting on the shelf -->
            <p style="color: ${data.unrealizedProfit >= 0 ? '#b45309' : '#b91c1c'}; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;"
               title="${data.unrealizedProfit >= 0 ? 'Projected gain if shelf sells out' : 'Pricing deficit — stock on hand priced below cost'}: ${this.formatCurrency(data.unrealizedProfit)}">
              ${data.unrealizedProfit >= 0 ? '+' : ''}${this.formatCurrency(data.unrealizedProfit)}
            </p>
            <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; display: block;"
                  title="Paid ${this.formatCurrency(data.inventoryValuationCost)} for stock worth ${this.formatCurrency(data.inventoryValuationRetail)} at till price">
              on ${this.formatCurrency(data.inventoryValuationCost)} of stock &middot; ${this.formatCurrency(data.inventoryValuationRetail)} at till
            </span>
            <span>${data.unrealizedProfit >= 0 ? 'If the shelf sold out' : 'Stock priced at or below cost'}${data.soldBelowCostCount > 0 ? ` &middot; <span style="color:#b91c1c;">${data.soldBelowCostCount} line(s) under cost</span>` : ''}</span>
            <div class="kpi-drilldown-hint">
              <i class="fa-solid fa-arrow-right"></i> Review Pricing &amp; Stock &rarr;
            </div>
          </div>
        </div>

        <!-- 7. Stock Intakes — factory POs for the selected period -->
        <div class="kpi-card interactive-kpi" onclick="app.switchView('purchases')" title="Click to open the Factory Purchase Orders ledger">
          <div class="kpi-icon-wrapper" style="background: #e0f2fe; color: #0369a1;">
            <i class="fa-solid fa-truck-ramp-box"></i>
          </div>
          <div class="kpi-info" style="flex: 1; min-width: 0;">
            <div style="display: flex; justify-content: space-between; align-items: baseline;">
              <h4>Stock Intakes</h4>
              <i class="fa-solid fa-chevron-right" style="font-size: 0.75rem; color: var(--slate-400);"></i>
            </div>
            <p style="color: ${data.totalStockPurchased > 0 ? '#0369a1' : 'inherit'}; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${this.formatCurrency(data.totalStockPurchased)}">${this.formatCurrency(data.totalStockPurchased)}</p>
            <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; display: block;"
                  title="Goods ${this.formatCurrency(data.totalIntakeGoods)}${data.totalIntakeDelivery > 0 ? ' + carriage ' + this.formatCurrency(data.totalIntakeDelivery) : ''}">
              Goods ${this.formatCurrency(data.totalIntakeGoods)}${data.totalIntakeDelivery > 0.005 ? ` &bull; carriage ${this.formatCurrency(data.totalIntakeDelivery)}` : ''}
            </span>
            ${(() => {
              // Signed in the supplier's direction: money still to leave the drawer is a
              // warning, money already sitting with the factory is something the shop owns.
              // Counted per order and never netted, so a shop that owes one supplier and
              // has cash with another is told both clearly.
              const unsettled = data.totalUnsettledIntake;
              const held = data.totalHeldWithFactory;
              const orders = data.filteredPurchases.length;
              const heldNote = held > 0.005 ? ` &middot; ${this.formatCurrency(held)} held with factory` : '';
              if (orders === 0) return `<span>No factory orders in ${this.escapeHtml(data.activeFilterLabel).toLowerCase()}</span>`;
              if (unsettled > 0.005) return `<span style="color:#b91c1c;">${orders} order(s) &middot; ${this.formatCurrency(unsettled)} still to pay${heldNote}</span>`;
              if (held > 0.005) return `<span style="color:#0369a1;">${orders} order(s) &middot; ${this.formatCurrency(held)} held with factory</span>`;
              return `<span>${orders} order(s) &middot; all settled</span>`;
            })()}
            <div class="kpi-drilldown-hint">
              <i class="fa-solid fa-arrow-right"></i> View Purchase Orders &rarr;
            </div>
          </div>
        </div>

        <!-- 8. Stock Alerts -->
        <div class="kpi-card interactive-kpi" onclick="app.switchView('inventory')" title="Click to view Inventory Stock Alerts">
          <div class="kpi-icon-wrapper ${data.outOfStockCount > 0 ? 'kpi-red' : (data.lowStockCount > 0 ? 'kpi-amber' : 'kpi-green')}">
            <i class="fa-solid fa-triangle-exclamation"></i>
          </div>
          <div class="kpi-info" style="flex: 1; min-width: 0;">
            <div style="display: flex; justify-content: space-between; align-items: baseline;">
              <h4>Stock Alerts</h4>
              <i class="fa-solid fa-chevron-right" style="font-size: 0.75rem; color: var(--slate-400);"></i>
            </div>
            <p>${data.outOfStockCount} Out &bull; ${data.lowStockCount} Low</p>
            <span>${data.outOfStockCount > 0 || data.lowStockCount > 0 ? 'Items needing factory restock' : 'All inventory levels healthy'}</span>
            <div class="kpi-drilldown-hint">
              <i class="fa-solid fa-arrow-right"></i> View Stock Alerts &rarr;
            </div>
          </div>
        </div>
      </div>

 <!-- Quick Store Operations Action Bar -->
      <div class="panel" style="margin-bottom: 1.5rem;">
        <div class="panel-body" style="display: flex; gap: 1rem; flex-wrap: wrap; align-items: center; justify-content: space-between;">
          <div>
            <h4 style="font-size: 1rem; font-weight: 700; color: var(--slate-800);">Quick Store Actions</h4>
            <p style="font-size: 0.85rem; color: var(--slate-500);">Fast navigation for common cashier, returns, and inventory operations</p>
          </div>
          <div style="display: flex; gap: 0.75rem; flex-wrap: wrap;">
            <button class="btn btn-primary" onclick="app.switchView('pos')">
              <i class="fa-solid fa-cash-register"></i> Open POS Checkout
            </button>
            <button class="btn btn-outline" style="color: #c2410c; border-color: #fed7aa; font-weight: 700;" onclick="app.openExpenseModal()">
              <i class="fa-solid fa-receipt"></i> Log Store Expense
            </button>
            <button class="btn btn-outline" style="color: #4338ca; border-color: #c7d2fe; font-weight: 700;" onclick="app.openSalesReturnModal()">
              <i class="fa-solid fa-arrow-rotate-left"></i> Customer Return
            </button>
            <button class="btn btn-success" onclick="app.switchView('purchases')">
              <i class="fa-solid fa-truck-ramp-box"></i> Stock In from Factory
            </button>
            <button class="btn btn-outline" onclick="app.switchView('products')">
              <i class="fa-solid fa-plus"></i> Add New Product
            </button>
            <button class="btn btn-outline" onclick="app.switchView('backups')">
              <i class="fa-solid fa-database"></i> Database Backups
            </button>
            ${(typeof this.isRentalsEnabled === 'function' && this.isRentalsEnabled()) ? `
              <button class="btn btn-outline" style="color: #7c3aed; border-color: #ddd6fe; font-weight: 700; background: #faf5ff;" onclick="app.switchView('rentals')">
                <i class="fa-solid fa-boxes-packing"></i> Rentals &amp; Hire (${(this.rentalsSummary && this.rentalsSummary.items_on_hire) || 0} out)
              </button>
            ` : ''}
          </div>
        </div>
      </div>

      <!-- Filtered Recent Sales & Stock Alerts Overview -->
      <div class="dashboard-two-col-grid">
        <div class="panel">
          <div class="panel-header">
            <h3>
              <i class="fa-solid fa-receipt"></i> Recent Store Sales
              ${isFiltered ? `<small style="font-size: 0.75rem; font-weight: normal; color: var(--slate-500); margin-left: 0.5rem;">(${this.escapeHtml(data.activeFilterLabel)})</small>` : ''}
            </h3>
            <button class="btn btn-outline btn-sm" onclick="app.switchView('sales')">View Sales Ledger</button>
          </div>
          <div class="panel-body table-panel-body">
            <div class="table-responsive">
              <table class="data-table">
                <thead>
                  <tr>
                    <th>Receipt #</th>
                    <th>Customer</th>
                    <th>Total</th>
                    <th>Profit</th>
                    <th>Payment</th>
                  </tr>
                </thead>
                <tbody>
                  ${recentSales.length > 0 ? recentSales.map(s => `
                    <tr>
                      <td style="font-weight: 600; font-family: monospace;">${this.escapeHtml(s.receipt_number)}</td>
                      <td>${this.escapeHtml(s.customer_name || 'Walk-in Customer')}</td>
                      <td style="font-weight: 700;">
                        ${this.isVoidedSale(s) ? `
                          <div style="font-size: 0.72rem; color: #94a3b8; text-decoration: line-through;">${this.formatCurrency(s.total_amount)}</div>
                          <div style="color: #b91c1c;">${this.formatCurrency(0)}</div>
                          <span class="badge badge-danger" style="font-size: 0.68rem; margin-top: 2px;" title="${this.escapeHtml(String(s.void_reason || 'No reason recorded'))} - voided ${this.escapeHtml(String(s.voided_at || 'today'))} by ${this.escapeHtml(String(s.void_user_name || 'the shop'))}">VOIDED</span>
                        ` : `
                        ${this.formatCurrency(s.total_amount)}
                        ${Number(s.refunded_amount || 0) > 0 ? `
                          <div style="font-size: 0.72rem; color: #dc2626; font-weight: 600; margin-top: 2px;">
                            -${this.formatCurrency(s.refunded_amount)} refunded
                          </div>
                          <span class="badge ${s.status === 'REFUNDED' ? 'badge-danger' : 'badge-warning'}" style="font-size: 0.68rem; margin-top: 2px;">
                            ${this.escapeHtml(s.status)}
                          </span>
                        ` : ''}
                        `}
                      </td>
                      <td>
                        ${(() => {
                          if (this.isVoidedSale(s)) {
                            return `<span style="color: var(--slate-400); font-weight: 600;">${this.formatCurrency(0)}</span> <span class="badge badge-danger" style="font-size: 0.65rem;">Voided</span>`;
                          }
                          const m = this.getSaleProfitMetrics(s);
                          if (m.isFullyRefunded) {
                            return `<span style="color: var(--slate-400); font-weight: 600;">${this.formatCurrency(0)}</span> <span class="badge badge-neutral" style="font-size: 0.65rem;">Refunded</span>`;
                          }
                          if (m.isPartiallyRefunded) {
                            return `<span style="color: var(--success); font-weight: 700;">+${this.formatCurrency(m.netProfit)}</span> <span class="badge badge-warning" style="font-size: 0.65rem;">Net</span>`;
                          }
                          return `<span style="color: var(--success); font-weight: 600;">+${this.formatCurrency(s.gross_profit)}</span>`;
                        })()}
                      </td>
                      <td><span class="badge badge-neutral">${this.escapeHtml(s.payment_method)}</span></td>
                    </tr>
                  `).join('') : `
                    <tr>
                      <td colspan="5" style="text-align: center; padding: 2rem; color: var(--slate-400);">
                        <i class="fa-solid fa-circle-info" style="margin-right: 0.5rem;"></i> No sales found for the selected filter period.
                      </td>
                    </tr>
                  `}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div class="panel">
          <div class="panel-header">
            <h3><i class="fa-solid fa-triangle-exclamation"></i> Stock Alerts & Reorders</h3>
            <button class="btn btn-outline btn-sm" onclick="app.switchView('inventory')">View Inventory</button>
          </div>
          <div class="panel-body table-panel-body">
            <div class="table-responsive">
              <table class="data-table">
                <thead>
                  <tr>
                    <th>Product</th>
                    <th>Stock</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  ${(() => {
                    const alertProducts = data.filteredProducts
                      .filter(p => p.effective_quantity <= Number(p.min_stock_alert || 5))
                      .slice(0, 5);

                    if (alertProducts.length === 0) {
                      return `
                        <tr>
                          <td colspan="4" style="text-align: center; padding: 2rem; color: var(--success);">
                            <i class="fa-solid fa-circle-check" style="margin-right: 0.5rem;"></i> All inventory levels are healthy!
                          </td>
                        </tr>
                      `;
                    }

                    return alertProducts.map(p => `
                      <tr>
                        <td style="font-weight: 600;">${this.escapeHtml(p.name)}</td>
                        <td><strong>${p.effective_quantity}</strong></td>
                        <td>
                          ${p.effective_quantity <= 0
                            ? `<span class="badge badge-danger">Out of Stock</span>`
                            : `<span class="badge badge-warning">Low Stock (&le; ${p.min_stock_alert || 5})</span>`}
                        </td>
                        <td>
                          <button class="btn btn-primary btn-sm" onclick="app.switchView('purchases')">
                            Restock
                          </button>
                        </td>
                      </tr>
                    `).join('');
                  })()}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <!-- Stock Bought In: what the factory delivered, in the sizes it was bought in -->
      <div class="panel" style="margin-top: 1.5rem;">
        <div class="panel-header">
          <h3>
            <i class="fa-solid fa-truck-ramp-box"></i> Stock Bought In
            ${isFiltered ? `<small style="font-size: 0.75rem; font-weight: normal; color: var(--slate-500); margin-left: 0.5rem;">(${this.escapeHtml(data.activeFilterLabel)})</small>` : ''}
          </h3>
          <button class="btn btn-outline btn-sm" onclick="app.switchView('purchases')">View Purchase Ledger</button>
        </div>
        <div class="panel-body table-panel-body">
          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Order #</th>
                  <th>Factory / Supplier</th>
                  <th>What Came In</th>
                  <th>Cost</th>
                  <th>Settled</th>
                </tr>
              </thead>
              <tbody>
                ${data.filteredPurchases.length > 0 ? data.filteredPurchases.slice(0, 5).map(p => `
                  <tr>
                    <td style="font-weight: 600; font-family: monospace;">
                      <a href="javascript:void(0)" style="color: var(--primary);" title="Open this order's supplier voucher"
                         onclick="app.openPurchaseVoucherModal(${this.jsStr(p.id)})">${this.escapeHtml(p.order_number)}</a>
                    </td>
                    <td>${this.escapeHtml(p.supplier_name || 'Factory Supplier')}</td>
                    <td style="font-size: 0.82rem;">${this.purchaseSummaryHtml(p, 2)}</td>
                    <td style="font-weight: 700;">${this.formatCurrency(p.total_cost)}</td>
                    <td>
                      ${(() => {
                        const paid = Number(p.amount_paid || 0);
                        const drawn = Number(p.credit_used || 0);
                        const left = Math.round((Number(p.total_cost || 0) - paid - drawn) * 100) / 100;
                        if (left > 0.005) return `<span class="badge badge-danger">${this.formatCurrency(left)} to pay</span>`;
                        if (left < -0.005) return `<span class="badge badge-info">${this.formatCurrency(Math.abs(left))} held with them</span>`;
                        // Closed without the whole invoice leaving the drawer today. Saying
                        // just "Paid" hides where the rest of the money came from, and the
                        // owner checking the till cannot find the difference in the cash box.
                        if (drawn > 0.005) return `<span class="badge badge-success">Paid &mdash; ${this.formatCurrency(drawn)} from balance</span>`;
                        return `<span class="badge badge-success">Paid</span>`;
                      })()}
                    </td>
                  </tr>
                `).join('') : `
                  <tr>
                    <td colspan="5" style="text-align: center; padding: 2rem; color: var(--slate-400);">
                      <i class="fa-solid fa-truck-ramp-box" style="margin-right: 0.5rem;"></i> Nothing was bought in for the selected filter period.
                    </td>
                  </tr>
                `}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- Who the shop is standing, ranked by what it owes them -->
      <div class="panel" style="margin-top: 1.5rem;">
        <div class="panel-header">
          <h3>
            <i class="fa-solid fa-handshake-angle"></i> Standing With Suppliers
            <small style="font-size: 0.72rem; font-weight: 600; color: var(--slate-500); margin-left: 0.5rem;"
                   title="A supplier's balance is the whole book as it stands this minute. It does not follow the period or branch filter above, because a shop that only restocks in September must not be able to report a debt-free October while it still owes him.">
              <i class="fa-solid fa-circle-info"></i> whole book, right now
            </small>
          </h3>
          <button class="btn btn-outline btn-sm" onclick="app.switchView('vendors')">Open Supplier Book</button>
        </div>
        <div class="panel-body">
          <div style="display: flex; flex-wrap: wrap; gap: 1.5rem; margin-bottom: 1rem; font-size: 0.85rem;">
            <div>
              <div style="color: var(--slate-500); font-size: 0.74rem; text-transform: uppercase; letter-spacing: 0.04em;">We Owe</div>
              <strong style="font-size: 1.25rem; font-family: monospace; color: ${data.totalSupplierDebt > 0.005 ? '#dc2626' : '#15803d'};">${this.formatCurrency(data.totalSupplierDebt)}</strong>
            </div>
            <div>
              <div style="color: var(--slate-500); font-size: 0.74rem; text-transform: uppercase; letter-spacing: 0.04em;">Held With Them</div>
              <strong style="font-size: 1.25rem; font-family: monospace; color: ${data.totalSupplierAdvance > 0.005 ? '#0369a1' : 'var(--slate-400)'};">${this.formatCurrency(data.totalSupplierAdvance)}</strong>
            </div>
            ${data.oneOffSupplierDebt > 0.005 ? `
            <div title="Orders recorded against a typed-in name rather than a registered supplier. No supplier row carries this money, so it is kept out of the ranking above rather than folded into it.">
              <div style="color: var(--slate-500); font-size: 0.74rem; text-transform: uppercase; letter-spacing: 0.04em;">Unregistered</div>
              <strong style="font-size: 1.25rem; font-family: monospace; color: #b45309;">${this.formatCurrency(data.oneOffSupplierDebt)}</strong>
            </div>` : ''}
          </div>

          ${data.supplierDebts.length > 0 ? `
            <div style="display: flex; flex-direction: column; gap: 0.4rem;">
              ${data.supplierDebts.slice(0, 6).map((v, i) => {
                const share = data.totalSupplierDebt > 0.005 ? Math.min(100, (v.balance / data.totalSupplierDebt) * 100) : 100;
                return `
                  <div style="display: flex; align-items: center; gap: 0.75rem; padding: 0.5rem 0.65rem; border: 1px solid var(--slate-200); border-radius: 8px; background: ${i === 0 ? '#fff5f5;' : 'var(--surface);'}">
                    <span style="flex: 0 0 1.4rem; text-align: center; font-weight: 800; color: var(--slate-400); font-size: 0.85rem;">${i + 1}</span>
                    <div style="flex: 1; min-width: 0;">
                      <div style="font-weight: 700; font-size: 0.88rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                        ${this.escapeHtml(v.name)}
                        ${v.phone ? `<a href="tel:${this.escapeHtml(v.phone)}" style="font-size: 0.75rem; font-weight: 500; color: var(--primary); margin-left: 0.4rem;" title="Call ${this.escapeHtml(v.phone)}"><i class="fa-solid fa-phone"></i> ${this.escapeHtml(v.phone)}</a>` : ''}
                      </div>
                      <div style="height: 4px; border-radius: 2px; background: var(--slate-200); margin-top: 0.3rem; overflow: hidden;">
                        <div style="height: 100%; width: ${share.toFixed(1)}%; background: #dc2626;"></div>
                      </div>
                      <div style="font-size: 0.72rem; color: var(--slate-500); margin-top: 0.2rem;">
                        ${share.toFixed(0)}% of what the shop owes${v.orders ? ` &middot; ${v.orders} order(s), last ${this.escapeHtml(v.lastDate || 'date unknown')}` : ''}
                      </div>
                    </div>
                    <div style="text-align: right;">
                      <div style="font-family: monospace; font-weight: 800; font-size: 1rem; color: #dc2626; white-space: nowrap;">${this.formatCurrency(v.balance)}</div>
                      <a href="javascript:void(0)" onclick="app.showVendorStatementModal(${this.jsStr(String(v.id))})"
                         style="font-size: 0.7rem; color: var(--primary); font-weight: 600;">Statement &rarr;</a>
                    </div>
                  </div>`;
              }).join('')}
              ${data.supplierDebts.length > 6 ? `
                <div style="font-size: 0.78rem; color: var(--slate-500); text-align: center; padding-top: 0.25rem;">
                  and ${data.supplierDebts.length - 6} more in the supplier book
                </div>` : ''}
            </div>
          ` : `
            <div style="text-align: center; padding: 1.25rem; color: var(--slate-400); font-size: 0.88rem;">
              <i class="fa-solid fa-circle-check" style="color: #15803d; margin-right: 0.4rem;"></i>
              ${data.supplierAdvances.length > 0 ? 'Nothing is owed to a registered supplier.' : 'No registered supplier is carrying a balance.'}
            </div>
          `}

          ${data.supplierAdvances.length > 0 ? `
            <div style="margin-top: 0.85rem; padding-top: 0.75rem; border-top: 1px dashed var(--slate-200);">
              <div style="font-size: 0.74rem; color: var(--slate-500); text-transform: uppercase; letter-spacing: 0.04em; margin-bottom: 0.4rem;">
                Money sitting with a supplier (the shop owns it)
              </div>
              <div style="display: flex; flex-wrap: wrap; gap: 0.5rem;">
                ${data.supplierAdvances.slice(0, 6).map(v => `
                  <span class="badge badge-neutral" style="font-size: 0.78rem; padding: 0.35rem 0.6rem; color: #0369a1;">
                    ${this.escapeHtml(v.name)}: <strong style="font-family: monospace;">${this.formatCurrency(v.amount)}</strong>
                  </span>`).join('')}
              </div>
            </div>
          ` : ''}
        </div>
      </div>
    `;
  }
});
