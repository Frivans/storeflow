class StoreAppSession {
  constructor(storageAdapter = null) {
    this.storageAdapter = storageAdapter || {
      local: window.localStorage,
      session: window.sessionStorage
    };
    this.helper = typeof StoreFlowStorage !== 'undefined' ? new StoreFlowStorage() : null;
  }

  readText(storage, key, fallback = '') {
    if (!storage || typeof storage.getItem !== 'function') return fallback;
    try {
      const value = storage.getItem(key);
      return value !== null ? value : fallback;
    } catch (error) {
      return fallback;
    }
  }

  parseUser(rawValue) {
    if (!this.helper) {
      return null;
    }

    const parsed = this.helper.parseJson(rawValue, null);
    if (!parsed || typeof parsed !== 'object') {
      return null;
    }

    // Check if wrapped in session envelope with 14-hour TTL
    if (parsed.user && typeof parsed.user === 'object') {
      const savedAt = Number(parsed.saved_at) || 0;
      const MAX_SESSION_MS = 14 * 60 * 60 * 1000; // 14 hours (double shift limit)
      if (savedAt > 0 && (Date.now() - savedAt > MAX_SESSION_MS)) {
        this.clearActiveUser();
        return null;
      }
      return this.helper.normalizeStoredUser(parsed.user);
    }

    return this.helper.normalizeStoredUser(parsed);
  }

  restoreActiveUser() {
    const localUser = this.readText(this.storageAdapter.local, 'storeflow_active_user', null);
    const sessionUser = this.readText(this.storageAdapter.session, 'storeflow_active_user', null);
    const rawValue = localUser || sessionUser;
    return rawValue ? this.parseUser(rawValue) : null;
  }

  persistActiveUser(user, rememberMe = true) {
    if (!user || typeof user !== 'object') {
      return false;
    }

    const payload = {
      user: user,
      saved_at: Date.now()
    };
    const serialized = JSON.stringify(payload);
    if (rememberMe) {
      this.storageAdapter.local.setItem('storeflow_active_user', serialized);
      this.storageAdapter.session.removeItem('storeflow_active_user');
    } else {
      this.storageAdapter.session.setItem('storeflow_active_user', serialized);
      this.storageAdapter.local.removeItem('storeflow_active_user');
    }

    return true;
  }

  clearActiveUser() {
    try {
      this.storageAdapter.local.removeItem('storeflow_active_user');
      this.storageAdapter.session.removeItem('storeflow_active_user');
      return true;
    } catch (error) {
      return false;
    }
  }
}

if (typeof window !== 'undefined') {
  window.StoreAppSession = StoreAppSession;
}

if (typeof module !== 'undefined') {
  module.exports = { StoreAppSession };
}
