class StoreFlowStorage {
  parseJson(rawValue, fallback = null) {
    if (rawValue === null || rawValue === undefined || rawValue === '') {
      return fallback;
    }

    if (typeof rawValue !== 'string') {
      return rawValue ?? fallback;
    }

    try {
      const parsed = JSON.parse(rawValue);
      return parsed !== null ? parsed : fallback;
    } catch (error) {
      return fallback;
    }
  }

  readJsonFromStorage(storage, key, fallback = null) {
    if (!storage || typeof storage.getItem !== 'function') {
      return fallback;
    }

    return this.parseJson(storage.getItem(key), fallback);
  }

  writeJsonToStorage(storage, key, value) {
    if (!storage || typeof storage.setItem !== 'function') {
      return false;
    }

    try {
      storage.setItem(key, JSON.stringify(value));
      return true;
    } catch (error) {
      return false;
    }
  }

  readText(storage, key, fallback = '') {
    if (!storage || typeof storage.getItem !== 'function') {
      return fallback;
    }

    try {
      return storage.getItem(key) ?? fallback;
    } catch (error) {
      return fallback;
    }
  }

  writeText(storage, key, value) {
    if (!storage || typeof storage.setItem !== 'function') {
      return false;
    }

    try {
      storage.setItem(key, String(value));
      return true;
    } catch (error) {
      return false;
    }
  }

  normalizeStoredUser(rawUser) {
    if (!rawUser || typeof rawUser !== 'object') {
      return null;
    }

    return {
      id: rawUser.id ?? null,
      username: rawUser.username ?? '',
      full_name: rawUser.full_name ?? rawUser.name ?? '',
      // Role 2 is Store Manager. A stored account that arrives without a role was being
      // normalised into one of the most privileged roles in the shop; the server is the
      // authority on what any user may do, so the local copy defaults to the least.
      role_id: rawUser.role_id ?? 3,
      role_name: rawUser.role_name ?? 'Staff',
      branch_code: rawUser.branch_code ?? 'MAIN-01',
      // Left absent when the stored copy never carried one, rather than filled in as an empty
      // list. A session written on this machine before the Access Map's tick list travelled with
      // the login payload is exactly that case, and app-shell.js hasPerm() reads an absent list
      // as "this till has never been told" and asks the role name - the question this code asked
      // before the ticks existed. An empty list is the other fact: the owner unticked every box,
      // and nobody may open anything. Turning the first into the second signed a working shop
      // into an empty menu the morning it updated.
      ...(Array.isArray(rawUser.permissions) ? { permissions: rawUser.permissions } : {}),
      must_change_password: (rawUser.must_change_password ? 1 : 0),
      has_pin: Boolean(rawUser.has_pin),
      email: rawUser.email ?? '',
      phone: rawUser.phone ?? ''
    };
  }
}

if (typeof window !== 'undefined') {
  window.StoreFlowStorage = StoreFlowStorage;
}

if (typeof module !== 'undefined') {
  module.exports = { StoreFlowStorage };
}
