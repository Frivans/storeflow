Object.assign(StoreApp.prototype, {
  getVendorsHTML() {
    const search = (this.vendorSearchTerm || '').toLowerCase().trim();
    let filtered = this.vendors.filter(v => {
      const matchesSearch = !search ||
        (v.name && v.name.toLowerCase().includes(search)) ||
        (v.contact_person && v.contact_person.toLowerCase().includes(search)) ||
        (v.phone && v.phone.toLowerCase().includes(search)) ||
        (v.email && v.email.toLowerCase().includes(search));

      if (!matchesSearch) return false;
      const bal = Number(v.balance || 0);
      if (this.vendorFilter === 'DEBT') return bal > 0.01;
      if (this.vendorFilter === 'CREDIT') return bal < -0.01;
      if (this.vendorFilter === 'CLEARED') return Math.abs(bal) <= 0.01;
      return true;
    });

    // Two directions, two numbers. Summing them into one "Total Owed" headline let a
    // supplier holding our deposit cancel out a supplier we owed, so the figure on the
    // card matched neither of them.
    const totalAccountsPayable = this.vendors.reduce((sum, v) => sum + Math.max(0, Number(v.balance || 0)), 0);
    const totalAdvancesHeld = this.vendors.reduce((sum, v) => sum + Math.max(0, -Number(v.balance || 0)), 0);
    const vendorsWithDebtCount = this.vendors.filter(v => Number(v.balance || 0) > 0.01).length;
    const vendorsHoldingAdvances = this.vendors.filter(v => Number(v.balance || 0) < -0.01).length;

    return `
      <div class="panel">
        <div class="panel-header" style="flex-wrap: wrap; gap: 0.75rem;">
          <div>
            <h3><i class="fa-solid fa-truck-field"></i> Factory Suppliers & Accounts Payable</h3>
            <p style="font-size: 0.85rem; color: var(--slate-600); margin: 0.25rem 0 0 0;">Manage direct manufacturers, supply contracts, vendor credit ledgers, and accounts payable settlements.</p>
          </div>
          <div style="display: flex; gap: 0.5rem; align-items: center;">
            <button class="btn btn-outline" onclick="app.switchView('purchases')"><i class="fa-solid fa-truck-ramp-box"></i> View Purchase Orders</button>
            <button class="btn btn-success" onclick="app.openNewVendorModal()"><i class="fa-solid fa-plus"></i> Add Factory Supplier</button>
          </div>
        </div>

        <div class="panel-body">
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 1.5rem;">
            <div style="background: var(--slate-50); border: 1px solid var(--slate-200); border-radius: var(--radius-md); padding: 1rem;">
              <span style="font-size: 0.78rem; font-weight: 600; text-transform: uppercase; color: var(--slate-500); display: block;">Total Registered Suppliers</span>
              <div style="font-size: 1.5rem; font-weight: 800; color: var(--slate-900); margin-top: 0.25rem;"><i class="fa-solid fa-building" style="color: var(--primary); font-size: 1.25rem; margin-right: 0.35rem;"></i>${this.vendors.length}</div>
            </div>
            <div style="background: rgba(239, 68, 68, 0.05); border: 1px solid rgba(239, 68, 68, 0.2); border-radius: var(--radius-md); padding: 1rem;">
              <span style="font-size: 0.78rem; font-weight: 600; text-transform: uppercase; color: var(--danger); display: block;">We Owe Suppliers</span>
              <div style="font-size: 1.5rem; font-weight: 800; color: var(--danger); margin-top: 0.25rem;"><i class="fa-solid fa-hand-holding-dollar" style="font-size: 1.25rem; margin-right: 0.35rem;"></i>${this.formatCurrency(totalAccountsPayable)}</div>
            </div>
            <div style="background: ${vendorsHoldingAdvances > 0 ? 'rgba(16, 185, 129, 0.07)' : 'var(--slate-50)'}; border: 1px solid ${vendorsHoldingAdvances > 0 ? 'rgba(16, 185, 129, 0.3)' : 'var(--slate-200)'}; border-radius: var(--radius-md); padding: 1rem;">
              <span style="font-size: 0.78rem; font-weight: 600; text-transform: uppercase; color: ${vendorsHoldingAdvances > 0 ? 'var(--success)' : 'var(--slate-500)'}; display: block;">Suppliers Hold Our Advances</span>
              <div style="font-size: 1.5rem; font-weight: 800; color: ${vendorsHoldingAdvances > 0 ? 'var(--success)' : 'var(--slate-400)'}; margin-top: 0.25rem;"><i class="fa-solid fa-boxes-packing" style="font-size: 1.25rem; margin-right: 0.35rem;"></i>${this.formatCurrency(totalAdvancesHeld)}</div>
              <div style="font-size: 0.72rem; color: var(--slate-500); margin-top: 0.2rem;">${vendorsHoldingAdvances > 0 ? `Deliveries owed by ${vendorsHoldingAdvances} supplier${vendorsHoldingAdvances > 1 ? 's' : ''}` : 'Deposits paid for goods not yet received'}</div>
            </div>
            <div style="background: var(--slate-50); border: 1px solid var(--slate-200); border-radius: var(--radius-md); padding: 1rem;">
              <span style="font-size: 0.78rem; font-weight: 600; text-transform: uppercase; color: var(--slate-500); display: block;">Suppliers with Balance Due</span>
              <div style="font-size: 1.5rem; font-weight: 800; color: var(--slate-900); margin-top: 0.25rem;"><i class="fa-solid fa-clock-rotate-left" style="color: var(--warning); font-size: 1.25rem; margin-right: 0.35rem;"></i>${vendorsWithDebtCount} <span style="font-size: 0.85rem; font-weight: 500; color: var(--slate-500);">/ ${this.vendors.length}</span></div>
            </div>
          </div>

          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.25rem; flex-wrap: wrap; gap: 0.75rem;">
            <div style="display: flex; gap: 0.5rem; align-items: center; flex: 1; max-width: 420px;">
              <div style="position: relative; width: 100%;">
                <input type="text" id="vendor-search-input" class="form-control" placeholder="Search supplier name, contact, phone, or email..." value="${this.escapeHtml(this.vendorSearchTerm)}" style="padding-left: 2.2rem;">
                <i class="fa-solid fa-magnifying-glass" style="position: absolute; left: 0.8rem; top: 50%; transform: translateY(-50%); color: var(--slate-400);"></i>
              </div>
            </div>

            <div style="display: flex; gap: 0.4rem; align-items: center; flex-wrap: wrap;">
              <button class="btn btn-sm ${this.vendorFilter === 'ALL' ? 'btn-primary' : 'btn-outline'}" onclick="app.filterVendors('ALL')">All Suppliers (${this.vendors.length})</button>
              <button class="btn btn-sm ${this.vendorFilter === 'DEBT' ? 'btn-danger' : 'btn-outline'}" onclick="app.filterVendors('DEBT')" style="${this.vendorFilter === 'DEBT' ? 'background: var(--danger); color: #fff; border-color: var(--danger);' : ''}"><i class="fa-solid fa-circle-exclamation"></i> Owed Debt (${vendorsWithDebtCount})</button>
              <button class="btn btn-sm ${this.vendorFilter === 'CREDIT' ? 'btn-success' : 'btn-outline'}" onclick="app.filterVendors('CREDIT')" style="${this.vendorFilter === 'CREDIT' ? 'background: var(--success); color: #fff; border-color: var(--success);' : ''}"><i class="fa-solid fa-arrow-rotate-left"></i> Our Advances (${vendorsHoldingAdvances})</button>
              <button class="btn btn-sm ${this.vendorFilter === 'CLEARED' ? 'btn-success' : 'btn-outline'}" onclick="app.filterVendors('CLEARED')"><i class="fa-solid fa-circle-check"></i> Settled Accounts</button>
            </div>
          </div>

          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Supplier / Factory Name</th>
                  <th>Contact Person</th>
                  <th>Phone & Email</th>
                  <th>Payment Terms</th>
                  <th style="text-align: right;">Supplier Account</th>
                  <th style="text-align: center;">Actions</th>
                </tr>
              </thead>
              <tbody>
                ${filtered.length > 0 ? filtered.map(v => {
                  const bal = Number(v.balance || 0);
                  const isDebt = bal > 0.01;
                  const isAdvance = bal < -0.01;
                  // What the account was carried in with, shown beside the figure it grew into.
                  // A cashier without rights to supplier money sees null, not zero.
                  const carriedIn = Number(v.opening_amount || 0);
                  const carriesLine = v.balance === null ? '' : (Math.abs(carriedIn) < 0.005 ? '' :
                    `<div style="font-size: 0.7rem; color: var(--slate-500); margin-top: 0.15rem;" title="${this.escapeHtml(v.opening_note || '')}${v.opening_by ? ' &bull; ' + this.escapeHtml(v.opening_by) : ''}">
                      <i class="fa-solid fa-folder-open"></i> ${this.formatCurrency(Math.abs(carriedIn))} ${carriedIn > 0 ? 'debt' : 'advance'} carried in
                    </div>`);
                  const accountCell = v.balance === null
                    ? `<span style="font-size: 0.85rem; color: var(--slate-400);" title="Supplier accounts are restricted to managers">&mdash;</span>`
                    : (isDebt
                        ? `<div style="font-weight: 800; font-size: 1.05rem; color: var(--danger);">${this.formatCurrency(bal)}</div><span class="badge badge-warning" style="font-size: 0.7rem; padding: 0.15rem 0.4rem;"><i class="fa-solid fa-clock"></i> We owe them</span>`
                        : isAdvance
                          ? `<div style="font-weight: 800; font-size: 1.05rem; color: var(--success);">${this.formatCurrency(Math.abs(bal))}</div><span class="badge badge-success" style="font-size: 0.7rem; padding: 0.15rem 0.4rem;"><i class="fa-solid fa-boxes-packing"></i> Advance held</span>`
                          : `<div style="font-weight: 700; color: var(--success); font-size: 0.95rem;">${this.formatCurrency(0)}</div><span class="badge badge-success" style="font-size: 0.7rem; padding: 0.15rem 0.4rem;"><i class="fa-solid fa-check"></i> Settled</span>`);
                  return `
                    <tr>
                      <td>
                        <div style="font-weight: 700; color: var(--slate-900); font-size: 0.95rem;">${this.escapeHtml(v.name)}</div>
                        ${v.tax_id ? `<span style="font-size: 0.75rem; color: var(--slate-500); font-family: monospace;">TIN: ${this.escapeHtml(v.tax_id)}</span>` : ''}
                        ${v.address ? `<div style="font-size: 0.78rem; color: var(--slate-500);"><i class="fa-solid fa-location-dot" style="font-size: 0.7rem;"></i> ${this.escapeHtml(v.address)}</div>` : ''}
                      </td>
                      <td><span style="font-weight: 600;">${this.escapeHtml(v.contact_person || 'Direct Factory')}</span></td>
                      <td>
                        ${v.phone ? `<div><i class="fa-solid fa-phone" style="font-size: 0.75rem; color: var(--slate-400);"></i> <a href="tel:${this.escapeHtml(v.phone)}" style="color: var(--primary); text-decoration: none;">${this.escapeHtml(v.phone)}</a></div>` : ''}
                        ${v.email ? `<div style="font-size: 0.8rem; color: var(--slate-600);"><i class="fa-solid fa-envelope" style="font-size: 0.75rem; color: var(--slate-400);"></i> ${this.escapeHtml(v.email)}</div>` : ''}
                      </td>
                      <td><span class="badge badge-info" style="font-size: 0.78rem;">${this.escapeHtml(v.payment_terms || 'NET30')}</span></td>
                      <td style="text-align: right;">${accountCell}${carriesLine}</td>
                      <td style="text-align: center;">
                        <div style="display: inline-flex; gap: 0.35rem; align-items: center;">
                          <button class="btn btn-outline btn-sm" onclick="app.openVendorPaymentModal(${this.jsStr(v.id)})" title="Record Payout / Settle Debt" style="color: var(--primary); font-weight: 600;"><i class="fa-solid fa-money-bill-transfer"></i> Payout</button>
                          ${v.balance === null ? '' : `<button class="btn btn-outline btn-sm" onclick="app.openVendorOpeningModal(${this.jsStr(v.id)})" title="Book the balance this account starts with, from the paper book"><i class="fa-solid fa-folder-open"></i> Opening</button>`}
                          <button class="btn btn-outline btn-sm" onclick="app.showVendorStatementModal(${this.jsStr(v.id)})" title="Print Supplier Statement of Account"><i class="fa-solid fa-file-invoice"></i> Ledger</button>
                          <button class="btn btn-outline btn-sm" onclick="app.openEditVendorModal(${this.jsStr(v.id)})" title="Edit Supplier Profile"><i class="fa-solid fa-pen-to-square"></i></button>
                          <button class="btn btn-outline btn-sm" onclick="app.deleteVendor(${this.jsStr(v.id)})" title="Delete Supplier" style="color: var(--danger);"><i class="fa-solid fa-trash"></i></button>
                        </div>
                      </td>
                    </tr>
                  `;
                }).join('') : `
                  <tr><td colspan="6" style="text-align: center; padding: 3rem; color: var(--slate-400);"><i class="fa-solid fa-truck-field" style="font-size: 2.25rem; margin-bottom: 0.75rem; display: block;"></i>No suppliers found matching your criteria.</td></tr>
                `}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  },

  bindVendorsEvents() {
    const searchInput = document.getElementById('vendor-search-input');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        this.vendorSearchTerm = e.target.value;
        const container = document.getElementById('view-content-container');
        if (container) {
          container.innerHTML = this.getVendorsHTML();
          this.bindVendorsEvents();
          const newSearch = document.getElementById('vendor-search-input');
          if (newSearch) {
            newSearch.focus();
            newSearch.setSelectionRange(newSearch.value.length, newSearch.value.length);
          }
        }
      });
    }
  },

  filterVendors(status) {
    this.vendorFilter = status;
    const container = document.getElementById('view-content-container');
    if (container) {
      container.innerHTML = this.getVendorsHTML();
      this.bindVendorsEvents();
    }
  },

  openNewVendorModal() {
    const title = document.getElementById('vendor-modal-title');
    if (title) title.innerHTML = '<i class="fa-solid fa-truck-field"></i> Add Factory Supplier';

    document.getElementById('vendor-form-id').value = '';
    document.getElementById('vendor-form-name').value = '';
    document.getElementById('vendor-form-contact').value = '';
    document.getElementById('vendor-form-phone').value = '';
    document.getElementById('vendor-form-email').value = '';
    document.getElementById('vendor-form-address').value = '';
    document.getElementById('vendor-form-terms').value = 'NET30';
    document.getElementById('vendor-form-tax').value = '';
    document.getElementById('vendor-form-bank').value = '';
    document.getElementById('vendor-form-notes').value = '';

    document.getElementById('vendor-modal').classList.add('active');
  },

  openEditVendorModal(vendorId) {
    const vendor = this.vendors.find(v => String(v.id) === String(vendorId));
    if (!vendor) return;

    const title = document.getElementById('vendor-modal-title');
    if (title) title.innerHTML = '<i class="fa-solid fa-pen-to-square"></i> Edit Supplier Profile';

    document.getElementById('vendor-form-id').value = vendor.id || '';
    document.getElementById('vendor-form-name').value = vendor.name || '';
    document.getElementById('vendor-form-contact').value = vendor.contact_person || '';
    document.getElementById('vendor-form-phone').value = vendor.phone || '';
    document.getElementById('vendor-form-email').value = vendor.email || '';
    document.getElementById('vendor-form-address').value = vendor.address || '';
    document.getElementById('vendor-form-terms').value = vendor.payment_terms || 'NET30';
    document.getElementById('vendor-form-tax').value = vendor.tax_id || '';
    document.getElementById('vendor-form-bank').value = vendor.bank_details || '';
    document.getElementById('vendor-form-notes').value = vendor.notes || '';

    document.getElementById('vendor-modal').classList.add('active');
  },

  closeVendorModal() {
    const modal = document.getElementById('vendor-modal');
    if (modal) modal.classList.remove('active');
  },

  // --- Opening balance: the number an account starts with ---
  //
  // A shop that has traded with a factory for years does not begin its book at zero, and the
  // only door there used to be for that money was the balance column itself - a figure with no
  // date, no name behind it, and nothing on the statement but a line the till invented to make
  // the totals add up. This books it instead, so the supplier's paper shows where the number
  // came from and who put it there.

  openVendorOpeningModal(vendorId) {
    const vendor = this.vendors.find(v => String(v.id) === String(vendorId));
    if (!vendor) return;

    document.getElementById('vopen-vendor-id').value = vendor.id;
    document.getElementById('vopen-vendor-name').innerText = vendor.name;

    const carriedIn = Number(vendor.opening_amount || 0);
    const accountLine = document.getElementById('vopen-account-line');
    if (accountLine) {
      accountLine.innerHTML = Math.abs(carriedIn) >= 0.005
        ? `Already carries in <strong>${this.formatCurrency(Math.abs(carriedIn))}</strong>${vendor.opening_by ? ` &bull; booked by ${this.escapeHtml(vendor.opening_by)}` : ''}`
        : `This account starts at ${this.formatCurrency(0)}`;
    }

    // The amount never arrives filled in. A carry-in is entered once, from the paper, and a
    // box that quietly repeats last time's figure is how an account ends up owing two.
    document.getElementById('vopen-amount').value = '';
    document.getElementById('vopen-note').value = '';
    document.getElementById('vopen-date').value = new Date().toISOString().slice(0, 10);
    document.getElementById('vopen-direction').value = Number(vendor.balance || 0) < -0.01 ? 'ADVANCE' : 'DEBT';

    document.getElementById('vendor-opening-modal').classList.add('active');
    setTimeout(() => document.getElementById('vopen-amount').focus(), 150);
  },

  closeVendorOpeningModal() {
    const modal = document.getElementById('vendor-opening-modal');
    if (modal) modal.classList.remove('active');
  },

  async saveVendorOpening() {
    if (this._vendorOpeningInFlight) return;
    this._vendorOpeningInFlight = true;
    const saveBtn = document.getElementById('vopen-save-btn');
    if (saveBtn) saveBtn.disabled = true;
    try {
      await this.bookVendorOpening();
    } finally {
      this._vendorOpeningInFlight = false;
      if (saveBtn) saveBtn.disabled = false;
    }
  },

  async bookVendorOpening() {
    const vendorId = document.getElementById('vopen-vendor-id').value;
    const vendor = this.vendors.find(v => String(v.id) === String(vendorId));
    if (!vendor) return;

    const gross = Math.round((parseFloat(document.getElementById('vopen-amount').value) || 0) * 100) / 100;
    if (gross <= 0) {
      this.showToast('Enter the amount this account starts with.', 'warning');
      return;
    }
    const direction = document.getElementById('vopen-direction').value === 'ADVANCE' ? 'ADVANCE' : 'DEBT';
    const signed = direction === 'ADVANCE' ? -gross : gross;
    const note = document.getElementById('vopen-note').value.trim();
    const openingDate = document.getElementById('vopen-date').value || new Date().toISOString().slice(0, 10);

    const payload = {
      action: 'record_opening',
      vendor_id: vendorId,
      amount: gross,
      direction: direction,
      note: note,
      opening_date: openingDate,
      user_id: this.currentUser?.id || 1,
      officer_name: this.currentUser?.full_name || 'Store Manager'
    };

    // Ask the shop's books first, the same way a payout does. apiFetch does not throw on a
    // refusal, so writing the carry-in down before the answer lands is how a till ends up
    // showing a debt the shop never booked - and then booking it a second time on sync.
    let offline = !this.isOnline;
    let refusal = null;
    if (!offline) {
      let res = null;
      try {
        res = await this.apiFetch('api/endpoints/vendors.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
      } catch (err) {
        res = null;
      }
      if (res === null) {
        offline = true;
      } else {
        const verdict = await this.classifyApiResponse(res);
        if (verdict.verdict === 'refused') refusal = verdict.message;
        else if (verdict.verdict === 'unreachable') offline = true;
      }
    }

    if (refusal) {
      this.showToast(`Opening balance was NOT booked: ${refusal}`, 'danger', 14000);
      if (typeof this.fetchVendors === 'function') await this.fetchVendors();
      this.renderCurrentView();
      return;
    }

    // The account moves by this row on this till as well, so the supplier list tells the same
    // story as the statement whether or not the line is up.
    const mirror = Object.assign({}, vendor, {
      balance: Math.round(((Number(vendor.balance || 0) + signed)) * 100) / 100,
      opening_amount: signed,
      opening_note: note || 'Opening balance brought forward',
      opening_date: openingDate,
      opening_by: payload.officer_name
    });
    const idx = this.vendors.findIndex(v => String(v.id) === String(vendorId));
    if (idx !== -1) this.vendors[idx] = mirror; else this.vendors.unshift(mirror);
    if (localDB.vendors) await localDB.vendors.put(mirror);

    if (offline) {
      // Rides the supplier's own queue row: the profile is what travels, and the carry-in
      // travels with it as the row the shop books for itself. A second delivery of the same
      // figure lands on the same account and the key refuses it.
      try {
        await localDB.sync_outbox.add({
          entity: 'vendor',
          action: 'UPDATE',
          data: mirror,
          timestamp: new Date().toISOString(),
          synced: 0
        });
      } catch (queueErr) {
        this.showToast(
          `This carry-in could not be queued on this till (${queueErr && queueErr.message ? queueErr.message : 'storage error'}). The supplier's account has not been changed on the shop's books - book it again once the till has room.`,
          'danger', 14000
        );
        return;
      }
    }

    this.closeVendorOpeningModal();
    // Online, the shop's own figure is the one to show, so pull it back rather than keep the
    // till's arithmetic on screen. Offline, the row the shop has never seen stays.
    if (!offline && typeof this.fetchVendors === 'function') await this.fetchVendors();
    await this.logClientActivity(
      'VENDOR_OPENING',
      `Booked an opening balance of ${this.formatCurrency(gross)} (${direction === 'ADVANCE' ? 'advance held by them' : 'debt owed by us'}) on supplier '${vendor.name}'${offline ? ' - held on this till, waiting to sync' : ''}.`,
      offline
    );
    this.renderCurrentView();
    this.showToast(
      direction === 'ADVANCE'
        ? `${vendor.name} now holds ${this.formatCurrency(gross)} of this shop's money from before${offline ? ' (kept on this till until the line is back)' : ''}.`
        : `${vendor.name} now carries in ${this.formatCurrency(gross)} of debt${offline ? ' (kept on this till until the line is back)' : ''}.`,
      offline ? 'warning' : 'success', 11000
    );
  }
});
