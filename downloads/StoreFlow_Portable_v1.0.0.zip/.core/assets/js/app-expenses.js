// assets/js/app-expenses.js - Store Operating Expenses & Cash Drawer Payouts Controller

Object.assign(StoreApp.prototype, {
  expensesTimeFilter: 'all',
  expensesCategoryFilter: 'ALL',
  expensesSourceFilter: 'ALL',
  expensesSearchQuery: '',

  setExpensesTimeFilter(timeVal) {
    this.expensesTimeFilter = timeVal || 'all';
    this.renderCurrentView();
  },

  setExpensesCategoryFilter(cat) {
    this.expensesCategoryFilter = cat || 'ALL';
    this.renderCurrentView();
  },

  setExpensesSourceFilter(src) {
    this.expensesSourceFilter = src || 'ALL';
    this.renderCurrentView();
  },

  setExpensesSearchQuery(q) {
    this.expensesSearchQuery = (q || '').trim();
    this.renderCurrentView();
  },

  getFilteredExpensesList() {
    const list = this.expenses || [];
    const tFilter = this.expensesTimeFilter || 'all';
    const cFilter = this.expensesCategoryFilter || 'ALL';
    const sFilter = (this.expensesSourceFilter || 'ALL').toUpperCase();
    const query = (this.expensesSearchQuery || '').toLowerCase();

    const now = new Date();
    const todayStr = now.toISOString().slice(0, 10);
    const monthStr = now.toISOString().slice(0, 7);

    // Week calculation
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(now.getDate() - 7);
    const weekStr = oneWeekAgo.toISOString().slice(0, 10);

    return list.filter(exp => {
      const expDate = (exp.expense_date || exp.created_at || '').slice(0, 10);

      // 1. Time Filter
      if (tFilter === 'today' && expDate !== todayStr) return false;
      if (tFilter === 'week' && expDate < weekStr) return false;
      if (tFilter === 'month' && !expDate.startsWith(monthStr)) return false;

      // 2. Category Filter
      if (cFilter !== 'ALL' && exp.category !== cFilter) return false;

      // 3. Payment Source Filter
      if (sFilter !== 'ALL' && (exp.payment_source || 'CASH_DRAWER').toUpperCase() !== sFilter) return false;

      // 4. Branch Filter (if multi-branch active and user is branch-scoped)
      if (this.isMultiBranch && this.branchCode && this.branchCode !== 'ALL') {
        if (exp.branch_code && exp.branch_code !== 'ALL' && exp.branch_code !== this.branchCode) {
          return false;
        }
      }

      // 5. Search Query
      if (query) {
        const matchTitle = (exp.title || '').toLowerCase().includes(query);
        const matchNum = (exp.expense_number || '').toLowerCase().includes(query);
        const matchPaidTo = (exp.paid_to || '').toLowerCase().includes(query);
        const matchBy = (exp.recorded_by || '').toLowerCase().includes(query);
        const matchRef = (exp.receipt_ref || '').toLowerCase().includes(query);
        if (!matchTitle && !matchNum && !matchPaidTo && !matchBy && !matchRef) {
          return false;
        }
      }

      return true;
    });
  },

  getExpensesHTML() {
    const filtered = this.getFilteredExpensesList();
    const totalCount = filtered.length;

    let totalAmount = 0;
    let drawerPayoutsTotal = 0;
    let bankMomoTotal = 0;
    let pettyCashTotal = 0;

    filtered.forEach(e => {
      const amt = Number(e.amount || 0);
      totalAmount += amt;
      const src = (e.payment_source || 'CASH_DRAWER').toUpperCase();
      if (src === 'CASH_DRAWER') {
        drawerPayoutsTotal += amt;
      } else if (src === 'BANK_TRANSFER' || src === 'MOBILE_MONEY') {
        bankMomoTotal += amt;
      } else if (src === 'PETTY_CASH') {
        pettyCashTotal += amt;
      }
    });

    // Whole book, minus what a voided receipt never earned: the goods went back on the shelf and
    // the money went back to the customer, so its gross profit was never the shop's.
    const totalSalesProfit = (this.sales || [])
      .filter(s => !this.isVoidedSale(s))
      .reduce((sum, s) => sum + Number(s.gross_profit || 0), 0);
    const netStoreProfit = totalSalesProfit - totalAmount;
    const showsMargin = this.maySeeProductCost();

    const categories = [
      'ALL',
      'Generator & Fuel',
      'Utilities & Bills',
      'Shop Supplies & Packaging',
      'Transport & Logistics',
      'Maintenance & Repairs',
      'Staff Wage / Advance',
      'Refreshments & Meals',
      'Rent & Lease',
      'Miscellaneous'
    ];

    return `
      <div class="panel">
        <div class="panel-header" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.75rem;">
          <div>
            <h2 style="margin: 0; font-size: 1.25rem; font-weight: 700; color: var(--slate-800);">
              <i class="fa-solid fa-receipt" style="color: var(--primary);"></i> Store Expenses & Cash Drawer Payouts
            </h2>
            <p style="margin: 0.15rem 0 0 0; font-size: 0.8rem; color: var(--slate-500);">
              Track operational store expenses, petty cash, and register drawer payouts to balance cash shifts and profit
            </p>
          </div>
          <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
            <button type="button" class="btn btn-outline btn-sm" onclick="app.exportExpensesCSV()" title="Export filtered records to CSV">
              <i class="fa-solid fa-file-csv"></i> Export CSV
            </button>
            <button type="button" class="btn btn-primary" onclick="app.openExpenseModal()" style="font-weight: 700; display: inline-flex; align-items: center; gap: 0.45rem;">
              <i class="fa-solid fa-plus"></i> <span>Record New Expense</span>
            </button>
          </div>
        </div>

        <div class="panel-body">
          <!-- Stat Summary Cards -->
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 1.25rem;">
            <div class="card" style="padding: 1rem; border-left: 4px solid var(--danger);">
              <div style="font-size: 0.75rem; text-transform: uppercase; color: var(--slate-500); font-weight: 600;">Total Store Expenses</div>
              <div style="font-size: 1.45rem; font-weight: 800; color: var(--danger); margin: 0.25rem 0;">${this.formatCurrency(totalAmount)}</div>
              <div style="font-size: 0.75rem; color: var(--slate-500);">${totalCount} expense record${totalCount === 1 ? '' : 's'}</div>
            </div>

            <div class="card" style="padding: 1rem; border-left: 4px solid #ea580c; background: #fffaf0;">
              <div style="display: flex; justify-content: space-between; align-items: center;">
                <div style="font-size: 0.75rem; text-transform: uppercase; color: #c2410c; font-weight: 700;">
                  <i class="fa-solid fa-cash-register"></i> Drawer Payouts
                </div>
                <button type="button" class="btn btn-outline btn-sm" onclick="app.openExpenseModal('CASH_DRAWER')" style="font-size: 0.68rem; padding: 0.15rem 0.45rem; border-color: #fdba74; color: #c2410c;" title="Quick Drawer Payout">
                  + Payout
                </button>
              </div>
              <div style="font-size: 1.45rem; font-weight: 800; color: #ea580c; margin: 0.25rem 0;">${this.formatCurrency(drawerPayoutsTotal)}</div>
              <div style="font-size: 0.75rem; color: #9a3412;">Directly deducted from register shift cash</div>
            </div>

            <div class="card" style="padding: 1rem; border-left: 4px solid #0284c7;">
              <div style="font-size: 0.75rem; text-transform: uppercase; color: var(--slate-500); font-weight: 600;">Bank / Mobile Money</div>
              <div style="font-size: 1.45rem; font-weight: 800; color: #0284c7; margin: 0.25rem 0;">${this.formatCurrency(bankMomoTotal)}</div>
              <div style="font-size: 0.75rem; color: var(--slate-500);">Electronic & bank payouts</div>
            </div>

            <div class="card" style="padding: 1rem; border-left: 4px solid #8b5cf6;">
              <div style="font-size: 0.75rem; text-transform: uppercase; color: var(--slate-500); font-weight: 600;">Petty Cash / Other</div>
              <div style="font-size: 1.45rem; font-weight: 800; color: #7c3aed; margin: 0.25rem 0;">${this.formatCurrency(pettyCashTotal)}</div>
              <div style="font-size: 0.75rem; color: var(--slate-500);">Office float or owner pocket</div>
            </div>

            ${showsMargin ? `
            <div class="card" style="padding: 1rem; border-left: 4px solid ${netStoreProfit >= 0 ? '#10b981' : '#ef4444'}; background: ${netStoreProfit >= 0 ? '#f0fdf4' : '#fef2f2'};">
              <div style="font-size: 0.75rem; text-transform: uppercase; color: ${netStoreProfit >= 0 ? '#15803d' : '#b91c1c'}; font-weight: 700;">
                <i class="fa-solid fa-scale-balanced"></i> Net Store Profit
              </div>
              <div style="font-size: 1.45rem; font-weight: 800; color: ${netStoreProfit >= 0 ? '#15803d' : '#b91c1c'}; margin: 0.25rem 0;">${this.formatCurrency(netStoreProfit)}</div>
              <div style="font-size: 0.75rem; color: #475569;">Gross ${this.formatCurrency(totalSalesProfit)} &minus; Exp ${this.formatCurrency(totalAmount)}</div>
            </div>
            ` : ''}
          </div>

          <!-- Filter & Search Toolbar -->
          <div style="display: flex; gap: 0.65rem; margin-bottom: 1.25rem; flex-wrap: wrap; align-items: center; background: var(--slate-50); padding: 0.85rem; border-radius: var(--radius-md); border: 1px solid var(--slate-200);">
            <div style="flex: 1; min-width: 220px; position: relative;">
              <i class="fa-solid fa-magnifying-glass" style="position: absolute; left: 0.85rem; top: 50%; transform: translateY(-50%); color: var(--slate-400); font-size: 0.85rem;"></i>
              <input type="text" id="expense-search-input" class="form-control" placeholder="Search by title, recipient, staff, expense #..." style="padding-left: 2.2rem; font-size: 0.85rem;" value="${this.escapeHtml(this.expensesSearchQuery)}" oninput="app.setExpensesSearchQuery(this.value)">
            </div>

            <!-- Time Filter -->
            <select class="form-control" style="width: auto; min-width: 135px; font-size: 0.85rem;" onchange="app.setExpensesTimeFilter(this.value)">
              <option value="all" ${this.expensesTimeFilter === 'all' ? 'selected' : ''}>All Time</option>
              <option value="today" ${this.expensesTimeFilter === 'today' ? 'selected' : ''}>Today</option>
              <option value="week" ${this.expensesTimeFilter === 'week' ? 'selected' : ''}>This Week</option>
              <option value="month" ${this.expensesTimeFilter === 'month' ? 'selected' : ''}>This Month</option>
            </select>

            <!-- Category Filter -->
            <select class="form-control" style="width: auto; min-width: 175px; font-size: 0.85rem;" onchange="app.setExpensesCategoryFilter(this.value)">
              ${categories.map(c => `
                <option value="${this.escapeHtml(c)}" ${this.expensesCategoryFilter === c ? 'selected' : ''}>${c === 'ALL' ? 'All Categories' : this.escapeHtml(c)}</option>
              `).join('')}
            </select>

            <!-- Payment Source Filter -->
            <select class="form-control" style="width: auto; min-width: 160px; font-size: 0.85rem;" onchange="app.setExpensesSourceFilter(this.value)">
              <option value="ALL" ${this.expensesSourceFilter === 'ALL' ? 'selected' : ''}>All Sources</option>
              <option value="CASH_DRAWER" ${this.expensesSourceFilter === 'CASH_DRAWER' ? 'selected' : ''}>Cash Drawer</option>
              <option value="BANK_TRANSFER" ${this.expensesSourceFilter === 'BANK_TRANSFER' ? 'selected' : ''}>Bank Transfer</option>
              <option value="MOBILE_MONEY" ${this.expensesSourceFilter === 'MOBILE_MONEY' ? 'selected' : ''}>Mobile Money</option>
              <option value="PETTY_CASH" ${this.expensesSourceFilter === 'PETTY_CASH' ? 'selected' : ''}>Petty Cash Float</option>
              <option value="OWNER_POCKET" ${this.expensesSourceFilter === 'OWNER_POCKET' ? 'selected' : ''}>Owner's Pocket</option>
            </select>

            ${(this.expensesSearchQuery || this.expensesTimeFilter !== 'all' || this.expensesCategoryFilter !== 'ALL' || this.expensesSourceFilter !== 'ALL') ? `
              <button type="button" class="btn btn-outline btn-sm" onclick="app.resetExpensesFilters()" style="padding: 0.5rem 0.75rem;" title="Reset all filters">
                <i class="fa-solid fa-rotate-left"></i> Reset
              </button>
            ` : ''}
          </div>

          <!-- Expenses Table / Mobile List -->
          <div class="table-responsive">
            <table class="data-table" id="expenses-table">
              <thead>
                <tr>
                  <th>Date & Time</th>
                  <th>Expense #</th>
                  <th>Title / Purpose</th>
                  <th>Category</th>
                  <th>Payment Source</th>
                  <th>Paid To</th>
                  <th>Recorded By</th>
                  <th style="text-align: right;">Amount</th>
                  <th style="text-align: center; width: 60px;">Action</th>
                </tr>
              </thead>
              <tbody>
                ${filtered.length > 0 ? filtered.map(exp => {
                  const src = (exp.payment_source || 'CASH_DRAWER').toUpperCase();
                  let srcBadge = '';
                  if (src === 'CASH_DRAWER') {
                    srcBadge = `<span class="badge" style="background: #fef2f2; color: #dc2626; border: 1px solid #fecaca;"><i class="fa-solid fa-cash-register"></i> Cash Drawer</span>`;
                  } else if (src === 'MOBILE_MONEY') {
                    srcBadge = `<span class="badge" style="background: #eff6ff; color: #2563eb; border: 1px solid #bfdbfe;"><i class="fa-solid fa-mobile-screen"></i> MoMo</span>`;
                  } else if (src === 'BANK_TRANSFER') {
                    srcBadge = `<span class="badge" style="background: #f5f3ff; color: #7c3aed; border: 1px solid #ddd6fe;"><i class="fa-solid fa-building-columns"></i> Bank</span>`;
                  } else if (src === 'PETTY_CASH') {
                    srcBadge = `<span class="badge" style="background: #f0fdf4; color: #166534; border: 1px solid #bbf7d0;"><i class="fa-solid fa-vault"></i> Petty Cash</span>`;
                  } else {
                    srcBadge = `<span class="badge badge-neutral">${this.escapeHtml(src)}</span>`;
                  }

                  const dateOnly = (exp.expense_date || exp.created_at || '').slice(0, 10);
                  const timeOnly = exp.created_at ? exp.created_at.slice(11, 16) : '';

                  return `
                    <tr>
                      <td data-label="Date">
                        <strong>${this.escapeHtml(dateOnly)}</strong>
                        ${timeOnly ? `<div style="font-size: 0.72rem; color: var(--slate-400);">${timeOnly}</div>` : ''}
                      </td>
                      <td data-label="Expense #">
                        <span style="font-family: monospace; font-weight: 600; color: var(--slate-700);">${this.escapeHtml(exp.expense_number || 'EXP---')}</span>
                        ${exp.receipt_ref ? `<div style="font-size: 0.7rem; color: #64748b;">Ref: ${this.escapeHtml(exp.receipt_ref)}</div>` : ''}
                      </td>
                      <td data-label="Title / Purpose">
                        <strong>${this.escapeHtml(exp.title || 'Expense')}</strong>
                        ${exp.notes ? `<div style="font-size: 0.74rem; color: var(--slate-500); font-style: italic;">"${this.escapeHtml(exp.notes)}"</div>` : ''}
                      </td>
                      <td data-label="Category">
                        <span class="badge badge-neutral" style="font-size: 0.72rem;">${this.escapeHtml(exp.category || 'General')}</span>
                      </td>
                      <td data-label="Payment Source">
                        ${srcBadge}
                      </td>
                      <td data-label="Paid To">
                        <span style="color: var(--slate-700); font-weight: 500;">${this.escapeHtml(exp.paid_to || '—')}</span>
                      </td>
                      <td data-label="Recorded By">
                        <span style="font-size: 0.8rem; color: var(--slate-600);">${this.escapeHtml(exp.recorded_by || 'Staff')}</span>
                      </td>
                      <td data-label="Amount" style="text-align: right;">
                        <strong style="color: var(--danger); font-size: 0.95rem;">-${this.formatCurrency(exp.amount)}</strong>
                      </td>
                      <td data-label="Action" style="text-align: center;">
                        <button type="button" class="btn btn-outline btn-sm" onclick="app.promptDeleteExpense(${this.jsStr(exp.id)})" style="color: var(--danger); border-color: var(--danger-border); padding: 0.25rem 0.5rem;" title="Delete expense record">
                          <i class="fa-solid fa-trash-can"></i>
                        </button>
                      </td>
                    </tr>
                  `;
                }).join('') : `
                  <tr>
                    <td colspan="9" style="text-align: center; padding: 3rem 1rem; color: var(--slate-400);">
                      <i class="fa-solid fa-receipt" style="font-size: 2.5rem; margin-bottom: 0.75rem; display: block; opacity: 0.4;"></i>
                      <div style="font-size: 0.95rem; font-weight: 600; color: var(--slate-600); margin-bottom: 0.25rem;">No store expenses found</div>
                      <span style="font-size: 0.78rem;">Click <strong>+ Record New Expense</strong> to log shop outlays, bills, or cash drawer payouts.</span>
                    </td>
                  </tr>
                `}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  },

  bindExpensesEvents() {
    // Search auto-focus restore if needed
    const searchInput = document.getElementById('expense-search-input');
    if (searchInput && document.activeElement && document.activeElement.id === 'expense-search-input') {
      searchInput.focus();
      searchInput.setSelectionRange(searchInput.value.length, searchInput.value.length);
    }
  },

  resetExpensesFilters() {
    this.expensesTimeFilter = 'all';
    this.expensesCategoryFilter = 'ALL';
    this.expensesSourceFilter = 'ALL';
    this.expensesSearchQuery = '';
    this.renderCurrentView();
  },

  openExpenseModal(presetSource = null) {
    const modal = document.getElementById('expense-modal');
    if (!modal) return;

    // Reset fields
    const form = document.getElementById('expense-form');
    if (form) form.reset();

    const dateInput = document.getElementById('expense-form-date');
    if (dateInput) dateInput.value = new Date().toISOString().slice(0, 10);

    const sourceSelect = document.getElementById('expense-form-source');
    if (sourceSelect) {
      sourceSelect.value = presetSource || 'CASH_DRAWER';
    }

    const drawerHint = document.getElementById('expense-form-drawer-hint');
    if (drawerHint) {
      drawerHint.style.display = (sourceSelect?.value === 'CASH_DRAWER') ? 'block' : 'none';
    }

    modal.classList.add('active');

    setTimeout(() => {
      const titleInput = document.getElementById('expense-form-title');
      if (titleInput) titleInput.focus();
    }, 150);
  },

  closeExpenseModal() {
    const modal = document.getElementById('expense-modal');
    if (modal) modal.classList.remove('active');
  },

  onExpenseSourceChange(newSource) {
    const drawerHint = document.getElementById('expense-form-drawer-hint');
    if (drawerHint) {
      drawerHint.style.display = (newSource === 'CASH_DRAWER') ? 'block' : 'none';
    }
  },

  async submitExpenseForm() {
    if (this._submittingExpense) return;
    this._submittingExpense = true;

    try {
      const titleInput = document.getElementById('expense-form-title');
      const amountInput = document.getElementById('expense-form-amount');
      const catSelect = document.getElementById('expense-form-category');
      const srcSelect = document.getElementById('expense-form-source');
      const paidToInput = document.getElementById('expense-form-paid-to');
      const refInput = document.getElementById('expense-form-receipt-ref');
      const dateInput = document.getElementById('expense-form-date');
      const notesInput = document.getElementById('expense-form-notes');

      const title = titleInput ? titleInput.value.trim() : '';
      const amount = amountInput ? parseFloat(amountInput.value) : 0;
      const category = catSelect ? catSelect.value : 'General';
      const paymentSource = srcSelect ? srcSelect.value : 'CASH_DRAWER';
      const paidTo = paidToInput ? paidToInput.value.trim() : '';
      const receiptRef = refInput ? refInput.value.trim() : '';
      const expenseDate = dateInput ? dateInput.value : new Date().toISOString().slice(0, 10);
      const notes = notesInput ? notesInput.value.trim() : '';

      if (!title) {
        this.showToast('Please enter an expense title or purpose', 'warning');
        if (titleInput) titleInput.focus();
        return;
      }

      if (isNaN(amount) || amount <= 0) {
        this.showToast('Please enter a valid expense amount greater than zero', 'warning');
        if (amountInput) amountInput.focus();
        return;
      }

      const activeShift = this.activeShift || (this.shifts && this.shifts.find(s => !s.end_time)) || null;
      const shiftId = activeShift ? activeShift.id : null;

      const result = await this.recordExpense({
        title,
        amount,
        category,
        payment_source: paymentSource,
        paid_to: paidTo,
        receipt_ref: receiptRef,
        expense_date: expenseDate,
        notes,
        shift_id: shiftId,
        branch_code: this.branchCode || 'MAIN-01',
        terminal_id: this.terminalId || 'REG-01'
      });

      if (result) {
        this.closeExpenseModal();

        // If active view is expenses, refresh view
        if (this.currentView === 'expenses') {
          this.renderCurrentView();
        }

        // If shift report modal is currently open, refresh shift calculations!
        const shiftModal = document.getElementById('shift-report-modal');
        if (shiftModal && shiftModal.classList.contains('active')) {
          this.openShiftReportModal();
        }
      }
    } catch (err) {
      console.error('submitExpenseForm caught error:', err);
      this.showToast('Failed to save expense: ' + (err.message || 'Unknown error'), 'danger');
    } finally {
      this._submittingExpense = false;
    }
  },

  promptDeleteExpense(id) {
    if (!id) return;
    const exp = (this.expenses || []).find(e => e.id === id);
    const label = exp ? `"${exp.title}" (${this.formatCurrency(exp.amount)})` : 'this expense record';

    if (confirm(`Are you sure you want to delete ${label}? This cannot be undone.`)) {
      this.deleteExpense(id).then(success => {
        if (success && this.currentView === 'expenses') {
          this.renderCurrentView();
        }
      });
    }
  },

  exportExpensesCSV() {
    const filtered = this.getFilteredExpensesList();
    if (filtered.length === 0) {
      this.showToast('No expense records to export', 'warning');
      return;
    }

    const headers = ['Date', 'Expense Number', 'Title', 'Category', 'Payment Source', 'Paid To', 'Recorded By', 'Amount', 'Receipt Ref', 'Notes'];
    const rows = filtered.map(e => [
      `"${e.expense_date || ''}"`,
      `"${e.expense_number || ''}"`,
      `"${(e.title || '').replace(/"/g, '""')}"`,
      `"${(e.category || '').replace(/"/g, '""')}"`,
      `"${e.payment_source || 'CASH_DRAWER'}"`,
      `"${(e.paid_to || '').replace(/"/g, '""')}"`,
      `"${(e.recorded_by || '').replace(/"/g, '""')}"`,
      Number(e.amount || 0).toFixed(2),
      `"${(e.receipt_ref || '').replace(/"/g, '""')}"`,
      `"${(e.notes || '').replace(/"/g, '""')}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `store_expenses_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    this.showToast('Expenses CSV exported successfully', 'success');
  }
});
