// assets/js/app-estimates.js
// Price Quotations & Proforma Invoices (Estimates Engine)
// Offline-first with IndexedDB and SQLite synchronization

Object.assign(StoreApp.prototype, {
  currentEstimates: [],
  estimatesFilter: 'all',
  activePreviewEstimate: null,
  activeConvertingEstimateId: null,

  saveCartAsEstimate() {
    if (!this.cart || this.cart.length === 0) {
      this.showToast('Please add at least one product to the cart first.', 'warning');
      return;
    }
    this.openNewEstimateModal();
  },

  startNewEstimateFlow() {
    this.closeEstimatesModal();
    if (this.cart && this.cart.length > 0) {
      this.openNewEstimateModal();
      return;
    }
    if (typeof this.switchView === 'function') {
      this.switchView('pos');
    }
    this.showToast('Add items to the POS Cart, then click "Proforma / Estimate" to create a quotation.', 'info');
    setTimeout(() => {
      const searchEl = document.getElementById('pos-search');
      if (searchEl) searchEl.focus();
    }, 150);
  },

  openNewEstimateModal() {
    let overlay = document.getElementById('modal-new-estimate');
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = 'modal-new-estimate';
      overlay.className = 'modal-overlay';
      document.body.appendChild(overlay);
    }

    const { totalAmount: total } = this.getCartTotals();
    const custSelect = document.getElementById('pos-customer-select') || document.getElementById('pos-customer');
    const custId = custSelect ? custSelect.value : (this.selectedCustomerId || 'cust-walkin');
    const customerObj = (this.customers || []).find(c => c.id === custId);
    const defaultCustName = customerObj && customerObj.id !== 'cust-walkin' ? customerObj.name : '';
    const defaultCustPhone = customerObj && customerObj.phone ? customerObj.phone : '';

    const defaultValidity = Math.max(1, parseInt(this.storeProfile?.estimate_validity_days || 7, 10));
    const today = new Date();
    const expiryDate = new Date(today.getTime() + defaultValidity * 86400000);
    const expiryStr = expiryDate.toISOString().slice(0, 10);
    const itemCount = (this.cart || []).reduce((sum, it) => sum + Number(it.quantity || 1), 0);

    overlay.innerHTML = `
      <div class="modal-content" style="background:#ffffff; border-radius:12px; max-width:520px; width:100%; box-shadow:0 25px 50px -12px rgba(0,0,0,0.25); overflow:hidden;">
        <div style="padding:1.1rem 1.4rem; border-bottom:1px solid var(--slate-200); display:flex; justify-content:space-between; align-items:center; background:#f0f9ff;">
          <div>
            <h3 style="margin:0; font-size:1.15rem; font-weight:800; color:#0369a1; display:flex; align-items:center; gap:0.45rem;">
              <i class="fa-solid fa-file-invoice" style="color:#0284c7;"></i> Create Price Quotation / Proforma
            </h3>
            <p style="margin:2px 0 0; font-size:0.78rem; color:#0284c7;">Lock prices and terms for prospective buyers without taking inventory off shelves.</p>
          </div>
          <button type="button" class="btn btn-outline btn-sm" onclick="app.closeNewEstimateModal()" style="border:none; color:var(--slate-400); font-size:1.2rem; cursor:pointer;">
            <i class="fa-solid fa-xmark"></i>
          </button>
        </div>

        <form id="new-estimate-form" onsubmit="event.preventDefault(); app.confirmNewEstimate();" style="padding:1.25rem 1.4rem; display:flex; flex-direction:column; gap:0.9rem;">
          <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:0.75rem 1rem; display:flex; justify-content:space-between; align-items:center;">
            <div>
              <span style="font-size:0.75rem; color:var(--slate-500); text-transform:uppercase; font-weight:700;">Cart Summary</span>
              <div style="font-size:0.88rem; font-weight:700; color:var(--slate-800);">${itemCount} item(s) selected</div>
            </div>
            <div style="text-align:right;">
              <span style="font-size:0.75rem; color:var(--slate-500); text-transform:uppercase; font-weight:700;">Total Quoted</span>
              <div style="font-size:1.15rem; font-weight:800; color:#0284c7;">${this.formatCurrency(total)}</div>
            </div>
          </div>

          <div>
            <label class="form-label" style="font-size:0.78rem; font-weight:700;">Customer or Company Name *</label>
            <input type="text" id="estimate-cust-name" class="form-control" required value="${this.escapeHtml(defaultCustName)}" placeholder="e.g. Kwame Mensah / Church Committee" style="font-size:0.88rem;">
          </div>

          <div>
            <label class="form-label" style="font-size:0.78rem; font-weight:700;">Phone Number (Optional - for WhatsApp & SMS)</label>
            <input type="tel" id="estimate-cust-phone" class="form-control" value="${this.escapeHtml(defaultCustPhone)}" placeholder="e.g. 0244123456" style="font-size:0.88rem;">
          </div>

          <div style="display:grid; grid-template-columns:1fr 1fr; gap:0.75rem; align-items:flex-start;">
            <div>
              <label class="form-label" style="font-size:0.78rem; font-weight:700;">Validity Duration (Days) *</label>
              <input type="number" id="estimate-validity-days" class="form-control" min="1" max="365" step="1" required 
                     value="${defaultValidity}" 
                     oninput="app.updateEstimateModalExpiryPreview()" 
                     style="font-size:0.95rem; font-weight:700; color:#0369a1;">
            </div>
            <div>
              <label class="form-label" style="font-size:0.78rem; font-weight:700;">Guaranteed Expiry Date</label>
              <div id="estimate-expiry-preview" style="font-size:0.85rem; font-weight:700; color:#0284c7; padding:0.55rem 0.75rem; background:#eff6ff; border:1px solid #bfdbfe; border-radius:6px; display:flex; align-items:center; gap:0.35rem;">
                <i class="fa-solid fa-calendar-check"></i> <span>${expiryStr}</span>
              </div>
            </div>
          </div>

          <div>
            <label class="form-label" style="font-size:0.78rem; font-weight:700;">Notes & Price Terms</label>
            <textarea id="estimate-notes" class="form-control" rows="2" style="font-size:0.82rem;" placeholder="e.g. Prices valid for ${defaultValidity} days from date of issue.">Prices valid for ${defaultValidity} days from date of issue.</textarea>
          </div>

          <div style="display:flex; justify-content:flex-end; gap:0.5rem; margin-top:0.5rem; border-top:1px solid #e2e8f0; padding-top:0.75rem;">
            <button type="button" class="btn btn-outline" onclick="app.closeNewEstimateModal()">Cancel</button>
            <button type="submit" class="btn btn-primary" style="background:#0284c7; border-color:#0369a1; font-weight:700; padding:0.55rem 1.25rem;">
              <i class="fa-solid fa-file-invoice"></i> Generate & View Quotation
            </button>
          </div>
        </form>
      </div>
    `;

    overlay.classList.add('active');
    overlay.style.display = 'flex';
  },

  updateEstimateModalExpiryPreview() {
    const daysInp = document.getElementById('estimate-validity-days');
    const prevEl = document.getElementById('estimate-expiry-preview');
    const notesInp = document.getElementById('estimate-notes');
    const days = Math.max(1, parseInt(daysInp?.value || 7, 10));
    const today = new Date();
    const expiry = new Date(today.getTime() + days * 86400000);
    const dateStr = expiry.toISOString().slice(0, 10);
    if (prevEl) {
      prevEl.innerHTML = `<i class="fa-solid fa-calendar-check"></i> <span>${dateStr} (${days}d)</span>`;
    }
    if (notesInp && notesInp.value.startsWith('Prices valid for')) {
      notesInp.value = `Prices valid for ${days} days from date of issue.`;
    }
  },

  closeNewEstimateModal() {
    const overlay = document.getElementById('modal-new-estimate');
    if (overlay) {
      overlay.classList.remove('active');
      overlay.style.display = 'none';
    }
  },

  async confirmNewEstimate() {
    if (!this.cart || this.cart.length === 0) {
      this.showToast('Please add at least one product to the cart first.', 'warning');
      this.closeNewEstimateModal();
      return;
    }

    const customerName = document.getElementById('estimate-cust-name')?.value.trim() || 'Walk-in Customer';
    const customerPhone = document.getElementById('estimate-cust-phone')?.value.trim() || '';
    const validityDays = Math.max(1, parseInt(document.getElementById('estimate-validity-days')?.value || 7, 10));
    const customNotes = document.getElementById('estimate-notes')?.value.trim() || `Prices valid for ${validityDays} days from date of issue.`;

    const { subtotal, discount, taxRate, tax, totalAmount: total } = this.getCartTotals();
    const custSelect = document.getElementById('pos-customer-select') || document.getElementById('pos-customer');
    const custId = custSelect ? custSelect.value : (this.selectedCustomerId || 'cust-walkin');

    const today = new Date();
    const validUntilDate = new Date(today.getTime() + validityDays * 86400000);
    const validUntilStr = validUntilDate.toISOString().slice(0, 10);

    const todayStr = today.toISOString().slice(0, 10).replace(/-/g, '');
    const randSuffix = Math.floor(1000 + Math.random() * 9000);
    const estimateNumber = `EST-${todayStr}-${randSuffix}`;
    const estimateId = `est-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;
    const nowIso = new Date().toISOString().slice(0, 19).replace('T', ' ');

    const estimateItems = this.cart.map(i => {
      const unitLabel = i.selected_unit || i.unit || 'pcs';
      const isPack = i.multiplier && Number(i.multiplier) > 1;
      const unitPrice = Number(i.selling_price || i.price || 0);
      const qty = Number(i.quantity || 1);
      const prodId = i.product_id || i.id;
      return {
        product_id: prodId,
        id: prodId,
        name: i.name,
        sku: i.sku || '',
        quantity: qty,
        unit: unitLabel,
        multiplier: i.multiplier || 1,
        base_unit: i.base_unit || '',
        is_pack: isPack,
        selling_price: unitPrice,
        subtotal: unitPrice * qty
      };
    });

    const attendant = this.currentUser ? (this.currentUser.full_name || this.currentUser.username) : 'Cashier';

    const estimate = {
      id: estimateId,
      estimate_number: estimateNumber,
      customer_id: custId,
      customer_name: customerName,
      customer_phone: customerPhone,
      created_by_name: attendant,
      estimate_date: nowIso,
      valid_until: validUntilStr,
      subtotal: subtotal,
      discount: discount,
      tax: tax,
      tax_rate: taxRate,
      total_amount: total,
      notes: customNotes,
      status: 'PENDING',
      items: estimateItems,
      branch_code: this.currentBranchCode || 'MAIN-01',
      created_at: nowIso,
      updated_at: nowIso,
      synced: 0
    };

    this.closeNewEstimateModal();

    // 1. Save to local IndexedDB
    try {
      if (window.localDB && localDB.estimates) {
        await localDB.estimates.put(estimate);
      }
    } catch (e) {
      console.warn('Could not save estimate to IndexedDB:', e);
    }

    // 2. Sync to Backend API if online
    if (this.isOnline) {
      try {
        await this.apiFetch('api/endpoints/estimates.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'create',
            ...estimate
          })
        });
      } catch (err) {
        console.warn('Could not sync estimate to server:', err);
      }
    }

    this.showToast(`Quotation ${estimateNumber} created (${validityDays} days validity)!`, 'success');

    // 3. Open Preview Modal
    this.showEstimateModal(estimate);

    // 4. Prompt to clear or keep cart
    if (typeof this.showConfirmModal === 'function') {
      const shouldClear = await this.showConfirmModal({
        title: 'Clear POS Cart?',
        message: 'The quotation has been saved. Would you like to clear the cart for the next customer?',
        confirmText: 'Clear Cart',
        cancelText: 'Keep Items'
      });
      if (shouldClear) {
        this.clearCart();
      }
    }
  },

  async openEstimatesModal() {
    const modal = document.getElementById('estimates-modal');
    if (!modal) return;

    modal.classList.add('active');
    await this.loadEstimates();
  },

  closeEstimatesModal() {
    const modal = document.getElementById('estimates-modal');
    if (modal) modal.classList.remove('active');
  },

  async loadEstimates() {
    let list = [];

    // 1. Load from IndexedDB
    try {
      if (window.localDB && localDB.estimates) {
        list = await localDB.estimates.orderBy('created_at').reverse().toArray();
      }
    } catch (e) {
      console.warn('Error reading estimates from IndexedDB:', e);
    }

    // 2. Fetch from Backend if online
    if (this.isOnline) {
      try {
        const res = await this.apiFetch('api/endpoints/estimates.php?status=all');
        const data = await res.json();
        if (data.success && Array.isArray(data.estimates)) {
          list = data.estimates;
          // Sync local IndexedDB mirror with server state (including after deletes or DB reset)
          if (window.localDB && localDB.estimates) {
            await localDB.estimates.clear();
            if (list.length > 0) {
              await localDB.estimates.bulkPut(list);
            }
          }
        }
      } catch (err) {
        console.warn('Network fetch estimates failed, using local DB:', err);
      }
    }

    this.currentEstimates = list;
    this.renderEstimatesTable();
  },

  setEstimatesFilter(status) {
    this.estimatesFilter = status;
    ['all', 'pending', 'converted'].forEach(s => {
      const btn = document.getElementById(`filter-est-${s}`);
      if (btn) {
        if (s === status) {
          btn.style.background = 'var(--primary)';
          btn.style.color = '#ffffff';
        } else {
          btn.style.background = 'transparent';
          btn.style.color = 'var(--slate-700)';
        }
      }
    });
    this.renderEstimatesTable();
  },

  filterEstimatesList() {
    this.renderEstimatesTable();
  },

  renderEstimatesTable() {
    const container = document.getElementById('estimates-table-container');
    const countLabel = document.getElementById('estimates-count-label');
    if (!container) return;

    const searchTerm = (document.getElementById('estimates-search')?.value || '').trim().toLowerCase();
    const filter = this.estimatesFilter || 'all';

    let list = this.currentEstimates || [];

    if (filter === 'pending') {
      list = list.filter(e => (e.status || 'PENDING').toUpperCase() === 'PENDING');
    } else if (filter === 'converted') {
      list = list.filter(e => (e.status || '').toUpperCase() === 'CONVERTED');
    }

    if (searchTerm) {
      list = list.filter(e =>
        (e.estimate_number || '').toLowerCase().includes(searchTerm) ||
        (e.customer_name || '').toLowerCase().includes(searchTerm) ||
        (e.customer_phone || '').toLowerCase().includes(searchTerm)
      );
    }

    if (countLabel) {
      countLabel.innerText = `${list.length} quotation${list.length === 1 ? '' : 's'} found`;
    }

    if (list.length === 0) {
      const cartCount = (this.cart || []).reduce((s, i) => s + Number(i.quantity || 1), 0);
      container.innerHTML = `
        <div style="text-align: center; padding: 3rem 1rem; color: var(--slate-400);">
          <i class="fa-solid fa-file-invoice" style="font-size: 2.5rem; margin-bottom: 0.75rem; display: block; opacity: 0.6;"></i>
          <p style="font-weight: 600; font-size: 0.95rem; margin-bottom: 0.25rem; color: var(--slate-700);">No quotations found</p>
          <span style="font-size: 0.8rem; display: block; margin-bottom: 1rem;">Add items to your POS Cart and click <strong>"Proforma / Estimate"</strong> to create one.</span>
          <button type="button" class="btn btn-primary btn-sm" onclick="app.startNewEstimateFlow()" style="background: #0284c7; border-color: #0284c7;">
            <i class="fa-solid fa-plus"></i> ${cartCount > 0 ? `Create Quotation from Cart (${cartCount} item${cartCount === 1 ? '' : 's'})` : 'Go to POS to Create Quotation'}
          </button>
        </div>
      `;
      return;
    }

    const todayStr = new Date().toISOString().slice(0, 10);

    const rowsHTML = list.map(est => {
      const isConverted = (est.status || '').toUpperCase() === 'CONVERTED';
      const isExpired = !isConverted && est.valid_until && est.valid_until < todayStr;
      
      let statusBadge = '<span class="badge" style="background: #e0f2fe; color: #0369a1; border: 1px solid #bae6fd; font-weight: 700;"><i class="fa-solid fa-clock"></i> Active</span>';
      if (isConverted) {
        statusBadge = '<span class="badge" style="background: #dcfce7; color: #15803d; border: 1px solid #bbf7d0; font-weight: 700;"><i class="fa-solid fa-circle-check"></i> Converted to Sale</span>';
      } else if (isExpired) {
        statusBadge = '<span class="badge" style="background: #fee2e2; color: #b91c1c; border: 1px solid #fca5a5; font-weight: 700;"><i class="fa-solid fa-hourglass-end"></i> Expired</span>';
      }

      const itemCount = Array.isArray(est.items) ? est.items.length : 0;
      const formattedDate = this.escapeHtml(est.estimate_date ? est.estimate_date.split(' ')[0] : (est.created_at ? est.created_at.split(' ')[0] : 'N/A'));

      return `
        <tr style="border-bottom: 1px solid var(--slate-200); ${isConverted ? 'opacity: 0.85; background: #fafafa;' : ''}">
          <td style="padding: 0.75rem 0.5rem; font-weight: 700; color: var(--slate-900);">
            <div style="display: flex; align-items: center; gap: 0.4rem;">
              <i class="fa-solid fa-file-invoice" style="color: #0284c7;"></i>
              <span>${this.escapeHtml(est.estimate_number)}</span>
            </div>
            <div style="font-size: 0.72rem; color: var(--slate-500); font-weight: normal; margin-top: 2px;">
              ${formattedDate} · ${itemCount} item${itemCount === 1 ? '' : 's'}
            </div>
          </td>
          <td style="padding: 0.75rem 0.5rem;">
            <div style="font-weight: 600; color: var(--slate-800);">${this.escapeHtml(est.customer_name || 'Walk-in Customer')}</div>
            ${est.customer_phone ? `<div style="font-size: 0.72rem; color: var(--slate-500);"><i class="fa-solid fa-phone" style="font-size: 0.65rem;"></i> ${this.escapeHtml(est.customer_phone)}</div>` : ''}
          </td>
          <td style="padding: 0.75rem 0.5rem; text-align: right; font-weight: 800; color: var(--slate-900); font-size: 0.95rem;">
            ${this.formatCurrency(est.total_amount || 0)}
          </td>
          <td style="padding: 0.75rem 0.5rem; text-align: center;">
            ${statusBadge}
            ${est.valid_until && !isConverted ? `<div style="font-size: 0.68rem; color: var(--slate-500); margin-top: 2px;">Valid to: ${this.escapeHtml(est.valid_until)}</div>` : ''}
          </td>
          <td style="padding: 0.75rem 0.5rem; text-align: right; white-space: nowrap;">
            <div style="display: inline-flex; gap: 0.35rem; align-items: center;">
              <button type="button" class="btn btn-outline btn-sm" onclick="app.showEstimateModal(${this.jsStr(est.id)})" title="View & Print Proforma Invoice" style="padding: 0.3rem 0.6rem; font-size: 0.78rem;">
                <i class="fa-solid fa-eye"></i> View
              </button>
              ${!isConverted ? `
                <button type="button" class="btn btn-primary btn-sm" onclick="app.convertEstimateToSale(${this.jsStr(est.id)})" title="Load all items into POS Cart to make sale" style="padding: 0.3rem 0.65rem; font-size: 0.78rem; font-weight: 700; background: #059669; border-color: #059669; color: #ffffff;">
                  <i class="fa-solid fa-cart-shopping"></i> Sell
                </button>
              ` : ''}
              <button type="button" class="btn btn-outline btn-sm" onclick="app.deleteEstimate(${this.jsStr(est.id)})" title="Delete Quotation" style="color: var(--danger); border-color: var(--danger-border); padding: 0.3rem 0.55rem; font-size: 0.78rem;">
                <i class="fa-solid fa-trash-can"></i>
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');

    container.innerHTML = `
      <div style="overflow-x: auto;">
        <table style="width: 100%; border-collapse: collapse; font-size: 0.85rem;">
          <thead>
            <tr style="background: var(--slate-50); border-bottom: 2px solid var(--slate-200); text-align: left; font-size: 0.75rem; color: var(--slate-600); text-transform: uppercase; letter-spacing: 0.04em;">
              <th style="padding: 0.6rem 0.5rem;">Quotation #</th>
              <th style="padding: 0.6rem 0.5rem;">Customer</th>
              <th style="padding: 0.6rem 0.5rem; text-align: right;">Total Amount</th>
              <th style="padding: 0.6rem 0.5rem; text-align: center;">Status</th>
              <th style="padding: 0.6rem 0.5rem; text-align: right;">Actions</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHTML}
          </tbody>
        </table>
      </div>
    `;
  },

  async showEstimateModal(estimateOrId) {
    let est = estimateOrId;
    if (typeof estimateOrId === 'string') {
      est = this.currentEstimates.find(e => e.id === estimateOrId);
      if (!est && window.localDB && localDB.estimates) {
        est = await localDB.estimates.get(estimateOrId);
      }
    }

    if (!est) {
      this.showToast('Could not load quotation details.', 'danger');
      return;
    }

    this.activePreviewEstimate = est;
    const modal = document.getElementById('estimate-preview-modal');
    const container = document.getElementById('printable-estimate-area');
    const convertBtn = document.getElementById('btn-estimate-convert-now');

    if (!modal || !container) return;

    if (convertBtn) {
      const isConverted = (est.status || '').toUpperCase() === 'CONVERTED';
      convertBtn.style.display = isConverted ? 'none' : 'inline-flex';
    }

    const prof = this.storeProfile || {};
    const items = Array.isArray(est.items) ? est.items : [];
    const formattedDate = this.escapeHtml(est.estimate_date ? est.estimate_date.split(' ')[0] : (est.created_at ? est.created_at.split(' ')[0] : 'N/A'));
    const isConverted = (est.status || '').toUpperCase() === 'CONVERTED';

    container.innerHTML = `
      <div class="proforma-invoice-sheet" style="background: #ffffff; border: 1px solid var(--slate-200); border-radius: 12px; padding: 2rem; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); color: var(--slate-800); font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
        <!-- Header -->
        <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid var(--slate-900); padding-bottom: 1.25rem; margin-bottom: 1.25rem;">
          <div>
            ${this.shouldPrintReceiptLogo() ? `<img src="${this.escapeHtml(this.getStoreLogo())}" alt="Logo" style="max-height: 48px; max-width: 160px; margin-bottom: 0.5rem; object-fit: contain;">` : ''}
            <h2 style="margin: 0; font-size: 1.35rem; font-weight: 800; color: var(--slate-900); letter-spacing: -0.01em;">${this.escapeHtml(prof.store_name || 'Apex Wholesale & Retail Mart')}</h2>
            <p style="margin: 0.2rem 0; font-size: 0.8rem; color: var(--slate-600);">${this.escapeHtml(prof.tagline || 'Your Trusted Quality Goods Supplier')}</p>
            <p style="margin: 0; font-size: 0.78rem; color: var(--slate-600);">${this.escapeHtml(prof.address || '')}</p>
            <p style="margin: 0.15rem 0 0; font-size: 0.78rem; color: var(--slate-600);">
              <strong>Phone:</strong> ${this.escapeHtml(prof.phone || '')} 
              ${prof.email ? `· <strong>Email:</strong> ${this.escapeHtml(prof.email)}` : ''}
              ${prof.tax_number ? `· <strong>Tax ID / TIN:</strong> ${this.escapeHtml(prof.tax_number)}` : ''}
            </p>
          </div>
          <div style="text-align: right;">
            <div style="display: inline-block; background: #0284c7; color: #ffffff; font-weight: 800; font-size: 0.85rem; padding: 0.35rem 0.85rem; border-radius: 6px; letter-spacing: 0.05em; text-transform: uppercase;">
              PROFORMA INVOICE
            </div>
            <div style="font-size: 0.72rem; color: var(--slate-500); margin-top: 0.35rem; font-weight: 600;">PRICE ESTIMATE / QUOTATION</div>
            <h3 style="margin: 0.35rem 0 0; font-size: 1.1rem; color: var(--slate-900); font-family: monospace; font-weight: 700;">${this.escapeHtml(est.estimate_number)}</h3>
          </div>
        </div>

        <!-- Meta Details Row -->
        <div style="display: flex; justify-content: space-between; gap: 1.5rem; background: var(--slate-50); border: 1px solid var(--slate-200); border-radius: 8px; padding: 1rem; margin-bottom: 1.5rem; font-size: 0.82rem;">
          <div style="flex: 1;">
            <div style="font-size: 0.7rem; font-weight: 700; color: var(--slate-500); text-transform: uppercase; margin-bottom: 0.25rem;">Quotation Prepared For:</div>
            <div style="font-size: 1rem; font-weight: 800; color: var(--slate-900);">${this.escapeHtml(est.customer_name || 'Walk-in Customer')}</div>
            ${est.customer_phone ? `<div style="color: var(--slate-600); margin-top: 0.15rem;"><i class="fa-solid fa-phone" style="font-size: 0.7rem;"></i> ${this.escapeHtml(est.customer_phone)}</div>` : ''}
          </div>
          <div style="text-align: right;">
            <div><strong>Issue Date:</strong> ${formattedDate}</div>
            <div style="color: #b45309; font-weight: 700; margin-top: 0.25rem;">
              <i class="fa-solid fa-calendar-check"></i> Valid Until: ${this.escapeHtml(est.valid_until || '7 Days')}
            </div>
            <div style="color: var(--slate-500); margin-top: 0.2rem;">Prepared by: ${this.escapeHtml(est.created_by_name || 'Cashier')}</div>
            ${isConverted ? '<div style="margin-top: 0.35rem;"><span class="badge badge-success"><i class="fa-solid fa-check"></i> Already Purchased</span></div>' : ''}
          </div>
        </div>

        <!-- Items Table -->
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 1.5rem; font-size: 0.85rem;">
          <thead>
            <tr style="background: var(--slate-100); border-bottom: 2px solid var(--slate-300); text-align: left; font-size: 0.75rem; color: var(--slate-700); text-transform: uppercase;">
              <th style="padding: 0.6rem 0.5rem; width: 45%;">Item Description</th>
              <th style="padding: 0.6rem 0.5rem; text-align: center; width: 15%;">Quantity</th>
              <th style="padding: 0.6rem 0.5rem; text-align: right; width: 20%;">Unit Price</th>
              <th style="padding: 0.6rem 0.5rem; text-align: right; width: 20%;">Total</th>
            </tr>
          </thead>
          <tbody>
            ${items.map(it => {
              const unit = it.unit || 'pcs';
              const price = Number(it.selling_price || 0);
              const qty = Number(it.quantity || 1);
              const lineTotal = price * qty;
              return `
                <tr style="border-bottom: 1px solid var(--slate-200);">
                  <td style="padding: 0.65rem 0.5rem;">
                    <strong style="color: var(--slate-900);">${this.escapeHtml(it.name || 'Product')}</strong>
                    ${it.sku ? `<div style="font-size: 0.72rem; color: var(--slate-500); font-family: monospace;">SKU: ${this.escapeHtml(it.sku)}</div>` : ''}
                  </td>
                  <td style="padding: 0.65rem 0.5rem; text-align: center; font-weight: 600;">
                    ${qty} <span style="font-size: 0.72rem; color: var(--slate-500);">${this.escapeHtml(unit)}</span>
                  </td>
                  <td style="padding: 0.65rem 0.5rem; text-align: right;">${this.formatCurrency(price)}</td>
                  <td style="padding: 0.65rem 0.5rem; text-align: right; font-weight: 700; color: var(--slate-900);">${this.formatCurrency(lineTotal)}</td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>

        <!-- Totals & Payment Instructions -->
        <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 2rem; border-top: 1px solid var(--slate-200); padding-top: 1rem;">
          <div style="flex: 1; font-size: 0.78rem; color: var(--slate-600); line-height: 1.5;">
            <div style="font-weight: 700; color: var(--slate-800); margin-bottom: 0.35rem; text-transform: uppercase;">
              <i class="fa-solid fa-circle-info" style="color: #0284c7;"></i> Notice & Terms:
            </div>
            <p style="margin: 0 0 0.35rem 0;">1. This is a <strong>Price Quotation / Proforma Invoice</strong> for planning and budget approval. It is NOT an official tax sales receipt.</p>
            <p style="margin: 0 0 0.35rem 0;">2. Prices quoted above are strictly guaranteed for <strong>7 days</strong> from date of issue.</p>
            <p style="margin: 0;">3. Inventory is not reserved until payment is completed at checkout.</p>
          </div>
          <div style="width: 250px; font-size: 0.85rem;">
            <div style="display: flex; justify-content: space-between; padding: 0.3rem 0; color: var(--slate-600);">
              <span>Subtotal:</span>
              <strong style="color: var(--slate-800);">${this.formatCurrency(est.subtotal || 0)}</strong>
            </div>
            ${est.discount > 0 ? `
              <div style="display: flex; justify-content: space-between; padding: 0.3rem 0; color: #15803d;">
                <span>Discount:</span>
                <strong>-${this.formatCurrency(est.discount)}</strong>
              </div>
            ` : ''}
            ${est.tax > 0 ? `
              <div style="display: flex; justify-content: space-between; padding: 0.3rem 0; color: var(--slate-600);">
                <span>Tax / VAT:</span>
                <strong style="color: var(--slate-800);">+${this.formatCurrency(est.tax)}</strong>
              </div>
            ` : ''}
            <div style="display: flex; justify-content: space-between; padding: 0.6rem 0; border-top: 2px solid var(--slate-900); margin-top: 0.4rem; font-size: 1.15rem; font-weight: 800; color: var(--slate-900);">
              <span>Grand Total:</span>
              <span style="color: var(--primary);">${this.formatCurrency(est.total_amount || 0)}</span>
            </div>
          </div>
        </div>
      </div>
    `;

    modal.classList.add('active');
  },

  closeEstimatePreviewModal() {
    const modal = document.getElementById('estimate-preview-modal');
    if (modal) modal.classList.remove('active');
  },

  convertCurrentEstimateToSale() {
    if (this.activePreviewEstimate) {
      this.convertEstimateToSale(this.activePreviewEstimate.id);
    }
  },

  async convertEstimateToSale(estimateId) {
    let est = this.currentEstimates.find(e => e.id === estimateId);
    if (!est && window.localDB && localDB.estimates) {
      est = await localDB.estimates.get(estimateId);
    }

    if (!est) {
      this.showToast('Quotation not found.', 'danger');
      return;
    }

    const todayStr = new Date().toISOString().slice(0, 10);
    const isExpired = est.valid_until && est.valid_until < todayStr;
    if (isExpired) {
      const proceed = typeof this.showConfirmModal === 'function'
        ? await this.showConfirmModal({
            title: 'Quotation Has Expired',
            message: `Notice: Quotation ${est.estimate_number} expired on ${est.valid_until}. Current catalog prices may be higher. Would you like to proceed with converting to a sale at quoted rates?`,
            confirmText: 'Proceed with Sale',
            cancelText: 'Cancel',
            confirmClass: 'btn-warning'
          })
        : confirm(`Quotation ${est.estimate_number} expired on ${est.valid_until}. Proceed with converting anyway?`);
      if (!proceed) return;
    }

    // Check if current cart has items
    if (this.cart && this.cart.length > 0) {
      if (typeof this.showConfirmModal === 'function') {
        const replace = await this.showConfirmModal({
          title: 'Replace Current Cart?',
          message: 'Your POS cart currently contains items. Would you like to overwrite it with the items from this quotation?',
          confirmText: 'Replace Cart',
          cancelText: 'Keep Current Cart'
        });
        if (!replace) return;
      }
    }

    // Populate cart with quotation items
    this.cart = (est.items || []).map(it => {
      const prodId = it.product_id || it.id;
      const rawProd = (this.products || []).find(p => p.id === prodId) || {};
      const effProd = (typeof this.getEffectiveProductForBranch === 'function' && rawProd.id)
        ? this.getEffectiveProductForBranch(rawProd)
        : rawProd;
      const baseUnit = (typeof this.productUnitOf === 'function' && effProd.id)
        ? this.productUnitOf(effProd, null)
        : null;
      const unitLabel = it.unit || (baseUnit && baseUnit.unit_name) || effProd.unit || rawProd.unit || 'pcs';
      const unitObj = (typeof this.productUnitOf === 'function' && effProd.id)
        ? this.productUnitOf(effProd, unitLabel)
        : null;
      const multiplier = Number(it.multiplier || (unitObj && unitObj.size_in_base) || 1);
      const basePrice = Number(effProd.effectivePrice || effProd.selling_price || rawProd.selling_price || 0);
      const unitSellingPrice = Number(it.selling_price !== undefined ? it.selling_price : (it.unit_price || basePrice));

      return {
        ...rawProd,
        product_id: prodId,
        id: prodId,
        name: it.name || rawProd.name || 'Item',
        sku: it.sku || rawProd.sku || '',
        product_type: rawProd.product_type || 'standard',
        combo_items: rawProd.combo_items || [],
        unit_cost_price: Number(effProd.cost_price || rawProd.cost_price || 0),
        base_selling_price: basePrice,
        selling_price: unitSellingPrice,
        unit_selling_price: unitSellingPrice,
        unit: (baseUnit && baseUnit.unit_name) || effProd.unit || rawProd.unit || 'pcs',
        selected_unit: unitLabel,
        multiplier: multiplier,
        base_unit: (baseUnit && baseUnit.unit_name) || effProd.unit || rawProd.unit || 'pcs',
        quantity: Number(it.quantity || 1),
        seat_number: this.activeSeat || 'Shared',
        prep_notes: '',
        branch_code: this.branchCode || 'MAIN-01',
        is_pack: it.is_pack || false
      };
    });

    this.cartDiscount = Number(est.discount || 0);
    this.activeConvertingEstimateId = est.id;

    // Set Customer in POS if available
    if (est.customer_id && est.customer_id !== 'cust-walkin') {
      this.selectedCustomerId = est.customer_id;
      const custSelect = document.getElementById('pos-customer-select') || document.getElementById('pos-customer');
      if (custSelect) custSelect.value = est.customer_id;
    }

    // Close preview & archive modals
    this.closeEstimatePreviewModal();
    this.closeEstimatesModal();

    // Switch to POS view
    this.switchView('pos');
    this.renderCurrentView();

    this.showToast(`Quotation ${est.estimate_number} loaded into cart! Click Pay [F4] to complete sale.`, 'success');
  },

  printCurrentEstimate() {
    window.print();
  },

  shareEstimateViaWhatsApp() {
    const est = this.activePreviewEstimate;
    if (!est) return;

    const prof = this.storeProfile || {};
    const sym = prof.currency_symbol || 'GH₵';
    const items = Array.isArray(est.items) ? est.items : [];

    let msg = `*PROFORMA INVOICE / PRICE ESTIMATE*\n`;
    msg += `*${prof.store_name || 'StoreFlow'}*\n`;
    if (prof.phone) msg += `Tel: ${prof.phone}\n`;
    msg += `--------------------------------\n`;
    msg += `Quotation #: *${est.estimate_number}*\n`;
    msg += `Date: ${est.estimate_date ? est.estimate_date.split(' ')[0] : 'Today'}\n`;
    msg += `Customer: ${est.customer_name || 'Valued Customer'}\n`;
    msg += `Valid Until: *${est.valid_until || '7 Days'}*\n`;
    msg += `--------------------------------\n`;
    msg += `*ITEMS:*\n`;

    items.forEach((it, idx) => {
      const lineTotal = (Number(it.selling_price) * Number(it.quantity)).toFixed(2);
      msg += `${idx + 1}. ${it.name} (${it.quantity} ${it.unit || 'pcs'} @ ${sym}${it.selling_price}) = *${sym}${lineTotal}*\n`;
    });

    msg += `--------------------------------\n`;
    if (est.discount > 0) msg += `Discount: -${sym}${Number(est.discount).toFixed(2)}\n`;
    if (est.tax > 0) msg += `Tax / VAT: +${sym}${Number(est.tax).toFixed(2)}\n`;
    msg += `*GRAND TOTAL: ${sym}${Number(est.total_amount).toFixed(2)}*\n\n`;
    msg += `_Prices are guaranteed for 7 days. Thank you for your inquiry!_`;

    let cleanPhone = (est.customer_phone || '').replace(/[^0-9]/g, '');
    if (cleanPhone.startsWith('0') && cleanPhone.length === 10) {
      cleanPhone = '233' + cleanPhone.substring(1);
    }

    const encoded = encodeURIComponent(msg);
    const waUrl = cleanPhone ? `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encoded}` : `https://api.whatsapp.com/send?text=${encoded}`;
    window.open(waUrl, '_blank');
  },

  async deleteEstimate(estimateId) {
    if (typeof this.showConfirmModal === 'function') {
      const ok = await this.showConfirmModal({
        title: 'Delete Quotation?',
        message: 'Are you sure you want to delete this price quotation? This action cannot be undone.',
        confirmText: 'Delete',
        cancelText: 'Cancel'
      });
      if (!ok) return;
    } else {
      if (!confirm('Are you sure you want to delete this quotation?')) return;
    }

    try {
      if (window.localDB && localDB.estimates) {
        await localDB.estimates.delete(estimateId);
      }
    } catch (e) {
      console.warn('Error deleting estimate locally:', e);
    }

    if (this.isOnline) {
      try {
        await this.apiFetch('api/endpoints/estimates.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'delete', id: estimateId })
        });
      } catch (err) {
        console.warn('Error deleting estimate on server:', err);
      }
    }

    this.currentEstimates = (this.currentEstimates || []).filter(e => e.id !== estimateId);
    this.renderEstimatesTable();
    this.showToast('Quotation deleted.', 'info');
  },

  async markEstimateConverted(estimateId, saleId) {
    if (!estimateId) return;
    const nowIso = new Date().toISOString().slice(0, 19).replace('T', ' ');

    try {
      if (window.localDB && localDB.estimates) {
        const est = await localDB.estimates.get(estimateId);
        if (est) {
          est.status = 'CONVERTED';
          est.converted_sale_id = saleId;
          est.converted_at = nowIso;
          await localDB.estimates.put(est);
        }
      }
    } catch (e) {
      console.warn('Could not update estimate in IndexedDB:', e);
    }

    if (this.isOnline) {
      try {
        await this.apiFetch('api/endpoints/estimates.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'convert', id: estimateId, sale_id: saleId })
        });
      } catch (err) {
        console.warn('Could not mark estimate converted on server:', err);
      }
    }
  }
});
