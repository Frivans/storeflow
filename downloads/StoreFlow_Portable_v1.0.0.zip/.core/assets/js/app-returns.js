// assets/js/app-returns.js - Dedicated Returns & Refunds View Controller

Object.assign(StoreApp.prototype, {
  returnsBranchFilter: 'ALL',
  returnsDateFilter: 'all',
  returnsTenderFilter: 'ALL',
  returnsSearchQuery: '',

  setReturnsBranchFilter(b) {
    this.returnsBranchFilter = b || 'ALL';
    this.renderCurrentView();
  },

  setReturnsDateFilter(d) {
    this.returnsDateFilter = d || 'all';
    this.renderCurrentView();
  },

  setReturnsTenderFilter(t) {
    this.returnsTenderFilter = t || 'ALL';
    this.renderCurrentView();
  },

  setReturnsSearchQuery(q) {
    this.returnsSearchQuery = (q || '').trim();
    this.renderCurrentView();
  },

  getFilteredReturnsList() {
    const list = this.salesReturns || [];
    const bFilter = (this.returnsBranchFilter || 'ALL').toUpperCase();
    const dFilter = this.returnsDateFilter || 'all';
    const tFilter = (this.returnsTenderFilter || 'ALL').toUpperCase();
    const query = (this.returnsSearchQuery || '').toLowerCase();

    const todayStr = new Date().toISOString().slice(0, 10);
    const monthStr = new Date().toISOString().slice(0, 7);

    return list.filter(r => {
      // 1. Branch filter
      if (bFilter !== 'ALL' && (r.branch_code || 'MAIN-01').toUpperCase() !== bFilter) {
        return false;
      }

      // 2. Date filter
      const rDate = (r.return_date || r.created_at || '').slice(0, 10);
      if (dFilter === 'today' && rDate !== todayStr) return false;
      if (dFilter === 'month' && !rDate.startsWith(monthStr)) return false;

      // 3. Tender filter
      if (tFilter !== 'ALL' && (r.refund_method || 'CASH').toUpperCase() !== tFilter) {
        return false;
      }

      // 4. Search query
      if (query) {
        const matchRet = (r.return_number || '').toLowerCase().includes(query);
        const matchRec = (r.receipt_number || '').toLowerCase().includes(query);
        const matchCust = (r.customer_name || '').toLowerCase().includes(query);
        const matchCash = (r.cashier_name || '').toLowerCase().includes(query);
        const matchReason = (r.reason || '').toLowerCase().includes(query);
        if (!matchRet && !matchRec && !matchCust && !matchCash && !matchReason) {
          return false;
        }
      }

      return true;
    });
  },

  getReturnsHTML() {
    const isCashier = this.isCashier();
    const filteredReturns = this.getFilteredReturnsList();
    // Row handlers address these by index; serialising a whole return object into an
    // onclick attribute cannot be made safe against quotes in stored text.
    this._returnsRowsShown = filteredReturns;
    const allReturns = this.salesReturns || [];

    // Calculate Summary Stats from filtered set
    const totalRefunded = filteredReturns.reduce((sum, r) => sum + Number(r.total_refund_amount || 0), 0);
    let restockedUnits = 0;
    let damagedUnits = 0;
    let cashPayouts = 0;
    let creditIssued = 0;

    filteredReturns.forEach(r => {
      const amt = Number(r.total_refund_amount || 0);
      if ((r.refund_method || 'CASH').toUpperCase() === 'CASH') {
        cashPayouts += amt;
      } else {
        creditIssued += amt;
      }

      (r.items || []).forEach(it => {
        const q = Number(it.quantity || 0);
        if ((it.item_condition || 'RESTOCK').toUpperCase() === 'RESTOCK') {
          restockedUnits += q;
        } else {
          damagedUnits += q;
        }
      });
    });

    return `
      <!-- Top Metrics Dashboard Panel -->
      <div class="panel" style="margin-bottom: 1.5rem;">
        <div class="panel-body" style="display: flex; gap: 2rem; flex-wrap: wrap; align-items: center;">
          <div>
            <span style="font-size: 0.8rem; color: var(--slate-500); text-transform: uppercase; font-weight: 600;">Return Slips</span>
            <p style="font-size: 1.5rem; font-weight: 800; color: var(--slate-900); margin: 0.2rem 0 0 0;">
              <i class="fa-solid fa-file-invoice" style="color: var(--primary); font-size: 1.25rem; margin-right: 0.35rem;"></i>
              ${filteredReturns.length}
            </p>
          </div>

          <div>
            <span style="font-size: 0.8rem; color: #dc2626; text-transform: uppercase; font-weight: 600;">Total Refunds Issued</span>
            <p style="font-size: 1.5rem; font-weight: 800; color: #dc2626; margin: 0.2rem 0 0 0;">
              -${this.formatCurrency(totalRefunded)}
            </p>
          </div>

          <div>
            <span style="font-size: 0.8rem; color: #166534; text-transform: uppercase; font-weight: 600;">Restocked to Shelves</span>
            <p style="font-size: 1.5rem; font-weight: 800; color: #15803d; margin: 0.2rem 0 0 0;">
              +${restockedUnits} units
            </p>
          </div>

          <div>
            <span style="font-size: 0.8rem; color: #b45309; text-transform: uppercase; font-weight: 600;">Damaged Write-offs</span>
            <p style="font-size: 1.5rem; font-weight: 800; color: #b45309; margin: 0.2rem 0 0 0;">
              ${damagedUnits} units
            </p>
          </div>

          <div>
            <span style="font-size: 0.8rem; color: var(--slate-500); text-transform: uppercase; font-weight: 600;">Cash Drawer Payouts</span>
            <p style="font-size: 1.5rem; font-weight: 800; color: var(--slate-800); margin: 0.2rem 0 0 0;">
              ${this.formatCurrency(cashPayouts)}
            </p>
          </div>

          <div>
            <span style="font-size: 0.8rem; color: #6b21a8; text-transform: uppercase; font-weight: 600;">Store Credit Issued</span>
            <p style="font-size: 1.5rem; font-weight: 800; color: #7e22ce; margin: 0.2rem 0 0 0;">
              ${this.formatCurrency(creditIssued)}
            </p>
          </div>
        </div>
      </div>

      <!-- Main Returns Ledger Panel -->
      <div class="panel">
        <div class="panel-header" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.75rem;">
          <div>
            <h3><i class="fa-solid fa-rotate-left" style="color: var(--primary);"></i> Customer Returns & Merchandise Refunds Ledger</h3>
            <p style="font-size: 0.82rem; color: var(--slate-500); margin: 0.2rem 0 0 0;">Audit trail of all merchandise returns, credit notes, and shelf restocks</p>
          </div>
          <div style="display: flex; align-items: center; gap: 0.6rem; flex-wrap: wrap;">
            ${allReturns.length > 0 && !isCashier ? `
              <button type="button" class="btn btn-outline btn-sm" style="color: #dc2626; border-color: #fecaca; font-weight: 600;" onclick="app.purgeUnsyncedReturns()" title="Clear offline test return records and reset returns ledger">
                <i class="fa-solid fa-trash-can"></i> Clear Return Slips
              </button>
            ` : ''}
            <button type="button" class="btn btn-primary" onclick="app.openSalesReturnModal()" style="font-weight: 700;">
              <i class="fa-solid fa-plus"></i> Process Customer Return
            </button>
          </div>
        </div>

        <!-- Filter Controls Bar -->
        <div style="padding: 0.85rem 1.25rem; background: var(--slate-50, #f8fafc); border-bottom: 1px solid var(--slate-200); display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 0.75rem;">
          <div style="display: flex; align-items: center; gap: 0.75rem; flex-wrap: wrap; flex: 1; max-width: 800px;">
            <!-- Search Input -->
            <div style="position: relative; flex: 1; min-width: 220px;">
              <input type="text" id="returns-search-input" class="form-control" placeholder="Search Return #, Receipt #, Customer, Cashier..." value="${this.escapeHtml(this.returnsSearchQuery || '')}" oninput="app.setReturnsSearchQuery(this.value)" style="font-size: 0.85rem; padding-left: 2rem;">
              <i class="fa-solid fa-magnifying-glass" style="position: absolute; left: 0.75rem; top: 50%; transform: translateY(-50%); color: var(--slate-400); font-size: 0.82rem;"></i>
            </div>

            ${this.isMultiBranch ? `
              <!-- Branch Filter -->
              <div style="display: flex; align-items: center; gap: 0.35rem;">
                <label style="font-size: 0.8rem; font-weight: 600; color: var(--slate-600);"><i class="fa-solid fa-store"></i> Branch:</label>
                <select id="returns-branch-filter" class="form-control" style="width: auto; padding: 0.35rem 0.65rem; font-size: 0.82rem; font-weight: 600;" onchange="app.setReturnsBranchFilter(this.value)">
                  <option value="ALL" ${this.returnsBranchFilter === 'ALL' ? 'selected' : ''}>All Branches (Consolidated)</option>
                  ${(this.branches || []).map(b => `
                    <option value="${this.escapeHtml(b.branch_code)}" ${this.returnsBranchFilter === b.branch_code ? 'selected' : ''}>
                      ${this.escapeHtml(b.branch_code)} - ${this.escapeHtml(b.name)}
                    </option>
                  `).join('')}
                </select>
              </div>
            ` : ''}

            <!-- Date Filter -->
            <div style="display: flex; align-items: center; gap: 0.35rem;">
              <label style="font-size: 0.8rem; font-weight: 600; color: var(--slate-600);"><i class="fa-solid fa-calendar"></i> Date:</label>
              <select id="returns-date-filter" class="form-control" style="width: auto; padding: 0.35rem 0.65rem; font-size: 0.82rem; font-weight: 600;" onchange="app.setReturnsDateFilter(this.value)">
                <option value="all" ${this.returnsDateFilter === 'all' ? 'selected' : ''}>All Time</option>
                <option value="today" ${this.returnsDateFilter === 'today' ? 'selected' : ''}>Today</option>
                <option value="month" ${this.returnsDateFilter === 'month' ? 'selected' : ''}>This Month</option>
              </select>
            </div>

            <!-- Tender Method Filter -->
            <div style="display: flex; align-items: center; gap: 0.35rem;">
              <label style="font-size: 0.8rem; font-weight: 600; color: var(--slate-600);"><i class="fa-solid fa-wallet"></i> Tender:</label>
              <select id="returns-tender-filter" class="form-control" style="width: auto; padding: 0.35rem 0.65rem; font-size: 0.82rem; font-weight: 600;" onchange="app.setReturnsTenderFilter(this.value)">
                <option value="ALL" ${this.returnsTenderFilter === 'ALL' ? 'selected' : ''}>All Tenders</option>
                <option value="CASH" ${this.returnsTenderFilter === 'CASH' ? 'selected' : ''}>Cash Drawer Payout</option>
                <option value="STORE_CREDIT" ${this.returnsTenderFilter === 'STORE_CREDIT' ? 'selected' : ''}>Customer Store Credit</option>
              </select>
            </div>
          </div>

          <div>
            <span class="badge badge-neutral" style="font-size: 0.78rem;">
              Showing ${filteredReturns.length} of ${allReturns.length} records
            </span>
          </div>
        </div>

        <!-- Returns Data Table -->
        <div class="panel-body">
          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Return Slip #</th>
                  <th>Date & Time</th>
                  <th>Orig. Receipt</th>
                  <th>Customer (Buyer)</th>
                  <th>Cashier</th>
                  ${this.isMultiBranch ? '<th>Branch</th>' : ''}
                  <th>Items Returned</th>
                  <th>Refund Amount</th>
                  <th>Tender</th>
                  <th>Slip</th>
                  ${!isCashier ? '<th style="text-align: center;">Actions</th>' : ''}
                </tr>
              </thead>
              <tbody>
                ${filteredReturns.length > 0 ? filteredReturns.map((r, returnIdx) => {
                  const itemCount = (r.items || []).length || r.item_count || 1;
                  return `
                    <tr>
                      <td style="font-weight: 700; font-family: monospace; color: #4338ca;">
                        ${this.escapeHtml(r.return_number)}
                      </td>
                      <td style="white-space: nowrap;">${this.escapeHtml((r.return_date || r.created_at || '').slice(0, 16))}</td>
                      <td style="font-family: monospace; font-weight: 600; cursor: pointer; color: var(--primary);" onclick="app.viewSaleReceipt(${this.jsStr(r.sale_id || r.receipt_number)})" title="View original sale receipt">
                        ${this.escapeHtml(r.receipt_number)}
                      </td>
                      <td>${this.escapeHtml(r.customer_name || 'Walk-in Customer')}</td>
                      <td>${this.escapeHtml(r.cashier_name || 'Cashier')}</td>
                      ${this.isMultiBranch ? `<td><span class="badge badge-neutral">${this.escapeHtml(r.branch_code || 'MAIN-01')}</span></td>` : ''}
                      <td>
                        <span class="badge badge-neutral">${itemCount} item(s)</span>
                      </td>
                      <td style="font-weight: 700; color: #dc2626; white-space: nowrap;">
                        -${this.formatCurrency(r.total_refund_amount)}
                      </td>
                      <td>
                        <span class="badge ${r.refund_method === 'STORE_CREDIT' ? 'badge-primary' : 'badge-neutral'}">
                          ${this.escapeHtml(r.refund_method || 'CASH')}
                        </span>
                      </td>
                      <td>
                        <button class="btn btn-outline btn-sm" style="font-size: 0.75rem; padding: 0.25rem 0.55rem;" onclick="app.showReturnCreditNoteAtRow(${returnIdx})" title="Print or view official Return Credit Note">
                          <i class="fa-solid fa-print"></i> Slip
                        </button>
                      </td>
                      ${!isCashier ? `
                        <td style="text-align: center;">
                          <button class="btn btn-outline btn-xs" style="color: #dc2626; border-color: #fee2e2; padding: 0.25rem 0.5rem;" onclick="event.stopPropagation(); app.deleteSalesReturn(${this.jsStr(r.id)})" title="Delete return record">
                            <i class="fa-solid fa-trash-can"></i>
                          </button>
                        </td>
                      ` : ''}
                    </tr>
                  `;
                }).join('') : `
                  <tr>
                    <td colspan="${!isCashier ? (this.isMultiBranch ? 11 : 10) : (this.isMultiBranch ? 10 : 9)}" style="text-align: center; padding: 3rem; color: var(--slate-400);">
                      <div style="font-size: 2.2rem; color: var(--slate-300); margin-bottom: 0.5rem;">
                        <i class="fa-solid fa-rotate-left"></i>
                      </div>
                      <p style="font-size: 0.95rem; font-weight: 600; color: var(--slate-600); margin: 0 0 0.35rem 0;">No Return Records Found</p>
                      <p style="font-size: 0.82rem; color: var(--slate-400); margin: 0 auto 1rem; max-width: 380px;">No merchandise returns match the selected branch, date, or search filter.</p>
                      <button class="btn btn-primary btn-sm" onclick="app.openSalesReturnModal()">
                        <i class="fa-solid fa-plus"></i> Process New Return
                      </button>
                    </td>
                  </tr>
                `}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  },

  showReturnCreditNoteAtRow(index) {
    const row = (this._returnsRowsShown || [])[Number(index)];
    if (!row) {
      this.showToast('That return is no longer in the list. Refresh the returns view.', 'warning');
      return;
    }
    this.showReturnCreditNote(row);
  },

  bindReturnsEvents() {
    const searchInput = document.getElementById('returns-search-input');
    if (searchInput && this.returnsSearchQuery) {
      searchInput.selectionStart = searchInput.selectionEnd = searchInput.value.length;
    }
  }
,

  async purgeUnsyncedReturns() {
    const totalCount = (this.salesReturns || []).length;
    if (totalCount === 0) {
      this.showToast('No return records to clear.', 'info');
      return;
    }

    const confirmed = await this.showConfirmModal({
      title: 'Clear All Return Records?',
      message: 'Are you sure you want to clear all ' + totalCount + ' return records? This will purge stuck test returns from local memory and reset the returns ledger. All underlying sales receipts remain intact.',
      icon: 'fa-trash-can',
      confirmText: 'Clear All Returns',
      confirmBtnClass: 'btn-danger'
    });
    if (!confirmed) return;

    try {
      if (typeof localDB !== 'undefined' && localDB.sales_returns) {
        await localDB.sales_returns.clear();
      }

      if (typeof localDB !== 'undefined' && localDB.sync_outbox) {
        const outboxEntries = await localDB.sync_outbox.filter(item => item.entity === 'sales_return').toArray();
        for (const entry of outboxEntries) {
          if (entry.id) await localDB.sync_outbox.delete(entry.id);
        }
      }

      if (this.isOnline) {
        try {
          await this.apiFetch('api/endpoints/returns.php?action=clear_all', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'clear_all' })
          });
        } catch (e) {
          console.warn('Server clear_all error:', e);
        }
      }

      this.salesReturns = [];

      (this.sales || []).forEach(s => {
        if (s.refunded_amount) s.refunded_amount = 0;
        if (s.status === 'REFUNDED' || s.status === 'PARTIALLY_REFUNDED') s.status = 'COMPLETED';
      });
      if (typeof localDB !== 'undefined' && localDB.sales) {
        try {
          await localDB.sales.clear();
          await localDB.sales.bulkPut(this.sales);
        } catch (e) {}
      }

      this.showToast('Successfully cleared ' + totalCount + ' return records!', 'success');
      this.renderCurrentView();
    } catch (err) {
      console.error('Error clearing returns:', err);
      this.showToast('Failed to clear returns: ' + err.message, 'danger');
    }
  },

  async deleteSalesReturn(returnId) {
    if (!returnId) return;

    const confirmed = await this.showConfirmModal({
      title: 'Delete Return Slip?',
      message: 'Are you sure you want to delete this return slip? This will remove the return record and adjust totals.',
      icon: 'fa-trash-can',
      confirmText: 'Delete Return',
      confirmBtnClass: 'btn-danger'
    });
    if (!confirmed) return;

    try {
      if (typeof localDB !== 'undefined' && localDB.sales_returns) {
        await localDB.sales_returns.delete(returnId);
      }

      if (typeof localDB !== 'undefined' && localDB.sync_outbox) {
        const outbox = await localDB.sync_outbox.filter(item => item.entity === 'sales_return' && (item.data?.id === returnId || item.data?.return_number === returnId)).toArray();
        for (const item of outbox) {
          if (item.id) await localDB.sync_outbox.delete(item.id);
        }
      }

      if (this.isOnline) {
        try {
          await this.apiFetch('api/endpoints/returns.php?action=delete&id=' + encodeURIComponent(returnId), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'delete', id: returnId })
          });
        } catch (e) {
          console.warn('Server return deletion error:', e);
        }
      }

      this.salesReturns = (this.salesReturns || []).filter(r => r.id !== returnId && r.return_number !== returnId);

      this.showToast('Return slip deleted.', 'success');
      this.renderCurrentView();
    } catch (err) {
      console.error('Error deleting return:', err);
      this.showToast('Failed to delete return: ' + err.message, 'danger');
    }
  }
});
