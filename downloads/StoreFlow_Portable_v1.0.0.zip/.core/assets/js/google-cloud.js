// assets/js/google-cloud.js
// StoreFlow Google Cloud Account & Drive Backup Engine
//
// 1. Google Sign-In:
//    - PC: GIS token client loaded lazily on user click (#150).
//    - Phone: Opens system browser to Cloudflare Worker auth page,
//      which returns via deep link (storeflow://auth?access_token=...).
// 2. Licence lookup (/account/status):
//    - Google access token verified server-side via Google tokeninfo (#146).
//    - Single-Device Activation Policy:
//      An account can have 1 active Phone device and 1 active PC device simultaneously.
//      Logging in on another device of the same edition prompts confirmation and logs
//      out the previous device upon confirmation.
// 3. Google Drive Backup & Restore:
//    - Cross-compatible SQLite (.db) backups across Phone and PC.
//    - Phone exports and imports directly via native SQLite bridge.
//    - PC exports encrypted .sfbak or standard .db, and imports both seamlessly.

(function() {
  'use strict';

  var GOOGLE_CLIENT_ID = '10289058720-7np458m2afi6sft4hk569hh26dgi4c6e.apps.googleusercontent.com';
  var SIGNER_BASE_URL = 'https://storeflow-license-signer.www-frivans.workers.dev';
  var SIGNER_STATUS_URL = SIGNER_BASE_URL + '/account/status';
    var GIS_SRC = 'https://accounts.google.com/gsi/client';
  var SCOPES = 'openid email profile https://www.googleapis.com/auth/drive.file';

  var tokenClient = null;
  var currentAccessToken = null;
  var pendingAfterToken = null;

  function dlg(o) {
    o = o || {};
    if (!o.brandSubtitle) o.brandSubtitle = 'Google Drive';
    if (!o.brandIcon) {
      if (o.tone === 'busy') o.brandIcon = 'fa-solid fa-spinner fa-spin';
      else if (o.tone === 'success') o.brandIcon = 'fa-solid fa-circle-check';
      else if (o.tone === 'error') o.brandIcon = 'fa-solid fa-triangle-exclamation';
      else o.brandIcon = 'fa-brands fa-google-drive';
    }
    if (!o.brandColor) {
      if (o.tone === 'success') o.brandColor = '#22c55e';
      else if (o.tone === 'error') o.brandColor = '#f59e0b';
      else if (o.tone === 'busy') o.brandColor = '#3b82f6';
      else o.brandColor = '#4285f4';
    }
    if (typeof window.sfBrandDialog === 'function') return window.sfBrandDialog(o);
    alert(o.message || o.title || '');
    return Promise.resolve({ action: 'ok' });
  }

  function isPhoneShell() {
    return !!(window.StoreFlowAndroid && typeof window.StoreFlowAndroid.getDeviceMachineId === 'function');
  }

  function apiFetch(url, opts) {
    if (window.app && typeof window.app.apiFetch === 'function') return window.app.apiFetch(url, opts);
    return fetch(url, Object.assign({ credentials: 'same-origin' }, opts || {}));
  }

  function getMachineRef() {
    var ref = '';
    if (isPhoneShell()) {
      try { ref = window.StoreFlowAndroid.getDeviceMachineId() || ''; } catch (e) {}
    }
    if (!ref && window.app && window.app._machineRef) ref = window.app._machineRef;
    if (!ref) {
      try { ref = sessionStorage.getItem('_sf_ref') || localStorage.getItem('_sf_ref') || ''; } catch (e) {}
    }
    return ref;
  }

    function isLocallyLicensed() {
    if (window.app && window.app._sessionScope === 'active') return true;
    if (window.StoreFlowMobileLicense && typeof window.StoreFlowMobileLicense.evaluate === 'function') {
      try {
        var s = window.StoreFlowMobileLicense.evaluate(getMachineRef());
        if (s && s.status === 'active') return true;
      } catch (e) {}
    }
    return false;
  }

  function getEdition() {
    var ref = getMachineRef();
    return /^SF-MOB-/.test(ref) ? 'phone' : 'pc';
  }

  var GoogleCloud = {
    clientId: GOOGLE_CLIENT_ID,
    _currentIntent: 'recover',

    _loadGis: function() {
      return new Promise(function(resolve, reject) {
        if (window.google && window.google.accounts && window.google.accounts.oauth2) return resolve();
        var existing = document.getElementById('_sf_gis_script');
        var s = existing || document.createElement('script');
        var done = false;
        var timer = setTimeout(function() { if (!done) { done = true; reject(new Error('Google Sign-In did not load in time')); } }, 15000);
        s.addEventListener('load', function() { if (!done) { done = true; clearTimeout(timer); resolve(); } });
        s.addEventListener('error', function() { if (!done) { done = true; clearTimeout(timer); reject(new Error('Could not load Google Sign-In')); } });
        if (!existing) {
          s.id = '_sf_gis_script';
          s.src = GIS_SRC;
          s.async = true;
          document.head.appendChild(s);
        }
      });
    },

    _initClient: function() {
      if (tokenClient) return;
      tokenClient = window.google.accounts.oauth2.initTokenClient({
        client_id: GOOGLE_CLIENT_ID,
        scope: SCOPES,
        callback: function(resp) {
          var cb = pendingAfterToken || GoogleCloud.onTokenReceived;
          pendingAfterToken = null;
          if (resp && resp.access_token) {
            currentAccessToken = resp.access_token;
            cb(resp.access_token);
          } else {
            dlg({ tone: 'error', title: 'Google Sign-In failed',
                  message: 'Google did not grant access' + (resp && resp.error ? ' (' + resp.error + ')' : '') + '. Nothing was changed.' });
          }
        },
        error_callback: function(err) {
          pendingAfterToken = null;
          if (err && err.type === 'popup_closed') return;
          dlg({ tone: 'error', title: 'Google Sign-In failed',
                message: 'The Google sign-in window could not be opened. Please allow pop-ups and try again.' });
        }
      });
    },

    _withToken: async function(callback) {
      if (!navigator.onLine) {
        dlg({ tone: 'error', title: 'Internet required',
              message: 'Google Sign-In needs an internet connection. Connect and try again.' });
        return;
      }
      try {
        await GoogleCloud._loadGis();
        GoogleCloud._initClient();
      } catch (e) {
        dlg({ tone: 'error', title: 'Google services unavailable', message: e.message + '. Check the connection and try again.' });
        return;
      }
      return new Promise(function(resolve, reject) {
        pendingAfterToken = async function(token) {
          try {
            var fn = (typeof callback === 'function') ? callback : GoogleCloud.onTokenReceived;
            var res = await fn(token);
            resolve(res);
          } catch (err) {
            reject(err);
          }
        };
        tokenClient.requestAccessToken({ prompt: currentAccessToken ? '' : 'select_account' });
      });
    },

    // Trigger Sign-In Flow
    signIn: function(opts) {
      var intent = 'recover';
      if (typeof opts === 'string') intent = opts;
      else if (opts && opts.intent) intent = opts.intent;
      GoogleCloud._currentIntent = intent;
      try { sessionStorage.setItem('_sf_auth_intent', intent); } catch (e) {}

      if (!navigator.onLine) {
        dlg({ tone: 'error', title: 'Internet required',
              message: 'Google Sign-In requires an active internet connection. Connect and try again.' });
        return;
      }

      var machineRef = getMachineRef();
      if (!machineRef) {
        dlg({ tone: 'error', title: 'Device reference missing',
              message: 'The Machine ID has not loaded yet. Reload StoreFlow and try again.' });
        return;
      }

      // Phone: Open system browser via Worker auth page (avoids WebView OAuth block)
      if (isPhoneShell() && window.StoreFlowAndroid && typeof window.StoreFlowAndroid.openExternalUrl === 'function') {
        dlg({
          tone: 'busy',
          title: 'Opening Google Sign-In…',
          message: 'Opening your secure system browser. Please complete Google sign-in to return to StoreFlow.',
          dismissible: true
        });
        var authUrl = SIGNER_BASE_URL + '/auth/google?edition=phone&machine_id=' + encodeURIComponent(machineRef) + '&intent=' + encodeURIComponent(intent);
        window.StoreFlowAndroid.openExternalUrl(authUrl);
        return;
      }

      // PC: Standard GIS popup
      return GoogleCloud._withToken(GoogleCloud.onTokenReceived);
    },

    // Callback when Google token is obtained
    onTokenReceived: async function(accessToken, confirmedTransfer) {
      currentAccessToken = accessToken;
      dlg({ tone: 'busy', title: 'Connecting to Google…',
            message: 'Checking your Google account for a StoreFlow licence…', dismissible: false });

      try {
        var machineRef = getMachineRef();
        if (!machineRef) {
          dlg({ tone: 'error', title: 'Device reference missing',
                message: 'The Machine ID has not loaded yet. Reload StoreFlow and try again.' });
          return;
        }

        var purchaseRef = '';
        try { purchaseRef = localStorage.getItem('_sf_purchase_ref') || sessionStorage.getItem('_sf_purchase_ref') || ''; } catch (e) {}
        var statusPayload = {
          google_access_token: accessToken,
          machine_id: machineRef,
          confirm_transfer: Boolean(confirmedTransfer)
        };
        if (purchaseRef) statusPayload.purchase_reference = purchaseRef;

        var statusRes = await fetch(SIGNER_STATUS_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(statusPayload)
        });

        var status = null;
        try { status = await statusRes.json(); } catch (e) {}

        if (!statusRes.ok || !status || !status.ok) {
          dlg({ tone: 'error', title: 'Licence check failed',
                message: (status && status.msg) ? status.msg : ('The licence server answered HTTP ' + statusRes.status + '.'),
                support: true, machineRef: machineRef });
          return;
        }

        var email = status.email || '';
        try {
          localStorage.setItem('_sf_google_email', email);
          if (status.reference) localStorage.setItem('_sf_purchase_ref', status.reference);
        } catch (e) {}

        // Single-Device Concurrency: Prompt if transfer deactivates another device
        if (status.needs_transfer_confirmation) {
          var choice = await dlg({
            tone: 'warning',
            title: 'Device Transfer Required',
            message: status.msg,
            buttons: [
              { label: 'Cancel', value: 'cancel' },
              { label: 'Confirm & Transfer (Logs Out Other Device)', value: 'confirm', primary: true }
            ]
          });
          if (choice && choice.action === 'confirm') {
            return GoogleCloud.onTokenReceived(accessToken, true);
          } else {
            dlg({ tone: 'info', title: 'Transfer Cancelled', message: 'Licence remains active on your other device. No changes made.' });
            return;
          }
        }

        // SCENARIO A: Paid Lifetime License
        if (status.licensed && status.token) {
          var applied = await GoogleCloud._applyToken(status.token, machineRef);
          if (!applied.ok) {
            dlg({ tone: 'error', title: 'Licence found but not applied',
                  message: 'This Google account owns a StoreFlow licence, but this device could not apply it:\n\n' + applied.msg + '\n\nPlease try again, or contact support.',
                  support: true, machineRef: machineRef });
            return;
          }

          sessionStorage.removeItem('_sf_banner_dismissed');

          // Check for cloud backups on Google Drive
          var backup = await GoogleCloud.findLatestDriveBackup(accessToken);
          if (backup) {
            var c = await dlg({
              tone: 'success',
              title: 'Licence Verified & Cloud Backup Found',
              message: 'Welcome back, ' + email + '!\nYour Lifetime Licence is active.\n\nFound a Google Drive backup: "' + backup.name + '" (' + GoogleCloud.formatBytes(backup.size) + ', ' + new Date(backup.modifiedTime).toLocaleDateString() + ').\nWould you like to restore your store records now?',
              buttons: [
                { label: 'Keep Local Data', value: 'skip' },
                { label: 'Restore from Google Drive', value: 'restore', primary: true }
              ]
            });
            if (c && c.action === 'restore') {
              await GoogleCloud.restoreDriveFile(backup, accessToken);
              return;
            }
            location.reload();
            return;
          }

          await dlg({
            tone: 'success',
            title: 'StoreFlow Unlocked!',
            message: 'Welcome back, ' + email + '!\nYour Lifetime Licence is active on this device.',
            buttons: [{ label: 'Continue to StoreFlow', value: 'ok', primary: true }]
          });
          location.reload();
          return;
        }

        if (status.edition_mismatch) {
          dlg({ tone: 'error', title: 'Different edition', message: status.msg, support: true, machineRef: machineRef });
          return;
        }

        // If the local terminal already has an active Lifetime License, acknowledge it cleanly (#156 UX)
        if (isLocallyLicensed()) {
          var existing = await GoogleCloud.findLatestDriveBackup(accessToken);
          if (existing) {
            var r = await dlg({
              tone: 'info',
              title: 'Cloud Backup Found',
              message: 'Signed in as ' + email + '.\nYour terminal is active with a Permanent Lifetime License.\n\nFound a backup on Google Drive: "' + existing.name + '". Would you like to restore it?',
              buttons: [
                { label: 'Skip', value: 'skip' },
                { label: 'Restore Data', value: 'restore', primary: true }
              ]
            });
            if (r && r.action === 'restore') {
              await GoogleCloud.restoreDriveFile(existing, accessToken);
              return;
            }
          }

          dlg({
            tone: 'success',
            title: 'Google Account Connected',
            message: 'Signed in as ' + email + '.\n\nYour terminal is active with a Permanent Lifetime Commercial License.\nYou can back up your store database to your personal Google Drive anytime from Settings → Backups.',
            buttons: [{ label: 'Continue to StoreFlow', value: 'ok', primary: true }]
          });
          return;
        }

        // SCENARIO B: Unlicensed account response handled according to user intent
        var intent = GoogleCloud._currentIntent || sessionStorage.getItem('_sf_auth_intent') || 'recover';

        if (intent === 'purchase') {
          // User intended to purchase lifetime license
          if (typeof window.sfLaunchPaystackCheckout === 'function') {
            window.sfLaunchPaystackCheckout(email);
            return;
          }
        }

        // Default / Recovery intent when no license found on cloud worker
        var existingBackup = await GoogleCloud.findLatestDriveBackup(accessToken);
        var subMsg = existingBackup ? ('\n\nFound a Google Drive backup: "' + existingBackup.name + '".') : '';

        var promptChoice = await dlg({
          tone: 'info',
          title: 'No Active License Found',
          message: 'Signed in as ' + email + '.\nNo StoreFlow Lifetime License was found under this Google account.' + subMsg + '\n\nTo activate StoreFlow, you can purchase a lifetime license or contact support with your Machine ID.',
          buttons: [
            { label: 'Return to StoreFlow', value: 'cancel' },
            { label: 'Purchase Lifetime License', value: 'purchase', primary: true }
          ]
        });

        if (promptChoice && promptChoice.action === 'purchase') {
          if (typeof window.sfLaunchPaystackCheckout === 'function') {
            window.sfLaunchPaystackCheckout(email);
          }
        }

      } catch (err) {
        console.error('[GoogleCloud]', err);
        dlg({ tone: 'error', title: 'Connection failed',
              message: 'Could not complete Google check: ' + (err && err.message ? err.message : 'network error') });
      }
    },

    // Apply Ed25519 Token
    _applyToken: async function(token, machineRef) {
      if (/^SF-MOB-/.test(machineRef)) {
        if (!window.StoreFlowMobileLicense || typeof window.StoreFlowMobileLicense.activate !== 'function') {
          return { ok: false, msg: 'The mobile licence module is not loaded.' };
        }
        var r = window.StoreFlowMobileLicense.activate(token, machineRef);
        return (r && r.ok) ? { ok: true } : { ok: false, msg: (r && (r.msg || r.message)) || 'Key was rejected on this phone.' };
      }
      try {
        var res = await fetch('api/endpoints/system.php?action=sync', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ token: token })
        });
        var data = null;
        try { data = await res.json(); } catch (e) {}
        if (res.ok && data && (data.ok || data.success)) return { ok: true };
        return { ok: false, msg: (data && (data.msg || data.message)) || ('Local server answered HTTP ' + res.status + '.') };
      } catch (e) {
        return { ok: false, msg: 'Could not reach local StoreFlow server: ' + e.message };
      }
    },

    // Search Google Drive for backups (cross-compatible .db and .sfbak)
    findLatestDriveBackup: async function(accessToken, targetMachineRef) {
      if (isPhoneShell()) return null; // Phone backups use native local document storage (#154)
      try {
        var ref = (targetMachineRef || getMachineRef() || '').substring(0, 12);
        if (!ref) {
          console.warn('[GoogleCloud] Machine reference is missing for Drive backup search.');
          return null;
        }
        var q = "name contains 'StoreFlow' and name contains '.sfbak' and name contains '" + ref + "' and trashed = false";
        var url = 'https://www.googleapis.com/drive/v3/files?q=' + encodeURIComponent(q) +
                  '&orderBy=modifiedTime%20desc&fields=files(id,name,size,modifiedTime)&pageSize=1';
        var res = await fetch(url, { headers: { Authorization: 'Bearer ' + accessToken } });
        if (!res.ok) return null;
        var data = await res.json();
        return (data.files && data.files.length) ? data.files[0] : null;
      } catch (e) {
        console.warn('[GoogleCloud] Drive search failed:', e);
        return null;
      }
    },

    // Restore Backup from Google Drive
    restoreDriveFile: async function(fileMeta, accessToken) {
      dlg({ tone: 'busy', title: 'Restoring Database…',
            message: 'Downloading backup "' + fileMeta.name + '" from Google Drive…', dismissible: false });

      try {
        var token = accessToken || currentAccessToken;
        var dl = await fetch('https://www.googleapis.com/drive/v3/files/' + encodeURIComponent(fileMeta.id) + '?alt=media', {
          headers: { Authorization: 'Bearer ' + token }
        });
        if (!dl.ok) throw new Error('Google Drive answered HTTP ' + dl.status);
        var blob = await dl.blob();
        if (!blob.size) throw new Error('Downloaded backup file was empty');

        var isDb = fileMeta.name.endsWith('.db') || (fileMeta.name.indexOf('.sfbak') === -1 && fileMeta.name.indexOf('.sfbackup') === -1);

        // PHONE RESTORE
        if (isPhoneShell()) {
          if (!window.StoreFlowAndroid || typeof window.StoreFlowAndroid.restoreDatabaseFromBase64 !== 'function') {
            throw new Error('Native database restore bridge is not available on this phone.');
          }

          if (!isDb) {
            throw new Error('This backup is an encrypted PC archive (.sfbak). Please restore it on your PC or restore an unencrypted .db backup.');
          }

          var reader = new FileReader();
          reader.onload = async function() {
            var base64 = (reader.result || '').split(',')[1] || '';
            var ok = window.StoreFlowAndroid.restoreDatabaseFromBase64(base64);
            if (ok) {
              await dlg({ tone: 'success', title: 'Restore Complete!',
                          message: 'Store database successfully restored from Google Drive.',
                          buttons: [{ label: 'Reload StoreFlow', value: 'ok', primary: true }] });
              location.reload();
            } else {
              dlg({ tone: 'error', title: 'Restore Failed', message: 'Could not write database onto phone storage.' });
            }
          };
          reader.readAsDataURL(blob);
          return;
        }

        // PC RESTORE
        if (isDb) {
          // Standard SQLite .db restore via upload_restore
          var fd = new FormData();
          fd.append('action', 'upload_restore');
          fd.append('backup_file', blob, fileMeta.name);
          var res = await apiFetch('api/endpoints/backups.php', { method: 'POST', body: fd });
          var data = null;
          try { data = await res.json(); } catch (e) {}
          if (!res.ok || !data || !data.success) {
            throw new Error((data && data.message) || ('Local server answered HTTP ' + res.status));
          }
          await dlg({ tone: 'success', title: 'Restore Complete!', message: data.message,
                      buttons: [{ label: 'Reload StoreFlow', value: 'ok', primary: true }] });
          location.reload();
          return;
        } else {
          // Encrypted .sfbak restore via import_restore
          var pass = await GoogleCloud._askPassphrase(
            'Restore Encrypted Backup',
            'Type the passphrase this backup was encrypted with.',
            'Decrypt & Restore',
            true
          );
          if (!pass) return;

          var fd2 = new FormData();
          fd2.append('action', 'import_restore');
          fd2.append('passphrase', pass);
          fd2.append('sfbak_file', blob, fileMeta.name);
          var res2 = await apiFetch('api/endpoints/backups.php', { method: 'POST', body: fd2 });
          var data2 = null;
          try { data2 = await res2.json(); } catch (e) {}
          if (res2.status === 409 && data2 && data2.cross_machine) {
            var conf = await dlg({
              tone: 'warning',
              brandSubtitle: 'Cross-Terminal Restore',
              title: 'Different Terminal Backup',
              message: (data2.message || 'This backup was created on a different machine.') + '\n\nAre you sure you want to restore it and overwrite this terminal\'s records?',
              buttons: [
                { label: 'Cancel', value: 'cancel' },
                { label: 'Overwrite & Restore', value: 'confirm', primary: true }
              ]
            });
            if (conf && conf.action === 'confirm') {
              fd2.append('cross_machine_confirmed', '1');
              res2 = await apiFetch('api/endpoints/backups.php', { method: 'POST', body: fd2 });
              try { data2 = await res2.json(); } catch (e) {}
            } else {
              return;
            }
          }
          if (!res2.ok || !data2 || !data2.success) {
            throw new Error((data2 && data2.message) || ('Local server answered HTTP ' + res2.status));
          }
          await dlg({ tone: 'success', title: 'Restore Complete!', message: data2.message,
                      buttons: [{ label: 'Reload StoreFlow', value: 'ok', primary: true }] });
          location.reload();
          return;
        }
      } catch (err) {
        console.error('[GoogleCloud] Restore error:', err);
        dlg({ tone: 'error', title: 'Restore Failed', message: err.message + '\n\nNo records were changed.' });
      }
    },

    // Backup current database directly to Google Drive
    uploadBackupToDrive: function() {
      if (isPhoneShell()) {
        dlg({
          tone: 'info',
          title: 'Device Backups',
          message: 'On the Phone Standalone edition, database backups are saved securely to your device\'s Documents folder to maintain offline privacy.\n\nUse Settings → Backups to create or restore device backups.',
          buttons: [{ label: 'OK', value: 'ok', primary: true }]
        });
        return;
      }
      if (!currentAccessToken) {
        return GoogleCloud._withToken(function(token) {
          return GoogleCloud._uploadWithToken(token);
        });
      }
      return GoogleCloud._uploadWithToken(currentAccessToken);
    },

    _uploadWithToken: async function(accessToken) {
      dlg({ tone: 'busy', title: 'Backing Up to Google Drive…',
            message: 'Exporting store database…', dismissible: false });

      try {
        var machineRef = getMachineRef();
        if (!machineRef) {
          throw new Error('Device machine reference is missing. Please reload StoreFlow and try again.');
        }
        var stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
        var blob = null;
        var fileName = '';
        var mimeType = 'application/octet-stream';

        // PHONE BACKUP
        if (isPhoneShell()) {
          if (!window.StoreFlowAndroid || typeof window.StoreFlowAndroid.getDatabaseBase64 !== 'function') {
            throw new Error('Native database export is not available on this phone.');
          }

          var b64 = window.StoreFlowAndroid.getDatabaseBase64();
          if (!b64) throw new Error('Could not read store database from phone storage.');

          var binaryStr = atob(b64);
          var len = binaryStr.length;
          var bytes = new Uint8Array(len);
          for (var i = 0; i < len; i++) {
            bytes[i] = binaryStr.charCodeAt(i);
          }
          blob = new Blob([bytes], { type: 'application/octet-stream' });
          fileName = 'StoreFlow-backup-phone-' + stamp + '.db';
        } else {
          // PC BACKUP: Passphrase-encrypted export (.sfbak) (#159, #160)
          var pass = await GoogleCloud._askPassphrase(
            'Encrypt Cloud Backup',
            'Choose a passphrase (at least 10 characters) to encrypt your store database before uploading to Google Drive.',
            'Encrypt & Upload'
          );
          if (!pass) return;

          dlg({ tone: 'busy', title: 'Encrypting Database…', message: 'Creating encrypted .sfbak container…', dismissible: false });

          var expRes = await apiFetch('api/endpoints/backups.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'export_encrypted', passphrase: pass })
          });

          if (!expRes.ok) {
            var errData = null;
            try { errData = await expRes.json(); } catch (e) {}
            throw new Error((errData && errData.message) || ('Server export failed with HTTP ' + expRes.status));
          }

          blob = await expRes.blob();
          fileName = 'StoreFlow-backup-' + machineRef.substring(0, 12) + '-' + stamp + '.sfbak';
        }

        if (!blob || !blob.size) throw new Error('Database backup file was empty');

        dlg({ tone: 'busy', title: 'Uploading to Google Drive…',
              message: 'Uploading encrypted backup (' + GoogleCloud.formatBytes(blob.size) + ') to Google Drive…', dismissible: false });

        var boundary = 'sf' + Date.now().toString(16) + Math.random().toString(16).slice(2);
        var meta = JSON.stringify({
          name: fileName,
          mimeType: 'application/octet-stream',
          description: 'StoreFlow POS Passphrase-Encrypted Cloud Backup (Machine: ' + machineRef.substring(0, 12) + ')'
        });

        var body = new Blob([
          '--' + boundary + '\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n' + meta + '\r\n',
          '--' + boundary + '\r\nContent-Type: ' + mimeType + '\r\n\r\n',
          blob,
          '\r\n--' + boundary + '--'
        ]);

        var up = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,size', {
          method: 'POST',
          headers: {
            Authorization: 'Bearer ' + accessToken,
            'Content-Type': 'multipart/related; boundary=' + boundary
          },
          body: body
        });

        if (!up.ok) throw new Error('Google Drive upload answered HTTP ' + up.status);
        var saved = await up.json();
        if (!saved || !saved.id) throw new Error('Google Drive did not confirm the upload');

        dlg({
          tone: 'success',
          title: 'Backup Saved to Google Drive!',
          message: 'Your store database has been securely uploaded to your personal Google Drive:\n"' + saved.name + '" (' + GoogleCloud.formatBytes(Number(saved.size) || blob.size) + ').'
        });

      } catch (err) {
        console.error('[GoogleCloud] Upload error:', err);
        dlg({ tone: 'error', title: 'Backup Failed', message: err.message + '\n\nNothing was uploaded.' });
      }
    },

    _askPassphrase: async function(title, message, confirmLabel, isRestore) {
      var r = await dlg({
        tone: 'info',
        brandSubtitle: 'Zero-Knowledge Encryption',
        brandIcon: 'fa-solid fa-shield-halved',
        brandColor: '#10b981',
        title: title || 'Encrypt Cloud Backup',
        message: (message || 'Choose a passphrase (at least 10 characters) to encrypt your store database.') +
                 '\n\nYour database is encrypted with Sodium Argon2id before leaving this machine. Google cannot read your store records.',
        input: {
          label: 'Encryption Passphrase',
          type: 'password',
          placeholder: 'Enter at least 10 characters…',
          autocomplete: 'off',
          validate: function(v) { return (v && v.length >= 10) ? '' : 'Passphrase must be at least 10 characters.'; }
        },
        buttons: [
          { label: 'Cancel', value: 'cancel' },
          { label: confirmLabel || 'Encrypt & Upload', value: 'go', primary: true }
        ]
      });
      return (r && r.action === 'go') ? r.value : null;
    },

    // Check if another device has taken over this license
    

    formatBytes: function(bytes) {
      bytes = Number(bytes) || 0;
      if (!bytes) return '0 B';
      var k = 1024, sizes = ['B', 'KB', 'MB', 'GB'];
      var i = Math.min(sizes.length - 1, Math.floor(Math.log(bytes) / Math.log(k)));
      return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
    }
  };

  try { localStorage.removeItem('_sf_cloud_backup_pass'); } catch (e) {}
  window.StoreFlowGoogleCloud = GoogleCloud;

  })();