// assets/js/app.js - StoreFlow Application Core Controller

class StoreApp extends StoreAppData {
  constructor() {
    super();
    this.mobileTableMode = localStorage.getItem('storeflow_mobile_table_mode') || 'cards';
  }

  async fastCashCheckout() {
    if (this.currentView !== 'pos') {
      this.switchView('pos');
      return;
    }
    if (!this.cart || this.cart.length === 0) {
      this.showToast('Cart is empty. Add a product first.', 'warning');
      return;
    }

    const { totalAmount } = this.getCartTotals();

    // Setup Cash Tender with exact total
    this.selectedPaymentMethod = 'CASH';
    const amountInput = document.getElementById('checkout-amount-paid');
    if (amountInput) amountInput.value = totalAmount.toFixed(2);
    this.updateCheckoutChange();

    this.showToast('Fast Cash: Processing exact cash sale...', 'info');
    await this.confirmFinalCheckout();
  }

  navigatePosGrid(direction) {
    const grid = document.getElementById('pos-product-grid');
    if (!grid) return;
    const cards = Array.from(grid.querySelectorAll('.pos-product-card:not([style*="display: none"])'));
    if (!cards.length) return;

    // Remove existing highlights
    cards.forEach(c => c.classList.remove('keyboard-highlighted'));

    // Estimate column count dynamically from layout width
    const cardWidth = cards[0]?.offsetWidth || 180;
    const cols = Math.max(1, Math.round(grid.clientWidth / cardWidth));

    if (this.focusedProductIndex === -1 || this.focusedProductIndex === undefined) {
      this.focusedProductIndex = 0;
    } else {
      switch (direction) {
        case 'right':
          this.focusedProductIndex = Math.min(cards.length - 1, this.focusedProductIndex + 1);
          break;
        case 'left':
          this.focusedProductIndex = Math.max(0, this.focusedProductIndex - 1);
          break;
        case 'down':
          this.focusedProductIndex = Math.min(cards.length - 1, this.focusedProductIndex + cols);
          break;
        case 'up':
          if (this.focusedProductIndex < cols) {
            this.focusedProductIndex = -1;
            const searchInput = document.getElementById('pos-search');
            if (searchInput) {
              searchInput.focus();
              searchInput.select();
            }
            return;
          }
          this.focusedProductIndex = Math.max(0, this.focusedProductIndex - cols);
          break;
      }
    }

    const activeCard = cards[this.focusedProductIndex];
    if (activeCard) {
      activeCard.classList.add('keyboard-highlighted');
      activeCard.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }
  }

  // ─── Session Scope & Quota System ──────────────────────────────────────────
  // (checks app usage entitlement from server on each session start)

  async syncHeartbeat() {
    try {
      if (this.isStandaloneOffline || window.location.hostname === 'storeflow.local' || window.location.protocol === 'file:') {
        if (typeof window.getMobileStandaloneLicense !== 'function') {
          // The phone has no server to ask and no licence reader of its own. That is
          // an unlicensed device, not a pass: this used to fall through to the
          // heartbeat, which a phone can never answer, and the app opened unlocked.
          this._showPaywall();
          return;
        }
        const mLic = typeof window.phoneLicenceOrLock === 'function'
          ? window.phoneLicenceOrLock(window.getMobileStandaloneLicense())
          : window.getMobileStandaloneLicense();
        if (!mLic || !mLic.ok) {
          this._showPaywall();
          return;
        }
        this._sessionScope = mLic.status;   // 'trial' | 'active' | 'expired'
        this._quotaDays = mLic.quota;
        this._quotaTotal = mLic.quotaTotal || 14;
        this._machineRef = mLic.ref || '';
        if (this._machineRef) {
          sessionStorage.setItem('_sf_ref', this._machineRef);
          this.updateSupportLinks(this._machineRef);
        }
        if (mLic.status === 'expired') {
          this._isInitialLock = false;
          this._showPaywall(mLic.reason);
        } else if (mLic.status === 'trial') {
          this._showTrialBanner(mLic.quota, this._quotaTotal);
        } else if (mLic.status === 'active') {
          const banner = document.getElementById('trial-banner');
          if (banner) banner.style.setProperty('display', 'none', 'important');
          this.updateLicenseBadge('active');
        }
        return;
      }

      const res = await fetch('api/endpoints/system.php?action=heartbeat');
      const data = await res.json();
      if (!data || !data.ok) return;
      this._sessionScope = data.status;   // 'trial' | 'active' | 'expired'
      this._quotaDays = data.quota;
      this._quotaTotal = data.total;
      this._machineRef = data.ref || '';
      if (this._machineRef) {
        sessionStorage.setItem('_sf_ref', this._machineRef);
        this.updateSupportLinks(this._machineRef);
      }
      if (data.status === 'expired') {
        this._isInitialLock = !!data.is_initial;
        this._showPaywall();
      } else if (data.status === 'trial') {
        this._showTrialBanner(data.quota, data.total);
      } else if (data.status === 'active') {
        const banner = document.getElementById('trial-banner');
        if (banner) banner.style.setProperty('display', 'none', 'important');
        this.updateLicenseBadge('active');
      }
    } catch (e) { /* silent — app continues offline */ }
  }

  _showTrialBanner(daysLeft, totalDays) {
    if (daysLeft > 3 && sessionStorage.getItem('_sf_banner_dismissed')) {
      this.updateLicenseBadge('trial', daysLeft);
      return;
    }
    const banner = document.getElementById('trial-banner');
    if (banner) {
      const daysEl = document.getElementById('trial-days-left');
      if (daysEl) daysEl.textContent = daysLeft;
      const unitEl = document.getElementById('trial-days-unit');
      if (unitEl) unitEl.textContent = Number(daysLeft) === 1 ? 'day' : 'days';
      const headline = document.getElementById('trial-banner-headline');
      if (headline) headline.textContent = daysLeft <= 3
        ? `Free Trial • ${daysLeft} Day${daysLeft !== 1 ? 's' : ''} Left!`
        : `StoreFlow Enterprise Evaluation (${daysLeft} Days)`;
      const sub = document.getElementById('trial-banner-sub');
      if (sub) sub.textContent = daysLeft <= 3
        ? `Your trial expires soon. Enter an extension or license key anytime to ensure uninterrupted cashier checkout.`
        : `Activate your license anytime to permanently secure your store database and multi-terminal access.`;
      banner.style.setProperty('display', 'block', 'important');
      const container = document.getElementById('app-container');
      if (container) container.classList.add('has-trial-banner');
    }
    this.updateLicenseBadge('trial', daysLeft);
  }

  updateLicenseBadge(status, daysLeft = 0) {
    ['topbar-license-badge', 'drawer-license-badge'].forEach(id => {
      const badge = document.getElementById(id);
      if (!badge) return;
      if (status === 'trial') {
        badge.className = Number(daysLeft) <= 3 ? 'badge badge-danger' : 'badge badge-warning';
        badge.style.setProperty('display', 'inline-flex', 'important');
      } else {
        badge.style.setProperty('display', 'none', 'important');
      }
    });
    ['topbar-license-text', 'drawer-license-text'].forEach(id => {
      const text = document.getElementById(id);
      if (text) {
        text.textContent = `Trial: ${daysLeft} Day${Number(daysLeft) !== 1 ? 's' : ''} Left`;
      }
    });
  }

  dismissTrialBanner() {
    const banner = document.getElementById('trial-banner');
    if (banner) banner.style.setProperty('display', 'none', 'important');
    const container = document.getElementById('app-container');
    if (container) container.classList.remove('has-trial-banner');
    sessionStorage.setItem('_sf_banner_dismissed', '1');
  }

  _showPaywall(reason) {
    ['login-screen', 'app-container', 'trial-banner'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.style.display = 'none';
    });
    const ref = this._machineRef || sessionStorage.getItem('_sf_ref') || '—';
    const mid = document.getElementById('paywall-machine-id-display');
    if (mid) mid.textContent = ref;
    if (ref && ref !== '—') this.updateSupportLinks(ref);

    const titleEl = document.getElementById('paywall-title');
    const subtitleEl = document.querySelector('.paywall-subtitle');
    const phoneWords = {
      'device-mismatch': ['This Key Was Issued to a Different Device',
        'Send the Machine ID above to Evans (+233 24 834 3007), who re-issues one that opens this handset at no cost.'],
      'key-not-valid-for-this-device': ['This Key Does Not Open This Phone',
        'Check you pasted the whole key. If it was bought for another device, send the Machine ID above to Evans (+233 24 834 3007) before paying again.'],
      'trial-elapsed': ['Your Free Trial Has Ended',
        'Enter the license key issued for this phone to keep trading and keep your records.'],
      'storage-unavailable': ['StoreFlow Cannot Read Its Licence',
        'Restart StoreFlow. If this returns, call +233 24 834 3007. Your records are safe — only the licence cannot be checked.']
    };
    phoneWords['no-native-storage'] = phoneWords['no-device-reference'] = phoneWords['no-verifier'] = phoneWords['storage-unavailable'];
    if (reason && phoneWords[reason]) {
      if (titleEl) titleEl.textContent = phoneWords[reason][0];
      if (subtitleEl) subtitleEl.textContent = phoneWords[reason][1];
    } else if (this._isInitialLock) {
      if (titleEl) titleEl.textContent = 'StoreFlow Activation Required';
      if (subtitleEl) subtitleEl.textContent = 'Welcome to StoreFlow! To begin your evaluation trial or activate full access, please provide your Machine ID to your sales representative.';
    } else {
      if (titleEl) titleEl.textContent = 'Your Free Trial Has Ended';
      if (subtitleEl) subtitleEl.textContent = 'Thank you for evaluating StoreFlow! Enter your license or trial extension key below to continue using all features.';
    }

    const paywall = document.getElementById('license-paywall');
    if (paywall) paywall.style.display = 'flex';
  }

  _hidePaywall() {
    const paywall = document.getElementById('license-paywall');
    if (paywall) paywall.style.display = 'none';
  }

  async openLicenseModal() {
    let ref = this._machineRef || sessionStorage.getItem('_sf_ref') || '';
    const mid = document.getElementById('license-modal-machine-id');
    if (!ref || ref === '—') {
      if (mid) mid.textContent = 'Loading machine ID...';
      try {
        const res = await fetch('api/endpoints/system.php?action=heartbeat');
        const data = await res.json();
        if (data && data.ref) {
          ref = data.ref;
          this._machineRef = ref;
          sessionStorage.setItem('_sf_ref', ref);
        }
      } catch (e) { /* offline fallback */ }
    }
    if (mid) mid.textContent = ref || '—';
    if (ref && ref !== '—') {
      this.updateSupportLinks(ref);
    }
    const modal = document.getElementById('license-modal');
    if (modal) modal.classList.add('active');
    setTimeout(() => { const inp = document.getElementById('license-modal-key-input'); if (inp) inp.focus(); }, 80);
  }

  closeLicenseModal() {
    const modal = document.getElementById('license-modal');
    if (modal) modal.classList.remove('active');
  }

  updateSupportLinks(ref) {
    if (!ref || ref === '—') return;
    const waMsg = encodeURIComponent(`Hello Evans, I would like to purchase a StoreFlow license key.\n\nMy Machine ID is: ${ref}`);
    const mailSub = encodeURIComponent('StoreFlow License Key Purchase');
    const mailBody = encodeURIComponent(`Hello Evans,\n\nI would like to purchase a StoreFlow license key.\n\nMy Machine ID is: ${ref}`);
    ['paywall-wa-link', 'modal-wa-link'].forEach(id => {
      const a = document.getElementById(id);
      if (a) a.href = `https://wa.me/233248343007?text=${waMsg}`;
    });
    ['paywall-email-link', 'modal-email-link'].forEach(id => {
      const a = document.getElementById(id);
      if (a) a.href = `mailto:www.frivans@gmail.com?subject=${mailSub}&body=${mailBody}`;
    });
    ['paywall-machine-id-display', 'license-modal-machine-id', 'about-machine-id'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.textContent = ref;
    });
  }

  copyMachineId(btn = null, elementId = 'license-modal-machine-id') {
    if (typeof window.sfCopyMachineId === 'function') {
      window.sfCopyMachineId(btn, elementId);
    } else {
      const ref = this._machineRef || sessionStorage.getItem('_sf_ref') || '';
      if (!ref) return;
      try {
        const ta = document.createElement('textarea');
        ta.value = ref;
        ta.style.position = 'fixed';
        ta.style.left = '-9999px';
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        this.showToast('Machine ID copied to clipboard.', 'success');
      } catch (e) {
        prompt('Copy your Machine ID:', ref);
      }
    }
  }

  async submitLicenseKey(inputId, alertId, btnId) {
    const inputEl = document.getElementById(inputId);
    const alertEl = document.getElementById(alertId);
    const btnEl = document.getElementById(btnId);
    if (!inputEl) return;
    const token = inputEl.value.trim();
    if (!token) { this._showScopeAlert(alertEl, 'Please enter your unlock token.'); return; }
    // On the Standalone phone there is no server to ask, and asking one used to end in
    // "Connection error" forever, because this form only ever POSTed to PHP the APK
    // does not carry. The phone checks the signature against its own device reference.
    if (window.location.hostname === 'storeflow.local' || window.location.protocol === 'file:') {
      if (typeof window.sfSubmitLicense === 'function') return window.sfSubmitLicense(inputId, alertId, btnId);
      if (btnEl) btnEl.disabled = false;
      this._showScopeAlert(alertEl, 'This phone cannot check a key yet. Restart StoreFlow and try again.');
      return;
    }
    if (btnEl) { btnEl.disabled = true; btnEl.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Verifying\u2026'; }
    if (alertEl) alertEl.style.display = 'none';
    try {
      const res = await fetch('api/endpoints/system.php?action=sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token })
      });
      const data = await res.json();
      if (data.ok) {
        sessionStorage.removeItem('_sf_banner_dismissed');
        if (data.status === 'trial') {
          this._sessionScope = 'trial';
          this._quotaDays = data.quota;
          this._quotaTotal = data.total;
          this._showTrialBanner(data.quota, data.total);
        } else {
          this._sessionScope = 'active';
          this.dismissTrialBanner();
          this.updateLicenseBadge('active');
        }
        this._hidePaywall();
        this.closeLicenseModal();
        this.showToast('\u2705 ' + (data.msg || 'Activated successfully!'), 'success');
        // Reload after brief delay so full UI restores cleanly
        setTimeout(() => location.reload(), 1200);
      } else {
        this._showScopeAlert(alertEl, data.msg || 'Invalid token. Please check and try again.');
      }
    } catch (e) {
      this._showScopeAlert(alertEl, 'Connection error. Please try again.');
    } finally {
      if (btnEl) { btnEl.disabled = false; btnEl.innerHTML = '<i class="fa-solid fa-unlock"></i> Activate'; }
    }
  }

  _showScopeAlert(alertEl, message) {
    if (!alertEl) return;
    const msgEl = alertEl.querySelector('span') || alertEl;
    msgEl.textContent = message;
    alertEl.style.display = 'flex';
  }

  generateProductBarcode() {
    // Generate valid EAN-13 format starting with 200 (GS1 standard prefix for in-store internal distribution)
    let code = '200' + Math.floor(100000000 + Math.random() * 900000000).toString();
    let sum = 0;
    for (let i = 0; i < 12; i++) {
      sum += parseInt(code[i], 10) * (i % 2 === 0 ? 1 : 3);
    }
    const checkDigit = (10 - (sum % 10)) % 10;
    const fullBarcode = code + checkDigit;

    const barcodeInput = document.getElementById('prod-form-barcode');
    if (barcodeInput) {
      barcodeInput.value = fullBarcode;
      barcodeInput.dispatchEvent(new Event('input', { bubbles: true }));
      this.showToast(`Generated in-store barcode: ${fullBarcode}`, 'success');
      this.playBeepSound(1200);
    }
  }

  async scanBarcodeFromImageFile(event) {
    const file = event.target?.files?.[0];
    if (!file) return;
    try {
      this.showToast('Analyzing barcode photo...', 'info');
      if (this.isScannerRunning && this.html5QrCode) {
        await this.stopCameraScannerInstance();
      }

      // Only support verified retail formats with checksums to prevent phantom reads (e.g. "NA")
      const formats = (typeof Html5QrcodeSupportedFormats !== 'undefined') ? [
        Html5QrcodeSupportedFormats.EAN_13,
        Html5QrcodeSupportedFormats.EAN_8,
        Html5QrcodeSupportedFormats.UPC_A,
        Html5QrcodeSupportedFormats.UPC_E,
        Html5QrcodeSupportedFormats.CODE_128,
        Html5QrcodeSupportedFormats.QR_CODE
      ] : undefined;

      const readerEl = document.getElementById('camera-scanner-reader');
      if (readerEl) readerEl.innerHTML = '';

      const scanner = new Html5Qrcode('camera-scanner-reader', {
        formatsToSupport: formats,
        verbose: false,
        experimental: {
          useBarCodeDetectorIfSupported: true
        }
      });
      this.html5QrCode = scanner;

      const decodedText = await scanner.scanFile(file, true);
      if (decodedText) {
        this.onBarcodeDetected(decodedText);
      }
    } catch (err) {
      console.warn('Image barcode scan error:', err);
      this.showToast('Could not detect barcode in that image. Ensure barcode is sharp, well-lit, and not cut off.', 'warning');
    } finally {
      if (event.target) event.target.value = '';
    }
  }

  submitManualScannerInput() {
    const input = document.getElementById('scanner-manual-input');
    if (!input) return;
    const code = input.value.trim();
    if (!code) {
      this.showToast('Please type a barcode number or SKU.', 'warning');
      return;
    }
    input.value = '';
    this.onBarcodeDetected(code);
  }


  playBeepSound(frequency = 1400) {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.value = frequency;
      gain.gain.value = 0.12;
      osc.start();
      setTimeout(() => {
        try {
          osc.stop();
          ctx.close();
        } catch (e) { }
      }, 90);
    } catch (e) { }
  }

  async openCameraScanner(targetMode = 'pos') {
    this.scannerTargetMode = targetMode;
    const modal = document.getElementById('camera-scanner-modal');
    if (!modal) return;

    if (typeof Html5Qrcode === 'undefined') {
      this.showToast('Barcode scanner library is loading. Please try again in a moment.', 'warning');
      return;
    }

    const titleEl = document.getElementById('camera-scanner-title');
    const continuousLabel = document.getElementById('scanner-continuous-toggle-label');
    const continuousCheckbox = document.getElementById('scanner-continuous-mode');

    if (targetMode === 'product-form') {
      if (titleEl) titleEl.innerHTML = '<i class="fa-solid fa-barcode"></i> Scan Barcode for Product';
      if (continuousLabel) continuousLabel.style.display = 'none';
      if (continuousCheckbox) continuousCheckbox.checked = false;
    } else if (targetMode === 'stock-audit') {
      if (titleEl) titleEl.innerHTML = '<i class="fa-solid fa-clipboard-check"></i> Stocktake Audit Scanner';
      if (continuousLabel) continuousLabel.style.display = 'flex';
      if (continuousCheckbox) continuousCheckbox.checked = true;
    } else {
      if (titleEl) titleEl.innerHTML = '<i class="fa-solid fa-barcode"></i> Scan Barcode to Cart';
      if (continuousLabel) continuousLabel.style.display = 'flex';
      if (continuousCheckbox) continuousCheckbox.checked = true;
    }

    const badge = document.getElementById('scanner-status-badge');
    if (badge) {
      badge.innerHTML = '<i class="fa-solid fa-camera"></i> Align barcode inside the guide box';
    }

    modal.classList.add('active');

    await this.stopCameraScannerInstance();

    const readerEl = document.getElementById('camera-scanner-reader');
    if (readerEl) readerEl.innerHTML = '';

    try {
      // Only support verified retail formats with checksums to prevent phantom reads (e.g. "NA")
      const formats = (typeof Html5QrcodeSupportedFormats !== 'undefined') ? [
        Html5QrcodeSupportedFormats.EAN_13,
        Html5QrcodeSupportedFormats.EAN_8,
        Html5QrcodeSupportedFormats.UPC_A,
        Html5QrcodeSupportedFormats.UPC_E,
        Html5QrcodeSupportedFormats.CODE_128,
        Html5QrcodeSupportedFormats.QR_CODE
      ] : undefined;

      this.html5QrCode = new Html5Qrcode('camera-scanner-reader', {
        formatsToSupport: formats,
        verbose: false,
        experimental: {
          useBarCodeDetectorIfSupported: true
        }
      });

      const cameras = await Html5Qrcode.getCameras().catch(() => []);
      this.availableCameras = cameras || [];

      const flipBtn = document.getElementById('btn-scanner-switch-cam');
      if (flipBtn) {
        flipBtn.style.display = (this.availableCameras.length > 1) ? 'inline-flex' : 'none';
      }

      // Prioritize environment/back camera if identified by label, else facingMode hint
      const backIdx = this.availableCameras.findIndex(c => /back|rear|environment/i.test(c.label || ''));
      this.currentCameraIndex = backIdx >= 0 ? backIdx : 0;
      const backCam = backIdx >= 0 ? this.availableCameras[backIdx] : null;

      await this.html5QrCode.start(
        { facingMode: 'environment' }, // ignored by html5-qrcode when videoConstraints is set
        this.getScannerConfig(backCam ? backCam.id : null),
        (decodedText) => {
          this.onBarcodeDetected(decodedText);
        },
        () => { }
      );

      this.isScannerRunning = true;
      const overlay = document.getElementById('scanner-viewfinder-overlay');
      if (overlay) overlay.style.display = 'block';

      // Attempt continuous autofocus if device camera supports it
      try {
        const track = this.html5QrCode.getRunningTrack();
        if (track && track.applyConstraints) {
          const caps = track.getCapabilities ? track.getCapabilities() : {};
          const adv = [];
          if (caps.focusMode && (caps.focusMode.includes('continuous') || caps.focusMode.includes('auto'))) {
            adv.push({ focusMode: 'continuous' });
          }
          if (adv.length > 0) {
            await track.applyConstraints({ advanced: adv });
          }
        }
      } catch (focusErr) {
        // Safe to ignore on webcams without focus motor
      }

      this.checkScannerTorchSupport();
    } catch (err) {
      console.error('Camera Scanner start error:', err);
      const isDenied = (err && (err.name === 'NotAllowedError' || String(err).includes('Permission')));
      if (isDenied) {
        this.showToast('Camera access permission was denied. Please allow camera permissions in your browser.', 'danger');
      } else {
        this.showToast('Could not start camera: ' + (err.message || 'No camera available'), 'danger');
      }
      this.closeCameraScanner();
    }
  }

  /**
   * Shared html5-qrcode live-scan config.
   * - qrbox: decode only a wide strip (matches the on-screen guide) instead of the full frame;
   *   with ZXing TRY_HARDER enabled, full-frame decoding is far too slow to catch a sharp frame.
   * - disableFlip: printed barcodes are never mirrored, so skip the second (flipped) decode pass.
   * - 720p: native resolution for most webcams (1080p is usually upscaled, softer and lower fps).
   * - deviceId goes inside videoConstraints because html5-qrcode ignores the camera id argument
   *   whenever videoConstraints is supplied.
   */
  getScannerConfig(deviceId = null) {
    const videoConstraints = {
      width: { ideal: 1280 },
      height: { ideal: 720 }
    };
    if (deviceId) {
      videoConstraints.deviceId = { exact: deviceId };
    } else {
      videoConstraints.facingMode = { ideal: 'environment' };
    }
    return {
      fps: 15,
      disableFlip: true,
      qrbox: (vw, vh) => {
        const width = Math.max(200, Math.floor(vw * 0.9));
        const height = Math.max(100, Math.floor(vh * 0.6));
        return { width: Math.min(width, vw), height: Math.min(height, vh) };
      },
      videoConstraints
    };
  }

  async stopCameraScannerInstance() {
    if (this.html5QrCode && this.isScannerRunning) {
      try {
        await this.html5QrCode.stop();
      } catch (e) { }
      try {
        this.html5QrCode.clear();
      } catch (e) { }
    }
    this.isScannerRunning = false;
    this.html5QrCode = null;
    this.isTorchOn = false;
  }

  async closeCameraScanner() {
    const modal = document.getElementById('camera-scanner-modal');
    if (modal) modal.classList.remove('active');

    const overlay = document.getElementById('scanner-viewfinder-overlay');
    if (overlay) overlay.style.display = 'none';

    await this.stopCameraScannerInstance();
  }

  onBarcodeDetected(decodedText) {
    if (!decodedText) return;
    const clean = String(decodedText).trim();
    // Guard against phantom reads or noise fragments (e.g. "NA", "A")
    // Real retail barcodes (EAN, UPC, Code 128) are always at least 4-6+ characters
    if (!clean || clean.length < 4) {
      console.warn('Ignored short/phantom barcode read:', clean);
      return;
    }

    const now = Date.now();
    if (this.lastScannedBarcode === clean && (now - (this.lastScannedBarcodeTime || 0) < 1400)) {
      return;
    }
    if (now - (this.lastScannedBarcodeTime || 0) < 650) {
      return;
    }

    this.lastScannedBarcode = clean;
    this.lastScannedBarcodeTime = now;

    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try { navigator.vibrate([60]); } catch (e) { }
    }

    if (this.scannerTargetMode === 'product-form') {
      const barcodeInput = document.getElementById('prod-form-barcode');
      if (barcodeInput) {
        barcodeInput.value = clean;
        barcodeInput.dispatchEvent(new Event('input', { bubbles: true }));
      }
      this.playBeepSound(1600);
      this.showToast(`Scanned Barcode: ${clean}`, 'success');
      this.closeCameraScanner();
    } else if (this.scannerTargetMode === 'stock-audit') {
      this.handleStockAuditBarcodeScan(clean);
      const isContinuous = document.getElementById('scanner-continuous-mode')?.checked ?? true;
      if (!isContinuous) {
        this.closeCameraScanner();
      }
    } else {
      this.handleBarcodeScan(clean);

      const isContinuous = document.getElementById('scanner-continuous-mode')?.checked ?? true;
      if (!isContinuous) {
        this.closeCameraScanner();
      } else {
        const badge = document.getElementById('scanner-status-badge');
        if (badge) {
          badge.innerHTML = `<i class="fa-solid fa-circle-check" style="color: #22c55e;"></i> Read: <strong>${this.escapeHtml(clean)}</strong>`;
          setTimeout(() => {
            if (badge && this.isScannerRunning) {
              badge.innerHTML = '<i class="fa-solid fa-camera"></i> Align next barcode inside the guide';
            }
          }, 1100);
        }
      }
    }
  }

  checkScannerTorchSupport() {
    const torchBtn = document.getElementById('btn-scanner-torch');
    if (!torchBtn) return;
    try {
      const track = this.html5QrCode?.getRunningTrack();
      const capabilities = track?.getCapabilities ? track.getCapabilities() : null;
      if (capabilities && capabilities.torch) {
        torchBtn.style.display = 'inline-flex';
      } else {
        torchBtn.style.display = 'none';
      }
    } catch (e) {
      torchBtn.style.display = 'none';
    }
  }

  async toggleScannerTorch() {
    if (!this.html5QrCode || !this.isScannerRunning) return;
    try {
      const track = this.html5QrCode.getRunningTrack();
      if (track && track.applyConstraints) {
        this.isTorchOn = !this.isTorchOn;
        await track.applyConstraints({
          advanced: [{ torch: this.isTorchOn }]
        });
        const lbl = document.getElementById('torch-label');
        if (lbl) lbl.textContent = this.isTorchOn ? 'Flash On' : 'Flash';
        const btn = document.getElementById('btn-scanner-torch');
        if (btn) btn.classList.toggle('btn-primary', this.isTorchOn);
      }
    } catch (e) {
      console.warn('Torch toggle error:', e);
    }
  }

  async switchScannerCamera() {
    if (!this.html5QrCode || !this.isScannerRunning || !this.availableCameras || this.availableCameras.length < 2) return;
    this.currentCameraIndex = ((this.currentCameraIndex || 0) + 1) % this.availableCameras.length;
    const nextCamera = this.availableCameras[this.currentCameraIndex];

    try {
      await this.html5QrCode.stop();
      this.isScannerRunning = false;

      await this.html5QrCode.start(
        nextCamera.id,
        this.getScannerConfig(nextCamera.id),
        (decodedText) => this.onBarcodeDetected(decodedText),
        () => { }
      );
      this.isScannerRunning = true;
      this.checkScannerTorchSupport();
    } catch (e) {
      console.error('Switch camera error:', e);
    }
  }

  // --- Connect Other Devices & Wireless Scanner Bridge (Phones & Tablets) ---

  async openConnectDevicesModal(initialTab = 'pos') {
    const modal = document.getElementById('connect-devices-modal');
    if (!modal) {
      this.openWirelessScannerModal();
      return;
    }
    modal.classList.add('active');

    const termInput = document.getElementById('connect-terminal-id-input');
    if (termInput) {
      termInput.value = this.terminalId || 'REG-01';
    }

    this.switchConnectDeviceTab(initialTab);
    await this.refreshConnectDevicesQr();
    this.fetchWirelessScannerHistory();
  }

  closeConnectDevicesModal() {
    const modal = document.getElementById('connect-devices-modal');
    if (modal) modal.classList.remove('active');
  }

  switchConnectDeviceTab(tab) {
    const tabPos = document.getElementById('tab-connect-pos');
    const tabGun = document.getElementById('tab-connect-gun');
    const contentPos = document.getElementById('connect-tab-content-pos');
    const contentGun = document.getElementById('connect-tab-content-gun');

    if (tab === 'pos') {
      if (tabPos) {
        tabPos.className = 'btn btn-sm';
        tabPos.style.background = '#ffffff';
        tabPos.style.color = 'var(--primary)';
        tabPos.style.boxShadow = '0 1px 2px rgba(0,0,0,0.06)';
      }
      if (tabGun) {
        tabGun.className = 'btn btn-sm btn-outline';
        tabGun.style.background = 'transparent';
        tabGun.style.color = 'var(--slate-700)';
        tabGun.style.boxShadow = 'none';
      }
      if (contentPos) contentPos.style.display = 'block';
      if (contentGun) contentGun.style.display = 'none';
    } else {
      if (tabGun) {
        tabGun.className = 'btn btn-sm';
        tabGun.style.background = '#ffffff';
        tabGun.style.color = 'var(--primary)';
        tabGun.style.boxShadow = '0 1px 2px rgba(0,0,0,0.06)';
      }
      if (tabPos) {
        tabPos.className = 'btn btn-sm btn-outline';
        tabPos.style.background = 'transparent';
        tabPos.style.color = 'var(--slate-700)';
        tabPos.style.boxShadow = 'none';
      }
      if (contentPos) contentPos.style.display = 'none';
      if (contentGun) contentGun.style.display = 'block';
    }
  }

  async refreshConnectDevicesQr() {
    const posQr = document.getElementById('connect-pos-qr-container');
    const posUrlInput = document.getElementById('connect-pos-url-input');
    const gunQr = document.getElementById('connect-gun-qr-container');
    const gunUrlInput = document.getElementById('connect-gun-url-input');
    const termInput = document.getElementById('connect-terminal-id-input');
    const ipSelector = document.getElementById('connect-ip-selector');
    const ipSelectorContainer = document.getElementById('connect-ip-selector-container');
    const term = this.normalizeTerminalId(termInput ? termInput.value : this.terminalId);

    try {
      const res = await this.apiFetch(`api/endpoints/scanner_bridge.php?action=info&terminal_id=${encodeURIComponent(term)}`);
      const data = await res.json();
      if (data.success) {
        // Behind a tunnel the till cannot name the address the phone will use: its own
        // LAN IP is a private one and its port belongs to the machine, so both are
        // dead links to anyone outside. Build the link from the address this page was
        // actually loaded from, unless the operator has deliberately picked an IP.
        const tunnelled = data.via_tunnel === true && !this.selectedConnectIp;
        const lanIp = tunnelled ? (window.location.hostname || data.server_ip)
                                : (this.selectedConnectIp || data.server_ip || window.location.hostname);
        const port = tunnelled ? '' : (data.port && data.port !== '80' && data.port !== '443' ? (':' + data.port) : (window.location.port ? ':' + window.location.port : ''));
        const scheme = window.location.protocol;
        const basePath = data.base_path ? (data.base_path === '/' ? '' : data.base_path) : '';

        const posUrl = `${scheme}//${lanIp}${port}${basePath}/`;
        if (data.pairing_token) this.activeScannerPairingToken = data.pairing_token;
        const pairQs = this.activeScannerPairingToken ? `&pair=${encodeURIComponent(this.activeScannerPairingToken)}` : '';
        const canPair = data.can_pair !== false;
        const gunUrl = `${scheme}//${lanIp}${port}${basePath}/?mode=scanner&term=${encodeURIComponent(term)}${canPair ? pairQs : ''}`;

        if (posUrlInput) posUrlInput.value = posUrl;
        if (gunUrlInput) gunUrlInput.value = canPair ? gunUrl : '';
        this.activePosConnectUrl = posUrl;
        this.activeCompanionUrl = canPair ? gunUrl : '';

        // The pairing secret is withheld from staff without settings rights, so the
        // gun QR would be a link the phone rejects at the pairing step. Say why.
        if (!canPair && gunQr) {
          gunQr.innerHTML = `<div style="font-size: 0.8rem; color: #64748b; text-align: center; padding: 0.75rem;">` +
            `<i class="fa-solid fa-lock"></i> Pairing a phone needs the <b>Manage Settings</b> permission. ` +
            `Ask a manager or store owner to scan and pair this terminal.</div>`;
        }

        // The launcher binds to loopback unless lan-mode.txt exists, so this QR
        // can be perfectly well-formed and still be dead the moment a phone scans
        // it. Say so here rather than letting the operator debug a "broken" app.
        const warnEl = document.getElementById('connect-gun-lan-warning');
        if (warnEl) {
          // A loopback-bound till is still reachable through a tunnel - the tunnel
          // connects from this very machine - so the lan-mode.txt advice would send
          // the owner hunting for a file that changes nothing about their link.
          if (data.lan_mode === false && !tunnelled) {
            warnEl.innerHTML = `<i class="fa-solid fa-circle-check" style="color: #15803d; margin-right: 0.35rem;"></i> ` +
              `<b>Wi-Fi access enabled automatically!</b> StoreFlow has created the network configuration file (lan-mode.txt). ` +
              `Please restart StoreFlow once from your desktop shortcut so your phone and other devices can connect.`;
            warnEl.style.background = '#f0fdf4';
            warnEl.style.border = '1px solid #86efac';
            warnEl.style.color = '#166534';
            warnEl.style.padding = '0.75rem 1rem';
            warnEl.style.borderRadius = '6px';
            warnEl.style.fontSize = '0.82rem';
            warnEl.style.display = 'block';
          } else {
            warnEl.style.display = 'none';
            warnEl.innerHTML = '';
          }
        }

        // Also update legacy scanner modal input if present
        const legInput = document.getElementById('wireless-scanner-url-input');
        if (legInput) legInput.value = gunUrl;

        // Populate IP selector dropdown if multiple IPs detected
        if (ipSelector && data.all_ips && data.all_ips.length > 1) {
          ipSelector.innerHTML = data.all_ips.map(ip => `<option value="${this.escapeHtml(ip)}" ${ip === lanIp ? 'selected' : ''}>${this.escapeHtml(ip)}</option>`).join('');
          if (ipSelectorContainer) ipSelectorContainer.style.display = 'block';
        }

        // Render POS QR Code
        if (typeof qrcode !== 'undefined' && posQr) {
          try {
            const qr = qrcode(0, 'M');
            qr.addData(posUrl);
            qr.make();
            posQr.innerHTML = qr.createSvgTag(5, 0);
          } catch (e) {
            posQr.innerHTML = `<span style="font-size:0.75rem; color:#dc2626;">QR Error</span>`;
          }
        }

        // Render Gun QR Code
        if (typeof qrcode !== 'undefined' && gunQr) {
          try {
            const qr2 = qrcode(0, 'M');
            qr2.addData(gunUrl);
            qr2.make();
            gunQr.innerHTML = qr2.createSvgTag(5, 0);
          } catch (e) {
            gunQr.innerHTML = `<span style="font-size:0.75rem; color:#dc2626;">QR Error</span>`;
          }
        }
      }
    } catch (err) {
      console.warn('Connect devices info fetch error:', err);
      const host = window.location.host;
      const path = window.location.pathname.replace(/\/index\.html$/i, '');
      const fallbackPos = `${window.location.protocol}//${host}${path}/`;
      const fallbackGun = `${window.location.protocol}//${host}${path}/?mode=scanner&term=${encodeURIComponent(term)}${this.activeScannerPairingToken ? `&pair=${encodeURIComponent(this.activeScannerPairingToken)}` : ''}`;

      if (posUrlInput) posUrlInput.value = fallbackPos;
      if (gunUrlInput) gunUrlInput.value = fallbackGun;
      this.activePosConnectUrl = fallbackPos;
      this.activeCompanionUrl = fallbackGun;

      if (typeof qrcode !== 'undefined') {
        if (posQr) {
          try {
            const qr = qrcode(0, 'M');
            qr.addData(fallbackPos);
            qr.make();
            posQr.innerHTML = qr.createSvgTag(5, 0);
          } catch (e) { }
        }
        if (gunQr) {
          try {
            const qr2 = qrcode(0, 'M');
            qr2.addData(fallbackGun);
            qr2.make();
            gunQr.innerHTML = qr2.createSvgTag(5, 0);
          } catch (e) { }
        }
      }
    }
  }

  onConnectDeviceIpChange(newIp) {
    this.selectedConnectIp = String(newIp || '').trim();
    this.refreshConnectDevicesQr();
  }

  copyConnectDeviceUrl(tab = 'pos') {
    const url = tab === 'pos' ? (document.getElementById('connect-pos-url-input')?.value || this.activePosConnectUrl) : (document.getElementById('connect-gun-url-input')?.value || this.activeCompanionUrl);
    if (!url) return;

    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(url).then(() => {
        this.showToast(tab === 'pos' ? 'Mobile Register link copied to clipboard!' : 'Barcode Scanner Gun link copied to clipboard!', 'success');
      }).catch(() => {
        this.fallbackCopyText(url);
      });
    } else {
      this.fallbackCopyText(url);
    }
  }

  // --- Wireless Companion Scanner Bridge (Cashier PC & Attendant Phone) ---

  async openWirelessScannerModal() {
    this.openConnectDevicesModal('gun');
  }

  closeWirelessScannerModal() {
    this.closeConnectDevicesModal();
  }

  async refreshWirelessScannerQr() {
    const qrContainer = document.getElementById('wireless-scanner-qr-container');
    const urlInput = document.getElementById('wireless-scanner-url-input');
    const termInput = document.getElementById('wireless-terminal-id-input');
    const term = this.normalizeTerminalId(termInput ? termInput.value : this.terminalId);

    try {
      const res = await this.apiFetch(`api/endpoints/scanner_bridge.php?action=info&terminal_id=${encodeURIComponent(term)}`);
      const data = await res.json();
      if (data.success && data.companion_url) {
        if (urlInput) urlInput.value = data.companion_url;
        this.activeCompanionUrl = data.companion_url;

        if (typeof qrcode !== 'undefined' && qrContainer) {
          try {
            const qr = qrcode(0, 'M');
            qr.addData(data.companion_url);
            qr.make();
            qrContainer.innerHTML = qr.createSvgTag(5, 0);
          } catch (qrErr) {
            console.warn('QR Code generation error:', qrErr);
            qrContainer.innerHTML = `<div style="font-size: 0.78rem; color: #dc2626;">Could not render QR code: ${this.escapeHtml(qrErr.message)}</div>`;
          }
        }
      } else if (data.success && qrContainer) {
        qrContainer.innerHTML = `<div style="font-size: 0.8rem; color: #64748b; text-align: center; padding: 0.75rem;">` +
          `<i class="fa-solid fa-lock"></i> Pairing a phone needs the <b>Manage Settings</b> permission. ` +
          `Ask a manager or store owner to pair this device.</div>`;
      }
    } catch (err) {
      console.warn('Failed to load scanner bridge info:', err);
      const host = window.location.host;
      const path = window.location.pathname.replace(/\/index\.html$/i, '');
      const fallbackUrl = `${window.location.protocol}//${host}${path}/?mode=scanner&term=${encodeURIComponent(term)}${this.activeScannerPairingToken ? `&pair=${encodeURIComponent(this.activeScannerPairingToken)}` : ''}`;
      if (urlInput) urlInput.value = fallbackUrl;
      if (typeof qrcode !== 'undefined' && qrContainer) {
        try {
          const qr = qrcode(0, 'M');
          qr.addData(fallbackUrl);
          qr.make();
          qrContainer.innerHTML = qr.createSvgTag(5, 0);
        } catch (e) { }
      }
    }
  }

  onWirelessTerminalIdChange(newVal) {
    const clean = this.normalizeTerminalId(newVal);
    this.terminalId = clean;
    localStorage.setItem('storeflow_terminal_id', clean);
    this.refreshWirelessScannerQr();
    this.restartWirelessScannerPolling();
  }

  copyWirelessScannerLink() {
    const urlInput = document.getElementById('wireless-scanner-url-input');
    const url = urlInput ? urlInput.value : this.activeCompanionUrl;
    if (!url) return;

    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(url).then(() => {
        this.showToast('Companion scanner pairing URL copied to clipboard!', 'success');
      }).catch(() => {
        this.fallbackCopyText(url);
      });
    } else {
      this.fallbackCopyText(url);
    }
  }

  fallbackCopyText(text) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try {
      document.execCommand('copy');
      this.showToast('Pairing URL copied to clipboard!', 'success');
    } catch (e) {
      this.showToast('Please copy the URL directly from the text box.', 'info');
    }
    document.body.removeChild(ta);
  }

  async sendTestWirelessScan() {
    const term = this.terminalId || 'REG-01';
    const sampleProduct = (this.products && this.products.length > 0) ? this.products[0] : null;
    const testBarcode = sampleProduct ? (sampleProduct.barcode || sampleProduct.sku || 'TEST-ITEM') : 'TEST-12345';

    try {
      const res = await this.apiFetch('api/endpoints/scanner_bridge.php?action=push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          terminal_id: term,
          barcode: testBarcode,
          device: 'Test Beam (Simulated)'
        })
      });
      const data = await res.json();
      if (data.success) {
        this.showToast(`Test beam sent for "${testBarcode}"! Ingesting into cart...`, 'success');
        this.pollWirelessScannerImmediate();
      } else {
        this.showToast('Test beam failed: ' + (data.message || 'Error'), 'danger');
      }
    } catch (err) {
      this.showToast('Test beam network error: ' + err.message, 'danger');
    }
  }

  async fetchWirelessScannerHistory() {
    const feed = document.getElementById('wireless-scanner-live-feed');
    if (!feed) return;
    const term = this.terminalId || 'REG-01';

    try {
      const res = await this.apiFetch(`api/endpoints/scanner_bridge.php?action=history&terminal_id=${encodeURIComponent(term)}&limit=15`);
      const data = await res.json();
      if (data.success && data.history && data.history.length > 0) {
        feed.innerHTML = data.history.map(item => {
          const time = item.created_at ? item.created_at.slice(11, 19) : '--:--:--';
          return `<div style="padding: 0.25rem 0; border-bottom: 1px solid rgba(255,255,255,0.08); display: flex; justify-content: space-between;">
            <div>
              <span style="color: #4ade80;">[${this.escapeHtml(time)}]</span> 
              <strong style="color: #f1f5f9;">${this.escapeHtml(item.product_name || item.barcode)}</strong>
              <span style="color: #94a3b8; font-size: 0.7rem;">(${this.escapeHtml(item.barcode)})</span>
            </div>
            <span style="color: #38bdf8; font-size: 0.7rem;">${this.escapeHtml(item.device_info || 'Phone')}</span>
          </div>`;
        }).join('');
      }
    } catch (e) { }
  }

  startWirelessScannerPolling() {
    if (this._wirelessPollInterval) return;
    this._wirelessPollInterval = setInterval(() => {
      this.pollWirelessScannerImmediate();
    }, 1200);
  }

  restartWirelessScannerPolling() {
    if (this._wirelessPollInterval) {
      clearInterval(this._wirelessPollInterval);
      this._wirelessPollInterval = null;
    }
    this.startWirelessScannerPolling();
  }

  stopWirelessScannerPolling() {
    if (this._wirelessPollInterval) {
      clearInterval(this._wirelessPollInterval);
      this._wirelessPollInterval = null;
    }
  }

  async pollWirelessScannerImmediate() {
    if (this._isPollingWireless) return;
    this._isPollingWireless = true;
    const term = this.terminalId || 'REG-01';

    try {
      const res = await this.apiFetch(`api/endpoints/scanner_bridge.php?action=poll&terminal_id=${encodeURIComponent(term)}`, { method: 'POST' });
      const data = await res.json();
      if (data.success && Array.isArray(data.scans) && data.scans.length > 0) {
        for (const scan of data.scans) {
          const code = scan.barcode;
          if (!code) continue;

          // Ingest barcode directly into active POS cart
          this.handleBarcodeScan(code);

          // Audio chirp for wireless beam arrival
          this.playBeepSound(1750);

          // High visibility toast
          this.showToast(`📱 Beamed from ${scan.device_info || 'Floor Attendant'}: ${scan.product_name || code}`, 'success');

          // Flash the POS Phone Scanner button
          const btn = document.getElementById('btn-pos-wireless-scan');
          if (btn) {
            btn.classList.add('flash-bridge-success');
            setTimeout(() => btn.classList.remove('flash-bridge-success'), 800);
          }

          // Prepend to modal live feed if open
          const feed = document.getElementById('wireless-scanner-live-feed');
          if (feed) {
            const time = new Date().toTimeString().slice(0, 8);
            const row = document.createElement('div');
            row.style.padding = '0.25rem 0';
            row.style.borderBottom = '1px solid rgba(255,255,255,0.08)';
            row.style.display = 'flex';
            row.style.justifyContent = 'space-between';
            row.innerHTML = `
              <div>
                <span style="color: #4ade80;">[${time}]</span> 
                <strong style="color: #f1f5f9;">${this.escapeHtml(scan.product_name || scan.barcode)}</strong>
                <span style="color: #94a3b8; font-size: 0.7rem;">(${this.escapeHtml(scan.barcode)})</span>
              </div>
              <span style="color: #38bdf8; font-size: 0.7rem;">${this.escapeHtml(scan.device_info || 'Phone')}</span>
            `;
            if (feed.firstElementChild && feed.firstElementChild.innerText.includes('No wireless scans')) {
              feed.innerHTML = '';
            }
            feed.prepend(row);
          }
        }
      }
    } catch (e) {
      // Background poll failure is silent
    } finally {
      this._isPollingWireless = false;
    }
  }

  // --- Companion Mobile Mode Execution (When phone opens pairing link) ---

  async startCompanionScannerMode(targetTerm = null) {
    this.isCompanionMode = true;
    const params = new URLSearchParams(window.location.search);
    const term = this.normalizeTerminalId(targetTerm || params.get('term') || localStorage.getItem('storeflow_companion_term'));
    this.companionTerminalId = term;
    localStorage.setItem('storeflow_companion_term', term);

    // Pairing secret issued by the POS terminal in the QR/URL. The companion page has
    // no POS session, so this is what authorises a push.
    const pair = params.get('pair') || localStorage.getItem('storeflow_companion_pair') || '';
    this.companionPairToken = pair;
    if (pair) localStorage.setItem('storeflow_companion_pair', pair);

    // Hide standard desktop screens
    const loginScreen = document.getElementById('login-screen');
    const appContainer = document.getElementById('app-container');
    const paywall = document.getElementById('license-paywall');
    const banner = document.getElementById('trial-banner');
    if (loginScreen) loginScreen.style.display = 'none';
    if (appContainer) appContainer.style.display = 'none';
    if (paywall) paywall.style.display = 'none';
    if (banner) banner.style.display = 'none';

    // Show Companion Screen
    const companionScreen = document.getElementById('companion-scanner-screen');
    if (companionScreen) {
      companionScreen.style.display = 'flex';
    }

    const badge = document.getElementById('companion-terminal-badge');
    if (badge) badge.textContent = this.companionTerminalId;

    this.companionTotalBeamed = 0;
    const totalBadge = document.getElementById('companion-total-scans-badge');
    if (totalBadge) totalBadge.textContent = '0 Beamed';

    // Launch camera
    await this.initCompanionCameraScanner();
  }

  async initCompanionCameraScanner() {
    if (typeof Html5Qrcode === 'undefined') {
      setTimeout(() => this.initCompanionCameraScanner(), 300);
      return;
    }

    const readerEl = document.getElementById('companion-scanner-reader');
    if (!readerEl) return;
    readerEl.innerHTML = '';

    await this.stopCompanionCameraInstance();

    try {
      const formats = (typeof Html5QrcodeSupportedFormats !== 'undefined') ? [
        Html5QrcodeSupportedFormats.EAN_13,
        Html5QrcodeSupportedFormats.EAN_8,
        Html5QrcodeSupportedFormats.UPC_A,
        Html5QrcodeSupportedFormats.UPC_E,
        Html5QrcodeSupportedFormats.CODE_128,
        Html5QrcodeSupportedFormats.QR_CODE
      ] : undefined;

      this.companionQrCode = new Html5Qrcode('companion-scanner-reader', {
        formatsToSupport: formats,
        verbose: false,
        experimental: { useBarCodeDetectorIfSupported: true }
      });

      const cameras = await Html5Qrcode.getCameras().catch(() => []);
      this.companionCameras = cameras || [];

      const flipBtn = document.getElementById('btn-companion-switch-cam');
      if (flipBtn) {
        flipBtn.style.display = (this.companionCameras.length > 1) ? 'flex' : 'none';
      }

      const backIdx = this.companionCameras.findIndex(c => /back|rear|environment/i.test(c.label || ''));
      this.companionCameraIndex = backIdx >= 0 ? backIdx : 0;
      const backCam = backIdx >= 0 ? this.companionCameras[backIdx] : null;

      await this.companionQrCode.start(
        { facingMode: 'environment' },
        this.getScannerConfig(backCam ? backCam.id : null),
        (decodedText) => this.onCompanionBarcodeScanned(decodedText),
        () => { }
      );

      this.isCompanionRunning = true;
      this.checkCompanionTorchSupport();

      const statusEl = document.getElementById('companion-status-text');
      if (statusEl) statusEl.textContent = 'Scanner Active';
    } catch (err) {
      console.error('Companion camera start error:', err);
      const statusEl = document.getElementById('companion-status-text');
      if (statusEl) {
        statusEl.textContent = 'Camera Blocked';
        statusEl.parentElement.style.color = '#ef4444';
      }
      this.showToast('Please enable camera permissions on your smartphone to scan barcodes.', 'danger');
    }
  }

  async stopCompanionCameraInstance() {
    if (this.companionQrCode && this.isCompanionRunning) {
      try { await this.companionQrCode.stop(); } catch (e) { }
      try { this.companionQrCode.clear(); } catch (e) { }
    }
    this.isCompanionRunning = false;
    this.companionQrCode = null;
    this.isCompanionTorchOn = false;
  }

  async onCompanionBarcodeScanned(decodedText) {
    if (!decodedText) return;
    const clean = String(decodedText).trim();
    if (!clean || clean.length < 4) return;

    const now = Date.now();
    if (this.lastCompanionBarcode === clean && (now - (this.lastCompanionTime || 0) < 1400)) {
      return;
    }
    if (now - (this.lastCompanionTime || 0) < 650) {
      return;
    }

    this.lastCompanionBarcode = clean;
    this.lastCompanionTime = now;

    // Haptic vibration feedback on attendant phone
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try { navigator.vibrate([80]); } catch (e) { }
    }

    // Audio chirp
    this.playBeepSound(1600);

    // Visual feedback in UI
    const card = document.getElementById('companion-last-scan-card');
    const statusText = document.getElementById('companion-last-scan-status');
    const nameEl = document.getElementById('companion-last-product-name');
    const barEl = document.getElementById('companion-last-product-barcode');
    const priceEl = document.getElementById('companion-last-product-price');

    if (card) {
      card.style.background = '#14532d'; // Forest green flash
      setTimeout(() => {
        if (card) card.style.background = '#1e293b';
      }, 700);
    }

    if (statusText) {
      statusText.innerHTML = '<i class="fa-solid fa-arrows-spin fa-spin" style="color: #38bdf8;"></i> Beaming to PC...';
    }
    if (nameEl) nameEl.textContent = 'Transmitting barcode...';
    if (barEl) barEl.textContent = clean;

    // Beam barcode to PC via scanner_bridge.php
    try {
      const term = this.companionTerminalId || 'REG-01';
      const res = await this.apiFetch('api/endpoints/scanner_bridge.php?action=push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          terminal_id: term,
          barcode: clean,
          device: 'Attendant Phone',
          pair: this.companionPairToken || ''
        })
      });
      const data = await res.json();

      if (data.success) {
        this.companionTotalBeamed = (this.companionTotalBeamed || 0) + 1;
        const totalBadge = document.getElementById('companion-total-scans-badge');
        if (totalBadge) totalBadge.textContent = `${this.companionTotalBeamed} Beamed`;

        const prod = data.product;
        if (statusText) {
          statusText.innerHTML = `<i class="fa-solid fa-circle-check" style="color: #4ade80;"></i> Beamed to ${this.escapeHtml(term)}`;
        }
        if (nameEl) {
          nameEl.textContent = prod ? prod.name : `Scanned Code: ${clean}`;
        }
        if (priceEl) {
          priceEl.textContent = prod ? this.formatCurrency(prod.selling_price) : '';
        }

        // Add to recent list
        const list = document.getElementById('companion-scans-list');
        if (list) {
          const time = new Date().toTimeString().slice(0, 8);
          const itemDiv = document.createElement('div');
          itemDiv.style.padding = '0.3rem 0';
          itemDiv.style.borderBottom = '1px solid #1e293b';
          itemDiv.style.display = 'flex';
          itemDiv.style.justifyContent = 'space-between';
          itemDiv.innerHTML = `
            <div>
              <span style="color: #4ade80;">[${time}]</span>
              <strong style="color: #ffffff;">${this.escapeHtml(prod ? prod.name : clean)}</strong>
            </div>
            <span style="color: #38bdf8;">${prod ? this.formatCurrency(prod.selling_price) : clean}</span>
          `;
          if (list.firstElementChild && list.firstElementChild.innerText.includes('Scanned items will appear')) {
            list.innerHTML = '';
          }
          list.prepend(itemDiv);
        }
      } else {
        if (statusText) {
          statusText.innerHTML = '<i class="fa-solid fa-circle-exclamation" style="color: #f87171;"></i> Beam Failed';
        }
        if (nameEl && data.message) {
          nameEl.textContent = data.message;
        }
        if (!this.companionPairToken) {
          this.showToast('This phone is not paired. Open StoreFlow on the POS terminal and scan the pairing QR again.', 'error');
        }
      }
    } catch (err) {
      console.warn('Beam push error:', err);
      if (statusText) {
        statusText.innerHTML = '<i class="fa-solid fa-triangle-exclamation" style="color: #f87171;"></i> Network Error';
      }
    }
  }

  submitCompanionManualBarcode() {
    const input = document.getElementById('companion-manual-input');
    if (!input) return;
    const val = input.value.trim();
    if (!val) return;
    input.value = '';
    this.onCompanionBarcodeScanned(val);
  }

  checkCompanionTorchSupport() {
    const btn = document.getElementById('btn-companion-torch');
    if (!btn) return;
    try {
      const track = this.companionQrCode?.getRunningTrack();
      const caps = track?.getCapabilities ? track.getCapabilities() : null;
      btn.style.display = (caps && caps.torch) ? 'flex' : 'none';
    } catch (e) {
      btn.style.display = 'none';
    }
  }

  async toggleCompanionTorch() {
    if (!this.companionQrCode || !this.isCompanionRunning) return;
    try {
      const track = this.companionQrCode.getRunningTrack();
      if (track && track.applyConstraints) {
        this.isCompanionTorchOn = !this.isCompanionTorchOn;
        await track.applyConstraints({ advanced: [{ torch: this.isCompanionTorchOn }] });
        const icon = document.getElementById('companion-torch-icon');
        const btn = document.getElementById('btn-companion-torch');
        if (btn) btn.style.background = this.isCompanionTorchOn ? '#eab308' : 'rgba(15, 23, 42, 0.75)';
        if (icon) icon.style.color = this.isCompanionTorchOn ? '#000000' : '#ffffff';
      }
    } catch (e) {
      console.warn('Companion torch toggle error:', e);
    }
  }

  async switchCompanionCamera() {
    if (!this.companionQrCode || !this.isCompanionRunning || !this.companionCameras || this.companionCameras.length < 2) return;
    this.companionCameraIndex = ((this.companionCameraIndex || 0) + 1) % this.companionCameras.length;
    const nextCam = this.companionCameras[this.companionCameraIndex];

    try {
      await this.companionQrCode.stop();
      this.isCompanionRunning = false;
      await this.companionQrCode.start(
        nextCam.id,
        this.getScannerConfig(nextCam.id),
        (decodedText) => this.onCompanionBarcodeScanned(decodedText),
        () => { }
      );
      this.isCompanionRunning = true;
      this.checkCompanionTorchSupport();
    } catch (e) {
      console.warn('Companion camera switch error:', e);
    }
  }

  async promptSwitchCompanionTerminal() {
    const current = this.companionTerminalId || 'REG-01';
    const nextTerm = await this.showPromptModal({ title: 'Beam Scanned Items to Register', desc: 'Enter the Target Cashier Register ID to beam scanned products into:', label: 'Target Terminal ID', placeholder: 'REG-01', defaultValue: current, icon: 'fa-wifi', confirmText: 'Beam to Register' });
    if (nextTerm && nextTerm.trim()) {
      const clean = nextTerm.trim().toUpperCase();
      this.companionTerminalId = clean;
      localStorage.setItem('storeflow_companion_term', clean);
      const badge = document.getElementById('companion-terminal-badge');
      if (badge) badge.textContent = clean;
      this.showToast(`Switched target terminal to ${clean}`, 'info');
    }
  }

  async exitCompanionScannerMode() {
    await this.stopCompanionCameraInstance();
    const companionScreen = document.getElementById('companion-scanner-screen');
    if (companionScreen) companionScreen.style.display = 'none';

    this.isCompanionMode = false;
    const cleanUrl = window.location.pathname;
    window.history.replaceState({}, document.title, cleanUrl);

    if (this.currentUser) {
      this.showApp();
    } else {
      this.showLogin();
    }
  }

  // --- View Renderers ---

  renderCurrentView() {
    const container = document.getElementById('view-content-container');
    if (!container) return;

    // Preserve mobile cart modal open state across re-renders
    const wasCartOpen = document.body.classList.contains('pos-cart-locked') ||
                        Boolean(document.querySelector('.pos-cart-panel.pos-cart-modal-open'));

    // Preserve active input focus (e.g. discount input or search)
    const activeEl = document.activeElement;
    const activeId = activeEl && activeEl.id ? activeEl.id : null;
    const cursorStart = activeEl && 'selectionStart' in activeEl ? activeEl.selectionStart : null;
    const cursorEnd = activeEl && 'selectionEnd' in activeEl ? activeEl.selectionEnd : null;

    switch (this.currentView) {
      case 'dashboard':
        if (typeof this.closePosCartModal === 'function') this.closePosCartModal();
        container.innerHTML = this.getDashboardHTML();
        break;
      case 'pos':
        container.innerHTML = this.getPosHTML();
        this.bindPosEvents();

        // Mobile Cart Modal State Preservation:
        if (wasCartOpen) {
          const newCartPanel = container.querySelector('.pos-cart-panel');
          if (newCartPanel && this.cart.length > 0) {
            newCartPanel.style.transition = 'none';
            newCartPanel.classList.add('pos-cart-modal-open');
            document.body.classList.add('pos-cart-locked');
            let overlay = document.getElementById('pos-cart-modal-overlay');
            if (!overlay) {
              overlay = document.createElement('div');
              overlay.id = 'pos-cart-modal-overlay';
              overlay.className = 'pos-cart-backdrop';
              overlay.onclick = () => this.closePosCartModal();
              document.body.appendChild(overlay);
            }
            overlay.classList.add('active');
            requestAnimationFrame(() => {
              newCartPanel.style.transition = '';
            });
          } else {
            // Cart was cleared or emptied to 0 items: close overlay cleanly
            if (typeof this.closePosCartModal === 'function') this.closePosCartModal();
          }
        } else {
          // If cart wasn't open, ensure no orphaned backdrop is active
          const overlay = document.getElementById('pos-cart-modal-overlay');
          if (overlay && !container.querySelector('.pos-cart-panel.pos-cart-modal-open')) {
            overlay.classList.remove('active');
            document.body.classList.remove('pos-cart-locked');
          }
        }

        // Restore active focus if applicable
        if (activeId) {
          const freshEl = document.getElementById(activeId);
          if (freshEl && typeof freshEl.focus === 'function') {
            freshEl.focus();
            if (cursorStart !== null && cursorEnd !== null && typeof freshEl.setSelectionRange === 'function') {
              try { freshEl.setSelectionRange(cursorStart, cursorEnd); } catch (e) {}
            }
          }
        }
        break;
      case 'products':
        container.innerHTML = this.getProductsHTML();
        this.bindProductsEvents();
        break;
      case 'inventory':
        container.innerHTML = this.getInventoryHTML();
        this.bindInventoryEvents();
        break;
      case 'batches':
        container.innerHTML = this.getBatchesHTML();
        break;
      case 'purchases':
        container.innerHTML = this.getPurchasesHTML();
        this.bindPurchasesEvents();
        break;
      case 'vendors':
        container.innerHTML = this.getVendorsHTML();
        this.bindVendorsEvents();
        break;
      case 'sales':
        container.innerHTML = this.getSalesHTML();
        this.bindSalesEvents();
        break;
      case 'returns':
        container.innerHTML = this.getReturnsHTML();
        this.bindReturnsEvents();
        break;
      case 'expenses':
        container.innerHTML = this.getExpensesHTML();
        this.bindExpensesEvents();
        break;
      case 'customers':
        container.innerHTML = this.getCustomersHTML();
        this.bindCustomersEvents();
        break;
      case 'users':
        container.innerHTML = this.getUsersHTML();
        this.bindUsersEvents();
        break;
      case 'backups':
        container.innerHTML = this.getBackupsHTML();
        this.bindBackupsEvents();
        break;
      case 'profile':
        container.innerHTML = this.getProfileHTML();
        this.bindProfileEvents();
        break;
      case 'activity_logs':
        container.innerHTML = this.getActivityLogsHTML();
        this.bindActivityLogsEvents();
        break;
      case 'analytics':
        container.innerHTML = this.getAnalyticsHTML();
        this.bindAnalyticsEvents();
        // Paint from what is already loaded, then bring in the receipt lines the product
        // and category boards are built from and repaint once. Waiting on the network here
        // would leave the counter staring at a blank page.
        this.ensureSaleLinesForAnalytics();
        break;
      default:
        container.innerHTML = this.getDashboardHTML();
    }
    this.applyMobileTableLabels(container);
    this.updateGlobalCartPill();
  }

  // --- Mobile Cards & Responsive Table Helpers ---

  applyMobileTableLabels(scope = document) {
    if (!scope) return;
    const root = (scope instanceof Element || scope instanceof Document) ? scope : document;
    const tables = root.querySelectorAll('.data-table:not(.keep-table)');
    tables.forEach(table => {
      const ths = Array.from(table.querySelectorAll('thead th'));
      if (!ths.length) return;
      const headers = ths.map(th => {
        let txt = th.innerText || th.textContent || '';
        txt = txt.trim().replace(/\s+/g, ' ');
        if (!txt) {
          txt = th.getAttribute('title') || th.getAttribute('aria-label') || '';
        }
        return txt;
      });

      const rows = table.querySelectorAll('tbody tr');
      rows.forEach(row => {
        const cells = Array.from(row.children).filter(el => el.tagName === 'TD');
        if (cells.length === 1 && cells[0].hasAttribute('colspan')) {
          cells[0].classList.add('table-empty-message');
          return;
        }

        let headerAssigned = false;
        cells.forEach((td, idx) => {
          const lbl = headers[idx] || '';
          if (lbl) {
            td.setAttribute('data-label', lbl);
          }

          const isPhotoOrImg = /photo|image|thumb|picture/i.test(lbl);
          const isAction = /action/i.test(lbl);
          const hasCheckbox = !!td.querySelector('input[type="checkbox"]');

          if (!headerAssigned && !isPhotoOrImg && !isAction && !hasCheckbox && idx < 3) {
            td.classList.add('table-card-header');
            headerAssigned = true;
          }

          // Wrap cell contents in .td-content if not already wrapped
          if (!td.querySelector(':scope > .td-content') && !td.classList.contains('table-empty-message')) {
            const wrapper = document.createElement('div');
            wrapper.className = 'td-content';
            while (td.firstChild) {
              wrapper.appendChild(td.firstChild);
            }
            td.appendChild(wrapper);
          }
        });
      });
    });
  }

  scrollToPosCart() {
    const pill = document.getElementById('pos-floating-cart-pill');
    if (pill) pill.classList.add('hide-floating-pill');
    const cartPanel = document.querySelector('.pos-cart-panel');
    if (cartPanel) {
      cartPanel.scrollIntoView({ behavior: 'smooth' });
    }
  }

  setupPosCartScrollObserver() {
    // Mobile cart is a bottom-sheet modal triggered by the pill;
    // ensure the floating pill remains active and visible on mobile when cart has items
    const pill = document.getElementById('pos-floating-cart-pill');
    if (pill) {
      pill.classList.remove('hide-floating-pill');
    }
    if (this._posCartObserver) {
      this._posCartObserver.disconnect();
      this._posCartObserver = null;
    }
  }

  updateGlobalCartPill() {
    const pill = document.getElementById('global-floating-cart-pill');
    if (!pill) return;

    const totalItems = (this.cart || []).reduce((sum, item) => sum + Number(item.quantity || 1), 0);
    const subtotal = (this.cart || []).reduce((sum, item) => sum + (Number(item.quantity || 1) * Number(item.selling_price || 0)), 0);

    // Show when cart has items AND user navigated away from POS view
    if (totalItems > 0 && this.currentView !== 'pos') {
      pill.style.display = 'flex';
      pill.innerHTML = `
        <div style="display: flex; align-items: center; gap: 0.65rem;">
          <span class="badge badge-success" style="padding: 0.22rem 0.6rem; font-size: 0.82rem; font-weight: 700; border-radius: 9999px;">
            <i class="fa-solid fa-cart-shopping"></i> ${totalItems}
          </span>
          <span style="font-weight: 700; font-size: 0.95rem;">${this.formatCurrency(subtotal)}</span>
        </div>
        <span style="font-weight: 600; font-size: 0.82rem; display: flex; align-items: center; gap: 0.4rem; color: #38bdf8;">
          Return to POS <i class="fa-solid fa-arrow-right"></i>
        </span>
      `;
    } else {
      pill.style.display = 'none';
    }
  }

  toggleMobileTableView() {
    this.mobileTableMode = (this.mobileTableMode === 'cards') ? 'table' : 'cards';
    localStorage.setItem('storeflow_mobile_table_mode', this.mobileTableMode);
    this.updateMobileTableUI();
    const modeName = this.mobileTableMode === 'cards' ? 'Card View' : 'Spreadsheet Table View';
    this.showToast(`Switched to mobile ${modeName}`, 'info');
  }

  updateMobileTableUI() {
    const appContainer = document.getElementById('app-container');
    const topbarBtn = document.getElementById('btn-mobile-table-toggle');
    const topbarIcon = document.getElementById('topbar-table-mode-icon');
    const topbarLabel = document.getElementById('topbar-table-mode-label');
    const drawerIcon = document.getElementById('drawer-table-mode-icon');
    const drawerLabel = document.getElementById('drawer-table-mode-label');

    if (!appContainer) return;

    if (this.mobileTableMode === 'table') {
      appContainer.classList.add('mobile-force-table');
      if (topbarBtn) {
        topbarBtn.title = 'Switch to Card View on Mobile';
        topbarBtn.setAttribute('aria-label', 'Switch to Card View on Mobile');
      }
      if (topbarIcon) topbarIcon.className = 'fa-solid fa-table-cells-large';
      if (topbarLabel) topbarLabel.textContent = 'Cards';
      if (drawerIcon) drawerIcon.className = 'fa-solid fa-table-cells-large';
      if (drawerLabel) drawerLabel.textContent = 'View: Spreadsheet Table';
    } else {
      appContainer.classList.remove('mobile-force-table');
      if (topbarBtn) {
        topbarBtn.title = 'Switch to Spreadsheet Table View on Mobile';
        topbarBtn.setAttribute('aria-label', 'Switch to Spreadsheet Table View on Mobile');
      }
      if (topbarIcon) topbarIcon.className = 'fa-solid fa-table-list';
      if (topbarLabel) topbarLabel.textContent = 'Table';
      if (drawerIcon) drawerIcon.className = 'fa-solid fa-table';
      if (drawerLabel) drawerLabel.textContent = 'View: Mobile Cards';
    }
  }

  formatCurrency(amount) {
    return `${this.currencySymbol()}${Number(amount || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  }

  // The currency symbol is free text on the settings screen and this function
  // feeds receipt and report markup, so an unfiltered symbol is a stored payload
  // printed on every sale. Anything that isn't currency-like prints as the default
  // instead - a symbol is never longer than a couple of characters anyway.
  currencySymbol() {
    const sym = String((this.storeProfile || {}).currency_symbol || '').trim();
    if (sym && sym.length <= 4 && /^[\p{Sc}\p{L}]+$/u.test(sym)) return sym;
    return '$';
  }

  // --- Dashboard ---

  getDashboardHTML() {
    // Superseded at runtime by the copy in app-dashboard.js, which is loaded after this file.
    // Kept VOID-clean anyway: a second reading of the book that counts a cleared receipt as
    // takings is a bug waiting for someone to reorder the script tags.
    const countedSales = (this.sales || []).filter(s => !this.isVoidedSale(s));
    const totalSalesRev = countedSales.reduce((sum, s) => sum + Number(s.total_amount || 0), 0);
    const totalGrossProfit = countedSales.reduce((sum, s) => sum + Number(s.gross_profit || 0), 0);
    const totalProductsCount = this.products.length;
    const lowStockCount = this.products.filter(p => Number(p.current_quantity || 0) <= Number(p.min_stock_alert || 5) && Number(p.current_quantity || 0) > 0).length;
    const outOfStockCount = this.products.filter(p => Number(p.current_quantity || 0) <= 0).length;

    const inventoryValuationCost = this.products.reduce((sum, p) => sum + (Number(p.current_quantity || 0) * Number(p.cost_price || 0)), 0);
    const inventoryValuationRetail = this.products.reduce((sum, p) => sum + (Number(p.current_quantity || 0) * Number(p.selling_price || 0)), 0);

    const recentSales = this.sales.slice(0, 5);

    return `
      <div class="kpi-grid">
        <div class="kpi-card">
          <div class="kpi-icon-wrapper kpi-blue">
            <i class="fa-solid fa-chart-line"></i>
          </div>
          <div class="kpi-info">
            <h4>Total Revenue</h4>
            <p>${this.formatCurrency(totalSalesRev)}</p>
            <span>From ${countedSales.length} transactions</span>
          </div>
        </div>

        <div class="kpi-card">
          <div class="kpi-icon-wrapper kpi-green">
            <i class="fa-solid fa-arrow-trend-up"></i>
          </div>
          <div class="kpi-info">
            <h4>Gross Profit</h4>
            <p>${this.formatCurrency(totalGrossProfit)}</p>
            <span>Selling price - Factory cost</span>
          </div>
        </div>

        <div class="kpi-card">
          <div class="kpi-icon-wrapper kpi-purple">
            <i class="fa-solid fa-boxes-stacked"></i>
          </div>
          <div class="kpi-info">
            <h4>Total Products</h4>
            <p>${totalProductsCount}</p>
            <span>Stock Worth: ${this.formatCurrency(inventoryValuationRetail)}</span>
          </div>
        </div>

        <div class="kpi-card">
          <div class="kpi-icon-wrapper ${outOfStockCount > 0 ? 'kpi-red' : (lowStockCount > 0 ? 'kpi-amber' : 'kpi-green')}">
            <i class="fa-solid fa-triangle-exclamation"></i>
          </div>
          <div class="kpi-info">
            <h4>Stock Alerts</h4>
            <p>${outOfStockCount} Out · ${lowStockCount} Low</p>
            <span>Items needing factory restock</span>
          </div>
        </div>
      </div>

      <div class="panel" style="margin-bottom: 1.5rem;">
        <div class="panel-body" style="display: flex; gap: 1rem; flex-wrap: wrap; align-items: center; justify-content: space-between;">
          <div>
            <h4 style="font-size: 1rem; font-weight: 700; color: var(--slate-800);">Quick Store Actions</h4>
            <p style="font-size: 0.85rem; color: var(--slate-500);">Fast navigation for common cashier and inventory operations</p>
          </div>
          <div style="display: flex; gap: 0.75rem; flex-wrap: wrap;">
            <button class="btn btn-primary" onclick="app.switchView('pos')">
              <i class="fa-solid fa-cash-register"></i> Open POS Checkout
            </button>
            <button class="btn btn-success" onclick="app.switchView('purchases')">
              <i class="fa-solid fa-truck-ramp-box"></i> Stock In from Factory
            </button>
            <button class="btn btn-outline" onclick="app.switchView('products')">
              <i class="fa-solid fa-plus"></i> Add New Product
            </button>
            <button class="btn btn-outline" onclick="app.switchView('backups')">
              <i class="fa-solid fa-database"></i> Database Backups
            </button>
          </div>
        </div>
      </div>

      <div class="dashboard-two-col-grid">
        <div class="panel">
          <div class="panel-header">
            <h3><i class="fa-solid fa-receipt"></i> Recent Store Sales</h3>
            <button class="btn btn-outline btn-sm" onclick="app.switchView('sales')">View All</button>
          </div>
          <div class="panel-body table-panel-body">
            <div class="table-responsive">
              <table class="data-table">
                <thead>
                  <tr>
                    <th>Receipt #</th>
                    <th>Customer</th>
                    <th>Total</th>
                    <th>Profit</th>
                    <th>Payment</th>
                  </tr>
                </thead>
                <tbody>
                  ${recentSales.length > 0 ? recentSales.map(s => `
                    <tr>
                      <td style="font-weight: 600; font-family: monospace;">${this.escapeHtml(s.receipt_number)}</td>
                      <td>${this.escapeHtml(s.customer_name || 'Walk-in Customer')}</td>
                      <td style="font-weight: 700;">
                      ${this.formatCurrency(s.total_amount)}
                      ${Number(s.refunded_amount || 0) > 0 ? `
                        <div style="font-size: 0.72rem; color: #dc2626; font-weight: 600; margin-top: 2px;">
                          -${this.formatCurrency(s.refunded_amount)} refunded
                        </div>
                        <span class="badge ${s.status === 'REFUNDED' ? 'badge-danger' : 'badge-warning'}" style="font-size: 0.68rem; margin-top: 2px;">
                          ${this.escapeHtml(s.status)}
                        </span>
                      ` : ''}
                    </td>
                      <td>
                        ${(() => {
                          const m = this.getSaleProfitMetrics(s);
                          if (m.isFullyRefunded) {
                            return `<span style="color: var(--slate-400); font-weight: 600;">${this.formatCurrency(0)}</span> <span class="badge badge-neutral" style="font-size: 0.65rem;">Void</span>`;
                          }
                          if (m.isPartiallyRefunded) {
                            return `<span style="color: var(--success); font-weight: 700;">+${this.formatCurrency(m.netProfit)}</span> <span class="badge badge-warning" style="font-size: 0.65rem;">Net</span>`;
                          }
                          return `<span style="color: var(--success); font-weight: 600;">+${this.formatCurrency(s.gross_profit)}</span>`;
                        })()}
                      </td>
                      <td><span class="badge badge-neutral">${this.escapeHtml(s.payment_method)}</span></td>
                    </tr>
                  `).join('') : `
                    <tr>
                      <td colspan="5" style="text-align: center; padding: 2rem; color: var(--slate-400);">
                        <i class="fa-solid fa-circle-info" style="margin-right: 0.5rem;"></i> No sales recorded yet. Open POS to ring up your first sale!
                      </td>
                    </tr>
                  `}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div class="panel">
          <div class="panel-header">
            <h3><i class="fa-solid fa-boxes-stacked"></i> Inventory Overview</h3>
            <button class="btn btn-outline btn-sm" onclick="app.switchView('inventory')">Manage Stock</button>
          </div>
          <div class="panel-body">
            <div style="display: flex; flex-direction: column; gap: 1rem;">
              <div style="display: flex; justify-content: space-between; border-bottom: 1px solid var(--slate-100); padding-bottom: 0.75rem;">
                <span style="color: var(--slate-600);"><i class="fa-solid fa-warehouse" style="width: 20px;"></i> Inventory Cost Valuation</span>
                <strong style="color: var(--slate-800);">${this.formatCurrency(inventoryValuationCost)}</strong>
              </div>
              <div style="display: flex; justify-content: space-between; border-bottom: 1px solid var(--slate-100); padding-bottom: 0.75rem;">
                <span style="color: var(--slate-600);"><i class="fa-solid fa-tag" style="width: 20px;"></i> Inventory Retail Valuation</span>
                <strong style="color: var(--primary);">${this.formatCurrency(inventoryValuationRetail)}</strong>
              </div>
              <div style="display: flex; justify-content: space-between; border-bottom: 1px solid var(--slate-100); padding-bottom: 0.75rem;">
                <span style="color: var(--slate-600);"><i class="fa-solid fa-coins" style="width: 20px;"></i> Potential Store Profit</span>
                <strong style="color: var(--success);">${this.formatCurrency(inventoryValuationRetail - inventoryValuationCost)}</strong>
              </div>
              <div style="display: flex; justify-content: space-between; padding-top: 0.25rem;">
                <span style="color: var(--slate-600);"><i class="fa-solid fa-clock-rotate-left" style="width: 20px;"></i> Auto-Backup Frequency</span>
                <span class="badge badge-info">Every ${this.escapeHtml(this.storeProfile.auto_backup_hours || 2)} Hours</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Low Stock & Factory Reorder Alerts -->
      ${(() => {
        const lowStockItems = this.products.filter(p => Number(p.current_quantity || 0) <= Number(p.min_stock_alert || 5));
        if (lowStockItems.length === 0) {
          return `
            <div class="panel" style="margin-top: 1.5rem; background: #f0fdf4; border: 1px solid #bbf7d0;">
              <div class="panel-body" style="padding: 1rem 1.25rem; display: flex; align-items: center; justify-content: space-between;">
                <div style="display: flex; align-items: center; gap: 0.75rem;">
                  <i class="fa-solid fa-circle-check" style="font-size: 1.5rem; color: #16a34a;"></i>
                  <div>
                    <strong style="color: #166534; font-size: 0.95rem;">All Inventory Quantities Are Healthy</strong>
                    <p style="font-size: 0.8rem; color: #15803d; margin: 0;">No items are currently below minimum stock thresholds.</p>
                  </div>
                </div>
                <button class="btn btn-outline btn-sm" onclick="app.switchView('inventory')" style="color: #166534; border-color: #86efac;">
                  <i class="fa-solid fa-boxes-stacked"></i> View Inventory
                </button>
              </div>
            </div>
          `;
        }

        return `
          <div class="panel" style="margin-top: 1.5rem; border: 1px solid #fecaca;">
            <div class="panel-header" style="background: #fef2f2; border-bottom: 1px solid #fee2e2;">
              <div style="display: flex; align-items: center; gap: 0.5rem;">
                <i class="fa-solid fa-triangle-exclamation" style="color: #dc2626; font-size: 1.1rem;"></i>
                <h3 style="color: #991b1b; font-size: 1rem;">Low Stock & Factory Reorder Reminders</h3>
                <span class="badge badge-danger">${lowStockItems.length} Needs Restock</span>
              </div>
              <button class="btn btn-outline btn-sm" onclick="app.switchView('purchases')">
                <i class="fa-solid fa-truck-ramp-box"></i> Factory Orders
              </button>
            </div>
            <div class="panel-body" style="padding: 0;">
              <div class="table-responsive">
                <table class="data-table">
                  <thead>
                    <tr>
                      <th>Product Name</th>
                      <th>Category</th>
                      <th>Current Quantity</th>
                      <th>Min Alert Threshold</th>
                      <th>Factory Unit Cost</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${lowStockItems.map(p => {
          const qty = Number(p.current_quantity || 0);
          const isZero = qty <= 0;
          return `
                        <tr>
                          <td style="font-weight: 600;">${this.escapeHtml(p.name)}</td>
                          <td><span class="badge badge-neutral">${this.escapeHtml(p.category)}</span></td>
                          <td>
                            <span class="badge ${isZero ? 'badge-danger' : 'badge-warning'}">
                              ${isZero ? 'OUT OF STOCK (0)' : `${qty} ${this.escapeHtml(p.unit || 'pcs')}`}
                            </span>
                          </td>
                          <td style="color: var(--slate-600);">${p.min_stock_alert || 5} ${this.escapeHtml(p.unit || 'pcs')}</td>
                          <td style="font-weight: 600;">${this.formatCurrency(p.cost_price)}</td>
                          <td>
                            <button class="btn btn-primary btn-sm" onclick="app.quickReorderProduct(${this.jsStr(p.id)})" title="Generate purchase order for this item">
                              <i class="fa-solid fa-truck-ramp-box"></i> Order from Factory
                            </button>
                          </td>
                        </tr>
                      `;
        }).join('')}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        `;
      })()}
    `;
  }

  quickReorderProduct(productId) {
    const prod = this.products.find(p => p.id === productId);
    if (!prod) return;

    this.switchView('purchases');
    setTimeout(() => {
      this.openNewPurchaseModal();
      const minAlert = Number(prod.min_stock_alert || 5);
      const curStock = Math.max(0, Number(prod.current_quantity || 0));
      const suggestedQty = Math.max(10, (minAlert * 3) - curStock);

      this.purchaseModalItems = [
        { product_id: prod.id, quantity: suggestedQty, cost_price: Number(prod.cost_price || 0) }
      ];
      this.renderPurchaseModalItems();
      this.showToast(`Pre-filled factory purchase order for ${prod.name} (${suggestedQty} ${prod.unit || 'pcs'})`, 'info');
    }, 120);
  }

  // --- Point of Sale (POS) ---

  getEffectiveProductForBranch(product, branchCode = null) {
    if (!product) return null;
    const bCode = (branchCode || this.branchCode || 'MAIN-01').toUpperCase();
    let effectiveStock = Number(product.current_quantity || 0);
    let effectivePrice = Number(product.selling_price || 0);
    let isAvailable = true;
    let hasCustomPrice = false;

    if (this.isMultiBranch && product.branch_settings && Array.isArray(product.branch_settings)) {
      const bSetting = product.branch_settings.find(bs => (bs.branch_code || '').toUpperCase() === bCode);
      if (bSetting) {
        if (bSetting.current_quantity !== undefined && bSetting.current_quantity !== null) {
          effectiveStock = Number(bSetting.current_quantity);
        }
        if (bSetting.custom_selling_price !== undefined && bSetting.custom_selling_price !== null && bSetting.custom_selling_price !== '') {
          effectivePrice = Number(bSetting.custom_selling_price);
          hasCustomPrice = true;
        }
        if (bSetting.is_available !== undefined && bSetting.is_available !== null) {
          isAvailable = Number(bSetting.is_available) === 1;
        }
      }
    }

    return {
      ...product,
      effectiveStock,
      effectivePrice,
      isAvailable,
      hasCustomPrice
    };
  }

  isRentalProduct(product) {
    if (!product) return false;
    if (Number(product.is_rental) === 1 || product.is_rental === '1' || product.is_rental === true) return true;
    const cat = String(product.category || '').toLowerCase();
    if (cat.includes('rental') || cat.includes('hire')) {
      return true;
    }
    return false;
  }

  getPosHTML() {
    const activeCategory = this.posSelectedCategory || 'All';
    let filteredProducts = (this.products || []).filter(p => !this.isRentalProduct(p));

    if (activeCategory !== 'All') {
      filteredProducts = filteredProducts.filter(p => p.category === activeCategory);
    }

    if (this.posSearchTerm) {
      const searchTerm = (this.posSearchTerm || '').trim().toLowerCase();
      const compactSearch = searchTerm.replace(/[\s\-_]/g, '');
      filteredProducts = filteredProducts.filter(p => {
        const name = (p.name || '').toLowerCase();
        const sku = (p.sku || '').toLowerCase();
        const skuCompact = sku.replace(/[\s\-_]/g, '');
        const barcode = (p.barcode || '').toLowerCase();
        const barcodeCompact = barcode.replace(/[\s\-_]/g, '');
        return (
          name.includes(searchTerm) ||
          sku.includes(searchTerm) ||
          (compactSearch && skuCompact.includes(compactSearch)) ||
          barcode.includes(searchTerm) ||
          (compactSearch && barcodeCompact.includes(compactSearch))
        );
      });
    }

    if (this.isMultiBranch) {
      // Filter out products that have been explicitly disabled for sales at this branch
      filteredProducts = filteredProducts.filter(rawP => {
        const eff = this.getEffectiveProductForBranch(rawP);
        return eff.isAvailable;
      });
    }

    const { subtotal, discount, taxRate, tax, totalAmount: total } = this.getCartTotals();

    return `
      <div class="pos-container">
        <!-- Left: Product Grid with Photos & Out-of-Stock handling -->
        <div class="pos-products-panel">
          <div class="pos-filter-bar">
            <div style="display: flex; gap: 0.5rem; flex: 1;">
              <div class="pos-search-input" style="flex: 1;">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" id="pos-search" class="form-control" placeholder="Search product name, SKU, or scan barcode..." value="${this.escapeHtml(this.posSearchTerm || '')}">
              </div>
              <button type="button" class="btn btn-outline" id="btn-pos-camera-scan" onclick="app.openCameraScanner('pos')" title="Scan barcode with phone/webcam camera" style="display: flex; align-items: center; gap: 0.45rem; padding: 0.6rem 0.95rem; font-weight: 700; border-color: var(--slate-300); color: var(--slate-700); background: #ffffff; flex-shrink: 0;">
                <i class="fa-solid fa-camera" style="color: var(--primary); font-size: 1.05rem;"></i>
                <span class="pos-scan-btn-text">Scan</span>
              </button>
            </div>
            <select id="pos-category-filter" class="form-control" style="width: 170px;">
              <option value="All">All Categories</option>
              ${this.categories.map(c => `<option value="${this.escapeHtml(c)}" ${activeCategory === c ? 'selected' : ''}>${this.escapeHtml(c)}</option>`).join('')}
            </select>
          </div>

          <div class="pos-grid" id="pos-product-grid">
            ${filteredProducts.length > 0 ? filteredProducts.map(rawP => {
      const eff = this.getEffectiveProductForBranch(rawP);
      const inStock = Number(eff.effectiveStock || 0);
      const isOut = inStock <= 0;
      const isLow = inStock > 0 && inStock <= Number(eff.min_stock_alert || 5);
      const imgUrl = eff.image_url || 'assets/images/products/placeholder.svg';

      return `
                <div class="pos-product-card ${isOut ? 'out-of-stock' : ''}" onclick="app.handleProductCardClick(${this.jsStr(eff.id)})">
                  ${isOut ? '<div class="out-of-stock-ribbon">Out of Stock</div>' : ''}
                  
                  <div class="product-img-wrapper">
                    <img src="${this.escapeHtml(imgUrl)}" alt="${this.escapeHtml(eff.name)}" loading="lazy" onerror="this.src='assets/images/products/placeholder.svg'">
                  </div>

                  <div>
                    <h4>${this.escapeHtml(eff.name)}</h4>
                    <span class="sku-text">${this.escapeHtml(eff.sku || 'No SKU')} · ${this.escapeHtml(eff.unit || 'pcs')}</span>
                  </div>

                  <div class="price-row">
                    <span class="price-tag">${this.formatCurrency(eff.effectivePrice)}</span>
                    <span class="badge ${isOut ? 'badge-danger' : (isLow ? 'badge-warning' : 'badge-neutral')}" style="margin-top: 0.25rem; font-size: 0.72rem; align-self: flex-start;">
                      ${isOut ? '0 in stock' : `${inStock} in stock`}
                    </span>
                  </div>
                </div>
              `;
    }).join('') : `
              <div style="grid-column: 1/-1; text-align: center; padding: 3rem; color: var(--slate-400);">
                <i class="fa-solid fa-box-open" style="font-size: 2.5rem; margin-bottom: 0.75rem; display: block;"></i>
                <p>No products match your search.</p>
              </div>
            `}
          </div>
        </div>

        <!-- Right: Cart & Checkout -->
        <div class="pos-cart-panel">
          <div class="cart-header">
            <div style="display: flex; align-items: center; gap: 0.5rem;">
              <button class="btn btn-outline btn-sm show-mobile-only" onclick="app.closePosCartModal()" style="padding: 0.25rem 0.55rem;" title="Close Cart Modal">
                <i class="fa-solid fa-arrow-left"></i>
              </button>
              <h3 style="font-size: 1.05rem; font-weight: 700; color: var(--slate-800); margin: 0;">
                <i class="fa-solid fa-cart-shopping"></i> Checkout Cart (${this.cart.reduce((c, i) => c + i.quantity, 0)})
              </h3>
            </div>
            <div style="display: flex; gap: 0.4rem; align-items: center;">
              <button class="btn btn-outline btn-sm" onclick="app.clearCart()" style="color: var(--danger); border-color: var(--danger-border);">
                <i class="fa-solid fa-trash-can"></i> Clear
              </button>
              <button class="btn btn-outline btn-sm show-mobile-only" onclick="app.closePosCartModal()" style="border: none; padding: 0.25rem 0.55rem; color: var(--slate-400);" title="Close">
                <i class="fa-solid fa-xmark" style="font-size: 1.1rem;"></i>
              </button>
            </div>
          </div>

          <!-- Customer Selection -->
          <div style="padding: 0.75rem 1.25rem; border-bottom: 1px solid var(--slate-200); background: #ffffff;">
            <label class="form-label" style="font-size: 0.75rem;">Customer (Buyer)</label>
            <div style="display: flex; gap: 0.5rem;">
              <select id="pos-customer-select" class="form-control" style="font-size: 0.85rem;">
                <option value="cust-walkin">Walk-in Customer</option>
                ${this.customers.filter(c => c.id !== 'cust-walkin').map(c => `
                  <option value="${this.escapeHtml(c.id)}" ${this.selectedCustomerId === c.id ? 'selected' : ''}>${this.escapeHtml(c.name)} (${this.escapeHtml(c.phone || 'No phone')})</option>
                `).join('')}
              </select>
              <button class="btn btn-outline btn-sm" onclick="app.openNewCustomerModal()" title="Add Customer">
                <i class="fa-solid fa-user-plus"></i>
              </button>
            </div>
          </div>

          <!-- Cart Item List -->
          <div class="cart-items-list" id="pos-cart-items">
            ${this.cart.length > 0 ? this.cart.map((item, idx) => `
              <div class="cart-item-row">
                <div class="cart-item-info">
                  <h5>${this.escapeHtml(item.name)}</h5>
                  <span>${this.formatCurrency(item.selling_price)} × ${item.quantity} = ${this.formatCurrency(item.quantity * item.selling_price)}</span>
                </div>
                <div class="cart-item-qty">
                  <button class="btn-qty" onclick="app.updateCartQty(${idx}, -1)"><i class="fa-solid fa-minus"></i></button>
                  <span style="font-weight: 700; min-width: 20px; text-align: center;">${item.quantity}</span>
                  <button class="btn-qty" onclick="app.updateCartQty(${idx}, 1)"><i class="fa-solid fa-plus"></i></button>
                  <button class="btn-qty" onclick="app.removeFromCart(${idx})" style="color: var(--danger); margin-left: 0.25rem;"><i class="fa-solid fa-xmark"></i></button>
                </div>
              </div>
            `).join('') : `
              <div style="text-align: center; padding: 3rem 1rem; color: var(--slate-400);">
                <i class="fa-solid fa-cart-arrow-down" style="font-size: 2rem; margin-bottom: 0.5rem; display: block;"></i>
                <p style="font-size: 0.9rem;">Cart is empty.</p>
                <span style="font-size: 0.75rem;">Click any product on the left to add.</span>
              </div>
            `}
          </div>

          <!-- Cart Footer & Totals -->
          <div class="cart-footer">
            <div class="cart-summary-line">
              <span>Subtotal</span>
              <span>${this.formatCurrency(subtotal)}</span>
            </div>
            <div class="cart-summary-line">
              <span>Discount</span>
              <input type="number" id="pos-cart-discount" style="width: 70px; text-align: right; padding: 0.2rem; font-size: 0.8rem;" value="${this.cartDiscount || 0}" min="0" step="any">
            </div>
            <div class="cart-summary-line total">
              <span>Total Payable</span>
              <span>${this.formatCurrency(total)}</span>
            </div>

            <button class="btn btn-success btn-lg" onclick="app.openCheckoutModal()" style="width: 100%; margin-top: 0.85rem;" ${this.cart.length === 0 ? 'disabled' : ''}>
              <i class="fa-solid fa-cash-register"></i> Proceed to Payment
            </button>
          </div>
        </div>

        ${this.cart.length > 0 ? `
          <div class="mobile-cart-float show-mobile-flex" id="pos-floating-cart-pill" onclick="app.openPosCartModal()">
            <div style="display: flex; align-items: center; gap: 0.6rem;">
              <span class="badge badge-success" style="padding: 0.2rem 0.55rem; font-size: 0.8rem;">
                <i class="fa-solid fa-cart-shopping"></i> ${this.cart.reduce((s, i) => s + i.quantity, 0)}
              </span>
              <span style="font-weight: 700; font-size: 0.95rem;">${this.formatCurrency(total)}</span>
            </div>
            <span style="font-weight: 600; font-size: 0.82rem; display: flex; align-items: center; gap: 0.35rem;">
              View Cart & Pay <i class="fa-solid fa-arrow-down"></i>
            </span>
          </div>
        ` : ''}
      </div>
    `;
  }

  bindPosEvents() {
    this.setupPosCartScrollObserver();
    const searchInput = document.getElementById('pos-search');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        this.posSearchTerm = e.target.value;
        this.renderCurrentView();
        const freshInput = document.getElementById('pos-search');
        if (freshInput) {
          freshInput.focus();
          freshInput.setSelectionRange(freshInput.value.length, freshInput.value.length);
        }
      });

      searchInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          const val = (searchInput.value || '').trim();
          if (val) {
            this.handleBarcodeScan(val);
            searchInput.value = '';
            this.posSearchTerm = '';
            this.renderCurrentView();
          }
        }
      });
    }

    const catSelect = document.getElementById('pos-category-filter');
    if (catSelect) {
      catSelect.addEventListener('change', (e) => {
        this.posSelectedCategory = e.target.value;
        this.renderCurrentView();
      });
    }

    const custSelect = document.getElementById('pos-customer-select');
    if (custSelect) {
      custSelect.addEventListener('change', (e) => {
        this.selectedCustomerId = e.target.value;
      });
    }

    const discountInput = document.getElementById('pos-cart-discount');
    if (discountInput) {
      discountInput.addEventListener('input', (e) => {
        this.cartDiscount = Number(e.target.value) || 0;
        this.renderCurrentView();
      });
    }
  }

  // --- Out of Stock Handling ---

  handleProductCardClick(productId) {
    const rawProduct = this.products.find(p => p.id === productId);
    if (!rawProduct) return;
    const product = this.getEffectiveProductForBranch(rawProduct);

    if (!product.isAvailable) {
      this.showToast(`"${product.name}" is not enabled for sales at branch ${this.branchCode || 'MAIN-01'}.`, 'warning');
      return;
    }

    const inStock = Number(product.effectiveStock || 0);

    // If out of stock
    if (inStock <= 0) {
      // Check if store allows negative stock sales
      if (this.storeProfile.allow_negative_stock == 1) {
        this.addToCart(productId);
        this.showToast(`Warning: "${product.name}" is out of stock. Stock is now negative.`, 'warning');
      } else {
        // Open Out-of-Stock dialog
        this.openOutOfStockModal(product);
      }
      return;
    }

    // Check if adding exceeds stock
    const cartItem = this.cart.find(i => i.product_id === productId);
    if (cartItem && (cartItem.quantity + 1 > inStock)) {
      if (this.storeProfile.allow_negative_stock == 1) {
        this.addToCart(productId);
      } else {
        this.showToast(`Cannot add more: Only ${inStock} ${product.unit || 'pcs'} available at ${this.branchCode || 'this branch'}.`, 'warning');
      }
      return;
    }

    this.addToCart(productId);
  }

  openOutOfStockModal(product, unitLabel = null) {
    this.pendingOosProductId = product.id;
    // The override adds the line afterwards, and a manager who was asked about a crate
    // and agreed to go negative does not mean one loose egg at the egg price.
    this.pendingOosUnitLabel = unitLabel;
    const title = document.getElementById('oos-product-title');
    if (title) title.innerText = product.name;

    const overrideBtn = document.getElementById('btn-oos-override');
    if (overrideBtn) {
      overrideBtn.style.display = this.isCashier() ? 'none' : 'block';
    }

    const modal = document.getElementById('outofstock-modal');
    if (modal) modal.classList.add('active');
  }

  closeOutOfStockModal() {
    this.pendingOosProductId = null;
    this.pendingOosUnitLabel = null;
    const modal = document.getElementById('outofstock-modal');
    if (modal) modal.classList.remove('active');
  }

  restockFromOosModal() {
    const prodId = this.pendingOosProductId;
    this.closeOutOfStockModal();
    this.switchView('purchases');
    setTimeout(() => {
      this.openNewPurchaseModal();
      if (prodId) {
        this.purchaseModalItems = [{
          product_id: prodId,
          quantity: 20,
          cost_price: this.products.find(p => p.id === prodId)?.cost_price || 0
        }];
        this.renderPurchaseModalItems();
      }
    }, 200);
  }

  overrideOosAndAddToCart() {
    if (this.isCashier()) {
      this.showToast('Permission denied: Cashiers cannot override out-of-stock restrictions.', 'danger');
      return;
    }
    if (this.pendingOosProductId) {
      const prodId = this.pendingOosProductId;
      const prodUnit = this.pendingOosUnitLabel;
      this.closeOutOfStockModal();
      this.addToCart(prodId, prodUnit);
      this.showToast('Product added via Manager Override (Negative Stock permitted).', 'info');
    }
  }

  addToCart(productId, selectedUnit = null) {
    const rawProduct = this.products.find(p => p.id === productId);
    if (!rawProduct) return;
    const product = this.getEffectiveProductForBranch(rawProduct);

    const baseUnit = this.productUnitOf(product, null);
    const unit = this.productUnitOf(product, selectedUnit);
    if (!unit) return;

    const basePrice = Number(product.effectivePrice || product.selling_price || 0);
    const sellingPrice = this.productUnitPrice(unit, basePrice);

    const targetSeat = this.activeSeat || 'Shared';
    const existingIndex = this.cart.findIndex(i => i.product_id === productId
      && String(i.selected_unit || i.unit || '').toLowerCase() === unit.unit_name.toLowerCase()
      && String(i.seat_number || 'Shared') === targetSeat);
    if (existingIndex >= 0) {
      this.cart[existingIndex].quantity += 1;
    } else {
      this.cart.push({
        product_id: product.id,
        name: product.name,
        unit_cost_price: Number(product.cost_price || 0),
        base_selling_price: basePrice,
        selling_price: sellingPrice,
        unit: (baseUnit && baseUnit.unit_name) || product.unit || 'pcs',
        selected_unit: unit.unit_name,
        multiplier: Number(unit.size_in_base || 1),
        quantity: 1,
        seat_number: targetSeat,
        prep_notes: '',
        branch_code: this.branchCode || 'MAIN-01'
      });
    }
    this.renderCurrentView();
  }

  updateCartQty(index, change) {
    if (this.cart[index]) {
      const item = this.cart[index];
      this.setCartQty(index, Number(item.quantity || 0) + change, true);
    }
  }

  // The one place a cart line's count changes, whether a button nudged it by one or a
  // cashier typed twelve crates at it. The count is in the line's own size and the shelf
  // is counted in loose units, so the two only meet after the conversion.
  setCartQty(index, rawValue, isStep = false) {
    const item = this.cart[index];
    if (!item) return;

    // A box cleared to be retyped is not a quantity of zero: it is the cashier deleting a
    // digit, and the line - with the goods already agreed with the customer - would go.
    if (rawValue === '' || rawValue === null || rawValue === undefined) return;
    const typed = Number(rawValue);
    if (!Number.isFinite(typed)) return;
    const newQty = Math.floor(typed);
    if (newQty <= 0) {
      this.cart.splice(index, 1);
      this.renderCurrentView();
      return;
    }
    if (newQty === Number(item.quantity || 0)) {
      this.renderCurrentView();
      return;
    }

    const rawProd = this.products.find(p => p.id === item.product_id);
    // Taking a line down is never refused, even on a cart that is already over the
    // shelf: a cashier unwinding a mistake must always be able to unwind it.
    if (rawProd && newQty > Number(item.quantity || 0)) {
      const prod = this.getEffectiveProductForBranch(rawProd);
      const multiplier = Number(item.multiplier || 1);
      const room = this.cartRoomInBase(prod, index);
      const wanted = newQty * multiplier;
      if (wanted > room.room && this.storeProfile.allow_negative_stock != 1) {
        this.showToast(isStep
          ? `Maximum available stock reached (${room.room} ${prod.unit || 'pcs'} left at ${this.branchCode || 'this branch'}).`
          : `Cannot put ${newQty} ${item.selected_unit || item.unit} of ${item.name} in the cart: that is ${wanted} ${prod.unit || 'pcs'} and ${room.room} are left on the shelf.`,
          'warning');
        this.renderCurrentView();
        return;
      }
    }

    item.quantity = newQty;
    if (item.discount_percent) {
      const rawLineTotal = Number(item.quantity || 1) * Number(item.selling_price || 0);
      item.line_discount = Math.round(((rawLineTotal * item.discount_percent) / 100) * 100) / 100;
    }
    this.renderCurrentView();
  }

  removeFromCart(index) {
    this.cart.splice(index, 1);
    this.renderCurrentView();
  }

  clearCart() {
    this.cart = [];
    this.cartDiscount = 0;
    this.renderCurrentView();
  }

  // --- Interactive Checkout Modal (No browser prompt) ---

  // --- Interactive Checkout Modal & Dynamic Payment Methods ---

  openCheckoutModal() {
    if (this.cart.length === 0) return;
    this.closePosCartModal();

    const { totalAmount, tax, taxRate } = this.getCartTotals();

    const custSelect = document.getElementById('pos-customer-select');
    const custId = custSelect ? custSelect.value : 'cust-walkin';
    const customerObj = this.customers.find(c => c.id === custId) || { name: 'Walk-in Customer' };

    document.getElementById('checkout-total-amount').innerText = this.formatCurrency(totalAmount);
    document.getElementById('checkout-customer-name').innerText = `Customer: ${customerObj.name}`;
    const taxBadge = document.getElementById('checkout-tax-badge');
    if (taxBadge) {
      taxBadge.innerText = tax > 0 ? `Includes Tax / VAT (${taxRate}%): +${this.formatCurrency(tax)}` : '';
    }

    // Render quick tender chips dynamically using current store currency
    const sym = this.storeProfile.currency_symbol || '$';
    const symHtml = this.escapeHtml(sym);
    const chipsContainer = document.getElementById('checkout-quick-cash-chips');
    if (chipsContainer) {
      chipsContainer.innerHTML = `
        <button type="button" class="btn-tender" onclick="app.setTenderAmount('exact')">Exact</button>
        <button type="button" class="btn-tender" onclick="app.setTenderAmount(10)">+${symHtml}10</button>
        <button type="button" class="btn-tender" onclick="app.setTenderAmount(20)">+${symHtml}20</button>
        <button type="button" class="btn-tender" onclick="app.setTenderAmount(50)">+${symHtml}50</button>
        <button type="button" class="btn-tender" onclick="app.setTenderAmount(100)">+${symHtml}100</button>
      `;
    }

    const paidInput = document.getElementById('checkout-amount-paid');
    paidInput.value = totalAmount.toFixed(2);

    paidInput.oninput = () => this.updateCheckoutChange();

    document.getElementById('checkout-modal').classList.add('active');

    // Default to Cash and trigger dynamic section update
    this.setPaymentMethod('CASH');
    setTimeout(() => paidInput.select(), 100);
  }

  openPosCartModal() {
    const cartPanel = document.querySelector('.pos-cart-panel');
    if (!cartPanel) return;

    let overlay = document.getElementById('pos-cart-modal-overlay');
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = 'pos-cart-modal-overlay';
      overlay.className = 'pos-cart-backdrop';
      overlay.onclick = () => this.closePosCartModal();
      document.body.appendChild(overlay);
    }
    overlay.classList.add('active');
    cartPanel.classList.add('pos-cart-modal-open');
    document.body.classList.add('pos-cart-locked');
  }

  closePosCartModal() {
    const cartPanel = document.querySelector('.pos-cart-panel');
    if (cartPanel) {
      cartPanel.classList.remove('pos-cart-modal-open');
    }
    const overlay = document.getElementById('pos-cart-modal-overlay');
    if (overlay) {
      overlay.classList.remove('active');
    }
    document.body.classList.remove('pos-cart-locked');
  }

  closeCheckoutModal() {
    document.getElementById('checkout-modal').classList.remove('active');
  }

  setPaymentMethod(method, btnEl) {
    this.selectedPaymentMethod = method;

    // 1. Update button visual active state
    document.querySelectorAll('.pay-method-btn').forEach(b => {
      const isMatch = b.getAttribute('data-method') === method;
      b.classList.toggle('active', isMatch);
    });

    // 2. Hide all payment method sections
    const sections = ['cash', 'card', 'transfer', 'split', 'credit'];
    sections.forEach(s => {
      const el = document.getElementById(`pay-section-${s}`);
      if (el) el.style.display = 'none';
    });

    const { totalAmount } = this.getCartTotals();
    const paidInput = document.getElementById('checkout-amount-paid');

    const custSelect = document.getElementById('pos-customer-select');
    const custId = custSelect ? custSelect.value : 'cust-walkin';
    const customerObj = this.customers.find(c => c.id === custId) || { name: 'Walk-in Customer', balance: 0 };

    // 3. Show and configure selected section
    if (method === 'CASH') {
      const cashSection = document.getElementById('pay-section-cash');
      if (cashSection) cashSection.style.display = 'block';
      if (paidInput) {
        paidInput.value = totalAmount.toFixed(2);
      }
      this.updateCheckoutChange();
    } else if (method === 'CARD') {
      const cardSection = document.getElementById('pay-section-card');
      if (cardSection) cardSection.style.display = 'block';
      if (paidInput) paidInput.value = totalAmount.toFixed(2);
    } else if (method === 'TRANSFER') {
      const transferSection = document.getElementById('pay-section-transfer');
      if (transferSection) transferSection.style.display = 'block';
      if (paidInput) paidInput.value = totalAmount.toFixed(2);
    } else if (method === 'SPLIT') {
      const splitSection = document.getElementById('pay-section-split');
      if (splitSection) splitSection.style.display = 'block';
      const cashInp = document.getElementById('split-cash-amount');
      const cardInp = document.getElementById('split-card-amount');
      const transferInp = document.getElementById('split-transfer-amount');
      if (cashInp && !cashInp.value && cardInp && !cardInp.value && transferInp && !transferInp.value) {
        cashInp.value = (totalAmount / 2).toFixed(2);
        cardInp.value = (totalAmount - parseFloat(cashInp.value)).toFixed(2);
        transferInp.value = '0.00';
      }
      this.updateSplitCalculation();
    } else if (method === 'CREDIT') {
      const creditSection = document.getElementById('pay-section-credit');
      if (creditSection) creditSection.style.display = 'block';

      const walkinWarning = document.getElementById('credit-walkin-warning');
      const custInfo = document.getElementById('credit-customer-info');

      if (custId === 'cust-walkin') {
        if (walkinWarning) walkinWarning.style.display = 'block';
        if (custInfo) custInfo.style.display = 'none';
      } else {
        if (walkinWarning) walkinWarning.style.display = 'none';
        if (custInfo) custInfo.style.display = 'block';

        const prevBal = Number(customerObj.balance || 0);
        const grossTotal = prevBal + totalAmount;

        const depositInput = document.getElementById('credit-deposit-paid');
        if (depositInput) {
          depositInput.value = '0.00';
          depositInput.oninput = () => this.updateCreditLiveBalance();
        }

        // Render quick-fill chips for credit deposit
        const chipsContainer = document.getElementById('credit-quick-chips');
        if (chipsContainer) {
          chipsContainer.innerHTML = `
            <button type="button" class="btn btn-outline btn-sm" style="font-size: 0.75rem; padding: 0.25rem 0.55rem;" onclick="app.setCreditDeposit(0)">
              No Deposit (0.00)
            </button>
            <button type="button" class="btn btn-outline btn-sm" style="font-size: 0.75rem; padding: 0.25rem 0.55rem; color: var(--primary); border-color: var(--primary);" onclick="app.setCreditDeposit(${totalAmount.toFixed(2)})">
              Pay Bill (${this.formatCurrency(totalAmount)})
            </button>
            ${prevBal > 0 ? `
              <button type="button" class="btn btn-outline btn-sm" style="font-size: 0.75rem; padding: 0.25rem 0.55rem; color: #047857; border-color: #047857; font-weight: 700;" onclick="app.setCreditDeposit(${grossTotal.toFixed(2)})">
                <i class="fa-solid fa-check"></i> Clear All Debt (${this.formatCurrency(grossTotal)})
              </button>
            ` : ''}
          `;
        }

        this.updateCreditLiveBalance();
        setTimeout(() => depositInput?.select(), 100);
      }
    }
  }

  setCreditDeposit(amount) {
    const depositInput = document.getElementById('credit-deposit-paid');
    if (depositInput) {
      depositInput.value = Number(amount || 0).toFixed(2);
      this.updateCreditLiveBalance();
    }
  }

  updateCreditLiveBalance() {
    const { totalAmount } = this.getCartTotals();

    const custSelect = document.getElementById('pos-customer-select');
    const custId = custSelect ? custSelect.value : 'cust-walkin';
    const customerObj = this.customers.find(c => c.id === custId) || { name: 'Walk-in Customer', balance: 0 };

    const prevBal = Number(customerObj.balance || 0);
    const grossTotal = prevBal + totalAmount;

    const depositInput = document.getElementById('credit-deposit-paid');
    const depositPaid = parseFloat(depositInput?.value) || 0;
    const finalProjectedBalance = grossTotal - depositPaid;

    const prevBalEl = document.getElementById('credit-prev-balance');
    const saleAmtEl = document.getElementById('credit-sale-amount');
    const grossDueEl = document.getElementById('credit-gross-due');
    const newBalEl = document.getElementById('credit-new-balance');
    const noteEl = document.getElementById('credit-balance-note');
    const boxEl = document.getElementById('credit-projected-box');
    const labelEl = document.getElementById('credit-projected-label');

    if (prevBalEl) prevBalEl.innerText = this.formatCurrency(prevBal);
    if (saleAmtEl) saleAmtEl.innerText = this.formatCurrency(totalAmount);
    if (grossDueEl) grossDueEl.innerText = this.formatCurrency(grossTotal);

    if (newBalEl) {
      if (finalProjectedBalance > 0) {
        newBalEl.innerText = this.formatCurrency(finalProjectedBalance);
        newBalEl.style.color = '#b45309';
        if (boxEl) {
          boxEl.style.background = '#fef3c7';
          boxEl.style.borderColor = '#fde68a';
        }
        if (labelEl) labelEl.innerText = 'Remaining Debt After Payment:';
        if (noteEl) {
          if (depositPaid > 0) {
            noteEl.innerHTML = `<i class="fa-solid fa-circle-info"></i> Deposit of ${this.formatCurrency(depositPaid)} applied. Customer will still owe <strong>${this.formatCurrency(finalProjectedBalance)}</strong>.`;
          } else {
            noteEl.innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i> Full sale added to credit. Total debt will be <strong>${this.formatCurrency(finalProjectedBalance)}</strong>.`;
          }
        }
      } else if (finalProjectedBalance === 0) {
        newBalEl.innerText = `${this.formatCurrency(0)} (Fully Cleared!)`;
        newBalEl.style.color = '#047857';
        if (boxEl) {
          boxEl.style.background = '#d1fae5';
          boxEl.style.borderColor = '#a7f3d0';
        }
        if (labelEl) labelEl.innerText = 'Projected Account Balance:';
        if (noteEl) {
          noteEl.innerHTML = `<i class="fa-solid fa-circle-check"></i> <strong>Full Settlement!</strong> Customer account and new purchase are completely cleared.`;
        }
      } else {
        const storeCredit = Math.abs(finalProjectedBalance);
        newBalEl.innerText = `+${this.formatCurrency(storeCredit)} (Store Credit)`;
        newBalEl.style.color = '#047857';
        if (boxEl) {
          boxEl.style.background = '#d1fae5';
          boxEl.style.borderColor = '#a7f3d0';
        }
        if (labelEl) labelEl.innerText = 'Advance Credit Generated:';
        if (noteEl) {
          noteEl.innerHTML = `<i class="fa-solid fa-credit-card"></i> Payment exceeds total debt by <strong>${this.formatCurrency(storeCredit)}</strong>. Surplus remains as customer advance credit.`;
        }
      }
    }
  }

  updateSplitCalculation(changedField = null) {
    const { totalAmount } = this.getCartTotals();

    const cash = parseFloat(document.getElementById('split-cash-amount')?.value) || 0;
    const card = parseFloat(document.getElementById('split-card-amount')?.value) || 0;
    const transfer = parseFloat(document.getElementById('split-transfer-amount')?.value) || 0;

    const sumPaid = cash + card + transfer;
    const diff = totalAmount - sumPaid;

    const badge = document.getElementById('split-remaining-badge');
    const alertEl = document.getElementById('split-status-alert');
    const textEl = document.getElementById('split-status-text');

    if (badge) {
      if (Math.abs(diff) < 0.01) {
        badge.className = 'badge badge-success';
        badge.innerHTML = '<i class="fa-solid fa-check"></i> Balanced (' + this.formatCurrency(0) + ')';
      } else if (diff > 0) {
        badge.className = 'badge badge-warning';
        badge.innerHTML = `Short: ${this.formatCurrency(diff)}`;
      } else {
        badge.className = 'badge badge-danger';
        badge.innerHTML = `Over: ${this.formatCurrency(Math.abs(diff))}`;
      }
    }

    if (alertEl && textEl) {
      if (Math.abs(diff) < 0.01) {
        alertEl.style.background = '#dcfce7';
        alertEl.style.color = '#15803d';
        textEl.innerHTML = `<i class="fa-solid fa-circle-check"></i> <strong>Perfect Balance!</strong> Total of ${this.formatCurrency(sumPaid)} matches total due.`;
      } else if (diff > 0) {
        alertEl.style.background = '#fef3c7';
        alertEl.style.color = '#92400e';
        textEl.innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i> Amount remaining to assign: <strong>${this.formatCurrency(diff)}</strong>`;
      } else {
        alertEl.style.background = '#fee2e2';
        alertEl.style.color = '#991b1b';
        textEl.innerHTML = `<i class="fa-solid fa-circle-exclamation"></i> Split total exceeds sale by <strong>${this.formatCurrency(Math.abs(diff))}</strong>.`;
      }
    }
  }

  autoFillSplitRemainder() {
    const { totalAmount } = this.getCartTotals();

    const cash = parseFloat(document.getElementById('split-cash-amount')?.value) || 0;
    const card = parseFloat(document.getElementById('split-card-amount')?.value) || 0;
    const transfer = parseFloat(document.getElementById('split-transfer-amount')?.value) || 0;

    const sumWithoutCash = card + transfer;
    const remainder = Math.max(0, totalAmount - sumWithoutCash);

    const cashInp = document.getElementById('split-cash-amount');
    if (cashInp) {
      cashInp.value = remainder.toFixed(2);
      this.updateSplitCalculation();
      this.showToast(`Auto-assigned ${this.formatCurrency(remainder)} to Cash remainder.`, 'info');
    }
  }

  setTenderAmount(amount) {
    const { totalAmount } = this.getCartTotals();
    const paidInput = document.getElementById('checkout-amount-paid');

    if (amount === 'exact') {
      paidInput.value = totalAmount.toFixed(2);
    } else {
      const current = parseFloat(paidInput.value) || 0;
      paidInput.value = (current + amount).toFixed(2);
    }
    this.updateCheckoutChange();
  }

  updateCheckoutChange() {
    const { totalAmount } = this.getCartTotals();

    const paidInput = document.getElementById('checkout-amount-paid');
    const amountPaid = parseFloat(paidInput?.value) || 0;
    const change = amountPaid - totalAmount;

    const changeEl = document.getElementById('checkout-change-amount');
    const boxEl = document.getElementById('checkout-change-container');

    if (changeEl && boxEl) {
      if (change >= 0) {
        changeEl.innerText = this.formatCurrency(change);
        boxEl.className = 'change-display-box change-positive';
        boxEl.querySelector('span:first-child').innerText = 'Change Due to Customer:';
      } else {
        changeEl.innerText = this.formatCurrency(Math.abs(change));
        boxEl.className = 'change-display-box change-underpaid';
        boxEl.querySelector('span:first-child').innerText = 'Remaining Balance / Due:';
      }
    }

    // Overpayment to Customer Account toggle
    const custSelect = document.getElementById('pos-customer-select');
    const custId = custSelect ? custSelect.value : 'cust-walkin';
    const overpaymentBox = document.getElementById('checkout-overpayment-box');
    const overpaymentAmountEl = document.getElementById('checkout-overpayment-amount');
    const overpaymentNoteEl = document.getElementById('checkout-overpayment-note');

    if (overpaymentBox) {
      if (custId !== 'cust-walkin' && change > 0) {
        overpaymentBox.style.display = 'block';
        if (overpaymentAmountEl) overpaymentAmountEl.innerText = this.formatCurrency(change);

        const customerObj = this.customers.find(c => c.id === custId);
        const currBal = Number(customerObj?.balance || 0);
        if (overpaymentNoteEl) {
          if (currBal > 0) {
            const newBal = currBal - change;
            overpaymentNoteEl.innerText = `Current debt: ${this.formatCurrency(currBal)} -> Balance after deposit: ${this.formatCurrency(newBal)}`;
          } else {
            overpaymentNoteEl.innerText = `Current balance: ${this.formatCurrency(currBal)} -> Will add store credit of ${this.formatCurrency(change)}`;
          }
        }
      } else {
        overpaymentBox.style.display = 'none';
      }
    }
  }

  async confirmFinalCheckout() {
    // This body awaits several writes before it clears the cart, so a second click - or
    // the Fast Cash key pressed twice - ran it twice against the same basket: two
    // receipts, stock out twice, the customer's balance adjusted twice. One sale at a
    // time, and the flag is released even if the body throws.
    if (this._checkoutInFlight) {
      this.showToast('This sale is still being completed. Please wait.', 'warning');
      return;
    }
    this._checkoutInFlight = true;
    try {
      await this._runFinalCheckout();
    } finally {
      this._checkoutInFlight = false;
    }
  }

  async _runFinalCheckout() {
    const { subtotal, totalCost, discount, tax, totalAmount, grossProfit } = this.getCartTotals();

    const custId = document.getElementById('pos-customer-select')?.value || 'cust-walkin';
    const customerObj = this.customers.find(c => c.id === custId) || { name: 'Walk-in Customer' };

    let amountPaid = totalAmount;
    let changeDue = 0;
    let notes = '';
    let applyOverpayment = false;
    let paymentReference = '';

    if (this.selectedPaymentMethod === 'CASH') {
      const paidInput = document.getElementById('checkout-amount-paid');
      amountPaid = parseFloat(paidInput?.value) || 0;
      if (amountPaid < totalAmount) {
        this.showToast('Amount paid is less than total amount due!', 'danger');
        return;
      }

      const overpaymentCheck = document.getElementById('checkout-apply-overpayment');
      if (custId !== 'cust-walkin' && amountPaid > totalAmount && overpaymentCheck && overpaymentCheck.checked) {
        applyOverpayment = true;
        const overpayment = amountPaid - totalAmount;
        customerObj.balance = Number(customerObj.balance || 0) - overpayment;
        await localDB.customers.put(customerObj);
        changeDue = 0;
        notes = (notes ? notes + ' | ' : '') + `Overpayment of ${this.formatCurrency(overpayment)} deposited to customer balance`;
      } else {
        changeDue = Math.max(0, amountPaid - totalAmount);
      }
    } else if (this.selectedPaymentMethod === 'CARD') {
      amountPaid = totalAmount;
      changeDue = 0;
      paymentReference = document.getElementById('checkout-card-ref')?.value.trim() || '';
      if (paymentReference) notes = (notes ? notes + ' | ' : '') + `Card Ref: ${paymentReference}`;

    } else if (this.selectedPaymentMethod === 'TRANSFER') {
      amountPaid = totalAmount;
      changeDue = 0;
      paymentReference = document.getElementById('checkout-transfer-ref')?.value.trim() || '';
      if (paymentReference) notes = (notes ? notes + ' | ' : '') + `MoMo Ref: ${paymentReference}`;

    } else if (this.selectedPaymentMethod === 'SPLIT') {
      const splitCash = parseFloat(document.getElementById('split-cash-amount')?.value) || 0;
      const splitCard = parseFloat(document.getElementById('split-card-amount')?.value) || 0;
      const splitTransfer = parseFloat(document.getElementById('split-transfer-amount')?.value) || 0;
      const splitTotal = splitCash + splitCard + splitTransfer;

      if (Math.abs(splitTotal - totalAmount) > 0.01) {
        this.showToast(`Split total (${this.formatCurrency(splitTotal)}) does not match total due (${this.formatCurrency(totalAmount)})!`, 'danger');
        return;
      }

      amountPaid = splitTotal;
      changeDue = 0;
      const customNotes = document.getElementById('split-payment-notes')?.value.trim() || '';
      const splitBreakdown = `Split: Cash(${this.formatCurrency(splitCash)}) + Card(${this.formatCurrency(splitCard)}) + Transfer(${this.formatCurrency(splitTransfer)})`;
      notes = customNotes ? `${customNotes} | ${splitBreakdown}` : splitBreakdown;
      paymentReference = `SPLIT[C:${splitCash.toFixed(2)},K:${splitCard.toFixed(2)},T:${splitTransfer.toFixed(2)}]`;

    } else if (this.selectedPaymentMethod === 'CREDIT') {
      if (custId === 'cust-walkin') {
        this.showToast('Credit sales require a registered customer! Please select or register a buyer.', 'danger');
        return;
      }
      const depositInput = document.getElementById('credit-deposit-paid');
      const depositPaid = parseFloat(depositInput?.value) || 0;
      amountPaid = depositPaid;
      changeDue = 0;
      const netCreditChange = totalAmount - depositPaid;
      customerObj.balance = Number(customerObj.balance || 0) + netCreditChange;
      await localDB.customers.put(customerObj);

      if (netCreditChange > 0) {
        notes = `Credit Sale. Deposit: ${this.formatCurrency(depositPaid)}. Outstanding Debt Added: ${this.formatCurrency(netCreditChange)}`;
      } else {
        notes = `Credit Sale with Full/Over Deposit: ${this.formatCurrency(depositPaid)}. Balance adjusted by: -${this.formatCurrency(Math.abs(netCreditChange))}`;
      }
    }

    const receiptNumber = 'REC-' + new Date().toISOString().slice(0, 10).replace(/-/g, '') + '-' + Math.floor(1000 + Math.random() * 9000);
    const saleId = 'sale_' + Math.random().toString(36).substring(2, 10);
    const saleDate = new Date().toISOString().slice(0, 19).replace('T', ' ');

    const activeAttendant = this.currentUser ? (this.currentUser.full_name || this.currentUser.username) : 'Store Attendant';

    const salePayload = {
      id: saleId,
      receipt_number: receiptNumber,
      customer_id: custId,
      user_id: this.currentUser ? this.currentUser.id : 1,
      terminal_id: this.terminalId || 'REG-01',
      branch_code: this.branchCode || 'MAIN-01',
      cashier_name: activeAttendant,
      attendant_name: activeAttendant,
      sale_date: saleDate,
      subtotal: subtotal,
      discount: discount,
      tax: Number(this.cartTax || 0),
      total_amount: totalAmount,
      total_cost: totalCost,
      gross_profit: grossProfit,
      payment_method: this.selectedPaymentMethod,
      payment_reference: paymentReference,
      amount_paid: amountPaid,
      change_due: changeDue,
      apply_overpayment_to_account: applyOverpayment,
      loyalty_points_redeemed: Number(this.redeemedLoyaltyPoints || 0),
      // The tab this bill is for, if the party is sitting at one. Sent with the receipt
      // rather than posted to a second endpoint afterwards, so there is one author of the
      // money and one moment at which a table is let go - and so an offline bill carries
      // the link in its own queue row instead of losing it.
      table_order_id: (this.activeTable && this.activeTable.orderId) ? this.activeTable.orderId : null,
      table_seat: (this.activeCheckoutSeat && this.activeCheckoutSeat !== 'ALL') ? this.activeCheckoutSeat : null,
      status: 'COMPLETED',
      notes: notes,
      items: this.cart.map(i => {
        const multiplier = Number(i.multiplier || 1);
        const baseQty = Number(i.quantity || 0) * multiplier;
        const costPrice = Number(i.unit_cost_price || 0);
        const lineSubtotal = Number(i.quantity || 0) * Number(i.selling_price || 0);
        const lineCost = baseQty * costPrice;
        const lineProfit = lineSubtotal - lineCost;

        const itemProdId = i.product_id || i.id;
        return {
          product_id: itemProdId,
          id: itemProdId,
          name: i.name,
          quantity: i.quantity,
          unit: i.selected_unit || i.unit || 'pcs',
          base_unit: i.unit || 'pcs',
          multiplier: multiplier,
          base_quantity: baseQty,
          unit_cost_price: costPrice,
          unit_selling_price: i.selling_price,
          subtotal: lineSubtotal,
          profit: lineProfit,
          seat_number: i.seat_number || 'Shared',
          prep_notes: i.prep_notes || ''
        };
      })
    };

    // 1. Decrement Local Stock in memory & IndexedDB (consolidated & branch)
    const activeBranchCode = (this.branchCode || 'MAIN-01').toUpperCase();
    for (const item of this.cart) {
      const prod = this.products.find(p => p.id === (item.product_id || item.id));
      const baseUnitsDeducted = Number(item.quantity || 0) * Number(item.multiplier || 1);
      if (prod) {
        prod.current_quantity = (prod.current_quantity || 0) - baseUnitsDeducted;
        if (prod.branch_settings && Array.isArray(prod.branch_settings)) {
          let bSetting = prod.branch_settings.find(bs => (bs.branch_code || '').toUpperCase() === activeBranchCode);
          if (bSetting) {
            bSetting.current_quantity = (bSetting.current_quantity || 0) - baseUnitsDeducted;
          } else {
            prod.branch_settings.push({
              branch_code: activeBranchCode,
              product_id: prod.id,
              current_quantity: -baseUnitsDeducted,
              is_available: 1
            });
          }
        }
        await localDB.products.put(prod);
      }
    }

    // 2. Save Sale into Local IndexedDB
    // "synced" means the server holds it. Saying 1 because the cable is plugged in,
    // before the POST has been answered, is how a refused receipt vanishes from the
    // shop's books while the cash has already left the drawer.
    await localDB.sales.put({
      ...salePayload,
      customer_name: customerObj.name,
      synced: 0
    });
    this.sales.unshift({
      ...salePayload,
      customer_name: customerObj.name
    });

    // 3. Online/Offline Sync
    // What the till is allowed to claim about this receipt, decided by the answer.
    let receiptHeld = false;
    let refusalMessage = null;
    let verdict = { verdict: 'unreachable', body: null };
    if (this.isOnline) {
      try {
        const res = await this.apiFetch('api/endpoints/sales.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(salePayload)
        });
        verdict = await this.classifyApiResponse(res);
      } catch (err) {
        verdict = { verdict: 'unreachable' };
      }

      // A receipt the server already has is booked, not refused: the first tap of this button
      // put it on the book, and the queue must not be asked to carry a second copy of a bill
      // that exists. Everything else the server said no to stays on this till.
      const alreadyBooked = verdict.verdict === 'refused' && verdict.body && verdict.body.duplicate === true;
      if (verdict.verdict === 'accepted' || alreadyBooked) {
        // The server's answer carries the money it actually priced - the loyalty figures off the
        // shop's own rates, and the total and change that follow from them. Stamping them onto the
        // till's copy is what lets the printed slip and the sales list show the discount the shop
        // gave rather than the guess the browser made, and it is where the cashier finds out that
        // a redemption was capped to the points the member really holds.
        const priced = verdict.body || {};
        // A duplicate answers with the row already on the book instead of a fresh pricing, so the
        // figures come off that row and the till's copy is made to agree with it.
        const onBook = priced.sale || {};
        const loyalty = priced.loyalty || null;
        const booked = {};
        const newTotal = Number(priced.total_amount || onBook.total_amount || 0);
        if (newTotal > 0) booked.total_amount = newTotal;
        if ((priced.change_due ?? onBook.change_due) !== undefined && (priced.change_due ?? onBook.change_due) !== null) {
          booked.change_due = Number(priced.change_due ?? onBook.change_due);
        }
        if (loyalty) {
          booked.loyalty_discount = Number(loyalty.loyalty_value || 0);
          booked.tier_discount = Number(loyalty.tier_value || 0);
          booked.loyalty_points_earned = Number(loyalty.earned || 0);
          booked.loyalty_points_redeemed = Number(loyalty.redeemed || 0);
        } else if (onBook.loyalty_discount !== undefined || onBook.tier_discount !== undefined) {
          booked.loyalty_discount = Number(onBook.loyalty_discount || 0);
          booked.tier_discount = Number(onBook.tier_discount || 0);
          booked.loyalty_points_earned = Number(onBook.loyalty_points_earned || 0);
          booked.loyalty_points_redeemed = Number(onBook.loyalty_points_redeemed || 0);
        }
        if (Object.keys(booked).length > 0) {
          const tillExpected = Number(salePayload.total_amount || 0);
          Object.assign(salePayload, booked);
          const row = this.sales.find(s => s.id === salePayload.id);
          if (row) Object.assign(row, booked);
          if (alreadyBooked) {
            this.showToast(`Receipt #${receiptNumber} was already on the book at ${this.formatCurrency(booked.total_amount || 0)}. Nothing was taken a second time.`, 'warning', 9000);
          } else if (booked.total_amount && Math.abs(booked.total_amount - tillExpected) > 0.005) {
            this.showToast(`The shop priced this bill at ${this.formatCurrency(booked.total_amount)}.`, 'info');
          }
        }
        try {
          const savedSale = await localDB.sales.get(salePayload.id);
          if (savedSale) {
            savedSale.synced = 1;
            await localDB.sales.put(Object.assign(savedSale, booked));
          }
        } catch (e) { }
        await this.logClientActivity(
          alreadyBooked ? 'SALE_DUPLICATE' : 'SALE_COMPLETED',
          alreadyBooked
            ? `Receipt #${receiptNumber} was rung a second time on this till. The server already had it at ${this.formatCurrency(salePayload.total_amount)}, so nothing was taken again.`
            : `Completed receipt #${receiptNumber} for ${this.formatCurrency(salePayload.total_amount)} (${salePayload.payment_method}). Customer: ${customerObj.name}${salePayload.discount > 0 ? ` (Discount: ${this.formatCurrency(salePayload.discount)})` : ''}`,
          false
        );
      } else {
        // Whether the server refused or nobody answered, the goods have left the shelf
        // and the money has been taken, so the receipt stays on this till and goes back
        // through the outbox. The cashier still hears the difference.
        await localDB.sync_outbox.add({
          entity: 'sale',
          action: 'CREATE',
          data: salePayload,
          timestamp: new Date().toISOString(),
          synced: 0
        });
        if (verdict.verdict === 'refused') {
          receiptHeld = true;
          refusalMessage = verdict.message;
          await this.logClientActivity(
            'SALE_REFUSED',
            `Receipt #${receiptNumber} for ${this.formatCurrency(salePayload.total_amount)} (${salePayload.payment_method}) was refused by the server: ${refusalMessage} Held on this till for retry.`,
            false
          );
        } else {
          await this.logClientActivity(
            'SALE_COMPLETED',
            `Completed offline receipt #${receiptNumber} for ${this.formatCurrency(salePayload.total_amount)} (${salePayload.payment_method}). Customer: ${customerObj.name}${salePayload.discount > 0 ? ` (Discount: ${this.formatCurrency(salePayload.discount)})` : ''}`,
            true
          );
        }
      }
    } else {
      await localDB.sync_outbox.add({
        entity: 'sale',
        action: 'CREATE',
        data: salePayload,
        timestamp: new Date().toISOString(),
        synced: 0
      });
      await this.logClientActivity(
        'SALE_COMPLETED',
        `Completed offline receipt #${receiptNumber} for ${this.formatCurrency(salePayload.total_amount)} (${salePayload.payment_method}). Customer: ${customerObj.name}${salePayload.discount > 0 ? ` (Discount: ${this.formatCurrency(salePayload.discount)})` : ''}`,
        true
      );
    }

    // Always refresh customer directory data
    await this.fetchCustomers();

    const settledSeat = this.activeCheckoutSeat;
    this.activeCheckoutSeat = null;
    const completedItems = [...this.cart];
    if (settledSeat && settledSeat !== 'ALL' && this._originalCart) {
      const rem = this._originalCart.filter(i => (i.seat_number || 'Shared') !== settledSeat);
      this._originalCart = null;
      if (rem.length > 0) {
        this.cart = rem;
        this.showToast(`Settled ${settledSeat}. ${rem.length} item(s) remain on ${this.activeTable ? this.activeTable.number : 'table'}.`, 'success');
      } else {
        this.cart = [];
        if (this.clearActiveTable) this.clearActiveTable();
      }
    } else {
      this._originalCart = null;
      this.cart = [];
      if (this.clearActiveTable) this.clearActiveTable();
    }
    this.cartDiscount = 0;
    this.redeemedLoyaltyPoints = 0;
    // A table is let go by the server, inside the same write as the receipt. This used to post
    // a second, unawaited settle to the floor endpoint afterwards, which freed the table
    // whether or not the bill had been booked - and the module wrote its own receipt to do it,
    // with no cost, no lot, no branch and no stock floor behind it.
    if (this.activeTable) {
      const freedTable = verdict.verdict === 'accepted' ? (verdict.body?.table_released || null) : null;
      if (receiptHeld) {
        // The server said no, the party is still sitting there and the tab is still open, so
        // it stays on this screen: the cashier can fix the cart and ring the bill again.
        this.showToast(`Tab still open on ${this.activeTable.number || 'the table'}: ${refusalMessage}`, 'warning', 9000);
      } else {
        if (freedTable) {
          this.showToast(`Table ${freedTable} settled and released.`, 'success');
        } else if (!this.isOnline) {
          this.showToast('Taken offline - the table releases when this receipt reaches the server.', 'info', 7000);
        }
        this.clearActiveTable();
      }
    }

    this.closeCheckoutModal();
    this.renderCurrentView();
    if (typeof this.broadcastSyncEvent === 'function') {
      this.broadcastSyncEvent('SALE_COMPLETED', { sale: salePayload, items: completedItems });
    }

    // 4. Auto-kick cash drawer for Cash or Split transactions with cash component
    if (this.selectedPaymentMethod === 'CASH' || this.selectedPaymentMethod === 'SPLIT') {
      if (this.isPrinterConnected && this.serialPort) {
        this.kickCashDrawer();
      }
    }

    // Refresh batch catalog in memory & IndexedDB
    if (typeof this.fetchBatches === 'function') {
      this.fetchBatches();
    }

    // If this sale originated from an estimate/quotation, mark it converted
    if (this.activeConvertingEstimateId && typeof this.markEstimateConverted === 'function') {
      this.markEstimateConverted(this.activeConvertingEstimateId, salePayload.id);
      this.activeConvertingEstimateId = null;
    }

    this.showReceiptModal({
      ...salePayload,
      customer_name: customerObj.name,
      customer_phone: customerObj.phone,
      customer_balance: customerObj.balance,
      held_note: receiptHeld ? refusalMessage : null,
      items: completedItems
    });

    if (receiptHeld) {
      // Do not tell a cashier a receipt is filed when the server turned it away - they
      // would hand over the goods and the change and move on to the next customer.
      this.showToast(
        `Receipt #${receiptNumber} was NOT accepted by the server: ${refusalMessage} The sale is held on this till and will be retried at sync. Check the money in the drawer against it.`,
        'danger',
        14000
      );
    } else {
      this.showToast(`Sale recorded successfully! Receipt #${receiptNumber}`, 'success');
    }
  }

  // --- Receipt Modal & Printing ---

  getReceiptTypographyStyles() {
    const prof = this.storeProfile || {};
    const rawFamily = prof.receipt_font_family || 'monospace';
    const rawSize = prof.receipt_font_size || 'medium';
    const rawWeight = prof.receipt_font_weight || 'normal';
    const rawPaper = prof.receipt_paper_width || '80mm';
    const rawSpacing = prof.receipt_spacing || 'ultra_compact';

    const fontFamilies = {
      'monospace': "'Courier New', Courier, monospace",
      'sans': "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
      'retro': "'Lucida Console', Monaco, 'Courier New', monospace",
      'condensed': "'Roboto Mono', Consolas, 'Courier New', monospace"
    };

    const fontSizes = {
      'compact': '0.70rem',
      'medium': '0.80rem',
      'large': '0.90rem'
    };

    const fontWeights = {
      'normal': '400',
      'medium': '600',
      'bold': '700'
    };

    const maxWidths = {
      '58mm': '220px',
      '80mm': '100%'
    };

    const spacingModes = ['ultra_compact', 'compact', 'standard'];

    // Resolve every setting through its own table before it is used. These values
    // are stored text the owner can type, and both `classes` and `cssText` below
    // are interpolated into class="..." and style="..." - places no escaping makes
    // safe. An unrecognised setting falls back to the default instead of reaching
    // the markup, so a crafted receipt_paper_width becomes a cosmetic downgrade
    // rather than a script that runs whenever anyone prints a receipt.
    const fontFamily = fontFamilies[rawFamily] ? rawFamily : 'monospace';
    const fontSize = fontSizes[rawSize] ? rawSize : 'medium';
    const fontWeight = fontWeights[rawWeight] ? rawWeight : 'normal';
    const paperWidth = maxWidths[rawPaper] ? rawPaper : '80mm';
    const spacing = spacingModes.includes(rawSpacing) ? rawSpacing : 'ultra_compact';

    return {
      paperWidth,
      fontFamily,
      fontSize,
      fontWeight,
      spacing,
      cssText: `font-family: ${fontFamilies[fontFamily] || fontFamilies.monospace}; font-size: ${fontSizes[fontSize] || '0.80rem'}; font-weight: ${fontWeights[fontWeight] || '400'}; max-width: ${maxWidths[paperWidth] || '100%'};`,
      classes: `receipt-roll-${paperWidth} receipt-font-${fontSize} receipt-weight-${fontWeight} receipt-spacing-${spacing}`
    };
  }

  showReceiptModal(saleData) {
    const modal = document.getElementById('receipt-modal');
    const container = document.getElementById('printable-receipt-area');
    if (!modal || !container) return;

    this.currentSaleForReceipt = saleData;
    this.currentPaymentReceipt = null;
    this.currentReturnForReceipt = null;
    const isVoided = this.isVoidedSale(saleData);
    const retBtn = document.getElementById('receipt-btn-return');
    if (retBtn) retBtn.style.display = isVoided ? 'none' : 'inline-flex';
    // The slip's Void door uses the ledger's own rules, so a receipt cannot be voided from the
    // print screen when the same row would have refused it in the sales table.
    const voidBtn = document.getElementById('receipt-btn-void');
    if (voidBtn) {
      voidBtn.style.display = (typeof this.canVoidSale === 'function' && this.canVoidSale(saleData))
        ? 'inline-flex' : 'none';
    }

    const prof = this.storeProfile;
    const isCredit = (saleData.payment_method || '').toUpperCase() === 'CREDIT';
    const totalAmt = Number(saleData.total_amount || 0);
    const paidAmt = Number(saleData.amount_paid || 0);
    const remainingDebtOnSale = Math.max(0, totalAmt - paidAmt);
    const attendantName = saleData.attendant_name || saleData.cashier_name || (this.currentUser ? (this.currentUser.full_name || this.currentUser.username) : 'Store Attendant');
    const typo = this.getReceiptTypographyStyles();

    container.innerHTML = `
      <div class="receipt-wrapper ${typo.classes}" style="${typo.cssText}">
        ${saleData.held_note ? `
          <div style="border: 2px solid #b91c1c; background: #fef2f2; color: #7f1d1d; padding: 0.5rem 0.6rem; margin-bottom: 0.6rem; font-weight: 700; font-size: 0.78rem; line-height: 1.35; text-align: left;">
            <div style="font-size: 0.86rem; letter-spacing: 0.04em;">&times; THIS SALE WAS NOT RECORDED BY THE SERVER</div>
            <div style="font-weight: 600;">${this.escapeHtml(String(saleData.held_note))}</div>
            <div style="font-weight: 600;">The till is holding it and will retry at sync. Count the drawer against this slip before the goods leave, and do not book it as takings until it clears.</div>
          </div>
        ` : ''}
        ${isVoided ? `
          <div style="border: 2px solid #b91c1c; background: #fef2f2; color: #7f1d1d; padding: 0.5rem 0.6rem; margin-bottom: 0.6rem; font-weight: 700; font-size: 0.78rem; line-height: 1.35; text-align: left;">
            <div style="font-size: 0.86rem; letter-spacing: 0.04em;">&times; VOIDED &mdash; THIS SLIP IS NOT PROOF OF PURCHASE</div>
            <div style="font-weight: 600;">Reason: ${this.escapeHtml(String(saleData.void_reason || 'No reason recorded'))}</div>
            <div style="font-weight: 600;">Voided ${this.escapeHtml(String(saleData.voided_at || 'today'))}${saleData.void_user_name ? ` by ${this.escapeHtml(String(saleData.void_user_name))}` : ''}</div>
            <div style="font-weight: 600;">The goods are back on the shelf and this receipt booked nothing. It is kept on the book for the audit trail and counts as ${this.formatCurrency(0)} of revenue and ${this.formatCurrency(0)} of tax at the shift count.</div>
          </div>
        ` : ''}
        <div class="receipt-header-center">
          ${this.shouldPrintReceiptLogo() ? `<img src="${this.escapeHtml(this.getStoreLogo())}" alt="Logo" class="receipt-logo">` : ''}
          <h3>${this.escapeHtml(prof.store_name)}</h3>
          ${prof.tagline ? `<p style="font-size: 0.76rem; margin: 0.1rem 0;">${this.escapeHtml(prof.tagline)}</p>` : ''}
          ${prof.address ? `<p style="font-size: 0.72rem; margin: 0.05rem 0;">${this.escapeHtml(prof.address)}</p>` : ''}
          ${(prof.phone || (prof.show_tax_on_receipt !== 0 && prof.tax_number)) ? `
            <p style="font-size: 0.72rem; margin: 0.05rem 0;">${prof.phone ? `Tel: ${this.escapeHtml(prof.phone)}` : ''}${prof.show_tax_on_receipt !== 0 && prof.tax_number ? ` | Tax ID: ${this.escapeHtml(prof.tax_number)}` : ''}</p>
          ` : ''}
          ${prof.receipt_header ? `
            <div class="receipt-divider"></div>
            <p style="font-size: 0.72rem; font-style: italic; margin: 0.1rem 0;">${this.escapeHtml(prof.receipt_header)}</p>
          ` : ''}
        </div>

        <div class="receipt-divider"></div>

        <div class="receipt-meta-block" style="font-size: 0.73rem; margin-bottom: 0.35rem; line-height: 1.35;">
          <div style="display: flex; justify-content: space-between; gap: 0.4rem;">
            <span><strong>Rec #:</strong> ${this.escapeHtml(saleData.receipt_number)}</span>
            <span>${this.escapeHtml(saleData.sale_date)}</span>
          </div>
          <div style="display: flex; justify-content: space-between; gap: 0.4rem;">
            ${prof.show_cashier_on_receipt !== 0 ? `<span><strong>Attendant:</strong> ${this.escapeHtml(attendantName)}</span>` : '<span></span>'}
            <span><strong>Pay:</strong> ${this.escapeHtml(saleData.payment_method)}${isCredit ? ' (CREDIT)' : ''}</span>
          </div>
          ${(saleData.customer_name && !['walk-in', 'walk-in customer'].includes(saleData.customer_name.trim().toLowerCase())) ? `
            <div style="display: flex; justify-content: space-between; gap: 0.4rem;">
              <span><strong>Customer:</strong> ${this.escapeHtml(saleData.customer_name)}</span>
              ${saleData.terminal_id ? `<span style="color: #64748b; font-size: 0.68rem;">Term: ${this.escapeHtml(saleData.terminal_id)}</span>` : ''}
            </div>
          ` : (saleData.terminal_id && saleData.terminal_id !== 'REG-01' ? `
            <div style="color: #64748b; font-size: 0.68rem;"><strong>Terminal:</strong> ${this.escapeHtml(saleData.terminal_id)}</div>
          ` : '')}
          ${saleData.payment_reference ? `<div><strong>Ref:</strong> ${this.escapeHtml(saleData.payment_reference)}</div>` : ''}
        </div>

        <div class="receipt-divider"></div>

        <table class="receipt-table">
          <thead>
            <tr>
              <th style="width: 38%; text-align: left;">Item</th>
              <th style="text-align: center; width: 12%;">Qty</th>
              <th style="text-align: right; width: 25%;">Price</th>
              <th style="text-align: right; width: 25%;">Total</th>
            </tr>
          </thead>
          <tbody>
            ${saleData.items.map(it => {
              const unitLabel = it.unit || 'pcs';
              const isPackItem = it.multiplier && Number(it.multiplier) > 1;
              return `
              <tr>
                <td style="word-break: break-word; padding-right: 0.35rem;">
                  ${this.escapeHtml(it.name || it.product_name || 'Item')}
                  ${it.combo_items && it.combo_items.length > 0 ? `
                    <div style="font-size: 0.68rem; color: #475569; font-style: italic;">
                      Includes: ${it.combo_items.map(ci => `${ci.quantity}x ${ci.component_name || 'Item'}`).join(', ')}
                    </div>
                  ` : ''}
                  ${isPackItem ? `
                    <div style="font-size: 0.70rem; color: #475569; font-weight: 600;">
                      [${this.escapeHtml(unitLabel.toUpperCase())} × ${it.multiplier}${this.escapeHtml(it.base_unit ? ' ' + it.base_unit : '')}]
                    </div>
                  ` : ''}
                  ${it.batch_number ? `
                    <div style="font-size: 0.68rem; color: #64748b; font-family: monospace; font-weight: normal;">
                      Lot: ${this.escapeHtml(it.batch_number)}${it.expiry_date ? ` · Exp: ${this.escapeHtml(it.expiry_date)}` : ''}
                    </div>
                  ` : ''}
                </td>
                <td style="text-align: center;">${it.quantity} <span style="font-size: 0.70rem; color: #64748b;">${this.escapeHtml(unitLabel)}</span></td>
                <td style="text-align: right; white-space: nowrap; padding-right: 0.2rem;">${this.formatCurrency(it.selling_price || it.unit_selling_price)}</td>
                <td style="text-align: right; white-space: nowrap;">${this.formatCurrency(it.quantity * (it.selling_price || it.unit_selling_price))}</td>
              </tr>
            `;
            }).join('')}
          </tbody>
        </table>

        <div class="receipt-divider"></div>

        <div style="font-size: 0.8rem; line-height: 1.55;">
          <div style="display: flex; justify-content: space-between;">
            <span>Subtotal:</span>
            <span>${this.formatCurrency(saleData.subtotal)}</span>
          </div>
          ${saleData.discount > 0 ? `
            <div style="display: flex; justify-content: space-between;">
              <span>Discount:</span>
              <span>-${this.formatCurrency(saleData.discount)}</span>
            </div>
          ` : ''}
          ${Number(saleData.loyalty_discount || 0) > 0 ? `
            <div style="display: flex; justify-content: space-between;">
              <span>Points redeemed${Number(saleData.loyalty_points_redeemed || 0) > 0 ? ` (${Number(saleData.loyalty_points_redeemed).toLocaleString()} pts)` : ''}:</span>
              <span>-${this.formatCurrency(Number(saleData.loyalty_discount))}</span>
            </div>
          ` : ''}
          ${Number(saleData.tier_discount || 0) > 0 ? `
            <div style="display: flex; justify-content: space-between;">
              <span>${this.escapeHtml(String(saleData.loyalty_tier || '').toUpperCase() || 'Member')} perk:</span>
              <span>-${this.formatCurrency(Number(saleData.tier_discount))}</span>
            </div>
          ` : ''}
          ${saleData.tax > 0 ? `
            <div style="display: flex; justify-content: space-between;">
              <span>Tax / VAT${isVoided ? ' (not charged)' : ''}:</span>
              <span style="${isVoided ? 'text-decoration: line-through; color: #b91c1c;' : ''}">+${this.formatCurrency(saleData.tax)}</span>
            </div>
          ` : ''}

          <div style="display: flex; justify-content: space-between; font-weight: bold; font-size: 0.95rem; margin-top: 0.35rem; border-top: 1px dashed #000; border-bottom: 1px dashed #000; padding: 0.35rem 0;">
            <span>${isVoided ? 'TOTAL RINGED (VOID):' : 'TOTAL BILL:'}</span>
            <span style="${isVoided ? 'text-decoration: line-through; color: #b91c1c;' : ''}">${this.formatCurrency(totalAmt)}</span>
          </div>
          ${isVoided ? `
            <div style="display: flex; justify-content: space-between; font-weight: 800; font-size: 0.95rem; color: #b91c1c; padding: 0.3rem 0;">
              <span>MONEY TAKEN:</span>
              <span>${this.formatCurrency(0)}</span>
            </div>
          ` : ''}

          ${isVoided ? (isCredit ? `
            <div style="font-size: 0.72rem; color: #991b1b; margin-top: 0.25rem; line-height: 1.4;">
              The credit on this sale was taken back off the account when it was voided. Nothing is owed from it.
            </div>
          ` : '') : isCredit ? `
            <div style="display: flex; justify-content: space-between; margin-top: 0.35rem;">
              <span>Deposit Paid:</span>
              <span>${this.formatCurrency(paidAmt)}</span>
            </div>
            <div style="display: flex; justify-content: space-between; font-weight: 700; color: #b91c1c;">
              <span>Credit Due (This Sale):</span>
              <span>${this.formatCurrency(remainingDebtOnSale)}</span>
            </div>
            ${saleData.customer_balance !== undefined && Number(saleData.customer_balance) > 0 ? `
              <div style="display: flex; justify-content: space-between; margin-top: 0.35rem; font-weight: 700; background: #fee2e2; padding: 0.25rem 0.4rem; border-radius: 3px; color: #991b1b; border: 1px solid #fecaca;">
                <span>Total Outstanding Debt:</span>
                <span>${this.formatCurrency(saleData.customer_balance)}</span>
              </div>
            ` : ''}
          ` : `
            <div style="display: flex; justify-content: space-between; margin-top: 0.35rem;">
              <span>Amount Paid:</span>
              <span>${this.formatCurrency(paidAmt)}</span>
            </div>
            <div style="display: flex; justify-content: space-between;">
              <span>Change Due:</span>
              <span>${this.formatCurrency(saleData.change_due)}</span>
            </div>
          `}
        </div>

        <div class="receipt-divider"></div>

        ${prof.receipt_momo_note && !isVoided ? `
          <div style="text-align: center; font-size: 0.70rem; background: #f8fafc; border: 1px dashed #cbd5e1; padding: 0.25rem 0.4rem; margin: 0.25rem 0; border-radius: 3px; color: #334155;">
            <strong>Payment Instructions:</strong> ${this.escapeHtml(prof.receipt_momo_note)}
          </div>
        ` : ''}

        <div style="text-align: center; font-size: 0.72rem; margin-top: 0.2rem; padding-bottom: 1mm;">
          ${isVoided
            ? `<p style="font-weight: 800; color: #b91c1c; letter-spacing: 0.05em; margin: 0;">THIS RECEIPT WAS VOIDED - ${this.escapeHtml(String(saleData.void_reason || 'NO REASON RECORDED').toUpperCase())}</p>`
            : `<p style="margin: 0;">${this.escapeHtml(prof.receipt_footer || 'Thank you for your business!')}</p>`}
        </div>
      </div>
    `;

    modal.classList.add('active');
  }

  closeReceiptModal() {
    const modal = document.getElementById('receipt-modal');
    if (modal) modal.classList.remove('active');
  }

  async printReceipt() {
    if (this.isPrinterConnected && this.serialPort && this.currentSaleForReceipt) {
      try {
        const rawData = this.encodeEscPosReceipt(this.currentSaleForReceipt);
        await this.sendRawToPrinter(rawData);
        this.showToast('Receipt printed directly to thermal printer.', 'success');
        return;
      } catch (err) {
        console.warn('Direct thermal print error, falling back to browser print:', err);
        this.showToast('Direct thermal print failed. Falling back to browser print.', 'warning');
      }
    }
    window.print();
  }

  // --- Products Catalog ---

  getProductsHTML() {
    const isCashier = this.isCashier();

    return `
      <div class="panel">
        <div class="panel-header">
          <h3><i class="fa-solid fa-boxes-stacked"></i> Products Catalog</h3>
          <div style="display: flex; gap: 0.5rem; align-items: center; flex-wrap: wrap;">
            <button class="btn btn-outline" onclick="app.openBarcodeLabelModal()" title="Open Barcode & Shelf Label Printing Studio">
              <i class="fa-solid fa-tags"></i> Print Barcodes / Labels
            </button>
            ${!isCashier ? `
              <button class="btn btn-primary" onclick="app.openNewProductModal()">
                <i class="fa-solid fa-plus"></i> Add New Product
              </button>
            ` : ''}
          </div>
        </div>
        <div class="panel-body">
          <div style="display: flex; gap: 1rem; margin-bottom: 1.25rem; flex-wrap: wrap;">
            <input type="text" id="products-search-input" class="form-control" placeholder="Search by name, SKU, or barcode..." style="max-width: 320px;">
            <select id="products-cat-filter" class="form-control" style="max-width: 200px;">
              <option value="All">All Categories</option>
              ${this.categories.map(c => `<option value="${this.escapeHtml(c)}">${this.escapeHtml(c)}</option>`).join('')}
            </select>
          </div>

          <div class="table-responsive">
            <table class="data-table" id="products-table">
              <thead>
                <tr>
                  <th style="width: 50px;">Photo</th>
                  <th>Product Name</th>
                  <th>SKU / Barcode</th>
                  <th>Category</th>
                  ${!isCashier ? '<th>Factory Cost</th>' : ''}
                  <th>Selling Price</th>
                  ${!isCashier ? '<th>Margin</th>' : ''}
                  <th>Stock on Hand</th>
                  ${!isCashier ? '<th>Actions</th>' : ''}
                </tr>
              </thead>
              <tbody id="products-table-body">
                ${this.products.map(p => {
      const cost = Number(p.cost_price || 0);
      const price = Number(p.selling_price || 0);
      const margin = price - cost;
      const marginPercent = cost > 0 ? Math.round((margin / cost) * 100) : 100;
      const stock = Number(p.current_quantity || 0);
      const isOut = stock <= 0;
      const isLow = stock > 0 && stock <= Number(p.min_stock_alert || 5);
      const imgUrl = p.image_url || 'assets/images/products/placeholder.svg';

      return `
                    <tr data-name="${this.escapeHtml(p.name || '')}" data-sku="${this.escapeHtml(p.sku || '')}" data-barcode="${this.escapeHtml(p.barcode || '')}">
                      <td>
                        <img src="${this.escapeHtml(imgUrl)}" class="table-img-thumb" style="cursor: pointer;" onclick="app.openProductDetailModal(${this.jsStr(p.id)})" title="Click to view details" alt="${this.escapeHtml(p.name)}" onerror="this.src='assets/images/products/placeholder.svg'">
                      </td>
                      <td style="font-weight: 600; cursor: pointer; color: var(--primary);" onclick="app.openProductDetailModal(${this.jsStr(p.id)})" title="Click to view details">
                        ${this.escapeHtml(p.name)}
                      </td>
                      <td>
                        <div style="font-family: monospace; font-weight: 600;">${this.escapeHtml(p.sku || 'N/A')}</div>
                        ${p.barcode ? `<div style="font-size: 0.78rem; color: var(--slate-600); font-family: monospace; margin-top: 2px;"><i class="fa-solid fa-barcode" style="color: var(--primary);"></i> ${this.escapeHtml(p.barcode)}</div>` : '<div style="font-size: 0.72rem; color: var(--slate-400); font-style: italic;">No barcode</div>'}
                      </td>
                      <td><span class="badge badge-neutral">${this.escapeHtml(p.category || 'General')}</span></td>
                      ${!isCashier ? `<td>${this.formatCurrency(cost)}</td>` : ''}
                      <td style="font-weight: 700; color: var(--primary);">${this.formatCurrency(price)}</td>
                      ${!isCashier ? `<td style="color: var(--success); font-weight: 600;">+${this.formatCurrency(margin)} (${marginPercent}%)</td>` : ''}
                      <td>
                        <span class="badge ${isOut ? 'badge-danger' : (isLow ? 'badge-warning' : 'badge-success')}">
                          ${stock} ${this.escapeHtml(p.unit || 'pcs')}
                        </span>
                      </td>
                      ${!isCashier ? `
                        <td>
                          <div style="display: flex; gap: 0.35rem;">
                            <button class="btn btn-outline btn-sm" onclick="app.openProductDetailModal(${this.jsStr(p.id)})" title="View Product Details">
                              <i class="fa-solid fa-eye"></i>
                            </button>
                            <button class="btn btn-outline btn-sm" onclick="app.openBarcodeLabelModal(${this.jsStr(p.id)})" title="Print Barcode Labels">
                              <i class="fa-solid fa-barcode"></i>
                            </button>
                            <button class="btn btn-outline btn-sm" onclick="app.editProduct(${this.jsStr(p.id)})" title="Edit Product">
                              <i class="fa-solid fa-pen-to-square"></i> Edit
                            </button>
                            <button class="btn btn-outline btn-sm" onclick="app.confirmDeleteProduct(${this.jsStr(p.id)}, ${this.jsStr(p.name)})" style="color: var(--danger); border-color: var(--danger-border);" title="Delete Product">
                              <i class="fa-solid fa-trash"></i>
                            </button>
                          </div>
                        </td>
                      ` : ''}
                    </tr>
                  `;
    }).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  }

  bindProductsEvents() {
    const searchInput = document.getElementById('products-search-input');
    const catSelect = document.getElementById('products-cat-filter');

    const filterTable = () => {
      const rawQ = (searchInput?.value || '').trim().toLowerCase();
      const compactQ = rawQ.replace(/[\s\-_]/g, '');
      const cat = catSelect?.value || 'All';
      const rows = document.querySelectorAll('#products-table-body tr');

      rows.forEach(r => {
        const text = r.innerText.toLowerCase();
        const barcode = (r.getAttribute('data-barcode') || '').toLowerCase();
        const barcodeCompact = barcode.replace(/[\s\-_]/g, '');
        const sku = (r.getAttribute('data-sku') || '').toLowerCase();
        const skuCompact = sku.replace(/[\s\-_]/g, '');
        const name = (r.getAttribute('data-name') || '').toLowerCase();

        const matchesQuery = !rawQ ||
          text.includes(rawQ) ||
          (compactQ && barcodeCompact.includes(compactQ)) ||
          (compactQ && skuCompact.includes(compactQ)) ||
          barcode.includes(rawQ) ||
          sku.includes(rawQ) ||
          name.includes(rawQ);

        const matchesCat = cat === 'All' || text.includes(cat.toLowerCase());
        r.style.display = (matchesQuery && matchesCat) ? '' : 'none';
      });
    };

    if (searchInput) searchInput.addEventListener('input', filterTable);
    if (catSelect) catSelect.addEventListener('change', filterTable);

    // Image Upload Listener for Product Form
    const imgFileInput = document.getElementById('prod-form-image-file');
    if (imgFileInput) {
      imgFileInput.onchange = (e) => {
        const file = e.target.files[0];
        if (file) {
          const reader = new FileReader();
          reader.onload = (event) => {
            const dataUrl = event.target.result;
            document.getElementById('prod-form-image-preview').src = dataUrl;
            document.getElementById('prod-form-image-url').value = dataUrl;
          };
          reader.readAsDataURL(file);
        }
      };
    }
  }

  openNewProductModal() {
    document.getElementById('product-modal-title').innerText = 'Add New Product';
    document.getElementById('prod-form-id').value = '';
    document.getElementById('prod-form-name').value = '';
    document.getElementById('prod-form-sku').value = '';
    document.getElementById('prod-form-barcode').value = '';
    document.getElementById('prod-form-category').value = 'General';
    document.getElementById('prod-form-unit').value = 'pcs';
    document.getElementById('prod-form-cost').value = '0.00';
    document.getElementById('prod-form-price').value = '0.00';
    document.getElementById('prod-form-stock').value = '0';
    document.getElementById('prod-form-stock-group').style.display = 'block';
    document.getElementById('prod-form-min-alert').value = '5';
    document.getElementById('prod-form-location').value = 'Main Storefront';
    document.getElementById('prod-form-image-url').value = 'assets/images/products/placeholder.svg';
    document.getElementById('prod-form-image-preview').src = 'assets/images/products/placeholder.svg';

    this.renderProductModalBranchRows(null);
    document.getElementById('product-modal').classList.add('active');
  }

  editProduct(productId) {
    const p = this.products.find(item => item.id === productId);
    if (!p) return;

    document.getElementById('product-modal-title').innerText = 'Edit Product';
    document.getElementById('prod-form-id').value = p.id;
    document.getElementById('prod-form-name').value = p.name;
    document.getElementById('prod-form-sku').value = p.sku || '';
    document.getElementById('prod-form-barcode').value = p.barcode || '';
    document.getElementById('prod-form-category').value = p.category || 'General';
    document.getElementById('prod-form-unit').value = p.unit || 'pcs';
    document.getElementById('prod-form-cost').value = p.cost_price || 0;
    document.getElementById('prod-form-price').value = p.selling_price || 0;
    document.getElementById('prod-form-stock-group').style.display = 'none';
    document.getElementById('prod-form-min-alert').value = p.min_stock_alert || 5;
    document.getElementById('prod-form-location').value = p.location || 'Main Storefront';

    const img = p.image_url || 'assets/images/products/placeholder.svg';
    document.getElementById('prod-form-image-url').value = img;
    document.getElementById('prod-form-image-preview').src = img;

    this.renderProductModalBranchRows(p);
    document.getElementById('product-modal').classList.add('active');
  }

  renderProductModalBranchRows(product = null) {
    const section = document.getElementById('prod-form-branch-section');
    const tbody = document.getElementById('prod-form-branch-tbody');
    const stockGroup = document.getElementById('prod-form-stock-group');

    if (!section || !tbody) return;

    if (!this.isMultiBranch) {
      section.style.display = 'none';
      if (stockGroup) stockGroup.style.display = product ? 'none' : 'block';
      return;
    }

    section.style.display = 'block';
    if (stockGroup) stockGroup.style.display = 'none'; // In multi-branch, stock is allocated per branch

    const branchList = this.branches && this.branches.length > 0 ? this.branches : [{ branch_code: 'MAIN-01', name: 'Main Storefront' }];
    const settingsMap = {};
    if (product && product.branch_settings) {
      product.branch_settings.forEach(b => {
        settingsMap[(b.branch_code || '').toUpperCase()] = b;
      });
    }

    tbody.innerHTML = branchList.map(b => {
      const code = (b.branch_code || 'MAIN-01').toUpperCase();
      const existing = settingsMap[code];
      const stock = existing ? Number(existing.current_quantity || 0) : (product && code === 'MAIN-01' ? Number(product.current_quantity || 0) : 0);
      const customPrice = (existing && existing.custom_selling_price !== null && existing.custom_selling_price !== undefined) ? existing.custom_selling_price : '';
      const isAvail = existing ? (existing.is_available !== 0) : true;

      return `
        <tr data-branch-code="${this.escapeHtml(code)}">
          <td>
            <div style="font-weight: 700; color: var(--slate-900); font-size: 0.85rem;">${this.escapeHtml(b.name)}</div>
            <span style="font-size: 0.72rem; color: var(--slate-500); font-family: monospace;">${this.escapeHtml(code)}</span>
          </td>
          <td>
            <input type="number" class="form-control prod-branch-stock" data-branch="${this.escapeHtml(code)}" value="${stock}" min="0" style="padding: 0.25rem 0.5rem; font-size: 0.85rem; font-weight: 700;">
          </td>
          <td>
            <input type="number" class="form-control prod-branch-price" data-branch="${this.escapeHtml(code)}" value="${customPrice}" step="any" placeholder="Default" style="padding: 0.25rem 0.5rem; font-size: 0.85rem;">
          </td>
          <td style="text-align: center;">
            <input type="checkbox" class="prod-branch-avail" data-branch="${this.escapeHtml(code)}" ${isAvail ? 'checked' : ''} style="width: 18px; height: 18px; cursor: pointer;">
          </td>
        </tr>
      `;
    }).join('');
    this.applyMobileTableLabels(tbody.closest('table') || tbody);
  }

  closeProductModal() {
    document.getElementById('product-modal').classList.remove('active');
  }

  async saveProductForm() {
    const id = document.getElementById('prod-form-id').value || ('prod_' + Math.random().toString(36).substring(2, 10));
    const isEdit = Boolean(document.getElementById('prod-form-id').value);
    const name = document.getElementById('prod-form-name').value.trim();
    if (!name) {
      this.showToast('Product name is required.', 'warning');
      return;
    }

    let sku = document.getElementById('prod-form-sku').value.trim();
    if (!sku) {
      if (isEdit) {
        const existingProd = this.products.find(p => p.id === id);
        sku = existingProd?.sku || '';
      }
      if (!sku) {
        const cleanName = name.replace(/[^a-zA-Z0-9]/g, '').substring(0, 4).toUpperCase() || 'PROD';
        sku = 'SKU-' + cleanName + '-' + Math.floor(100 + Math.random() * 900);
      }
    }

    const hasExpiry = document.getElementById('prod-form-has-expiry')?.checked ? 1 : 0;
    const batchNumber = (document.getElementById('prod-form-batch-no')?.value || '').trim();
    const expiryDate = (document.getElementById('prod-form-expiry-date')?.value || '').trim() || null;
    const mfgDate = (document.getElementById('prod-form-mfg-date')?.value || '').trim() || null;
    const alertBeforeDays = parseInt(document.getElementById('prod-form-alert-days')?.value) || 30;

    const hasPack = document.getElementById('prod-form-has-pack')?.checked;
    const packUnit = hasPack ? (document.getElementById('prod-form-pack-unit')?.value || '').trim() : '';
    const packSize = hasPack ? Math.max(1, parseFloat(document.getElementById('prod-form-pack-size')?.value) || 1) : 1;
    const packPrice = hasPack ? (parseFloat(document.getElementById('prod-form-pack-price')?.value) || 0) : 0;

    const payload = {
      id: id,
      name: name,
      sku: sku,
      barcode: document.getElementById('prod-form-barcode').value.trim(),
      category: document.getElementById('prod-form-category').value.trim() || 'General',
      unit: document.getElementById('prod-form-unit').value.trim() || 'pcs',
      cost_price: parseFloat(document.getElementById('prod-form-cost').value) || 0,
      selling_price: parseFloat(document.getElementById('prod-form-price').value) || 0,
      initial_stock: parseFloat(document.getElementById('prod-form-stock').value) || 0,
      min_stock_alert: parseInt(document.getElementById('prod-form-min-alert').value) || 5,
      location: document.getElementById('prod-form-location').value.trim() || 'Main Storefront',
      image_url: document.getElementById('prod-form-image-url').value || 'assets/images/products/placeholder.svg',
      has_expiry: hasExpiry,
      batch_number: batchNumber,
      expiry_date: expiryDate,
      mfg_date: mfgDate,
      alert_before_days: alertBeforeDays,
      pack_unit: packUnit,
      pack_size: packSize,
      pack_price: packPrice
    };

    if (this.isMultiBranch) {
      const branchSettings = [];
      let totalStock = 0;
      document.querySelectorAll('#prod-form-branch-tbody tr').forEach(row => {
        const bCode = row.getAttribute('data-branch-code');
        const stock = parseFloat(row.querySelector('.prod-branch-stock')?.value) || 0;
        const customPriceVal = row.querySelector('.prod-branch-price')?.value;
        const customPrice = (customPriceVal !== '' && customPriceVal !== null && !isNaN(parseFloat(customPriceVal))) ? parseFloat(customPriceVal) : null;
        const isAvail = row.querySelector('.prod-branch-avail')?.checked ? 1 : 0;
        branchSettings.push({
          branch_code: bCode,
          current_quantity: stock,
          custom_selling_price: customPrice,
          is_available: isAvail
        });
        totalStock += stock;
      });
      payload.branch_settings = branchSettings;
      payload.current_quantity = totalStock;
    }

    if (isEdit) {
      const idx = this.products.findIndex(p => p.id === id);
      if (idx >= 0) {
        this.products[idx] = { ...this.products[idx], ...payload };
        await localDB.products.put(this.products[idx]);
      }
    } else {
      payload.current_quantity = this.isMultiBranch ? payload.current_quantity : payload.initial_stock;
      this.products.push(payload);
      await localDB.products.put(payload);
    }

    if (this.isOnline) {
      try {
        const res = await this.apiFetch('api/endpoints/products.php', {
          method: isEdit ? 'PUT' : 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        const resData = await res.json().catch(() => null);
        if (!res.ok || (resData && resData.success === false)) {
          throw new Error(resData?.message || 'Server error saving product');
        }
        await this.fetchProducts();
        await this.fetchInventory();
      } catch (err) {
        console.warn('Backend product save notice:', err.message);
        await localDB.sync_outbox.add({
          entity: 'product',
          action: isEdit ? 'UPDATE' : 'CREATE',
          data: payload,
          timestamp: new Date().toISOString(),
          synced: 0
        });
      }
    } else {
      await localDB.sync_outbox.add({
        entity: 'product',
        action: isEdit ? 'UPDATE' : 'CREATE',
        data: payload,
        timestamp: new Date().toISOString(),
        synced: 0
      });
    }

    this.closeProductModal();
    this.renderCurrentView();
    this.showToast('Product saved successfully!', 'success');
  }

  // --- Factory Purchases (Stock In) ---

  getPurchasesHTML() {
    return `
      <div class="panel">
        <div class="panel-header">
          <h3><i class="fa-solid fa-truck-ramp-box"></i> Factory Purchase Orders (Stock In)</h3>
          <button class="btn btn-success" onclick="app.openNewPurchaseModal()">
            <i class="fa-solid fa-plus"></i> Record Factory Purchase
          </button>
        </div>
        <div class="panel-body">
          <p style="font-size: 0.85rem; color: var(--slate-600); margin-bottom: 1.25rem;">
            When the store owner goes to the factory to purchase items at cost price, record them here to automatically stock your inventory.
          </p>

          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Order #</th>
                  <th>Factory / Supplier</th>
                  <th>Purchase Date</th>
                  <th>Products Purchased</th>
                  <th>Total Cost</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                ${this.purchases.length > 0 ? this.purchases.map(p => `
                  <tr>
                    <td style="font-weight: 600; font-family: monospace;">${this.escapeHtml(p.order_number)}</td>
                    <td style="font-weight: 600;">${this.escapeHtml(p.supplier_name)}</td>
                    <td>${this.escapeHtml(p.order_date)}</td>
                    <td>${p.total_products_count || (p.items ? p.items.length : 1)} products</td>
                    <td style="font-weight: 700; color: var(--slate-900);">${this.formatCurrency(p.total_cost)}</td>
                    <td>
                      <span class="badge badge-success"><i class="fa-solid fa-check"></i> Stocked</span>
                      ${p.payment_status === 'CREDIT' ? `<span class="badge badge-danger" style="margin-left: 0.25rem;"><i class="fa-solid fa-clock"></i> Credit</span>` : (p.payment_status === 'PARTIAL' ? `<span class="badge badge-warning" style="margin-left: 0.25rem;"><i class="fa-solid fa-clock-rotate-left"></i> Partial</span>` : `<span class="badge badge-success" style="margin-left: 0.25rem;"><i class="fa-solid fa-circle-check"></i> Paid</span>`)}
                    </td>
                  </tr>
                `).join('') : `
                  <tr>
                    <td colspan="6" style="text-align: center; padding: 3rem; color: var(--slate-400);">
                      <i class="fa-solid fa-truck-ramp-box" style="font-size: 2rem; margin-bottom: 0.5rem; display: block;"></i>
                      No factory purchase orders recorded yet.
                    </td>
                  </tr>
                `}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  }

  bindPurchasesEvents() { }

  openNewPurchaseModal(preselectedProductId = null) {
    const vendorSelect = document.getElementById('purchase-vendor-select');
    if (vendorSelect) {
      vendorSelect.innerHTML = `
        <option value="">-- Select Registered Vendor or Type Name --</option>
        ${this.vendors.map(v => `
          <option value="${this.escapeHtml(v.id)}">${this.escapeHtml(v.name)} ${Number(v.balance || 0) > 0 ? `(Owed: ${this.formatCurrency(v.balance)})` : ''}</option>
        `).join('')}
        <option value="__custom__">+ Enter Custom Factory / One-Off Supplier</option>
      `;
      vendorSelect.value = '';
    }
    const customGrp = document.getElementById('grp-purchase-supplier-custom');
    if (customGrp) customGrp.style.display = 'none';

    const supNameInput = document.getElementById('purchase-supplier-name');
    if (supNameInput) supNameInput.value = '';

    const supContact = document.getElementById('purchase-supplier-contact');
    if (supContact) supContact.value = '';

    const payStatus = document.getElementById('purchase-payment-status');
    if (payStatus) payStatus.value = 'PAID';

    const partRow = document.getElementById('purchase-partial-row');
    if (partRow) partRow.style.display = 'none';

    const amtPaidInput = document.getElementById('purchase-amount-paid');
    if (amtPaidInput) amtPaidInput.value = '0.00';

    document.getElementById('purchase-date').value = new Date().toISOString().slice(0, 10);
    document.getElementById('purchase-notes').value = '';

    const targetProd = (preselectedProductId && this.products.find(p => p.id === preselectedProductId)) || this.products[0];
    const defaultExp = targetProd?.has_expiry == 1 && targetProd?.expiry_date ? targetProd.expiry_date : '';

    this.purchaseModalItems = [
      {
        product_id: targetProd?.id || '',
        quantity: 10,
        cost_price: targetProd?.cost_price || 0,
        batch_number: '',
        expiry_date: defaultExp
      }
    ];
    this.renderPurchaseModalItems();
    this.updatePurchaseModalBalanceBadge();

    document.getElementById('purchase-modal').classList.add('active');
  }

  closePurchaseModal() {
    document.getElementById('purchase-modal').classList.remove('active');
  }

  handlePurchaseVendorSelect(vendorId) {
    const customGrp = document.getElementById('grp-purchase-supplier-custom');
    const nameInput = document.getElementById('purchase-supplier-name');
    const contactInput = document.getElementById('purchase-supplier-contact');

    if (vendorId === '__custom__') {
      if (customGrp) customGrp.style.display = 'block';
      if (nameInput) { nameInput.value = ''; nameInput.focus(); }
      if (contactInput) contactInput.value = '';
    } else if (vendorId) {
      if (customGrp) customGrp.style.display = 'none';
      const vendor = this.vendors.find(v => String(v.id) === String(vendorId));
      if (vendor) {
        if (nameInput) nameInput.value = vendor.name;
        if (contactInput) contactInput.value = vendor.phone || vendor.contact_person || '';
      }
    } else {
      if (customGrp) customGrp.style.display = 'none';
      if (nameInput) nameInput.value = '';
      if (contactInput) contactInput.value = '';
    }
  }

  handlePurchasePaymentModeChange(mode) {
    const partRow = document.getElementById('purchase-partial-row');
    const amtPaidInput = document.getElementById('purchase-amount-paid');

    if (mode === 'CREDIT') {
      if (partRow) partRow.style.display = 'flex';
      if (amtPaidInput) {
        amtPaidInput.disabled = false;
        if (!amtPaidInput.value || parseFloat(amtPaidInput.value) <= 0) {
          amtPaidInput.value = '0.00';
        }
      }
    } else {
      // PAID IN FULL
      if (partRow) partRow.style.display = 'none';
      if (amtPaidInput) {
        amtPaidInput.disabled = false;
        amtPaidInput.value = '0.00';
      }
    }
    this.updatePurchaseModalBalanceBadge();
  }

  updatePurchaseModalBalanceBadge() {
    const totalCost = this.purchaseModalItems.reduce((sum, item) => sum + ((item.quantity || 0) * (item.cost_price || 0)), 0);
    const mode = document.getElementById('purchase-payment-status')?.value || 'PAID';
    const amtPaidInput = document.getElementById('purchase-amount-paid');
    const badge = document.getElementById('purchase-balance-badge');

    if (mode === 'PAID') {
      if (badge) badge.style.display = 'none';
      return;
    }

    const paid = Math.max(0, parseFloat(amtPaidInput?.value) || 0);
    const debt = Math.max(0, totalCost - paid);

    if (badge) {
      badge.style.display = 'inline-block';
      if (debt <= 0.001) {
        badge.className = 'badge badge-success';
        badge.innerHTML = `<i class="fa-solid fa-circle-check"></i> Fully Paid (${this.formatCurrency(0)} Debt)`;
      } else if (paid > 0) {
        badge.className = 'badge badge-warning';
        badge.innerHTML = `<i class="fa-solid fa-clock-rotate-left"></i> Partial Debt: <strong>${this.formatCurrency(debt)}</strong>`;
      } else {
        badge.className = 'badge badge-danger';
        badge.innerHTML = `<i class="fa-solid fa-clock"></i> 100% Credit Debt: <strong>${this.formatCurrency(debt)}</strong>`;
      }
    }
  }

  addPurchaseModalItemRow() {
    this.purchaseModalItems.push({
      product_id: this.products[0]?.id || '',
      quantity: 1,
      cost_price: this.products[0]?.cost_price || 0
    });
    this.renderPurchaseModalItems();
  }

  removePurchaseModalItemRow(index) {
    this.purchaseModalItems.splice(index, 1);
    this.renderPurchaseModalItems();
  }

  renderPurchaseModalItems() {
    const container = document.getElementById('purchase-items-rows');
    if (!container) return;

    container.innerHTML = this.purchaseModalItems.map((row, idx) => `
      <div style="display: grid; grid-template-columns: 2fr 1fr 1fr 40px; gap: 0.5rem; margin-bottom: 0.5rem; align-items: center;">
        <select class="form-control" onchange="app.updatePurchaseRowProduct(${idx}, this.value)">
          ${this.products.map(p => `
            <option value="${this.escapeHtml(p.id)}" ${row.product_id === p.id ? 'selected' : ''}>${this.escapeHtml(p.name)} (${this.formatCurrency(p.cost_price)})</option>
          `).join('')}
        </select>
        <input type="number" class="form-control" placeholder="Qty" value="${row.quantity}" min="1" oninput="app.purchaseModalItems[${idx}].quantity = parseFloat(this.value) || 0; app.updatePurchaseModalTotal();">
        <input type="number" class="form-control" placeholder="Factory Cost" value="${row.cost_price}" step="any" oninput="app.purchaseModalItems[${idx}].cost_price = parseFloat(this.value) || 0; app.updatePurchaseModalTotal();">
        <button class="btn btn-outline btn-sm" onclick="app.removePurchaseModalItemRow(${idx})" style="color: var(--danger);"><i class="fa-solid fa-xmark"></i></button>
      </div>
    `).join('');

    this.updatePurchaseModalTotal();
  }

  updatePurchaseRowProduct(index, productId) {
    const prod = this.products.find(p => p.id === productId);
    if (prod && this.purchaseModalItems[index]) {
      this.purchaseModalItems[index].product_id = prod.id;
      this.purchaseModalItems[index].cost_price = Number(prod.cost_price || 0);
      this.renderPurchaseModalItems();
    }
  }

  updatePurchaseModalTotal() {
    const totalEl = document.getElementById('purchase-modal-total');
    if (!totalEl) return;
    const total = this.purchaseModalItems.reduce((sum, item) => sum + ((item.quantity || 0) * (item.cost_price || 0)), 0);
    totalEl.innerText = this.formatCurrency(total);
    this.updatePurchaseModalBalanceBadge();
  }

  async savePurchaseOrder() {
    const vendorSelect = document.getElementById('purchase-vendor-select');
    const selectedVendorId = vendorSelect ? vendorSelect.value : '';
    let supplierName = '';

    if (selectedVendorId && selectedVendorId !== '__custom__') {
      const matchedVendor = this.vendors.find(v => String(v.id) === String(selectedVendorId));
      supplierName = matchedVendor ? matchedVendor.name : '';
    } else {
      supplierName = (document.getElementById('purchase-supplier-name')?.value || '').trim();
    }

    if (!supplierName) {
      this.showToast('Please select or specify a Supplier / Factory name.', 'warning');
      return;
    }

    if (this.purchaseModalItems.length === 0) {
      this.showToast('Add at least one product to the purchase order.', 'warning');
      return;
    }

    const orderNumber = 'PO-' + new Date().toISOString().slice(0, 10).replace(/-/g, '') + '-' + Math.floor(1000 + Math.random() * 9000);
    const orderDate = document.getElementById('purchase-date').value || new Date().toISOString().slice(0, 10);
    const totalCost = this.purchaseModalItems.reduce((sum, item) => sum + ((item.quantity || 0) * (item.cost_price || 0)), 0);
    const paymentMode = document.getElementById('purchase-payment-status')?.value || 'PAID';
    const amtPaidInput = document.getElementById('purchase-amount-paid');

    let amountPaid = 0;
    if (paymentMode === 'PAID') {
      amountPaid = totalCost;
    } else {
      // CREDIT (with optional deposit/down payment)
      amountPaid = Math.min(totalCost, Math.max(0, parseFloat(amtPaidInput?.value) || 0));
    }

    const unpaidAmount = Math.max(0, totalCost - amountPaid);
    const paymentStatus = (unpaidAmount <= 0.001) ? 'PAID' : (amountPaid > 0 ? 'PARTIAL' : 'CREDIT');

    const purchasePayload = {
      id: 'po_' + Math.random().toString(36).substring(2, 10),
      order_number: orderNumber,
      supplier_name: supplierName,
      supplier_contact: document.getElementById('purchase-supplier-contact').value.trim(),
      vendor_id: (selectedVendorId && selectedVendorId !== '__custom__') ? selectedVendorId : null,
      amount_paid: amountPaid,
      payment_status: paymentStatus,
      branch_code: this.currentUser?.branch_code || 'MAIN-01',
      order_date: orderDate,
      total_cost: totalCost,
      shipping_cost: 0,
      notes: document.getElementById('purchase-notes').value.trim(),
      items: this.purchaseModalItems
    };

    // Update Product Stock & Weighted Average Cost
    for (const item of this.purchaseModalItems) {
      const prod = this.products.find(p => p.id === item.product_id);
      if (prod) {
        const curQty = Number(prod.current_quantity || 0);
        const oldCost = Number(prod.cost_price || item.cost_price || 0);
        const incomingQty = Number(item.quantity || 0);
        const incomingCost = Number(item.cost_price || 0);

        let weightedCost = incomingCost;
        if (curQty > 0) {
          weightedCost = ((curQty * oldCost) + (incomingQty * incomingCost)) / (curQty + incomingQty);
        }

        prod.current_quantity = curQty + incomingQty;
        prod.cost_price = Number(weightedCost.toFixed(2));
        await localDB.products.put(prod);
      }
    }

    // Update Vendor Balance if bought on credit or partial
    if (purchasePayload.vendor_id && unpaidAmount > 0) {
      const targetVendor = this.vendors.find(v => String(v.id) === String(purchasePayload.vendor_id));
      if (targetVendor) {
        targetVendor.balance = Number((Number(targetVendor.balance || 0) + unpaidAmount).toFixed(2));
        if (localDB.vendors) {
          await localDB.vendors.put(targetVendor);
        }
      }
    }

    this.purchases.unshift(purchasePayload);
    await localDB.purchases.put(purchasePayload);

    if (this.isOnline) {
      try {
        await this.apiFetch('api/endpoints/purchases.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(purchasePayload)
        });
        await this.logClientActivity(
          'PURCHASE_ORDER',
          `Received factory purchase order #${purchasePayload.order_number || ''} from ${purchasePayload.supplier_name} (Total: ${this.formatCurrency(purchasePayload.total_cost)}).`,
          false
        );
      } catch (err) {
        await localDB.sync_outbox.add({
          entity: 'purchase',
          action: 'CREATE',
          data: purchasePayload,
          timestamp: new Date().toISOString(),
          synced: 0
        });
        await this.logClientActivity(
          'PURCHASE_ORDER',
          `Created offline factory purchase order from ${purchasePayload.supplier_name} (Total: ${this.formatCurrency(purchasePayload.total_cost)}).`,
          true
        );
      }
    } else {
      await localDB.sync_outbox.add({
        entity: 'purchase',
        action: 'CREATE',
        data: purchasePayload,
        timestamp: new Date().toISOString(),
        synced: 0
      });
      await this.logClientActivity(
        'PURCHASE_ORDER',
        `Created offline factory purchase order from ${purchasePayload.supplier_name} (Total: ${this.formatCurrency(purchasePayload.total_cost)}).`,
        true
      );
    }

    this.closePurchaseModal();
    this.renderCurrentView();
    this.showToast(`Factory purchase ${orderNumber} recorded! Inventory stock updated.`, 'success');
  }

  // --- Factory Suppliers & Accounts Payable Directory ---

  getVendorsHTML() {
    const search = (this.vendorSearchTerm || '').toLowerCase().trim();
    let filtered = this.vendors.filter(v => {
      const matchesSearch = !search ||
        (v.name && v.name.toLowerCase().includes(search)) ||
        (v.contact_person && v.contact_person.toLowerCase().includes(search)) ||
        (v.phone && v.phone.toLowerCase().includes(search)) ||
        (v.email && v.email.toLowerCase().includes(search));

      if (!matchesSearch) return false;

      const bal = Number(v.balance || 0);
      if (this.vendorFilter === 'DEBT') return bal > 0.01;
      if (this.vendorFilter === 'CLEARED') return bal <= 0.01;
      return true;
    });

    const totalAccountsPayable = this.vendors.reduce((sum, v) => sum + Number(v.balance || 0), 0);
    const vendorsWithDebtCount = this.vendors.filter(v => Number(v.balance || 0) > 0.01).length;

    return `
      <div class="panel">
        <div class="panel-header" style="flex-wrap: wrap; gap: 0.75rem;">
          <div>
            <h3><i class="fa-solid fa-truck-field"></i> Factory Suppliers & Accounts Payable</h3>
            <p style="font-size: 0.85rem; color: var(--slate-600); margin: 0.25rem 0 0 0;">
              Manage direct manufacturers, supply contracts, vendor credit ledgers, and accounts payable settlements.
            </p>
          </div>
          <div style="display: flex; gap: 0.5rem; align-items: center;">
            <button class="btn btn-outline" onclick="app.switchView('purchases')">
              <i class="fa-solid fa-truck-ramp-box"></i> View Purchase Orders
            </button>
            <button class="btn btn-success" onclick="app.openNewVendorModal()">
              <i class="fa-solid fa-plus"></i> Add Factory Supplier
            </button>
          </div>
        </div>

        <div class="panel-body">
          <!-- Summary Metrics Cards -->
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 1.5rem;">
            <div style="background: var(--slate-50); border: 1px solid var(--slate-200); border-radius: var(--radius-md); padding: 1rem;">
              <span style="font-size: 0.78rem; font-weight: 600; text-transform: uppercase; color: var(--slate-500); display: block;">Total Registered Suppliers</span>
              <div style="font-size: 1.5rem; font-weight: 800; color: var(--slate-900); margin-top: 0.25rem;">
                <i class="fa-solid fa-building" style="color: var(--primary); font-size: 1.25rem; margin-right: 0.35rem;"></i>
                ${this.vendors.length}
              </div>
            </div>

            <div style="background: rgba(239, 68, 68, 0.05); border: 1px solid rgba(239, 68, 68, 0.2); border-radius: var(--radius-md); padding: 1rem;">
              <span style="font-size: 0.78rem; font-weight: 600; text-transform: uppercase; color: var(--danger); display: block;">Total Accounts Payable (Owed)</span>
              <div style="font-size: 1.5rem; font-weight: 800; color: var(--danger); margin-top: 0.25rem;">
                <i class="fa-solid fa-hand-holding-dollar" style="font-size: 1.25rem; margin-right: 0.35rem;"></i>
                ${this.formatCurrency(totalAccountsPayable)}
              </div>
            </div>

            <div style="background: var(--slate-50); border: 1px solid var(--slate-200); border-radius: var(--radius-md); padding: 1rem;">
              <span style="font-size: 0.78rem; font-weight: 600; text-transform: uppercase; color: var(--slate-500); display: block;">Suppliers with Balance Due</span>
              <div style="font-size: 1.5rem; font-weight: 800; color: var(--slate-900); margin-top: 0.25rem;">
                <i class="fa-solid fa-clock-rotate-left" style="color: var(--warning); font-size: 1.25rem; margin-right: 0.35rem;"></i>
                ${vendorsWithDebtCount} <span style="font-size: 0.85rem; font-weight: 500; color: var(--slate-500);">/ ${this.vendors.length}</span>
              </div>
            </div>
          </div>

          <!-- Filter & Search Toolbar -->
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.25rem; flex-wrap: wrap; gap: 0.75rem;">
            <div style="display: flex; gap: 0.5rem; align-items: center; flex: 1; max-width: 420px;">
              <div style="position: relative; width: 100%;">
                <input type="text" id="vendor-search-input" class="form-control" placeholder="Search supplier name, contact, phone, or email..." value="${this.escapeHtml(this.vendorSearchTerm)}" style="padding-left: 2.2rem;">
                <i class="fa-solid fa-magnifying-glass" style="position: absolute; left: 0.8rem; top: 50%; transform: translateY(-50%); color: var(--slate-400);"></i>
              </div>
            </div>

            <div style="display: flex; gap: 0.4rem; align-items: center; flex-wrap: wrap;">
              <button class="btn btn-sm ${this.vendorFilter === 'ALL' ? 'btn-primary' : 'btn-outline'}" onclick="app.filterVendors('ALL')">
                All Suppliers (${this.vendors.length})
              </button>
              <button class="btn btn-sm ${this.vendorFilter === 'DEBT' ? 'btn-danger' : 'btn-outline'}" onclick="app.filterVendors('DEBT')" style="${this.vendorFilter === 'DEBT' ? 'background: var(--danger); color: #fff; border-color: var(--danger);' : ''}">
                <i class="fa-solid fa-circle-exclamation"></i> Owed Debt (${vendorsWithDebtCount})
              </button>
              <button class="btn btn-sm ${this.vendorFilter === 'CLEARED' ? 'btn-success' : 'btn-outline'}" onclick="app.filterVendors('CLEARED')">
                <i class="fa-solid fa-circle-check"></i> Cleared / Zero Debt
              </button>
            </div>
          </div>

          <!-- Vendors Table -->
          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Supplier / Factory Name</th>
                  <th>Contact Person</th>
                  <th>Phone & Email</th>
                  <th>Payment Terms</th>
                  <th style="text-align: right;">Accounts Payable</th>
                  <th style="text-align: center;">Actions</th>
                </tr>
              </thead>
              <tbody>
                ${filtered.length > 0 ? filtered.map(v => {
      const bal = Number(v.balance || 0);
      const isDebt = bal > 0.01;
      return `
                    <tr>
                      <td>
                        <div style="font-weight: 700; color: var(--slate-900); font-size: 0.95rem;">${this.escapeHtml(v.name)}</div>
                        ${v.tax_id ? `<span style="font-size: 0.75rem; color: var(--slate-500); font-family: monospace;">TIN: ${this.escapeHtml(v.tax_id)}</span>` : ''}
                        ${v.address ? `<div style="font-size: 0.78rem; color: var(--slate-500);"><i class="fa-solid fa-location-dot" style="font-size: 0.7rem;"></i> ${this.escapeHtml(v.address)}</div>` : ''}
                      </td>
                      <td>
                        <span style="font-weight: 600;">${this.escapeHtml(v.contact_person || 'Direct Factory')}</span>
                      </td>
                      <td>
                        ${v.phone ? `<div><i class="fa-solid fa-phone" style="font-size: 0.75rem; color: var(--slate-400);"></i> <a href="tel:${this.escapeHtml(v.phone)}" style="color: var(--primary); text-decoration: none;">${this.escapeHtml(v.phone)}</a></div>` : ''}
                        ${v.email ? `<div style="font-size: 0.8rem; color: var(--slate-600);"><i class="fa-solid fa-envelope" style="font-size: 0.75rem; color: var(--slate-400);"></i> ${this.escapeHtml(v.email)}</div>` : ''}
                      </td>
                      <td>
                        <span class="badge badge-info" style="font-size: 0.78rem;">
                          ${this.escapeHtml(v.payment_terms || 'NET30')}
                        </span>
                      </td>
                      <td style="text-align: right;">
                        ${isDebt ? `
                          <div style="font-weight: 800; font-size: 1.05rem; color: var(--danger);">
                            ${this.formatCurrency(bal)}
                          </div>
                          <span class="badge badge-warning" style="font-size: 0.7rem; padding: 0.15rem 0.4rem;">
                            <i class="fa-solid fa-clock"></i> Owed Debt
                          </span>
                        ` : `
                          <div style="font-weight: 700; color: var(--success); font-size: 0.95rem;">
                            ${this.formatCurrency(0)}
                          </div>
                          <span class="badge badge-success" style="font-size: 0.7rem; padding: 0.15rem 0.4rem;">
                            <i class="fa-solid fa-check"></i> Cleared
                          </span>
                        `}
                      </td>
                      <td style="text-align: center;">
                        <div style="display: inline-flex; gap: 0.35rem; align-items: center;">
                          <button class="btn btn-outline btn-sm" onclick="app.openVendorPaymentModal(${this.jsStr(v.id)})" title="Record Payout / Settle Debt" style="color: var(--primary); font-weight: 600;">
                            <i class="fa-solid fa-money-bill-transfer"></i> Payout
                          </button>
                          <button class="btn btn-outline btn-sm" onclick="app.showVendorStatementModal(${this.jsStr(v.id)})" title="Print Supplier Statement of Account">
                            <i class="fa-solid fa-file-invoice"></i> Ledger
                          </button>
                          <button class="btn btn-outline btn-sm" onclick="app.openEditVendorModal(${this.jsStr(v.id)})" title="Edit Supplier Profile">
                            <i class="fa-solid fa-pen-to-square"></i>
                          </button>
                          <button class="btn btn-outline btn-sm" onclick="app.deleteVendor(${this.jsStr(v.id)})" title="Delete Supplier" style="color: var(--danger);">
                            <i class="fa-solid fa-trash"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  `;
    }).join('') : `
                  <tr>
                    <td colspan="6" style="text-align: center; padding: 3rem; color: var(--slate-400);">
                      <i class="fa-solid fa-truck-field" style="font-size: 2.25rem; margin-bottom: 0.75rem; display: block;"></i>
                      No suppliers found matching your criteria.
                    </td>
                  </tr>
                `}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  }

  bindVendorsEvents() {
    const searchInput = document.getElementById('vendor-search-input');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        this.vendorSearchTerm = e.target.value;
        const container = document.getElementById('view-content-container');
        if (container) {
          container.innerHTML = this.getVendorsHTML();
          this.bindVendorsEvents();
          // refocus
          const newSearch = document.getElementById('vendor-search-input');
          if (newSearch) {
            newSearch.focus();
            newSearch.setSelectionRange(newSearch.value.length, newSearch.value.length);
          }
        }
      });
    }
  }

  filterVendors(status) {
    this.vendorFilter = status;
    const container = document.getElementById('view-content-container');
    if (container) {
      container.innerHTML = this.getVendorsHTML();
      this.bindVendorsEvents();
    }
  }

  openNewVendorModal() {
    const title = document.getElementById('vendor-modal-title');
    if (title) title.innerHTML = '<i class="fa-solid fa-truck-field"></i> Add Factory Supplier';

    document.getElementById('vendor-form-id').value = '';
    document.getElementById('vendor-form-name').value = '';
    document.getElementById('vendor-form-contact').value = '';
    document.getElementById('vendor-form-phone').value = '';
    document.getElementById('vendor-form-email').value = '';
    document.getElementById('vendor-form-address').value = '';
    document.getElementById('vendor-form-terms').value = 'NET30';
    document.getElementById('vendor-form-tax').value = '';
    document.getElementById('vendor-form-bank').value = '';
    document.getElementById('vendor-form-notes').value = '';

    document.getElementById('vendor-modal').classList.add('active');
  }

  openEditVendorModal(vendorId) {
    const vendor = this.vendors.find(v => String(v.id) === String(vendorId));
    if (!vendor) return;

    const title = document.getElementById('vendor-modal-title');
    if (title) title.innerHTML = '<i class="fa-solid fa-pen-to-square"></i> Edit Supplier Profile';

    document.getElementById('vendor-form-id').value = vendor.id || '';
    document.getElementById('vendor-form-name').value = vendor.name || '';
    document.getElementById('vendor-form-contact').value = vendor.contact_person || '';
    document.getElementById('vendor-form-phone').value = vendor.phone || '';
    document.getElementById('vendor-form-email').value = vendor.email || '';
    document.getElementById('vendor-form-address').value = vendor.address || '';
    document.getElementById('vendor-form-terms').value = vendor.payment_terms || 'NET30';
    document.getElementById('vendor-form-tax').value = vendor.tax_id || '';
    document.getElementById('vendor-form-bank').value = vendor.bank_details || '';
    document.getElementById('vendor-form-notes').value = vendor.notes || '';

    document.getElementById('vendor-modal').classList.add('active');
  }

  closeVendorModal() {
    document.getElementById('vendor-modal').classList.remove('active');
  }

  async saveVendorForm() {
    const id = document.getElementById('vendor-form-id').value.trim();
    const name = document.getElementById('vendor-form-name').value.trim();

    if (!name) {
      this.showToast('Supplier / Factory Name is required.', 'warning');
      return;
    }

    const payload = {
      id: id || ('ven_' + Math.random().toString(36).substring(2, 10)),
      name: name,
      contact_person: document.getElementById('vendor-form-contact').value.trim(),
      phone: document.getElementById('vendor-form-phone').value.trim(),
      email: document.getElementById('vendor-form-email').value.trim(),
      address: document.getElementById('vendor-form-address').value.trim(),
      payment_terms: document.getElementById('vendor-form-terms').value,
      tax_id: document.getElementById('vendor-form-tax').value.trim(),
      bank_details: document.getElementById('vendor-form-bank').value.trim(),
      notes: document.getElementById('vendor-form-notes').value.trim(),
      balance: id ? (this.vendors.find(v => String(v.id) === String(id))?.balance || 0) : 0
    };

    if (id) {
      const idx = this.vendors.findIndex(v => String(v.id) === String(id));
      if (idx !== -1) {
        this.vendors[idx] = { ...this.vendors[idx], ...payload };
      }
    } else {
      this.vendors.unshift(payload);
    }

    if (localDB.vendors) {
      await localDB.vendors.put(payload);
    }

    if (this.isOnline) {
      try {
        await this.apiFetch('api/endpoints/vendors.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
      } catch (err) {
        await localDB.sync_outbox.add({
          entity: 'vendor',
          action: id ? 'UPDATE' : 'CREATE',
          data: payload,
          timestamp: new Date().toISOString(),
          synced: 0
        });
      }
    } else {
      await localDB.sync_outbox.add({
        entity: 'vendor',
        action: id ? 'UPDATE' : 'CREATE',
        data: payload,
        timestamp: new Date().toISOString(),
        synced: 0
      });
    }

    this.closeVendorModal();
    this.renderCurrentView();
    this.showToast(`Supplier '${name}' saved successfully!`, 'success');

    // Create then carry in, in one breath - which is the order a shopkeeper actually works in.
    // He writes the factory's name and terms first, then turns back to the paper book for the
    // number the account starts on. Asking here means that number lands as a dated, signed row
    // instead of being retyped into the balance column, where nothing could ever account for it.
    if (!id) {
      const wantsOpening = await this.showConfirmModal({
        title: 'Add an opening balance?',
        message: `'${name}' starts at ${this.formatCurrency(0)}. If the paper book already owes them, or they are holding money you paid ahead of a delivery, book it now - it goes on their statement with today's date and your name on it. Skip it and the account stays at zero until an order moves it.`,
        icon: 'fa-folder-open',
        confirmText: 'Enter the balance',
        cancelText: 'Leave at zero',
        confirmBtnClass: 'btn-primary'
      });
      if (wantsOpening) this.openVendorOpeningModal(payload.id);
    }
  }

  async deleteVendor(vendorId) {
    const vendor = this.vendors.find(v => String(v.id) === String(vendorId));
    if (!vendor) return;

    const openBal = Number(vendor.balance || 0);
    if (openBal > 0.01) {
      this.showToast(`Cannot delete '${vendor.name}' because there is an outstanding accounts payable debt of ${this.formatCurrency(openBal)}. Please settle the debt first.`, 'warning');
      return;
    }
    // The other direction is money too. A supplier holding an advance used to be deletable
    // while every other account was protected, so the shop could erase the only record
    // that someone still owed it goods.
    if (openBal < -0.01) {
      this.showToast(`Cannot delete '${vendor.name}' because they are holding an advance of ${this.formatCurrency(Math.abs(openBal))} against future deliveries. Settle or reclaim it first.`, 'warning');
      return;
    }

    const confirmed = await this.showConfirmModal({
      title: 'Delete Supplier?',
      message: `Are you sure you want to delete supplier '${vendor.name}'?`,
      icon: 'fa-trash-can',
      confirmText: 'Delete Supplier',
      confirmBtnClass: 'btn-danger'
    });
    if (!confirmed) {
      return;
    }

    this.vendors = this.vendors.filter(v => String(v.id) !== String(vendorId));
    if (localDB.vendors) {
      await localDB.vendors.delete(vendorId);
    }

    if (this.isOnline) {
      try {
        const res = await this.apiFetch(`api/endpoints/vendors.php?id=${vendorId}`, {
          method: 'DELETE'
        });
        const data = await res.json();
        if (!data.success) {
          this.showToast(data.message || 'Error deleting supplier from server', 'warning');
        }
      } catch (err) {
        await localDB.sync_outbox.add({
          entity: 'vendor',
          action: 'DELETE',
          data: { id: vendorId },
          timestamp: new Date().toISOString(),
          synced: 0
        });
      }
    } else {
      await localDB.sync_outbox.add({
        entity: 'vendor',
        action: 'DELETE',
        data: { id: vendorId },
        timestamp: new Date().toISOString(),
        synced: 0
      });
    }

    this.renderCurrentView();
    this.showToast(`Supplier '${vendor.name}' removed`, 'info');
  }

  // --- Accounts Payable Payouts ---

  openVendorPaymentModal(vendorId) {
    const vendor = this.vendors.find(v => String(v.id) === String(vendorId));
    if (!vendor) return;

    document.getElementById('vpay-vendor-id').value = vendor.id;
    document.getElementById('vpay-vendor-name').innerText = vendor.name;

    const bal = Number(vendor.balance || 0);
    const balLine = document.getElementById('vpay-balance-line');
    const amtInput = document.getElementById('vpay-amount');
    if (bal > 0.01) {
      balLine.innerHTML = `Owed: <span id="vpay-current-balance">${this.formatCurrency(bal)}</span>`;
      balLine.style.color = 'var(--danger)';
    } else if (bal < -0.01) {
      balLine.innerHTML = `Advance held with them: <span id="vpay-current-balance">${this.formatCurrency(Math.abs(bal))}</span>`;
      balLine.style.color = 'var(--success)';
    } else {
      balLine.innerHTML = `Settled: <span id="vpay-current-balance">${this.formatCurrency(0)}</span>`;
      balLine.style.color = 'var(--slate-600)';
    }

    amtInput.value = bal > 0.01 ? bal.toFixed(2) : '';
    document.getElementById('vpay-date').value = new Date().toISOString().slice(0, 10);
    document.getElementById('vpay-reference').value = '';
    document.getElementById('vpay-notes').value = '';

    document.getElementById('vendor-payment-modal').classList.add('active');
    setTimeout(() => amtInput.focus(), 150);
  }

  closeVendorPaymentModal() {
    document.getElementById('vendor-payment-modal').classList.remove('active');
  }

  async saveVendorPayment() {
    // A payout is cash leaving a till, and a cashier double-clicks it the same way he
    // double-clicks anything else. The second click used to settle an account already at
    // zero or start a second one, because a fresh id was rolled per click and nothing on
    // the shop's books could tell the two payments apart. While one is in flight the
    // button says so and a second call is refused, so a double-click is not a double pay.
    if (this._vendorPayoutInFlight) return;
    this._vendorPayoutInFlight = true;
    const payoutBtn = document.getElementById('vpay-save-btn');
    if (payoutBtn) payoutBtn.disabled = true;
    try {
      await this.recordVendorPayout();
    } finally {
      this._vendorPayoutInFlight = false;
      if (payoutBtn) payoutBtn.disabled = false;
    }
  }

  async recordVendorPayout() {
    const vendorId = document.getElementById('vpay-vendor-id').value;
    const vendor = this.vendors.find(v => String(v.id) === String(vendorId));
    if (!vendor) return;

    const amount = parseFloat(document.getElementById('vpay-amount').value) || 0;
    if (amount <= 0) {
      this.showToast('Please enter a valid payout amount.', 'warning');
      return;
    }

    const paymentMethod = document.getElementById('vpay-method').value || 'CASH';
    const paymentDate = document.getElementById('vpay-date').value || new Date().toISOString().slice(0, 10);
    const referenceNo = document.getElementById('vpay-reference').value.trim();
    const notes = document.getElementById('vpay-notes').value.trim();

    const previousBalance = Number(vendor.balance || 0);
    const overshoot = Math.round((amount - previousBalance) * 100) / 100;

    // Paying more than the account owes is either a mis-typed figure or a deposit for
    // goods still to come. Both are common at a counter, so ask which - and never let the
    // difference fall between the two answers the way max(0, balance - amount) used to.
    let allowAdvance = false;
    if (overshoot > 0.01) {
      const confirmed = await this.showConfirmModal({
        title: 'Pay more than the account owes?',
        message: `'${vendor.name}' is owed ${this.formatCurrency(Math.max(0, previousBalance))}. This payout is ${this.formatCurrency(amount)} - ${this.formatCurrency(overshoot)} more. Confirm and the extra is held as an advance the supplier owes you in goods. Cancel it to correct the amount.`,
        icon: 'fa-hand-holding-dollar',
        confirmText: 'Yes, hold it as an advance',
        confirmBtnClass: 'btn-primary'
      });
      if (!confirmed) return;
      allowAdvance = true;
    }

    const paymentPayload = {
      id: 'vpay_' + Math.random().toString(36).substring(2, 10),
      action: 'record_payment',
      vendor_id: vendorId,
      amount: amount,
      allow_advance: allowAdvance,
      payment_method: paymentMethod,
      reference_no: referenceNo,
      payment_date: paymentDate,
      notes: notes,
      user_id: this.currentUser?.id || 1,
      officer_name: this.currentUser?.full_name || 'Store Manager'
    };

    // Ask the shop's books before writing the payout down. apiFetch does not throw on a
    // refusal, so the old code had already moved the local balance and toasted success
    // long before the answer arrived.
    let offline = !this.isOnline;
    let refusal = null;
    let alreadyRecorded = false;
    let settledOrders = null;
    if (!offline) {
      let res = null;
      try {
        res = await this.apiFetch('api/endpoints/vendors.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(paymentPayload)
        });
      } catch (err) {
        res = null;
      }
      if (res === null) {
        offline = true;
      } else {
        const verdict = await this.classifyApiResponse(res);
        if (verdict.verdict === 'refused') {
          refusal = verdict.message;
          alreadyRecorded = !!(verdict.body && verdict.body.already_recorded);
        }
        else if (verdict.verdict === 'accepted') settledOrders = (verdict.body && verdict.body.applied_orders) || [];
        else if (verdict.verdict === 'unreachable') offline = true;
      }
    }

    if (refusal) {
      // The shop's books already hold this exact payment, so the till must agree with them
      // rather than keep showing a debt the shop has paid. Pull the account back.
      if (alreadyRecorded) {
        this.showToast(`${refusal} Refreshing the supplier's account.`, 'warning', 14000);
        if (typeof this.fetchVendors === 'function') this.fetchVendors();
      } else {
        this.showToast(`Payout was NOT recorded: ${refusal} Nothing was paid and the account stands where it was.`, 'danger', 14000);
      }
      return;
    }

    const newBalance = Math.round((previousBalance - amount) * 100) / 100;
    vendor.balance = newBalance;
    if (localDB.vendors) {
      await localDB.vendors.put(vendor);
    }
    if (localDB.vendor_payments) {
      await localDB.vendor_payments.put(paymentPayload);
    }
    if (offline) {
      await localDB.sync_outbox.add({
        entity: 'vendor_payment',
        action: 'CREATE',
        data: paymentPayload,
        timestamp: new Date().toISOString(),
        synced: 0
      });
    }

    // Which invoices the money actually closed is the rest of the news, and the cashier
    // needs it on the screen he is standing at: an account that reads GH₵0.00 above a list
    // of orders still stamped PARTIAL is exactly what makes a shopkeeper pay a bill twice,
    // once from the till and once from the paper the supplier brings.
    //
    // Online, the shop's books say what they settled and the till copies that. Offline, the
    // till walks its own copy of the orders the same way the server will, so the counter is
    // not showing a debt it has already paid while the line is down.
    if (offline || settledOrders === null) {
      settledOrders = this.allocatePayoutToOrdersLocally(vendorId, amount);
    }
    await this.applyPayoutOrderSettlements(settledOrders);
    const closedNumbers = (settledOrders || [])
      .filter(s => String(s.payment_status).toUpperCase() === 'PAID')
      .map(s => s.order_number || s.id);
    const settledNote = closedNumbers.length ? ` · ${closedNumbers.join(', ')} now fully paid` : '';

    this.closeVendorPaymentModal();
    this.renderCurrentView();

    if (offline) {
      this.showToast(`Paid ${this.formatCurrency(amount)} to ${vendor.name}. Held on this till and waiting to sync to the shop's books.${settledNote}`, 'warning', 11000);
    } else if (newBalance < -0.01) {
      this.showToast(`Paid ${this.formatCurrency(amount)} to ${vendor.name}. Settled, with ${this.formatCurrency(Math.abs(newBalance))} held as an advance they owe you in goods.${settledNote}`, 'success', 11000);
    } else {
      this.showToast(`Paid ${this.formatCurrency(amount)} to ${vendor.name}. Remaining debt: ${this.formatCurrency(newBalance)}${settledNote}`, 'success', 9000);
    }
  }

  // --- Supplier Statement of Account & Ledger ---

  async showVendorStatementModal(vendorId) {
    const vendor = this.vendors.find(v => String(v.id) === String(vendorId));
    if (!vendor) return;

    this.currentVendorForStatement = vendor;
    const printArea = document.getElementById('printable-vendor-statement-area');
    if (!printArea) return;

    printArea.innerHTML = `<div style="text-align: center; padding: 2rem;"><i class="fa-solid fa-spinner fa-spin"></i> Loading supplier ledger...</div>`;
    document.getElementById('vendor-statement-modal').classList.add('active');

    let payments = [];
    let purchases = [];

    if (this.isOnline) {
      try {
        const [payRes, poRes] = await Promise.all([
          this.apiFetch(`api/endpoints/vendors.php?vendor_id=${encodeURIComponent(vendorId)}&payments=1`),
          this.apiFetch(`api/endpoints/vendors.php?vendor_id=${encodeURIComponent(vendorId)}&purchases=1`)
        ]);
        const payData = await payRes.json();
        const poData = await poRes.json();
        if (payData.success && Array.isArray(payData.payments)) payments = payData.payments;
        if (poData.success && Array.isArray(poData.purchases)) purchases = poData.purchases;
      } catch (err) {
        console.warn('Falling back to local ledger data');
      }
    }

    // Merge IndexedDB local vendor payments
    if (localDB.vendor_payments) {
      try {
        const allLocalPayments = await localDB.vendor_payments.where('vendor_id').equals(vendorId).toArray();
        allLocalPayments.forEach(lp => {
          if (!payments.some(p => p.id === lp.id)) {
            payments.push(lp);
          }
        });
      } catch (e) { }
    }

    // Merge purchases
    if (purchases.length === 0) {
      purchases = this.purchases.filter(p => String(p.vendor_id) === String(vendorId) || p.supplier_name === vendor.name);
    } else {
      this.purchases.forEach(lp => {
        if ((String(lp.vendor_id) === String(vendorId) || lp.supplier_name === vendor.name) && !purchases.some(p => p.id === lp.id)) {
          purchases.push(lp);
        }
      });
    }

    // Merge transactions into chronological timeline
    const transactions = [];

    purchases.forEach(po => {
      const totalCost = Number(po.total_cost || 0);
      const amountPaid = Number(po.amount_paid || 0);
      const drawn = Number(po.credit_used || 0);
      const netDebt = Math.round((totalCost - amountPaid - drawn) * 100) / 100;

      // The order bills its gross; the money paid against it is a separate credit line,
      // because that is exactly how it is stored. Booking the debit as (total - deposit)
      // here while the deposit also appeared as a payout credit counted the same money
      // twice, and every part-paid order understated the shop's debt by its own deposit.
      const debit = totalCost;
      const credit = 0;
      let desc = '';
      if (netDebt > 0) {
        desc = amountPaid > 0
          ? `Stock supply order &bull; Gross: ${this.formatCurrency(totalCost)} | Deposit paid on order: ${this.formatCurrency(amountPaid)}${drawn > 0 ? ` | Drawn off balance: ${this.formatCurrency(drawn)}` : ''} | Added to Debt: +${this.formatCurrency(netDebt)}`
          : `Factory stock supply &bull; Gross: ${this.formatCurrency(totalCost)}${drawn > 0 ? ` | Drawn off balance: ${this.formatCurrency(drawn)}` : ''} | Added to Debt: +${this.formatCurrency(netDebt)}`;
      } else if (netDebt < 0) {
        desc = `Stock supply covered in advance &bull; Gross: ${this.formatCurrency(totalCost)} | Paid: ${this.formatCurrency(amountPaid)} | Advance held for delivery: ${this.formatCurrency(Math.abs(netDebt))}`;
      } else if (drawn > 0) {
        // Settled without the invoice leaving the drawer. Without this line the statement
        // bills GH₵180, shows GH₵160 against it and leaves the shopkeeper looking for a
        // GH₵20 that was paid for weeks ago.
        desc = `Stock supply settled &bull; Gross: ${this.formatCurrency(totalCost)} | Cash: ${this.formatCurrency(amountPaid)} | Drawn off balance held: ${this.formatCurrency(drawn)}`;
      } else {
        desc = `Stock supply paid in full &bull; ${this.formatCurrency(totalCost)}`;
      }

      transactions.push({
        date: po.order_date || po.created_at || 'N/A',
        timestamp: new Date(po.order_date || po.created_at || 0).getTime() || 0,
        type: 'PURCHASE',
        ref: po.order_number || po.id || 'PO-ORDER',
        purchase_id: po.id,
        purchase_data: po,
        description: desc,
        total_cost: totalCost,
        amount_paid: amountPaid,
        debit: debit,
        credit: credit
      });
    });

    payments.forEach(pay => {
      const pAmt = Number(pay.amount || 0);
      transactions.push({
        date: pay.payment_date || pay.created_at || 'N/A',
        timestamp: new Date(pay.payment_date || pay.created_at || 0).getTime() || 0,
        type: 'PAYMENT',
        ref: pay.reference_no || pay.id || 'PAYOUT',
        purchase_id: null,
        payment_data: pay,
        description: `Debt settlement payout (${this.escapeHtml(pay.payment_method || 'CASH')})${pay.notes ? ` &bull; ${this.escapeHtml(pay.notes)}` : ''}`,
        debit: 0,
        credit: pAmt
      });
    });

    // A number the shop carried in from its paper book is a line on this statement, with the
    // date it was read off the paper and the name of whoever typed it in. Until the account
    // could hold one, the only starting figure was a hole punched in vendors.balance, and the
    // line below had to guess at it after the fact.
    const carriedIn = Number(vendor.opening_amount || 0);
    if (Math.abs(carriedIn) >= 0.005) {
      const openStamp = vendor.opening_date || vendor.created_at || '';
      const openTime = openStamp ? (new Date(openStamp).getTime() || 0) : 0;
      transactions.push({
        date: openStamp ? new Date(openStamp).toLocaleDateString() : 'Account setup',
        timestamp: openTime,
        type: 'OPENING',
        ref: 'CARRY-IN',
        purchase_id: null,
        opening_data: {
          amount: carriedIn, note: vendor.opening_note || '',
          officer: vendor.opening_by || '', date: vendor.opening_date || ''
        },
        description: (carriedIn > 0
            ? `Balance carried in from the paper books &bull; ${this.formatCurrency(carriedIn)} owed before this shop kept the account`
            : `Advance carried in &bull; ${this.formatCurrency(Math.abs(carriedIn))} paid ahead of delivery before this shop kept the account`)
          + (vendor.opening_note ? ` &bull; ${this.escapeHtml(vendor.opening_note)}` : '')
          + (vendor.opening_by ? ` &bull; booked by ${this.escapeHtml(vendor.opening_by)}` : ''),
        debit: carriedIn > 0 ? carriedIn : 0,
        credit: carriedIn < 0 ? Math.abs(carriedIn) : 0,
        is_opening: true
      });
    }

    // Sort chronologically ascending
    transactions.sort((a, b) => a.timestamp - b.timestamp);

    // Reconcile with Vendor Balance via Opening Balance (Initial Debt)
    let totalDebtChange = 0;
    transactions.forEach(tx => {
      totalDebtChange += (tx.debit - tx.credit);
    });

    const currentVendorBalance = Number(vendor.balance || 0);
    const openingBalance = Math.round((currentVendorBalance - totalDebtChange) * 100) / 100;

    if (Math.abs(openingBalance) >= 0.01) {
      transactions.unshift({
        date: vendor.created_at ? new Date(vendor.created_at).toLocaleDateString() : 'Account Setup',
        timestamp: vendor.created_at ? new Date(vendor.created_at).getTime() - 86400000 : 0,
        type: 'OPENING',
        ref: 'OPENING-BAL',
        purchase_id: null,
        description: `Opening figure this book never recorded &bull; the gap between the account and the orders and payouts on these pages`,
        debit: openingBalance > 0 ? openingBalance : 0,
        credit: openingBalance < 0 ? Math.abs(openingBalance) : 0,
        is_opening: true
      });
    }

    let runningBal = 0;
    let totalBilled = 0;
    let totalSettled = 0;

    const ledgerRows = transactions.map((tx, idx) => {
      totalBilled += tx.debit;
      totalSettled += tx.credit;
      runningBal += (tx.debit - tx.credit);
      return {
        ...tx,
        running_balance: runningBal
      };
    });

    this._activeVendorStatementLedger = ledgerRows;

    const storeLogo = this.getStoreLogo();
    const shouldLogo = this.shouldPrintReceiptLogo();
    const storeName = this.storeProfile.store_name || 'My Store Enterprise';
    const finalBal = currentVendorBalance;

    printArea.innerHTML = `
      <div style="background: #fff; padding: 2rem; border-radius: var(--radius-md); box-shadow: var(--shadow-sm); font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; color: #1e293b;">
        <!-- Header -->
        <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #e2e8f0; padding-bottom: 1.5rem; margin-bottom: 1.5rem;">
          <div>
            ${shouldLogo && storeLogo ? `<img src="${this.escapeHtml(storeLogo)}" alt="Logo" class="receipt-logo" style="max-height: 48px; margin-bottom: 0.5rem; display: block;">` : ''}
            <h2 style="margin: 0; font-size: 1.35rem; color: #0f172a;">${this.escapeHtml(storeName)}</h2>
            <div style="font-size: 0.85rem; color: #64748b; margin-top: 0.2rem;">${this.escapeHtml(this.storeProfile.address || 'Central Commercial District')}</div>
            <div style="font-size: 0.85rem; color: #64748b;">Phone: ${this.escapeHtml(this.storeProfile.phone || '')} | Email: ${this.escapeHtml(this.storeProfile.email || '')}</div>
          </div>
          <div style="text-align: right;">
            <div style="font-size: 1.25rem; font-weight: 800; color: var(--primary); text-transform: uppercase; letter-spacing: 0.05em;">Supplier Statement of Account</div>
            <div style="font-size: 0.82rem; color: #64748b; margin-top: 0.25rem;">Issued: ${new Date().toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' })}</div>
            <div style="font-size: 0.82rem; font-weight: 600; color: #0f172a; margin-top: 0.25rem;">Terms: ${this.escapeHtml(vendor.payment_terms || 'NET 30')}</div>
          </div>
        </div>

        <!-- Supplier Info & Current Debt Due -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: var(--radius-md); padding: 1rem 1.25rem; margin-bottom: 1.25rem;">
          <div>
            <span style="font-size: 0.72rem; text-transform: uppercase; font-weight: 700; color: #64748b;">Factory / Vendor Beneficiary:</span>
            <div style="font-size: 1.15rem; font-weight: 800; color: #0f172a; margin-top: 0.15rem;">${this.escapeHtml(vendor.name)}</div>
            <div style="font-size: 0.85rem; color: #475569; margin-top: 0.2rem;">Contact: ${this.escapeHtml(vendor.contact_person || 'Accounts Payable Dept')}</div>
            <div style="font-size: 0.85rem; color: #475569;">Phone: ${this.escapeHtml(vendor.phone || 'N/A')}</div>
            ${vendor.bank_details ? `<div style="font-size: 0.8rem; color: #64748b; margin-top: 0.25rem;"><i class="fa-solid fa-building-columns"></i> ${this.escapeHtml(vendor.bank_details)}</div>` : ''}
          </div>
          <div style="text-align: right; display: flex; flex-direction: column; justify-content: center; align-items: flex-end;">
            <span style="font-size: 0.72rem; text-transform: uppercase; font-weight: 700; color: ${finalBal > 0 ? 'var(--danger)' : 'var(--success)'};">Account Status:</span>
            <div style="font-size: 1.65rem; font-weight: 900; color: ${finalBal > 0 ? 'var(--danger)' : 'var(--success)'}; margin-top: 0.1rem;">
              ${finalBal > 0 ? `DEBT: ${this.formatCurrency(finalBal)}` : (finalBal < 0 ? `CREDIT: ${this.formatCurrency(Math.abs(finalBal))}` : 'CLEARED (' + this.formatCurrency(0) + ')')}
            </div>
            <span style="font-size: 0.75rem; color: #64748b;">${finalBal > 0.01 ? 'Payment Due per supply terms' : (finalBal < -0.01 ? 'Advance held by the supplier against future deliveries' : 'Account in good standing / zero debt')}</span>
          </div>
        </div>

        <!-- 3 Reconciled Summary Cards -->
        <div class="statement-summary-grid" style="margin-bottom: 1.25rem;">
          <div class="statement-summary-card">
            <h5>Total Supplies Incurred</h5>
            <p style="color: #b91c1c;">${this.formatCurrency(totalBilled)}</p>
          </div>
          <div class="statement-summary-card">
            <h5>Total Payouts Settled</h5>
            <p style="color: #15803d;">${this.formatCurrency(totalSettled)}</p>
          </div>
          <div class="statement-summary-card">
            <h5>Current Accounts Payable Balance</h5>
            <p style="color: ${finalBal > 0 ? '#b91c1c' : '#15803d'}; font-weight: 800;">${this.formatCurrency(finalBal)}</p>
          </div>
        </div>

        <!-- Interactive Hint Banner -->
        <div style="background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; padding: 0.6rem 0.9rem; margin-bottom: 1rem; display: flex; align-items: center; justify-content: space-between; gap: 0.5rem; font-size: 0.8rem; color: #1e40af;">
          <div>
            <i class="fa-solid fa-hand-pointer" style="margin-right: 0.4rem; color: #2563eb;"></i>
            <strong>Interactive Breakdown:</strong> Click or tap on any transaction row below to inspect stocked items, unit costs, and purchase vouchers.
          </div>
          <span style="font-size: 0.72rem; color: #3b82f6; font-weight: 600;">Tap row to expand / collapse</span>
        </div>

        <!-- Ledger Table -->
        <div class="table-responsive" style="margin-bottom: 1.5rem; overflow-x: auto; -webkit-overflow-scrolling: touch;">
          <table class="statement-table" style="width: 100%; border-collapse: collapse; font-size: 0.82rem; table-layout: fixed; min-width: 820px;">
            <thead>
              <tr style="border-bottom: 2px solid #cbd5e1; background: #f1f5f9; text-align: left;">
                <th style="padding: 0.65rem 0.6rem; width: 14%; min-width: 95px;">Date</th>
                <th style="padding: 0.65rem 0.6rem; width: 15%; min-width: 120px;">Reference #</th>
                <th style="padding: 0.65rem 0.4rem; width: 9%; min-width: 75px;">Type</th>
                <th style="padding: 0.65rem 0.75rem; width: 26%; min-width: 170px;">Description / Supply Order</th>
                <th style="padding: 0.65rem 0.85rem; text-align: right; width: 12%; min-width: 110px;">Cost (+)</th>
                <th style="padding: 0.65rem 0.85rem; text-align: right; width: 12%; min-width: 110px;">Paid (-)</th>
                <th style="padding: 0.65rem 0.85rem; text-align: right; width: 12%; min-width: 115px;">Balance Due</th>
              </tr>
            </thead>
            <tbody>
              ${ledgerRows.length > 0 ? ledgerRows.map((tx, idx) => `
                <tr class="statement-ledger-row ${tx.is_opening ? 'statement-opening-row' : ''}"
                    onclick="app.toggleVendorStatementRowBreakdown(${idx})"
                    title="Tap to view how this order was recorded">
                  <td style="font-size: 0.78rem; word-break: break-word;">${this.escapeHtml(tx.date)}</td>
                  <td style="font-family: monospace; font-size: 0.78rem; font-weight: 700; color: var(--primary);">
                    <div style="display: flex; align-items: center; gap: 0.35rem;">
                      ${tx.purchase_id ? '<i class="fa-solid fa-truck-ramp-box" style="color: #2563eb; font-size: 0.8rem;"></i>' : (tx.is_opening ? '<i class="fa-solid fa-folder-open" style="color: #7c3aed; font-size: 0.8rem;"></i>' : '<i class="fa-solid fa-money-bill-wave" style="color: #16a34a; font-size: 0.8rem;"></i>')}
                      <span>${this.escapeHtml(tx.ref)}</span>
                      <i class="fa-solid fa-chevron-down" id="vendor-drawer-arrow-${idx}" style="font-size: 0.65rem; color: var(--slate-400); margin-left: auto; transition: transform 0.2s ease;"></i>
                    </div>
                  </td>
                  <td>
                    <span class="badge ${tx.debit > 0 ? 'badge-danger' : 'badge-success'}" style="font-size: 0.68rem; padding: 0.15rem 0.35rem; white-space: nowrap;">
                      ${this.escapeHtml(tx.type)}
                    </span>
                  </td>
                  <td style="font-size: 0.76rem; color: var(--slate-700); word-break: break-word; line-height: 1.35;">
                    ${tx.description}
                    <div style="font-size: 0.68rem; color: #4338ca; font-weight: 600; margin-top: 2px;">
                      <i class="fa-solid fa-caret-down"></i> Tap to inspect items &amp; breakdown
                    </div>
                  </td>
                  <td style="padding: 0.65rem 0.85rem; text-align: right; font-weight: 600; font-size: 0.78rem; font-variant-numeric: tabular-nums; color: ${tx.debit > 0 ? '#b91c1c' : 'var(--slate-400)'}; white-space: nowrap;">
                    ${tx.debit > 0 ? '+' + this.formatCurrency(tx.debit) : '-'}
                  </td>
                  <td style="padding: 0.65rem 0.85rem; text-align: right; font-weight: 600; font-size: 0.78rem; font-variant-numeric: tabular-nums; color: ${tx.credit > 0 ? '#15803d' : 'var(--slate-400)'}; white-space: nowrap;">
                    ${tx.credit > 0 ? '-' + this.formatCurrency(tx.credit) : '-'}
                  </td>
                  <td style="padding: 0.65rem 0.85rem; text-align: right; font-weight: 700; font-size: 0.8rem; font-variant-numeric: tabular-nums; color: ${tx.running_balance > 0 ? '#b91c1c' : '#15803d'}; white-space: nowrap;">
                    ${this.formatCurrency(tx.running_balance)}
                  </td>
                </tr>
                <!-- Expandable Drawer for Vendor Transaction -->
                <tr id="vendor-drawer-row-${idx}" class="statement-drawer-row" style="display: none;">
                  <td colspan="7" style="padding: 0.85rem 1rem; border-top: 1px dashed var(--slate-200); border-bottom: 2px solid var(--slate-300); background: #f8fafc;">
                    <div id="vendor-drawer-content-${idx}">
                      <div style="text-align: center; padding: 0.5rem; color: var(--slate-400); font-size: 0.8rem;">
                        <i class="fa-solid fa-spinner fa-spin"></i> Loading supply order breakdown...
                      </div>
                    </div>
                  </td>
                </tr>
              `).join('') : `
                <tr>
                  <td colspan="7" style="text-align: center; padding: 2rem; color: #94a3b8;">
                    No ledger transactions recorded yet for this supplier.
                  </td>
                </tr>
              `}
            </tbody>
          </table>
        </div>

        <!-- Footer Sign-off -->
        <div style="display: flex; justify-content: space-between; align-items: flex-end; border-top: 1px solid #e2e8f0; padding-top: 1.5rem; margin-top: 1.5rem;">
          <div>
            <div style="font-size: 0.75rem; color: #94a3b8;">Authorized Finance & Audit Stamp</div>
            <div style="border-bottom: 1px dashed #cbd5e1; width: 180px; height: 35px; margin-top: 0.5rem;"></div>
            <div style="font-size: 0.75rem; color: #64748b; margin-top: 0.35rem;">StoreFlow Audit Officer</div>
          </div>
          <div style="text-align: right; font-size: 0.78rem; color: #94a3b8;">
            <div>Automated Enterprise Supply Chain System</div>
            <div>Generated by StoreFlow POS</div>
          </div>
        </div>
      </div>
    `;
  }

  async toggleVendorStatementRowBreakdown(index) {
    const drawerRow = document.getElementById(`vendor-drawer-row-${index}`);
    const arrow = document.getElementById(`vendor-drawer-arrow-${index}`);
    const content = document.getElementById(`vendor-drawer-content-${index}`);
    if (!drawerRow || !this._activeVendorStatementLedger) return;

    const isOpen = drawerRow.style.display !== 'none';
    if (isOpen) {
      drawerRow.style.display = 'none';
      if (arrow) arrow.style.transform = 'rotate(0deg)';
      return;
    }

    drawerRow.style.display = 'table-row';
    if (arrow) arrow.style.transform = 'rotate(180deg)';

    const row = this._activeVendorStatementLedger[index];
    if (!row) return;

    if (row.is_opening) {
      const booked = row.opening_data;
      if (booked) {
        content.innerHTML = `
          <div style="background: #faf5ff; border: 1px solid #e9d5ff; border-radius: 8px; padding: 0.75rem 1rem;">
            <div style="font-weight: 700; color: #6b21a8; font-size: 0.85rem; margin-bottom: 0.25rem;">
              <i class="fa-solid fa-folder-open"></i> Balance carried in on this account
            </div>
            <p style="font-size: 0.8rem; color: #4c1d95; margin: 0 0 0.35rem 0; line-height: 1.4;">
              <strong>${this.formatCurrency(Math.abs(Number(booked.amount || 0)))}</strong> of
              ${Number(booked.amount || 0) > 0 ? 'debt this shop owed' : 'money this shop had paid ahead'}
              when it started keeping this account, booked
              ${this.escapeHtml(booked.date ? new Date(booked.date).toLocaleDateString() : 'at account setup')}
              by <strong>${this.escapeHtml(booked.officer || 'Staff')}</strong>.
            </p>
            <p style="font-size: 0.78rem; color: #6d28d9; margin: 0; line-height: 1.4;">
              ${booked.note ? `<em>&quot;${this.escapeHtml(booked.note)}&quot;</em>` : 'No note was recorded with it.'}
            </p>
          </div>
        `;
        return;
      }
      content.innerHTML = `
        <div style="background: #faf5ff; border: 1px solid #e9d5ff; border-radius: 8px; padding: 0.75rem 1rem;">
          <div style="font-weight: 700; color: #6b21a8; font-size: 0.85rem; margin-bottom: 0.25rem;">
            <i class="fa-solid fa-folder-open"></i> Supplier Opening Debt Balance
          </div>
          <p style="font-size: 0.8rem; color: #4c1d95; margin: 0; line-height: 1.4;">
            This account carries <strong>${this.formatCurrency(row.debit || row.credit)}</strong> that no order, payout or booked opening balance on these pages accounts for. Book the real figure as an opening balance on the supplier and this line goes away.
          </p>
        </div>
      `;
      return;
    }

    if (row.payment_data) {
      const p = row.payment_data;
      content.innerHTML = `
        <div style="background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 0.75rem 1rem; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.75rem;">
          <div>
            <div style="font-weight: 700; color: #166534; font-size: 0.85rem; margin-bottom: 0.25rem;">
              <i class="fa-solid fa-circle-check"></i> Supplier Payout / Settlement Slip
            </div>
            <div style="font-size: 0.8rem; color: #15803d; line-height: 1.4;">
              <strong>Payment Method:</strong> ${this.escapeHtml(p.payment_method || 'CASH')} &bull; 
              <strong>Amount Paid Out:</strong> ${this.formatCurrency(p.amount || row.credit)} &bull; 
              <strong>Notes / Ref:</strong> ${this.escapeHtml(p.notes || p.reference_no || 'None recorded')}
            </div>
          </div>
          <div>
            <span class="badge badge-success" style="padding: 0.35rem 0.65rem; font-size: 0.78rem;">
              <i class="fa-solid fa-check"></i> Disbursed
            </span>
          </div>
        </div>
      `;
      return;
    }

    if (row.purchase_id) {
      content.innerHTML = `
        <div style="text-align: center; padding: 0.75rem; color: var(--slate-500); font-size: 0.8rem;">
          <i class="fa-solid fa-spinner fa-spin"></i> Loading itemized supply items...
        </div>
      `;

      let po = this.purchases.find(p => p.id === row.purchase_id) || row.purchase_data;
      if (!po || !po.items || po.items.length === 0) {
        if (this.isOnline) {
          try {
            const res = await this.apiFetch(`api/endpoints/purchases.php?id=${encodeURIComponent(row.purchase_id)}`);
            const json = await res.json();
            if (json.success && json.purchase) {
              po = json.purchase;
              const idx = this.purchases.findIndex(p => p.id === row.purchase_id);
              if (idx >= 0) this.purchases[idx] = po;
            }
          } catch (e) { }
        }
      }

      const items = (po && Array.isArray(po.items)) ? po.items : [];
      const totalCost = Number(po?.total_cost || row.total_cost || row.debit);
      const amountPaid = Number(po?.amount_paid || row.amount_paid || 0);
      const drawnOnOrder = Number(po?.credit_used || row.credit_used || 0);
      // The account really does move by the whole difference - the drawn credit is the reason
      // a +20 move lands on a -20 balance and closes it rather than opening a debt - so the
      // figure stays signed and only the colour says which way it left the shop settled.
      const debtAdded = Math.round((totalCost - amountPaid) * 100) / 100;
      const stillToPay = Math.round((totalCost - amountPaid - drawnOnOrder) * 100) / 100;
      const closedByBalance = drawnOnOrder > 0.005 && stillToPay <= 0.005;

      content.innerHTML = `
        <div style="background: #ffffff; border: 1px solid var(--slate-300); border-radius: 8px; padding: 0.85rem; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
          <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--slate-200); padding-bottom: 0.5rem; margin-bottom: 0.65rem; flex-wrap: wrap; gap: 0.5rem;">
            <div>
              <span style="font-weight: 800; color: var(--slate-900); font-size: 0.9rem;">
                <i class="fa-solid fa-truck-ramp-box" style="color: #2563eb; margin-right: 0.35rem;"></i>
                Purchase Order #${this.escapeHtml(po?.order_number || row.ref)}
              </span>
              <span style="font-size: 0.75rem; color: var(--slate-500); margin-left: 0.5rem;">
                <i class="fa-solid fa-calendar-day"></i> ${this.escapeHtml(po?.order_date || row.date)} &bull; Status: ${this.escapeHtml(po?.payment_status || 'COMPLETED')}
              </span>
            </div>
            <div>
              <button type="button" class="btn btn-sm btn-primary" onclick="event.stopPropagation(); app.openPurchaseVoucherModal(${this.jsStr(row.purchase_id)})" style="padding: 0.35rem 0.75rem; font-size: 0.78rem;">
                <i class="fa-solid fa-file-invoice-dollar"></i> Open Purchase Voucher
              </button>
            </div>
          </div>

          <!-- Items Table -->
          <table style="width: 100%; font-size: 0.78rem; border-collapse: collapse; margin-bottom: 0.75rem;">
            <thead>
              <tr style="background: var(--slate-50); color: var(--slate-600); border-bottom: 1px solid var(--slate-200);">
                <th style="padding: 0.35rem 0.5rem; text-align: left;">Stocked Product Item</th>
                <th style="padding: 0.35rem 0.5rem; text-align: center; width: 14%;">Quantity</th>
                <th style="padding: 0.35rem 0.5rem; text-align: right; width: 18%;">Unit Cost</th>
                <th style="padding: 0.35rem 0.5rem; text-align: left; width: 22%;">Batch / Expiry</th>
                <th style="padding: 0.35rem 0.5rem; text-align: right; width: 18%;">Total Cost</th>
              </tr>
            </thead>
            <tbody>
              ${items.length > 0 ? items.map(it => {
                const prodName = it.product_name || it.name || (this.products.find(p => String(p.id) === String(it.product_id))?.name) || 'Stock Item';
                const qty = Number(it.quantity || 1);
                const unitCost = Number(it.cost_price || it.unit_cost_price || 0);
                const lineTotal = Number(it.subtotal || (qty * unitCost));
                const batchNum = it.batch_number ? it.batch_number : null;
                const expDate = it.expiry_date ? it.expiry_date : null;

                return `
                  <tr style="border-bottom: 1px solid var(--slate-100);">
                    <td style="padding: 0.4rem 0.5rem; font-weight: 600; color: var(--slate-800);">${this.escapeHtml(prodName)}</td>
                    <td style="padding: 0.4rem 0.5rem; text-align: center;">${qty} ${this.escapeHtml(it.unit || 'pcs')}</td>
                    <td style="padding: 0.4rem 0.5rem; text-align: right; font-family: monospace;">${this.formatCurrency(unitCost)}</td>
                    <td style="padding: 0.4rem 0.5rem; font-size: 0.72rem; color: var(--slate-500);">
                      ${batchNum ? `<span>Lot: ${this.escapeHtml(batchNum)}</span>` : ''}
                      ${expDate ? `<span style="margin-left: 0.25rem; color: #c2410c;">Exp: ${this.escapeHtml(expDate)}</span>` : (!batchNum ? '<span style="color: var(--slate-400);">-</span>' : '')}
                    </td>
                    <td style="padding: 0.4rem 0.5rem; text-align: right; font-weight: 700; font-family: monospace;">${this.formatCurrency(lineTotal)}</td>
                  </tr>
                `;
              }).join('') : `
                <tr>
                  <td colspan="5" style="text-align: center; padding: 0.5rem; color: var(--slate-400);">
                    Itemized details stored under Purchase Order #${this.escapeHtml(po?.order_number || row.ref)}
                  </td>
                </tr>
              `}
            </tbody>
          </table>

          <!-- Financial Breakdown Summary Bar -->
          <div style="background: var(--slate-50); border: 1px solid var(--slate-200); border-radius: 6px; padding: 0.5rem 0.75rem; display: flex; justify-content: space-between; align-items: center; font-size: 0.8rem; flex-wrap: wrap; gap: 0.5rem;">
            <div>
              <span style="color: var(--slate-500);">Total Order Cost:</span>
              <strong style="color: var(--slate-900); font-family: monospace; margin-left: 0.25rem;">${this.formatCurrency(totalCost)}</strong>
            </div>
            <div>
              <span style="color: var(--slate-500);">Paid on Order / Delivery:</span>
              <strong style="color: #15803d; font-family: monospace; margin-left: 0.25rem;">${this.formatCurrency(amountPaid)}</strong>
            </div>
            ${drawnOnOrder > 0.005 ? `
            <div>
              <span style="color: var(--slate-500);">Drawn off balance held:</span>
              <strong style="color: #0369a1; font-family: monospace; margin-left: 0.25rem;">${this.formatCurrency(drawnOnOrder)}</strong>
            </div>` : ''}
            <div>
              <span style="color: var(--slate-500);">Added to Supplier Balance:</span>
              <strong style="color: ${closedByBalance ? '#0369a1' : (debtAdded > 0 ? '#b91c1c' : '#15803d')}; font-family: monospace; font-size: 0.88rem; margin-left: 0.25rem;">
                ${debtAdded > 0 ? '+' + this.formatCurrency(debtAdded) : (debtAdded < 0 ? '-' + this.formatCurrency(Math.abs(debtAdded)) : this.formatCurrency(0))}
              </strong>
            </div>
          </div>
        </div>
      `;
    }
  }

  async openPurchaseVoucherModal(purchaseId) {
    const modal = document.getElementById('purchase-voucher-modal');
    const container = document.getElementById('printable-purchase-voucher-area');
    if (!modal || !container) return;

    let po = this.purchases.find(p => p.id === purchaseId);
    // The list now travels with the order's sizes but not its per-unit cost, so a row that
    // already has lines only asks the server for the full record when it is online. Offline
    // the lines it has are enough to print what was bought - which is the whole point of a
    // till that keeps working when the cable is out.
    const hasLines = p => !!p && ((Array.isArray(p.items) && p.items.length > 0) || (Array.isArray(p.lines) && p.lines.length > 0));
    if (!hasLines(po)) {
      if (this.isOnline) {
        try {
          const res = await this.apiFetch(`api/endpoints/purchases.php?id=${encodeURIComponent(purchaseId)}`);
          const json = await res.json();
          if (json.success && json.purchase) {
            po = json.purchase;
            const idx = this.purchases.findIndex(p => p.id === purchaseId);
            if (idx >= 0) this.purchases[idx] = po;
          }
        } catch (e) { }
      }
    }

    if (!po) return;

    const items = (Array.isArray(po.items) && po.items.length) ? po.items : (Array.isArray(po.lines) ? po.lines : []);
    const prof = this.storeProfile;
    const storeLogo = this.getStoreLogo();
    const shouldLogo = this.shouldPrintReceiptLogo();
    const totalCost = Number(po.total_cost || 0);
    const amountPaid = Number(po.amount_paid || 0);
    const drawnFromBalance = Number(po.credit_used || 0);
    // Signed, because the paper has to say which way the difference runs. Clamping this to
    // zero is what made a GH₵700,000 deposit on a GH₵660,000 order print "Remaining Debt
    // Due: $0.00" in green - the very sentence that told the shopkeeper nobody owed him.
    const accountBalance = Math.round((totalCost - amountPaid - drawnFromBalance) * 100) / 100;

    container.innerHTML = `
      <div style="background: #ffffff; padding: 1.5rem; border-radius: 8px; border: 1px solid var(--slate-200); font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; color: #0f172a;">
        <!-- Voucher Header -->
        <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #e2e8f0; padding-bottom: 1rem; margin-bottom: 1rem;">
          <div>
            ${shouldLogo && storeLogo ? `<img src="${this.escapeHtml(storeLogo)}" alt="Logo" style="max-height: 44px; margin-bottom: 0.35rem; display: block;">` : ''}
            <h3 style="margin: 0; font-size: 1.2rem; color: #0f172a; font-weight: 800;">${this.escapeHtml(prof.store_name || 'StoreFlow')}</h3>
            <div style="font-size: 0.8rem; color: #64748b;">${this.escapeHtml(prof.address || '')}</div>
            <div style="font-size: 0.8rem; color: #64748b;">Phone: ${this.escapeHtml(prof.phone || '')}</div>
          </div>
          <div style="text-align: right;">
            <div style="font-size: 1rem; font-weight: 800; color: var(--primary); text-transform: uppercase;">Purchase Order Voucher</div>
            <div style="font-family: monospace; font-size: 0.85rem; font-weight: 700; color: #0f172a; margin-top: 0.15rem;">#${this.escapeHtml(po.order_number || po.id)}</div>
            <div style="font-size: 0.78rem; color: #64748b; margin-top: 0.15rem;">Order Date: ${this.escapeHtml(po.order_date || 'N/A')}</div>
          </div>
        </div>

        <!-- Supplier & Delivery Info -->
        <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 0.75rem 1rem; margin-bottom: 1rem; font-size: 0.82rem;">
          <div><strong>Supplier / Vendor:</strong> ${this.escapeHtml(po.supplier_name || 'Factory Supplier')}</div>
          ${po.supplier_contact ? `<div style="margin-top: 0.15rem;"><strong>Contact:</strong> ${this.escapeHtml(po.supplier_contact)}</div>` : ''}
          ${po.notes ? `<div style="margin-top: 0.15rem; color: #64748b;"><strong>Notes:</strong> ${this.escapeHtml(po.notes)}</div>` : ''}
        </div>

        <!-- Items Table -->
        <table style="width: 100%; border-collapse: collapse; font-size: 0.8rem; margin-bottom: 1rem;">
          <thead>
            <tr style="background: #f1f5f9; border-bottom: 1px solid #cbd5e1; text-align: left;">
              <th style="padding: 0.45rem 0.5rem;">Product Item</th>
              <th style="padding: 0.45rem 0.5rem; text-align: center; width: 14%;">Qty</th>
              <th style="padding: 0.45rem 0.5rem; text-align: right; width: 20%;">Cost Price</th>
              <th style="padding: 0.45rem 0.5rem; text-align: right; width: 22%;">Total</th>
            </tr>
          </thead>
          <tbody>
            ${items.map(it => {
              const name = it.product_name || it.name || 'Stock Item';
              const qty = Number(it.quantity || 1);
              const sub = Number(it.subtotal || 0);
              // A purchase row straight off the list carries the line total but not the price
              // per size, so the paper works that back out of the two rather than printing
              // GH₵0.00 beside a crate the shop paid three thousand for.
              const cost = Number((it.cost_price === undefined || it.cost_price === null || it.cost_price === '')
                ? (qty > 0 ? sub / qty : 0) : it.cost_price);
              const lineTotal = sub || (qty * cost);
              const sizeLabel = String(it.unit || it.base_unit || 'pcs').trim() || 'pcs';
              const mult = Math.max(1, Number(it.multiplier || 1));
              // The voucher goes back to the supplier, so it has to read the way the order
              // was placed - five crates - and the loose count in brackets is what tells the
              // shop's own stock check what those five were worth on the shelf.
              const looseEquiv = mult > 1
                ? ` <span style="font-size: 0.72rem; color: #64748b;">(= ${this.escapeHtml(String(parseFloat((qty * mult).toFixed(3))))} ${this.escapeHtml(it.base_unit || '')})</span>`
                : '';
              return `
                <tr style="border-bottom: 1px solid #f1f5f9;">
                  <td style="padding: 0.45rem 0.5rem; font-weight: 600;">${this.escapeHtml(name)}</td>
                  <td style="padding: 0.45rem 0.5rem; text-align: center;">${qty} ${this.escapeHtml(sizeLabel)}${looseEquiv}</td>
                  <td style="padding: 0.45rem 0.5rem; text-align: right; font-family: monospace;">${this.formatCurrency(cost)}</td>
                  <td style="padding: 0.45rem 0.5rem; text-align: right; font-weight: 700; font-family: monospace;">${this.formatCurrency(lineTotal)}</td>
                </tr>
              `;
            }).join('')}
          </tbody>
        </table>

        <!-- Totals Strip -->
        <div style="border-top: 2px solid #e2e8f0; padding-top: 0.65rem; display: flex; flex-direction: column; align-items: flex-end; gap: 0.35rem; font-size: 0.82rem;">
          <div>Gross Order Total: <strong style="font-family: monospace; font-size: 0.95rem;">${this.formatCurrency(totalCost)}</strong></div>
          <div>Amount Paid: <strong style="color: #15803d; font-family: monospace;">${this.formatCurrency(amountPaid)}</strong></div>
          ${drawnFromBalance > 0.005 ? `<div style="color: #0369a1;">Drawn off balance held: <strong style="font-family: monospace;">${this.formatCurrency(drawnFromBalance)}</strong></div>` : ''}
          <div style="font-size: 0.9rem; font-weight: 800; color: ${accountBalance > 0.005 ? '#dc2626' : accountBalance < -0.005 ? '#1d4ed8' : '#15803d'};">
            ${accountBalance > 0.005
              ? `Remaining Debt Due: ${this.formatCurrency(accountBalance)}`
              : accountBalance < -0.005
                ? `Advance Held With Supplier: ${this.formatCurrency(Math.abs(accountBalance))}`
                : `Balance Owing: ${this.formatCurrency(0)} &mdash; Paid in Full`}
          </div>
        </div>
      </div>
    `;

    modal.classList.add('active');
  }

  closePurchaseVoucherModal() {
    const modal = document.getElementById('purchase-voucher-modal');
    if (modal) modal.classList.remove('active');
  }

  printPurchaseVoucher() {
    window.print();
  }

  closeVendorStatementModal() {
    document.getElementById('vendor-statement-modal').classList.remove('active');
  }

  printVendorStatement() {
    const printArea = document.getElementById('printable-vendor-statement-area');
    if (!printArea) return;

    const printWin = window.open('', '_blank', 'width=880,height=720');
    if (!printWin) {
      window.print();
      return;
    }

    printWin.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Supplier Statement - ${this.escapeHtml(this.currentVendorForStatement?.name || 'Vendor')}</title>
        <style>
          @page { size: letter; margin: 15mm; }
          body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 10px; color: #0f172a; }
          table { width: 100%; border-collapse: collapse; }
          th, td { padding: 8px; border-bottom: 1px solid #e2e8f0; }
          th { background: #f8fafc; font-weight: 700; }
          .receipt-logo { filter: grayscale(100%) contrast(140%); max-height: 48px; }
        </style>
      </head>
      <body>
        ${printArea.innerHTML}
        <script>
          window.onload = function() { window.print(); window.close(); };
        </script>
      </body>
      </html>
    `);
    printWin.document.close();
  }

  // --- Inventory & Stock Control ---

  setInventoryBranchFilter(branchCode) {
    this.inventoryBranchFilter = branchCode;
    this.fetchInventory().then(() => {
      this.renderCurrentView();
    });
  }

  getProductStockAtBranch(productId, branchCode) {
    const prod = this.products.find(p => p.id === productId);
    if (!prod) return 0;
    if (!this.isMultiBranch) return Number(prod.current_quantity || 0);

    const bCode = (branchCode || 'MAIN-01').toUpperCase();
    if (prod.branch_settings && Array.isArray(prod.branch_settings)) {
      const bs = prod.branch_settings.find(s => (s.branch_code || '').toUpperCase() === bCode);
      if (bs && bs.current_quantity !== undefined && bs.current_quantity !== null) {
        return Number(bs.current_quantity);
      }
    }
    return 0;
  }

  getInventoryHTML() {
    const isFilteredBranch = this.isMultiBranch && this.inventoryBranchFilter && this.inventoryBranchFilter !== 'ALL';
    const activeBranchName = isFilteredBranch
      ? (this.branches.find(b => b.branch_code === this.inventoryBranchFilter)?.name || this.inventoryBranchFilter)
      : 'All Branches (Consolidated)';

    let totalStockUnits = 0;
    let totalCostVal = 0;
    let totalRetailVal = 0;
    let lowStockCount = 0;
    let outOfStockCount = 0;

    const computedItems = this.products.map(p => {
      let qty = 0;
      let price = Number(p.selling_price || 0);
      let isAvail = true;
      let hasCustomPrice = false;

      if (isFilteredBranch) {
        const bSetting = (p.branch_settings && Array.isArray(p.branch_settings))
          ? p.branch_settings.find(bs => (bs.branch_code || '').toUpperCase() === this.inventoryBranchFilter.toUpperCase())
          : null;
        qty = bSetting ? Number(bSetting.current_quantity || 0) : 0;
        if (bSetting && bSetting.custom_selling_price !== null && bSetting.custom_selling_price !== '') {
          price = Number(bSetting.custom_selling_price);
          hasCustomPrice = true;
        }
        if (bSetting && bSetting.is_available !== undefined && bSetting.is_available !== null) {
          isAvail = Number(bSetting.is_available) === 1;
        }
      } else {
        qty = Number(p.current_quantity || 0);
      }

      const cost = Number(p.cost_price || 0);
      const minAlert = Number(p.min_stock_alert || 5);
      const isOut = qty <= 0;
      const isLow = qty > 0 && qty <= minAlert;

      totalStockUnits += qty;
      totalCostVal += (qty * cost);
      totalRetailVal += (qty * price);
      if (isOut) outOfStockCount++;
      else if (isLow) lowStockCount++;

      return {
        product: p,
        qty,
        cost,
        price,
        hasCustomPrice,
        isAvail,
        isOut,
        isLow,
        costValuation: qty * cost,
        retailValuation: qty * price
      };
    });

    // ── Live Inventory Filtering & Sorting ──────────────────────────────────
    let filteredItems = [...computedItems];

    const q = (this.invSearchQuery || '').trim().toLowerCase();
    if (q) {
      filteredItems = filteredItems.filter(item => {
        const name = (item.product.name || '').toLowerCase();
        const sku = (item.product.sku || '').toLowerCase();
        const barcode = (item.product.barcode || '').toLowerCase();
        const cat = (item.product.category || '').toLowerCase();
        return name.includes(q) || sku.includes(q) || barcode.includes(q) || cat.includes(q);
      });
    }

    if (this.invStatusFilter === 'IN_STOCK') {
      filteredItems = filteredItems.filter(item => !item.isOut && !item.isLow);
    } else if (this.invStatusFilter === 'LOW') {
      filteredItems = filteredItems.filter(item => item.isLow);
    } else if (this.invStatusFilter === 'OUT') {
      filteredItems = filteredItems.filter(item => item.qty === 0);
    } else if (this.invStatusFilter === 'NEGATIVE') {
      filteredItems = filteredItems.filter(item => item.qty < 0);
    }

    if (this.invCatFilter && this.invCatFilter !== 'ALL') {
      filteredItems = filteredItems.filter(item => (item.product.category || 'General').toLowerCase() === this.invCatFilter.toLowerCase());
    }

    const sort = this.invSortFilter || 'NAME';
    if (sort === 'STOCK_ASC') {
      filteredItems.sort((a, b) => a.qty - b.qty);
    } else if (sort === 'STOCK_DESC') {
      filteredItems.sort((a, b) => b.qty - a.qty);
    } else if (sort === 'RETAIL_DESC') {
      filteredItems.sort((a, b) => b.retailValuation - a.retailValuation);
    } else if (sort === 'COST_DESC') {
      filteredItems.sort((a, b) => b.costValuation - a.costValuation);
    } else {
      filteredItems.sort((a, b) => (a.product.name || '').localeCompare(b.product.name || ''));
    }

    const hasActiveInvFilters = Boolean(
      (this.invSearchQuery && this.invSearchQuery.trim()) ||
      (this.invStatusFilter && this.invStatusFilter !== 'ALL') ||
      (this.invCatFilter && this.invCatFilter !== 'ALL') ||
      (this.invSortFilter && this.invSortFilter !== 'NAME')
    );

    return `
      <div class="panel">
        <div class="panel-header" style="flex-wrap: wrap; gap: 0.75rem;">
          <div>
            <h3><i class="fa-solid fa-boxes-stacked"></i> Live Inventory Stock Control</h3>
            <p style="font-size: 0.8rem; color: var(--slate-500); margin: 0.2rem 0 0 0;">
              Active View: <strong>${this.escapeHtml(activeBranchName)}</strong>
            </p>
          </div>
          <div style="display: flex; gap: 0.5rem; align-items: center; flex-wrap: wrap;">
            ${this.isMultiBranch ? `
              <div style="display: flex; align-items: center; gap: 0.4rem; background: var(--slate-100); padding: 0.3rem 0.6rem; border-radius: 6px; border: 1px solid var(--slate-200);">
                <i class="fa-solid fa-store" style="color: var(--primary); font-size: 0.85rem;"></i>
                <label for="inventory-branch-filter" style="font-size: 0.8rem; font-weight: 600; color: var(--slate-700); margin: 0;">Branch:</label>
                <select id="inventory-branch-filter" class="form-control" style="width: auto; padding: 0.25rem 0.5rem; font-size: 0.85rem; font-weight: 600;" onchange="app.setInventoryBranchFilter(this.value)">
                  <option value="ALL" ${this.inventoryBranchFilter === 'ALL' ? 'selected' : ''}>All Branches (Consolidated)</option>
                  ${this.branches.map(b => `
                    <option value="${this.escapeHtml(b.branch_code)}" ${this.inventoryBranchFilter === b.branch_code ? 'selected' : ''}>
                      ${this.escapeHtml(b.name)} (${this.escapeHtml(b.branch_code)})
                    </option>
                  `).join('')}
                </select>
              </div>

              <button class="btn btn-outline" onclick="app.openStockAuditModal()" style="font-size: 0.85rem; font-weight: 700; color: #0284c7; border-color: #bae6fd; background: #f0f9ff;" title="Open live stocktaking & variance audit">
                <i class="fa-solid fa-clipboard-check"></i> Stocktake Audit
              </button>
              <button class="btn btn-primary" onclick="app.openTransferModal()" style="font-size: 0.85rem;">
                <i class="fa-solid fa-truck-arrow-right"></i> Transfer Stock
              </button>
            ` : ''}

            <button class="btn btn-outline" onclick="app.openStockAdjustmentModal()" style="font-size: 0.85rem;">
              <i class="fa-solid fa-sliders"></i> Adjust Stock (+/-)
            </button>

            <button class="btn btn-outline" onclick="app.switchView('batches')" style="font-size: 0.85rem; color: #ea580c; border-color: #fed7aa; background: #fff7ed;" title="Open batch & expiry tracking">
              <i class="fa-solid fa-boxes-packing"></i> Batches & Expiry ${this.batchesSummary?.expired_count > 0 ? `<span class="badge badge-danger" style="margin-left: 0.35rem; font-size: 0.72rem; padding: 0.15rem 0.4rem; font-weight: 800;">${this.batchesSummary.expired_count} Expired</span>` : ''}
            </button>
          </div>
        </div>

        <div class="panel-body">
          <!-- Expiry Alert Banner -->
          ${this.batchesSummary && this.batchesSummary.expired_count > 0 ? `
            <div style="background: #fef2f2; border: 1.5px solid #fecaca; border-radius: 8px; padding: 0.85rem 1.15rem; margin-bottom: 1rem; display: flex; align-items: center; justify-content: space-between; gap: 0.75rem; flex-wrap: wrap;">
              <div style="display: flex; align-items: center; gap: 0.65rem;">
                <div style="width: 36px; height: 36px; border-radius: 50%; background: #fee2e2; display: flex; align-items: center; justify-content: center; color: #dc2626; font-size: 1.1rem; flex-shrink: 0;">
                  <i class="fa-solid fa-triangle-exclamation"></i>
                </div>
                <div>
                  <div style="font-weight: 800; color: #991b1b; font-size: 0.92rem;">
                    ${this.batchesSummary.expired_count} Perishable ${this.batchesSummary.expired_count === 1 ? 'batch has' : 'batches have'} EXPIRED on shelves!
                  </div>
                  <div style="font-size: 0.78rem; color: #b91c1c;">
                    Total ${this.batchesSummary.expired_units} units (${this.formatCurrency(this.batchesSummary.expired_cost)} at risk). Immediate quarantine or write-off recommended.
                  </div>
                </div>
              </div>
              <button class="btn btn-danger btn-sm" onclick="app.switchView('batches'); app.setBatchFilter('expired');" style="font-weight: 700; white-space: nowrap;">
                <i class="fa-solid fa-dumpster-fire"></i> Review & Write Off Expired
              </button>
            </div>
          ` : ''}

          <!-- Summary Metrics Cards -->
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 0.75rem; margin-bottom: 1.25rem;">
            <div style="background: var(--slate-50); border: 1px solid var(--slate-200); border-radius: 8px; padding: 0.75rem 1rem;">
              <div style="font-size: 0.75rem; color: var(--slate-500); text-transform: uppercase; font-weight: 700;">Stock Units On Hand</div>
              <div style="font-size: 1.4rem; font-weight: 800; color: var(--slate-800); margin-top: 0.2rem;">${totalStockUnits.toLocaleString()}</div>
            </div>
            <div style="background: var(--slate-50); border: 1px solid var(--slate-200); border-radius: 8px; padding: 0.75rem 1rem;">
              <div style="font-size: 0.75rem; color: var(--slate-500); text-transform: uppercase; font-weight: 700;">Inventory Cost Valuation</div>
              <div style="font-size: 1.4rem; font-weight: 800; color: var(--slate-700); margin-top: 0.2rem;">${this.formatCurrency(totalCostVal)}</div>
            </div>
            <div style="background: var(--slate-50); border: 1px solid var(--slate-200); border-radius: 8px; padding: 0.75rem 1rem;">
              <div style="font-size: 0.75rem; color: var(--slate-500); text-transform: uppercase; font-weight: 700;">Retail Valuation</div>
              <div style="font-size: 1.4rem; font-weight: 800; color: var(--primary); margin-top: 0.2rem;">${this.formatCurrency(totalRetailVal)}</div>
            </div>
            <div style="background: var(--slate-50); border: 1px solid var(--slate-200); border-radius: 8px; padding: 0.75rem 1rem;">
              <div style="font-size: 0.75rem; color: var(--slate-500); text-transform: uppercase; font-weight: 700;">Stock Alerts</div>
              <div style="display: flex; gap: 0.5rem; align-items: center; margin-top: 0.2rem;">
                <span class="badge ${lowStockCount > 0 ? 'badge-warning' : 'badge-neutral'}" style="font-size: 0.82rem;">
                  <i class="fa-solid fa-triangle-exclamation"></i> ${lowStockCount} Low
                </span>
                <span class="badge ${outOfStockCount > 0 ? 'badge-danger' : 'badge-neutral'}" style="font-size: 0.82rem;">
                  <i class="fa-solid fa-circle-xmark"></i> ${outOfStockCount} Out
                </span>
              </div>
            </div>
          </div>

          <!-- Comprehensive Live Inventory Filter Bar -->
          <div style="background: var(--slate-50); border: 1px solid var(--slate-200); border-radius: 8px; padding: 0.85rem 1rem; margin-bottom: 1.25rem; display: flex; flex-wrap: wrap; gap: 0.75rem; align-items: center; justify-content: space-between;">
            <div style="display: flex; gap: 0.65rem; flex-wrap: wrap; align-items: center; flex: 1;">
              <!-- Search Input -->
              <div style="position: relative; min-width: 250px; flex: 1;">
                <i class="fa-solid fa-magnifying-glass" style="position: absolute; left: 0.75rem; top: 50%; transform: translateY(-50%); color: var(--slate-400); font-size: 0.85rem;"></i>
                <input type="text" id="inventory-search-input" class="form-control" placeholder="Search product name, SKU, or barcode..." style="padding-left: 2.1rem;" value="${this.escapeHtml(this.invSearchQuery || '')}">
              </div>
              <!-- Stock Status Filter -->
              <select id="inventory-status-filter" class="form-control" style="width: auto; min-width: 160px; font-weight: 600;">
                <option value="ALL" ${(!this.invStatusFilter || this.invStatusFilter === 'ALL') ? 'selected' : ''}>All Stock Statuses</option>
                <option value="IN_STOCK" ${this.invStatusFilter === 'IN_STOCK' ? 'selected' : ''}>In Stock (> Alert)</option>
                <option value="LOW" ${this.invStatusFilter === 'LOW' ? 'selected' : ''}>Low Stock Alert</option>
                <option value="OUT" ${this.invStatusFilter === 'OUT' ? 'selected' : ''}>Out of Stock (0)</option>
                <option value="NEGATIVE" ${this.invStatusFilter === 'NEGATIVE' ? 'selected' : ''}>Oversold / Negative (&lt; 0)</option>
              </select>
              <!-- Category Filter -->
              <select id="inventory-cat-filter" class="form-control" style="width: auto; min-width: 150px; font-weight: 600;">
                <option value="ALL" ${(!this.invCatFilter || this.invCatFilter === 'ALL') ? 'selected' : ''}>All Categories</option>
                ${(this.categories || []).map(cat => `
                  <option value="${this.escapeHtml(cat)}" ${this.invCatFilter === cat ? 'selected' : ''}>${this.escapeHtml(cat)}</option>
                `).join('')}
              </select>
              <!-- Sorting Filter -->
              <select id="inventory-sort-filter" class="form-control" style="width: auto; min-width: 150px; font-weight: 600;">
                <option value="NAME" ${(!this.invSortFilter || this.invSortFilter === 'NAME') ? 'selected' : ''}>Product Name (A &rarr; Z)</option>
                <option value="STOCK_ASC" ${this.invSortFilter === 'STOCK_ASC' ? 'selected' : ''}>Stock: Lowest First</option>
                <option value="STOCK_DESC" ${this.invSortFilter === 'STOCK_DESC' ? 'selected' : ''}>Stock: Highest First</option>
                <option value="RETAIL_DESC" ${this.invSortFilter === 'RETAIL_DESC' ? 'selected' : ''}>Highest Retail Valuation</option>
                <option value="COST_DESC" ${this.invSortFilter === 'COST_DESC' ? 'selected' : ''}>Highest Cost Valuation</option>
              </select>
            </div>
            ${hasActiveInvFilters ? `
              <button type="button" class="btn btn-outline btn-sm" onclick="app.resetInventoryFilters()" style="color: var(--slate-600); font-weight: 600;" title="Clear all active inventory filters">
                <i class="fa-solid fa-xmark"></i> Clear Filters
              </button>
            ` : ''}
          </div>

          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th style="width: 50px;">Photo</th>
                  <th>Product</th>
                  <th>SKU</th>
                  <th>Unit</th>
                  <th>Stock on Hand</th>
                  <th>Reorder Alert Level</th>
                  <th>Cost Valuation</th>
                  <th>Selling Valuation</th>
                  <th>Status</th>
                  ${this.isMultiBranch ? '<th style="text-align: center; width: 110px;">Actions</th>' : ''}
                </tr>
              </thead>
              <tbody>
                ${filteredItems.length > 0 ? filteredItems.map(item => {
      const p = item.product;
      const imgUrl = p.image_url || 'assets/images/products/placeholder.svg';

      return `
                    <tr>
                      <td>
                        <img src="${this.escapeHtml(imgUrl)}" class="table-img-thumb" style="cursor: pointer;" onclick="app.openProductDetailModal(${this.jsStr(p.id)})" title="Click to view details" alt="${this.escapeHtml(p.name)}" onerror="this.src='assets/images/products/placeholder.svg'">
                      </td>
                      <td style="font-weight: 600; cursor: pointer; color: var(--primary);" onclick="app.openProductDetailModal(${this.jsStr(p.id)})" title="Click to view details">
                        ${this.escapeHtml(p.name)}
                        ${isFilteredBranch && !item.isAvail ? '<span class="badge badge-neutral" style="font-size: 0.65rem; margin-left: 0.35rem;">Disabled at branch</span>' : ''}
                      </td>
                      <td style="font-family: monospace;">${this.escapeHtml(p.sku || 'N/A')}</td>
                      <td>${this.escapeHtml(p.unit || 'pcs')}</td>
                      <td style="font-weight: 700; font-size: 0.95rem; white-space: nowrap;">
                        ${item.qty}
                        ${this.isMultiBranch && !isFilteredBranch ? `
                          <button class="btn btn-outline btn-sm" onclick="app.openBranchStockModal(${this.jsStr(p.id)})" style="margin-left: 0.4rem; padding: 0.15rem 0.45rem; font-size: 0.72rem;" title="View stock breakdown by branch">
                            <i class="fa-solid fa-sitemap"></i> Breakdown
                          </button>
                        ` : ''}
                      </td>
                      <td>${p.min_stock_alert || 5}</td>
                      <td>${this.formatCurrency(item.costValuation)}</td>
                      <td style="font-weight: 600; color: var(--primary);">
                        ${this.formatCurrency(item.retailValuation)}
                        ${item.hasCustomPrice ? '<span class="badge badge-neutral" style="font-size: 0.65rem; margin-left: 0.25rem;">Branch Price</span>' : ''}
                      </td>
                      <td>
                        ${!item.isAvail ? `
                          <span class="badge badge-neutral">
                            <i class="fa-solid fa-ban"></i> Disabled
                          </span>
                        ` : (item.isOut ? `
                          <span class="badge badge-danger">
                            <i class="fa-solid fa-circle-xmark"></i> Out of Stock
                          </span>
                        ` : (item.isLow ? `
                          <span class="badge badge-warning">
                            <i class="fa-solid fa-triangle-exclamation"></i> Low Stock
                          </span>
                        ` : `
                          <span class="badge badge-success">
                            <i class="fa-solid fa-circle-check"></i> In Stock
                          </span>
                        `))}
                      </td>
                      ${this.isMultiBranch ? `
                        <td style="text-align: center;">
                          <div style="display: flex; gap: 0.3rem; justify-content: center;">
                            <button class="btn btn-outline btn-sm" onclick="app.openBranchStockModal(${this.jsStr(p.id)})" title="Branch Stock Breakdown" style="padding: 0.25rem 0.45rem;">
                              <i class="fa-solid fa-cubes-stacked"></i>
                            </button>
                            <button class="btn btn-outline btn-sm" onclick="app.openTransferModal(${this.jsStr(p.id)})" title="Transfer Stock to another branch" style="padding: 0.25rem 0.45rem;">
                              <i class="fa-solid fa-truck-arrow-right"></i>
                            </button>
                          </div>
                        </td>
                      ` : ''}
                    </tr>
                  `;
    }).join('') : `
                  <tr>
                    <td colspan="${this.isMultiBranch ? 10 : 9}" style="text-align: center; padding: 2.5rem; color: var(--slate-500);">
                      <div style="font-size: 1.75rem; margin-bottom: 0.5rem; color: var(--slate-400);"><i class="fa-solid fa-boxes-stacked"></i></div>
                      <div style="font-weight: 600; font-size: 1rem; color: var(--slate-700);">No products match your search or filter criteria</div>
                      <div style="font-size: 0.85rem; margin-top: 0.25rem;">Try modifying your search keywords or resetting filters.</div>
                      <button class="btn btn-primary btn-sm" style="margin-top: 0.85rem;" onclick="app.resetInventoryFilters()">Reset All Filters</button>
                    </td>
                  </tr>
                `}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  }

  resetInventoryFilters() {
    this.invSearchQuery = '';
    this.invStatusFilter = 'ALL';
    this.invCatFilter = 'ALL';
    this.invSortFilter = 'NAME';
    this.render();
  }

  bindInventoryEvents() {
    const searchInput = document.getElementById('inventory-search-input');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        clearTimeout(this._invSearchTimer);
        const val = e.target.value;
        const cursorStart = e.target.selectionStart;
        const cursorEnd = e.target.selectionEnd;
        this._invSearchTimer = setTimeout(() => {
          this.invSearchQuery = val;
          this.render();
          const nextInput = document.getElementById('inventory-search-input');
          if (nextInput) {
            nextInput.focus();
            if (cursorStart !== null && cursorEnd !== null) {
              nextInput.setSelectionRange(cursorStart, cursorEnd);
            }
          }
        }, 220);
      });
    }

    const statusFilter = document.getElementById('inventory-status-filter');
    if (statusFilter) {
      statusFilter.addEventListener('change', (e) => {
        this.invStatusFilter = e.target.value;
        this.render();
      });
    }

    const catFilter = document.getElementById('inventory-cat-filter');
    if (catFilter) {
      catFilter.addEventListener('change', (e) => {
        this.invCatFilter = e.target.value;
        this.render();
      });
    }

    const sortFilter = document.getElementById('inventory-sort-filter');
    if (sortFilter) {
      sortFilter.addEventListener('change', (e) => {
        this.invSortFilter = e.target.value;
        this.render();
      });
    }
  }

  openStockAdjustmentModal(preselectedProductId = null, preselectedBranch = null, defaultType = null, defaultReason = null, allowedMaxQty = null) {
    this.activeAdjustmentProductId = preselectedProductId;
    const isRentalMode = (defaultType === 'REPAIRED' || defaultType === 'FOUND_REPLACED' || this.currentView === 'rentals');
    let candidateProducts = this.products || [];
    if (isRentalMode) {
      const rentalOnly = candidateProducts.filter(p => this.isRentalProduct && this.isRentalProduct(p));
      if (rentalOnly.length > 0) {
        candidateProducts = rentalOnly;
      }
    }

    const select = document.getElementById('stock-adj-product-select');
    if (select) {
      select.innerHTML = candidateProducts.map(p => {
        let label = `${this.escapeHtml(p.name)} (Stock: ${p.current_quantity || 0} ${this.escapeHtml(p.unit || 'pcs')})`;
        if (isRentalMode && this.itemDamageStats && this.itemDamageStats[p.id]) {
          const st = this.itemDamageStats[p.id];
          if (defaultType === 'REPAIRED') {
            label = `${this.escapeHtml(p.name)} [Stock: ${p.current_quantity || 0} | Damaged/In Repair: ${st.net_damaged || 0}]`;
          } else if (defaultType === 'FOUND_REPLACED') {
            label = `${this.escapeHtml(p.name)} [Stock: ${p.current_quantity || 0} | Missing/Lost: ${st.net_missing || 0}]`;
          } else if ((st.net_damaged || 0) > 0 || (st.net_missing || 0) > 0) {
            label = `${this.escapeHtml(p.name)} [Stock: ${p.current_quantity || 0} | Repair: ${st.net_damaged || 0}, Missing: ${st.net_missing || 0}]`;
          }
        }
        return `
          <option value="${this.escapeHtml(p.id)}" ${p.id === preselectedProductId ? 'selected' : ''}>
            ${label}
          </option>
        `;
      }).join('');
      if (preselectedProductId) {
        select.value = preselectedProductId;
      }
    }

    const branchGroup = document.getElementById('stock-adj-branch-group');
    const branchSelect = document.getElementById('stock-adj-branch');
    if (branchGroup && branchSelect) {
      if (this.isMultiBranch && this.branches.length > 0) {
        branchGroup.style.display = 'block';
        const defaultBranch = preselectedBranch || (this.inventoryBranchFilter && this.inventoryBranchFilter !== 'ALL'
          ? this.inventoryBranchFilter
          : (this.branchCode || 'MAIN-01'));
        branchSelect.innerHTML = this.branches.map(b => `
          <option value="${this.escapeHtml(b.branch_code)}" ${b.branch_code === defaultBranch ? 'selected' : ''}>
            ${this.escapeHtml(b.name)} (${this.escapeHtml(b.branch_code)})
          </option>
        `).join('');
      } else {
        branchGroup.style.display = 'none';
      }
    }

    const typeSelect = document.getElementById('stock-adj-type');
    if (typeSelect) {
      typeSelect.value = defaultType || 'ADJUSTMENT_ADD';
    }

    const qtyInput = document.getElementById('stock-adj-qty');
    if (qtyInput) {
      if (allowedMaxQty !== null && allowedMaxQty !== undefined && Number(allowedMaxQty) > 0) {
        qtyInput.value = String(allowedMaxQty);
        qtyInput.max = String(allowedMaxQty);
      } else {
        qtyInput.value = '1';
        qtyInput.removeAttribute('max');
      }
    }

    const reasonInput = document.getElementById('stock-adj-reason');
    if (reasonInput) {
      if (defaultReason) {
        reasonInput.value = defaultReason;
      } else if (defaultType === 'REPAIRED') {
        reasonInput.value = 'Repaired equipment restored to warehouse stock';
      } else if (defaultType === 'FOUND_REPLACED') {
        reasonInput.value = 'Recovered missing equipment / hirer replacement added to warehouse fleet';
      } else {
        reasonInput.value = 'Manual stock adjustment';
      }
    }

    document.getElementById('stock-adj-modal')?.classList.add('active');
    this.updateStockAdjPreview();
  }

  updateStockAdjPreview() {
    const prodId = document.getElementById('stock-adj-product-select')?.value;
    const type = document.getElementById('stock-adj-type')?.value || 'ADJUSTMENT_ADD';
    const qty = parseFloat(document.getElementById('stock-adj-qty')?.value) || 0;
    const branchCode = (this.isMultiBranch && document.getElementById('stock-adj-branch'))
      ? document.getElementById('stock-adj-branch').value
      : (this.branchCode || 'MAIN-01');

    const impactTextEl = document.getElementById('stock-adj-impact-text');
    const impactCardEl = document.getElementById('stock-adj-impact-card');
    if (!impactTextEl) return;

    const prod = this.products.find(p => p.id === prodId);
    if (!prod) {
      impactTextEl.textContent = 'Select a product';
      return;
    }

    let currentStock = Number(prod.current_quantity || 0);
    if (this.isMultiBranch && prod.branch_settings && Array.isArray(prod.branch_settings)) {
      const bSet = prod.branch_settings.find(bs => (bs.branch_code || '').toUpperCase() === branchCode.toUpperCase());
      if (bSet) {
        currentStock = Number(bSet.current_quantity || 0);
      }
    }

    // Rental repair / restored caps inspection
    if (type === 'REPAIRED' || type === 'FOUND_REPLACED') {
      const stats = (this.itemDamageStats && this.itemDamageStats[prodId]) || {};
      const maxAwaiting = type === 'REPAIRED' 
        ? (stats.net_damaged !== undefined ? Number(stats.net_damaged) : null)
        : (stats.net_missing !== undefined ? Number(stats.net_missing) : null);

      if (maxAwaiting !== null) {
        if (maxAwaiting <= 0) {
          impactTextEl.textContent = `⚠️ All damaged/missing units for '${prod.name}' have already been repaired & restored! (0 awaiting)`;
          if (impactCardEl) {
            impactCardEl.style.background = '#fef3c7';
            impactCardEl.style.borderColor = '#fde68a';
            impactTextEl.style.color = '#92400e';
          }
          return;
        } else if (qty > maxAwaiting) {
          impactTextEl.textContent = `⚠️ Quantity ${qty} exceeds ${maxAwaiting} unit(s) recorded as awaiting ${type === 'REPAIRED' ? 'repair' : 'recovery'}!`;
          if (impactCardEl) {
            impactCardEl.style.background = '#fee2e2';
            impactCardEl.style.borderColor = '#fecaca';
            impactTextEl.style.color = '#b91c1c';
          }
          return;
        }
      }
    }

    const isSub = (type === 'ADJUSTMENT_REMOVE' || type === 'DAMAGE');
    const delta = isSub ? -qty : qty;
    const projected = Math.max(0, currentStock + delta);
    const unit = prod.unit || 'pcs';

    const sign = delta >= 0 ? `+${delta}` : `${delta}`;
    impactTextEl.textContent = `Current: ${currentStock} ${unit} (${sign}) -> New Stock: ${projected} ${unit}`;

    if (impactCardEl) {
      if (isSub) {
        impactCardEl.style.background = '#fef2f2';
        impactCardEl.style.borderColor = '#fecaca';
        impactTextEl.style.color = '#b91c1c';
      } else {
        impactCardEl.style.background = '#f0fdf4';
        impactCardEl.style.borderColor = '#bbf7d0';
        impactTextEl.style.color = '#15803d';
      }
    }
  }

  closeStockAdjustmentModal() {
    document.getElementById('stock-adj-modal')?.classList.remove('active');
  }

  async saveStockAdjustment() {
    const prodId = document.getElementById('stock-adj-product-select')?.value;
    const type = document.getElementById('stock-adj-type')?.value;
    const qty = parseFloat(document.getElementById('stock-adj-qty')?.value) || 0;
    const reason = (document.getElementById('stock-adj-reason')?.value || '').trim() || 'Manual stock adjustment';
    const branchCode = (this.isMultiBranch && document.getElementById('stock-adj-branch'))
      ? document.getElementById('stock-adj-branch').value
      : (this.branchCode || 'MAIN-01');

    if (!prodId) {
      this.showToast('Please select a product to adjust.', 'warning');
      return;
    }

    if (qty <= 0) {
      this.showToast('Adjustment quantity must be greater than zero.', 'warning');
      return;
    }

    // Rental repair / restored caps inspection
    if (type === 'REPAIRED' || type === 'FOUND_REPLACED') {
      const stats = (this.itemDamageStats && this.itemDamageStats[prodId]) || {};
      if (type === 'REPAIRED' && stats.net_damaged !== undefined && qty > Number(stats.net_damaged)) {
        this.showToast(`Cannot restock ${qty} repaired units. Only ${stats.net_damaged} unit(s) are awaiting repair.`, 'danger');
        return;
      }
      if (type === 'FOUND_REPLACED' && stats.net_missing !== undefined && qty > Number(stats.net_missing)) {
        this.showToast(`Cannot restore ${qty} missing units. Only ${stats.net_missing} unit(s) are recorded as missing.`, 'danger');
        return;
      }
    }

    // The shelf number the cashier just moved is the till's own copy; the server has to
    // agree before this is called an adjustment. A refusal used to fall into the same
    // success toast, and the refetch below quietly put the old number back a second later
    // - so the owner was told the count was fixed while the books still held the old one.
    let adjustmentRefused = null;

    const prod = this.products.find(p => p.id === prodId);
    if (prod) {
      const delta = (type === 'ADJUSTMENT_REMOVE' || type === 'DAMAGE') ? -qty : qty;
      prod.current_quantity = Math.max(0, (prod.current_quantity || 0) + delta);

      if (prod.branch_settings && Array.isArray(prod.branch_settings)) {
        let bSetting = prod.branch_settings.find(bs => (bs.branch_code || '').toUpperCase() === branchCode.toUpperCase());
        if (bSetting) {
          bSetting.current_quantity = Math.max(0, Number(bSetting.current_quantity || 0) + delta);
        } else {
          prod.branch_settings.push({
            product_id: prodId,
            branch_code: branchCode,
            current_quantity: Math.max(0, delta),
            custom_selling_price: null,
            is_available: 1
          });
        }
      }

      await localDB.products.put(prod);

      if (this.isOnline) {
        try {
          const res = await this.apiFetch('api/endpoints/inventory.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ product_id: prodId, branch_code: branchCode, type, quantity: qty, reason })
          });
          const verdict = await this.classifyApiResponse(res);
          if (verdict.verdict === 'refused') adjustmentRefused = verdict.message;
        } catch (e) {
          console.warn('Inventory adjustment sync deferred:', e);
          await this.logClientActivity(
            'STOCK_ADJUSTMENT',
            `Stock adjusted by ${delta > 0 ? '+' : ''}${delta} for '${prod.name || prodId}' at ${branchCode}: ${reason}.`,
            true
          );
        }
        if (adjustmentRefused === null) {
          await this.logClientActivity(
            'STOCK_ADJUSTMENT',
            `Stock adjusted by ${delta > 0 ? '+' : ''}${delta} for '${prod.name || prodId}' at ${branchCode}: ${reason}.`,
            false
          );
        }
      } else {
        await this.logClientActivity(
          'STOCK_ADJUSTMENT',
          `Stock adjusted by ${delta > 0 ? '+' : ''}${delta} for '${prod.name || prodId}' at ${branchCode}: ${reason}.`,
          true
        );
      }
    }

    this.closeStockAdjustmentModal();
    await this.fetchProducts();
    await this.fetchInventory();
    if (typeof this.fetchRentals === 'function') {
      await this.fetchRentals();
    }
    this.renderCurrentView();

    // If adjustment was triggered from Product Detail modal, re-open with fresh data!
    if (this.activeAdjustmentProductId) {
      const refreshedId = this.activeAdjustmentProductId;
      this.activeAdjustmentProductId = null;
      await this.openProductDetailModal(refreshedId);
    }

    if (typeof this.broadcastSyncEvent === 'function') {
      this.broadcastSyncEvent('STOCK_ADJUSTED', { productId: prodId, branchCode, delta, type });
    }

    if (adjustmentRefused !== null) {
      this.showToast(`Stock was NOT adjusted: ${adjustmentRefused} The shelf still shows the old count.`, 'danger', 12000);
      return;
    }

    this.showToast('Stock quantity adjusted successfully!', 'success');
  }

  // --- Inter-Branch Stock Transfers (IBT) ---

  openTransferModal(prefilledProductId = null, prefilledSource = null) {
    if (!this.isMultiBranch) {
      this.showToast('Multi-Branch Mode is disabled. Enable it in Store Settings to use Inter-Branch Transfers.', 'warning');
      return;
    }

    if (!this.branches || this.branches.length < 2) {
      this.showToast('At least 2 active branches are required to transfer stock.', 'warning');
      return;
    }

    const sourceSelect = document.getElementById('transfer-source-branch');
    const destSelect = document.getElementById('transfer-dest-branch');
    if (!sourceSelect || !destSelect) return;

    const defaultSource = prefilledSource || (this.inventoryBranchFilter !== 'ALL' ? this.inventoryBranchFilter : (this.branchCode || this.branches[0].branch_code));

    sourceSelect.innerHTML = this.branches.map(b => `
      <option value="${this.escapeHtml(b.branch_code)}" ${b.branch_code === defaultSource ? 'selected' : ''}>
        ${this.escapeHtml(b.name)} (${this.escapeHtml(b.branch_code)})
      </option>
    `).join('');

    this.updateTransferDestOptions();

    const container = document.getElementById('transfer-items-container');
    if (container) {
      container.innerHTML = '';
      this.transferRowCounter = 0;
    }

    const notesInput = document.getElementById('transfer-notes');
    if (notesInput) notesInput.value = '';

    this.addTransferRow(prefilledProductId, 1);

    const modal = document.getElementById('stock-transfer-modal');
    if (modal) modal.classList.add('active');
  }

  closeTransferModal() {
    const modal = document.getElementById('stock-transfer-modal');
    if (modal) modal.classList.remove('active');
  }

  updateTransferDestOptions() {
    const sourceSelect = document.getElementById('transfer-source-branch');
    const destSelect = document.getElementById('transfer-dest-branch');
    if (!sourceSelect || !destSelect) return;

    const sourceCode = sourceSelect.value;
    const destBranches = this.branches.filter(b => b.branch_code !== sourceCode);

    const currentDest = destSelect.value;
    destSelect.innerHTML = destBranches.map(b => `
      <option value="${this.escapeHtml(b.branch_code)}" ${b.branch_code === currentDest ? 'selected' : ''}>
        ${this.escapeHtml(b.name)} (${this.escapeHtml(b.branch_code)})
      </option>
    `).join('');

    if (destBranches.length > 0 && (!destSelect.value || destSelect.value === sourceCode)) {
      destSelect.value = destBranches[0].branch_code;
    }
  }

  handleTransferSourceChange() {
    this.updateTransferDestOptions();
    const rows = document.querySelectorAll('.transfer-item-row');
    rows.forEach(row => this.updateTransferRowStock(row));
    this.updateTransferMetrics();
  }

  addTransferRow(selectedProdId = null, qty = 1) {
    const container = document.getElementById('transfer-items-container');
    if (!container) return;

    const rowId = `transfer-row-${++this.transferRowCounter}`;
    const defaultProdId = selectedProdId || (this.products.length > 0 ? this.products[0].id : '');

    const row = document.createElement('div');
    row.id = rowId;
    row.className = 'transfer-item-row';
    row.style.cssText = 'display: flex; flex-wrap: wrap; gap: 0.5rem; align-items: center; background: #ffffff; padding: 0.5rem 0.65rem; border-radius: 8px; border: 1px solid var(--slate-200);';

    const prodOptions = this.products.map(p => `
      <option value="${this.escapeHtml(p.id)}" ${p.id === defaultProdId ? 'selected' : ''}>
        ${this.escapeHtml(p.name)} (${this.escapeHtml(p.sku || 'No SKU')})
      </option>
    `).join('');

    row.innerHTML = `
      <div style="flex: 3; min-width: 160px;">
        <select class="form-control transfer-row-product" style="font-size: 0.85rem;" onchange="app.handleTransferProductChange(${this.jsStr(rowId)})">
          ${prodOptions}
        </select>
      </div>
      <div style="flex: 1.2; min-width: 96px;">
        <select class="form-control transfer-row-unit" style="font-size: 0.85rem;" onchange="app.handleTransferUnitChange(${this.jsStr(rowId)})"></select>
      </div>
      <div style="flex: 1.5; text-align: center;">
        <span class="badge badge-neutral transfer-row-avail-badge" style="font-size: 0.75rem; white-space: nowrap;">
          Avail: 0
        </span>
      </div>
      <div style="flex: 1.2;">
        <input type="number" class="form-control transfer-row-qty" value="${qty}" min="1" style="font-size: 0.85rem; text-align: center;" oninput="app.refreshTransferRowHint(${this.jsStr(rowId)}); app.updateTransferMetrics()">
      </div>
      <div style="width: 32px; text-align: center;">
        <button type="button" class="btn btn-outline btn-sm" onclick="app.removeTransferRow(${this.jsStr(rowId)})" style="color: var(--danger); border-color: var(--danger-border); padding: 0.25rem 0.45rem;">
          <i class="fa-solid fa-trash-can"></i>
        </button>
      </div>
      <div class="transfer-row-hint" style="width: 100%; font-size: 0.72rem; color: var(--slate-500);"></div>
    `;

    container.appendChild(row);
    this.renderTransferRowUnits(row);
    this.updateTransferRowStock(row);
    this.updateTransferMetrics();
  }

  // The sizes this product is stocked in, in the order the catalogue lists them.
  renderTransferRowUnits(row) {
    const prodSelect = row.querySelector('.transfer-row-product');
    const unitSelect = row.querySelector('.transfer-row-unit');
    if (!prodSelect || !unitSelect) return;
    const prod = this.products.find(p => p.id === prodSelect.value);
    const units = this.productUnitsOf(prod || {});
    const wanted = unitSelect.value;
    unitSelect.innerHTML = units.map(u => `
      <option value="${this.escapeHtml(u.unit_name)}">
        ${this.escapeHtml(u.unit_name)}${Number(u.size_in_base || 1) > 1 ? ` (x${u.size_in_base})` : ''}
      </option>
    `).join('');
    if (wanted && [...unitSelect.options].some(o => o.value === wanted)) unitSelect.value = wanted;
  }

  // What the line is actually moving, in the units the shelf counts. A waybill that reads
  // "4" tells the receiving branch nothing; one that reads "4 Crate = 120 egg" tells the
  // officer what to count off the lorry and the till what to take off the shelf.
  transferRowParts(row) {
    const prodSelect = row.querySelector('.transfer-row-product');
    const unitSelect = row.querySelector('.transfer-row-unit');
    const qtyInput = row.querySelector('.transfer-row-qty');
    const prod = this.products.find(p => p.id === (prodSelect?.value || ''));
    const unit = this.productUnitOf(prod || {}, unitSelect?.value || '');
    const multiplier = Math.max(1, Number(unit?.size_in_base || 1));
    const quantity = Math.max(0, parseFloat(qtyInput?.value || 0));
    return {
      prod,
      unitName: unit ? unit.unit_name : (prod?.unit || 'pcs'),
      baseUnit: prod?.unit || 'pcs',
      multiplier,
      quantity,
      baseQuantity: Math.round(quantity * multiplier * 10000) / 10000
    };
  }

  refreshTransferRowHint(rowId) {
    const row = typeof rowId === 'string' ? document.getElementById(rowId) : rowId;
    if (!row) return;
    const hint = row.querySelector('.transfer-row-hint');
    if (!hint) return;
    const parts = this.transferRowParts(row);
    if (!parts.prod) { hint.textContent = ''; return; }
    const sourceSelect = document.getElementById('transfer-source-branch');
    const src = sourceSelect ? sourceSelect.value : 'MAIN-01';
    hint.textContent = parts.multiplier > 1
      ? `${parts.quantity} × ${parts.unitName} = ${parts.baseQuantity} ${parts.baseUnit} leaving ${src}`
      : `${parts.quantity} ${parts.unitName} leaving ${src}`;
  }

  handleTransferUnitChange(rowId) {
    const row = document.getElementById(rowId);
    if (!row) return;
    this.refreshTransferRowHint(row);
    this.updateTransferMetrics();
  }

  removeTransferRow(rowId) {
    const row = document.getElementById(rowId);
    if (row) {
      row.remove();
      this.updateTransferMetrics();
    }
  }

  handleTransferProductChange(rowId) {
    const row = document.getElementById(rowId);
    if (row) {
      this.updateTransferRowStock(row);
      this.updateTransferMetrics();
    }
  }

  updateTransferRowStock(row) {
    const sourceSelect = document.getElementById('transfer-source-branch');
    const sourceBranch = sourceSelect ? sourceSelect.value : 'MAIN-01';
    const prodSelect = row.querySelector('.transfer-row-product');
    const badge = row.querySelector('.transfer-row-avail-badge');
    const qtyInput = row.querySelector('.transfer-row-qty');
    if (!prodSelect || !badge) return;

    // A new product is stocked in its own sizes, so the size list is rebuilt from it
    // before anything else on the row is read.
    this.renderTransferRowUnits(row);

    const prodId = prodSelect.value;
    const stock = this.getProductStockAtBranch(prodId, sourceBranch);
    const prod = this.products.find(p => p.id === prodId);
    const unit = prod?.unit || 'pcs';

    // The shelf is counted loose; the line is counted in sizes. The badge stays loose
    // because that is what the officer sees on the rack.
    badge.innerText = `Avail: ${stock} ${unit}`;
    if (stock <= 0) {
      badge.className = 'badge badge-danger transfer-row-avail-badge';
    } else if (stock <= 5) {
      badge.className = 'badge badge-warning transfer-row-avail-badge';
    } else {
      badge.className = 'badge badge-success transfer-row-avail-badge';
    }

    if (qtyInput) {
      const parts = this.transferRowParts(row);
      if (this.storeProfile.allow_negative_stock == 1) {
        qtyInput.removeAttribute('max');
      } else {
        const wholeSizes = Math.max(1, Math.floor(stock / parts.multiplier));
        qtyInput.max = wholeSizes;
      }
    }
    this.refreshTransferRowHint(row);
  }

  updateTransferMetrics() {
    let totalLines = 0;
    let totalBaseUnits = 0;

    const rows = document.querySelectorAll('.transfer-item-row');
    rows.forEach(row => {
      const parts = this.transferRowParts(row);
      if (parts.quantity > 0) {
        totalLines++;
        totalBaseUnits += parts.baseQuantity;
      }
    });

    const unitsEl = document.getElementById('transfer-total-units');
    const linesEl = document.getElementById('transfer-total-lines');
    if (unitsEl) unitsEl.innerText = totalBaseUnits.toLocaleString();
    if (linesEl) linesEl.innerText = totalLines;
  }

  async saveStockTransfer() {
    const sourceSelect = document.getElementById('transfer-source-branch');
    const destSelect = document.getElementById('transfer-dest-branch');
    const notesInput = document.getElementById('transfer-notes');
    const submitBtn = document.getElementById('btn-save-transfer');

    if (!sourceSelect || !destSelect) return;
    const sourceBranch = sourceSelect.value;
    const destBranch = destSelect.value;
    const notes = notesInput ? notesInput.value.trim() : '';

    if (sourceBranch === destBranch) {
      this.showToast('Source branch and Destination branch must be different.', 'warning');
      return;
    }

    const rows = document.querySelectorAll('.transfer-item-row');
    if (rows.length === 0) {
      this.showToast('Please add at least one line item to transfer.', 'warning');
      return;
    }

    const items = [];
    let hasError = false;
    let totalLines = 0;
    let totalBaseUnits = 0;
    let looseUnit = 'units';

    rows.forEach(row => {
      const parts = this.transferRowParts(row);

      if (!parts.prod || parts.quantity <= 0) {
        hasError = true;
        this.showToast('Each line item must have a valid product and positive quantity.', 'warning');
        return;
      }

      // Compared in the units the shelf is counted in. A waybill that asked for 4 crates
      // while guarding "4" against 120 eggs would ship 120 and book 4.
      const availableStock = this.getProductStockAtBranch(parts.prod.id, sourceBranch);
      if (parts.baseQuantity > availableStock && this.storeProfile.allow_negative_stock != 1) {
        hasError = true;
        this.showToast(
          `Transfer quantity for "${parts.prod.name}" (${parts.quantity} ${parts.unitName} = ${parts.baseQuantity} ${parts.baseUnit}) exceeds on-hand stock (${availableStock} ${parts.baseUnit}) at ${sourceBranch}.`,
          'warning'
        );
        return;
      }

      totalLines++;
      totalBaseUnits += parts.baseQuantity;
      looseUnit = parts.baseUnit;
      items.push({
        product_id: parts.prod.id,
        unit: parts.unitName,
        quantity: parts.quantity
      });
    });

    if (hasError || items.length === 0) return;

    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Dispatching Transfer...';
    }

    try {
      const localTrfId = 'trf_' + Math.random().toString(36).substring(2, 10);
      const trfNum = 'TRF-' + new Date().toISOString().slice(0, 10).replace(/-/g, '') + '-' + Math.floor(1000 + Math.random() * 9000);
      const payload = {
        id: localTrfId,
        transfer_number: trfNum,
        source_branch: sourceBranch,
        destination_branch: destBranch,
        notes: notes,
        items: items,
        created_at: new Date().toISOString().slice(0, 19).replace('T', ' ')
      };

      let transferResultId = localTrfId;
      let transferResultNum = trfNum;

      // The waybill is asked of the server before the local shelf is touched, so a
      // transfer the books turned away cannot leave this till holding stock that was
      // never moved - and cannot then be queued and moved a second time at the sync.
      let offline = !this.isOnline;
      let refusal = null;
      if (!offline) {
        let res = null;
        try {
          res = await this.apiFetch('api/endpoints/transfers.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
          });
        } catch (err) {
          res = null;
        }
        if (res === null) {
          offline = true;
        } else {
          const verdict = await this.classifyApiResponse(res);
          if (verdict.verdict === 'refused') {
            refusal = verdict.message;
          } else if (verdict.verdict === 'unreachable') {
            offline = true;
          } else {
            transferResultId = verdict.body.transfer_id || transferResultId;
            transferResultNum = verdict.body.transfer_number || transferResultNum;
          }
        }
      }

      if (refusal) {
        this.showToast(
          `Transfer was NOT dispatched: ${refusal} Nothing left ${sourceBranch} and nothing arrived at ${destBranch}. Fix the line and send it again.`,
          'danger',
          14000
        );
        return;
      }

      await this.applyTransferLocally(payload, transferResultId, transferResultNum, offline);

      if (offline) {
        await this.logClientActivity(
          'STOCK_TRANSFER',
          `Created offline stock transfer (${sourceBranch} -> ${destBranch}). Total ${totalLines} lines (${totalBaseUnits} ${looseUnit}).`,
          true
        );
      } else {
        await this.logClientActivity(
          'STOCK_TRANSFER',
          `Dispatched stock transfer ${transferResultNum} (${sourceBranch} -> ${destBranch}). Total ${totalLines} lines (${totalBaseUnits} ${looseUnit}).`,
          false
        );
      }

      this.showToast(
        offline
          ? `Transfer saved on this till (#${transferResultNum}). It leaves ${sourceBranch} on this counter and goes to the books at the next sync.`
          : `Transfer dispatched! Reference #${transferResultNum}`,
        offline ? 'warning' : 'success',
        offline ? 9000 : 3500
      );
      this.closeTransferModal();

      if (this.isOnline) {
        await this.fetchProducts();
        await this.fetchInventory();
        await this.fetchTransfers();
      }
      this.renderCurrentView();
      this.openTransferWaybillModal(transferResultId);

    } catch (err) {
      this.showToast(`Transfer error: ${err.message}`, 'danger');
    } finally {
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Dispatch Transfer & Update Stock';
      }
    }
  }

  // How many loose units a line really moves. The waybill carries the size name, never
  // a multiplier the till invented, so the count is looked up in the catalogue copy this
  // till holds - the same lookup the books do on their side of the wire.
  transferLineBaseQuantity(line) {
    const prod = this.products.find(p => p.id === line.product_id) || {};
    const unit = this.productUnitOf(prod, line.unit || '');
    const multiplier = Math.max(1, Number(unit?.size_in_base || 1));
    return Math.round(Number(line.quantity || 0) * multiplier * 10000) / 10000;
  }

  // Move the local shelf and keep the local waybill. Only called once the transfer is
  // either accepted by the books or committed to the outbox for them.
  async applyTransferLocally(payload, transferResultId, transferResultNum, offline) {
    const sourceBranch = payload.source_branch;
    const destBranch = payload.destination_branch;

    // Branch shelves are counted in loose units, so a crate moving is thirty leaving.
    for (const it of payload.items) {
      const moved = this.transferLineBaseQuantity(it);
      const p = this.products.find(prod => prod.id === it.product_id);
      if (p && Array.isArray(p.branch_settings)) {
        const sB = p.branch_settings.find(b => (b.branch_code || '').toUpperCase() === sourceBranch.toUpperCase());
        if (sB) sB.current_quantity = (sB.current_quantity || 0) - moved;
        const dB = p.branch_settings.find(b => (b.branch_code || '').toUpperCase() === destBranch.toUpperCase());
        if (dB) dB.current_quantity = (dB.current_quantity || 0) + moved;
        await localDB.products.put(p);
      }
    }

    if (offline) {
      await localDB.sync_outbox.add({
        entity: 'transfer',
        action: 'CREATE',
        data: payload,
        timestamp: new Date().toISOString(),
        synced: 0
      });
    }

    if (localDB.stock_transfers) {
      await localDB.stock_transfers.put({
        ...payload,
        id: transferResultId,
        transfer_number: transferResultNum,
        synced: offline ? 0 : 1
      });
    }

    this.transfers.unshift({
      ...payload,
      id: transferResultId,
      transfer_number: transferResultNum,
      items: payload.items.map(it => {
        const p = this.products.find(x => x.id === it.product_id);
        const unit = this.productUnitOf(p || {}, it.unit || '');
        return {
          ...it,
          product_name: p?.name || 'Item',
          sku: p?.sku || '',
          base_unit: p?.unit || 'pcs',
          unit: unit ? unit.unit_name : (p?.unit || 'pcs'),
          multiplier: Math.max(1, Number(unit?.size_in_base || 1)),
          base_quantity: this.transferLineBaseQuantity(it)
        };
      })
    });
  }

  async openTransferWaybillModal(transferId) {
    let transfer = this.transfers.find(t => t.id === transferId);
    if (!transfer || !transfer.items || transfer.items.length === 0) {
      try {
        const res = await this.apiFetch(`api/endpoints/transfers.php?id=${encodeURIComponent(transferId)}`);
        const data = await res.json();
        if (data.success && data.transfer) {
          transfer = data.transfer;
        }
      } catch (e) {
        console.warn('Could not fetch transfer details', e);
      }
    }

    if (!transfer) {
      this.showToast('Transfer record not found', 'warning');
      return;
    }

    this.currentTransferForWaybill = transfer;
    const container = document.getElementById('transfer-waybill-content');
    if (!container) return;

    const sourceName = transfer.source_branch_name || transfer.source_branch || 'Source';
    const destName = transfer.destination_branch_name || transfer.destination_branch || 'Destination';
    const createdDate = transfer.created_at || new Date().toLocaleString();
    const createdBy = transfer.officer_name || transfer.officer_username || (this.currentUser ? (this.currentUser.full_name || this.currentUser.username) : 'Store Manager');
    const items = transfer.items || [];
    // Counted in the units the shelf is counted in, so the total on the paper agrees
    // with what left the rack. A waybill of "4" that carried forty crates would be a
    // waybill the receiving branch signs for without noticing.
    const transferLoose = (it) => (Number(it.base_quantity) > 0 ? Number(it.base_quantity) : Number(it.quantity || 0));
    const totalQty = items.reduce((s, it) => s + transferLoose(it), 0);
    const looseWord = (() => {
      const hit = items.find(it => String(it.base_unit || '').trim() !== '');
      return hit ? hit.base_unit : 'units';
    })();

    container.innerHTML = `
      <div id="printable-transfer-waybill-area" style="padding: 1rem; color: #0f172a; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #0f172a; padding-bottom: 0.85rem; margin-bottom: 1rem;">
          <div>
            ${this.shouldPrintReceiptLogo() ? `<img src="${this.escapeHtml(this.getStoreLogo())}" alt="Logo" style="max-height: 44px; margin-bottom: 0.4rem;">` : ''}
            <h3 style="margin: 0; font-size: 1.2rem; font-weight: 800;">${this.escapeHtml(this.storeProfile?.store_name || 'My Store Enterprise')}</h3>
            <p style="margin: 0.15rem 0 0 0; font-size: 0.8rem; color: #64748b;">${this.escapeHtml(this.storeProfile?.tagline || 'Inter-Branch Stock Transfer Note')}</p>
          </div>
          <div style="text-align: right;">
            <span class="badge badge-success" style="font-size: 0.85rem; padding: 0.35rem 0.65rem; font-weight: 700;">TRANSFER DISPATCHED</span>
            <div style="margin-top: 0.35rem; font-family: monospace; font-size: 0.95rem; font-weight: 800; color: var(--primary);">${this.escapeHtml(transfer.transfer_number || transfer.id)}</div>
            <div style="font-size: 0.78rem; color: #64748b;">Date: ${this.escapeHtml(createdDate)}</div>
          </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; background: #f8fafc; padding: 0.85rem; border-radius: 8px; border: 1px solid #e2e8f0; margin-bottom: 1rem; font-size: 0.85rem;">
          <div>
            <span style="font-size: 0.72rem; text-transform: uppercase; font-weight: 700; color: #ef4444; display: block; margin-bottom: 0.2rem;"><i class="fa-solid fa-arrow-up-from-bracket"></i> Source (Dispatching Branch)</span>
            <strong style="font-size: 0.95rem;">${this.escapeHtml(sourceName)}</strong>
            <div style="font-family: monospace; font-size: 0.78rem; color: #64748b;">Code: ${this.escapeHtml(transfer.source_branch)}</div>
            <div style="margin-top: 0.35rem; font-size: 0.78rem;"><strong>Dispatched By:</strong> ${this.escapeHtml(createdBy)}</div>
          </div>
          <div>
            <span style="font-size: 0.72rem; text-transform: uppercase; font-weight: 700; color: #10b981; display: block; margin-bottom: 0.2rem;"><i class="fa-solid fa-arrow-down-to-bracket"></i> Destination (Receiving Branch)</span>
            <strong style="font-size: 0.95rem;">${this.escapeHtml(destName)}</strong>
            <div style="font-family: monospace; font-size: 0.78rem; color: #64748b;">Code: ${this.escapeHtml(transfer.destination_branch)}</div>
            <div style="margin-top: 0.35rem; font-size: 0.78rem;"><strong>Status:</strong> <span style="font-weight: 700; color: #10b981;">COMPLETED</span></div>
          </div>
        </div>

        ${transfer.notes ? `
          <div style="font-size: 0.82rem; margin-bottom: 1rem; padding: 0.5rem 0.75rem; background: #fffbeb; border-left: 3px solid #f59e0b; border-radius: 4px;">
            <strong>Waybill Notes:</strong> ${this.escapeHtml(transfer.notes)}
          </div>
        ` : ''}

        <table style="width: 100%; border-collapse: collapse; font-size: 0.85rem; margin-bottom: 1.5rem;">
          <thead>
            <tr style="background: #f1f5f9; border-bottom: 2px solid #cbd5e1; text-align: left;">
              <th style="padding: 0.5rem; width: 45px;">#</th>
              <th style="padding: 0.5rem;">Product Description</th>
              <th style="padding: 0.5rem; text-align: center;">SKU</th>
              <th style="padding: 0.5rem; text-align: center;">Unit</th>
              <th style="padding: 0.5rem; text-align: right;">Quantity Dispatched</th>
            </tr>
          </thead>
          <tbody>
            ${items.map((it, idx) => `
              <tr style="border-bottom: 1px solid #e2e8f0;">
                <td style="padding: 0.5rem; color: #64748b;">${idx + 1}</td>
                <td style="padding: 0.5rem; font-weight: 600;">${this.escapeHtml(it.product_name || it.name || 'Item')}</td>
                <td style="padding: 0.5rem; text-align: center; font-family: monospace; font-size: 0.8rem;">${this.escapeHtml(it.sku || '-')}</td>
                <td style="padding: 0.5rem; text-align: center;">${this.escapeHtml(it.unit || it.base_unit || 'pcs')}</td>
                <td style="padding: 0.5rem; text-align: right; font-weight: 700; font-size: 0.95rem;">${it.quantity}${(it.unit && it.base_unit && String(it.unit).toLowerCase() !== String(it.base_unit).toLowerCase())
                  ? `<div style="font-size: 0.7rem; font-weight: 600; color: #64748b;">= ${transferLoose(it)} ${this.escapeHtml(it.base_unit)}</div>`
                  : ''}</td>
              </tr>
            `).join('')}
          </tbody>
          <tfoot>
            <tr style="background: #f8fafc; font-weight: 700; border-top: 2px solid #0f172a;">
              <td colspan="4" style="padding: 0.5rem; text-align: right;">TOTAL DISPATCHED (LOOSE):</td>
              <td style="padding: 0.5rem; text-align: right; font-size: 1rem; color: var(--primary);">${totalQty} <span style="font-size: 0.75rem; color: #64748b;">${this.escapeHtml(looseWord)}</span></td>
            </tr>
          </tfoot>
        </table>

        <!-- Signatures and Audit Sign-off -->
        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1rem; margin-top: 2.5rem; padding-top: 1rem; border-top: 1px dashed #cbd5e1; font-size: 0.78rem; text-align: center;">
          <div>
            <div style="height: 40px; border-bottom: 1px solid #0f172a; margin-bottom: 0.35rem;"></div>
            <strong>Dispatched By (Source Branch)</strong>
            <div style="color: #64748b; font-size: 0.72rem;">Signature & Date</div>
          </div>
          <div>
            <div style="height: 40px; border-bottom: 1px solid #0f172a; margin-bottom: 0.35rem;"></div>
            <strong>Driver / Logistics Courier</strong>
            <div style="color: #64748b; font-size: 0.72rem;">Signature & Vehicle Reg</div>
          </div>
          <div>
            <div style="height: 40px; border-bottom: 1px solid #0f172a; margin-bottom: 0.35rem;"></div>
            <strong>Received By (Dest Branch)</strong>
            <div style="color: #64748b; font-size: 0.72rem;">Signature & Date</div>
          </div>
        </div>
      </div>
    `;

    const modal = document.getElementById('transfer-waybill-modal');
    if (modal) modal.classList.add('active');
  }

  closeTransferWaybillModal() {
    const modal = document.getElementById('transfer-waybill-modal');
    if (modal) modal.classList.remove('active');
  }

  printTransferWaybill() {
    const printArea = document.getElementById('printable-transfer-waybill-area');
    if (!printArea) return;

    const printWin = window.open('', '_blank', 'width=880,height=720');
    if (!printWin) {
      window.print();
      return;
    }

    printWin.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Transfer Waybill - ${this.escapeHtml(this.currentTransferForWaybill?.transfer_number || 'IBT')}</title>
        <style>
          @page { size: letter; margin: 15mm; }
          body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 10px; color: #0f172a; }
          table { width: 100%; border-collapse: collapse; }
          th, td { padding: 8px; border-bottom: 1px solid #e2e8f0; }
          th { background: #f8fafc; font-weight: 700; }
        </style>
      </head>
      <body>
        ${printArea.innerHTML}
        <script>
          window.onload = function() { window.print(); window.close(); };
        </script>
      </body>
      </html>
    `);
    printWin.document.close();
  }

  // --- Quick Branch Stock Distribution Modal ---

  openBranchStockModal(productId) {
    const product = this.products.find(p => p.id === productId);
    if (!product) return;

    this.selectedStockModalProduct = product;
    const body = document.getElementById('branch-stock-modal-body');
    if (!body) return;

    const totalQty = Number(product.current_quantity || 0);
    const imgUrl = product.image_url || 'assets/images/products/placeholder.svg';

    const branchList = this.branches.map(b => {
      const bSetting = (product.branch_settings && Array.isArray(product.branch_settings))
        ? product.branch_settings.find(bs => (bs.branch_code || '').toUpperCase() === b.branch_code.toUpperCase())
        : null;

      const qty = bSetting ? Number(bSetting.current_quantity || 0) : 0;
      const customPrice = (bSetting && bSetting.custom_selling_price !== null && bSetting.custom_selling_price !== '') ? Number(bSetting.custom_selling_price) : null;
      const isAvail = bSetting ? (Number(bSetting.is_available) === 1) : true;

      return {
        branch: b,
        qty,
        customPrice,
        isAvail
      };
    });

    body.innerHTML = `
      <div style="display: flex; gap: 1rem; align-items: center; margin-bottom: 1.25rem; padding-bottom: 1rem; border-bottom: 1px solid var(--slate-200);">
        <img src="${this.escapeHtml(imgUrl)}" alt="${this.escapeHtml(product.name)}" style="width: 60px; height: 60px; object-fit: cover; border-radius: 8px; border: 1px solid var(--slate-200);" onerror="this.src='assets/images/products/placeholder.svg'">
        <div>
          <h4 style="margin: 0; font-size: 1.05rem; font-weight: 700;">${this.escapeHtml(product.name)}</h4>
          <span style="font-size: 0.8rem; color: var(--slate-500); font-family: monospace;">SKU: ${this.escapeHtml(product.sku || 'N/A')} · Base Price: ${this.formatCurrency(product.selling_price)}</span>
          <div style="margin-top: 0.25rem;">
            <span class="badge badge-primary" style="font-size: 0.8rem;">Consolidated Stock: <strong>${totalQty} ${this.escapeHtml(product.unit || 'pcs')}</strong></span>
          </div>
        </div>
      </div>

      <div class="table-responsive">
        <table class="data-table" style="font-size: 0.85rem;">
          <thead>
            <tr>
              <th>Branch Location</th>
              <th style="text-align: center;">On-Hand Stock</th>
              <th style="text-align: right;">Selling Price</th>
              <th style="text-align: center;">Catalog Status</th>
            </tr>
          </thead>
          <tbody>
            ${branchList.map(item => `
              <tr>
                <td>
                  <strong>${this.escapeHtml(item.branch.name)}</strong>
                  <div style="font-family: monospace; font-size: 0.75rem; color: var(--slate-500);">${this.escapeHtml(item.branch.branch_code)}</div>
                </td>
                <td style="text-align: center; font-weight: 700; font-size: 0.95rem;">
                  <span class="badge ${item.qty <= 0 ? 'badge-danger' : (item.qty <= 5 ? 'badge-warning' : 'badge-success')}">
                    ${item.qty} ${this.escapeHtml(product.unit || 'pcs')}
                  </span>
                </td>
                <td style="text-align: right;">
                  ${item.customPrice !== null ? `
                    <span style="font-weight: 700; color: var(--primary);">${this.formatCurrency(item.customPrice)}</span>
                    <span class="badge badge-neutral" style="font-size: 0.65rem; display: block; margin-top: 2px;">Custom</span>
                  ` : `
                    <span>${this.formatCurrency(product.selling_price)}</span>
                    <span style="font-size: 0.7rem; color: var(--slate-400); display: block;">Standard</span>
                  `}
                </td>
                <td style="text-align: center;">
                  ${item.isAvail ? `
                    <span class="badge badge-success" style="font-size: 0.72rem;"><i class="fa-solid fa-check"></i> Active</span>
                  ` : `
                    <span class="badge badge-neutral" style="font-size: 0.72rem;"><i class="fa-solid fa-ban"></i> Disabled</span>
                  `}
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;

    const modal = document.getElementById('branch-stock-modal');
    if (modal) modal.classList.add('active');
  }

  closeBranchStockModal() {
    this.selectedStockModalProduct = null;
    const modal = document.getElementById('branch-stock-modal');
    if (modal) modal.classList.remove('active');
  }

  openTransferModalFromStock() {
    const prodId = this.selectedStockModalProduct?.id;
    this.closeBranchStockModal();
    if (prodId) {
      setTimeout(() => {
        this.openTransferModal(prodId);
      }, 150);
    }
  }

  // --- Sales History & Profit Reports ---

  setSalesBranchFilter(branchCode) {
    this.salesBranchFilter = branchCode;
    this.renderCurrentView();
  }

  getSalesHTML() {
    const isCashier = this.isCashier();
    const filteredSales = (this.salesBranchFilter && this.salesBranchFilter !== 'ALL')
      ? this.sales.filter(s => (s.branch_code || 'MAIN-01').toUpperCase() === this.salesBranchFilter.toUpperCase())
      : this.sales;

    const salesMetrics = filteredSales.map(s => ({
      sale: s,
      metrics: this.getSaleProfitMetrics(s)
    }));

    const totalRev = salesMetrics.reduce((sum, item) => sum + item.metrics.netRevenue, 0);
    const totalProfit = salesMetrics.reduce((sum, item) => sum + item.metrics.netProfit, 0);
    const totalRefunded = filteredSales.reduce((sum, s) => sum + Number(s.refunded_amount || 0), 0);

    return `
      <div class="panel" style="margin-bottom: 1.5rem;">
        <div class="panel-body" style="display: flex; gap: 2rem; flex-wrap: wrap;">
          <div>
            <span style="font-size: 0.8rem; color: var(--slate-500); text-transform: uppercase; font-weight: 600;">Total Transactions</span>
            <p style="font-size: 1.4rem; font-weight: 700; color: var(--slate-900);">${filteredSales.length}</p>
          </div>
          <div>
            <span style="font-size: 0.8rem; color: var(--slate-500); text-transform: uppercase; font-weight: 600;">Net Sales Revenue</span>
            <p style="font-size: 1.4rem; font-weight: 700; color: var(--primary);">${this.formatCurrency(totalRev)}</p>
          </div>
          ${totalRefunded > 0 ? `
            <div>
              <span style="font-size: 0.8rem; color: #dc2626; text-transform: uppercase; font-weight: 600;">Refunded / Returned</span>
              <p style="font-size: 1.4rem; font-weight: 700; color: #dc2626;">-${this.formatCurrency(totalRefunded)}</p>
            </div>
          ` : ''}
          ${!isCashier ? `
            <div>
              <span style="font-size: 0.8rem; color: var(--slate-500); text-transform: uppercase; font-weight: 600;">Net Gross Profit</span>
              <p style="font-size: 1.4rem; font-weight: 700; color: var(--success);">${this.formatCurrency(totalProfit)}</p>
            </div>
          ` : ''}
        </div>
      </div>

      <div class="panel">
        <div class="panel-header" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.75rem;">
          <h3><i class="fa-solid fa-receipt"></i> Completed Store Sales & Receipts Ledger</h3>
          <div style="display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap;">
            <button type="button" class="btn btn-outline btn-sm" onclick="app.openSalesReturnModal()" style="color: #4338ca; border-color: #c7d2fe; font-weight: 700;">
              <i class="fa-solid fa-arrow-rotate-left"></i> Process Return
            </button>
            <label style="font-size: 0.8rem; font-weight: 600; color: var(--slate-600);"><i class="fa-solid fa-store"></i> Branch:</label>
            <select id="sales-branch-filter" class="form-control" style="width: auto; padding: 0.35rem 0.65rem; font-size: 0.82rem; font-weight: 600;" onchange="app.setSalesBranchFilter(this.value)">
              <option value="ALL">All Branches (Consolidated)</option>
              ${(this.branches || []).map(b => `
                <option value="${this.escapeHtml(b.branch_code)}" ${this.salesBranchFilter === b.branch_code ? 'selected' : ''}>
                  ${this.escapeHtml(b.branch_code)} - ${this.escapeHtml(b.name)}
                </option>
              `).join('')}
            </select>
          </div>
        </div>
        <div class="panel-body">
          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Receipt #</th>
                  <th>Date & Time</th>
                  <th>Branch</th>
                  <th>Customer (Buyer)</th>
                  <th>Revenue</th>
                  ${!isCashier ? '<th>Factory Cost</th>' : ''}
                  ${!isCashier ? '<th>Profit</th>' : ''}
                  <th>Payment</th>
                  <th>Receipt</th>
                </tr>
              </thead>
              <tbody>
                ${filteredSales.length > 0 ? filteredSales.map(s => `
                  <tr style="cursor: pointer;" onclick="app.viewSaleReceipt(${this.jsStr(s.id)})">
                    <td style="font-weight: 600; font-family: monospace;">${this.escapeHtml(s.receipt_number)}</td>
                    <td>${this.escapeHtml(s.sale_date)}</td>
                    <td><span class="badge badge-outline" style="font-family: monospace; font-size: 0.75rem;">${this.escapeHtml(s.branch_code || 'MAIN-01')}</span></td>
                    <td>${this.escapeHtml(s.customer_name || 'Walk-in Customer')}</td>
                    <td style="font-weight: 700;">${this.formatCurrency(s.total_amount)}</td>
                    ${!isCashier ? `<td style="color: var(--slate-500);">${this.formatCurrency(s.total_cost || 0)}</td>` : ''}
                    ${!isCashier ? `
                      <td>
                        ${(() => {
                          const m = this.getSaleProfitMetrics(s);
                          if (m.isFullyRefunded) {
                            return `<span style="color: var(--slate-400); font-weight: 600;">${this.formatCurrency(0)}</span> <span class="badge badge-neutral" style="font-size: 0.65rem; margin-left: 3px;">Void</span>`;
                          }
                          if (m.isPartiallyRefunded) {
                            return `<span style="color: var(--success); font-weight: 700;">+${this.formatCurrency(m.netProfit)}</span> <span class="badge badge-warning" style="font-size: 0.65rem; margin-left: 3px;">Net</span>`;
                          }
                          return `<span style="color: var(--success); font-weight: 700;">+${this.formatCurrency(s.gross_profit || 0)}</span>`;
                        })()}
                      </td>
                    ` : ''}
                    <td>
                      <span class="badge badge-neutral">${this.escapeHtml(s.payment_method)}</span>
                      ${s.payment_reference ? `<div style="font-size: 0.72rem; color: #0284c7; font-weight: 600; font-family: monospace; margin-top: 2px;">Ref: ${this.escapeHtml(s.payment_reference)}</div>` : ''}
                    </td>
                    <td>
                      <div style="display: flex; gap: 0.35rem;">
                        <button class="btn btn-outline btn-sm" onclick="event.stopPropagation(); app.viewSaleReceipt(${this.jsStr(s.id)})">
                          <i class="fa-solid fa-print"></i> View
                        </button>
                        <button class="btn btn-outline btn-sm" style="color: #4338ca; border-color: #c7d2fe; font-weight: 600;" onclick="event.stopPropagation(); app.openSalesReturnModal(${this.jsStr(s.receipt_number)})" title="Process customer merchandise return for this sale">
                          <i class="fa-solid fa-arrow-rotate-left"></i> Return
                        </button>
                      </div>
                    </td>
                  </tr>
                `).join('') : `
                  <tr>
                    <td colspan="${isCashier ? 7 : 9}" style="text-align: center; padding: 3rem; color: var(--slate-400);">
                      <i class="fa-solid fa-receipt" style="font-size: 2rem; margin-bottom: 0.5rem; display: block;"></i>
                      No sales recorded for the selected branch.
                    </td>
                  </tr>
                `}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  }

  bindSalesEvents() { }

  async viewSaleReceipt(saleId) {
    let sale = this.sales.find(s => s.id === saleId);
    if (!sale) return;

    if (!sale.items || sale.items.length === 0) {
      if (this.isOnline) {
        try {
          const res = await this.apiFetch(`api/endpoints/sales.php?id=${saleId}`);
          const data = await res.json();
          if (data.success && data.sale) {
            sale = data.sale;
          }
        } catch (e) {
          console.warn('Could not fetch sale details');
        }
      }
    }

    if (!sale.items) {
      sale.items = [{ name: 'Store Items Total', quantity: 1, selling_price: sale.total_amount }];
    }

    // Server returns `product_name`; offline/local sales use `name`. Normalize both.
    sale.items = sale.items.map(it => {
      const prod = this.products.find(p => String(p.id) === String(it.product_id));
      return {
        ...it,
        name: it.name || it.product_name || (prod ? prod.name : 'Item'),
        selling_price: it.selling_price || it.unit_selling_price || it.unit_price || 0
      };
    });

    if (sale.customer_id) {
      const cust = this.customers.find(c => c.id === sale.customer_id);
      if (cust) {
        sale.customer_balance = cust.balance;
      }
    }

    this.showReceiptModal(sale);
  }

  // --- Customers (Buyers) ---

  getCustomersHTML() {
    return `
      <div class="panel">
        <div class="panel-header">
          <h3><i class="fa-solid fa-users"></i> Customers (Buyers) Directory</h3>
          <button class="btn btn-primary" onclick="app.openNewCustomerModal()">
            <i class="fa-solid fa-user-plus"></i> Add Customer
          </button>
        </div>
        <div class="panel-body">
          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Customer Name</th>
                  <th>Phone Number</th>
                  <th>Email</th>
                  <th>Address</th>
                  <th>Outstanding Balance</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                ${this.customers.map(c => {
      const bal = Number(c.balance || 0);
      return `
                    <tr>
                      <td style="font-weight: 600;">${this.escapeHtml(c.name)}</td>
                      <td>${this.escapeHtml(c.phone || 'N/A')}</td>
                      <td>${this.escapeHtml(c.email || 'N/A')}</td>
                      <td>${this.escapeHtml(c.address || 'In-Store')}</td>
                      <td>
                        ${bal > 0 ? `
                          <span style="color: var(--danger); font-weight: 700;">
                            <i class="fa-solid fa-triangle-exclamation"></i> ${this.formatCurrency(bal)}
                          </span>
                        ` : (bal < 0 ? `
                          <span class="badge badge-success" style="font-weight: 600;">
                            <i class="fa-solid fa-credit-card"></i> Credit: ${this.formatCurrency(Math.abs(bal))}
                          </span>
                        ` : `
                          <span style="color: var(--slate-600); font-weight: 500;">
                            ${this.formatCurrency(0)}
                          </span>
                        `)}
                      </td>
                      <td>
                        <div style="display: flex; gap: 0.35rem;">
                          ${c.id !== 'cust-walkin' ? `
                            <button class="btn btn-outline btn-sm" onclick="app.openDebtPaymentModal(${this.jsStr(c.id)})" title="Record payment or deposit" style="color: var(--success); border-color: var(--success);">
                              <i class="fa-solid fa-hand-holding-dollar"></i> Pay
                            </button>
                            <button class="btn btn-outline btn-sm" onclick="app.openCustomerStatementModal(${this.jsStr(c.id)})" title="View Statement of Account & Ledger" style="color: var(--primary); border-color: var(--primary);">
                              <i class="fa-solid fa-file-invoice"></i> Statement
                            </button>
                          ` : ''}
                          <button class="btn btn-outline btn-sm" onclick="app.editCustomer(${this.jsStr(c.id)})" title="Edit Details">
                            <i class="fa-solid fa-pen"></i> Edit
                          </button>
                          ${(c.id !== 'cust-walkin' && !this.isCashier()) ? `
                            <button class="btn btn-outline btn-sm" onclick="app.confirmDeleteCustomer(${this.jsStr(c.id)}, ${this.jsStr(c.name)})" style="color: var(--danger); border-color: var(--danger-border);" title="Delete Customer">
                              <i class="fa-solid fa-trash"></i>
                            </button>
                          ` : ''}
                        </div>
                      </td>
                    </tr>
                  `;
    }).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  }

  bindCustomersEvents() { }

  openNewCustomerModal() {
    document.getElementById('cust-form-id').value = '';
    document.getElementById('cust-form-name').value = '';
    document.getElementById('cust-form-phone').value = '';
    document.getElementById('cust-form-email').value = '';
    document.getElementById('cust-form-address').value = '';
    document.getElementById('cust-form-balance').value = '0.00';
    document.getElementById('cust-form-notes').value = '';
    document.getElementById('customer-modal').classList.add('active');
  }

  editCustomer(customerId) {
    const c = this.customers.find(item => item.id === customerId);
    if (!c) return;

    document.getElementById('cust-form-id').value = c.id;
    document.getElementById('cust-form-name').value = c.name;
    document.getElementById('cust-form-phone').value = c.phone || '';
    document.getElementById('cust-form-email').value = c.email || '';
    document.getElementById('cust-form-address').value = c.address || '';
    document.getElementById('cust-form-balance').value = c.balance || 0;
    document.getElementById('cust-form-notes').value = c.notes || '';
    document.getElementById('customer-modal').classList.add('active');
  }

  closeCustomerModal() {
    document.getElementById('customer-modal').classList.remove('active');
  }

  async saveCustomerForm() {
    const id = document.getElementById('cust-form-id').value || ('cust_' + Math.random().toString(36).substring(2, 10));
    const isEdit = Boolean(document.getElementById('cust-form-id').value);
    const name = document.getElementById('cust-form-name').value.trim();

    if (!name) {
      this.showToast('Customer name is required.', 'warning');
      return;
    }

    const payload = {
      id: id,
      name: name,
      phone: document.getElementById('cust-form-phone').value.trim(),
      email: document.getElementById('cust-form-email').value.trim(),
      address: document.getElementById('cust-form-address').value.trim(),
      balance: parseFloat(document.getElementById('cust-form-balance').value) || 0,
      notes: document.getElementById('cust-form-notes').value.trim()
    };

    if (isEdit) {
      const idx = this.customers.findIndex(c => c.id === id);
      if (idx >= 0) {
        this.customers[idx] = payload;
        await localDB.customers.put(payload);
      }
    } else {
      this.customers.push(payload);
      await localDB.customers.put(payload);
    }

    if (this.isOnline) {
      try {
        await this.apiFetch('api/endpoints/customers.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
      } catch (err) {
        await localDB.sync_outbox.add({
          entity: 'customer',
          action: 'CREATE',
          data: payload,
          timestamp: new Date().toISOString(),
          synced: 0
        });
      }
    } else {
      await localDB.sync_outbox.add({
        entity: 'customer',
        action: 'CREATE',
        data: payload,
        timestamp: new Date().toISOString(),
        synced: 0
      });
    }

    this.closeCustomerModal();
    this.renderCurrentView();
    this.showToast('Customer saved successfully!', 'success');
  }

  openDebtPaymentModal(customerId) {
    const c = this.customers.find(item => item.id === customerId);
    if (!c) return;

    document.getElementById('debt-pay-customer-id').value = c.id;
    document.getElementById('debt-pay-customer-name').innerText = c.name;
    const balEl = document.getElementById('debt-pay-current-balance');
    const bal = Number(c.balance || 0);

    if (bal > 0) {
      balEl.innerText = `${this.formatCurrency(bal)} (Customer owes store)`;
      balEl.style.color = 'var(--danger)';
    } else if (bal < 0) {
      balEl.innerText = `${this.formatCurrency(Math.abs(bal))} (Store Credit / Advance)`;
      balEl.style.color = 'var(--success)';
    } else {
      balEl.innerText = `${this.formatCurrency(0)} (Account settled)`;
      balEl.style.color = 'var(--slate-700)';
    }

    const payInput = document.getElementById('debt-pay-amount');
    payInput.value = bal > 0 ? bal.toFixed(2) : '';
    document.getElementById('debt-pay-notes').value = '';

    document.getElementById('debt-payment-modal').classList.add('active');
    setTimeout(() => payInput.select(), 100);
  }

  closeDebtPaymentModal() {
    const modal = document.getElementById('debt-payment-modal');
    if (modal) modal.classList.remove('active');
  }

  async saveDebtPayment() {
    const custId = document.getElementById('debt-pay-customer-id')?.value;
    const amount = parseFloat(document.getElementById('debt-pay-amount')?.value) || 0;
    const method = document.getElementById('debt-pay-method')?.value || 'CASH';
    const notes = document.getElementById('debt-pay-notes')?.value.trim() || 'Direct debt settlement';

    if (!custId) return;
    if (amount <= 0) {
      this.showToast('Please enter a valid payment amount greater than zero.', 'warning');
      return;
    }

    const customerObj = this.customers.find(c => c.id === custId);
    const prevBal = Number(customerObj?.balance || 0);

    // One key for one payment. The same id rides the local record, the online ask and the
    // queue row: the shop's books refuse a replay of it, and sync.php needs it to know which
    // row it has already applied. Queued without an id, an offline settlement was skipped on
    // every sync pass - the cash left the drawer, the receipt printed, and the account on the
    // shop's book never moved.
    const payId = 'pay_' + Date.now().toString(36) + (Math.random().toString(36).slice(2, 8));
    const paymentRecord = {
      id: payId,
      customer_id: custId,
      user_id: this.currentUser?.id || 'local',
      amount: amount,
      payment_method: method,
      notes: notes,
      created_at: new Date().toISOString()
    };
    const payload = {
      action: 'record_payment',
      payment_id: payId,
      customer_id: custId,
      amount: amount,
      payment_method: method,
      notes: notes
    };

    if (this._debtPayInFlight) return;
    this._debtPayInFlight = true;

    let verdict = { verdict: 'unreachable' };
    try {
      if (this.isOnline) {
        try {
          const res = await this.apiFetch('api/endpoints/customers.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
          });
          verdict = await this.classifyApiResponse(res);
        } catch (e) {
          verdict = { verdict: 'unreachable' };
        }
      }

      // The shop said no: no account moved, and nothing goes in the queue behind a decision.
      // This is the branch that used to be filed as an outage and re-applied a day later.
      if (verdict.verdict === 'refused') {
        const replay = !!(verdict.body && verdict.body.already_recorded);
        await this.fetchCustomers();
        this.renderCurrentView();
        this.showToast(replay
          ? `The shop already holds this payment of ${this.formatCurrency(amount)} - it was not taken twice.`
          : `Payment of ${this.formatCurrency(amount)} was NOT taken: ${verdict.message}`, 'danger', 12000);
        return;
      }

      // Accepted, or nobody answered: either way the till keeps its own copy of the money it
      // has in hand, but only the shop's answer may set the balance the receipt prints.
      let newBal = prevBal - amount;
      if (verdict.verdict === 'accepted' && verdict.body && verdict.body.customer) {
        newBal = Number(verdict.body.customer.balance);
      }
      if (customerObj) {
        customerObj.balance = newBal;
        await localDB.customers.put(customerObj);
      }
      try {
        await localDB.customer_payments.put(Object.assign({}, paymentRecord, { synced: verdict.verdict === 'accepted' ? 1 : 0 }));
      } catch (e) { }

      if (verdict.verdict === 'accepted') {
        await this.logClientActivity(
          'DEBT_PAYMENT',
          `Received debt payment of ${this.formatCurrency(amount)} (${method}) from '${customerObj?.name || custId}'. Remaining: ${this.formatCurrency(newBal)}.`,
          false
        );
      } else {
        await localDB.sync_outbox.add({
          entity: 'customer_payment',
          action: 'PAYMENT',
          data: Object.assign({}, paymentRecord),
          timestamp: new Date().toISOString(),
          synced: 0
        });
        await this.logClientActivity(
          'DEBT_PAYMENT',
          `Received offline debt payment of ${this.formatCurrency(amount)} (${method}) from '${customerObj?.name || custId}'.`,
          true
        );
      }

      const paymentReceiptData = {
        receipt_number: `PAY-${payId.slice(-6).toUpperCase()}`,
        payment_date: new Date().toLocaleString(),
        customer_id: custId,
        customer_name: customerObj?.name || 'Customer',
        customer_phone: customerObj?.phone || '',
        prev_balance: prevBal,
        amount_paid: amount,
        new_balance: newBal,
        payment_method: method,
        notes: notes,
        cashier_name: this.currentUser?.full_name || this.currentUser?.username || 'Cashier'
      };

      await this.fetchCustomers();
      this.closeDebtPaymentModal();
      this.renderCurrentView();
      this.showToast(verdict.verdict === 'accepted'
        ? `Payment of ${this.formatCurrency(amount)} recorded. Balance ${this.formatCurrency(Math.max(0, newBal))}.`
        : `Payment of ${this.formatCurrency(amount)} is on this till and waiting to sync - the shop's book has not taken it yet.`,
        verdict.verdict === 'accepted' ? 'success' : 'warning', 9000);
      this.showDebtPaymentReceipt(paymentReceiptData);
    } finally {
      this._debtPayInFlight = false;
    }
  }

  showDebtPaymentReceipt(data) {
    const modal = document.getElementById('receipt-modal');
    const container = document.getElementById('printable-receipt-area');
    if (!modal || !container) return;

    this.currentSaleForReceipt = null;
    this.currentPaymentReceipt = data;
    this.currentReturnForReceipt = null;
    const retBtn = document.getElementById('receipt-btn-return');
    if (retBtn) retBtn.style.display = 'none';
    const voidBtn = document.getElementById('receipt-btn-void');
    if (voidBtn) voidBtn.style.display = 'none';

    const prof = this.storeProfile;
    const isCleared = data.new_balance <= 0;
    const typo = this.getReceiptTypographyStyles();

    container.innerHTML = `
      <div class="receipt-wrapper ${typo.classes}" style="${typo.cssText}">
        <div class="receipt-header-center">
          ${this.shouldPrintReceiptLogo() ? `<img src="${this.escapeHtml(this.getStoreLogo())}" alt="Logo" class="receipt-logo">` : ''}
          <h3>${this.escapeHtml(prof.store_name)}</h3>
          <p style="font-size: 0.8rem; margin: 0.2rem 0;">${this.escapeHtml(prof.tagline || '')}</p>
          <p style="font-size: 0.75rem;">${this.escapeHtml(prof.address || '')}</p>
          <p style="font-size: 0.75rem;">Phone: ${this.escapeHtml(prof.phone || '')}${prof.show_tax_on_receipt !== 0 && prof.tax_number ? ` | Tax ID: ${this.escapeHtml(prof.tax_number)}` : ''}</p>
          <div class="receipt-divider"></div>
          <p style="font-size: 0.85rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.05em; margin: 0.25rem 0;">
            <i class="fa-solid fa-receipt"></i> Official Debt Payment Receipt
          </p>
        </div>

        <div style="font-size: 0.75rem; margin-bottom: 0.5rem; line-height: 1.45;">
          <div><strong>Payment Receipt #:</strong> ${this.escapeHtml(data.receipt_number)}</div>
          <div><strong>Date & Time:</strong> ${this.escapeHtml(data.payment_date)}</div>
          <div><strong>Customer:</strong> ${this.escapeHtml(data.customer_name)}</div>
          ${data.customer_phone ? `<div><strong>Phone:</strong> ${this.escapeHtml(data.customer_phone)}</div>` : ''}
          <div><strong>Cashier:</strong> ${this.escapeHtml(data.cashier_name)}</div>
        </div>

        <div class="receipt-divider"></div>

        <div style="font-size: 0.8rem; line-height: 1.6;">
          <div style="display: flex; justify-content: space-between;">
            <span>Previous Outstanding Debt:</span>
            <span style="font-weight: 600;">${this.formatCurrency(data.prev_balance)}</span>
          </div>

          <div style="display: flex; justify-content: space-between; font-weight: bold; font-size: 1rem; margin: 0.4rem 0; background: #f1f5f9; padding: 0.4rem 0.5rem; border-radius: 4px; border: 1px dashed #64748b;">
            <span>AMOUNT SETTLED:</span>
            <span style="color: #15803d;">${this.formatCurrency(data.amount_paid)}</span>
          </div>

          <div style="display: flex; justify-content: space-between;">
            <span>Payment Tender:</span>
            <span style="font-weight: 600;">${this.escapeHtml(data.payment_method)}</span>
          </div>

          ${data.notes ? `
            <div style="font-size: 0.75rem; color: #475569; margin: 0.25rem 0; font-style: italic;">
              Memo/Notes: "${this.escapeHtml(data.notes)}"
            </div>
          ` : ''}

          <div class="receipt-divider"></div>

          <div style="display: flex; justify-content: space-between; font-weight: bold; font-size: 0.95rem; margin-top: 0.35rem;">
            <span>REMAINING BALANCE:</span>
            <span style="color: ${isCleared ? '#15803d' : '#b91c1c'};">
              ${isCleared ? 'CLEARED (' + this.formatCurrency(0) + ')' : this.formatCurrency(data.new_balance)}
            </span>
          </div>
          ${data.new_balance < 0 ? `
            <div style="font-size: 0.72rem; color: #15803d; text-align: right; margin-top: 0.15rem;">
              (Advance Store Credit: ${this.formatCurrency(Math.abs(data.new_balance))})
            </div>
          ` : ''}
        </div>

        <div class="receipt-divider"></div>

        <div style="margin-top: 1.5rem; display: flex; justify-content: space-between; font-size: 0.72rem; color: #475569;">
          <div style="border-top: 1px solid #94a3b8; width: 45%; padding-top: 0.25rem; text-align: center;">Cashier Signature</div>
          <div style="border-top: 1px solid #94a3b8; width: 45%; padding-top: 0.25rem; text-align: center;">Customer Signature</div>
        </div>

        <div style="text-align: center; font-size: 0.75rem; margin-top: 1rem;">
          <p>${this.escapeHtml(prof.receipt_footer || 'Thank you for your prompt settlement!')}</p>
        </div>
      </div>
    `;

    modal.classList.add('active');
  }

  // --- Customer Statement of Account & Ledger ---

  async openCustomerStatementModal(customerId) {
    const cust = this.customers.find(c => c.id === customerId);
    if (!cust) return;

    const modal = document.getElementById('customer-statement-modal');
    const container = document.getElementById('printable-statement-area');
    if (!modal || !container) return;

    container.innerHTML = `
      <div style="text-align: center; padding: 3rem; color: var(--slate-500);">
        <i class="fa-solid fa-spinner fa-spin fa-2x"></i>
        <p style="margin-top: 0.5rem;">Loading customer ledger history...</p>
      </div>
    `;
    modal.classList.add('active');

    // 1. Credit Sales (filter by customer_id)
    let customerSales = this.sales.filter(s => s.customer_id === customerId);
    
    // If online, fetch customer sales from API to ensure complete item details
    if (this.isOnline) {
      try {
        const res = await this.apiFetch(`api/endpoints/sales.php?customer_id=${encodeURIComponent(customerId)}`);
        const json = await res.json();
        if (json.success && Array.isArray(json.sales)) {
          json.sales.forEach(srvSale => {
            const existingIdx = customerSales.findIndex(s => s.id === srvSale.id);
            if (existingIdx >= 0) {
              customerSales[existingIdx] = { ...customerSales[existingIdx], ...srvSale };
            } else {
              customerSales.push(srvSale);
            }
          });
        }
      } catch (e) { }
    }

    const creditSales = customerSales.filter(s => 
      ((s.payment_method || '').toUpperCase() === 'CREDIT' || (Number(s.total_amount || 0) > Number(s.amount_paid || 0)))
    );

    // 2. Payments (merge API + localDB)
    let payments = [];
    if (this.isOnline) {
      try {
        const res = await this.apiFetch(`api/endpoints/customers.php?customer_id=${encodeURIComponent(customerId)}&payments=1`);
        const json = await res.json();
        if (json.success && Array.isArray(json.payments)) {
          payments = json.payments;
        }
      } catch (e) { }
    }

    try {
      const localPayments = await localDB.customer_payments.where('customer_id').equals(customerId).toArray();
      localPayments.forEach(lp => {
        if (!payments.some(p => p.id === lp.id)) {
          payments.push(lp);
        }
      });
    } catch (e) { }

    // 3. Assemble unified ledger
    const ledger = [];

    creditSales.forEach(s => {
      // A void already came off this account on the shop's book, so the statement moves nothing
      // for it. The slip still shows, at nil, because a customer who kept his copy of it would
      // otherwise read a statement that quietly forgot the bill.
      if (this.isVoidedSale(s)) {
        ledger.push({
          date: s.sale_date || s.created_at || 'N/A',
          timestamp: new Date(s.sale_date || s.created_at).getTime() || 0,
          ref: s.receipt_number || s.id,
          sale_id: s.id,
          sale_data: s,
          type: 'Voided Receipt',
          description: `Receipt voided &bull; Bill of ${this.formatCurrency(Number(s.total_amount || 0))} cancelled${s.void_reason ? ` (${this.escapeHtml(String(s.void_reason))})` : ''} | Nothing charged, goods returned`,
          total_amount: Number(s.total_amount || 0),
          amount_paid: 0,
          debit: 0,
          credit: 0,
          is_voided: true
        });
        return;
      }

      const totalAmt = Number(s.total_amount || 0);
      const paidAmt = Number(s.amount_paid || 0);
      const netDebt = Math.round((totalAmt - paidAmt) * 100) / 100;
      
      let debit = 0;
      let credit = 0;
      let desc = '';

      if (netDebt > 0) {
        debit = netDebt;
        credit = 0;
        desc = paidAmt > 0
          ? `Credit sale &bull; Bill: ${this.formatCurrency(totalAmt)} | Paid on spot: ${this.formatCurrency(paidAmt)} | Added to Debt: +${this.formatCurrency(netDebt)}`
          : `Purchased goods on credit &bull; Gross Bill: ${this.formatCurrency(totalAmt)}`;
      } else if (netDebt < 0) {
        debit = 0;
        credit = Math.abs(netDebt);
        desc = `Credit purchase with overpayment &bull; Bill: ${this.formatCurrency(totalAmt)} | Deposited: ${this.formatCurrency(paidAmt)} | Credit to Account: -${this.formatCurrency(credit)}`;
      } else {
        debit = 0;
        credit = 0;
        desc = `Sale paid in full &bull; ${this.formatCurrency(totalAmt)}`;
      }

      ledger.push({
        date: s.sale_date || s.created_at || 'N/A',
        timestamp: new Date(s.sale_date || s.created_at).getTime() || 0,
        ref: s.receipt_number || s.id,
        sale_id: s.id,
        sale_data: s,
        type: 'Credit Sale',
        description: desc,
        total_amount: totalAmt,
        amount_paid: paidAmt,
        debit: debit,
        credit: credit
      });
    });

    payments.forEach(p => {
      const pAmt = Number(p.amount || 0);
      ledger.push({
        date: p.created_at ? new Date(p.created_at).toLocaleString() : 'N/A',
        timestamp: new Date(p.created_at).getTime() || 0,
        ref: p.id || 'PAY',
        sale_id: null,
        payment_data: p,
        type: `Payment (${p.payment_method || 'CASH'})`,
        description: this.escapeHtml(p.notes || 'Customer debt settlement payment'),
        debit: 0,
        credit: pAmt
      });
    });

    // 4. Sort chronologically ascending
    ledger.sort((a, b) => a.timestamp - b.timestamp);

    // 5. Reconcile with Customer Balance via Opening Balance (Initial Debt)
    let totalSalesDebtChange = 0;
    ledger.forEach(entry => {
      totalSalesDebtChange += (entry.debit - entry.credit);
    });

    const currentCustomerBalance = Number(cust.balance || 0);
    const openingBalance = Math.round((currentCustomerBalance - totalSalesDebtChange) * 100) / 100;

    if (Math.abs(openingBalance) >= 0.01) {
      ledger.unshift({
        date: cust.created_at ? new Date(cust.created_at).toLocaleDateString() : 'Account Setup',
        timestamp: cust.created_at ? new Date(cust.created_at).getTime() - 86400000 : 0,
        ref: 'OPENING-BAL',
        sale_id: null,
        type: 'Opening Balance',
        description: 'Initial customer outstanding debt brought forward from account setup',
        debit: openingBalance > 0 ? openingBalance : 0,
        credit: openingBalance < 0 ? Math.abs(openingBalance) : 0,
        is_opening: true
      });
    }

    // 6. Compute running balance and summary totals
    let runningBal = 0;
    let totalBilled = 0;
    let totalSettled = 0;

    const ledgerRows = ledger.map(entry => {
      totalBilled += entry.debit;
      totalSettled += entry.credit;
      runningBal += (entry.debit - entry.credit);
      return {
        ...entry,
        running_balance: runningBal
      };
    });

    this._activeCustomerStatementLedger = ledgerRows;

    const prof = this.storeProfile;
    const finalBal = currentCustomerBalance;

    container.innerHTML = `
      <div class="statement-wrapper">
        <div class="statement-header">
          <div style="display: flex; gap: 0.85rem; align-items: center;">
            ${this.shouldPrintReceiptLogo() ? `<img src="${this.escapeHtml(this.getStoreLogo())}" alt="Logo" style="width: 52px; height: 52px; border-radius: 12px; object-fit: contain;">` : ''}
            <div>
              <h3 style="font-size: 1.4rem; font-weight: 800; color: var(--slate-900); margin-bottom: 0.25rem;">
                ${this.escapeHtml(prof.store_name)}
              </h3>
              <p style="font-size: 0.85rem; color: var(--slate-600); margin: 0.15rem 0;">${this.escapeHtml(prof.address || '')}</p>
              <p style="font-size: 0.85rem; color: var(--slate-600); margin: 0.15rem 0;">Phone: ${this.escapeHtml(prof.phone || '')} | Email: ${this.escapeHtml(prof.email || '')}</p>
              <p style="font-size: 0.8rem; color: var(--slate-500); margin: 0.15rem 0;">Tax ID: ${this.escapeHtml(prof.tax_number || 'N/A')}</p>
            </div>
          </div>
          <div class="statement-badge">
            <h2>Customer Statement of Account</h2>
            <p style="font-size: 0.85rem; color: var(--slate-500); font-family: monospace;">Date: ${new Date().toLocaleDateString()}</p>
          </div>
        </div>

        <div style="display: flex; justify-content: space-between; background: var(--slate-50); border: 1px solid var(--slate-200); border-radius: var(--radius-md); padding: 1rem; margin-bottom: 1.25rem; flex-wrap: wrap; gap: 1rem;">
          <div>
            <span style="font-size: 0.75rem; text-transform: uppercase; color: var(--slate-400); font-weight: 600;">Bill To / Customer</span>
            <h4 style="font-size: 1.15rem; font-weight: 700; color: var(--slate-900); margin-top: 0.25rem;">${this.escapeHtml(cust.name)}</h4>
            <p style="font-size: 0.85rem; color: var(--slate-600); margin: 0.2rem 0;"><i class="fa-solid fa-phone" style="width: 16px;"></i> ${this.escapeHtml(cust.phone || 'No phone')}</p>
            <p style="font-size: 0.85rem; color: var(--slate-600); margin: 0.2rem 0;"><i class="fa-solid fa-envelope" style="width: 16px;"></i> ${this.escapeHtml(cust.email || 'No email')}</p>
          </div>
          <div style="text-align: right; align-self: center;">
            <span style="font-size: 0.75rem; text-transform: uppercase; color: var(--slate-400); font-weight: 600;">Account Status</span>
            <div style="font-size: 1.35rem; font-weight: 800; color: ${finalBal > 0 ? '#dc2626' : '#16a34a'}; margin-top: 0.25rem;">
              ${finalBal > 0 ? `DEBT: ${this.formatCurrency(finalBal)}` : (finalBal < 0 ? `CREDIT: ${this.formatCurrency(Math.abs(finalBal))}` : 'CLEARED (' + this.formatCurrency(0) + ')')}
            </div>
          </div>
        </div>

        <div class="statement-summary-grid" style="margin-bottom: 1.25rem;">
          <div class="statement-summary-card">
            <h5>Total Credit Incurred</h5>
            <p style="color: #b91c1c;">${this.formatCurrency(totalBilled)}</p>
          </div>
          <div class="statement-summary-card">
            <h5>Total Payments Settled</h5>
            <p style="color: #15803d;">${this.formatCurrency(totalSettled)}</p>
          </div>
          <div class="statement-summary-card">
            <h5>Current Net Balance</h5>
            <p style="color: ${finalBal > 0 ? '#b91c1c' : '#15803d'}; font-weight: 800;">${this.formatCurrency(finalBal)}</p>
          </div>
        </div>

        <div style="background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; padding: 0.6rem 0.9rem; margin-bottom: 1rem; display: flex; align-items: center; justify-content: space-between; gap: 0.5rem; font-size: 0.8rem; color: #1e40af;">
          <div>
            <i class="fa-solid fa-hand-pointer" style="margin-right: 0.4rem; color: #2563eb;"></i>
            <strong>Interactive Breakdown:</strong> Click or tap on any transaction row below to view full items purchased, deposits, and receipts.
          </div>
          <span style="font-size: 0.72rem; color: #3b82f6; font-weight: 600;">Tap row to expand / collapse</span>
        </div>

        <h4 style="font-size: 1rem; font-weight: 700; color: var(--slate-800); margin-bottom: 0.75rem;">
          <i class="fa-solid fa-list-check"></i> Chronological Transaction Ledger
        </h4>

        <div class="table-responsive" style="overflow-x: auto; -webkit-overflow-scrolling: touch;">
          <table class="statement-table" style="width: 100%; border-collapse: collapse; font-size: 0.82rem; table-layout: fixed; min-width: 820px;">
            <thead>
              <tr style="border-bottom: 2px solid #cbd5e1; background: #f1f5f9; text-align: left;">
                <th style="padding: 0.65rem 0.6rem; width: 14%; min-width: 95px;">Date</th>
                <th style="padding: 0.65rem 0.6rem; width: 15%; min-width: 120px;">Reference #</th>
                <th style="padding: 0.65rem 0.4rem; width: 9%; min-width: 75px;">Type</th>
                <th style="padding: 0.65rem 0.75rem; width: 26%; min-width: 170px;">Description</th>
                <th style="padding: 0.65rem 0.85rem; text-align: right; width: 12%; min-width: 110px;">Debit (+)</th>
                <th style="padding: 0.65rem 0.85rem; text-align: right; width: 12%; min-width: 110px;">Credit (-)</th>
                <th style="padding: 0.65rem 0.85rem; text-align: right; width: 12%; min-width: 115px;">Balance</th>
              </tr>
            </thead>
            <tbody>
              ${ledgerRows.length > 0 ? ledgerRows.map((row, idx) => `
                <tr class="statement-ledger-row ${row.is_opening ? 'statement-opening-row' : ''}" 
                    onclick="app.toggleStatementRowBreakdown(${idx})"
                    title="Tap to view how this credit was recorded">
                  <td style="font-size: 0.78rem; word-break: break-word;">${this.escapeHtml(row.date)}</td>
                  <td style="font-family: monospace; font-size: 0.78rem; font-weight: 700; color: var(--primary);">
                    <div style="display: flex; align-items: center; gap: 0.35rem;">
                      ${row.sale_id ? '<i class="fa-solid fa-receipt" style="color: #2563eb; font-size: 0.8rem;"></i>' : (row.is_opening ? '<i class="fa-solid fa-folder-open" style="color: #7c3aed; font-size: 0.8rem;"></i>' : '<i class="fa-solid fa-money-bill-wave" style="color: #16a34a; font-size: 0.8rem;"></i>')}
                      <span>${this.escapeHtml(row.ref)}</span>
                      <i class="fa-solid fa-chevron-down" id="drawer-arrow-${idx}" style="font-size: 0.65rem; color: var(--slate-400); margin-left: auto; transition: transform 0.2s ease;"></i>
                    </div>
                  </td>
                  <td>
                    <span class="badge ${row.is_voided ? 'badge-danger' : (row.debit > 0 ? 'badge-danger' : 'badge-success')}" style="font-size: 0.68rem; padding: 0.15rem 0.35rem; white-space: nowrap;">
                      ${this.escapeHtml(row.type)}
                    </span>
                  </td>
                  <td style="font-size: 0.76rem; color: var(--slate-700); word-break: break-word; line-height: 1.35;">
                    ${row.description}
                    <div style="font-size: 0.68rem; color: #4338ca; font-weight: 600; margin-top: 2px;">
                      <i class="fa-solid fa-caret-down"></i> Tap to inspect items &amp; breakdown
                    </div>
                  </td>
                  <td style="padding: 0.65rem 0.85rem; text-align: right; font-weight: 600; font-size: 0.78rem; font-variant-numeric: tabular-nums; color: ${row.debit > 0 ? '#b91c1c' : 'var(--slate-400)'}; white-space: nowrap;">
                    ${row.debit > 0 ? '+' + this.formatCurrency(row.debit) : '-'}
                  </td>
                  <td style="padding: 0.65rem 0.85rem; text-align: right; font-weight: 600; font-size: 0.78rem; font-variant-numeric: tabular-nums; color: ${row.credit > 0 ? '#15803d' : 'var(--slate-400)'}; white-space: nowrap;">
                    ${row.credit > 0 ? '-' + this.formatCurrency(row.credit) : '-'}
                  </td>
                  <td style="padding: 0.65rem 0.85rem; text-align: right; font-weight: 700; font-size: 0.8rem; font-variant-numeric: tabular-nums; color: ${row.running_balance > 0 ? '#b91c1c' : '#15803d'}; white-space: nowrap;">
                    ${this.formatCurrency(row.running_balance)}
                  </td>
                </tr>
                <!-- Expandable Drawer for Row -->
                <tr id="drawer-row-${idx}" class="statement-drawer-row" style="display: none;">
                  <td colspan="7" style="padding: 0.85rem 1rem; border-top: 1px dashed var(--slate-200); border-bottom: 2px solid var(--slate-300); background: #f8fafc;">
                    <div id="drawer-content-${idx}">
                      <div style="text-align: center; padding: 0.5rem; color: var(--slate-400); font-size: 0.8rem;">
                        <i class="fa-solid fa-spinner fa-spin"></i> Loading transaction breakdown...
                      </div>
                    </div>
                  </td>
                </tr>
              `).join('') : `
                <tr>
                  <td colspan="7" style="text-align: center; padding: 2rem; color: var(--slate-400);">
                    <i class="fa-solid fa-circle-check" style="margin-right: 0.5rem; color: #16a34a;"></i>
                    No credit transactions or payment records found for this account.
                  </td>
                </tr>
              `}
            </tbody>
          </table>
        </div>

        <div style="margin-top: 2rem; padding-top: 1rem; border-top: 1px dashed var(--slate-300); display: flex; justify-content: space-between; font-size: 0.8rem; color: var(--slate-500);">
          <div>Generated by: ${this.escapeHtml(this.currentUser?.full_name || this.currentUser?.username || 'StoreFlow System')}</div>
          <div>All records certified accurate as of ${new Date().toLocaleString()}</div>
        </div>
      </div>
    `;
  }

  // The payment slip used to be handed to the button as a JSON blob inlined into the
  // onclick attribute, where a stored note containing an entity-encoded quote could
  // break out of the handler. The row is already kept in _activeCustomerStatementLedger,
  // so the handler only needs the index.
  showStatementPaymentSlip(index) {
    const row = (this._activeCustomerStatementLedger || [])[index];
    const p = row && row.payment_data;
    if (!p) return;
    const settled = Number(p.amount || row.credit);
    const paidAt = String(p.created_at || row.date || '');
    // The slip used to hand the printer a `previous_balance` while the printer reads
    // `prev_balance`, and carried no receipt number, date or cashier at all - so a
    // settlement reprinted from the customer's statement came out of the drawer showing
    // no debt it cleared (GH₵0.00) and no number for the customer to quote if he argued.
    const when = new Date(paidAt.replace(' ', 'T'));
    this.showDebtPaymentReceipt({
      payment_id: p.id,
      receipt_number: `PAY-${String(p.id || '').slice(-6).toUpperCase()}`,
      payment_date: isNaN(when.getTime()) ? paidAt : when.toLocaleString(),
      customer_id: p.customer_id,
      customer_name: this.customers.find(c => c.id === p.customer_id)?.name || 'Customer',
      customer_phone: this.customers.find(c => c.id === p.customer_id)?.phone || '',
      cashier_name: p.cashier_name || this.currentUser?.full_name || 'Cashier',
      amount_paid: settled,
      prev_balance: Number(row.running_balance) + settled,
      new_balance: Number(row.running_balance),
      payment_method: p.payment_method || 'CASH',
      notes: p.notes
    });
  }

  async toggleStatementRowBreakdown(index) {
    const drawerRow = document.getElementById(`drawer-row-${index}`);
    const arrow = document.getElementById(`drawer-arrow-${index}`);
    const content = document.getElementById(`drawer-content-${index}`);
    if (!drawerRow || !this._activeCustomerStatementLedger) return;

    const isOpen = drawerRow.style.display !== 'none';
    if (isOpen) {
      drawerRow.style.display = 'none';
      if (arrow) arrow.style.transform = 'rotate(0deg)';
      return;
    }

    drawerRow.style.display = 'table-row';
    if (arrow) arrow.style.transform = 'rotate(180deg)';

    const row = this._activeCustomerStatementLedger[index];
    if (!row) return;

    if (row.is_opening) {
      content.innerHTML = `
        <div style="background: #faf5ff; border: 1px solid #e9d5ff; border-radius: 8px; padding: 0.75rem 1rem;">
          <div style="font-weight: 700; color: #6b21a8; font-size: 0.85rem; margin-bottom: 0.25rem;">
            <i class="fa-solid fa-folder-open"></i> Customer Opening Balance Breakdown
          </div>
          <p style="font-size: 0.8rem; color: #4c1d95; margin: 0; line-height: 1.4;">
            This initial debt balance of <strong>${this.formatCurrency(row.debit || row.credit)}</strong> was carried forward when this customer profile was created or set up in the directory.
          </p>
        </div>
      `;
      return;
    }

    if (row.payment_data) {
      const p = row.payment_data;
      content.innerHTML = `
        <div style="background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 0.75rem 1rem; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.75rem;">
          <div>
            <div style="font-weight: 700; color: #166534; font-size: 0.85rem; margin-bottom: 0.25rem;">
              <i class="fa-solid fa-circle-check"></i> Customer Debt Settlement Payment
            </div>
            <div style="font-size: 0.8rem; color: #15803d; line-height: 1.4;">
              <strong>Payment Method:</strong> ${this.escapeHtml(p.payment_method || 'CASH')} &bull; 
              <strong>Amount Settled:</strong> ${this.formatCurrency(p.amount || row.credit)} &bull; 
              <strong>Notes:</strong> ${this.escapeHtml(p.notes || 'None recorded')}
            </div>
          </div>
          <div>
            <button type="button" class="btn btn-sm btn-outline" onclick="event.stopPropagation(); app.showStatementPaymentSlip(${Number(index) || 0})" style="background: #ffffff; border-color: #86efac; color: #166534; font-weight: 600; font-size: 0.78rem;">
              <i class="fa-solid fa-print"></i> View Payment Slip
            </button>
          </div>
        </div>
      `;
      return;
    }

    if (row.sale_id) {
      content.innerHTML = `
        <div style="text-align: center; padding: 0.75rem; color: var(--slate-500); font-size: 0.8rem;">
          <i class="fa-solid fa-spinner fa-spin"></i> Loading itemized receipt products...
        </div>
      `;

      let sale = this.sales.find(s => s.id === row.sale_id) || row.sale_data;
      if (!sale || !sale.items || sale.items.length === 0) {
        if (this.isOnline) {
          try {
            const res = await this.apiFetch(`api/endpoints/sales.php?id=${encodeURIComponent(row.sale_id)}`);
            const json = await res.json();
            if (json.success && json.sale) {
              sale = json.sale;
              const idx = this.sales.findIndex(s => s.id === row.sale_id);
              if (idx >= 0) this.sales[idx] = sale;
            }
          } catch (e) { }
        }
      }

      const items = (sale && Array.isArray(sale.items)) ? sale.items : [];
      const totalBill = Number(sale?.total_amount || row.total_amount || row.debit);
      // A void gave the money back and cleared the bill, so the drawer restates it at nil rather
      // than showing a deposit and a debt the account no longer carries.
      const receiptIsVoided = this.isVoidedSale(sale);
      const amountPaid = receiptIsVoided ? 0 : Number(sale?.amount_paid || row.amount_paid || 0);
      const debtAdded = receiptIsVoided ? 0 : Math.round((totalBill - amountPaid) * 100) / 100;
      const cashierName = sale?.cashier_name || sale?.attendant_name || (this.currentUser ? this.currentUser.full_name : 'Staff');

      content.innerHTML = `
        <div style="background: #ffffff; border: 1px solid var(--slate-300); border-radius: 8px; padding: 0.85rem; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
          <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--slate-200); padding-bottom: 0.5rem; margin-bottom: 0.65rem; flex-wrap: wrap; gap: 0.5rem;">
            <div>
              <span style="font-weight: 800; color: var(--slate-900); font-size: 0.9rem;">
                <i class="fa-solid fa-receipt" style="color: #2563eb; margin-right: 0.35rem;"></i>
                Receipt #${this.escapeHtml(sale?.receipt_number || row.ref)}
              </span>
              <span style="font-size: 0.75rem; color: var(--slate-500); margin-left: 0.5rem;">
                <i class="fa-solid fa-clock"></i> ${this.escapeHtml(sale?.sale_date || row.date)} &bull; Cashier: ${this.escapeHtml(cashierName)}
              </span>
            </div>
            <div>
              <button type="button" class="btn btn-sm btn-primary" onclick="event.stopPropagation(); app.viewSaleReceipt(${this.jsStr(row.sale_id)})" style="padding: 0.35rem 0.75rem; font-size: 0.78rem;">
                <i class="fa-solid fa-print"></i> Open Official Thermal Receipt
              </button>
            </div>
          </div>

          <!-- Items Table -->
          <table style="width: 100%; font-size: 0.78rem; border-collapse: collapse; margin-bottom: 0.75rem;">
            <thead>
              <tr style="background: var(--slate-50); color: var(--slate-600); border-bottom: 1px solid var(--slate-200);">
                <th style="padding: 0.35rem 0.5rem; text-align: left;">Product Item</th>
                <th style="padding: 0.35rem 0.5rem; text-align: center; width: 15%;">Quantity</th>
                <th style="padding: 0.35rem 0.5rem; text-align: right; width: 20%;">Unit Price</th>
                <th style="padding: 0.35rem 0.5rem; text-align: right; width: 20%;">Total</th>
              </tr>
            </thead>
            <tbody>
              ${items.length > 0 ? items.map(it => {
                const prodName = it.name || it.product_name || (this.products.find(p => String(p.id) === String(it.product_id))?.name) || 'Product Item';
                const qty = Number(it.quantity || 1);
                const unitPrice = Number(it.unit_selling_price || it.unit_price || it.selling_price || 0);
                const lineTotal = Number(it.subtotal || it.total_price || (qty * unitPrice));
                return `
                  <tr style="border-bottom: 1px solid var(--slate-100);">
                    <td style="padding: 0.4rem 0.5rem; font-weight: 600; color: var(--slate-800);">${this.escapeHtml(prodName)}</td>
                    <td style="padding: 0.4rem 0.5rem; text-align: center;">${qty} ${this.escapeHtml(it.unit || 'pcs')}</td>
                    <td style="padding: 0.4rem 0.5rem; text-align: right; font-family: monospace;">${this.formatCurrency(unitPrice)}</td>
                    <td style="padding: 0.4rem 0.5rem; text-align: right; font-weight: 700; font-family: monospace;">${this.formatCurrency(lineTotal)}</td>
                  </tr>
                `;
              }).join('') : `
                <tr>
                  <td colspan="4" style="text-align: center; padding: 0.5rem; color: var(--slate-400);">
                    Item details recorded under Receipt #${this.escapeHtml(sale?.receipt_number || row.ref)}
                  </td>
                </tr>
              `}
            </tbody>
          </table>

          <!-- Financial Breakdown Summary Bar -->
          ${receiptIsVoided ? `
            <div style="background: #fef2f2; border: 1px solid #fecaca; border-radius: 6px; padding: 0.5rem 0.75rem; margin-bottom: 0.5rem; font-size: 0.78rem; color: #991b1b; line-height: 1.4;">
              <strong style="letter-spacing: 0.03em;">VOIDED${sale?.void_reason ? ` - ${this.escapeHtml(String(sale.void_reason))}` : ''}.</strong>
              This bill was cancelled the day it was rung: the money went back to you, the goods went back on the shelf, and nothing was added to your account.
              ${sale?.voided_at ? `Cleared ${this.escapeHtml(String(sale.voided_at))}${sale?.void_user_name ? ` by ${this.escapeHtml(String(sale.void_user_name))}` : ''}.` : ''}
            </div>
          ` : ''}
          <div style="background: var(--slate-50); border: 1px solid var(--slate-200); border-radius: 6px; padding: 0.5rem 0.75rem; display: flex; justify-content: space-between; align-items: center; font-size: 0.8rem; flex-wrap: wrap; gap: 0.5rem;">
            <div>
              <span style="color: var(--slate-500);">Gross Bill${receiptIsVoided ? ' (cancelled)' : ''}:</span>
              <strong style="color: ${receiptIsVoided ? '#94a3b8' : 'var(--slate-900)'}; font-family: monospace; margin-left: 0.25rem; ${receiptIsVoided ? 'text-decoration: line-through;' : ''}">${this.formatCurrency(totalBill)}</strong>
            </div>
            <div>
              <span style="color: var(--slate-500);">Deposit / Paid on Spot:</span>
              <strong style="color: #15803d; font-family: monospace; margin-left: 0.25rem;">${this.formatCurrency(amountPaid)}</strong>
            </div>
            <div>
              <span style="color: var(--slate-500);">Added to Customer Debt:</span>
              <strong style="color: ${debtAdded > 0 ? '#b91c1c' : '#15803d'}; font-family: monospace; font-size: 0.88rem; margin-left: 0.25rem;">
                ${debtAdded > 0 ? '+' + this.formatCurrency(debtAdded) : (debtAdded < 0 ? '-' + this.formatCurrency(Math.abs(debtAdded)) : this.formatCurrency(0))}
              </strong>
            </div>
          </div>
        </div>
      `;
    }
  }

  closeCustomerStatementModal() {
    const modal = document.getElementById('customer-statement-modal');
    if (modal) modal.classList.remove('active');
  }

  printCustomerStatement() {
    window.print();
  }

  // --- Cashier Register Shift Balancing & Z-Report ---

  async openShiftReportModal(selectedTerminal = null) {
    const modal = document.getElementById('shift-report-modal');
    const container = document.getElementById('shift-modal-interactive-body');
    const printContainer = document.getElementById('printable-shift-area');
    if (!modal || !container) return;

    // Determine active register for this report
    const activeTerm = this.normalizeTerminalId(selectedTerminal || this.shiftFilterTerminal || this.terminalId);
    this.shiftFilterTerminal = activeTerm;

    const todayStr = new Date().toISOString().slice(0, 10);

    // Fetch today's synchronized floats and terminals across all devices from server
    if (this.isOnline) {
      try {
        const res = await this.apiFetch(`api/endpoints/shifts.php?action=floats&date=${todayStr}&branch_code=${this.branchCode || 'MAIN-01'}`);
        if (res && res.success) {
          if (!this.todayFloats) this.todayFloats = {};
          (res.floats || []).forEach(f => {
            if (f.terminal_id) {
              const t = this.normalizeTerminalId(f.terminal_id);
              this.todayFloats[t] = parseFloat(f.opening_float || 0);
            }
          });
          if (Array.isArray(res.terminals)) {
            if (!this.activeRegisteredTerminals) this.activeRegisteredTerminals = new Set();
            res.terminals.forEach(t => {
              if (t) this.activeRegisteredTerminals.add(this.normalizeTerminalId(t));
            });
          }
        }
      } catch (e) { }
    }

    // Collect all terminals dynamically across the shop
    const availableTerms = new Set();
    if (this.terminalId) {
      availableTerms.add(this.normalizeTerminalId(this.terminalId));
    }
    if (this.todayFloats) {
      Object.keys(this.todayFloats).forEach(t => availableTerms.add(this.normalizeTerminalId(t)));
    }
    if (this.activeRegisteredTerminals) {
      this.activeRegisteredTerminals.forEach(t => availableTerms.add(t));
    }
    (this.sales || []).forEach(s => {
      const isToday = (s.sale_date || '').startsWith(todayStr) || (s.created_at || '').startsWith(todayStr);
      if (isToday && s.terminal_id) {
        availableTerms.add(this.normalizeTerminalId(s.terminal_id));
      }
    });
    (this.shifts || []).forEach(sh => {
      if (sh.terminal_id) availableTerms.add(this.normalizeTerminalId(sh.terminal_id));
    });
    (this.expenses || []).forEach(ex => {
      if (ex.terminal_id) availableTerms.add(this.normalizeTerminalId(ex.terminal_id));
    });
    if (availableTerms.size === 0) {
      availableTerms.add('REG-01');
    }
    const termList = Array.from(availableTerms).sort();

    // Filter sales by active terminal (or all terminals)
    const todaySales = this.sales.filter(s => {
      const isToday = (s.sale_date || '').startsWith(todayStr) || (s.created_at || '').startsWith(todayStr);
      if (!isToday) return false;
      if (activeTerm === 'ALL') return true;
      return (s.terminal_id || 'REG-01').toUpperCase() === activeTerm;
    });

    // A voided receipt is not in the takings and not in the drawer: the money was handed back and
    // the goods went back on the shelf. Counting one here would set an expected cash figure the
    // till cannot meet, so the Z-report names the voided slips beside the totals instead.
    const billableTodaySales = todaySales.filter(s => !this.isVoidedSale(s));
    const voidedTodaySales = todaySales.filter(s => this.isVoidedSale(s));
    const voidedTodayValue = voidedTodaySales.reduce((sum, s) => sum + Number(s.total_amount || 0), 0);

    let cashSales = 0;
    let cardSales = 0;
    let transferSales = 0;
    let creditSales = 0;
    let totalSalesGross = 0;

    billableTodaySales.forEach(s => {
      const m = (s.payment_method || '').toUpperCase();
      const amt = Number(s.total_amount || 0);
      totalSalesGross += amt;
      if (m === 'CASH') cashSales += amt;
      else if (m === 'CARD' || m === 'POS') cardSales += amt;
      else if (m === 'TRANSFER' || m === 'BANK') transferSales += amt;
      else if (m === 'CREDIT') creditSales += amt;
      else cashSales += amt;
    });

    let debtCashCollected = 0;
    try {
      const localPayments = await localDB.customer_payments.toArray();
      localPayments.filter(p => {
        const isToday = (p.created_at || '').startsWith(todayStr);
        if (!isToday) return false;
        if (activeTerm === 'ALL') return true;
        return (p.terminal_id || 'REG-01').toUpperCase() === activeTerm;
      }).forEach(p => {
        if ((p.payment_method || '').toUpperCase() === 'CASH') {
          debtCashCollected += Number(p.amount || 0);
        }
      });
    } catch (e) { }

    let cashRefunds = 0;
    try {
      if (typeof localDB !== 'undefined' && localDB.sales_returns) {
        const localReturns = await localDB.sales_returns.toArray();
        localReturns.filter(r => {
          const isToday = (r.return_date || r.created_at || '').startsWith(todayStr);
          if (!isToday) return false;
          if (activeTerm === 'ALL') return true;
          return (r.terminal_id || 'REG-01').toUpperCase() === activeTerm;
        }).forEach(r => {
          if ((r.refund_method || 'CASH').toUpperCase() === 'CASH') {
            cashRefunds += Number(r.total_refund_amount || 0);
          }
        });
      }
    } catch (e) { }

    let drawerExpenses = 0;
    try {
      (this.expenses || []).filter(e => {
        const d = (e.expense_date || e.created_at || '').slice(0, 10);
        const isDrawer = (e.payment_source || 'CASH_DRAWER').toUpperCase() === 'CASH_DRAWER';
        const isTerm = (activeTerm === 'ALL') || (!e.terminal_id || e.terminal_id.toUpperCase() === activeTerm);
        return d === todayStr && isDrawer && isTerm;
      }).forEach(e => {
        drawerExpenses += Number(e.amount || 0);
      });
    } catch (e) { }

    // Equipment Rentals Cash & Caution Reconciliation
    let rentalCashCollected = 0;
    let rentalCautionRefunded = 0;
    let rentalContractsCount = 0;

    if (typeof this.isRentalsEnabled === 'function' && this.isRentalsEnabled() && Array.isArray(this.rentals)) {
      this.rentals.forEach(r => {
        const isDispatchToday = (r.pickup_date || r.created_at || '').slice(0, 10) === todayStr;
        const isReturnToday = r.status === 'RETURNED' && (r.actual_return_date || r.updated_at || '').slice(0, 10) === todayStr;
        const matchesTerm = (activeTerm === 'ALL') || (!r.terminal_id || (r.terminal_id || 'REG-01').toUpperCase() === activeTerm);

        if (matchesTerm) {
          if (isDispatchToday) {
            const payMethod = (r.payment_method || 'CASH').toUpperCase();
            if (payMethod === 'CASH') {
              rentalContractsCount++;
              if (r.payment_status === 'PAID') {
                rentalCashCollected += Number(r.total_rental_amount || 0);
              }
              if (['HELD', 'SETTLED', 'FORFEITED'].includes(r.caution_deposit_status)) {
                rentalCashCollected += Number(r.caution_deposit || 0);
              }
            }
          }

          if (isReturnToday) {
            if (Number(r.deposit_refunded || 0) > 0) {
              rentalCautionRefunded += Number(r.deposit_refunded);
            }
            if ((r.payment_method || 'CASH').toUpperCase() === 'CASH' && Number(r.additional_amount_owed || 0) > 0 && r.payment_status === 'PAID') {
              rentalCashCollected += Number(r.additional_amount_owed);
            }
          }
        }
      });
    }

    const expectedCashInDrawer = Math.max(0, cashSales + debtCashCollected + rentalCashCollected - cashRefunds - drawerExpenses - rentalCautionRefunded);

    let savedFloat = 0;
    if (activeTerm === 'ALL') {
      if (this.todayFloats && Object.keys(this.todayFloats).length > 0) {
        savedFloat = Object.values(this.todayFloats).reduce((sum, v) => sum + Number(v || 0), 0);
      } else {
        savedFloat = parseFloat(localStorage.getItem(`storeflow_opening_float_${todayStr}`)) || 0;
      }
    } else {
      if (this.todayFloats && this.todayFloats[activeTerm] !== undefined) {
        savedFloat = Number(this.todayFloats[activeTerm]);
      } else {
        const floatKey = `storeflow_opening_float_${activeTerm}_${todayStr}`;
        savedFloat = parseFloat(localStorage.getItem(floatKey)) ||
                     parseFloat(localStorage.getItem(`storeflow_opening_float_${todayStr}`)) || 0;
      }
    }

    this.currentShiftData = {
      shift_date: new Date().toLocaleDateString(),
      shift_time: new Date().toLocaleTimeString(),
      cashier_name: this.currentUser?.full_name || this.currentUser?.username || 'Store Cashier',
      cashier_role: this.getUserRoleName() || 'Cashier',
      terminal_id: activeTerm,
      total_transactions: billableTodaySales.length + rentalContractsCount,
      voided_count: voidedTodaySales.length,
      voided_value: voidedTodayValue,
      total_sales_gross: totalSalesGross,
      cash_sales: cashSales,
      card_sales: cardSales,
      transfer_sales: transferSales,
      credit_sales: creditSales,
      debt_cash_collected: debtCashCollected,
      drawer_expenses: drawerExpenses,
      cash_refunds_paid: cashRefunds,
      rental_cash_collected: rentalCashCollected,
      rental_caution_refunded: rentalCautionRefunded,
      expected_cash: expectedCashInDrawer,
      opening_float: savedFloat,
      counted_cash: expectedCashInDrawer + savedFloat,
      variance: 0,
      notes: ''
    };

    container.innerHTML = `
      <div style="display: flex; flex-direction: column; gap: 1rem;">
        <div style="background: var(--slate-50); border: 1px solid var(--slate-200); border-radius: var(--radius-md); padding: 0.85rem 1rem; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.75rem;">
          <div>
            <div style="font-size: 0.75rem; text-transform: uppercase; color: var(--slate-400); font-weight: 600;">Shift Operator</div>
            <strong style="color: var(--slate-900); font-size: 0.95rem;">${this.escapeHtml(this.currentShiftData.cashier_name)}</strong>
            <span class="badge badge-info" style="margin-left: 0.35rem; font-size: 0.7rem;">${this.escapeHtml(this.currentShiftData.cashier_role)}</span>
            
            <div style="display: flex; align-items: center; gap: 0.4rem; margin-top: 0.4rem;">
              <span style="font-size: 0.75rem; font-weight: 700; color: var(--slate-700);"><i class="fa-solid fa-desktop" style="color: #2563eb;"></i> Account For Register:</span>
              <select id="shift-filter-terminal" class="form-control" style="font-size: 0.78rem; padding: 0.2rem 0.5rem; font-weight: 700; border-radius: 4px; height: auto; max-width: 220px;" onchange="app.openShiftReportModal(this.value)">
                ${termList.map(t => `<option value="${this.escapeHtml(t)}" ${t === activeTerm ? 'selected' : ''}>Register ${t}</option>`).join('')}
                <option value="ALL" ${activeTerm === 'ALL' ? 'selected' : ''}>🏬 All Registers (Consolidated)</option>
              </select>
            </div>
          </div>
          <div style="text-align: right; font-size: 0.8rem; color: var(--slate-500); font-family: monospace;">
            <div>${this.escapeHtml(this.currentShiftData.shift_date)}</div>
            <div>${this.escapeHtml(this.currentShiftData.shift_time)}</div>
            <div style="font-size: 0.72rem; color: #2563eb; font-weight: 700; margin-top: 0.25rem;">
              ${activeTerm === 'ALL' ? 'Consolidated Storewide Total' : `Individual Register: ${activeTerm}`}
            </div>
          </div>
        </div>

        <div style="border: 1px solid var(--slate-200); border-radius: var(--radius-md); padding: 1rem; background: #ffffff;">
          <h4 style="font-size: 0.9rem; font-weight: 700; color: var(--slate-800); margin-bottom: 0.75rem; border-bottom: 1px solid var(--slate-100); padding-bottom: 0.5rem; display: flex; justify-content: space-between; align-items: center;">
            <span><i class="fa-solid fa-cash-register"></i> Register Sales Breakdown (${billableTodaySales.length} Transactions${voidedTodaySales.length > 0 ? `, ${voidedTodaySales.length} voided` : ''})</span>
            <span class="badge badge-outline" style="font-size: 0.7rem; font-weight: 700;">${activeTerm}</span>
          </h4>
          <div style="display: flex; flex-direction: column; gap: 0.45rem; font-size: 0.85rem;">
            <div style="display: flex; justify-content: space-between;">
              <span style="color: var(--slate-600);"><i class="fa-solid fa-money-bill-wave" style="width: 18px; color: #16a34a;"></i> Cash Sales:</span>
              <strong>${this.formatCurrency(cashSales)}</strong>
            </div>
            <div style="display: flex; justify-content: space-between;">
              <span style="color: var(--slate-600);"><i class="fa-solid fa-credit-card" style="width: 18px; color: #2563eb;"></i> Card / POS Sales:</span>
              <strong>${this.formatCurrency(cardSales)}</strong>
            </div>
            <div style="display: flex; justify-content: space-between;">
              <span style="color: var(--slate-600);"><i class="fa-solid fa-building-columns" style="width: 18px; color: #7c3aed;"></i> Bank Transfers:</span>
              <strong>${this.formatCurrency(transferSales)}</strong>
            </div>
            <div style="display: flex; justify-content: space-between;">
              <span style="color: var(--slate-600);"><i class="fa-solid fa-file-invoice" style="width: 18px; color: #d97706;"></i> Credit Sales (Unpaid):</span>
              <strong>${this.formatCurrency(creditSales)}</strong>
            </div>
            <div style="display: flex; justify-content: space-between; border-top: 1px dashed var(--slate-200); padding-top: 0.45rem;">
              <span style="color: var(--slate-600);"><i class="fa-solid fa-hand-holding-dollar" style="width: 18px; color: #059669;"></i> Debt Payments (Cash Collected):</span>
              <strong style="color: #059669;">+${this.formatCurrency(debtCashCollected)}</strong>
            </div>
            ${rentalCashCollected > 0.004 ? `
            <div style="display: flex; justify-content: space-between; border-top: 1px dashed var(--slate-200); padding-top: 0.45rem;">
              <span style="color: #7c3aed;"><i class="fa-solid fa-boxes-packing" style="width: 18px; color: #7c3aed;"></i> Equipment Rentals (Cash In):</span>
              <strong style="color: #7c3aed;">+${this.formatCurrency(rentalCashCollected)}</strong>
            </div>
            ` : ''}
            <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px dashed var(--slate-200); padding-top: 0.45rem;">
              <span style="color: #dc2626;"><i class="fa-solid fa-arrow-up-from-bracket" style="width: 18px; color: #dc2626;"></i> Drawer Payouts / Expenses:</span>
              <div style="display: flex; gap: 0.45rem; align-items: center;">
                <strong style="color: #dc2626;">-${this.formatCurrency(drawerExpenses)}</strong>
                <button type="button" class="btn btn-outline btn-sm" onclick="app.openExpenseModal('CASH_DRAWER')" style="font-size: 0.7rem; padding: 0.15rem 0.45rem; color: #dc2626; border-color: #fecaca; background: #fff5f5;" title="Record cash taken from drawer">
                  + Payout
                </button>
              </div>
            </div>
            ${cashRefunds > 0.004 ? `
            <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px dashed var(--slate-200); padding-top: 0.45rem;">
              <span style="color: #dc2626;" title="Cash paid back to customers on credit notes raised on this register today"><i class="fa-solid fa-rotate-left" style="width: 18px; color: #dc2626;"></i> Cash Back on Returns:</span>
              <strong style="color: #dc2626;">-${this.formatCurrency(cashRefunds)}</strong>
            </div>
            ` : ''}
            ${rentalCautionRefunded > 0.004 ? `
            <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px dashed var(--slate-200); padding-top: 0.45rem;">
              <span style="color: #dc2626;" title="Caution security deposits handed back to hirers upon safe return of equipment"><i class="fa-solid fa-vault" style="width: 18px; color: #dc2626;"></i> Caution Deposits Refunded:</span>
              <strong style="color: #dc2626;">-${this.formatCurrency(rentalCautionRefunded)}</strong>
            </div>
            ` : ''}
            <div style="display: flex; justify-content: space-between; border-top: 1px solid var(--slate-800); padding-top: 0.5rem; font-weight: 700; font-size: 0.95rem;">
              <span>TOTAL REVENUE REGISTERED:</span>
              <span>${this.formatCurrency(totalSalesGross + debtCashCollected + rentalCashCollected)}</span>
            </div>
            ${voidedTodaySales.length > 0 ? `
              <div style="margin-top: 0.5rem; padding: 0.45rem 0.55rem; background: #fef2f2; border: 1px solid #fecaca; border-radius: 4px;">
                <div style="display: flex; justify-content: space-between; font-size: 0.8rem; color: #991b1b; font-weight: 700;">
                  <span><i class="fa-solid fa-ban" style="width: 18px; color: #b91c1c;"></i> Receipts voided on this register:</span>
                  <span>${voidedTodaySales.length} &middot; ${this.formatCurrency(voidedTodayValue)}</span>
                </div>
                <div style="font-size: 0.72rem; color: #b91c1c; margin-top: 0.25rem; line-height: 1.4;">
                  Cleared against a reason, cash handed back and the goods restocked. Already kept out of every figure above: the drawer should be ${this.formatCurrency(voidedTodayValue)} lighter than the slips this register printed.
                </div>
              </div>
            ` : ''}
          </div>
        </div>

        <div style="background: #f8fafc; border: 1px solid #cbd5e1; border-radius: var(--radius-md); padding: 1rem;">
          <h4 style="font-size: 0.9rem; font-weight: 700; color: var(--slate-800); margin-bottom: 0.75rem;">
            <i class="fa-solid fa-calculator"></i> Drawer Cash Reconciliation (${activeTerm})
          </h4>

          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem; margin-bottom: 0.75rem;">
            <div>
              <label style="font-size: 0.75rem; font-weight: 600; color: var(--slate-600); display: block; margin-bottom: 0.25rem;">
                <i class="fa-solid fa-coins" style="color: #d97706;"></i> Starting Opening Float
              </label>
              <div style="display: flex; gap: 0.4rem;">
                <input type="number" id="shift-opening-float" class="form-control" value="${savedFloat > 0 ? savedFloat.toFixed(2) : '0.00'}" step="any" oninput="app.updateShiftVariance()">
                <button type="button" class="btn btn-outline btn-sm" onclick="app.saveMorningFloat()" title="Lock in morning float for this register" style="white-space: nowrap; font-size: 0.72rem; padding: 0.25rem 0.5rem;">
                  <i class="fa-solid fa-check"></i> Set Float
                </button>
              </div>
              <span style="font-size: 0.7rem; color: var(--slate-500);">Change placed in register at start of day</span>
            </div>
            <div>
              <label style="font-size: 0.75rem; font-weight: 600; color: var(--slate-600); display: block; margin-bottom: 0.25rem;">
                <i class="fa-solid fa-money-bill-1-wave" style="color: #16a34a;"></i> Physical Cash Counted in Drawer
              </label>
              <input type="number" id="shift-counted-cash" class="form-control" value="${(expectedCashInDrawer + savedFloat).toFixed(2)}" step="any" oninput="app.updateShiftVariance()" style="font-weight: 700;">
              <span style="font-size: 0.7rem; color: var(--slate-500);">Actual cash counted at shift close</span>
            </div>
          </div>

          <div style="display: flex; justify-content: space-between; font-size: 0.85rem; padding: 0.4rem 0;">
            <span style="color: var(--slate-600);">Expected Drawer Cash (Sales + Float):</span>
            <strong id="shift-expected-display">${this.formatCurrency(expectedCashInDrawer + savedFloat)}</strong>
          </div>

          <div id="shift-variance-box" class="shift-variance-card shift-variance-balanced">
            <div style="font-size: 0.75rem; text-transform: uppercase; font-weight: 700; letter-spacing: 0.05em;">Register Status</div>
            <div id="shift-variance-val" style="font-size: 1.25rem; font-weight: 800; margin: 0.2rem 0;">BALANCED (${this.formatCurrency(0)})</div>
            <span id="shift-variance-sub" style="font-size: 0.75rem;">Drawer counted cash matches expected receipts perfectly.</span>
          </div>

          <div style="margin-top: 0.75rem;">
            <label style="font-size: 0.75rem; font-weight: 600; color: var(--slate-600); display: block; margin-bottom: 0.25rem;">
              Shift Notes / Discrepancy Reason (Optional)
            </label>
            <input type="text" id="shift-notes" class="form-control" placeholder="e.g., Drawer balanced, or reason for variance...">
          </div>

          <div style="margin-top: 0.75rem; background: #f0f9ff; border: 1.5px solid #bae6fd; border-radius: var(--radius-md); padding: 0.65rem 0.85rem;">
            <label style="display: flex; align-items: center; gap: 0.55rem; font-size: 0.82rem; font-weight: 700; color: #0369a1; cursor: pointer; margin: 0;">
              <input type="checkbox" id="shift-send-sms-owner" checked style="width: 17px; height: 17px; accent-color: #0284c7;">
              <span><i class="fa-solid fa-comment-sms"></i> Dispatch Z-Report Summary SMS to Store Owner</span>
            </label>
            <div style="font-size: 0.72rem; color: #0284c7; margin-top: 0.2rem; margin-left: 1.6rem;">
              Sends end-of-shift reconciliation (Sales, Cash, Variance) instantly via mNotify.
            </div>
          </div>
        </div>
      </div>
    `;

    this.updateShiftPrintView();
    modal.classList.add('active');
  }

  async saveMorningFloat() {
    const todayStr = new Date().toISOString().slice(0, 10);
    const activeTerm = this.normalizeTerminalId(this.shiftFilterTerminal || this.terminalId);
    const val = parseFloat(document.getElementById('shift-opening-float')?.value) || 0;
    
    localStorage.setItem(`storeflow_opening_float_${activeTerm}_${todayStr}`, val);
    localStorage.setItem(`storeflow_opening_float_${todayStr}`, val);

    if (!this.todayFloats) this.todayFloats = {};
    this.todayFloats[activeTerm] = val;

    if (!this.activeRegisteredTerminals) this.activeRegisteredTerminals = new Set();
    this.activeRegisteredTerminals.add(activeTerm);

    if (this.currentShiftData) {
      this.currentShiftData.opening_float = val;
      this.updateShiftVariance();
    }

    if (this.isOnline) {
      try {
        await this.apiFetch('api/endpoints/shifts.php?action=set_float', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            terminal_id: activeTerm,
            branch_code: this.branchCode || 'MAIN-01',
            shift_date: todayStr,
            opening_float: val
          })
        });
      } catch (e) { }
    }

    try {
      await this.logClientActivity(
        'SHIFT_OPEN',
        `Morning register float recorded: ${this.formatCurrency(val)} on Terminal ${activeTerm}.`
      );
    } catch (e) { }
    this.showToast(`✅ Morning float of ${this.formatCurrency(val)} saved for Register ${activeTerm}!`, 'success');
  }

  async promptChangeTerminal() {
    const current = this.terminalId || 'REG-01';
    const input = await this.showPromptModal({
      title: 'POS Cash Register Terminal ID',
      desc: 'Set the active register ID for this computer or device (e.g. REG-01, REG-02, REG-03). All sales, receipts, and cashier shifts on this device will be tagged with this register.',
      label: 'Terminal / Register Identifier',
      placeholder: 'e.g. REG-02',
      defaultValue: current,
      icon: 'fa-desktop',
      confirmText: 'Save Register ID'
    });
    if (input === null || input === undefined) return;
    const clean = this.normalizeTerminalId(input);

    this.terminalId = clean;
    localStorage.setItem('storeflow_terminal_id', clean);

    const topBadge = document.getElementById('topbar-terminal-badge');
    if (topBadge) topBadge.innerHTML = `<i class="fa-solid fa-desktop"></i> ${this.escapeHtml(clean)}`;
    const drawerBadge = document.getElementById('drawer-terminal-badge');
    if (drawerBadge) drawerBadge.innerHTML = `<i class="fa-solid fa-desktop"></i> ${this.escapeHtml(clean)}`;

    this.showToast(`✅ This device is now active as Register: ${clean}`, 'success');
    if (this.currentView === 'pos') {
      this.renderCurrentView();
    }
  }

  updateShiftVariance() {
    if (!this.currentShiftData) return;

    const openingFloat = parseFloat(document.getElementById('shift-opening-float')?.value) || 0;
    const countedCash = parseFloat(document.getElementById('shift-counted-cash')?.value) || 0;
    const expected = this.currentShiftData.expected_cash + openingFloat;
    const variance = countedCash - expected;

    this.currentShiftData.opening_float = openingFloat;
    this.currentShiftData.counted_cash = countedCash;
    this.currentShiftData.variance = variance;

    const expectedDisplay = document.getElementById('shift-expected-display');
    if (expectedDisplay) expectedDisplay.innerText = this.formatCurrency(expected);

    const varianceBox = document.getElementById('shift-variance-box');
    const varianceVal = document.getElementById('shift-variance-val');
    const varianceSub = document.getElementById('shift-variance-sub');

    if (varianceBox && varianceVal && varianceSub) {
      if (Math.abs(variance) < 0.01) {
        varianceBox.className = 'shift-variance-card shift-variance-balanced';
        varianceVal.innerText = 'BALANCED (' + this.formatCurrency(0) + ')';
        varianceSub.innerText = 'Drawer counted cash matches expected receipts perfectly.';
      } else if (variance > 0) {
        varianceBox.className = 'shift-variance-card shift-variance-surplus';
        varianceVal.innerText = `SURPLUS (+${this.formatCurrency(variance)})`;
        varianceSub.innerText = 'Physical cash exceeds expected receipts. Surplus recorded in drawer log.';
      } else {
        varianceBox.className = 'shift-variance-card shift-variance-shortage';
        varianceVal.innerText = `SHORTAGE (${this.formatCurrency(variance)})`;
        varianceSub.innerText = 'Warning: Physical cash is below expected receipts. Shortage flagged for review.';
      }
    }

    this.updateShiftPrintView();
  }

  updateShiftPrintView() {
    const printContainer = document.getElementById('printable-shift-area');
    if (!printContainer || !this.currentShiftData) return;

    const prof = this.storeProfile;
    const d = this.currentShiftData;
    const isBalanced = Math.abs(d.variance) < 0.01;
    const typo = this.getReceiptTypographyStyles();

    printContainer.innerHTML = `
      <div class="receipt-wrapper ${typo.classes}" style="${typo.cssText}">
        <div class="receipt-header-center">
          ${this.shouldPrintReceiptLogo() ? `<img src="${this.escapeHtml(this.getStoreLogo())}" alt="Logo" class="receipt-logo">` : ''}
          <h3>${this.escapeHtml(prof.store_name)}</h3>
          <p style="font-size: 0.8rem; margin: 0.2rem 0;">${this.escapeHtml(prof.tagline || '')}</p>
          <p style="font-size: 0.75rem;">${this.escapeHtml(prof.address || '')}</p>
          <div class="receipt-divider"></div>
          <p style="font-size: 0.95rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.05em; margin: 0.25rem 0;">
            <i class="fa-solid fa-calculator"></i> CASH REGISTER Z-REPORT
          </p>
          <p style="font-size: 0.75rem;">Daily End-of-Shift Reconciliation</p>
        </div>

        <div style="font-size: 0.75rem; margin-bottom: 0.5rem; line-height: 1.45;">
          <div><strong>Date & Time:</strong> ${this.escapeHtml(d.shift_date)} ${this.escapeHtml(d.shift_time)}</div>
          <div><strong>Operator:</strong> ${this.escapeHtml(d.cashier_name)} (${this.escapeHtml(d.cashier_role)})</div>
          <div><strong>Register / Terminal:</strong> <span style="font-family: monospace; font-weight: 700;">${this.escapeHtml(d.terminal_id || "REG-01")}</span></div>
          <div><strong>Total Transactions:</strong> ${d.total_transactions} sales completed${Number(d.voided_count || 0) > 0 ? ` <span style="color:#b91c1c; font-weight:700;">&middot; ${Number(d.voided_count)} voided, kept out below</span>` : ''}</div>
        </div>

        <div class="receipt-divider"></div>

        <div style="font-size: 0.78rem; line-height: 1.55;">
          <div style="font-weight: 700; text-transform: uppercase; margin-bottom: 0.35rem;">Sales Summary By Tender</div>
          <div style="display: flex; justify-content: space-between;">
            <span>Cash Sales:</span>
            <span>${this.formatCurrency(d.cash_sales)}</span>
          </div>
          <div style="display: flex; justify-content: space-between;">
            <span>POS / Card Sales:</span>
            <span>${this.formatCurrency(d.card_sales)}</span>
          </div>
          <div style="display: flex; justify-content: space-between;">
            <span>Bank Transfers:</span>
            <span>${this.formatCurrency(d.transfer_sales)}</span>
          </div>
          <div style="display: flex; justify-content: space-between;">
            <span>Credit Sales:</span>
            <span>${this.formatCurrency(d.credit_sales)}</span>
          </div>
          <div style="display: flex; justify-content: space-between; margin-top: 0.25rem; font-weight: 700;">
            <span>TOTAL GROSS SALES:</span>
            <span>${this.formatCurrency(d.total_sales_gross)}</span>
          </div>
          ${Number(d.voided_count || 0) > 0 ? `
            <div style="display: flex; justify-content: space-between; margin-top: 0.25rem; padding: 0.2rem 0.35rem; background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; font-weight: 700; font-size: 0.74rem;">
              <span>Voided (cash handed back, goods restocked):</span>
              <span>${Number(d.voided_count)} &middot; ${this.formatCurrency(Number(d.voided_value || 0))}</span>
            </div>
          ` : ''}
        </div>

        <div class="receipt-divider"></div>

        <div style="font-size: 0.78rem; line-height: 1.55;">
          <div style="font-weight: 700; text-transform: uppercase; margin-bottom: 0.35rem;">Drawer Balancing</div>
          <div style="display: flex; justify-content: space-between;">
            <span>Opening Float:</span>
            <span>${this.formatCurrency(d.opening_float)}</span>
          </div>
          <div style="display: flex; justify-content: space-between;">
            <span>Cash Sales Receipts:</span>
            <span>${this.formatCurrency(d.cash_sales)}</span>
          </div>
          <div style="display: flex; justify-content: space-between;">
            <span>Debt Cash Settlements:</span>
            <span>+${this.formatCurrency(d.debt_cash_collected)}</span>
          </div>
          ${Number(d.rental_cash_collected || 0) > 0 ? `
          <div style="display: flex; justify-content: space-between; color: #7c3aed;">
            <span>Rental Cash Receipts:</span>
            <span>+${this.formatCurrency(d.rental_cash_collected)}</span>
          </div>
          ` : ''}
          ${Number(d.drawer_expenses || 0) > 0 ? `
          <div style="display: flex; justify-content: space-between; color: #dc2626;">
            <span>Drawer Payouts / Expenses:</span>
            <span>-${this.formatCurrency(d.drawer_expenses)}</span>
          </div>
          ` : ''}
          ${Number(d.cash_refunds_paid || 0) > 0 ? `
          <div style="display: flex; justify-content: space-between; color: #dc2626;">
            <span>Cash Back on Returns:</span>
            <span>-${this.formatCurrency(d.cash_refunds_paid)}</span>
          </div>
          ` : ''}
          ${Number(d.rental_caution_refunded || 0) > 0 ? `
          <div style="display: flex; justify-content: space-between; color: #dc2626;">
            <span>Rental Caution Refunded:</span>
            <span>-${this.formatCurrency(d.rental_caution_refunded)}</span>
          </div>
          ` : ''}
          <div style="display: flex; justify-content: space-between; font-weight: 700; border-top: 1px dashed #000; padding-top: 0.25rem; margin-top: 0.25rem;">
            <span>Expected Cash:</span>
            <span>${this.formatCurrency(d.expected_cash + d.opening_float)}</span>
          </div>
          <div style="display: flex; justify-content: space-between; font-weight: 700; font-size: 0.85rem; margin-top: 0.25rem;">
            <span>Actual Counted Cash:</span>
            <span>${this.formatCurrency(d.counted_cash)}</span>
          </div>

          <div style="display: flex; justify-content: space-between; font-weight: 800; font-size: 0.9rem; margin-top: 0.35rem; border-top: 1px solid #000; border-bottom: 1px solid #000; padding: 0.35rem 0;">
            <span>CASH VARIANCE:</span>
            <span>${isBalanced ? 'BALANCED (' + this.formatCurrency(0) + ')' : (d.variance > 0 ? `+${this.formatCurrency(d.variance)} (SURPLUS)` : `${this.formatCurrency(d.variance)} (SHORTAGE)`)}</span>
          </div>
        </div>

        ${d.notes ? `
          <div style="font-size: 0.72rem; margin: 0.5rem 0; font-style: italic;">
            Notes: "${this.escapeHtml(d.notes)}"
          </div>
        ` : ''}

        <div class="receipt-divider"></div>

        <div style="margin-top: 1.5rem; display: flex; justify-content: space-between; font-size: 0.72rem; color: #000;">
          <div style="border-top: 1px solid #000; width: 45%; padding-top: 0.25rem; text-align: center;">Cashier Sign-off</div>
          <div style="border-top: 1px solid #000; width: 45%; padding-top: 0.25rem; text-align: center;">Supervisor Sign-off</div>
        </div>

        <div style="text-align: center; font-size: 0.7rem; margin-top: 1rem; color: #475569;">
          <p>Official Shift Z-Report certified by StoreFlow POS</p>
        </div>
      </div>
    `;
  }

  closeShiftReportModal() {
    const modal = document.getElementById('shift-report-modal');
    if (modal) modal.classList.remove('active');
  }

  previewShiftReceiptSlip() {
    this.updateShiftPrintView();
    const slipHTML = document.getElementById('printable-shift-area')?.innerHTML;
    if (!slipHTML) return;
    const receiptContainer = document.getElementById('printable-receipt-area');
    const receiptModal = document.getElementById('receipt-modal');
    if (receiptContainer && receiptModal) {
      receiptContainer.innerHTML = slipHTML;
      receiptModal.classList.add('active');
    }
  }

  async printShiftReport() {
    if (this.isPrinterConnected && this.serialPort && this.currentShiftData) {
      try {
        const rawData = this.encodeEscPosShift(this.currentShiftData);
        await this.sendRawToPrinter(rawData);
        this.showToast('Z-Report printed directly to USB thermal printer.', 'success');
        return;
      } catch (err) {
        console.warn('Direct thermal print error, falling back to browser print:', err);
      }
    }
    this.updateShiftPrintView();
    // Copy into printable-receipt-area to ensure compatibility across all print drivers
    const slipHTML = document.getElementById('printable-shift-area')?.innerHTML;
    const receiptContainer = document.getElementById('printable-receipt-area');
    if (receiptContainer && slipHTML) {
      receiptContainer.innerHTML = slipHTML;
    }
    setTimeout(() => {
      window.print();
    }, 80);
  }

  async saveShiftClose() {
    if (!this.currentShiftData) return;

    const notes = document.getElementById('shift-notes')?.value.trim() || '';
    this.currentShiftData.notes = notes;

    const d = this.currentShiftData;
    const isBalanced = Math.abs(d.variance) < 0.01;
    const varianceStr = isBalanced ? 'Balanced (' + this.formatCurrency(0) + ')' : (d.variance > 0 ? `Surplus of +${this.formatCurrency(d.variance)}` : `Shortage of ${this.formatCurrency(d.variance)}`);

    // Dedicated register_shifts record
    const shiftRecord = {
      id: 'shift_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
      shift_number: 'SHIFT-' + new Date().toISOString().slice(0, 10).replace(/-/g, '') + '-' + Math.floor(1000 + Math.random() * 9000),
      user_id: this.currentUser ? this.currentUser.id : 1,
      cashier_name: d.cashier_name || 'Cashier',
      role_name: d.cashier_role || 'Cashier',
      terminal_id: this.terminalId || 'REG-01',
      // Without this the close is filed under whatever branch the endpoint defaults to, while the
      // Z-note and the drawer seams are scoped to the till's own - one box reading level here and
      // short there. shifts.php checks a cashier cannot file into another branch.
      branch_code: this.branchCode || 'MAIN-01',
      shift_date: new Date().toISOString().slice(0, 10),
      shift_time: new Date().toTimeString().slice(0, 8),
      opening_float: Number(d.opening_float || 0),
      total_transactions: Number(d.total_transactions || 0),
      total_sales_gross: Number(d.total_sales_gross || 0),
      voided_count: Number(d.voided_count || 0),
      voided_value: Number(d.voided_value || 0),
      cash_sales: Number(d.cash_sales || 0),
      card_sales: Number(d.card_sales || 0),
      transfer_sales: Number(d.transfer_sales || 0),
      credit_sales: Number(d.credit_sales || 0),
      debt_cash_collected: Number(d.debt_cash_collected || 0),
      drawer_expenses: Number(d.drawer_expenses || 0),
      cash_refunds_paid: Number(d.cash_refunds_paid || 0),
      rental_cash_collected: Number(d.rental_cash_collected || 0),
      rental_caution_refunded: Number(d.rental_caution_refunded || 0),
      expected_cash: Number(d.expected_cash || 0),
      counted_cash: Number(d.counted_cash || 0),
      variance: Number(d.variance || 0),
      notes: notes,
      created_at: new Date().toISOString()
    };

    try {
      await localDB.register_shifts.put(shiftRecord);
      this.shifts.unshift(shiftRecord);
    } catch (e) { }

    if (this.isOnline) {
      try {
        await this.apiFetch('api/endpoints/shifts.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(shiftRecord)
        });
      } catch (err) {
        await localDB.sync_outbox.add({
          entity: 'shift',
          action: 'CREATE',
          data: shiftRecord,
          timestamp: new Date().toISOString(),
          synced: 0
        });
      }
    } else {
      await localDB.sync_outbox.add({
        entity: 'shift',
        action: 'CREATE',
        data: shiftRecord,
        timestamp: new Date().toISOString(),
        synced: 0
      });
    }

    // Log to activity logs (persists locally and syncs to backend/outbox)
    try {
      await this.logClientActivity(
        'SHIFT_CLOSE',
        `Daily shift closed on Terminal ${this.terminalId || 'REG-01'}. Expected: ${this.formatCurrency(d.expected_cash + d.opening_float)}, Counted: ${this.formatCurrency(d.counted_cash)}, Variance: ${varianceStr}.${notes ? ` Notes: "${notes}"` : ''}`
      );
    } catch (e) { }

    if (document.getElementById('shift-send-sms-owner')?.checked) {
      // The note names the close it was composed from: shift_number is how sms.php finds the row
      // the shop signed for instead of reading the figures still sitting on the screen.
      d.shift_number = shiftRecord.shift_number;
      d.shift_date_iso = shiftRecord.shift_date;
      this.sendShiftSummarySMS(false);
    }

    this.closeShiftReportModal();
    this.showToast(`Register shift closed successfully! Register variance: ${varianceStr}`, isBalanced ? 'success' : (d.variance > 0 ? 'info' : 'warning'));
  }

  async sendShiftSummarySMS(interactive = true) {
    if (!this.currentShiftData) {
      this.showToast('No shift data available.', 'warning');
      return;
    }
    const d = this.currentShiftData;
    let targetPhone = this.storeProfile.mnotify_owner_phone || this.storeProfile.phone || '';

    if (interactive) {
      const phoneInput = await this.showPromptModal({
        title: 'Send Shift Z-Report SMS (mNotify)',
        desc: `Send end-of-shift balancing summary for Shift #${d.shift_number || 'CURRENT'} directly to the store owner or manager.`,
        label: 'Owner / Manager Mobile Number',
        placeholder: 'e.g. 0244123456',
        defaultValue: targetPhone,
        icon: 'fa-comment-sms',
        confirmText: 'Dispatch Z-Report'
      });
      if (!phoneInput) return;
      targetPhone = phoneInput;
    }

    if (!targetPhone) {
      if (interactive) this.showToast('Owner phone number is not configured.', 'warning');
      return;
    }

    // The drawer is scoped by the book's own day. shift_date is a display string and its order
    // depends on the browser's locale, so the ISO the shift was filed under travels beside it.
    const isoDay = (s) => /^\d{4}-\d{2}-\d{2}$/.test(String(s || '')) ? String(s) : '';
    const bookDate = isoDay(d.shift_date_iso) || isoDay(d.shift_date) || new Date().toISOString().slice(0, 10);

    try {
      if (interactive) this.showToast('Dispatching Z-Report SMS via mNotify...', 'info');
      const res = await this.apiFetch('api/endpoints/sms.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'send_shift_summary',
          recipient: targetPhone.trim(),
          cashier_name: d.cashier_name || 'Cashier',
          shift_number: d.shift_number || ('SHIFT-' + new Date().toISOString().slice(0, 10).replace(/-/g, '')),
          branch_code: this.branchCode || 'MAIN-01',
          terminal_id: this.terminalId || 'REG-01',
          shift_date: d.shift_date || new Date().toISOString().slice(0, 10),
          shift_date_iso: bookDate,
          shift_time: d.shift_time || new Date().toTimeString().slice(0, 8),
          total_sales: Number(d.total_sales_gross || 0).toFixed(2),
          cash_sales: Number(d.cash_sales || 0).toFixed(2),
          card_transfer: (Number(d.card_sales || 0) + Number(d.transfer_sales || 0)).toFixed(2),
          debt_cash: Number(d.debt_cash_collected || 0).toFixed(2),
          opening_float: Number(d.opening_float || 0).toFixed(2),
          rental_cash: Number(d.rental_cash_collected || 0).toFixed(2),
          caution_refunded: Number(d.rental_caution_refunded || 0).toFixed(2),
          voided_count: Number(d.voided_count || 0),
          voided_value: Number(d.voided_value || 0).toFixed(2),
          counted_cash: Number(d.counted_cash || 0).toFixed(2),
          notes: d.notes || ''
        })
      });
      const data = await res.json();
      if (data.success) {
        this.showToast(data.message || 'Z-Report summary SMS delivered to store owner!', 'success');
      } else if (interactive) {
        this.showToast(data.message || 'Failed to send shift summary SMS.', 'danger');
      }
    } catch (err) {
      if (interactive) this.showToast('SMS network error: ' + err.message, 'danger');
    }
  }

  // --- Shift History Archive (Z-Reports) ---

  async openShiftHistoryModal() {
    const modal = document.getElementById('shift-history-modal');
    const tbody = document.getElementById('shift-history-table-body');
    if (!modal || !tbody) return;

    modal.classList.add('active');
    tbody.innerHTML = `<tr><td colspan="8" style="text-align: center; padding: 2rem;"><i class="fa-solid fa-spinner fa-spin"></i> Loading shift history...</td></tr>`;

    let shifts = [];
    if (this.isOnline) {
      try {
        const res = await this.apiFetch('api/endpoints/shifts.php');
        const json = await res.json();
        if (json.success && Array.isArray(json.shifts)) {
          shifts = json.shifts;
          this.shifts = shifts;
          await localDB.register_shifts.clear();
          await localDB.register_shifts.bulkPut(shifts);
        }
      } catch (e) { }
    }

    if (shifts.length === 0) {
      try {
        shifts = await localDB.register_shifts.orderBy('created_at').reverse().toArray();
      } catch (e) { }
    }

    this.renderShiftHistoryRows(shifts);
  }

  renderShiftHistoryRows(shifts) {
    const tbody = document.getElementById('shift-history-table-body');
    if (!tbody) return;

    if (!shifts || shifts.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="8" style="text-align: center; padding: 2rem; color: var(--slate-400);">
            <i class="fa-solid fa-calculator" style="margin-right: 0.5rem;"></i> No past shift closures recorded yet.
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = shifts.map(s => {
      const v = Number(s.variance || 0);
      const isBalanced = Math.abs(v) < 0.01;
      const statusBadge = isBalanced
        ? `<span class="badge badge-success">Balanced (${this.formatCurrency(0)})</span>`
        : (v > 0 ? `<span class="badge badge-info">Surplus (+${this.formatCurrency(v)})</span>` : `<span class="badge badge-danger">Shortage (${this.formatCurrency(v)})</span>`);

      return `
        <tr>
          <td style="font-size: 0.82rem; font-weight: 600;">${this.escapeHtml(s.shift_date || '')} ${this.escapeHtml(s.shift_time || '')}</td>
          <td style="font-family: monospace; font-size: 0.8rem; font-weight: 700;">${this.escapeHtml(s.shift_number || s.id)}</td>
          <td><strong>${this.escapeHtml(s.cashier_name || 'Cashier')}</strong></td>
          <td><span class="badge badge-outline" style="font-size: 0.72rem;">${this.escapeHtml(s.terminal_id || 'REG-01')}</span></td>
          <td style="text-align: right; font-weight: 700;">${this.formatCurrency(s.total_sales_gross || 0)}</td>
          <td style="text-align: right;">${this.formatCurrency(s.counted_cash || 0)}</td>
          <td style="text-align: center;">${statusBadge}</td>
          <td style="text-align: right;">
            <button class="btn btn-outline btn-sm" onclick="app.viewHistoricalShift(${this.jsStr(s.id)})" title="Reprint Z-Report">
              <i class="fa-solid fa-print"></i> Z-Report
            </button>
          </td>
        </tr>
      `;
    }).join('');
    this.applyMobileTableLabels(tbody.closest('table') || tbody);
  }

  closeShiftHistoryModal() {
    const modal = document.getElementById('shift-history-modal');
    if (modal) modal.classList.remove('active');
  }

  async viewHistoricalShift(shiftId) {
    let shift = (this.shifts || []).find(s => s.id === shiftId);
    if (!shift) {
      shift = await localDB.register_shifts.get(shiftId);
    }
    if (!shift) {
      this.showToast('Shift record not found.', 'warning');
      return;
    }

    this.currentShiftData = {
      shift_date: shift.shift_date,
      shift_time: shift.shift_time,
      cashier_name: shift.cashier_name,
      cashier_role: shift.role_name || 'Cashier',
      terminal_id: shift.terminal_id || 'REG-01',
      total_transactions: shift.total_transactions || 0,
      total_sales_gross: Number(shift.total_sales_gross || 0),
      voided_count: Number(shift.voided_count || 0),
      voided_value: Number(shift.voided_value || 0),
      cash_sales: Number(shift.cash_sales || 0),
      card_sales: Number(shift.card_sales || 0),
      transfer_sales: Number(shift.transfer_sales || 0),
      credit_sales: Number(shift.credit_sales || 0),
      debt_cash_collected: Number(shift.debt_cash_collected || 0),
      drawer_expenses: Number(shift.drawer_expenses || 0),
      cash_refunds_paid: Number(shift.cash_refunds_paid || 0),
      rental_cash_collected: Number(shift.rental_cash_collected || 0),
      rental_caution_refunded: Number(shift.rental_caution_refunded || 0),
      expected_cash: Number(shift.expected_cash || 0),
      opening_float: Number(shift.opening_float || 0),
      counted_cash: Number(shift.counted_cash || 0),
      variance: Number(shift.variance || 0),
      notes: shift.notes || ''
    };

    this.closeShiftHistoryModal();
    this.openShiftReportModal();
  }

  // --- ESC/POS Direct Hardware Thermal Printing & Cash Drawer Kick ---

  isSerialSupported() {
    return 'serial' in navigator;
  }

  async connectThermalPrinter() {
    if (!this.isSerialSupported()) {
      this.showToast('Web Serial is not supported in this browser. Use Chrome, Edge, or Opera for direct thermal printing.', 'warning');
      return;
    }

    try {
      this.serialPort = await navigator.serial.requestPort();
      await this.serialPort.open({ baudRate: 9600 });
      this.isPrinterConnected = true;
      localStorage.setItem('storeflow_printer_mode', 'SERIAL');
      this.updatePrinterUI();
      this.showToast('USB Thermal Printer connected successfully!', 'success');
    } catch (err) {
      console.warn('Printer connection cancelled or failed:', err);
      if (err.name !== 'NotFoundError') {
        this.showToast('Failed to connect to printer: ' + err.message, 'danger');
      }
    }
  }

  async disconnectThermalPrinter() {
    if (this.serialPort) {
      try {
        await this.serialPort.close();
      } catch (e) { }
      this.serialPort = null;
    }
    this.isPrinterConnected = false;
    localStorage.setItem('storeflow_printer_mode', 'BROWSER');
    this.updatePrinterUI();
    this.showToast('Thermal printer disconnected.', 'info');
  }

  async toggleThermalPrinterConnection() {
    if (this.isPrinterConnected) {
      await this.disconnectThermalPrinter();
    } else {
      await this.connectThermalPrinter();
    }
  }

  updatePrinterUI() {
    const label = document.getElementById('thermal-printer-label');
    const btn = document.getElementById('btn-thermal-printer-status');
    if (label && btn) {
      if (this.isPrinterConnected) {
        btn.className = 'btn btn-success btn-sm';
        label.innerHTML = '<i class="fa-solid fa-circle-check"></i> ESC/POS Direct';
        btn.title = 'Direct USB/Serial Thermal Printer Connected (Click to Disconnect)';
      } else {
        btn.className = 'btn btn-outline btn-sm';
        label.innerText = 'Printer: Browser';
        btn.title = 'Using Standard Browser Print Dialogue (Click to Connect USB Thermal)';
      }
    }

    const drawerLabel = document.getElementById('drawer-printer-label');
    if (drawerLabel) {
      drawerLabel.innerHTML = this.isPrinterConnected ? '<i class="fa-solid fa-circle-check" style="color: #4ade80;"></i> Printer: ESC/POS Direct' : 'Printer: Browser Print';
    }

    const profBadge = document.getElementById('prof-printer-badge');
    if (profBadge) {
      profBadge.className = `badge ${this.isPrinterConnected ? 'badge-success' : 'badge-slate'}`;
      profBadge.innerHTML = `<i class="fa-solid ${this.isPrinterConnected ? 'fa-plug-circle-check' : 'fa-plug-circle-xmark'}"></i> ${this.isPrinterConnected ? 'Hardware Thermal Online' : 'Standard Browser Print Fallback'}`;
    }

    if (this.currentView === 'settings') {
      this.renderCurrentView();
    }
  }

  async sendRawToPrinter(uint8Data) {
    if (!this.serialPort || !this.serialPort.writable) {
      throw new Error('Printer not connected');
    }
    const writer = this.serialPort.writable.getWriter();
    try {
      await writer.write(uint8Data);
    } finally {
      writer.releaseLock();
    }
  }

  async kickCashDrawer() {
    if (!this.isPrinterConnected || !this.serialPort) {
      this.showToast('Connect a USB/Serial thermal printer first to trigger the cash drawer kick.', 'warning');
      return;
    }
    try {
      // ESC p m t1 t2 (Standard Epson/Star pulse: pin 2/5, 50ms)
      const kickCommand = new Uint8Array([0x1B, 0x70, 0x00, 0x19, 0xFA]);
      await this.sendRawToPrinter(kickCommand);
      this.showToast('Cash drawer open pulse sent!', 'success');
    } catch (e) {
      this.showToast('Failed to open cash drawer: ' + e.message, 'danger');
    }
  }

  async testPrintThermal() {
    if (!this.isPrinterConnected || !this.serialPort) {
      this.showToast('Please connect a USB/Serial thermal printer first.', 'warning');
      return;
    }
    try {
      const dummySale = {
        receipt_number: 'TEST-' + Math.floor(1000 + Math.random() * 9000),
        sale_date: new Date().toLocaleString(),
        cashier_name: this.currentUser?.full_name || 'Admin',
        terminal_id: this.terminalId || 'REG-01',
        customer_name: 'Test Diagnostics',
        subtotal: 10.00,
        discount: 0,
        tax: 0,
        total_amount: 10.00,
        payment_method: 'CASH',
        amount_paid: 10.00,
        change_due: 0.00,
        items: [
          { name: 'Hardware Self-Test', quantity: 1, unit_selling_price: 10.00, subtotal: 10.00 }
        ]
      };
      const raw = this.encodeEscPosReceipt(dummySale);
      await this.sendRawToPrinter(raw);
      this.showToast('Test receipt printed successfully!', 'success');
    } catch (e) {
      this.showToast('Test print failed: ' + e.message, 'danger');
    }
  }

  encodeEscPosReceipt(sale) {
    const encoder = new TextEncoder();
    const prof = this.storeProfile || {};
    const parts = [];

    const is58mm = (prof.receipt_paper_width === '58mm');
    const isCompact = (prof.receipt_font_size === 'compact');
    const isBoldDensity = (prof.receipt_font_weight === 'bold');
    const isUltraCompact = (prof.receipt_spacing === 'ultra_compact' || !prof.receipt_spacing);
    const divider = is58mm ? ' ------------------------------\n' : ' --------------------------------------\n';

    const append = (str) => parts.push(encoder.encode(str));
    const appendBytes = (bytes) => parts.push(new Uint8Array(bytes));

    // INIT + Set safe left margin (GS L 16 dots = ~2mm) so outer characters never clip
    appendBytes([0x1B, 0x40]);
    appendBytes([0x1D, 0x4C, 0x10, 0x00]);

    // Apply font size: Font B (9x17) for compact, Font A (12x24) for standard/large
    if (isCompact) {
      appendBytes([0x1B, 0x4D, 0x01]);
    } else {
      appendBytes([0x1B, 0x4D, 0x00]);
    }

    // Apply thermal density: Double-strike mode for bold
    if (isBoldDensity) {
      appendBytes([0x1B, 0x47, 0x01]);
    }

    // Header (Centered, Double Height / Bold)
    appendBytes([0x1B, 0x61, 0x01]); // Center
    appendBytes([0x1B, 0x45, 0x01]); // Bold on
    appendBytes([0x1D, 0x21, 0x01]); // Double height
    append((prof.store_name || 'STOREFLOW MART') + '\n');
    appendBytes([0x1D, 0x21, 0x00]); // Normal size
    appendBytes([0x1B, 0x45, 0x00]); // Bold off

    if (prof.tagline) append(prof.tagline + '\n');
    if (prof.address) append(prof.address + '\n');
    if (prof.phone) append('Tel: ' + prof.phone + '\n');
    if (prof.tax_number) append('Tax ID: ' + prof.tax_number + '\n');

    append(divider);
    appendBytes([0x1B, 0x61, 0x00]); // Align Left

    if (isUltraCompact || isCompact) {
      append(`Rec: #${sale.receipt_number || sale.id}  ${(sale.sale_date || '').slice(0, 16)}\n`);
      append(`Attendant: ${sale.cashier_name || 'Attendant'}  Pay: ${sale.payment_method || 'CASH'}\n`);
      if (sale.customer_name && !['walk-in', 'walk-in customer'].includes(sale.customer_name.trim().toLowerCase())) {
        append(`Cust: ${sale.customer_name}\n`);
      }
    } else {
      append(`Receipt: ${sale.receipt_number || sale.id}\n`);
      append(`Date:    ${sale.sale_date || new Date().toLocaleString()}\n`);
      append(`Cashier: ${sale.cashier_name || 'Attendant'}\n`);
      append(`Terminal: ${sale.terminal_id || this.terminalId || 'REG-01'}\n`);
      append(`Customer: ${sale.customer_name || 'Walk-in Customer'}\n`);
    }

    // The roll has to argue for itself: a voided slip that reads like a receipt will be filed
    // as proof of purchase and counted as takings by whoever finds it in six months.
    const isVoidedSlip = this.isVoidedSale(sale);
    if (isVoidedSlip) {
      appendBytes([0x1B, 0x61, 0x01]); // Center
      appendBytes([0x1B, 0x45, 0x01]); // Bold on
      appendBytes([0x1D, 0x21, 0x11]); // Double height and width
      append('*** VOIDED ***\n');
      appendBytes([0x1D, 0x21, 0x00]); // Normal size
      appendBytes([0x1B, 0x45, 0x00]); // Bold off
      appendBytes([0x1B, 0x61, 0x00]); // Align Left
      append(`Reason : ${String(sale.void_reason || 'No reason recorded')}\n`);
      append(`Cleared: ${sale.voided_at || 'today'}${sale.void_user_name ? ` by ${sale.void_user_name}` : ''}\n`);
      append('This receipt took no money and is\nnot proof of purchase. The goods are\nback on the shelf.\n');
    }
    append(divider);

    // Column Headers & Items
    // A line for two crates reads "2" in the quantity column and nothing else, so the roll
    // has to say what the two were: the size, and how many of the loose unit a size holds.
    const sizeLine = (item) => {
      const mult = Number(item.multiplier || 1);
      const sizeName = String(item.unit || '').trim();
      if (mult <= 1 || sizeName === '') return '';
      return `  ${sizeName} = ${parseFloat((mult).toFixed(3))} ${String(item.base_unit || '').trim()}\n`;
    };
    if (is58mm) {
      append(' Item        Qty  Price  Total\n');
      append(divider);
      (sale.items || []).forEach(item => {
        const name = (item.name || item.product_name || 'Item').slice(0, 11).padEnd(11, ' ');
        const qty = String(item.quantity || 1).padStart(3, ' ');
        const price = Number(item.selling_price || item.unit_selling_price || 0).toFixed(2).padStart(6, ' ');
        const total = Number(item.subtotal || 0).toFixed(2).padStart(6, ' ');
        append(` ${name} ${qty} ${price} ${total}\n`);
        const note = sizeLine(item);
        if (note) append(note);
      });
    } else {
      append(' Item               Qty   Price    Total\n');
      append(divider);
      (sale.items || []).forEach(item => {
        const name = (item.name || item.product_name || 'Item').slice(0, 16).padEnd(16, ' ');
        const qty = String(item.quantity || 1).padStart(3, ' ');
        const price = Number(item.selling_price || item.unit_selling_price || 0).toFixed(2).padStart(7, ' ');
        const total = Number(item.subtotal || 0).toFixed(2).padStart(8, ' ');
        append(` ${name} ${qty} ${price} ${total}\n`);
        const note = sizeLine(item);
        if (note) append(note);
      });
    }

    append(divider);
    appendBytes([0x1B, 0x61, 0x02]); // Align Right
    append(`Subtotal: ${this.formatCurrency(sale.subtotal || 0)}\n`);
    if (Number(sale.discount || 0) > 0) {
      append(`Discount: -${this.formatCurrency(sale.discount)}\n`);
    }
    if (Number(sale.loyalty_discount || 0) > 0) {
      const pts = Number(sale.loyalty_points_redeemed || 0);
      append(`Points${pts > 0 ? ` (${pts.toLocaleString()} pts)` : ''}: -${this.formatCurrency(Number(sale.loyalty_discount))}\n`);
    }
    if (Number(sale.tier_discount || 0) > 0) {
      append(`Member perk: -${this.formatCurrency(Number(sale.tier_discount))}\n`);
    }
    if (Number(sale.tax || 0) > 0) {
      if (isVoidedSlip) {
        append(`Tax: ${this.formatCurrency(sale.tax)} NOT CHARGED\n`);
      } else {
        append(`Tax: +${this.formatCurrency(sale.tax)}\n`);
      }
    }

    appendBytes([0x1B, 0x45, 0x01]); // Bold on
    appendBytes([0x1D, 0x21, 0x01]); // Double height
    append(`${isVoidedSlip ? 'RINGED' : 'TOTAL'}: ${this.formatCurrency(sale.total_amount || 0)}\n`);
    appendBytes([0x1D, 0x21, 0x00]); // Normal
    appendBytes([0x1B, 0x45, 0x00]); // Bold off

    if (isVoidedSlip) {
      appendBytes([0x1B, 0x45, 0x01]); // Bold on
      append(`MONEY TAKEN: ${this.formatCurrency(0)}\n`);
      appendBytes([0x1B, 0x45, 0x00]); // Bold off
    } else {
      append(`Paid (${sale.payment_method || 'CASH'}): ${this.formatCurrency(sale.amount_paid || sale.total_amount)}\n`);
      if (Number(sale.change_due || 0) > 0) {
        append(`Change Due: ${this.formatCurrency(sale.change_due)}\n`);
      }
    }

    append(divider);
    appendBytes([0x1B, 0x61, 0x01]); // Align Center
    if (isVoidedSlip) {
      appendBytes([0x1B, 0x45, 0x01]); // Bold on
      append('THIS RECEIPT WAS VOIDED\n');
      appendBytes([0x1B, 0x45, 0x00]); // Bold off
    } else {
      append((prof.receipt_footer || 'Thank you for your patronage!') + '\n');
    }
    append(`Certified by StoreFlow POS\n${isUltraCompact ? '\n' : '\n\n'}`);

    if (isBoldDensity) {
      appendBytes([0x1B, 0x47, 0x00]); // Turn off double-strike
    }

    // Kick drawer (pin 2/5 pulse) - only for a live sale. A reprinted void is a record, not a
    // call to open the box, and a till that pops its drawer on it invites someone to put money
    // in or take it out against a receipt that booked nothing.
    if (!isVoidedSlip) {
      appendBytes([0x1B, 0x70, 0x00, 0x19, 0xFA]);
    }

    // Paper Cut
    appendBytes([0x1D, 0x56, 0x41, 0x03]);

    const totalLength = parts.reduce((acc, p) => acc + p.length, 0);
    const combined = new Uint8Array(totalLength);
    let offset = 0;
    for (const p of parts) {
      combined.set(p, offset);
      offset += p.length;
    }
    return combined;
  }

  encodeEscPosShift(d) {
    const encoder = new TextEncoder();
    const prof = this.storeProfile || {};
    const parts = [];

    const append = (str) => parts.push(encoder.encode(str));
    const appendBytes = (bytes) => parts.push(new Uint8Array(bytes));

    appendBytes([0x1B, 0x40]); // Init
    appendBytes([0x1B, 0x61, 0x01]); // Center
    appendBytes([0x1B, 0x45, 0x01]); // Bold
    append((prof.store_name || 'STOREFLOW') + '\n');
    append('DAILY CASH REGISTER Z-REPORT\n');
    appendBytes([0x1B, 0x45, 0x00]); // Bold off
    append('------------------------------------------\n');

    appendBytes([0x1B, 0x61, 0x00]); // Left
    append(`Date & Time: ${d.shift_date} ${d.shift_time}\n`);
    append(`Operator:    ${d.cashier_name} (${d.cashier_role})\n`);
    append(`Terminal:    ${d.terminal_id || this.terminalId || 'REG-01'}\n`);
    append(`Sales Count: ${d.total_transactions} orders\n`);
    if (Number(d.voided_count || 0) > 0) {
      append(`Voided:        ${Number(d.voided_count)} receipt(s) cleared\n`);
    }
    append('------------------------------------------\n');

    append('TENDER BREAKDOWN:\n');
    append(`  Cash Sales:         ${this.formatCurrency(d.cash_sales)}\n`);
    append(`  POS/Card Sales:     ${this.formatCurrency(d.card_sales)}\n`);
    append(`  Bank Transfers:     ${this.formatCurrency(d.transfer_sales)}\n`);
    append(`  Credit (Unpaid):    ${this.formatCurrency(d.credit_sales)}\n`);
    append(`  Debt Cash Received: +${this.formatCurrency(d.debt_cash_collected)}\n`);
    append('------------------------------------------\n');
    append(`TOTAL GROSS SALES:   ${this.formatCurrency(d.total_sales_gross)}\n`);
    if (Number(d.voided_count || 0) > 0) {
      append(`VOIDED, NOT COUNTED: ${Number(d.voided_count)} x ${this.formatCurrency(Number(d.voided_value || 0))}\n`);
      append('(cash handed back, goods restocked)\n');
    }
    append('------------------------------------------\n');

    append('DRAWER RECONCILIATION:\n');
    append(`  Opening Float:      ${this.formatCurrency(d.opening_float)}\n`);
    if (Number(d.rental_cash_collected || 0) > 0) {
      append(`  Rental Cash In:     +${this.formatCurrency(d.rental_cash_collected)}\n`);
    }
    if (Number(d.drawer_expenses || 0) > 0) {
      append(`  Drawer Expenses:    -${this.formatCurrency(d.drawer_expenses)}\n`);
    }
    if (Number(d.cash_refunds_paid || 0) > 0) {
      append(`  Refunds Paid Out:   -${this.formatCurrency(d.cash_refunds_paid)}\n`);
    }
    if (Number(d.rental_caution_refunded || 0) > 0) {
      append(`  Caution Refunded:   -${this.formatCurrency(d.rental_caution_refunded)}\n`);
    }
    append(`  Expected Cash:      ${this.formatCurrency(d.expected_cash + d.opening_float)}\n`);
    append(`  Counted Cash:       ${this.formatCurrency(d.counted_cash)}\n`);

    const isBalanced = Math.abs(d.variance) < 0.01;
    const varianceStr = isBalanced ? 'BALANCED (' + this.formatCurrency(0) + ')' : (d.variance > 0 ? `SURPLUS (+${this.formatCurrency(d.variance)})` : `SHORTAGE (${this.formatCurrency(d.variance)})`);
    appendBytes([0x1B, 0x45, 0x01]); // Bold
    append(`  VARIANCE:           ${varianceStr}\n`);
    appendBytes([0x1B, 0x45, 0x00]); // Bold off

    if (d.notes) append(`  Notes: ${d.notes}\n`);
    append('------------------------------------------\n');
    append('\nCashier Sign:  ___________________\n\n');
    append('Supervisor:    ___________________\n\n\n\n');

    appendBytes([0x1D, 0x56, 0x41, 0x03]); // Cut

    const totalLength = parts.reduce((acc, p) => acc + p.length, 0);
    const combined = new Uint8Array(totalLength);
    let offset = 0;
    for (const p of parts) {
      combined.set(p, offset);
      offset += p.length;
    }
    return combined;
  }

  // --- Users & Roles ---

  getUsersHTML() {
    return `
      <div class="panel">
        <div class="panel-header">
          <h3><i class="fa-solid fa-user-shield"></i> Store Managers & Staff</h3>
          <button class="btn btn-primary" onclick="app.openNewUserModal()">
            <i class="fa-solid fa-user-plus"></i> Add Staff Account
          </button>
        </div>
        <div class="panel-body">
          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Full Name</th>
                  <th>Username</th>
                  <th>Assigned Role</th>
                  ${this.isMultiBranch ? '<th style="width: 150px;">Assigned Branch</th>' : ''}
                  <th>Contact</th>
                  <th>Account Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                ${this.users.length > 0 ? this.users.map(u => {
      let branchBadge = '';
      if (this.isMultiBranch) {
        const uBranch = (u.branch_code || 'MAIN-01').toUpperCase();
        if (uBranch === 'ALL') {
          branchBadge = `<span class="badge badge-purple" style="font-size: 0.75rem;" title="Enterprise access across all locations"><i class="fa-solid fa-network-wired"></i> All Branches</span>`;
        } else {
          const bObj = (this.branches || []).find(b => (b.branch_code || '').toUpperCase() === uBranch);
          const bName = bObj ? bObj.name : uBranch;
          branchBadge = `<span class="badge badge-slate" style="font-size: 0.75rem;" title="Restricted to ${this.escapeHtml(bName)}"><i class="fa-solid fa-store" style="color: var(--primary);"></i> ${this.escapeHtml(uBranch)}</span>`;
        }
      }
      return `
                  <tr>
                    <td style="font-weight: 600;">${this.escapeHtml(u.full_name)}</td>
                    <td style="font-family: monospace;">${this.escapeHtml(u.username)}</td>
                    <td><span class="badge badge-info">${this.escapeHtml(u.role_name)}</span></td>
                    ${this.isMultiBranch ? `<td>${branchBadge}</td>` : ''}
                    <td>${this.escapeHtml(u.email || u.phone || 'N/A')}</td>
                    <td>
                      <span class="badge ${u.is_active ? 'badge-success' : 'badge-danger'}">
                        ${u.is_active ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td>
                      <div style="display: flex; gap: 0.35rem;">
                        <button class="btn btn-outline btn-sm" onclick="app.editUser(${this.jsStr(u.id)})" title="Edit Staff Credentials">
                          <i class="fa-solid fa-pen"></i> Edit
                        </button>
                        ${u.id > 1 ? `
                          <button class="btn btn-outline btn-sm" onclick="app.confirmDeleteUser(${u.id}, ${this.jsStr(u.username)})" style="color: var(--danger); border-color: var(--danger-border);" title="Delete Staff Account">
                            <i class="fa-solid fa-trash"></i>
                          </button>
                        ` : ''}
                      </div>
                    </td>
                  </tr>
                `;
    }).join('') : `
                  <tr>
                    <td colspan="${this.isMultiBranch ? '7' : '6'}" style="text-align: center; padding: 2rem; color: var(--slate-400);">
                      Store Administrator (admin)
                    </td>
                  </tr>
                `}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      ${this.getRolesAccessMapHTML()}
    `;
  }

  // --- Access Map: one row per role, one column per right the server is willing to grant ---

  accessMapRights() {
    return Object.keys(this.permissionCatalogue || {});
  }

  // manage_inventory reads as "Inventory" and view_reports as "Reports" across the top of a
  // grid. The key it came from and the sentence saying what granting it opens both travel in
  // the header's tooltip, so the short word never has to be guessed at - and never has to be
  // kept in step with db.php by hand, because this list is db.php's answer.
  accessMapColumnLabel(right) {
    return String(right)
      .replace(/^(manage|view)_/, '')
      .split('_')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  }

  getRolesAccessMapHTML() {
    const rights = this.accessMapRights();
    // roles.php sends the whole map, its catalogue and can_manage together, and sends a
    // single role with no catalogue to anyone it judged cannot edit it. Both halves are the
    // server's decision; a till that never reached it has no catalogue and so no table.
    if (!this.canManageRoles || rights.length === 0) return '';

    const rows = (this.roles || [])
      .map(role => this.accessMapRowHTML(String(Number(role.id) || 0), role))
      .join('');

    return `
      <div class="panel">
        <div class="panel-header">
          <h3><i class="fa-solid fa-key"></i> Access Map</h3>
          <button class="btn btn-outline" onclick="app.openNewRoleRow()">
            <i class="fa-solid fa-plus"></i> New Role
          </button>
        </div>
        <div class="panel-body">
          <p style="margin: 0 0 0.85rem; font-size: 0.8rem; color: var(--slate-500); line-height: 1.5;">
            A tick is the only thing that puts a screen on that role's menu, and the ceiling is
            the largest discount its staff may apply at the counter - 0 meaning none at all.
            Saving binds at once on the server; a till already open shows the new menu the next
            time it loads.
          </p>
          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th style="min-width: 210px;">Role</th>
                  ${rights.map(right => `
                    <th style="text-align: center; white-space: nowrap;"
                        data-right="${this.escapeHtml(right)}"
                        title="${this.escapeHtml(right)}: ${this.escapeHtml(this.permissionCatalogue[right] || '')}">
                      ${this.accessMapColumnLabel(right)}
                    </th>`).join('')}
                  <th style="text-align: center; white-space: nowrap;"
                      title="The largest percentage this role may take off a line at the till, or off a whole sale.">
                    Discount ceiling
                  </th>
                  <th style="text-align: center;">Staff</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                ${rows}
                ${this.showNewRoleRow
                  ? this.accessMapRowHTML('new', { id: 0, role_name: '', description: '', permissions: [], max_discount_pct: 10, user_count: 0 })
                  : ''}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  }

  accessMapRowHTML(token, role) {
    const rights = this.accessMapRights();
    const locked = role.is_system === true || Number(role.id) === 1;
    // The Administrator row is drawn as what the server already treats it as: hasPermission()
    // answers yes to every right for role 1 whatever its column says, so showing its stored
    // ticks would be a map that disagrees with the territory.
    const held = locked ? rights : (Array.isArray(role.permissions) ? role.permissions : []);
    const ceiling = (role.max_discount_pct === undefined || role.max_discount_pct === null || role.max_discount_pct === '')
      ? 10 : Number(role.max_discount_pct);
    const staff = Number(role.user_count || 0);

    const nameCell = locked ? `
      <td>
        <div style="font-weight: 600;">${this.escapeHtml(role.role_name || 'Administrator')}</div>
        <div style="font-size: 0.72rem; color: var(--slate-500); margin-top: 0.2rem; line-height: 1.45;">
          The owner's own role. It holds every right and is not editable here, so a mistake on
          this screen can never lock you out of your own shop.
        </div>
      </td>` : `
      <td>
        <input type="text" id="role-name-${token}" class="form-control" maxlength="60"
               value="${this.escapeHtml(role.role_name || '')}" placeholder="e.g. Night Cashier">
        <input type="text" id="role-desc-${token}" class="form-control" style="margin-top: 0.35rem;"
               value="${this.escapeHtml(role.description || '')}" placeholder="What this role is for">
      </td>`;

    const rightCells = rights.map(right => {
      const on = held.includes(right);
      return locked
        ? `<td style="text-align: center;">${on
            ? '<i class="fa-solid fa-check" style="color: var(--success);"></i>'
            : '<span style="color: var(--slate-400);">&ndash;</span>'}</td>`
        : `<td style="text-align: center;">
             <input type="checkbox" id="role-perm-${token}-${this.escapeHtml(right)}"
                    data-right="${this.escapeHtml(right)}" ${on ? 'checked' : ''}
                    title="${this.escapeHtml(right)}: ${this.escapeHtml(this.permissionCatalogue[right] || '')}">
           </td>`;
    }).join('');

    const ceilingCell = locked
      ? `<td style="text-align: center; white-space: nowrap;">${ceiling}%</td>`
      : `<td style="text-align: center;">
           <span style="display: inline-flex; align-items: center; gap: 0.2rem;">
             <input type="number" id="role-cap-${token}" class="form-control" min="0" max="100" step="0.5"
                    value="${ceiling}" style="width: 72px; text-align: center;">%
           </span>
         </td>`;

    const actionCell = locked
      ? `<td><span class="badge badge-neutral">Fixed</span></td>`
      : `<td>
           <div style="display: flex; gap: 0.35rem;">
             <button class="btn btn-outline btn-sm" onclick="app.saveRoleFromRow(${this.jsStr(token)})">
               <i class="fa-solid fa-floppy-disk"></i> Save
             </button>
             ${token === 'new'
               ? `<button class="btn btn-outline btn-sm" onclick="app.cancelNewRoleRow()">Cancel</button>`
               : (staff === 0 ? `
             <button class="btn btn-outline btn-sm" style="color: var(--danger); border-color: var(--danger-border);"
                     title="Delete this role" onclick="app.confirmDeleteRole(${Number(role.id)}, ${this.jsStr(role.role_name || '')})">
               <i class="fa-solid fa-trash"></i>
             </button>` : '')}
           </div>
         </td>`;

    return `
      <tr>
        ${nameCell}
        ${rightCells}
        ${ceilingCell}
        <td style="text-align: center;">${staff}</td>
        ${actionCell}
      </tr>
    `;
  }

  openNewRoleRow() {
    this.showNewRoleRow = true;
    this.renderCurrentView();
    const first = document.getElementById('role-name-new');
    if (first) first.focus();
  }

  cancelNewRoleRow() {
    this.showNewRoleRow = false;
    this.renderCurrentView();
  }

  // Read the row back off the screen rather than from a copy kept in memory, the way the
  // staff form does, and refuse here what roles.php refuses there. Refusing early is not
  // trust in the client - the server still checks all of it - it is only that an owner who
  // taps Save with nothing ticked should be told which tick they meant, not shown a 400.
  collectRoleRow(token) {
    const nameEl = document.getElementById(`role-name-${token}`);
    const capEl = document.getElementById(`role-cap-${token}`);
    if (!nameEl || !capEl) {
      this.showToast('That role is no longer on the screen. Reload the staff list and try again.', 'warning');
      return null;
    }

    const roleName = nameEl.value.trim();
    if (!roleName) {
      this.showToast('A role needs a name, or the staff roster cannot tell it apart from another.', 'warning');
      return null;
    }

    const permissions = this.accessMapRights().filter(right => {
      const box = document.getElementById(`role-perm-${token}-${right}`);
      return box && box.checked;
    });
    if (permissions.length === 0) {
      this.showToast('A role with no ticks cannot open anything, so it cannot be saved. Tick at least one right.', 'warning');
      return null;
    }

    // 0 is an answer here, not an empty field: it is how an owner says this role may never
    // discount. Only a field with no value at all falls back to the server's default.
    const rawCap = String(capEl.value).trim();
    if (rawCap === '' || !isFinite(Number(rawCap))) {
      this.showToast('The discount ceiling must be a number of percent. Use 0 for a role that may not discount.', 'warning');
      return null;
    }
    const ceiling = Math.round(Number(rawCap) * 100) / 100;
    if (ceiling < 0 || ceiling > 100) {
      this.showToast('The discount ceiling must be between 0% and 100%.', 'warning');
      return null;
    }

    const descEl = document.getElementById(`role-desc-${token}`);
    return {
      role_name: roleName,
      description: descEl ? descEl.value.trim() : '',
      permissions,
      max_discount_pct: ceiling
    };
  }

  async saveRoleFromRow(token) {
    const roleId = token === 'new' ? 0 : (Number(token) || 0);
    const role = this.collectRoleRow(token);
    if (!role) return;

    if (!this.isOnline) {
      this.showToast('The Access Map needs the shop server. Nothing has changed.', 'warning');
      return;
    }

    try {
      const cls = await this.classifyApiResponse(
        await this.apiFetch('api/endpoints/roles.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'save', id: roleId, ...role })
        })
      );

      if (cls.verdict === 'unreachable') {
        this.showToast('The till could not reach the server, so the role was not changed.', 'warning');
        return;
      }
      if (cls.verdict !== 'accepted') {
        this.showToast(cls.message || 'The role could not be saved. The change was not made.', 'danger');
        return;
      }

      this.showNewRoleRow = false;
      await this.fetchUsers();
      await this.refreshSessionAfterRoleChange(roleId);
      this.renderCurrentView();
      this.showToast(`Access for '${role.role_name}' saved.`, 'success');
    } catch (err) {
      this.showToast('The till could not reach the server, so the role was not changed.', 'warning');
    }
  }

  // The menu a till shows is built from the copy of the session it holds, so a tick changed
  // here does not move this owner's own menu until that copy is re-read. Ask the server for
  // it instead of repeating what was just posted: if the row on disk says something else, the
  // menu should match the row. Anyone else on the edited role picks it up on their next load.
  async refreshSessionAfterRoleChange(roleId) {
    if (roleId <= 0 || !this.currentUser) return;
    if (Number(this.currentUser.role_id) !== roleId) return;
    try {
      const cls = await this.classifyApiResponse(
        await this.apiFetch('api/endpoints/users.php?action=current')
      );
      if (cls.verdict === 'accepted' && cls.body.user) {
        this.currentUser = cls.body.user;
        this.sessionManager.persistActiveUser(cls.body.user, true);
        this.updateUserUI();
        this.applyRolePermissions();
      }
    } catch (err) {
      // A till that lost the line between the save and this read shows a stale menu until it
      // next loads. The save itself already reached the server, which is what gates the data.
    }
  }

  confirmDeleteRole(roleId, roleName) {
    if (Number(roleId) === 1) {
      this.showToast('The Administrator role is fixed and cannot be deleted.', 'warning');
      return;
    }
    this.pendingDelete = { type: 'role', id: Number(roleId), name: String(roleName || '') };
    document.getElementById('delete-modal-title').innerText = 'Delete Role';
    document.getElementById('delete-modal-msg').innerHTML =
      `Delete <strong>${this.escapeHtml(roleName || '')}</strong> from the Access Map? `
      + 'No staff account is on it, so nobody loses a screen today - but the ticks set for it go with it.';
    document.getElementById('confirm-delete-modal').classList.add('active');
  }

  bindUsersEvents() { }

  populateUserBranchOptions(selectedCode = 'MAIN-01') {
    const branchGroup = document.getElementById('user-form-branch-group');
    const branchSelect = document.getElementById('user-form-branch');
    if (!branchSelect) return;

    if (this.isMultiBranch) {
      if (branchGroup) branchGroup.style.display = 'block';
      const options = [
        '<option value="ALL">All Branches (Floating / Central Enterprise)</option>',
        ...(this.branches || []).map(b => {
          const isSel = (b.branch_code || '').toUpperCase() === (selectedCode || 'MAIN-01').toUpperCase();
          return `<option value="${this.escapeHtml(b.branch_code)}" ${isSel ? 'selected' : ''}>${this.escapeHtml(b.branch_code)} - ${this.escapeHtml(b.name)}</option>`;
        })
      ];
      branchSelect.innerHTML = options.join('');
      branchSelect.value = selectedCode || 'MAIN-01';
    } else {
      if (branchGroup) branchGroup.style.display = 'none';
      branchSelect.innerHTML = '<option value="MAIN-01" selected>MAIN-01 - Main Storefront</option>';
      branchSelect.value = 'MAIN-01';
    }
  }

  // The staff form lists the roles the Access Map holds, so a role created there is assignable
  // the moment it saves. The options this select ships with are the three rows a new shop is
  // seeded with, which is how a fourth role used to end up unassignable - so when the map never
  // loaded, those three are left exactly as the page wrote them rather than replaced by a
  // second copy of the same names kept here.
  populateUserRolesOptions(selectedRoleId = 2) {
    const select = document.getElementById('user-form-role');
    if (!select) return;
    const roles = (this.roles || []).slice();
    if (roles.length === 0) return;

    // Administrator last, as the form always had it: assigning ownership should be something
    // an owner reaches for, not the first row of a dropdown.
    roles.sort((a, b) => (Number(a.id) === 1 ? 1 : 0) - (Number(b.id) === 1 ? 1 : 0));
    select.innerHTML = roles.map(role => {
      const id = Number(role.id);
      return `<option value="${id}">${this.escapeHtml(role.role_name || `Role ${id}`)}</option>`;
    }).join('');
    const wanted = roles.some(role => Number(role.id) === Number(selectedRoleId))
      ? Number(selectedRoleId)
      : Number(roles[0].id);
    select.value = String(wanted);
  }

  // This name is what an offline grant, the sidebar greeting and legacyRoleRights() all read,
  // so it has to come from the map rather than from a guess about which three roles exist.
  roleRecordFor(roleId) {
    return (this.roles || []).find(role => Number(role.id) === Number(roleId)) || null;
  }

  roleNameFor(roleId) {
    const role = this.roleRecordFor(roleId);
    if (role) return role.role_name || '';
    return roleId === 1 ? 'Administrator' : (roleId === 3 ? 'Cashier' : 'Store Manager');
  }

  rolePermissionsFor(roleId) {
    const role = this.roleRecordFor(roleId);
    return role && Array.isArray(role.permissions) ? role.permissions : [];
  }

  openNewUserModal() {
    document.getElementById('user-modal-title').innerHTML = '<i class="fa-solid fa-user-plus"></i> Add Staff Account';
    document.getElementById('user-form-id').value = '';
    document.getElementById('user-form-name').value = '';
    document.getElementById('user-form-username').value = '';
    document.getElementById('user-form-password').value = '';
    if (document.getElementById('user-form-pin')) document.getElementById('user-form-pin').value = '';
    document.getElementById('user-form-password-label').innerText = 'Initial Password *';
    this.populateUserRolesOptions(2);
    document.getElementById('user-form-email').value = '';
    document.getElementById('user-form-phone').value = '';
    this.populateUserBranchOptions(this.branchCode || 'MAIN-01');
    document.getElementById('user-modal').classList.add('active');
  }

  editUser(userId) {
    const u = this.users.find(item => item.id == userId);
    if (!u) return;

    document.getElementById('user-modal-title').innerHTML = '<i class="fa-solid fa-user-pen"></i> Edit Staff Account';
    document.getElementById('user-form-id').value = u.id;
    document.getElementById('user-form-name').value = u.full_name || '';
    document.getElementById('user-form-username').value = u.username || '';
    document.getElementById('user-form-password').value = '';
    if (document.getElementById('user-form-pin')) document.getElementById('user-form-pin').value = '';
    document.getElementById('user-form-password-label').innerText = 'New Password (leave blank to keep current)';
    this.populateUserRolesOptions(u.role_id || 2);
    document.getElementById('user-form-email').value = u.email || '';
    document.getElementById('user-form-phone').value = u.phone || '';
    this.populateUserBranchOptions(u.branch_code || 'MAIN-01');
    document.getElementById('user-modal').classList.add('active');
  }

  closeUserModal() {
    document.getElementById('user-modal').classList.remove('active');
  }

  async saveUserForm() {
    const id = parseInt(document.getElementById('user-form-id').value) || 0;
    const isEdit = id > 0;
    const fullName = document.getElementById('user-form-name').value.trim();
    const username = document.getElementById('user-form-username').value.trim();
    const password = document.getElementById('user-form-password').value;
    const pinCode = document.getElementById('user-form-pin') ? document.getElementById('user-form-pin').value.trim() : '';
    const roleId = parseInt(document.getElementById('user-form-role').value) || 2;
    const email = document.getElementById('user-form-email').value.trim();
    const phone = document.getElementById('user-form-phone').value.trim();
    const branchCode = this.isMultiBranch ? (document.getElementById('user-form-branch')?.value || 'MAIN-01') : 'MAIN-01';

    if (!fullName || !username) {
      this.showToast('Full name and username are required.', 'warning');
      return;
    }

    if (!isEdit && !password) {
      this.showToast('Initial password is required when creating a new user.', 'warning');
      return;
    }

    if (pinCode && !/^\d{4,6}$/.test(pinCode)) {
      this.showToast('Quick Unlock PIN must be 4 to 6 numeric digits.', 'warning');
      return;
    }

    const roleName = this.roleNameFor(roleId);
    // Ticks come from the Access Map when it loaded. A till that never reached the server has
    // no map, and guessing one here would sign a working offline account into whichever menu
    // the guess picked - so it keeps whatever the stored grant already carried.
    const heldRole = this.roleRecordFor(roleId);
    const roleTicks = heldRole && Array.isArray(heldRole.permissions) ? heldRole.permissions : null;

    // 1. Keep the stored hash-based offline auth record current without ever storing plaintext passwords.
    if (password) {
      const credHash = await this.hashCredentials(username, password);
      const existing = this.getOfflineHashes()[String(username).toLowerCase()];
      const grantUser = existing && existing.user
        ? { ...existing.user, full_name: fullName, role_id: roleId, role_name: roleName, branch_code: branchCode,
            ...(roleTicks ? { permissions: roleTicks } : {}) }
        : {
            id: id || Date.now(),
            username: username,
            full_name: fullName,
            role_id: roleId,
            role_name: roleName,
            branch_code: branchCode,
            permissions: roleTicks || []
          };
      this.saveOfflineGrant(username, grantUser, credHash);
    }

    // 2. If editing current active logged-in user, update session immediately
    if (this.currentUser && (this.currentUser.id === id || this.currentUser.username.toLowerCase() === username.toLowerCase())) {
      this.currentUser.username = username;
      this.currentUser.full_name = fullName;
      this.currentUser.role_id = roleId;
      this.currentUser.role_name = roleName;
      if (roleTicks) this.currentUser.permissions = roleTicks;
      this.currentUser.email = email;
      this.currentUser.phone = phone;
      this.currentUser.branch_code = branchCode;
      if (this.isMultiBranch && branchCode !== 'ALL') {
        this.branchCode = branchCode;
        localStorage.setItem('storeflow_branch_code', branchCode);
      }

      localStorage.setItem('storeflow_active_user', JSON.stringify(this.currentUser));
      this.updateUserUI();
      // Moving ones own account to another role moves the menu with it, or the owner would
      // keep seeing screens the server has already stopped answering.
      if (typeof this.applyRolePermissions === 'function') this.applyRolePermissions();
    }

    // 3. Online Server Update
    if (this.isOnline) {
      try {
        const res = await this.apiFetch('api/endpoints/users.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            id: id,
            full_name: fullName,
            username: username,
            password: password,
            pin_code: pinCode,
            role_id: roleId,
            branch_code: branchCode,
            email: email,
            phone: phone
          })
        });
        const data = await res.json();
        if (data.success) {
          await this.fetchUsers();
          this.closeUserModal();
          this.renderCurrentView();
          this.showToast(`User '${username}' saved successfully!`, 'success');
        } else {
          this.showToast(data.message, 'danger');
        }
      } catch (e) {
        this.showToast('Server update error; updated locally.', 'warning');
        this.closeUserModal();
        this.renderCurrentView();
      }
    } else {
      const existingIdx = this.users.findIndex(u => u.id === id || u.username === username);
      const updatedUser = {
        id: id || Date.now(),
        username,
        full_name: fullName,
        role_id: roleId,
        role_name: roleName,
        permissions: roleTicks || [],
        branch_code: branchCode,
        email,
        phone,
        is_active: 1
      };
      if (existingIdx >= 0) {
        this.users[existingIdx] = updatedUser;
      } else {
        this.users.push(updatedUser);
      }
      this.closeUserModal();
      this.renderCurrentView();
      this.showToast(`Credentials for '${username}' saved locally for offline login.`, 'success');
    }
  }

  // --- Universal Delete Confirmation Methods ---

  confirmDeleteProduct(id, name) {
    this.pendingDelete = { type: 'product', id, name };
    document.getElementById('delete-modal-title').innerText = 'Delete Product';
    document.getElementById('delete-modal-msg').innerHTML = `Are you sure you want to delete product <strong>${this.escapeHtml(name)}</strong>? It will be removed from your active catalog and Point of Sale.`;
    document.getElementById('confirm-delete-modal').classList.add('active');
  }

  confirmDeleteCustomer(id, name) {
    if (id === 'cust-walkin') {
      this.showToast('Walk-in Customer cannot be deleted.', 'warning');
      return;
    }
    this.pendingDelete = { type: 'customer', id, name };
    document.getElementById('delete-modal-title').innerText = 'Delete Customer';
    document.getElementById('delete-modal-msg').innerHTML = `Are you sure you want to delete customer <strong>${this.escapeHtml(name)}</strong>?`;
    document.getElementById('confirm-delete-modal').classList.add('active');
  }

  confirmDeleteUser(id, username) {
    if (id === 1) {
      this.showToast('The primary Administrator account cannot be deleted.', 'warning');
      return;
    }
    if (this.currentUser && this.currentUser.id === id) {
      this.showToast('You cannot delete your own active signed-in account.', 'warning');
      return;
    }
    this.pendingDelete = { type: 'user', id, name: username };
    document.getElementById('delete-modal-title').innerText = 'Retire Staff Account';
    document.getElementById('delete-modal-msg').innerHTML = `Retire <strong>${this.escapeHtml(username)}</strong>? `
      + 'They can no longer sign in or unlock the terminal, but the receipts they rang up keep their name. '
      + 'The account stays in the staff list and can be reopened from there.';
    document.getElementById('confirm-delete-modal').classList.add('active');
  }

  closeDeleteModal() {
    this.pendingDelete = null;
    const modal = document.getElementById('confirm-delete-modal');
    if (modal) modal.classList.remove('active');
  }

  async executeDelete() {
    if (!this.pendingDelete) return;
    const { type, id, name } = this.pendingDelete;

    if (this.isCashier()) {
      this.showToast('Permission denied: Cashiers cannot delete catalog, customer, or staff records.', 'danger');
      this.closeDeleteModal();
      return;
    }

    if (type === 'user' && !this.isAdmin()) {
      this.showToast('Permission denied: Only Administrators can delete staff accounts.', 'danger');
      this.closeDeleteModal();
      return;
    }

    const btn = document.getElementById('btn-confirm-delete');
    if (btn) btn.disabled = true;

    try {
      if (type === 'product') {
        this.products = this.products.filter(p => p.id !== id);
        await localDB.products.delete(id);

        if (this.isOnline) {
          try {
            await this.apiFetch(`api/endpoints/products.php?id=${encodeURIComponent(id)}`, { method: 'DELETE' });
          } catch (e) {
            await localDB.sync_outbox.add({
              entity: 'product',
              action: 'DELETE',
              data: { id },
              timestamp: new Date().toISOString(),
              synced: 0
            });
          }
        } else {
          await localDB.sync_outbox.add({
            entity: 'product',
            action: 'DELETE',
            data: { id },
            timestamp: new Date().toISOString(),
            synced: 0
          });
        }
        this.showToast(`Product '${name}' deleted successfully.`, 'success');
        if (typeof this.broadcastSyncEvent === 'function') {
          this.broadcastSyncEvent('PRODUCT_MUTATED', { action: 'DELETE', id });
        }
      } else if (type === 'customer') {
        this.customers = this.customers.filter(c => c.id !== id);
        await localDB.customers.delete(id);

        if (this.isOnline) {
          try {
            await this.apiFetch(`api/endpoints/customers.php?id=${encodeURIComponent(id)}`, { method: 'DELETE' });
          } catch (e) {
            await localDB.sync_outbox.add({
              entity: 'customer',
              action: 'DELETE',
              data: { id },
              timestamp: new Date().toISOString(),
              synced: 0
            });
          }
        } else {
          await localDB.sync_outbox.add({
            entity: 'customer',
            action: 'DELETE',
            data: { id },
            timestamp: new Date().toISOString(),
            synced: 0
          });
        }
        this.showToast(`Customer '${name}' deleted successfully.`, 'success');
        if (typeof this.broadcastSyncEvent === 'function') {
          this.broadcastSyncEvent('CUSTOMER_MUTATED', { action: 'DELETE', id });
        }
      } else if (type === 'user') {
        // Retire, do not erase. The server keeps the row because sales.user_id points at it
        // for the life of the book, so the staff list keeps it too and marks it inactive -
        // otherwise the screen loses a person the receipt ledger still names, until the next
        // reload brings the row straight back. There is no outbox bucket for staff accounts,
        // so a till that cannot reach the server says so instead of pretending the door is
        // shut: the account would still sign in as soon as it reloaded.
        if (this.isOnline) {
          const cls = await this.classifyApiResponse(
            await this.apiFetch(`api/endpoints/users.php?id=${encodeURIComponent(id)}`, { method: 'DELETE' })
          );
          if (cls.verdict !== 'accepted') {
            this.showToast(cls.verdict === 'unreachable'
              ? 'No connection to the server, so the account is still active. Try again once the till reaches it.'
              : (cls.message || 'The server refused to retire that account.'), 'danger');
            return;
          }
        }
        this.users = (this.users || []).map(u => Number(u.id) === Number(id) ? { ...u, is_active: 0 } : u);
        const offlineHashes = this.safeJsonParse(localStorage.getItem('storeflow_offline_hashes'), {});
        delete offlineHashes[name.toLowerCase()];
        localStorage.setItem('storeflow_offline_hashes', JSON.stringify(offlineHashes));

        this.showToast(`Staff account '${name}' retired. They can no longer sign in; their sales keep their name.`, 'success');
      } else if (type === 'role') {
        // The map only offers this button on a role with nobody on it, and roles.php counts the
        // staff again before deleting, so a second owner who moved someone onto it from another
        // till in the last few minutes gets a refusal instead of an orphaned sign-in.
        if (!this.hasPerm('manage_users')) {
          this.showToast('Permission denied: only a role holding Manage Users can delete a role.', 'danger');
          return;
        }
        const cls = await this.classifyApiResponse(
          await this.apiFetch('api/endpoints/roles.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'delete', id })
          })
        );
        if (cls.verdict !== 'accepted') {
          this.showToast(cls.verdict === 'unreachable'
            ? 'No connection to the server, so the role is still in the Access Map.'
            : (cls.message || 'The server refused to delete that role.'), 'danger');
          return;
        }
        await this.fetchUsers();
        this.showToast(`Role '${name}' removed from the Access Map.`, 'success');
      }
    } catch (err) {
      this.showToast(`Failed to delete: ${err.message}`, 'danger');
    } finally {
      if (btn) btn.disabled = false;
      this.closeDeleteModal();
      this.renderCurrentView();
    }
  }

  // --- Database & 2-Hour Auto Backups ---

  // Every backup_type the endpoint can emit has to be named here. The snapshot table is
  // how an owner decides which file is safe to lose, so a type that silently renders as
  // "Manual" is worse than no badge at all - it tells them an encrypted copy they
  // imported from another machine is one they clicked by hand.
  backupTypeBadgeHtml(type) {
    const known = {
      'AUTOMATIC_2HR':       { cls: 'badge-success', icon: 'fa-clock',      label: 'Auto (2hr)' },
      'MANUAL':              { cls: 'badge-info',    icon: 'fa-hand',       label: 'Manual' },
      'PRE_RESTORE_SAFETY':  { cls: 'badge-warning', icon: 'fa-shield',     label: 'Safety' },
      'PRE_RESET_SAFETY':    { cls: 'badge-warning', icon: 'fa-shield',     label: 'Before reset' },
      'SAFETY':              { cls: 'badge-warning', icon: 'fa-shield',     label: 'Safety' },
      'UPLOADED':            { cls: 'badge-neutral', icon: 'fa-upload',     label: 'Uploaded' },
      'IMPORTED_ENCRYPTED':  { cls: 'badge-info',    icon: 'fa-lock',       label: 'Imported (encrypted)' }
    };
    // A hasOwnProperty guard, not a plain lookup: backup_type is a free-text column, and
    // a row reading "constructor" or "__proto__" would otherwise find Object.prototype and
    // put the word "undefined" in front of an owner choosing which snapshot to restore over.
    const b = Object.prototype.hasOwnProperty.call(known, type) ? known[type] : null;
    if (!b) {
      return `<span class="badge badge-neutral">${this.escapeHtml(String(type || 'UNKNOWN'))}</span>`;
    }
    return `<span class="badge ${b.cls}"><i class="fa-solid ${b.icon}"></i> ${b.label}</span>`;
  }

  getBackupsHTML() {
    return `
      <!-- Google Drive Cloud Backup & Restore Card -->
      <div class="panel" style="margin-bottom: 1.25rem; border-left: 4px solid #4285F4;">
        <div class="panel-body" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
          <div>
            <h3 style="font-size: 1.15rem; font-weight: 700; color: var(--slate-900); display: flex; align-items: center; gap: 0.5rem;">
              <svg width="20" height="20" viewBox="0 0 18 18"><path fill="#4285F4" d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844c-.209 1.125-.843 2.078-1.796 2.717v2.258h2.908c1.702-1.567 2.684-3.874 2.684-6.616z"/><path fill="#34A853" d="M9 18c2.43 0 4.467-.806 5.956-2.184l-2.908-2.258c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332C2.438 15.983 5.482 18 9 18z"/><path fill="#FBBC05" d="M3.964 10.707c-.18-.54-.282-1.117-.282-1.707s.102-1.167.282-1.707V4.961H.957C.347 6.173 0 7.548 0 9s.347 2.827.957 4.039l3.007-2.332z"/><path fill="#EA4335" d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0 5.482 0 2.438 2.017.957 4.961L3.964 7.293C4.672 5.166 6.656 3.58 9 3.58z"/></svg>
              Google Drive Cloud Storage
            </h3>
            <p style="font-size: 0.85rem; color: var(--slate-600); margin-top: 0.25rem;">
              Back up your store database to your personal Google Drive account. PC database backups are passphrase-encrypted (.sfbak) before leaving the machine, ensuring customer records remain scrambled.
            </p>
          </div>
          <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
            <button class="btn btn-outline" onclick="if(window.StoreFlowGoogleCloud) StoreFlowGoogleCloud.signIn()">
              <i class="fa-solid fa-cloud-arrow-down"></i> Restore from Google Drive
            </button>
            <button class="btn btn-primary" onclick="if(window.StoreFlowGoogleCloud) StoreFlowGoogleCloud.uploadBackupToDrive()" style="background: #1a73e8; border-color: #1a73e8;">
              <i class="fa-solid fa-cloud-arrow-up"></i> Backup to Google Drive
            </button>
          </div>
        </div>
      </div>

      <!-- Location & Disaster Recovery Info Card -->
      <div class="panel" style="margin-bottom: 1.25rem;">
        <div class="panel-body" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
          <div>
            <h3 style="font-size: 1.15rem; font-weight: 700; color: var(--slate-900); display: flex; align-items: center; gap: 0.5rem;">
              <i class="fa-solid fa-database" style="color: var(--primary);"></i> Database Storage &amp; 2-Hour Auto Backups
            </h3>
            <p style="font-size: 0.85rem; color: var(--slate-600); margin-top: 0.25rem;">
              StoreFlow writes a snapshot of the till's records into this computer's backups folder every 2 hours, and keeps the last 7 days of them.
            </p>
            <div style="margin-top: 0.6rem; display: flex; flex-wrap: wrap; gap: 1.25rem; font-size: 0.8rem; color: var(--slate-600);">
              <div><strong style="color: var(--slate-800);"><i class="fa-solid fa-hard-drive" style="color: #2563eb;"></i> Kept on:</strong> this computer only &mdash; there is no StoreFlow server that holds your books</div>
              <div><strong style="color: var(--slate-800);"><i class="fa-solid fa-folder-tree" style="color: #16a34a;"></i> Backups Folder:</strong> <code style="background: #f1f5f9; padding: 2px 6px; border-radius: 4px; font-family: monospace; font-size: 0.82rem;">data/backups/</code></div>
            </div>
          </div>
          <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
            <button class="btn btn-outline" onclick="document.getElementById('backup-file-upload-input').click()">
              <i class="fa-solid fa-upload"></i> Upload &amp; Restore .db
            </button>
            <input type="file" id="backup-file-upload-input" accept=".db,.sqlite,.sqlite3" style="display: none;" onchange="app.handleBackupFileUpload(event)">
            
            <button class="btn btn-primary" onclick="app.triggerManualBackup()">
              <i class="fa-solid fa-camera"></i> Create Snapshot Now
            </button>
          </div>
        </div>
      </div>

      <!-- Encrypted copy for off-site storage -->
      <div class="panel" style="margin-bottom: 1.25rem;">
        <div class="panel-header" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.5rem;">
          <h3><i class="fa-solid fa-file-shield" style="color: var(--primary);"></i> Encrypted Copy for Off-Site Storage</h3>
          <span class="badge badge-info">Scrambled before it leaves this computer</span>
        </div>
        <div class="panel-body">
          <p style="font-size: 0.85rem; color: var(--slate-600); margin-bottom: 0.9rem;">
            The snapshots below stay readable on this computer, which is what you want at the counter and what you do not want in a bag. An encrypted copy is the one to keep somewhere else - a USB stick in a drawer, a second machine, your own cloud account. A fire, a flood or a stolen PC is when it earns its keep.
          </p>
          <p style="font-size: 0.85rem; color: var(--slate-900); background: #fff7ed; border: 1px solid #fdba74; border-radius: 6px; padding: 0.6rem 0.85rem; margin-bottom: 1.1rem;">
            <i class="fa-solid fa-triangle-exclamation" style="color: #c2410c;"></i>
            <strong>The passphrase is never stored anywhere.</strong> Nobody - not staff, not the seller - can reopen this file without it. A lost passphrase means that copy is gone for good, so write the passphrase down and keep the paper apart from the file.
          </p>

          <div style="display: flex; flex-wrap: wrap; gap: 1rem; align-items: flex-end;">
            <div class="form-group" style="flex: 1 1 280px; margin-bottom: 0;">
              <label class="form-label" for="sfbak-export-pass">Passphrase for the new copy</label>
              <div style="position: relative;">
                <input type="password" id="sfbak-export-pass" class="form-control" autocomplete="new-password" spellcheck="false"
                       placeholder="At least 10 characters you will still know next year" style="padding-right: 2.4rem;">
                <button type="button" class="btn btn-sm btn-outline" title="Show the passphrase once, so you can write it down"
                        style="position: absolute; right: 0.3rem; top: 50%; transform: translateY(-50%); border: none; background: transparent;"
                        onclick="app.toggleSfbakPass('sfbak-export-pass', this)"><i class="fa-solid fa-eye"></i></button>
              </div>
            </div>
            <div class="form-group" style="flex: 1 1 280px; margin-bottom: 0;">
              <label class="form-label" for="sfbak-export-pass2">Repeat it exactly</label>
              <input type="password" id="sfbak-export-pass2" class="form-control" autocomplete="new-password" spellcheck="false" placeholder="A typo here is a backup nobody can open">
            </div>
            <button type="button" class="btn btn-primary" onclick="app.exportEncryptedBackup()">
              <i class="fa-solid fa-file-shield"></i> Create Encrypted Copy
            </button>
          </div>

          <div style="border-top: 1px solid var(--slate-200); margin: 1.25rem 0 1rem;"></div>

          <div style="display: flex; flex-wrap: wrap; gap: 1rem; align-items: flex-end;">
            <div class="form-group" style="flex: 1 1 240px; margin-bottom: 0;">
              <label class="form-label" for="sfbak-import-file">Encrypted backup file (.sfbak)</label>
              <input type="file" id="sfbak-import-file" class="form-control" accept=".sfbak">
            </div>
            <div class="form-group" style="flex: 1 1 240px; margin-bottom: 0;">
              <label class="form-label" for="sfbak-import-pass">The passphrase it was made with</label>
              <div style="position: relative;">
                <input type="password" id="sfbak-import-pass" class="form-control" autocomplete="off" spellcheck="false"
                       placeholder="Typed from the paper, not remembered" style="padding-right: 2.4rem;">
                <button type="button" class="btn btn-sm btn-outline" title="Show what you typed"
                        style="position: absolute; right: 0.3rem; top: 50%; transform: translateY(-50%); border: none; background: transparent;"
                        onclick="app.toggleSfbakPass('sfbak-import-pass', this)"><i class="fa-solid fa-eye"></i></button>
              </div>
            </div>
            <button type="button" class="btn btn-outline-danger" onclick="app.restoreEncryptedBackup()">
              <i class="fa-solid fa-rotate-left"></i> Decrypt &amp; Restore
            </button>
          </div>
          <p style="font-size: 0.78rem; color: var(--slate-500); margin-top: 0.7rem;">
            Restoring replaces every current record with the ones inside that file. StoreFlow saves a safety snapshot of today's state first, so this is undoable.
          </p>
        </div>
      </div>

      <!-- Backups Table Panel -->
      <div class="panel">
        <div class="panel-header" style="display: flex; justify-content: space-between; align-items: center;">
          <h3><i class="fa-solid fa-box-archive"></i> Point-in-Time Backup Snapshots</h3>
          <span class="badge badge-info">${this.backups.length} Backups Stored</span>
        </div>
        <div class="panel-body">
          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Backup File</th>
                  <th>Created Date &amp; Time</th>
                  <th>File Size</th>
                  <th>Backup Type</th>
                  <th style="text-align: right;">Actions</th>
                </tr>
              </thead>
              <tbody>
                ${this.backups.length > 0 ? this.backups.map((b, bIdx) => `
                  <tr>
                    <td style="font-weight: 600; font-family: monospace;">
                      <i class="fa-solid fa-file-shield" style="color: #4f46e5; margin-right: 0.35rem;"></i>
                      ${this.escapeHtml(b.filename)}
                    </td>
                    <td>${this.escapeHtml(b.created_at)}</td>
                    <td><span class="badge badge-neutral">${this.escapeHtml(b.size_formatted)}</span></td>
                    <td>${this.backupTypeBadgeHtml(b.backup_type)}</td>
                    <td style="text-align: right; white-space: nowrap;">
                      <a href="${this.escapeHtml(b.download_url)}" class="btn btn-outline btn-sm" download title="Download .db file to PC or USB">
                        <i class="fa-solid fa-download"></i> Download
                      </a>
                      <button type="button" class="btn btn-sm btn-outline-danger" onclick="app.confirmRestoreBackup(${bIdx})" style="margin-left: 0.35rem;" title="Restore this snapshot into active database">
                        <i class="fa-solid fa-rotate-left"></i> Restore
                      </button>
                    </td>
                  </tr>
                `).join('') : `
                  <tr>
                    <td colspan="5" style="text-align: center; padding: 3rem; color: var(--slate-400);">
                      <i class="fa-solid fa-database" style="font-size: 2rem; margin-bottom: 0.5rem; display: block;"></i>
                      No backup snapshots created yet. Click "Create Snapshot Now" to take your first backup.
                    </td>
                  </tr>
                `}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      ${this.isAdmin() ? `
      <!-- Start the shop again clean -->
      <div class="panel" style="margin-top: 1.25rem; border: 1px solid #fecaca;">
        <div class="panel-header" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.5rem;">
          <h3><i class="fa-solid fa-broom" style="color: #b91c1c;"></i> Reset Database</h3>
          <span class="badge badge-warning">Clears records &mdash; keeps the licence</span>
        </div>
        <div class="panel-body">
          <p style="font-size: 0.85rem; color: var(--slate-600); margin-bottom: 0.9rem;">
            Handing this shop to somebody else, or starting the books again in the same shop? This clears the trade records without deleting the file behind them, which is what keeps this computer's activation intact: the Machine ID does not move, so the key you were given still fits.
          </p>
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1rem; margin-bottom: 1rem;">
            <div style="background: #fef2f2; border: 1px solid #fecaca; border-radius: 8px; padding: 0.85rem 1rem;">
              <strong style="color: #b91c1c; font-size: 0.85rem;"><i class="fa-solid fa-eraser"></i> Destroyed</strong>
              <ul style="font-size: 0.82rem; color: var(--slate-700); margin: 0.5rem 0 0 1.1rem; line-height: 1.6;">
                <li>Every receipt, return, quotation/estimate and rental contract</li>
                <li>Every product, pack unit, combo/bundle, price, stock level, batch and transfer</li>
                <li>Every supplier, factory purchase order, their debts and their payments</li>
                <li>Every customer and loyalty points ledger (except the walk-in account)</li>
                <li>Every expense, register shift, dining tab and kitchen ticket</li>
              </ul>
            </div>
            <div style="background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 0.85rem 1rem;">
              <strong style="color: #15803d; font-size: 0.85rem;"><i class="fa-solid fa-lock"></i> Kept</strong>
              <ul style="font-size: 0.82rem; color: var(--slate-700); margin: 0.5rem 0 0 1.1rem; line-height: 1.6;">
                <li>This computer's licence and activation</li>
                <li>Staff accounts, their roles and their names</li>
                <li>Store settings, branches and receipt wording</li>
                <li>Your dining floor — the tables themselves are your furniture, reset to vacant</li>
                <li>The shop's own log of who did what</li>
                <li>One copy of the shop as it stands right now</li>
              </ul>
            </div>
          </div>
          <p style="font-size: 0.8rem; color: var(--slate-600); margin-bottom: 1rem;">
            The copy is written to <code style="background: #f1f5f9; padding: 2px 6px; border-radius: 4px; font-family: monospace;">data/backups/</code> before anything is cleared and named on screen; the older rolling snapshots are removed with it. Every till in the shop is then told the book changed, so a phone still holding yesterday's records is refused rather than quietly merged in.
          </p>
          <button type="button" class="btn btn-outline-danger" onclick="app.resetShopDatabase()">
            <i class="fa-solid fa-broom"></i> Reset Database
          </button>
        </div>
      </div>` : ''}
    `;
  }

  bindBackupsEvents() { }

  async confirmRestoreBackup(index) {
    const entry = this.backups[Number(index)];
    if (!entry || !entry.filename) {
      this.showToast('That snapshot is no longer in the list. Reload the backups view and try again.', 'warning');
      return;
    }
    const filename = entry.filename;

    if (!this.isOnline) {
      this.showToast('Database restore requires an active connection to the local PHP server.', 'warning');
      return;
    }

    const confirmed = await this.showConfirmModal({
      title: 'Restore Database Snapshot?',
      message: `Are you sure you want to restore from snapshot "${filename}"?\n\n• All current database records will be restored to this exact point.\n• StoreFlow will automatically create a PRE_RESTORE_SAFETY backup of your current data first.\n• You can revert back anytime if needed.`,
      icon: 'fa-rotate-left',
      confirmText: 'Yes, Restore Database',
      cancelText: 'Cancel',
      confirmBtnClass: 'btn-danger'
    });

    if (!confirmed) return;

    this.showToast('Restoring database snapshot... Please wait.', 'info');

    try {
      const res = await this.apiFetch('api/endpoints/backups.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'restore', filename: filename })
      });
      const data = await res.json();
      if (data.success) {
        this.showToast(data.message, 'success');
        setTimeout(() => {
          window.location.reload();
        }, 1200);
      } else {
        this.showToast('Restore failed: ' + data.message, 'danger');
      }
    } catch (e) {
      this.showToast('Failed to restore database: ' + e.message, 'danger');
    }
  }

  // Written as its own string because the panel above the button and the modal in front of the
  // button have to promise the same thing. An owner comparing two lists that disagree about what
  // a reset keeps is an owner who stops clicking.
  databaseResetCopy() {
    return 'This clears the trade records on this shop\'s book.\n\n'
      + 'Destroyed:\n'
      + '• Every receipt, return, quotation/estimate and rental contract\n'
      + '• Every product, pack unit, combo/bundle, price, stock level, batch and transfer\n'
      + '• Every supplier, factory purchase order, their debts and their payments\n'
      + '• Every customer and loyalty points ledger (except the walk-in account)\n'
      + '• Every expense, register shift, dining tab and kitchen ticket\n\n'
      + 'Kept:\n'
      + '• This computer\'s licence and activation — the Machine ID does not move\n'
      + '• Staff accounts, their roles and the names you gave them\n'
      + '• Store settings, branches and receipt wording\n'
      + '• Your dining floor — the tables themselves are your furniture, not a record\n'
      + '• The shop\'s own log of who did what\n'
      + '• One copy of the shop as it stands right now, written before anything is cleared and named on screen';
  }

  async resetShopDatabase() {
    // The server checks this too, and checks the word. This guard is so the button in front of a
    // manager who was handed the backups page does not promise a thing it will refuse.
    if (!this.isAdmin()) {
      this.showToast('Only the shop\'s Administrator can reset its database.', 'danger');
      return;
    }
    if (!this.isOnline) {
      this.showToast('Resetting the database needs a connection to the local StoreFlow server.', 'warning');
      return;
    }

    const confirmed = await this.showConfirmModal({
      title: 'Reset Database?',
      message: this.databaseResetCopy(),
      icon: 'fa-triangle-exclamation',
      confirmText: 'Continue',
      cancelText: 'Cancel',
      confirmBtnClass: 'btn-danger'
    });
    if (!confirmed) return;

    // Typed, not clicked. The button above is a yes to having read the list; this one is a yes to
    // the shop losing its history, and it is the same word the server refuses without.
    const typed = await this.showPromptModal({
      title: 'Type RESET to continue',
      desc: 'Nothing is changed until the word matches, exactly as it is shown.',
      label: 'Type the word RESET',
      placeholder: 'RESET',
      confirmText: 'Reset the book',
      icon: 'fa-triangle-exclamation'
    });
    if (typed !== 'RESET') {
      this.showToast('Nothing was changed.', 'info');
      return;
    }

    try {
      const res = await this.apiFetch('api/endpoints/backups.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'reset', confirm: 'RESET' })
      });
      const data = await res.json();
      if (!data.success) {
        this.showToast('Reset failed: ' + (data.message || 'the server refused'), 'danger');
        return;
      }
      // The fresh book has a new name, and it goes through the gate that will not swallow a queue:
      // another till may still be holding yesterday's records against the old book, and those have
      // to be refused and shown to the owner, not adopted over.
      await this.checkBookEpoch(data.book_epoch);
      const keptCopy = (data.safety_backup && data.safety_backup.filename) || 'the safety copy';
      this.showToast('The book is clear. ' + Number(data.cleared_rows || 0)
        + ' record row(s) were removed. The shop as it stood is saved as ' + keptCopy + '.',
        'success', 16000);
      setTimeout(() => window.location.reload(), 3000);
    } catch (e) {
      this.showToast('Could not reach the server to reset the database: ' + e.message, 'danger');
    }
  }

  async handleBackupFileUpload(event) {
    const file = event.target.files && event.target.files[0];
    if (!file) return;

    if (!this.isOnline) {
      this.showToast('Database upload and restore requires an active connection to the local PHP server.', 'warning');
      event.target.value = '';
      return;
    }

    const sizeMb = (file.size / 1024 / 1024).toFixed(2);
    const confirmed = await this.showConfirmModal({
      title: 'Restore External Database File?',
      message: `Are you sure you want to restore from uploaded file "${file.name}" (${sizeMb} MB)?\n\n• A safety backup of your current active database will be saved automatically first.\n• The database will be validated and applied immediately.`,
      icon: 'fa-upload',
      confirmText: 'Upload & Restore',
      cancelText: 'Cancel',
      confirmBtnClass: 'btn-danger'
    });

    if (!confirmed) {
      event.target.value = '';
      return;
    }

    this.showToast('Uploading and verifying external database archive...', 'info');

    const formData = new FormData();
    formData.append('action', 'upload_restore');
    formData.append('backup_file', file);

    try {
      const res = await fetch('api/endpoints/backups.php', {
        method: 'POST',
        body: formData
      });
      const data = await res.json();
      if (data.success) {
        this.showToast(data.message, 'success');
        setTimeout(() => {
          window.location.reload();
        }, 1200);
      } else {
        this.showToast('Upload restore failed: ' + data.message, 'danger');
      }
    } catch (e) {
      this.showToast('Error uploading database: ' + e.message, 'danger');
    } finally {
      event.target.value = '';
    }
  }

  async triggerManualBackup() {
    if (window.StoreFlowAndroid && typeof window.StoreFlowAndroid.backupDatabaseToDocuments === 'function') {
      const backupPath = window.StoreFlowAndroid.backupDatabaseToDocuments();
      if (backupPath) {
        this.showToast('SQLite backup saved to Documents/StoreFlow/backups/ successfully!', 'success');
        if (typeof this.fetchBackups === 'function') await this.fetchBackups();
        this.renderCurrentView();
      } else {
        this.showToast('Failed to create SQLite backup in Documents.', 'danger');
      }
      return;
    }

    if (!this.isOnline) {
      this.showToast('Manual server database snapshots require connection to Apache/PHP.', 'warning');
      return;
    }

    this.showToast('Generating SQLite database snapshot...', 'info');
    try {
      const res = await this.apiFetch('api/endpoints/backups.php', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        await this.fetchBackups();
        this.renderCurrentView();
        this.showToast('Database snapshot created successfully!', 'success');
      } else {
        this.showToast(data.message, 'danger');
      }
    } catch (e) {
      this.showToast('Failed to trigger database backup: ' + e.message, 'danger');
    }
  }

  // --- Encrypted off-site copies (.sfbak) ---

  toggleSfbakPass(inputId, btn) {
    const el = document.getElementById(inputId);
    if (!el) return;
    const revealing = el.type === 'password';
    el.type = revealing ? 'text' : 'password';
    const icon = btn && btn.querySelector ? btn.querySelector('i') : null;
    if (icon) icon.className = 'fa-solid ' + (revealing ? 'fa-eye-slash' : 'fa-eye');
    if (revealing) el.focus();
  }

  // Erase a passphrase from the screen once the request has carried it away. The field
  // is a text box in a DOM that stays open after this view is left - and a till is a
  // counter that other people stand behind.
  _sfbakWipePassFields(ids) {
    (Array.isArray(ids) ? ids : [ids]).forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;
      el.value = '';
      el.type = 'password';
      const icon = el.parentElement && el.parentElement.querySelector
        ? el.parentElement.querySelector('button i') : null;
      if (icon) icon.className = 'fa-solid fa-eye';
    });
  }

  // The name comes from the server header, so it is treated as untrusted text: any path
  // separators go, then the whole thing must still look like our own export name or it
  // is replaced with a locally generated one.
  _sfbakNameFromResponse(res) {
    const disposition = (res.headers && res.headers.get('Content-Disposition')) || '';
    const match = disposition.match(/filename="?([^";]+)"?/);
    const cleaned = match ? match[1].replace(/^.*[\\/]/, '').replace(/[^A-Za-z0-9._\-()]/g, '_') : '';
    if (/^StoreFlow-encrypted-backup-[0-9TZ:._\-]+\.sfbak$/.test(cleaned)) return cleaned;
    const now = new Date();
    const pad = n => String(n).padStart(2, '0');
    return `StoreFlow-encrypted-backup-${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}_${pad(now.getHours())}-${pad(now.getMinutes())}-${pad(now.getSeconds())}.sfbak`;
  }

  async _sfbakSaveToFolder(blob, filename) {
    // On the till's own browser the owner points the copy at a folder he chose -
    // Documents\StoreFlow, a USB stick in the drawer - the way he would save it himself.
    // Returns true (written), 'cancelled' (he closed the picker) or false (this browser
    // cannot do it, or refused the permission), which is when the download runs instead.
    if (typeof window.showDirectoryPicker !== 'function') return false;
    let dir;
    try {
      dir = await window.showDirectoryPicker({ id: 'storeflow-backups', mode: 'readwrite' });
    } catch (err) {
      if (err && err.name === 'AbortError') return 'cancelled';
      return false;
    }
    try {
      const handle = await dir.getFileHandle(filename, { create: true });
      const writable = await handle.createWritable();
      await writable.write(blob);
      await writable.close();
      return true;
    } catch (err) {
      this.showToast('Could not write into that folder: ' + (err && err.message ? err.message : err), 'danger');
      return 'cancelled';
    }
  }

  _sfbakBrowserDownload(blob, filename) {
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  }

  async exportEncryptedBackup() {
    if (!this.isOnline) {
      this.showToast('Making an encrypted copy needs a connection to the local StoreFlow server.', 'warning');
      return;
    }
    const passEl = document.getElementById('sfbak-export-pass');
    const repeatEl = document.getElementById('sfbak-export-pass2');
    const passphrase = passEl ? passEl.value : '';

    if (passphrase.length < 10) {
      this.showToast('Choose a passphrase of at least 10 characters. It is the only thing that opens the file, and it is never stored.', 'warning');
      return;
    }
    if (passphrase.length > 200) {
      this.showToast('That passphrase is too long to be remembered, which is the same as lost.', 'warning');
      return;
    }
    if (!repeatEl || repeatEl.value !== passphrase) {
      this.showToast('The two passphrase boxes do not match. Fix them now - a typo here is a backup nobody can open.', 'warning');
      return;
    }

    const ready = await this.showConfirmModal({
      title: 'Have you written the passphrase down?',
      message: 'The passphrase is never stored: not in the database, not in the activity log, not with the seller. Lose it and this copy cannot be opened by anyone, ever.\n\nUse the eye on the passphrase box to check what you typed, write it on paper, keep the paper apart from the backup, then continue.',
      icon: 'fa-key',
      confirmText: 'I have written it down',
      cancelText: 'Cancel',
      confirmBtnClass: 'btn-primary'
    });
    if (!ready) return;

    this.showToast('Encrypting a copy of the till database...', 'info');
    let res;
    try {
      res = await this.apiFetch('api/endpoints/backups.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'export_encrypted', passphrase })
      });
    } catch (err) {
      this._sfbakWipePassFields(['sfbak-export-pass', 'sfbak-export-pass2']);
      this.showToast('Could not reach the local server: ' + (err && err.message ? err.message : err), 'danger');
      return;
    }
    this._sfbakWipePassFields(['sfbak-export-pass', 'sfbak-export-pass2']);

    const contentType = (res.headers && res.headers.get('Content-Type')) || '';
    if (!res.ok || contentType.indexOf('application/json') !== -1) {
      let message = 'The encrypted copy could not be made.';
      try {
        const body = await res.json();
        if (body && typeof body.message === 'string' && body.message) message = body.message;
      } catch (err) { /* a non-JSON refusal says only what the status already said */ }
      this.showToast('Encrypted export failed: ' + message, 'danger');
      return;
    }

    let blob;
    try {
      blob = await res.blob();
    } catch (err) {
      this.showToast('The encrypted copy arrived damaged: ' + (err && err.message ? err.message : err), 'danger');
      return;
    }
    if (!blob || !blob.size) {
      this.showToast('The encrypted copy came back empty. Nothing was saved.', 'danger');
      return;
    }

    const filename = this._sfbakNameFromResponse(res);
    const saved = await this._sfbakSaveToFolder(blob, filename);
    if (saved === 'cancelled') {
      this.showToast('Nothing was saved, and nothing was changed.', 'info');
      return;
    }
    if (saved === true) {
      this.showToast(`${filename} written to the folder you chose. Keep it somewhere other than this computer.`, 'success');
    } else {
      this._sfbakBrowserDownload(blob, filename);
      this.showToast(`${filename} is in your downloads. Copy it to a USB stick or a second PC, not onto this same disk.`, 'success');
    }
  }

  async restoreEncryptedBackup() {
    if (!this.isOnline) {
      this.showToast('Restoring an encrypted copy needs a connection to the local StoreFlow server.', 'warning');
      return;
    }
    const fileEl = document.getElementById('sfbak-import-file');
    const file = fileEl && fileEl.files ? fileEl.files[0] : null;
    if (!file) {
      this.showToast('Choose the .sfbak file you want to restore from first.', 'warning');
      return;
    }
    const passEl = document.getElementById('sfbak-import-pass');
    const passphrase = passEl ? passEl.value : '';
    if (!passphrase) {
      this.showToast('Type the passphrase this file was made with. Without it the file is unreadable by design.', 'warning');
      return;
    }

    const sizeMb = (file.size / 1024 / 1024).toFixed(2);
    const confirmed = await this.showConfirmModal({
      title: 'Restore from the encrypted copy?',
      message: `"${file.name}" (${sizeMb} MB)\n\n• Every current record is replaced by the records inside that file.\n• A safety snapshot of today's state is taken first, so this is undoable.\n• The file is verified before anything changes; a wrong passphrase or a damaged copy stops it with nothing touched.`,
      icon: 'fa-file-shield',
      confirmText: 'Decrypt & Restore',
      cancelText: 'Cancel',
      confirmBtnClass: 'btn-danger'
    });
    if (!confirmed) return;

    this.showToast('Reading and verifying the encrypted copy...', 'info');
    const formData = new FormData();
    formData.append('action', 'import_restore');
    formData.append('passphrase', passphrase);
    formData.append('sfbak_file', file);
    this._sfbakWipePassFields(['sfbak-import-pass']);

    try {
      const res = await this.apiFetch('api/endpoints/backups.php', { method: 'POST', body: formData });
      const data = await res.json();
      if (data.success) {
        if (fileEl) fileEl.value = '';
        this.showToast(data.message, 'success');
        setTimeout(() => { window.location.reload(); }, 1500);
      } else {
        this.showToast('Encrypted restore failed: ' + data.message, 'danger');
      }
    } catch (err) {
      this.showToast('Error restoring the encrypted copy: ' + (err && err.message ? err.message : err), 'danger');
    }
  }

  // --- Store Profile & Receipt Settings ---

  getProfileHTML() {
    const prof = this.storeProfile;

    return `
      <div class="profile-layout-grid">
        <div class="panel">
          <div class="panel-header">
            <h3><i class="fa-solid fa-store"></i> Edit Store Profile</h3>
            <button class="btn btn-primary" onclick="app.saveProfileForm()">
              <i class="fa-solid fa-floppy-disk"></i> Save Profile
            </button>
          </div>
          <div class="panel-body">
            <!-- Software License & Terminal Binding Status -->
            <div style="background: ${this._sessionScope === 'trial' ? '#fffbeb' : '#f0fdf4'}; border: 1.5px solid ${this._sessionScope === 'trial' ? '#f59e0b' : '#22c55e'}; border-radius: var(--radius-md); padding: 0.9rem 1.25rem; margin-bottom: 1.25rem; display: flex; justify-content: space-between; align-items: center; gap: 1rem; flex-wrap: wrap;">
              <div style="display: flex; align-items: center; gap: 0.85rem;">
                <div style="width: 38px; height: 38px; border-radius: 8px; background: ${this._sessionScope === 'trial' ? '#d97706' : '#16a34a'}; color: #ffffff; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; flex-shrink: 0;">
                  <i class="fa-solid ${this._sessionScope === 'trial' ? 'fa-clock' : 'fa-certificate'}"></i>
                </div>
                <div>
                  <div style="font-weight: 700; font-size: 0.92rem; color: var(--slate-900);">
                    License Status: ${this._sessionScope === 'trial' ? `Free Evaluation (${this._quotaDays || 0} Day${Number(this._quotaDays) !== 1 ? 's' : ''} Remaining)` : 'Permanent Lifetime Commercial License'}
                  </div>
                  <div style="font-size: 0.76rem; color: var(--slate-600); margin-top: 0.1rem;">
                    Terminal Hardware Binding: <code style="font-size: 0.72rem; background: rgba(0,0,0,0.06); padding: 2px 5px; border-radius: 3px;">${this.escapeHtml((this._machineRef || 'STANDALONE').substring(0, 24))}…</code>
                  </div>
                </div>
              </div>
              ${this._sessionScope === 'trial' ? `
                <button type="button" class="btn btn-sm btn-primary" onclick="window.sfStartPurchaseFlow ? window.sfStartPurchaseFlow() : app.openLicenseModal()" style="background: linear-gradient(135deg, #0d9488 0%, #059669 100%); border: none; font-weight: 700; box-shadow: 0 2px 6px rgba(13,148,136,0.3); padding: 0.45rem 0.9rem; font-size: 0.82rem;">
                  <i class="fa-solid fa-bolt"></i> Upgrade to Lifetime License
                </button>
              ` : `
                <div style="display: flex; align-items: center; gap: 0.4rem; color: #16a34a; font-size: 0.85rem; font-weight: 700;">
                  <i class="fa-solid fa-circle-check"></i> Activated
                </div>
              `}
            </div>

            <!-- Business Operating Mode Selector (Retail vs Hospitality vs Hybrid) -->
            ${typeof this.getOperatingModeSelectorHTML === 'function' ? this.getOperatingModeSelectorHTML() : ''}

            <!-- Loyalty & Rewards Policy (the shop's own figures, priced by the server) -->
            ${typeof this.getLoyaltyPolicyCardHTML === 'function' ? this.getLoyaltyPolicyCardHTML() : ''}

            <!-- Mode Switcher: Solo Store vs Multi-Branch Network -->
            <div style="background: ${this.isMultiBranch ? '#eef2ff' : '#f8fafc'}; border: 1.5px solid ${this.isMultiBranch ? '#6366f1' : 'var(--slate-200)'}; border-radius: var(--radius-md); padding: 1rem 1.25rem; margin-bottom: 1.25rem; display: flex; justify-content: space-between; align-items: center; gap: 1rem; flex-wrap: wrap;">
              <div style="display: flex; align-items: center; gap: 0.85rem;">
                <div style="width: 40px; height: 40px; border-radius: 8px; background: ${this.isMultiBranch ? '#4f46e5' : '#64748b'}; color: #ffffff; display: flex; align-items: center; justify-content: center; font-size: 1.15rem; flex-shrink: 0;">
                  <i class="fa-solid ${this.isMultiBranch ? 'fa-code-branch' : 'fa-shop'}"></i>
                </div>
                <div>
                  <div style="font-weight: 700; font-size: 0.95rem; color: var(--slate-900);">
                    Store Architecture: ${this.isMultiBranch ? 'Multi-Branch Enterprise Network' : 'Solo Store Mode (Single Location)'}
                  </div>
                  <div style="font-size: 0.78rem; color: var(--slate-600); margin-top: 0.1rem;">
                    ${this.isMultiBranch
        ? 'Branch directory, multi-location sales tagging, and branch-filtered analytics are enabled.'
        : 'Streamlined single-store interface. Branch tags and extra multi-store selectors are hidden.'}
                  </div>
                </div>
              </div>
              <label style="display: flex; align-items: center; gap: 0.5rem; font-size: 0.85rem; font-weight: 700; color: ${this.isMultiBranch ? '#4f46e5' : 'var(--slate-600)'}; cursor: pointer; user-select: none;">
                <input type="checkbox" id="prof-multi-branch-toggle" ${this.isMultiBranch ? 'checked' : ''} onchange="app.toggleMultiBranchMode(this.checked)" style="width: 18px; height: 18px; cursor: pointer;">
                <span>Enable Multi-Branch Mode</span>
              </label>
            </div>

            <p style="font-size: 0.85rem; color: var(--slate-600); margin-bottom: 1.25rem;">
              This information will be printed on customer receipts and invoices, and displayed across the app.
            </p>

            <!-- Custom Store Logo & White-Labeling Upload -->
            <div style="background: var(--slate-50); border: 1.5px dashed var(--slate-300); border-radius: var(--radius-md); padding: 1rem 1.25rem; margin-bottom: 1.25rem; display: flex; align-items: center; justify-content: space-between; gap: 1rem; flex-wrap: wrap;">
              <div style="display: flex; align-items: center; gap: 1rem;">
                <div style="position: relative; width: 62px; height: 62px; border-radius: 14px; overflow: hidden; border: 2px solid var(--slate-300); background: #0f172a; flex-shrink: 0; box-shadow: var(--shadow-sm); display: flex; align-items: center; justify-content: center;">
                  <img id="prof-logo-preview" src="${this.escapeHtml(this.getStoreLogo())}" alt="Store Logo" style="width: 100%; height: 100%; object-fit: contain;">
                </div>
                <div>
                  <div style="display: flex; gap: 0.5rem; align-items: center;">
                    <label class="form-label" style="margin-bottom: 0; font-weight: 700; font-size: 0.95rem;">Store Brand Logo</label>
                    <span class="badge ${prof.logo_url ? 'badge-success' : 'badge-slate'}" id="prof-logo-status-badge">
                      ${prof.logo_url ? '<i class="fa-solid fa-circle-check"></i> Custom Store Logo Active' : 'StoreFlow Default (Fallback)'}
                    </span>
                  </div>
                  <p style="font-size: 0.78rem; color: var(--slate-600); margin: 0.25rem 0 0.5rem;">
                    Replaces the StoreFlow logo across the sidebar, login screen, customer receipts, and statement reports.
                  </p>
                  <div style="display: flex; gap: 0.5rem; align-items: center; flex-wrap: wrap;">
                    <input type="file" id="prof-logo-file-input" accept="image/png, image/jpeg, image/webp, image/svg+xml" onchange="app.handleLogoFileSelect(event)" style="display: none;">
                    <button type="button" class="btn btn-outline btn-sm" onclick="document.getElementById('prof-logo-file-input').click()">
                      <i class="fa-solid fa-cloud-arrow-up"></i> Upload Custom Logo
                    </button>
                    ${prof.logo_url ? `
                      <button type="button" class="btn btn-danger btn-sm" onclick="app.removeCustomLogo()">
                        <i class="fa-solid fa-trash-can"></i> Reset to Default
                      </button>
                    ` : ''}
                  </div>
                </div>
              </div>
            </div>

            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Store / Business Name *</label>
                <input type="text" id="prof-name" class="form-control" value="${this.escapeHtml(prof.store_name || '')}">
              </div>
              <div class="form-group">
                <label class="form-label">Tagline / Motto</label>
                <input type="text" id="prof-tagline" class="form-control" value="${this.escapeHtml(prof.tagline || '')}">
              </div>
            </div>

            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Phone Number</label>
                <input type="text" id="prof-phone" class="form-control" value="${this.escapeHtml(prof.phone || '')}">
              </div>
              <div class="form-group">
                <label class="form-label">Email Address</label>
                <input type="email" id="prof-email" class="form-control" value="${this.escapeHtml(prof.email || '')}">
              </div>
            </div>

            <div class="form-group">
              <label class="form-label">Store Physical Address</label>
              <input type="text" id="prof-address" class="form-control" value="${this.escapeHtml(prof.address || '')}">
            </div>

            <div class="form-row">
              <div class="form-group" style="flex: 2;">
                <label class="form-label">Tax / VAT Registration Number (TIN / GRA)</label>
                <input type="text" id="prof-tax" class="form-control" value="${this.escapeHtml(prof.tax_number || '')}" placeholder="e.g. C0001234567 or VAT-998877">
              </div>
              <div class="form-group" style="flex: 1;">
                <label class="form-label">Default Tax / VAT Rate (%)</label>
                <input type="number" id="prof-tax-rate" class="form-control" value="${this.escapeHtml(prof.tax_rate !== undefined ? prof.tax_rate : 0)}" min="0" max="100" step="0.1" placeholder="0">
              </div>
            </div>
            <p style="font-size: 0.74rem; color: var(--slate-500); margin-top: -0.5rem; margin-bottom: 1rem;">
              Set to <strong>0%</strong> if your retail prices are tax-inclusive or tax-exempt. If set above 0%, tax is computed automatically at POS checkout.
            </p>

            <div class="form-row" style="background: var(--slate-50); padding: 0.85rem 1rem; border-radius: var(--radius-md); border: 1px solid var(--slate-200); margin-bottom: 1rem; align-items: flex-end;">
              <div class="form-group" style="flex: 2; margin-bottom: 0;">
                <label class="form-label"><i class="fa-solid fa-coins" style="color: var(--primary);"></i> Select Store Currency</label>
                <select id="prof-currency-select" class="form-control" onchange="app.handleCurrencySelect(this.value)">
                  <option value="USD|$|USD" ${prof.currency_code === 'USD' ? 'selected' : ''}>USD - US Dollar ($)</option>
                  <option value="GHS|GH₵|GHS" ${prof.currency_code === 'GHS' || prof.currency_symbol === 'GH₵' || prof.currency_symbol === '₵' ? 'selected' : ''}>GHS - Ghanaian Cedi (GH₵)</option>
                  <option value="NGN|₦|NGN" ${prof.currency_code === 'NGN' || prof.currency_symbol === '₦' ? 'selected' : ''}>NGN - Nigerian Naira (₦)</option>
                  <option value="EUR|€|EUR" ${prof.currency_code === 'EUR' ? 'selected' : ''}>EUR - Euro (€)</option>
                  <option value="GBP|£|GBP" ${prof.currency_code === 'GBP' ? 'selected' : ''}>GBP - British Pound (£)</option>
                  <option value="KES|KSh|KES" ${prof.currency_code === 'KES' ? 'selected' : ''}>KES - Kenyan Shilling (KSh)</option>
                  <option value="ZAR|R|ZAR" ${prof.currency_code === 'ZAR' ? 'selected' : ''}>ZAR - South African Rand (R)</option>
                  <option value="CAD|$|CAD" ${prof.currency_code === 'CAD' ? 'selected' : ''}>CAD - Canadian Dollar ($)</option>
                  <option value="AUD|$|AUD" ${prof.currency_code === 'AUD' ? 'selected' : ''}>AUD - Australian Dollar ($)</option>
                  <option value="INR|₹|INR" ${prof.currency_code === 'INR' ? 'selected' : ''}>INR - Indian Rupee (₹)</option>
                  <option value="EGP|E£|EGP" ${prof.currency_code === 'EGP' ? 'selected' : ''}>EGP - Egyptian Pound (E£)</option>
                  <option value="TZS|TSh|TZS" ${prof.currency_code === 'TZS' ? 'selected' : ''}>TZS - Tanzanian Shilling (TSh)</option>
                  <option value="UGX|USh|UGX" ${prof.currency_code === 'UGX' ? 'selected' : ''}>UGX - Ugandan Shilling (USh)</option>
                  <option value="RWF|FRw|RWF" ${prof.currency_code === 'RWF' ? 'selected' : ''}>RWF - Rwandan Franc (FRw)</option>
                  <option value="XOF|CFA|XOF" ${prof.currency_code === 'XOF' ? 'selected' : ''}>XOF - West African CFA (CFA)</option>
                  <option value="XAF|FCFA|XAF" ${prof.currency_code === 'XAF' ? 'selected' : ''}>XAF - Central African CFA (FCFA)</option>
                  <option value="AED|د.إ|AED" ${prof.currency_code === 'AED' ? 'selected' : ''}>AED - UAE Dirham (د.إ)</option>
                  <option value="SAR|﷼|SAR" ${prof.currency_code === 'SAR' ? 'selected' : ''}>SAR - Saudi Riyal (﷼)</option>
                  <option value="CUSTOM||" ${!['USD', 'GHS', 'NGN', 'EUR', 'GBP', 'KES', 'ZAR', 'CAD', 'AUD', 'INR', 'EGP', 'TZS', 'UGX', 'RWF', 'XOF', 'XAF', 'AED', 'SAR'].includes(prof.currency_code) ? 'selected' : ''}>Custom / Type My Own...</option>
                </select>
              </div>
              <div class="form-group" style="flex: 1; margin-bottom: 0;">
                <label class="form-label">Symbol</label>
                <input type="text" id="prof-currency-symbol" class="form-control" value="${this.escapeHtml(prof.currency_symbol || '$')}" oninput="app.updateLiveReceiptPreview()" style="font-weight: 700;">
              </div>
              <div class="form-group" style="flex: 1; margin-bottom: 0;">
                <label class="form-label">Code</label>
                <input type="text" id="prof-currency-code" class="form-control" value="${this.escapeHtml(prof.currency_code || 'USD')}" style="font-weight: 700;">
              </div>
            </div>

            <!-- Customer Receipt Text & Styling Suite -->
            <div style="background: #f8fafc; border: 1.5px solid var(--slate-200); border-radius: var(--radius-md); padding: 1.1rem; margin-top: 1.25rem; margin-bottom: 1.25rem;">
              <h4 style="font-size: 0.95rem; font-weight: 700; color: var(--slate-800); margin-bottom: 0.85rem; display: flex; align-items: center; gap: 0.45rem;">
                <i class="fa-solid fa-receipt" style="color: var(--primary);"></i> Customer Receipt Text & Customization
              </h4>

              <div class="form-group">
                <label class="form-label">Receipt Header Subtitle / Greeting</label>
                <input type="text" id="prof-receipt-header" class="form-control" value="${this.escapeHtml(prof.receipt_header || '')}" placeholder="e.g. Welcome to My Store Enterprise! · Official Retail Invoice">
                <small style="color: var(--slate-500); font-size: 0.73rem;">Prints directly below the store name & address on the thermal receipt.</small>
              </div>

              <div class="form-group">
                <label class="form-label">Payment / MoMo Transfer Instructions (Optional)</label>
                <input type="text" id="prof-receipt-momo" class="form-control" value="${this.escapeHtml(prof.receipt_momo_note || '')}" placeholder="e.g. MoMo Pay ID: 123456 (Name: Kofi Mensah) · Bank: Ecobank 144100..." oninput="app.updateLiveReceiptPreview()">
                <small style="color: var(--slate-500); font-size: 0.73rem;">Displayed prominently above the return policy for customers paying via mobile money or bank transfer.</small>
              </div>

              <div class="form-group">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.35rem; flex-wrap: wrap; gap: 0.3rem;">
                  <label class="form-label" style="margin-bottom: 0;">Receipt Footer Note & Return Policy</label>
                  <div style="display: flex; gap: 0.35rem; flex-wrap: wrap;">
                    <span style="font-size: 0.72rem; color: var(--slate-500); align-self: center;">Quick Templates:</span>
                    <button type="button" class="btn btn-outline btn-sm" style="font-size: 0.68rem; padding: 0.15rem 0.45rem;" onclick="app.applyReceiptPolicyTemplate('no_return')">
                      🚫 No Returns
                    </button>
                    <button type="button" class="btn btn-outline btn-sm" style="font-size: 0.68rem; padding: 0.15rem 0.45rem;" onclick="app.applyReceiptPolicyTemplate('exchange_48h')">
                      🔄 48h Exchange
                    </button>
                    <button type="button" class="btn btn-outline btn-sm" style="font-size: 0.68rem; padding: 0.15rem 0.45rem;" onclick="app.applyReceiptPolicyTemplate('appreciation')">
                      🙏 Warm Thanks
                    </button>
                  </div>
                </div>
                <textarea id="prof-receipt-footer" class="form-control" rows="3" placeholder="Enter terms of sale, warranty, or return policy...">${this.escapeHtml(prof.receipt_footer || '')}</textarea>
              </div>

              <!-- Thermal Receipt Layout Toggles -->
              <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 0.75rem; background: #ffffff; border: 1px solid var(--slate-200); border-radius: var(--radius-md); padding: 0.85rem; margin-top: 0.75rem;">
                <label style="display: flex; align-items: center; gap: 0.5rem; font-size: 0.82rem; font-weight: 600; color: var(--slate-700); cursor: pointer; margin: 0;">
                  <input type="checkbox" id="prof-print-logo-receipts" ${this.shouldPrintReceiptLogo() ? 'checked' : ''} onchange="app.updateLiveReceiptPreview()" style="width: 17px; height: 17px; accent-color: var(--primary);">
                  <span>Print Store Logo on Slip</span>
                </label>
                <label style="display: flex; align-items: center; gap: 0.5rem; font-size: 0.82rem; font-weight: 600; color: var(--slate-700); cursor: pointer; margin: 0;">
                  <input type="checkbox" id="prof-show-tax-receipt" ${prof.show_tax_on_receipt !== 0 ? 'checked' : ''} onchange="app.updateLiveReceiptPreview()" style="width: 17px; height: 17px; accent-color: var(--primary);">
                  <span>Show Tax / TIN Line</span>
                </label>
                <label style="display: flex; align-items: center; gap: 0.5rem; font-size: 0.82rem; font-weight: 600; color: var(--slate-700); cursor: pointer; margin: 0;">
                  <input type="checkbox" id="prof-show-cashier-receipt" ${prof.show_cashier_on_receipt !== 0 ? 'checked' : ''} onchange="app.updateLiveReceiptPreview()" style="width: 17px; height: 17px; accent-color: var(--primary);">
                  <span>Show Cashier & Terminal</span>
                </label>
              </div>

              <!-- Thermal Receipt Typography & Paper Settings -->
              <div style="background: #ffffff; border: 1px solid var(--slate-200); border-radius: var(--radius-md); padding: 1rem; margin-top: 0.75rem;">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.75rem; flex-wrap: wrap; gap: 0.5rem;">
                  <div style="font-weight: 700; font-size: 0.88rem; color: var(--slate-800); display: flex; align-items: center; gap: 0.4rem;">
                    <i class="fa-solid fa-font" style="color: var(--primary);"></i> Receipt Typography & Paper Width
                  </div>
                  <span class="badge badge-neutral" style="font-size: 0.7rem;"><i class="fa-solid fa-eye"></i> Live Preview Sync</span>
                </div>
                
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 0.75rem;">
                  <!-- Paper Roll Width -->
                  <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="font-size: 0.78rem;">Paper Roll Width</label>
                    <select id="prof-receipt-paper-width" class="form-control form-control-sm" onchange="app.updateLiveReceiptPreview()">
                      <option value="80mm" ${(prof.receipt_paper_width || '80mm') === '80mm' ? 'selected' : ''}>80mm (Standard POS Roll)</option>
                      <option value="58mm" ${prof.receipt_paper_width === '58mm' ? 'selected' : ''}>58mm (Mobile / Mini Thermal)</option>
                    </select>
                  </div>

                  <!-- Font Type / Family -->
                  <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="font-size: 0.78rem;">Font Type / Family</label>
                    <select id="prof-receipt-font-family" class="form-control form-control-sm" onchange="app.updateLiveReceiptPreview()">
                      <option value="monospace" ${(prof.receipt_font_family || 'monospace') === 'monospace' ? 'selected' : ''}>Classic Thermal (Courier Mono)</option>
                      <option value="sans" ${prof.receipt_font_family === 'sans' ? 'selected' : ''}>Modern Retail (Segoe UI / Sans)</option>
                      <option value="retro" ${prof.receipt_font_family === 'retro' ? 'selected' : ''}>Retro POS (Lucida Console)</option>
                      <option value="condensed" ${prof.receipt_font_family === 'condensed' ? 'selected' : ''}>Condensed Roll (Roboto Mono)</option>
                    </select>
                  </div>

                  <!-- Font Size -->
                  <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="font-size: 0.78rem;">Font Size</label>
                    <select id="prof-receipt-font-size" class="form-control form-control-sm" onchange="app.updateLiveReceiptPreview()">
                      <option value="compact" ${prof.receipt_font_size === 'compact' ? 'selected' : ''}>Compact (11px · Space Saver)</option>
                      <option value="medium" ${(prof.receipt_font_size || 'medium') === 'medium' ? 'selected' : ''}>Standard (13px · Balanced)</option>
                      <option value="large" ${prof.receipt_font_size === 'large' ? 'selected' : ''}>Large (15px · High Legibility)</option>
                    </select>
                  </div>

                  <!-- Font Weight / Density -->
                  <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="font-size: 0.78rem;">Print Darkness / Weight</label>
                    <select id="prof-receipt-font-weight" class="form-control form-control-sm" onchange="app.updateLiveReceiptPreview()">
                      <option value="normal" ${(prof.receipt_font_weight || 'normal') === 'normal' ? 'selected' : ''}>Normal (400 · Crisp Default)</option>
                      <option value="medium" ${prof.receipt_font_weight === 'medium' ? 'selected' : ''}>Medium (600 · Enhanced Clarity)</option>
                      <option value="bold" ${prof.receipt_font_weight === 'bold' ? 'selected' : ''}>Bold (700 · High Density / Dark)</option>
                    </select>
                  </div>

                  <!-- Layout & Paper Saver Mode -->
                  <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="font-size: 0.78rem;">Layout & Paper Saver</label>
                    <select id="prof-receipt-spacing" class="form-control form-control-sm" onchange="app.updateLiveReceiptPreview()">
                      <option value="ultra_compact" ${(prof.receipt_spacing || 'ultra_compact') === 'ultra_compact' ? 'selected' : ''}>⚡ Ultra-Compact (Near-Square · 50% Paper Saver)</option>
                      <option value="compact" ${prof.receipt_spacing === 'compact' ? 'selected' : ''}>Compact (Slim Lines & Tight Margins)</option>
                      <option value="standard" ${prof.receipt_spacing === 'standard' ? 'selected' : ''}>Classic (Detailed / Normal Spacing)</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>

            <div class="form-row" style="background: var(--slate-50); padding: 1rem; border-radius: var(--radius-md); border: 1px solid var(--slate-200); margin-top: 1rem; display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1rem;">
              <div class="form-group" style="margin-bottom: 0;">
                <label class="form-label">Automatic DB Backup Interval (Hours)</label>
                <input type="number" id="prof-backup-hours" class="form-control" value="${this.escapeHtml(prof.auto_backup_hours || 2)}" min="1" max="24" style="max-width: 140px;">
              </div>
              <div class="form-group" style="margin-bottom: 0;">
                <label class="form-label">Default Quotation Validity (Days)</label>
                <div style="display: flex; align-items: center; gap: 0.5rem;">
                  <input type="number" id="prof-estimate-validity-days" class="form-control" value="${this.escapeHtml(prof.estimate_validity_days || 7)}" min="1" max="365" style="max-width: 110px; font-weight: 700;">
                  <span style="font-size: 0.78rem; color: var(--slate-500);">days before prices expire</span>
                </div>
              </div>
              <div class="form-group" style="margin-bottom: 0;">
                <label class="form-label">Out-of-Stock Sales Policy</label>
                <label style="display: flex; align-items: center; gap: 0.5rem; font-size: 0.82rem; font-weight: 600; color: var(--slate-700); margin-top: 0.35rem; cursor: pointer;">
                  <input type="checkbox" id="prof-allow-negative-stock" ${prof.allow_negative_stock == 1 ? 'checked' : ''} style="width: 18px; height: 18px; accent-color: var(--primary);">
                  <span>Allow selling out-of-stock items (negative inventory)</span>
                </label>
              </div>
              <div class="form-group" style="margin-bottom: 0;">
                <label class="form-label">Item Line-by-Line Discounts</label>
                <label style="display: flex; align-items: center; gap: 0.5rem; font-size: 0.82rem; font-weight: 600; color: var(--slate-700); margin-top: 0.35rem; cursor: pointer;">
                  <input type="checkbox" id="prof-enable-line-discounts" ${prof.enable_line_discounts == 1 ? 'checked' : ''} style="width: 18px; height: 18px; accent-color: var(--primary);">
                  <span>Enable discount button on individual POS cart items</span>
                </label>
              </div>
            </div>

            <!-- mNotify SMS Gateway Configuration (Digital Receipts & Customer Alerts) -->
            <div class="form-row" style="background: #f0f9ff; padding: 1rem 1.25rem; border-radius: var(--radius-md); border: 1px solid #bae6fd; margin-top: 1rem;">
              <div style="width: 100%; margin-bottom: 0.5rem; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.5rem;">
                <div style="display: flex; align-items: center; gap: 0.5rem;">
                  <i class="fa-solid fa-comment-sms" style="color: #0284c7; font-size: 1.15rem;"></i>
                  <strong style="color: #0369a1; font-size: 0.95rem;">mNotify SMS Gateway Integration (Ghana & West Africa)</strong>
                </div>
                <button type="button" class="btn btn-sm btn-outline" onclick="app.testMNotifySMS()" style="font-weight: 700; color: #0284c7; border-color: #0284c7; background: #ffffff;">
                  <i class="fa-solid fa-paper-plane"></i> Test SMS Connection
                </button>
              </div>

              <div class="form-group" style="flex: 1; min-width: 200px; margin-bottom: 0.5rem;">
                <label class="form-label">mNotify API Key</label>
                <input type="password" id="prof-mnotify-api-key" class="form-control" value="${prof.mnotify_api_key ? '********' : ''}" placeholder="Paste your mNotify API key here...">
                <small style="color: var(--slate-500); font-size: 0.73rem;">Get your API key from <a href="https://mnotify.com" target="_blank" style="color: var(--primary);">mnotify.com</a> account portal.</small>
              </div>

              <div class="form-group" style="flex: 1; min-width: 150px; margin-bottom: 0.5rem;">
                <label class="form-label">Sender ID (Max 11 chars)</label>
                <input type="text" id="prof-mnotify-sender-id" class="form-control" maxlength="11" value="${this.escapeHtml(prof.mnotify_sender_id || 'StoreFlow')}" placeholder="e.g. MYSTORE" style="font-weight: 700; text-transform: uppercase;">
                <small style="color: var(--slate-500); font-size: 0.73rem;">Approved Sender ID displayed to customer.</small>
              </div>

              <div class="form-group" style="flex: 1; min-width: 220px; margin-bottom: 0.5rem;">
                <label class="form-label">Owner/Manager Mobile Number</label>
                <input type="text" id="prof-mnotify-owner-phone" class="form-control" value="${this.escapeHtml(prof.mnotify_owner_phone || prof.phone || '')}" placeholder="e.g. 0244123456" style="font-weight: 600;">
                <small style="color: var(--slate-500); font-size: 0.73rem;">Alert recipient for Low-Stock warnings & Shift Z-Reports.</small>
              </div>

              <div class="form-group" style="width: 100%; margin-bottom: 0.35rem;">
                <label style="display: flex; align-items: center; gap: 0.5rem; font-size: 0.85rem; font-weight: 600; color: var(--slate-700); cursor: pointer;">
                  <input type="checkbox" id="prof-mnotify-auto-sms" ${prof.mnotify_auto_sms == 1 ? 'checked' : ''} style="width: 18px; height: 18px; accent-color: var(--primary);">
                  <span>Automatically dispatch instant SMS receipt to customer upon POS checkout</span>
                </label>
              </div>

              <div class="form-group" style="width: 100%; margin-bottom: 0.35rem;">
                <label style="display: flex; align-items: center; gap: 0.5rem; font-size: 0.85rem; font-weight: 600; color: var(--slate-700); cursor: pointer;">
                  <input type="checkbox" id="prof-mnotify-low-stock" ${prof.mnotify_low_stock_alert !== 0 ? 'checked' : ''} style="width: 18px; height: 18px; accent-color: var(--primary);">
                  <span>Automatically send Low-Stock SMS alert to owner when items drop below reorder level</span>
                </label>
              </div>

              <div class="form-group" style="width: 100%; margin-bottom: 0;">
                <label style="display: flex; align-items: center; gap: 0.5rem; font-size: 0.85rem; font-weight: 600; color: var(--slate-700); cursor: pointer;">
                  <input type="checkbox" id="prof-mnotify-shift-close" ${prof.mnotify_shift_close_alert !== 0 ? 'checked' : ''} style="width: 18px; height: 18px; accent-color: var(--primary);">
                  <span>Enable one-click dispatch of daily Shift Z-Report reconciliation summary SMS to owner</span>
                </label>
              </div>
            </div>

            <!-- Terminal & Multi-Branch Workstation Configuration -->
            <div class="form-row" style="background: var(--slate-50); padding: 1rem; border-radius: var(--radius-md); border: 1px solid var(--slate-200); margin-top: 1rem;">
              <div class="form-group" style="margin-bottom: 0;">
                <label class="form-label"><i class="fa-solid fa-desktop" style="color: var(--primary);"></i> Workstation / Terminal ID</label>
                <input type="text" id="prof-terminal-id" class="form-control" value="${this.escapeHtml(this.terminalId || 'REG-01')}" placeholder="REG-01" style="max-width: 160px; font-weight: 700; font-family: monospace; text-transform: uppercase;">
                <small style="color: var(--slate-500); font-size: 0.75rem;">Terminal ID tagged to sales & shifts.</small>
              </div>
              ${this.isMultiBranch ? `
                <div class="form-group" style="margin-bottom: 0;">
                  <label class="form-label"><i class="fa-solid fa-code-branch" style="color: var(--primary);"></i> Assigned Store Branch</label>
                  <div style="display: flex; gap: 0.4rem; align-items: center;">
                    <select id="prof-branch-code" class="form-control" style="max-width: 220px; font-weight: 700; font-family: monospace;">
                      ${(this.branches && this.branches.length > 0 ? this.branches : [{ branch_code: 'MAIN-01', name: 'Main Storefront' }]).map(b => `
                        <option value="${this.escapeHtml(b.branch_code)}" ${(b.branch_code || '').toUpperCase() === (this.branchCode || 'MAIN-01').toUpperCase() ? 'selected' : ''}>
                          ${this.escapeHtml(b.branch_code)} - ${this.escapeHtml(b.name)}
                        </option>
                      `).join('')}
                    </select>
                    <button type="button" class="btn btn-outline btn-sm" onclick="app.openBranchModal()" title="Manage Branches & Locations">
                      <i class="fa-solid fa-gear"></i> Manage
                    </button>
                  </div>
                  <small style="color: var(--slate-500); font-size: 0.75rem;">Physical branch assigned to this computer/device.</small>
                </div>
              ` : `
                <div class="form-group" style="margin-bottom: 0;">
                  <label class="form-label"><i class="fa-solid fa-shop" style="color: var(--slate-500);"></i> Branch Mode</label>
                  <div style="font-size: 0.85rem; color: var(--slate-600); padding: 0.45rem 0;">
                    <span class="badge badge-neutral"><i class="fa-solid fa-shop"></i> Solo Store Mode</span>
                    <span style="font-size: 0.75rem; color: var(--slate-500); margin-left: 0.5rem;">All transactions tied to primary location.</span>
                  </div>
                </div>
              `}
            </div>
          </div>
        </div>

        <!-- Live Receipt Preview -->
        <div class="panel">
          <div class="panel-header" style="display: flex; justify-content: space-between; align-items: center;">
            <h3><i class="fa-solid fa-receipt"></i> Live Receipt Preview</h3>
            <div style="display: flex; gap: 0.4rem; align-items: center;">
              <span id="prev-paper-badge" class="badge badge-outline" style="font-size: 0.68rem; font-weight: 700;">${(prof.receipt_paper_width || '80mm') === '58mm' ? '58mm Mobile Roll' : '80mm POS Roll'}</span>
              <span class="badge badge-success" style="font-size: 0.7rem;"><i class="fa-solid fa-bolt"></i> Real-time Sync</span>
            </div>
          </div>
          <div class="panel-body" style="background: var(--slate-100); display: flex; justify-content: center; overflow-x: auto;">
            <div id="live-receipt-preview-wrapper" class="receipt-wrapper ${(this.getReceiptTypographyStyles ? this.getReceiptTypographyStyles().classes : '')}" style="box-shadow: 0 4px 12px rgba(0,0,0,0.08); background: #ffffff; border-radius: 4px; ${(this.getReceiptTypographyStyles ? this.getReceiptTypographyStyles().cssText : '')}">
              <div class="receipt-header-center" style="text-align: center; margin-bottom: 0.35rem;">
                <img id="prev-receipt-logo" src="${this.escapeHtml(this.getStoreLogo())}" alt="Logo" class="receipt-logo" style="${this.shouldPrintReceiptLogo() ? 'display: block; margin: 0 auto 0.35rem;' : 'display: none;'} max-height: 48px;">
                <h3 id="prev-name" style="font-size: 1.05rem; font-weight: 800; margin: 0 0 0.15rem 0; color: #000;">${this.escapeHtml(prof.store_name || '')}</h3>
                <p id="prev-tagline" style="font-size: 0.74rem; margin: 0 0 0.15rem 0; color: #475569;">${this.escapeHtml(prof.tagline || '')}</p>
                <p id="prev-address" style="font-size: 0.72rem; margin: 0; color: #475569;">${this.escapeHtml(prof.address || '')}</p>
                <p style="font-size: 0.72rem; margin: 0.1rem 0 0 0; color: #475569;">Phone: <span id="prev-phone">${this.escapeHtml(prof.phone || '')}</span></p>
                <p id="prev-tax-header-line" style="font-size: 0.72rem; margin: 0.1rem 0 0 0; color: #475569; ${prof.show_tax_on_receipt !== 0 && prof.tax_number ? '' : 'display: none;'}">TIN: <span id="prev-tax">${this.escapeHtml(prof.tax_number || '')}</span></p>
                <div class="receipt-divider" style="border-top: 1px dashed #94a3b8; margin: 0.35rem 0;"></div>
                <p id="prev-header" style="font-size: 0.72rem; font-style: italic; margin: 0; color: #334155;">${this.escapeHtml(prof.receipt_header || '')}</p>
              </div>

              <div id="prev-meta-section" class="receipt-meta-block" style="font-size: 0.72rem; margin-bottom: 0.35rem; line-height: 1.35; color: #334155;">
                <div style="display: flex; justify-content: space-between; gap: 0.4rem;">
                  <span><strong>Rec #:</strong> REC-SAMPLE-001</span>
                  <span>${new Date().toISOString().slice(0, 10)} 10:30</span>
                </div>
                <div style="display: flex; justify-content: space-between; gap: 0.4rem;">
                  <span id="prev-cashier-line" style="${prof.show_cashier_on_receipt !== 0 ? '' : 'display: none;'}"><strong>Attendant:</strong> ${this.escapeHtml(this.currentUser?.full_name || 'Cashier 1')}</span>
                  <span><strong>Pay:</strong> CASH</span>
                </div>
              </div>

              <div class="receipt-divider" style="border-top: 1px dashed #94a3b8; margin: 0.35rem 0;"></div>

              <table class="receipt-table" style="width: 100%; border-collapse: collapse; font-size: 0.75rem; margin-bottom: 0.5rem;">
                <thead>
                  <tr style="border-bottom: 1px solid #cbd5e1;">
                    <th style="text-align: left; padding: 0.2rem 0;">Item</th>
                    <th style="text-align: center; width: 35px; padding: 0.2rem 0;">Qty</th>
                    <th style="text-align: right; padding: 0.2rem 0;">Total</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td style="padding: 0.25rem 0;">Sample Product A</td>
                    <td style="text-align: center;">2</td>
                    <td id="prev-item-price-1" style="text-align: right;">${this.escapeHtml(prof.currency_symbol || '$')}20.00</td>
                  </tr>
                  <tr>
                    <td style="padding: 0.25rem 0;">Sample Product B</td>
                    <td style="text-align: center;">1</td>
                    <td id="prev-item-price-2" style="text-align: right;">${this.escapeHtml(prof.currency_symbol || '$')}20.00</td>
                  </tr>
                </tbody>
              </table>

              <div class="receipt-divider" style="border-top: 1px dashed #94a3b8; margin: 0.5rem 0;"></div>

              <div style="font-size: 0.78rem; line-height: 1.6; color: #1e293b;">
                <div style="display: flex; justify-content: space-between;">
                  <span>Subtotal:</span>
                  <span id="prev-subtotal-display">${this.escapeHtml(prof.currency_symbol || '$')}40.00</span>
                </div>
                <div id="prev-tax-row" style="display: flex; justify-content: space-between; color: #64748b; font-size: 0.72rem; ${(prof.show_tax_on_receipt !== 0 && (prof.tax_rate || 0) > 0) ? '' : 'display: none;'}">
                  <span id="prev-tax-label">Tax / VAT (${prof.tax_rate || 0}%):</span>
                  <span id="prev-tax-display">+${this.escapeHtml(prof.currency_symbol || '$')}${((40 * (prof.tax_rate || 0)) / 100).toFixed(2)}</span>
                </div>
                <div class="receipt-divider" style="border-top: 1px dashed #000; margin: 0.35rem 0;"></div>
                <div style="display: flex; justify-content: space-between; font-weight: 800; font-size: 0.95rem; color: #000;">
                  <span>TOTAL:</span>
                  <span id="prev-total-display">${this.escapeHtml(prof.currency_symbol || '$')}${((40 + ((40 * (prof.tax_rate || 0)) / 100))).toFixed(2)}</span>
                </div>
              </div>

              <!-- Payment / MoMo Notice on Receipt -->
              <div id="prev-momo-notice" style="margin-top: 0.65rem; padding: 0.45rem 0.5rem; background: #f8fafc; border: 1px dashed #cbd5e1; border-radius: 3px; font-size: 0.7rem; text-align: center; color: #334155; ${prof.receipt_momo_note ? '' : 'display: none;'}">
                <i class="fa-solid fa-mobile-screen" style="color: #6366f1; margin-right: 3px;"></i> <span id="prev-momo-text">${this.escapeHtml(prof.receipt_momo_note || '')}</span>
              </div>

              <div class="receipt-divider" style="border-top: 1px dashed #94a3b8; margin: 0.65rem 0;"></div>

              <div style="text-align: center; font-size: 0.72rem; color: #475569; line-height: 1.4;">
                <p id="prev-footer" style="margin: 0;">${this.escapeHtml(prof.receipt_footer || '')}</p>
                <div style="font-size: 0.65rem; color: #94a3b8; margin-top: 0.4rem;">*** Thank You! Please Call Again ***</div>
              </div>
            </div>
          </div>
        </div>

        <!-- Hardware Thermal Printer & Cash Drawer Panel -->
        <div class="panel" style="grid-column: 1 / -1;">
          <div class="panel-header" style="display: flex; justify-content: space-between; align-items: center;">
            <h3><i class="fa-solid fa-print"></i> POS Hardware & ESC/POS Thermal Printing</h3>
            <span class="badge ${this.isPrinterConnected ? 'badge-success' : 'badge-slate'}" id="prof-printer-badge">
              <i class="fa-solid ${this.isPrinterConnected ? 'fa-plug-circle-check' : 'fa-plug-circle-xmark'}"></i>
              ${this.isPrinterConnected ? 'Hardware Thermal Online' : 'Standard Browser Print Fallback'}
            </span>
          </div>
          <div class="panel-body">
            <p style="color: var(--slate-600); font-size: 0.85rem; margin-bottom: 1.25rem;">
              Connect your USB or Serial ESC/POS 58mm/80mm thermal receipt printer (Epson, Xprinter, MUNBYN, Star) via the Web Serial API for instantaneous silent printing, automatic paper guillotine cutter, and RJ11/RJ12 cash drawer kick pulses.
            </p>

            <div style="display: flex; flex-wrap: wrap; gap: 0.75rem; align-items: center;">
              ${!this.isSerialSupported() ? `
                <div class="alert alert-warning" style="margin: 0; width: 100%;">
                  <i class="fa-solid fa-triangle-exclamation"></i> Web Serial API is not supported in this browser. Please use Google Chrome, Microsoft Edge, or Opera on Windows/macOS/Linux for direct USB thermal printing. Standard browser printing is used as fallback.
                </div>
              ` : `
                ${!this.isPrinterConnected ? `
                  <button type="button" class="btn btn-primary" onclick="app.connectThermalPrinter()">
                    <i class="fa-solid fa-plug"></i> Pair & Connect USB Thermal Printer
                  </button>
                ` : `
                  <button type="button" class="btn btn-secondary" onclick="app.testPrintThermal()">
                    <i class="fa-solid fa-print"></i> Print ESC/POS Test Slip
                  </button>
                  <button type="button" class="btn btn-secondary" onclick="app.kickCashDrawer()">
                    <i class="fa-solid fa-cash-register"></i> Kick Cash Drawer
                  </button>
                  <button type="button" class="btn btn-danger" onclick="app.disconnectThermalPrinter()">
                    <i class="fa-solid fa-power-off"></i> Disconnect Printer
                  </button>
                `}
              `}
            </div>
          </div>
        </div>
      </div>
    `;
  }

  applyReceiptPolicyTemplate(key) {
    const templates = {
      no_return: 'Goods received in good condition cannot be returned or refunded. Thank you for your understanding and patronage!',
      exchange_48h: 'Exchanges permitted within 48 hours in original condition with this receipt. No cash refunds. Store credit only.',
      appreciation: 'Thank you for shopping with us! We appreciate your business and look forward to serving you again soon.',
      warranty: 'Standard 7-day manufacturer defect replacement warranty with original packaging and invoice.'
    };
    const footerEl = document.getElementById('prof-receipt-footer');
    if (footerEl && templates[key]) {
      footerEl.value = templates[key];
      this.updateLiveReceiptPreview();
      this.showToast('Template policy applied to receipt footer!', 'info');
    }
  }

  bindProfileEvents() {
    const textInputs = [
      'prof-name', 'prof-tagline', 'prof-phone', 'prof-address', 'prof-tax',
      'prof-tax-rate', 'prof-currency-symbol', 'prof-receipt-header',
      'prof-receipt-footer', 'prof-receipt-momo'
    ];
    textInputs.forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        el.addEventListener('input', () => this.updateLiveReceiptPreview());
      }
    });

    const toggles = [
      'prof-print-logo-receipts', 'prof-show-tax-receipt', 'prof-show-cashier-receipt',
      'prof-receipt-paper-width', 'prof-receipt-font-family',
      'prof-receipt-font-size', 'prof-receipt-font-weight', 'prof-receipt-spacing'
    ];
    toggles.forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        el.addEventListener('change', () => this.updateLiveReceiptPreview());
      }
    });

    // Run preview update immediately on mount so live preview reflects active profile settings
    this.updateLiveReceiptPreview();
  }

  async saveProfileForm() {
    try {
      const termInput = document.getElementById('prof-terminal-id');
      const branchInput = document.getElementById('prof-branch-code');
      const terminalId = this.normalizeTerminalId(termInput ? termInput.value : this.terminalId);
      const branchCode = branchInput ? branchInput.value.trim().toUpperCase() || 'MAIN-01' : (this.branchCode || 'MAIN-01');

      this.terminalId = terminalId;
      this.branchCode = branchCode;
      localStorage.setItem('storeflow_terminal_id', terminalId);
      localStorage.setItem('storeflow_branch_code', branchCode);

      const termBadge = document.getElementById('topbar-terminal-badge');
      if (termBadge) {
        termBadge.innerHTML = `<i class="fa-solid fa-desktop"></i> ${this.escapeHtml(this.terminalId)}`;
      }
      const branchBadge = document.getElementById('topbar-branch-badge');
      if (branchBadge) {
        branchBadge.innerHTML = `<i class="fa-solid fa-store"></i> ${this.escapeHtml(this.branchCode)}`;
      }
      const drawerBranchBadge = document.getElementById('drawer-branch-badge');
      if (drawerBranchBadge) {
        drawerBranchBadge.innerHTML = `<i class="fa-solid fa-store"></i> ${this.escapeHtml(this.branchCode)}`;
      }

      const printLogoCheck = document.getElementById('prof-print-logo-receipts');
      const printLogoOnReceipts = printLogoCheck ? (printLogoCheck.checked ? 1 : 0) : 1;

      let logoUrl = (this.storeProfile && this.storeProfile.logo_url) || null;
      if (this.pendingCustomLogo !== undefined) {
        logoUrl = this.pendingCustomLogo || null;
      }

      const payload = {
        id: 1,
        store_name: document.getElementById('prof-name')?.value?.trim() || this.storeProfile?.store_name || 'My Store',
        tagline: document.getElementById('prof-tagline')?.value?.trim() ?? (this.storeProfile?.tagline || ''),
        phone: document.getElementById('prof-phone')?.value?.trim() ?? (this.storeProfile?.phone || ''),
        email: document.getElementById('prof-email')?.value?.trim() ?? (this.storeProfile?.email || ''),
        address: document.getElementById('prof-address')?.value?.trim() ?? (this.storeProfile?.address || ''),
        tax_number: document.getElementById('prof-tax')?.value?.trim() ?? (this.storeProfile?.tax_number || ''),
        tax_rate: parseFloat(document.getElementById('prof-tax-rate')?.value) || 0,
        currency_symbol: document.getElementById('prof-currency-symbol')?.value?.trim() || this.storeProfile?.currency_symbol || '$',
        currency_code: document.getElementById('prof-currency-code')?.value?.trim() || this.storeProfile?.currency_code || 'USD',
        receipt_header: document.getElementById('prof-receipt-header')?.value?.trim() ?? (this.storeProfile?.receipt_header || ''),
        receipt_footer: document.getElementById('prof-receipt-footer')?.value?.trim() ?? (this.storeProfile?.receipt_footer || ''),
        receipt_momo_note: document.getElementById('prof-receipt-momo')?.value?.trim() ?? (this.storeProfile?.receipt_momo_note || ''),
        receipt_font_size: document.getElementById('prof-receipt-font-size')?.value || this.storeProfile?.receipt_font_size || 'medium',
        receipt_font_weight: document.getElementById('prof-receipt-font-weight')?.value || this.storeProfile?.receipt_font_weight || 'normal',
        receipt_font_family: document.getElementById('prof-receipt-font-family')?.value || this.storeProfile?.receipt_font_family || 'monospace',
        receipt_paper_width: document.getElementById('prof-receipt-paper-width')?.value || this.storeProfile?.receipt_paper_width || '80mm',
        receipt_spacing: document.getElementById('prof-receipt-spacing')?.value || this.storeProfile?.receipt_spacing || 'ultra_compact',
        show_tax_on_receipt: document.getElementById('prof-show-tax-receipt')?.checked ? 1 : 0,
        show_cashier_on_receipt: document.getElementById('prof-show-cashier-receipt')?.checked ? 1 : 0,
        auto_backup_hours: parseInt(document.getElementById('prof-backup-hours')?.value, 10) || 2,
        allow_negative_stock: document.getElementById('prof-allow-negative-stock')?.checked ? 1 : 0,
        terminal_id: terminalId,
        branch_code: branchCode,
        is_multi_branch: this.isMultiBranch ? 1 : 0,
        logo_url: logoUrl,
        print_logo_on_receipts: printLogoOnReceipts,
        mnotify_api_key: document.getElementById('prof-mnotify-api-key')?.value?.trim() || undefined,
        mnotify_sender_id: document.getElementById('prof-mnotify-sender-id')?.value?.trim() || 'StoreFlow',
        mnotify_auto_sms: document.getElementById('prof-mnotify-auto-sms')?.checked ? 1 : 0,
        mnotify_owner_phone: document.getElementById('prof-mnotify-owner-phone')?.value?.trim() || '',
        mnotify_low_stock_alert: document.getElementById('prof-mnotify-low-stock')?.checked ? 1 : 0,
        mnotify_shift_close_alert: document.getElementById('prof-mnotify-shift-close')?.checked ? 1 : 0,
        estimate_validity_days: Math.max(1, parseInt(document.getElementById('prof-estimate-validity-days')?.value || 7, 10)),
        enable_line_discounts: document.getElementById('prof-enable-line-discounts')?.checked ? 1 : 0,
        operating_mode: (this.getOperatingMode ? this.getOperatingMode() : (this.operatingMode || 'RETAIL'))
      };

      this.storeProfile = { ...this.storeProfile, ...payload, id: 1 };
      localStorage.setItem('storeflow_store_profile', JSON.stringify(this.storeProfile));

      try {
        await localDB.store_profile.put(this.storeProfile);
      } catch (dbErr) {
        console.warn('LocalDB store_profile put notice:', dbErr);
      }

      this.updateStoreBrandUI();
      this.updateUserUI();

      if (this.isOnline) {
        try {
          await this.apiFetch('api/endpoints/profile.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
          });
        } catch (e) {
          console.warn('Profile sync deferred');
        }
      }

      this.renderCurrentView();
      this.showToast('Store profile & workstation settings saved! Changes will appear on future receipts and shifts.', 'success');
    } catch (err) {
      console.error('Failed to save store profile:', err);
      this.showToast('Error saving profile: ' + (err.message || 'Please check form fields and retry.'), 'error');
    }
  }

  handleLogoFileSelect(event) {
    const file = event.target.files && event.target.files[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      this.showToast('Please choose an image file under 2MB.', 'warning');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const rawDataUrl = e.target.result;
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxDim = 256;
        let w = img.width;
        let h = img.height;
        if (w > h) {
          if (w > maxDim) {
            h = Math.round((h * maxDim) / w);
            w = maxDim;
          }
        } else {
          if (h > maxDim) {
            w = Math.round((w * maxDim) / h);
            h = maxDim;
          }
        }
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, w, h);
        const optimizedDataUrl = canvas.toDataURL('image/png');

        this.pendingCustomLogo = optimizedDataUrl;
        const previewImg = document.getElementById('prof-logo-preview');
        if (previewImg) previewImg.src = optimizedDataUrl;
        const prevReceiptLogo = document.getElementById('prev-receipt-logo');
        if (prevReceiptLogo) prevReceiptLogo.src = optimizedDataUrl;
        const statusBadge = document.getElementById('prof-logo-status-badge');
        if (statusBadge) {
          statusBadge.className = 'badge badge-success';
          statusBadge.innerHTML = '<i class="fa-solid fa-circle-check"></i> Custom Logo Ready (Save to Apply)';
        }
        this.showToast('Custom logo loaded! Click "Save Profile" to apply across the app.', 'info');
      };
      img.src = rawDataUrl;
    };
    reader.readAsDataURL(file);
  }

  removeCustomLogo() {
    this.pendingCustomLogo = '';
    this.storeProfile.logo_url = null;
    const previewImg = document.getElementById('prof-logo-preview');
    if (previewImg) previewImg.src = 'assets/icons/icon-192.png';
    const prevReceiptLogo = document.getElementById('prev-receipt-logo');
    if (prevReceiptLogo) prevReceiptLogo.src = 'assets/icons/icon-192.png';
    const statusBadge = document.getElementById('prof-logo-status-badge');
    if (statusBadge) {
      statusBadge.className = 'badge badge-slate';
      statusBadge.innerText = 'StoreFlow Default (Fallback)';
    }
    this.showToast('Reset to StoreFlow default icon. Click "Save Profile" to save changes.', 'info');
  }

  updateLiveReceiptPreview() {
    const sym = document.getElementById('prof-currency-symbol')?.value || '$';
    const taxRate = parseFloat(document.getElementById('prof-tax-rate')?.value) || 0;
    const showTax = document.getElementById('prof-show-tax-receipt') ? document.getElementById('prof-show-tax-receipt').checked : true;
    const showCashier = document.getElementById('prof-show-cashier-receipt') ? document.getElementById('prof-show-cashier-receipt').checked : true;
    const printLogoCheck = document.getElementById('prof-print-logo-receipts');
    const momoNote = document.getElementById('prof-receipt-momo')?.value.trim() || '';
    const taxNumber = document.getElementById('prof-tax')?.value.trim() || '';

    // 0. Live Typography & Paper Roll Styling
    const previewWrapper = document.getElementById('live-receipt-preview-wrapper');
    const paperWidth = document.getElementById('prof-receipt-paper-width')?.value || this.storeProfile.receipt_paper_width || '80mm';
    const fontFamily = document.getElementById('prof-receipt-font-family')?.value || this.storeProfile.receipt_font_family || 'monospace';
    const fontSize = document.getElementById('prof-receipt-font-size')?.value || this.storeProfile.receipt_font_size || 'medium';
    const fontWeight = document.getElementById('prof-receipt-font-weight')?.value || this.storeProfile.receipt_font_weight || 'normal';
    const spacing = document.getElementById('prof-receipt-spacing')?.value || this.storeProfile.receipt_spacing || 'ultra_compact';

    if (previewWrapper) {
      if (paperWidth === '58mm') {
        previewWrapper.style.maxWidth = '230px';
      } else {
        previewWrapper.style.maxWidth = '320px';
      }

      if (spacing === 'ultra_compact') {
        previewWrapper.style.padding = paperWidth === '58mm' ? '0.65rem 0.5rem' : '0.85rem 0.75rem';
        previewWrapper.style.lineHeight = '1.18';
      } else if (spacing === 'compact') {
        previewWrapper.style.padding = paperWidth === '58mm' ? '0.85rem 0.6rem' : '1.05rem 0.85rem';
        previewWrapper.style.lineHeight = '1.28';
      } else {
        previewWrapper.style.padding = paperWidth === '58mm' ? '1rem 0.65rem' : '1.25rem 1rem';
        previewWrapper.style.lineHeight = '1.45';
      }

      const fontFamilies = {
        'monospace': "'Courier New', Courier, monospace",
        'sans': "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
        'retro': "'Lucida Console', Monaco, 'Courier New', monospace",
        'condensed': "'Roboto Mono', Consolas, 'Courier New', monospace"
      };
      previewWrapper.style.fontFamily = fontFamilies[fontFamily] || fontFamilies.monospace;

      const fontSizes = {
        'compact': '0.70rem',
        'medium': '0.78rem',
        'large': '0.88rem'
      };
      previewWrapper.style.fontSize = fontSizes[fontSize] || '0.78rem';

      const fontWeights = {
        'normal': '400',
        'medium': '600',
        'bold': '700'
      };
      previewWrapper.style.fontWeight = fontWeights[fontWeight] || '400';

      previewWrapper.className = `receipt-wrapper receipt-roll-${paperWidth} receipt-font-${fontSize} receipt-weight-${fontWeight} receipt-spacing-${spacing}`;
    }

    const paperBadge = document.getElementById('prev-paper-badge');
    if (paperBadge) {
      paperBadge.innerText = paperWidth === '58mm' ? '58mm Mobile Roll' : '80mm POS Roll';
    }

    // 1. Live text mirroring for header, address, phone, TIN, footer
    const map = {
      'prof-name': 'prev-name',
      'prof-tagline': 'prev-tagline',
      'prof-address': 'prev-address',
      'prof-phone': 'prev-phone',
      'prof-tax': 'prev-tax',
      'prof-receipt-header': 'prev-header',
      'prof-receipt-footer': 'prev-footer'
    };
    for (const [inputId, prevId] of Object.entries(map)) {
      const inp = document.getElementById(inputId);
      const prev = document.getElementById(prevId);
      if (inp && prev) prev.innerText = inp.value;
    }

    // 2. Pricing & Currency
    const p1 = document.getElementById('prev-item-price-1');
    const p2 = document.getElementById('prev-item-price-2');
    if (p1) p1.innerText = `${sym}20.00`;
    if (p2) p2.innerText = `${sym}20.00`;

    const subtotal = 40.00;
    const subtotalEl = document.getElementById('prev-subtotal-display');
    if (subtotalEl) subtotalEl.innerText = `${sym}${subtotal.toFixed(2)}`;

    // 3. Tax calculation & visibility
    const taxAmt = (showTax && taxRate > 0) ? (subtotal * (taxRate / 100)) : 0;
    const totalAmt = subtotal + taxAmt;

    const taxRow = document.getElementById('prev-tax-row');
    const taxLabel = document.getElementById('prev-tax-label');
    const taxDisplay = document.getElementById('prev-tax-display');
    if (taxRow) {
      if (showTax && taxRate > 0) {
        taxRow.style.display = 'flex';
        if (taxLabel) taxLabel.innerText = `Tax / VAT (${taxRate}%):`;
        if (taxDisplay) taxDisplay.innerText = `+${sym}${taxAmt.toFixed(2)}`;
      } else {
        taxRow.style.display = 'none';
      }
    }

    const taxHeaderLine = document.getElementById('prev-tax-header-line');
    if (taxHeaderLine) {
      taxHeaderLine.style.display = (showTax && taxNumber) ? 'block' : 'none';
    }

    const totalEl = document.getElementById('prev-total-display');
    if (totalEl) totalEl.innerText = `${sym}${totalAmt.toFixed(2)}`;

    // 4. MoMo / Bank Note
    const momoBox = document.getElementById('prev-momo-notice');
    const momoText = document.getElementById('prev-momo-text');
    if (momoBox) {
      momoBox.style.display = momoNote ? 'block' : 'none';
      if (momoText) momoText.innerText = momoNote;
    }

    // 5. Logo & Cashier line
    const prevReceiptLogo = document.getElementById('prev-receipt-logo');
    if (prevReceiptLogo && printLogoCheck) {
      prevReceiptLogo.style.display = printLogoCheck.checked ? 'block' : 'none';
    }

    const cashierLine = document.getElementById('prev-cashier-line');
    if (cashierLine) {
      cashierLine.style.display = showCashier ? 'block' : 'none';
    }

    // 6. Dynamic Metadata formatting (Paired 2-col vs Stacked)
    const metaSection = document.getElementById('prev-meta-section');
    if (metaSection) {
      if (spacing === 'standard') {
        metaSection.innerHTML = `
          <div><strong>Receipt #:</strong> REC-SAMPLE-001</div>
          <div><strong>Date:</strong> ${new Date().toISOString().slice(0, 10)} 10:30 AM</div>
          <div id="prev-cashier-line" style="${showCashier ? '' : 'display: none;'}"><strong>Attendant:</strong> ${this.escapeHtml(this.currentUser?.full_name || 'Cashier 1')} · <span id="prev-terminal-display">${this.escapeHtml(this.terminalId || 'REG-01')}</span></div>
          <div><strong>Customer:</strong> Sample Buyer (Walk-in)</div>
        `;
      } else {
        metaSection.innerHTML = `
          <div style="display: flex; justify-content: space-between; gap: 0.4rem;">
            <span><strong>Rec #:</strong> REC-SAMPLE-001</span>
            <span>${new Date().toISOString().slice(0, 10)} 10:30</span>
          </div>
          <div style="display: flex; justify-content: space-between; gap: 0.4rem;">
            <span id="prev-cashier-line" style="${showCashier ? '' : 'display: none;'}"><strong>Attendant:</strong> ${this.escapeHtml(this.currentUser?.full_name || 'Cashier 1')}</span>
            <span><strong>Pay:</strong> CASH</span>
          </div>
        `;
      }
    }
  }

  async toggleMultiBranchMode(enabled) {
    this.isMultiBranch = !!enabled;
    this.storeProfile = { ...this.storeProfile, is_multi_branch: this.isMultiBranch ? 1 : 0, id: 1 };
    await localDB.store_profile.put(this.storeProfile);

    if (this.isOnline) {
      try {
        await this.apiFetch('api/endpoints/profile.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(this.storeProfile)
        });
      } catch (e) {
        console.warn('Failed to sync multi-branch toggle');
      }
    }

    this.updateUserUI();
    this.renderCurrentView();
    this.showToast(
      this.isMultiBranch
        ? 'Multi-Branch Enterprise Mode activated! Branch directory and filters enabled.'
        : 'Solo Store Mode activated! Single-store view restored.',
      'info'
    );
  }

  handleCurrencySelect(val) {
    if (val === 'CUSTOM||') {
      const symInput = document.getElementById('prof-currency-symbol');
      if (symInput) symInput.focus();
      return;
    }
    const parts = val.split('|');
    const code = parts[0] || 'USD';
    const symbol = parts[1] || '$';

    const symInput = document.getElementById('prof-currency-symbol');
    const codeInput = document.getElementById('prof-currency-code');
    if (symInput) symInput.value = symbol;
    if (codeInput) codeInput.value = code;

    this.updateLiveReceiptPreview();
  }


  // --- Branch Directory & Multi-Store Management ---

  async openBranchModal() {
    const modal = document.getElementById('branch-management-modal');
    if (!modal) return;

    if (this.isOnline) {
      await this.fetchBranches();
    }
    this.renderBranchTableRows();
    modal.classList.add('active');
  }

  closeBranchModal() {
    const modal = document.getElementById('branch-management-modal');
    if (modal) modal.classList.remove('active');
  }

  renderBranchTableRows() {
    const tbody = document.getElementById('branch-table-body');
    if (!tbody) return;

    if (!this.branches || this.branches.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="7" style="text-align: center; padding: 2.5rem; color: var(--slate-400);">
            <i class="fa-solid fa-code-branch" style="font-size: 2rem; margin-bottom: 0.5rem; display: block;"></i>
            No branches registered yet. Add your first branch location above.
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML = this.branches.map(b => {
      const isActive = Number(b.is_active) === 1;
      const salesCount = b.total_sales_count || 0;
      const revenue = Number(b.total_revenue || 0);

      return `
        <tr style="${!isActive ? 'opacity: 0.6; background: var(--slate-50);' : ''}">
          <td style="font-weight: 700; font-family: monospace;">${this.escapeHtml(b.branch_code)}</td>
          <td style="font-weight: 600;">${this.escapeHtml(b.name)}</td>
          <td style="font-size: 0.82rem; color: var(--slate-600);">${this.escapeHtml(b.address || '—')}</td>
          <td style="font-size: 0.82rem;">${this.escapeHtml(b.manager_name || '—')} <span style="color: var(--slate-400);">(${this.escapeHtml(b.phone || 'N/A')})</span></td>
          <td style="text-align: right; font-weight: 700;">${salesCount > 0 ? `${salesCount} sales (${this.formatCurrency(revenue)})` : '0 sales'}</td>
          <td style="text-align: center;">
            <span class="badge ${isActive ? 'badge-success' : 'badge-slate'}">
              ${isActive ? 'Active' : 'Disabled'}
            </span>
          </td>
          <td style="text-align: right;">
            <div style="display: flex; gap: 0.35rem; justify-content: flex-end;">
              <button class="btn btn-outline btn-sm" onclick="app.openBranchFormModal(${this.jsStr(b.id)})" title="Edit Branch">
                <i class="fa-solid fa-pen-to-square"></i>
              </button>
              <button class="btn btn-outline btn-sm" onclick="app.toggleBranchStatus(${this.jsStr(b.id)})" title="${isActive ? 'Deactivate Branch' : 'Activate Branch'}">
                <i class="fa-solid ${isActive ? 'fa-ban' : 'fa-check'}"></i>
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
    this.applyMobileTableLabels(tbody.closest('table') || tbody);
  }

  openBranchFormModal(branchId = null) {
    const modal = document.getElementById('branch-form-modal');
    const titleEl = document.getElementById('branch-form-title');
    const idInput = document.getElementById('branch-id');
    const codeInput = document.getElementById('branch-code-input');
    const nameInput = document.getElementById('branch-name-input');
    const addressInput = document.getElementById('branch-address-input');
    const phoneInput = document.getElementById('branch-phone-input');
    const managerInput = document.getElementById('branch-manager-input');
    const statusGroup = document.getElementById('branch-status-group');
    const activeInput = document.getElementById('branch-active-input');

    if (!modal) return;

    if (branchId) {
      const branch = (this.branches || []).find(b => b.id === branchId);
      if (branch) {
        if (titleEl) titleEl.innerHTML = '<i class="fa-solid fa-pen-to-square"></i> Edit Store Branch';
        if (idInput) idInput.value = branch.id;
        if (codeInput) { codeInput.value = branch.branch_code; codeInput.readOnly = false; }
        if (nameInput) nameInput.value = branch.name;
        if (addressInput) addressInput.value = branch.address || '';
        if (phoneInput) phoneInput.value = branch.phone || '';
        if (managerInput) managerInput.value = branch.manager_name || '';
        if (statusGroup) statusGroup.style.display = 'block';
        if (activeInput) activeInput.checked = Number(branch.is_active) === 1;
      }
    } else {
      if (titleEl) titleEl.innerHTML = '<i class="fa-solid fa-store"></i> Register Store Branch';
      if (idInput) idInput.value = '';
      if (codeInput) { codeInput.value = ''; codeInput.readOnly = false; }
      if (nameInput) nameInput.value = '';
      if (addressInput) addressInput.value = '';
      if (phoneInput) phoneInput.value = '';
      if (managerInput) managerInput.value = '';
      if (statusGroup) statusGroup.style.display = 'none';
      if (activeInput) activeInput.checked = true;
    }

    modal.classList.add('active');
  }

  closeBranchFormModal() {
    const modal = document.getElementById('branch-form-modal');
    if (modal) modal.classList.remove('active');
  }

  async saveBranchForm() {
    const id = document.getElementById('branch-id')?.value.trim();
    const branchCode = document.getElementById('branch-code-input')?.value.trim().toUpperCase();
    const name = document.getElementById('branch-name-input')?.value.trim();
    const address = document.getElementById('branch-address-input')?.value.trim();
    const phone = document.getElementById('branch-phone-input')?.value.trim();
    const managerName = document.getElementById('branch-manager-input')?.value.trim();
    const isActive = document.getElementById('branch-active-input')?.checked ? 1 : 0;

    if (!branchCode || !name) {
      this.showToast('Branch code and branch name are required.', 'warning');
      return;
    }

    const payload = {
      id: id || undefined,
      branch_code: branchCode,
      name,
      address,
      phone,
      manager_name: managerName,
      is_active: isActive
    };

    if (!this.isOnline) {
      this.showToast('You must be online to register or update store branches.', 'warning');
      return;
    }

    try {
      const res = await this.apiFetch('api/endpoints/branches.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data.success) {
        await this.fetchBranches();
        this.renderBranchTableRows();
        this.closeBranchFormModal();
        this.renderCurrentView();
        this.showToast(data.message || 'Branch saved successfully!', 'success');
      } else {
        this.showToast(data.message || 'Failed to save branch.', 'danger');
      }
    } catch (e) {
      this.showToast('Network error while saving branch: ' + e.message, 'danger');
    }
  }

  async toggleBranchStatus(branchId) {
    if (!this.isOnline) {
      this.showToast('Online connection required to toggle branch status.', 'warning');
      return;
    }

    try {
      const res = await this.apiFetch('api/endpoints/branches.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'toggle_status', id: branchId })
      });
      const data = await res.json();
      if (data.success) {
        await this.fetchBranches();
        this.renderBranchTableRows();
        this.renderCurrentView();
        this.showToast(data.message, 'success');
      } else {
        this.showToast(data.message, 'warning');
      }
    } catch (e) {
      this.showToast('Failed to update branch status: ' + e.message, 'danger');
    }
  }

  // --- Activity & Audit Logs ---

  async fetchActivityLogs(filterType = 'ALL') {
    if (this.isOnline) {
      try {
        const url = filterType && filterType !== 'ALL'
          ? `api/endpoints/activity_logs.php?action_type=${encodeURIComponent(filterType)}&limit=250`
          : 'api/endpoints/activity_logs.php?limit=250';
        const res = await this.apiFetch(url);
        const data = await res.json();
        if (data.success && data.logs) {
          this.activityLogs = data.logs;
          try {
            if (typeof localDB !== 'undefined' && localDB.activity_logs) {
              await localDB.activity_logs.bulkPut(this.activityLogs);
            }
          } catch (e) { }
        }
      } catch (err) {
        console.warn('Could not fetch server logs; falling back to local database.');
        try {
          if (typeof localDB !== 'undefined' && localDB.activity_logs) {
            this.activityLogs = await localDB.activity_logs.reverse().sortBy('created_at');
          }
        } catch (e) {
          this.activityLogs = [];
        }
      }
    } else {
      try {
        if (typeof localDB !== 'undefined' && localDB.activity_logs) {
          this.activityLogs = await localDB.activity_logs.reverse().sortBy('created_at');
        }
      } catch (e) {
        this.activityLogs = [];
      }
    }
  }

  async logClientActivity(actionType, details, sendToServer = true) {
    const user = this.currentUser || { id: 1, full_name: 'Store Administrator', role_name: 'Administrator' };
    const logItem = {
      id: 'log_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
      user_id: user.id || 1,
      user_name: user.full_name || user.username || 'Staff',
      role_name: user.role_name || 'Staff',
      action_type: actionType,
      details: details,
      ip_address: this.isOnline ? 'Client Web App' : 'Offline Client Mode',
      created_at: new Date().toISOString().slice(0, 19).replace('T', ' ')
    };

    if (!Array.isArray(this.activityLogs)) this.activityLogs = [];
    this.activityLogs.unshift(logItem);
    try {
      if (typeof localDB !== 'undefined' && localDB.activity_logs) {
        await localDB.activity_logs.put(logItem);
      }
    } catch (e) { }

    if (sendToServer) {
      if (this.isOnline) {
        try {
          await this.apiFetch('api/endpoints/activity_logs.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(logItem)
          });
        } catch (e) {
          if (typeof localDB !== 'undefined' && localDB.sync_outbox) {
            try {
              await localDB.sync_outbox.add({
                entity: 'activity_log',
                action: 'CREATE',
                data: logItem,
                timestamp: new Date().toISOString(),
                synced: 0
              });
            } catch (syncErr) { }
          }
        }
      } else {
        if (typeof localDB !== 'undefined' && localDB.sync_outbox) {
          try {
            await localDB.sync_outbox.add({
              entity: 'activity_log',
              action: 'CREATE',
              data: logItem,
              timestamp: new Date().toISOString(),
              synced: 0
            });
          } catch (syncErr) { }
        }
      }
    }
  }

  activityLogsActionFilter = 'ALL';
  activityLogsStaffFilter = 'ALL';
  activityLogsSearchQuery = '';

  setActivityLogsActionFilter(val) {
    this.activityLogsActionFilter = val || 'ALL';
    this.renderCurrentView();
  }

  setActivityLogsStaffFilter(val) {
    this.activityLogsStaffFilter = val || 'ALL';
    this.renderCurrentView();
  }

  setActivityLogsSearchQuery(val) {
    this.activityLogsSearchQuery = (val || '').trim();
    const q = this.activityLogsSearchQuery.toLowerCase();
    const rows = document.querySelectorAll('#activity-logs-table-body tr[data-action]');
    let visibleCount = 0;
    rows.forEach(r => {
      const text = (r.textContent || '').toLowerCase();
      const matches = !q || text.includes(q);
      r.classList.toggle('row-hidden', !matches);
      r.hidden = !matches;
      r.style.setProperty('display', matches ? '' : 'none', 'important');
      if (matches) visibleCount++;
    });
    const statShowing = document.getElementById('activity-logs-stat-showing');
    if (statShowing) statShowing.innerText = visibleCount;
  }

  resetActivityLogsFilters() {
    this.activityLogsActionFilter = 'ALL';
    this.activityLogsStaffFilter = 'ALL';
    this.activityLogsSearchQuery = '';
    this.renderCurrentView();
  }

  getFilteredActivityLogsList() {
    const list = this.activityLogs || [];
    const actionCategory = this.activityLogsActionFilter || 'ALL';
    const selectedStaff = this.activityLogsStaffFilter || 'ALL';
    const q = (this.activityLogsSearchQuery || '').toLowerCase().trim();

    return list.filter(l => {
      const action = (l.action_type || 'GENERAL').toUpperCase();
      const staff = (l.user_name || '').trim();
      const role = (l.role_name || '').trim();
      const details = (l.details || '').trim();
      const ip = (l.ip_address || '').trim();
      const time = (l.created_at || '').trim();

      // 1. Action Category Filter
      if (actionCategory !== 'ALL') {
        if (actionCategory === 'SALE') {
          if (!action.includes('SALE')) return false;
        } else if (actionCategory === 'PAYMENT') {
          if (!action.includes('PAYMENT') && !action.includes('DEBT')) return false;
        } else if (actionCategory === 'EXPENSE') {
          if (!action.includes('EXPENSE')) return false;
        } else if (actionCategory === 'RETURN') {
          if (!action.includes('RETURN')) return false;
        } else if (actionCategory === 'STOCK') {
          if (!action.includes('STOCK') && !action.includes('AUDIT') && !action.includes('WRITEOFF') && !action.includes('BATCH')) return false;
        } else if (actionCategory === 'PRODUCT') {
          if (!action.includes('PRODUCT')) return false;
        } else if (actionCategory === 'TRANSFER') {
          if (!action.includes('TRANSFER')) return false;
        } else if (actionCategory === 'SHIFT') {
          if (!action.includes('SHIFT')) return false;
        } else if (actionCategory === 'LOGIN') {
          if (!action.includes('LOGIN') && !action.includes('LOGOUT') && !action.includes('UNLOCK')) return false;
        } else if (actionCategory === 'USER') {
          if (!action.includes('USER')) return false;
        } else if (actionCategory === 'PURCHASE') {
          if (!action.includes('PURCHASE') && !action.includes('VENDOR')) return false;
        } else if (actionCategory === 'SYSTEM') {
          if (!action.includes('SETTINGS') && !action.includes('LICENSE') && !action.includes('BACKUP')) return false;
        } else {
          if (!action.includes(actionCategory)) return false;
        }
      }

      // 2. Staff Member Filter
      if (selectedStaff !== 'ALL' && staff !== selectedStaff) {
        return false;
      }

      // 3. Search Query Filter
      if (q) {
        const combined = `${time} ${staff} ${role} ${action} ${details} ${ip}`.toLowerCase();
        if (!combined.includes(q)) return false;
      }

      return true;
    });
  }

  async refreshActivityLogs() {
    await this.fetchActivityLogs();
    this.renderCurrentView();
    this.showToast('Activity logs refreshed.', 'info');
  }

  exportActivityLogsCSV() {
    const logsToExport = this.getFilteredActivityLogsList();
    if (!logsToExport || logsToExport.length === 0) {
      this.showToast('No activity logs match criteria to export.', 'warning');
      return;
    }

    const headers = ['ID', 'Date & Time', 'Staff Member', 'Role', 'Action Type', 'Details', 'IP / Terminal'];
    const rows = logsToExport.map(l => [
      `"${l.id || ''}"`,
      `"${l.created_at || ''}"`,
      `"${(l.user_name || '').replace(/"/g, '""')}"`,
      `"${(l.role_name || '').replace(/"/g, '""')}"`,
      `"${l.action_type || ''}"`,
      `"${(l.details || '').replace(/"/g, '""')}"`,
      `"${l.ip_address || ''}"`
    ]);

    const csvContent = [headers.join(','), ...rows.map(e => e.join(','))].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `StoreFlow_Activity_Logs_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    this.showToast(`Exported ${logsToExport.length} activity records to CSV.`, 'success');
  }

  getActivityLogsHTML() {
    this.activityLogsActionFilter = this.activityLogsActionFilter || 'ALL';
    this.activityLogsStaffFilter = this.activityLogsStaffFilter || 'ALL';
    this.activityLogsSearchQuery = this.activityLogsSearchQuery || '';

    const allLogs = this.activityLogs || [];
    const filteredLogs = this.getFilteredActivityLogsList();
    const hasActiveFilter = (this.activityLogsActionFilter !== 'ALL' || this.activityLogsStaffFilter !== 'ALL' || this.activityLogsSearchQuery !== '');

    const totalLogs = allLogs.length;
    const loginCount = allLogs.filter(l => {
      const act = l.action_type || '';
      return act.includes('LOGIN') || act.includes('LOGOUT') || act.includes('UNLOCK');
    }).length;
    const salesCount = allLogs.filter(l => {
      const act = l.action_type || '';
      return act.includes('SALE') || act.includes('PAYMENT') || act.includes('RETURN') || act.includes('EXPENSE');
    }).length;
    const catalogCount = allLogs.filter(l => {
      const act = l.action_type || '';
      return act.includes('PRODUCT') || act.includes('STOCK') || act.includes('AUDIT') || act.includes('BATCH') || act.includes('TRANSFER') || act.includes('PURCHASE');
    }).length;

    const staffNames = Array.from(new Set(allLogs.map(l => l.user_name).filter(Boolean)));

    return `
      <!-- Activity Logs KPI Stat Overview -->
      <div class="panel" style="margin-bottom: 1.5rem;">
        <div class="panel-body" style="display: flex; gap: 2.5rem; flex-wrap: wrap;">
          <div>
            <span style="font-size: 0.8rem; color: var(--slate-500); text-transform: uppercase; font-weight: 600;">
              <i class="fa-solid fa-list-check"></i> Total Audit Entries
            </span>
            <p style="font-size: 1.4rem; font-weight: 700; color: var(--slate-900);">${totalLogs}</p>
          </div>
          <div>
            <span style="font-size: 0.8rem; color: var(--slate-500); text-transform: uppercase; font-weight: 600;">
              <i class="fa-solid fa-user-shield"></i> Security & Sign-ins
            </span>
            <p style="font-size: 1.4rem; font-weight: 700; color: var(--primary);">${loginCount}</p>
          </div>
          <div>
            <span style="font-size: 0.8rem; color: var(--slate-500); text-transform: uppercase; font-weight: 600;">
              <i class="fa-solid fa-cash-register"></i> Sales, Payments & Cash Flow
            </span>
            <p style="font-size: 1.4rem; font-weight: 700; color: var(--success);">${salesCount}</p>
          </div>
          <div>
            <span style="font-size: 0.8rem; color: var(--slate-500); text-transform: uppercase; font-weight: 600;">
              <i class="fa-solid fa-boxes-stacked"></i> Catalog, Stock & Audits
            </span>
            <p style="font-size: 1.4rem; font-weight: 700; color: var(--warning);">${catalogCount}</p>
          </div>
        </div>
      </div>

      <!-- Main Logs Panel -->
      <div class="panel">
        <div class="panel-header" style="flex-wrap: wrap; gap: 0.75rem;">
          <div>
            <h3><i class="fa-solid fa-clock-rotate-left"></i> System Activity & Audit Trail</h3>
            <p style="font-size: 0.8rem; color: var(--slate-500); margin: 0.2rem 0 0 0;">
              Real-time audit log of staff actions, security events, catalog modifications, inventory reconciliations, and financial receipts.
            </p>
          </div>
          <div style="display: flex; gap: 0.5rem;">
            <button class="btn btn-outline btn-sm" onclick="app.refreshActivityLogs()">
              <i class="fa-solid fa-arrows-rotate"></i> Refresh
            </button>
            <button class="btn btn-outline btn-sm" onclick="app.exportActivityLogsCSV()">
              <i class="fa-solid fa-file-csv"></i> Export CSV
            </button>
          </div>
        </div>

        <div class="panel-body">
          <!-- Filters Bar -->
          <div style="display: flex; gap: 0.75rem; margin-bottom: 1.25rem; flex-wrap: wrap; align-items: center; background: var(--slate-50); padding: 0.85rem; border-radius: var(--radius-md); border: 1px solid var(--slate-200);">
            <div style="position: relative; flex: 1; min-width: 220px;">
              <input type="text" id="logs-search-input" class="form-control" placeholder="Search actions, notes, cashier, IP..." value="${this.escapeHtml(this.activityLogsSearchQuery)}" oninput="app.setActivityLogsSearchQuery(this.value)" style="padding-left: 2rem;">
              <i class="fa-solid fa-magnifying-glass" style="position: absolute; left: 0.75rem; top: 50%; transform: translateY(-50%); color: var(--slate-400); font-size: 0.85rem;"></i>
            </div>

            <select id="logs-action-filter" class="form-control" style="width: auto; min-width: 190px;" onchange="app.setActivityLogsActionFilter(this.value)">
              <option value="ALL" ${this.activityLogsActionFilter === 'ALL' ? 'selected' : ''}>All Action Categories</option>
              <option value="SALE" ${this.activityLogsActionFilter === 'SALE' ? 'selected' : ''}>POS Sales & Sync</option>
              <option value="PAYMENT" ${this.activityLogsActionFilter === 'PAYMENT' ? 'selected' : ''}>Debt Payments</option>
              <option value="EXPENSE" ${this.activityLogsActionFilter === 'EXPENSE' ? 'selected' : ''}>Expenses & Cash Payouts</option>
              <option value="RETURN" ${this.activityLogsActionFilter === 'RETURN' ? 'selected' : ''}>Customer Returns & Refunds</option>
              <option value="STOCK" ${this.activityLogsActionFilter === 'STOCK' ? 'selected' : ''}>Stock Adjustments & Audits</option>
              <option value="PRODUCT" ${this.activityLogsActionFilter === 'PRODUCT' ? 'selected' : ''}>Product Catalog Events</option>
              <option value="TRANSFER" ${this.activityLogsActionFilter === 'TRANSFER' ? 'selected' : ''}>Inter-Branch Transfers</option>
              <option value="SHIFT" ${this.activityLogsActionFilter === 'SHIFT' ? 'selected' : ''}>Register Shifts & Z-Reports</option>
              <option value="LOGIN" ${this.activityLogsActionFilter === 'LOGIN' ? 'selected' : ''}>Sign-in & Terminal Security</option>
              <option value="USER" ${this.activityLogsActionFilter === 'USER' ? 'selected' : ''}>Staff Accounts</option>
              <option value="PURCHASE" ${this.activityLogsActionFilter === 'PURCHASE' ? 'selected' : ''}>Purchases & Suppliers</option>
              <option value="SYSTEM" ${this.activityLogsActionFilter === 'SYSTEM' ? 'selected' : ''}>Settings, License & Backups</option>
            </select>

            <select id="logs-staff-filter" class="form-control" style="width: auto; min-width: 170px;" onchange="app.setActivityLogsStaffFilter(this.value)">
              <option value="ALL" ${this.activityLogsStaffFilter === 'ALL' ? 'selected' : ''}>All Staff Members</option>
              ${staffNames.map(name => `<option value="${this.escapeHtml(name)}" ${this.activityLogsStaffFilter === name ? 'selected' : ''}>${this.escapeHtml(name)}</option>`).join('')}
            </select>

            ${hasActiveFilter ? `
              <button type="button" class="btn btn-outline btn-sm" onclick="app.resetActivityLogsFilters()" style="padding: 0.5rem 0.85rem; color: #dc2626; border-color: #fecaca; background: #fff5f5; font-weight: 600;" title="Reset all filters">
                <i class="fa-solid fa-rotate-left"></i> Reset
              </button>
            ` : ''}

            <span style="font-size: 0.8rem; color: var(--slate-500); margin-left: auto;">
              Showing <strong id="activity-logs-stat-showing" style="color: var(--slate-800);">${filteredLogs.length}</strong> of ${totalLogs} entries
            </span>
          </div>

          <!-- Logs Table -->
          <div class="table-responsive">
            <table class="data-table" id="activity-logs-table">
              <thead>
                <tr>
                  <th style="min-width: 140px;">Timestamp</th>
                  <th style="min-width: 160px;">Staff Member</th>
                  <th style="min-width: 150px;">Action</th>
                  <th>Audit Note & Details</th>
                  <th style="min-width: 130px;">Terminal / Source</th>
                </tr>
              </thead>
              <tbody id="activity-logs-table-body">
                ${filteredLogs.length > 0 ? filteredLogs.map(l => {
      const action = l.action_type || 'GENERAL';
      let badgeClass = 'badge-neutral';
      let actionIcon = 'fa-circle-info';
      let actionLabel = action.replace(/_/g, ' ');

      if (action === 'LOGIN') {
        badgeClass = 'badge-success';
        actionIcon = 'fa-arrow-right-to-bracket';
        actionLabel = 'Signed In';
      } else if (action === 'LOGIN_FAILED') {
        badgeClass = 'badge-danger';
        actionIcon = 'fa-triangle-exclamation';
        actionLabel = 'Failed Login';
      } else if (action === 'LOGOUT') {
        badgeClass = 'badge-neutral';
        actionIcon = 'fa-arrow-right-from-bracket';
        actionLabel = 'Signed Out';
      } else if (action === 'TERMINAL_UNLOCKED') {
        badgeClass = 'badge-info';
        actionIcon = 'fa-lock-open';
        actionLabel = 'Terminal Unlocked';
      } else if (action === 'SALE_COMPLETED') {
        badgeClass = 'badge-info';
        actionIcon = 'fa-cart-shopping';
        actionLabel = 'Sale Made';
      } else if (action === 'OFFLINE_SALE_SYNC') {
        badgeClass = 'badge-primary';
        actionIcon = 'fa-cloud-arrow-up';
        actionLabel = 'Offline Sale Synced';
      } else if (action === 'DEBT_PAYMENT') {
        badgeClass = 'badge-success';
        actionIcon = 'fa-hand-holding-dollar';
        actionLabel = 'Debt Settled';
      } else if (action === 'DEBT_PAYMENT_SYNC') {
        badgeClass = 'badge-primary';
        actionIcon = 'fa-cloud-arrow-up';
        actionLabel = 'Payment Synced';
      } else if (action === 'RECORD_EXPENSE') {
        badgeClass = 'badge-danger';
        actionIcon = 'fa-arrow-up-from-bracket';
        actionLabel = 'Expense Recorded';
      } else if (action === 'DELETE_EXPENSE') {
        badgeClass = 'badge-danger';
        actionIcon = 'fa-trash-can';
        actionLabel = 'Expense Deleted';
      } else if (action === 'EXPENSE_SYNC') {
        badgeClass = 'badge-primary';
        actionIcon = 'fa-cloud-arrow-up';
        actionLabel = 'Expense Synced';
      } else if (action === 'SALE_RETURN') {
        badgeClass = 'badge-warning';
        actionIcon = 'fa-arrow-rotate-left';
        actionLabel = 'Item Returned';
      } else if (action === 'RETURN_SYNC') {
        badgeClass = 'badge-primary';
        actionIcon = 'fa-cloud-arrow-up';
        actionLabel = 'Return Synced';
      } else if (action === 'STOCK_ADJUSTMENT') {
        badgeClass = 'badge-warning';
        actionIcon = 'fa-boxes-packing';
        actionLabel = 'Stock Adjusted';
      } else if (action === 'STOCK_AUDIT') {
        badgeClass = 'badge-success';
        actionIcon = 'fa-clipboard-check';
        actionLabel = 'Stocktake Audit';
      } else if (action === 'STOCK_TRANSFER') {
        badgeClass = 'badge-info';
        actionIcon = 'fa-truck-ramp-box';
        actionLabel = 'Stock Transfer';
      } else if (action === 'TRANSFER_SYNC') {
        badgeClass = 'badge-primary';
        actionIcon = 'fa-cloud-arrow-up';
        actionLabel = 'Transfer Synced';
      } else if (action === 'STOCK_WRITEOFF') {
        badgeClass = 'badge-danger';
        actionIcon = 'fa-ban';
        actionLabel = 'Stock Write-off';
      } else if (action === 'BATCH_SAVE') {
        badgeClass = 'badge-neutral';
        actionIcon = 'fa-boxes-stacked';
        actionLabel = 'Batch Saved';
      } else if (action === 'BATCH_RECALL') {
        badgeClass = 'badge-danger';
        actionIcon = 'fa-triangle-exclamation';
        actionLabel = 'Batch Recalled';
      } else if (action === 'PURCHASE_ORDER') {
        badgeClass = 'badge-primary';
        actionIcon = 'fa-truck-moving';
        actionLabel = 'Purchase Order';
      } else if (action === 'PURCHASE_SYNC') {
        badgeClass = 'badge-primary';
        actionIcon = 'fa-cloud-arrow-up';
        actionLabel = 'Purchase Synced';
      } else if (action === 'VENDOR_PAYOUT') {
        badgeClass = 'badge-danger';
        actionIcon = 'fa-money-bill-transfer';
        actionLabel = 'Vendor Payout';
      } else if (action === 'VENDOR_MANAGEMENT') {
        badgeClass = 'badge-neutral';
        actionIcon = 'fa-building';
        actionLabel = 'Supplier Saved';
      } else if (action === 'VENDOR_DELETE') {
        badgeClass = 'badge-danger';
        actionIcon = 'fa-trash';
        actionLabel = 'Supplier Deleted';
      } else if (action === 'SHIFT_CLOSE') {
        badgeClass = 'badge-success';
        actionIcon = 'fa-cash-register';
        actionLabel = 'Shift Closed';
      } else if (action === 'SHIFT_SYNC') {
        badgeClass = 'badge-primary';
        actionIcon = 'fa-cloud-arrow-up';
        actionLabel = 'Shift Synced';
      } else if (action === 'PRODUCT_CREATE') {
        badgeClass = 'badge-primary';
        actionIcon = 'fa-plus';
        actionLabel = 'Product Added';
      } else if (action === 'PRODUCT_UPDATE') {
        badgeClass = 'badge-warning';
        actionIcon = 'fa-pen-to-square';
        actionLabel = 'Product Edited';
      } else if (action === 'PRODUCT_DELETE') {
        badgeClass = 'badge-danger';
        actionIcon = 'fa-trash';
        actionLabel = 'Product Archived';
      } else if (action === 'CUSTOMER_CREATE') {
        badgeClass = 'badge-primary';
        actionIcon = 'fa-user-plus';
        actionLabel = 'Customer Added';
      } else if (action === 'CUSTOMER_UPDATE') {
        badgeClass = 'badge-neutral';
        actionIcon = 'fa-user-pen';
        actionLabel = 'Customer Edited';
      } else if (action === 'CUSTOMER_DELETE') {
        badgeClass = 'badge-danger';
        actionIcon = 'fa-user-xmark';
        actionLabel = 'Customer Deleted';
      } else if (action === 'USER_CREATE') {
        badgeClass = 'badge-primary';
        actionIcon = 'fa-user-shield';
        actionLabel = 'Staff Added';
      } else if (action === 'USER_UPDATE') {
        badgeClass = 'badge-neutral';
        actionIcon = 'fa-user-gear';
        actionLabel = 'Staff Edited';
      } else if (action === 'USER_DELETE') {
        badgeClass = 'badge-danger';
        actionIcon = 'fa-user-slash';
        actionLabel = 'Staff Deleted';
      } else if (action === 'SETTINGS_UPDATE') {
        badgeClass = 'badge-neutral';
        actionIcon = 'fa-sliders';
        actionLabel = 'Settings Updated';
      } else if (action === 'LICENSE_ACTIVATED') {
        badgeClass = 'badge-success';
        actionIcon = 'fa-key';
        actionLabel = 'License Active';
      } else if (action === 'LICENSE_FAILED') {
        badgeClass = 'badge-danger';
        actionIcon = 'fa-key';
        actionLabel = 'Invalid Key';
      } else if (action === 'BACKUP_CREATED') {
        badgeClass = 'badge-info';
        actionIcon = 'fa-database';
        actionLabel = 'Backup Saved';
      } else if (action === 'BACKUP_DOWNLOAD') {
        badgeClass = 'badge-info';
        actionIcon = 'fa-download';
        actionLabel = 'Backup Download';
      }

      const roleName = l.role_name || 'Staff';
      let roleBadge = 'badge-neutral';
      if (roleName.toLowerCase().includes('admin')) roleBadge = 'badge-danger';
      else if (roleName.toLowerCase().includes('manager')) roleBadge = 'badge-info';
      else if (roleName.toLowerCase().includes('cashier')) roleBadge = 'badge-success';

      return `
                    <tr data-action="${this.escapeHtml(action)}" data-staff="${this.escapeHtml(l.user_name || 'System')}">
                      <td style="font-size: 0.82rem; color: var(--slate-600); white-space: nowrap;">
                        <i class="fa-regular fa-clock" style="color: var(--slate-400); margin-right: 0.25rem;"></i>
                        ${this.escapeHtml(l.created_at || 'Just now')}
                      </td>
                      <td>
                        <div style="font-weight: 600; color: var(--slate-900); font-size: 0.88rem;">${this.escapeHtml(l.user_name || 'System')}</div>
                        <span class="badge ${roleBadge}" style="font-size: 0.68rem; padding: 0.1rem 0.35rem; margin-top: 0.15rem;">
                          ${this.escapeHtml(roleName)}
                        </span>
                      </td>
                      <td>
                        <span class="badge ${badgeClass}" style="display: inline-flex; align-items: center; gap: 0.35rem;">
                          <i class="fa-solid ${actionIcon}"></i>
                          <span>${this.escapeHtml(actionLabel)}</span>
                        </span>
                      </td>
                      <td style="font-size: 0.88rem; color: var(--slate-700);">
                        ${this.escapeHtml(l.details || 'No additional details.')}
                      </td>
                      <td style="font-size: 0.78rem; color: var(--slate-500); font-family: monospace;">
                        <i class="fa-solid fa-network-wired" style="margin-right: 0.2rem;"></i>
                        ${this.escapeHtml(l.ip_address || '127.0.0.1')}
                      </td>
                    </tr>
                  `;
    }).join('') : `
                  <tr>
                    <td colspan="5" style="text-align: center; padding: 3rem; color: var(--slate-400);">
                      <i class="fa-solid fa-filter-circle-xmark" style="font-size: 2.2rem; margin-bottom: 0.5rem; display: block; color: var(--slate-300);"></i>
                      ${hasActiveFilter ? 'No activity logs match your filter criteria.' : 'No activity logs recorded yet.'}
                      ${hasActiveFilter ? `
                        <div style="margin-top: 0.75rem;">
                          <button type="button" class="btn btn-outline btn-sm" onclick="app.resetActivityLogsFilters()">
                            <i class="fa-solid fa-rotate-left"></i> Reset All Filters
                          </button>
                        </div>
                      ` : ''}
                    </td>
                  </tr>
                `}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  }

  bindActivityLogsEvents() {
    // Declarative inline onchange & oninput handlers manage state persistence across re-renders
  }

  // --- Analytics & Comparative Reports Engine ---

  getAnalyticsDates() {
    const now = new Date();
    let start, end, priorStart, priorEnd, label, priorLabel;

    switch (this.analyticsPreset) {
      case 'today': {
        start = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0);
        end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);
        priorStart = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1, 0, 0, 0);
        priorEnd = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1, 23, 59, 59);
        label = `Today (${start.toLocaleDateString()})`;
        priorLabel = `Yesterday (${priorStart.toLocaleDateString()})`;
        break;
      }
      case 'yesterday': {
        start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1, 0, 0, 0);
        end = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1, 23, 59, 59);
        priorStart = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 2, 0, 0, 0);
        priorEnd = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 2, 23, 59, 59);
        label = `Yesterday (${start.toLocaleDateString()})`;
        priorLabel = `Day Before (${priorStart.toLocaleDateString()})`;
        break;
      }
      case 'last_7_days': {
        start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 6, 0, 0, 0);
        end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);
        priorStart = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 13, 0, 0, 0);
        priorEnd = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 7, 23, 59, 59);
        label = `Last 7 Days (${start.toLocaleDateString()} - ${end.toLocaleDateString()})`;
        priorLabel = `Prior 7 Days (${priorStart.toLocaleDateString()} - ${priorEnd.toLocaleDateString()})`;
        break;
      }
      case 'last_month': {
        start = new Date(now.getFullYear(), now.getMonth() - 1, 1, 0, 0, 0);
        const lastDay = new Date(now.getFullYear(), now.getMonth(), 0).getDate();
        end = new Date(now.getFullYear(), now.getMonth() - 1, lastDay, 23, 59, 59);
        priorStart = new Date(now.getFullYear(), now.getMonth() - 2, 1, 0, 0, 0);
        const lastDayPrior = new Date(now.getFullYear(), now.getMonth() - 1, 0).getDate();
        priorEnd = new Date(now.getFullYear(), now.getMonth() - 2, lastDayPrior, 23, 59, 59);
        label = `Last Month (${start.toLocaleString('default', { month: 'short', year: 'numeric' })})`;
        priorLabel = `Month Before (${priorStart.toLocaleString('default', { month: 'short', year: 'numeric' })})`;
        break;
      }
      case 'this_year': {
        start = new Date(now.getFullYear(), 0, 1, 0, 0, 0);
        end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);
        priorStart = new Date(now.getFullYear() - 1, 0, 1, 0, 0, 0);
        priorEnd = new Date(now.getFullYear() - 1, now.getMonth(), now.getDate(), 23, 59, 59);
        label = `This Year (${now.getFullYear()} YTD)`;
        priorLabel = `Last Year (${now.getFullYear() - 1} Same Period)`;
        break;
      }
      case 'custom': {
        const sParts = (this.analyticsStartDate || '').split('-');
        const eParts = (this.analyticsEndDate || '').split('-');
        start = sParts.length === 3 ? new Date(Number(sParts[0]), Number(sParts[1]) - 1, Number(sParts[2]), 0, 0, 0) : new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0);
        end = eParts.length === 3 ? new Date(Number(eParts[0]), Number(eParts[1]) - 1, Number(eParts[2]), 23, 59, 59) : new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);
        const diffMs = Math.max(86400000, end.getTime() - start.getTime());
        priorEnd = new Date(start.getTime() - 1000);
        priorStart = new Date(priorEnd.getTime() - diffMs);
        label = `Custom (${start.toLocaleDateString()} - ${end.toLocaleDateString()})`;
        priorLabel = `Preceding ${Math.round(diffMs / 86400000)} Days`;
        break;
      }
      case 'this_month':
      default: {
        start = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0);
        end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59);
        priorStart = new Date(now.getFullYear(), now.getMonth() - 1, 1, 0, 0, 0);
        const lastDayOfPrev = new Date(now.getFullYear(), now.getMonth(), 0).getDate();
        const prevDay = Math.min(now.getDate(), lastDayOfPrev);
        priorEnd = new Date(now.getFullYear(), now.getMonth() - 1, prevDay, 23, 59, 59);
        label = `This Month (${now.toLocaleString('default', { month: 'short', year: 'numeric' })} MTD)`;
        priorLabel = `Last Month (${priorStart.toLocaleString('default', { month: 'short', year: 'numeric' })} Same Days)`;
        break;
      }
    }

    return { start, end, priorStart, priorEnd, label, priorLabel };
  }

  // A VOID left the book with nothing on it: the money went back out of the drawer and the goods
  // went back on the shelf, so counting one in a revenue, tender or profit sum overstates the day.
  // Only includeVoided callers - the ones that intend to show the voided receipts as their own
  // line - should ask for them, and a row with no status at all is still counted, because the
  // older books this till has seen do not always carry one.
  filterSalesByRange(salesList, start, end, userFilter, branchFilter = null, includeVoided = false) {
    const activeBranchFilter = branchFilter || this.selectedBranchFilter || 'ALL';
    return (salesList || []).filter(s => {
      if (!includeVoided && this.isVoidedSale(s)) return false;
      const rawDate = s.sale_date || s.created_at;
      if (!rawDate) return false;
      const d = new Date(String(rawDate).replace(' ', 'T'));
      if (isNaN(d.getTime())) return false;
      if (d < start || d > end) return false;
      if (userFilter && userFilter !== 'ALL') {
        const u = (s.cashier_name || s.attendant_name || '').toLowerCase();
        const uid = String(s.user_id || '');
        if (!u.includes(userFilter.toLowerCase()) && uid !== userFilter) return false;
      }
      if (activeBranchFilter && activeBranchFilter !== 'ALL') {
        const b = String(s.branch_code || 'MAIN-01').toUpperCase();
        if (b !== activeBranchFilter.toUpperCase()) return false;
      }
      return true;
    });
  }

  getAnalyticsGrowthBadge(curr, prior) {
    if (!this.analyticsCompareWithPrior) return '';
    const currentNum = Number(curr || 0);
    const priorNum = Number(prior || 0);

    if (priorNum === 0) {
      if (currentNum > 0) {
        // A percentage of nothing is not a hundred. A shop that sold nothing last week and
        // GH₵10 this week was told its revenue rose "+100%", and the owner who went back to
        // check found an empty period, not a half-empty one. Say what actually happened.
        return '<span class="badge-growth-pos" title="Nothing sold in the prior period, so this is new volume rather than a rise"><i class="fa-solid fa-arrow-trend-up"></i> new</span>';
      }
      return '<span class="badge-growth-neutral" title="No change"><i class="fa-solid fa-minus"></i> 0.0%</span>';
    }

    const pct = ((currentNum - priorNum) / priorNum) * 100;
    const formatted = Math.abs(pct).toFixed(1);

    if (pct > 0) {
      return `<span class="badge-growth-pos" title="Up ${formatted}% vs prior period"><i class="fa-solid fa-arrow-trend-up"></i> +${formatted}%</span>`;
    } else if (pct < 0) {
      return `<span class="badge-growth-neg" title="Down ${formatted}% vs prior period"><i class="fa-solid fa-arrow-trend-down"></i> -${formatted}%</span>`;
    }
    return `<span class="badge-growth-neutral" title="Equal to prior period"><i class="fa-solid fa-minus"></i> 0.0%</span>`;
  }

  generateAnalyticsTrendChart(sales, start, end) {
    const durationDays = (end.getTime() - start.getTime()) / 86400000;
    const buckets = [];

    if (durationDays <= 2) {
      // Hourly intervals (00:00 - 23:00)
      for (let h = 0; h < 24; h++) {
        const label = `${String(h).padStart(2, '0')}:00`;
        buckets.push({ key: h, label, rev: 0, profit: 0, count: 0 });
      }
      sales.forEach(s => {
        const d = new Date(String(s.sale_date || s.created_at).replace(' ', 'T'));
        const h = d.getHours();
        const b = buckets.find(item => item.key === h);
        if (b) {
          b.rev += Number(s.total_amount || 0);
          b.profit += Number(s.gross_profit || 0);
          b.count++;
        }
      });
    } else if (durationDays <= 45) {
      // Daily intervals
      const cur = new Date(start);
      cur.setHours(0, 0, 0, 0);
      while (cur <= end) {
        const iso = cur.toISOString().slice(0, 10);
        const label = cur.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
        buckets.push({ key: iso, label, rev: 0, profit: 0, count: 0 });
        cur.setDate(cur.getDate() + 1);
      }
      sales.forEach(s => {
        const iso = String(s.sale_date || s.created_at).slice(0, 10);
        const b = buckets.find(item => item.key === iso);
        if (b) {
          b.rev += Number(s.total_amount || 0);
          b.profit += Number(s.gross_profit || 0);
          b.count++;
        }
      });
    } else {
      // Monthly intervals
      const cur = new Date(start.getFullYear(), start.getMonth(), 1);
      while (cur <= end) {
        const key = `${cur.getFullYear()}-${String(cur.getMonth() + 1).padStart(2, '0')}`;
        const label = cur.toLocaleDateString(undefined, { month: 'short', year: '2-digit' });
        buckets.push({ key, label, rev: 0, profit: 0, count: 0 });
        cur.setMonth(cur.getMonth() + 1);
      }
      sales.forEach(s => {
        const key = String(s.sale_date || s.created_at).slice(0, 7);
        const b = buckets.find(item => item.key === key);
        if (b) {
          b.rev += Number(s.total_amount || 0);
          b.profit += Number(s.gross_profit || 0);
          b.count++;
        }
      });
    }

    if (buckets.length === 0) {
      return '<div style="text-align: center; padding: 3rem; color: var(--slate-400);">No time interval data available.</div>';
    }

    const svgWidth = 700;
    const svgHeight = 220;
    const padLeft = 65;
    const padRight = 20;
    const padTop = 20;
    const padBottom = 35;
    const plotWidth = svgWidth - padLeft - padRight;
    const plotHeight = svgHeight - padTop - padBottom;

    const maxRev = Math.max(...buckets.map(b => b.rev), 100);
    const maxVal = maxRev * 1.15;

    // Calculate (x, y) coordinates
    const pointsRev = [];
    const pointsProfit = [];

    buckets.forEach((b, idx) => {
      const x = padLeft + (buckets.length > 1 ? (idx / (buckets.length - 1)) * plotWidth : plotWidth / 2);
      const yRev = padTop + plotHeight - (Math.max(0, b.rev) / maxVal) * plotHeight;
      const yProfit = padTop + plotHeight - (Math.max(0, b.profit) / maxVal) * plotHeight;
      pointsRev.push({ x, y: yRev, ...b });
      pointsProfit.push({ x, y: yProfit, ...b });
    });

    const pathRevLine = pointsRev.map((p, idx) => `${idx === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ');
    const pathRevArea = `${pathRevLine} L ${pointsRev[pointsRev.length - 1].x.toFixed(1)} ${(padTop + plotHeight).toFixed(1)} L ${pointsRev[0].x.toFixed(1)} ${(padTop + plotHeight).toFixed(1)} Z`;

    const pathProfLine = pointsProfit.map((p, idx) => `${idx === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ');
    const pathProfArea = `${pathProfLine} L ${pointsProfit[pointsProfit.length - 1].x.toFixed(1)} ${(padTop + plotHeight).toFixed(1)} L ${pointsProfit[0].x.toFixed(1)} ${(padTop + plotHeight).toFixed(1)} Z`;

    // Horizontal grid lines
    const gridSteps = 4;
    let gridLinesSvg = '';
    for (let i = 0; i <= gridSteps; i++) {
      const yVal = (maxVal / gridSteps) * i;
      const yPos = padTop + plotHeight - (i / gridSteps) * plotHeight;
      gridLinesSvg += `
        <line x1="${padLeft}" y1="${yPos.toFixed(1)}" x2="${svgWidth - padRight}" y2="${yPos.toFixed(1)}" stroke="#e2e8f0" stroke-dasharray="3,3" stroke-width="1"/>
        <text x="${padLeft - 8}" y="${(yPos + 4).toFixed(1)}" text-anchor="end" font-size="10" fill="#64748b" font-family="sans-serif">${this.formatCurrency(yVal).split('.')[0]}</text>
      `;
    }

    // X-axis label sampling
    let labelInterval = 1;
    if (buckets.length > 12) labelInterval = Math.ceil(buckets.length / 8);

    let xLabelsSvg = '';
    pointsRev.forEach((p, idx) => {
      if (idx % labelInterval === 0 || idx === buckets.length - 1) {
        xLabelsSvg += `
          <text x="${p.x.toFixed(1)}" y="${svgHeight - 10}" text-anchor="middle" font-size="10" fill="#64748b" font-family="sans-serif">${this.escapeHtml(p.label)}</text>
        `;
      }
    });

    // Data points & tooltip circles
    let dotsSvg = '';
    pointsRev.forEach((p, idx) => {
      const profP = pointsProfit[idx];
      dotsSvg += `
        <circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="4" fill="#ffffff" stroke="#2563eb" stroke-width="2" style="cursor: pointer;">
          <title>${p.label} - Revenue: ${this.formatCurrency(p.rev)} | Profit: ${this.formatCurrency(p.profit)} (${p.count} sales)</title>
        </circle>
        <circle cx="${profP.x.toFixed(1)}" cy="${profP.y.toFixed(1)}" r="3" fill="#ffffff" stroke="#10b981" stroke-width="1.8" style="cursor: pointer;">
          <title>${profP.label} - Gross Profit: ${this.formatCurrency(profP.profit)}</title>
        </circle>
      `;
    });

    return `
      <svg viewBox="0 0 ${svgWidth} ${svgHeight}" style="width: 100%; max-height: 200px; height: auto; display: block; overflow: visible;">
        <defs>
          <linearGradient id="grad-rev" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#3b82f6" stop-opacity="0.25"/>
            <stop offset="100%" stop-color="#3b82f6" stop-opacity="0.01"/>
          </linearGradient>
          <linearGradient id="grad-prof" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#10b981" stop-opacity="0.25"/>
            <stop offset="100%" stop-color="#10b981" stop-opacity="0.01"/>
          </linearGradient>
        </defs>
        ${gridLinesSvg}
        <path d="${pathRevArea}" fill="url(#grad-rev)"/>
        <path d="${pathProfArea}" fill="url(#grad-prof)"/>
        <path d="${pathRevLine}" fill="none" stroke="#2563eb" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="${pathProfLine}" fill="none" stroke="#10b981" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
        ${dotsSvg}
        ${xLabelsSvg}
      </svg>
    `;
  }

  generateAnalyticsTenderChart(salesList) {
    // The caller hands this a range that already leaves voided receipts out, but a void's money
    // physically went back out of the drawer, so it is not a tender whoever asks for the chart.
    const sales = (salesList || []).filter(s => !this.isVoidedSale(s));
    const totalRev = sales.reduce((sum, s) => sum + Number(s.total_amount || 0), 0);
    const tenderTotals = {
      CASH: { label: 'Cash', count: 0, amount: 0, color: '#10b981' },
      CARD: { label: 'Card / POS', count: 0, amount: 0, color: '#3b82f6' },
      BANK_TRANSFER: { label: 'Bank Transfer', count: 0, amount: 0, color: '#8b5cf6' },
      CREDIT: { label: 'Customer Debt', count: 0, amount: 0, color: '#f59e0b' },
      SPLIT: { label: 'Split / Other', count: 0, amount: 0, color: '#06b6d4' }
    };

    sales.forEach(s => {
      const pm = (s.payment_method || 'CASH').toUpperCase();
      let target = tenderTotals[pm];
      if (!target) {
        if (pm.includes('CARD')) target = tenderTotals.CARD;
        else if (pm.includes('TRANSFER')) target = tenderTotals.BANK_TRANSFER;
        else if (pm.includes('CREDIT') || pm.includes('DEBT')) target = tenderTotals.CREDIT;
        else target = tenderTotals.SPLIT;
      }
      target.count++;
      target.amount += Number(s.total_amount || 0);
    });

    const activeTenders = Object.values(tenderTotals).filter(t => t.count > 0);
    if (activeTenders.length === 0 || totalRev <= 0) {
      return `
        <div style="text-align: center; padding: 2.5rem; color: var(--slate-400);">
          <i class="fa-solid fa-chart-pie" style="font-size: 2rem; margin-bottom: 0.5rem; display: block;"></i>
          No payment tender data recorded for this period.
        </div>
      `;
    }

    // SVG Donut metrics
    const size = 200;
    const center = size / 2;
    const radius = 68;
    const strokeWidth = 24;
    const circumference = 2 * Math.PI * radius; // ~427.25

    let currentOffset = 0;
    let donutSegmentsSvg = '';

    activeTenders.forEach(t => {
      const pct = t.amount / totalRev;
      const strokeDash = pct * circumference;
      donutSegmentsSvg += `
        <circle cx="${center}" cy="${center}" r="${radius}" fill="transparent"
          stroke="${t.color}" stroke-width="${strokeWidth}"
          stroke-dasharray="${strokeDash.toFixed(2)} ${(circumference - strokeDash).toFixed(2)}"
          stroke-dashoffset="${(-currentOffset).toFixed(2)}"
          style="transition: stroke-dasharray 0.3s ease;">
          <title>${t.label}: ${this.formatCurrency(t.amount)} (${(pct * 100).toFixed(1)}%)</title>
        </circle>
      `;
      currentOffset += strokeDash;
    });

    const allTenders = Object.values(tenderTotals);
    const legendHtml = allTenders.map(t => {
      const pct = totalRev > 0 ? ((t.amount / totalRev) * 100).toFixed(1) : '0.0';
      const isZero = t.count === 0;
      const tenderAvg = t.count > 0 ? (t.amount / t.count) : 0;
      return `
        <div style="background: ${isZero ? '#fcfcfd' : 'var(--slate-50)'}; border: 1px solid var(--slate-200); border-radius: var(--radius-md); padding: 0.65rem 0.9rem; opacity: ${isZero ? '0.68' : '1'};">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.35rem;">
            <span style="display: flex; align-items: center; gap: 0.45rem; font-weight: 700; font-size: 0.85rem; color: var(--slate-800);">
              <span class="legend-dot" style="background-color: ${t.color}; width: 10px; height: 10px;"></span>
              ${this.escapeHtml(t.label)}
            </span>
            <span style="font-weight: 800; font-size: 0.9rem; color: var(--slate-900);">
              ${this.formatCurrency(t.amount)}
            </span>
          </div>
          <div class="progress-bar-bg" style="height: 6px;">
            <div class="progress-bar-fill" style="width: ${pct}%; background-color: ${t.color};"></div>
          </div>
          <div style="display: flex; justify-content: space-between; font-size: 0.72rem; color: var(--slate-500); margin-top: 0.3rem;">
            <span>${t.count} transaction${t.count === 1 ? '' : 's'}${t.count > 0 ? ` &bull; Avg ${this.formatCurrency(tenderAvg)}` : ''}</span>
            <span style="font-weight: 600;">${pct}% share</span>
          </div>
        </div>
      `;
    }).join('');

    const immediateCollected = (tenderTotals.CASH.amount || 0) + (tenderTotals.CARD.amount || 0) + (tenderTotals.BANK_TRANSFER.amount || 0) + (tenderTotals.SPLIT.amount || 0);
    const creditExtended = tenderTotals.CREDIT.amount || 0;
    const immediatePct = totalRev > 0 ? ((immediateCollected / totalRev) * 100).toFixed(1) : '0.0';
    const avgTicket = sales.length > 0 ? (totalRev / sales.length) : 0;
    const topTender = [...activeTenders].sort((a, b) => b.amount - a.amount)[0] || tenderTotals.CASH;

    return `
      <div class="donut-chart-container" style="display: flex; align-items: stretch; gap: 1.25rem; flex-wrap: wrap; flex: 1;">
        <div style="display: flex; flex-direction: column; justify-content: space-between; align-items: center; width: 210px; flex-shrink: 0; margin: 0 auto; gap: 0.75rem;">
          <div class="donut-chart-wrapper" style="position: relative; width: ${size}px; height: ${size}px; flex-shrink: 0;">
            <svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" style="transform: rotate(-90deg); display: block; max-width: 100%; height: auto;">
              <circle cx="${center}" cy="${center}" r="${radius}" fill="transparent" stroke="#f1f5f9" stroke-width="${strokeWidth}" />
              ${donutSegmentsSvg}
            </svg>
            <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; display: flex; flex-direction: column; align-items: center; justify-content: center; pointer-events: none;">
              <span style="font-size: 0.72rem; text-transform: uppercase; color: var(--slate-400); font-weight: 700; letter-spacing: 0.05em;">Volume</span>
              <span style="font-size: 1.05rem; font-weight: 800; color: var(--slate-900);">${this.formatCurrency(totalRev).split('.')[0]}</span>
              <span style="font-size: 0.72rem; color: var(--slate-500);">${sales.length} sales</span>
            </div>
          </div>

          <div style="width: 100%; display: flex; flex-direction: column; gap: 0.45rem;">
            <div style="background: var(--slate-50); border: 1px solid var(--slate-200); border-radius: var(--radius-sm); padding: 0.5rem 0.65rem;">
              <span style="font-size: 0.65rem; font-weight: 700; text-transform: uppercase; color: var(--slate-500); display: block;">Immediate Cash &amp; Digital</span>
              <strong style="font-size: 0.88rem; color: #059669;">${this.formatCurrency(immediateCollected)}</strong>
              <span style="font-size: 0.68rem; color: var(--slate-500); display: block;">${immediatePct}% settled at counter</span>
            </div>
            <div style="background: var(--slate-50); border: 1px solid var(--slate-200); border-radius: var(--radius-sm); padding: 0.5rem 0.65rem;">
              <span style="font-size: 0.65rem; font-weight: 700; text-transform: uppercase; color: var(--slate-500); display: block;">Credit / Debt Sales</span>
              <strong style="font-size: 0.88rem; color: ${creditExtended > 0 ? '#d97706' : 'var(--slate-700)'};">${this.formatCurrency(creditExtended)}</strong>
              <span style="font-size: 0.68rem; color: var(--slate-500); display: block;">${tenderTotals.CREDIT.count} credit invoice(s)</span>
            </div>
            <div style="background: var(--slate-50); border: 1px solid var(--slate-200); border-radius: var(--radius-sm); padding: 0.5rem 0.65rem;">
              <span style="font-size: 0.65rem; font-weight: 700; text-transform: uppercase; color: var(--slate-500); display: block;">Avg Ticket &bull; Top Rail</span>
              <strong style="font-size: 0.88rem; color: var(--slate-900);">${this.formatCurrency(avgTicket)}</strong>
              <span style="font-size: 0.68rem; color: var(--primary); font-weight: 600; display: block;">Primary: ${this.escapeHtml(topTender.label)}</span>
            </div>
          </div>
        </div>

        <div style="flex: 1; min-width: 220px; display: flex; flex-direction: column; justify-content: space-between; gap: 0.65rem;">
          ${legendHtml}
        </div>
      </div>
    `;
  }

  generateAnalyticsTopProducts(sales) {
    const productStats = {};
    let unitemisedRevenue = 0;
    let unitemisedCount = 0;

    sales.forEach(s => {
      // A receipt with no lines is not a product called "Assorted Store Sale". Until the
      // list endpoint could carry its lines, every server-loaded sale landed here as one
      // invented best-seller holding the whole receipt's revenue, and the shop's top
      // products board was a fiction written from its own headers.
      if (!Array.isArray(s.items) || s.items.length === 0) {
        unitemisedRevenue += Number(s.total_amount || 0);
        unitemisedCount++;
        return;
      }
      s.items.forEach(i => {
        const key = i.product_id || i.product_name || i.name;
        if (!productStats[key]) {
          productStats[key] = {
            id: i.product_id,
            name: i.product_name || i.name,
            qty: 0,
            revenue: 0,
            cost: 0,
            profit: 0,
            unit: '',
            costKnown: false
          };
        }
        const qty = Number(i.quantity || 1);
        const sp = Number(i.selling_price || i.unit_selling_price || 0);
        // The column on a sale line has always been unit_cost_price; asking for cost_price
        // here returned undefined, so every product on this board booked zero cost and the
        // shop's own top-products report told the owner a fifty-penny margin was a hundred.
        // The two names are read in turn now - but a till user who may not see costs gets
        // lines with the field stripped out, and reading that as zero would book the whole
        // takings as profit. Absent is kept apart from zero, and the board says nothing.
        const cpRaw = (i.cost_price !== undefined && i.cost_price !== null)
          ? i.cost_price
          : ((i.unit_cost_price !== undefined && i.unit_cost_price !== null) ? i.unit_cost_price : null);
        const cp = Number(cpRaw || 0);
        // The shelf, the cost column and the movement ledger are all measured in loose
        // units, so a box line counted once here books one bottle's cost against a box's
        // revenue and the shop's most profitable product is the one it sells in packs.
        const loose = Number(i.base_quantity > 0 ? i.base_quantity : qty);
        const sub = Number(i.subtotal || (sp * qty));
        productStats[key].qty += loose;
        productStats[key].revenue += sub;
        productStats[key].cost += (cp * loose);
        productStats[key].profit += (sub - (cp * loose));
        if (cpRaw !== null) productStats[key].costKnown = true;
        if (!productStats[key].unit) {
          const looseRow = this.products.find(pp => String(pp.id) === String(i.product_id));
          productStats[key].unit = String(i.base_unit || (looseRow && looseRow.unit) || '').trim();
        }
      });
    });

    const sorted = Object.values(productStats).sort((a, b) => b.revenue - a.revenue).slice(0, 5);
    // Say what was left out rather than quietly folding it into a product that does not
    // exist: an owner comparing this board to the takings needs to see the gap.
    const omittedNote = unitemisedCount > 0
      ? `<div style="font-size: 0.74rem; color: var(--slate-500); padding-top: 0.35rem; border-top: 1px dashed var(--slate-200);">
           <i class="fa-solid fa-circle-info"></i>
           ${unitemisedCount} sale${unitemisedCount === 1 ? '' : 's'} in this period carry no itemised lines (${this.formatCurrency(unitemisedRevenue)} of revenue) and are left out of this ranking.
         </div>`
      : '';
    if (sorted.length === 0) {
      return `
        <div style="text-align: center; padding: 2.5rem; color: var(--slate-400);">
          <i class="fa-solid fa-boxes-stacked" style="font-size: 2rem; margin-bottom: 0.5rem; display: block;"></i>
          No product volume recorded for this period.
          ${omittedNote}
        </div>
      `;
    }

    const topRev = sorted[0].revenue || 1;
    const rankColors = ['#f59e0b', '#94a3b8', '#d97706', '#64748b', '#64748b'];

    return `
      <div style="display: flex; flex-direction: column; gap: 0.85rem;">
        ${sorted.map((p, idx) => {
      const pct = Math.min(100, Math.round((p.revenue / topRev) * 100));
      return `
            <div style="background: var(--slate-50); border: 1px solid var(--slate-200); border-radius: var(--radius-md); padding: 0.75rem 1rem;">
              <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.4rem;">
                <div style="display: flex; align-items: center; gap: 0.5rem;">
                  <span style="display: inline-flex; align-items: center; justify-content: center; width: 22px; height: 22px; border-radius: 50%; background: ${rankColors[idx]}; color: #ffffff; font-size: 0.72rem; font-weight: 800;">
                    ${idx + 1}
                  </span>
                  <span style="font-weight: 700; color: var(--slate-800); font-size: 0.88rem;">${this.escapeHtml(p.name)}</span>
                </div>
                <div style="text-align: right;">
                  <span style="font-weight: 800; color: var(--slate-900); font-size: 0.92rem;">${this.formatCurrency(p.revenue)}</span>
                  <span style="font-size: 0.74rem; color: var(--success); font-weight: 600; display: block;">${p.costKnown ? `+${this.formatCurrency(p.profit)} profit` : ''}</span>
                </div>
              </div>
              <div class="progress-bar-bg" style="height: 6px;">
                <div class="progress-bar-fill" style="width: ${pct}%; background-color: var(--primary);"></div>
              </div>
              <div style="display: flex; justify-content: space-between; font-size: 0.74rem; color: var(--slate-500); margin-top: 0.35rem;">
                <span>${p.qty} ${this.escapeHtml(p.unit || 'units')} sold</span>
                <span>${p.costKnown ? `Margin: ${p.revenue > 0 ? ((p.profit / p.revenue) * 100).toFixed(1) : 0}%` : 'Cost not visible to this user'}</span>
              </div>
            </div>
          `;
    }).join('')}
        ${omittedNote}
      </div>
    `;
  }

  generateAnalyticsStaffTable(sales, totalStoreRev) {
    // Gather distinct staff identifiers
    const staffMap = {};

    // First populate from registered users
    (this.users || []).forEach(u => {
      const name = u.full_name || u.username;
      staffMap[name.toLowerCase()] = {
        name: name,
        role: u.role_name || 'Staff',
        salesCount: 0,
        revenue: 0,
        profit: 0,
        tenders: {}
      };
    });

    // Populate actual metrics from sales
    sales.forEach(s => {
      // The list endpoint never carried the cashier, so every sale the shop had ever made
      // on the server landed in one row called "Store Cashier" and the attendant board
      // ranked a person who does not exist above the people who do.
      const staffName = s.attendant_name || s.cashier_name || 'Unattributed sale';
      const key = staffName.toLowerCase();
      if (!staffMap[key]) {
        staffMap[key] = {
          name: staffName,
          role: 'Attendant',
          salesCount: 0,
          revenue: 0,
          profit: 0,
          tenders: {}
        };
      }
      staffMap[key].salesCount++;
      const amt = Number(s.total_amount || 0);
      staffMap[key].revenue += amt;
      staffMap[key].profit += Number(s.gross_profit || 0);

      const m = (s.payment_method || 'CASH').toUpperCase();
      staffMap[key].tenders[m] = (staffMap[key].tenders[m] || 0) + amt;
    });

    const staffList = Object.values(staffMap).sort((a, b) => b.revenue - a.revenue);

    return `
      <div class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>Attendant / Cashier</th>
              <th>Role</th>
              <th style="text-align: right;">Transactions</th>
              <th style="text-align: right;">Total Revenue</th>
              <th style="text-align: right;">Gross Profit</th>
              <th style="text-align: right;">Avg Basket</th>
              <th style="text-align: right;">Margin %</th>
              <th style="text-align: right;">Store Share</th>
            </tr>
          </thead>
          <tbody>
            ${staffList.map(st => {
      const avgBasket = st.salesCount > 0 ? (st.revenue / st.salesCount) : 0;
      const marginPct = st.revenue > 0 ? ((st.profit / st.revenue) * 100).toFixed(1) : '0.0';
      const sharePct = totalStoreRev > 0 ? ((st.revenue / totalStoreRev) * 100).toFixed(1) : '0.0';

      return `
                <tr>
                  <td>
                    <div style="display: flex; align-items: center; gap: 0.6rem;">
                      <div style="width: 32px; height: 32px; border-radius: 50%; background: var(--primary-light); color: var(--primary); display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 0.8rem;">
                        ${this.escapeHtml(st.name.slice(0, 2).toUpperCase())}
                      </div>
                      <span style="font-weight: 600; color: var(--slate-900);">${this.escapeHtml(st.name)}</span>
                    </div>
                  </td>
                  <td><span class="badge badge-neutral">${this.escapeHtml(st.role)}</span></td>
                  <td style="text-align: right; font-weight: 700;">${st.salesCount}</td>
                  <td style="text-align: right; font-weight: 700; color: var(--slate-900);">${this.formatCurrency(st.revenue)}</td>
                  <td style="text-align: right; font-weight: 700; color: var(--success);">+${this.formatCurrency(st.profit)}</td>
                  <td style="text-align: right;">${this.formatCurrency(avgBasket)}</td>
                  <td style="text-align: right; font-weight: 600;">${marginPct}%</td>
                  <td style="text-align: right;">
                    <span style="font-weight: 700; color: var(--primary);">${sharePct}%</span>
                  </td>
                </tr>
              `;
    }).join('')}
          </tbody>
        </table>
      </div>
    `;
  }

  generateAnalyticsCustomerSummary(sales) {
    let walkInCount = 0;
    let walkInRev = 0;
    let namedCount = 0;
    let namedRev = 0;

    sales.forEach(s => {
      const isNamed = s.customer_id && s.customer_id !== 'cust-walkin' && s.customer_name && s.customer_name !== 'Walk-in Customer';
      const amt = Number(s.total_amount || 0);
      if (isNamed) {
        namedCount++;
        namedRev += amt;
      } else {
        walkInCount++;
        walkInRev += amt;
      }
    });

    const debtors = (this.customers || []).filter(c => Number(c.balance || 0) > 0).sort((a, b) => Number(b.balance || 0) - Number(a.balance || 0));
    const totalExposure = debtors.reduce((sum, c) => sum + Number(c.balance || 0), 0);

    return `
      <div class="analytics-grid-2">
        <div style="background: var(--slate-50); border: 1px solid var(--slate-200); border-radius: var(--radius-md); padding: 1rem;">
          <h5 style="margin: 0 0 0.75rem 0; font-size: 0.88rem; color: var(--slate-800); display: flex; align-items: center; gap: 0.4rem;">
            <i class="fa-solid fa-users-viewfinder" style="color: var(--primary);"></i> Buyer Demographics
          </h5>
          <div style="display: flex; flex-direction: column; gap: 0.6rem; font-size: 0.82rem;">
            <div style="display: flex; justify-content: space-between; border-bottom: 1px solid var(--slate-200); padding-bottom: 0.4rem;">
              <span style="color: var(--slate-600);"><i class="fa-solid fa-person-walking"></i> Walk-in Customers</span>
              <span style="font-weight: 700;">${walkInCount} tx (${this.formatCurrency(walkInRev)})</span>
            </div>
            <div style="display: flex; justify-content: space-between; border-bottom: 1px solid var(--slate-200); padding-bottom: 0.4rem;">
              <span style="color: var(--slate-600);"><i class="fa-solid fa-id-card"></i> Named Account Buyers</span>
              <span style="font-weight: 700;">${namedCount} tx (${this.formatCurrency(namedRev)})</span>
            </div>
            <div style="display: flex; justify-content: space-between; padding-top: 0.2rem;">
              <span style="color: var(--slate-600);">Named Spend Average</span>
              <span style="font-weight: 700; color: var(--primary);">${this.formatCurrency(namedCount > 0 ? (namedRev / namedCount) : 0)}</span>
            </div>
          </div>
        </div>

        <div style="background: #fff1f2; border: 1px solid #fecdd3; border-radius: var(--radius-md); padding: 1rem;">
          <h5 style="margin: 0 0 0.75rem 0; font-size: 0.88rem; color: #9f1239; display: flex; align-items: center; justify-content: space-between;">
            <span style="display: flex; align-items: center; gap: 0.4rem;">
              <i class="fa-solid fa-triangle-exclamation"></i> Outstanding Debt Exposure
            </span>
            <span style="font-weight: 800; font-size: 0.95rem;">${this.formatCurrency(totalExposure)}</span>
          </h5>
          <div style="font-size: 0.78rem; color: #881337; margin-bottom: 0.6rem;">
            ${debtors.length} customers currently holding unpaid accounts receivable.
          </div>
          <div style="display: flex; flex-direction: column; gap: 0.4rem;">
            ${debtors.slice(0, 3).map(d => `
              <div style="display: flex; justify-content: space-between; align-items: center; background: #ffffff; padding: 0.4rem 0.6rem; border-radius: var(--radius-sm); font-size: 0.78rem;">
                <span style="font-weight: 600; color: var(--slate-900);">${this.escapeHtml(d.name)}</span>
                <div style="display: flex; align-items: center; gap: 0.4rem;">
                  <span style="font-weight: 700; color: var(--danger);">${this.formatCurrency(d.balance)}</span>
                  <button class="btn btn-outline btn-sm" onclick="app.openCustomerStatementModal(${this.jsStr(d.id)})" style="padding: 0.1rem 0.4rem; font-size: 0.7rem;">
                    <i class="fa-solid fa-file-invoice"></i>
                  </button>
                </div>
              </div>
            `).join('')}
            ${debtors.length === 0 ? '<div style="color: var(--success); font-weight: 600; font-size: 0.78rem;"><i class="fa-solid fa-circle-check"></i> Clean ledger! No unpaid customer debts.</div>' : ''}
          </div>
        </div>
      </div>
    `;
  }

  generateAnalyticsHourlyHeatmap(sales) {
    const isDowMode = this.analyticsTrafficTab === 'dow';
    const totalTx = sales.length;

    // --- 1. Hourly Distribution (24 Hours) ---
    const hourly = [];
    for (let h = 0; h < 24; h++) {
      hourly.push({
        hour: h,
        label: `${String(h).padStart(2, '0')}:00`,
        count: 0,
        revenue: 0
      });
    }

    // --- 2. Day-of-the-Week Distribution (Monday to Sunday) ---
    const dowList = [
      { dayIndex: 1, label: 'Monday', short: 'Mon', count: 0, revenue: 0, profit: 0 },
      { dayIndex: 2, label: 'Tuesday', short: 'Tue', count: 0, revenue: 0, profit: 0 },
      { dayIndex: 3, label: 'Wednesday', short: 'Wed', count: 0, revenue: 0, profit: 0 },
      { dayIndex: 4, label: 'Thursday', short: 'Thu', count: 0, revenue: 0, profit: 0 },
      { dayIndex: 5, label: 'Friday', short: 'Fri', count: 0, revenue: 0, profit: 0 },
      { dayIndex: 6, label: 'Saturday', short: 'Sat', count: 0, revenue: 0, profit: 0 },
      { dayIndex: 0, label: 'Sunday', short: 'Sun', count: 0, revenue: 0, profit: 0 }
    ];

    sales.forEach(s => {
      const rawDate = s.sale_date || s.created_at;
      if (!rawDate) return;
      const d = new Date(String(rawDate).replace(' ', 'T'));
      if (isNaN(d.getTime())) return;

      const m = this.getSaleProfitMetrics(s);
      const h = d.getHours();
      if (hourly[h]) {
        hourly[h].count++;
        hourly[h].revenue += m.netRevenue;
      }

      const dayIdx = d.getDay();
      const dowObj = dowList.find(item => item.dayIndex === dayIdx);
      if (dowObj) {
        dowObj.count++;
        dowObj.revenue += m.netRevenue;
        dowObj.profit += m.netProfit;
      }
    });

    const maxCount = Math.max(...hourly.map(item => item.count), 0);
    const peakHourObj = hourly.reduce((max, cur) => cur.count > max.count ? cur : max, hourly[0]);
    const bizHours = hourly.filter(h => h.hour >= 8 && h.hour <= 20);
    const quietHourObj = bizHours.reduce((min, cur) => cur.count < min.count ? cur : min, bizHours[0] || hourly[0]);

    const formatHourDisplay = (h) => {
      const ampm = h >= 12 ? 'PM' : 'AM';
      const h12 = h % 12 === 0 ? 12 : h % 12;
      return `${h12}:00 ${ampm}`;
    };

    // Day of week analytics calculations
    const maxDowRev = Math.max(...dowList.map(item => item.revenue), 0);
    const maxDowCount = Math.max(...dowList.map(item => item.count), 0);
    const totalWeeklyRev = dowList.reduce((sum, item) => sum + item.revenue, 0);
    const peakDowObj = dowList.reduce((max, cur) => cur.revenue > max.revenue ? cur : max, dowList[0]);
    const activeDow = dowList.filter(item => item.count > 0);
    const quietDowObj = activeDow.length > 0 ? activeDow.reduce((min, cur) => cur.revenue < min.revenue ? cur : min, activeDow[0]) : null;
    const peakDowShare = totalWeeklyRev > 0 ? Math.round((peakDowObj.revenue / totalWeeklyRev) * 1000) / 10 : 0;

    return `
      <div class="chart-card" style="margin-bottom: 0;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.85rem; flex-wrap: wrap; gap: 0.75rem;">
          <div>
            <h4 style="margin: 0; font-size: 0.95rem; font-weight: 700; color: var(--slate-800); display: flex; align-items: center; gap: 0.5rem;">
              <i class="fa-solid fa-chart-simple" style="color: #6366f1;"></i> Store Traffic & Temporal Patterns
            </h4>
            <span style="font-size: 0.76rem; color: var(--slate-500);">
              ${isDowMode ? 'Customer volume & sales distribution by day of week' : 'Transaction volume across 24-hour cycles'}
            </span>
          </div>

          <!-- Interactive View Mode Toggle: Hourly vs Day-of-Week -->
          <div style="display: flex; gap: 0.35rem; align-items: center; background: var(--slate-100); padding: 3px; border-radius: 6px;">
            <button class="btn-chip-filter ${!isDowMode ? 'active' : ''}"
                    style="border-radius: 4px; font-size: 0.74rem; padding: 0.25rem 0.65rem; border: none; font-weight: 600;"
                    onclick="app.setAnalyticsTrafficTab('hourly')">
              <i class="fa-solid fa-clock"></i> By Hour (24h)
            </button>
            <button class="btn-chip-filter ${isDowMode ? 'active' : ''}"
                    style="border-radius: 4px; font-size: 0.74rem; padding: 0.25rem 0.65rem; border: none; font-weight: 600;"
                    onclick="app.setAnalyticsTrafficTab('dow')">
              <i class="fa-solid fa-calendar-week"></i> By Day of Week (Mon–Sun)
            </button>
          </div>
        </div>

        <!-- Intelligent Recommendation Banner -->
        <div style="background: #eef2ff; border-left: 4px solid #6366f1; padding: 0.75rem 1rem; border-radius: 0 var(--radius-sm) var(--radius-sm) 0; margin-bottom: 1rem; font-size: 0.8rem; color: #3730a3;">
          <strong><i class="fa-solid fa-lightbulb"></i> Staffing & Trading Intelligence:</strong>
          ${totalTx > 0 ? (
            isDowMode ? `
              Top trading day is <strong>${peakDowObj.label}</strong> generating <strong>${this.formatCurrency(peakDowObj.revenue)} (${peakDowShare}% of total sales across ${peakDowObj.count} transactions)</strong>. Maintain full checkout register staffing. ${quietDowObj && quietDowObj.dayIndex !== peakDowObj.dayIndex ? `Quietest day is <strong>${quietDowObj.label}</strong> (${this.formatCurrency(quietDowObj.revenue)}), optimal for supplier stock arrivals and shelf inventory audits.` : ''}
            ` : `
              Peak rush occurs around <strong>${formatHourDisplay(peakHourObj.hour)}</strong> with <strong>${peakHourObj.count} transactions</strong> (${this.formatCurrency(peakHourObj.revenue)}). Optimal to staff multiple checkout registers during this window. Quietest daytime period is <strong>${formatHourDisplay(quietHourObj.hour)}</strong>, ideal for stock shelf intake and inventory cycle audits.
            `
          ) : 'No transactions recorded yet in this selected period to analyze trading patterns.'}
        </div>

        ${isDowMode ? `
          <!-- Day of the Week (Mon - Sun) Visual Cards & Relative Bars -->
          <div style="display: flex; gap: 0.65rem; align-items: stretch; justify-content: space-between; flex-wrap: wrap;">
            ${dowList.map(d => {
              const isPeak = d.count > 0 && d.dayIndex === peakDowObj.dayIndex;
              const isQuiet = quietDowObj && d.count > 0 && d.dayIndex === quietDowObj.dayIndex && d.dayIndex !== peakDowObj.dayIndex;
              const revPct = maxDowRev > 0 ? Math.round((d.revenue / maxDowRev) * 100) : 0;
              const barHeight = Math.max(d.count > 0 ? 12 : 4, revPct);
              const avgTicket = d.count > 0 ? (d.revenue / d.count) : 0;

              return `
                <div style="flex: 1 1 100px; min-width: 95px; background: ${isPeak ? '#f0fdf4' : (d.count > 0 ? '#ffffff' : 'var(--slate-50)')}; border: 1px solid ${isPeak ? '#86efac' : 'var(--slate-200)'}; border-radius: 8px; padding: 0.75rem 0.6rem; display: flex; flex-direction: column; justify-content: space-between; box-shadow: ${isPeak ? '0 1px 3px rgba(34,197,94,0.15)' : 'none'};">
                  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.4rem;">
                    <span style="font-weight: 800; font-size: 0.82rem; color: ${isPeak ? '#15803d' : 'var(--slate-800)'};">${d.short}</span>
                    ${isPeak ? '<span class="badge badge-success" style="font-size: 0.6rem; padding: 1px 4px;"><i class="fa-solid fa-crown"></i> Top</span>' : ''}
                    ${isQuiet ? '<span class="badge badge-neutral" style="font-size: 0.6rem; padding: 1px 4px;">Quiet</span>' : ''}
                  </div>

                  <div style="height: 65px; display: flex; align-items: flex-end; margin-bottom: 0.45rem; background: ${isPeak ? '#dcfce7' : '#f8fafc'}; border-radius: 4px; padding: 2px;">
                    <div style="width: 100%; height: ${barHeight}%; background: ${isPeak ? 'linear-gradient(180deg, #10b981, #059669)' : (d.count > 0 ? '#3b82f6' : '#cbd5e1')}; border-radius: 3px; transition: height 0.3s ease;"></div>
                  </div>

                  <div style="text-align: left; font-size: 0.74rem;">
                    <div style="font-weight: 800; font-size: 0.86rem; color: ${isPeak ? '#15803d' : 'var(--slate-900)'}; font-family: monospace;">${this.formatCurrency(d.revenue)}</div>
                    <div style="color: var(--slate-500); font-size: 0.7rem; margin-top: 2px;">
                      ${d.count} sale(s)${d.count > 0 ? ` &bull; avg ${this.formatCurrency(avgTicket)}` : ''}
                    </div>
                  </div>
                </div>
              `;
            }).join('')}
          </div>
        ` : `
          <!-- 24-Hour Visual Heatmap Bars -->
          <div class="heatmap-container">
            ${hourly.map(item => {
              const pct = maxCount > 0 ? (item.count / maxCount) * 100 : 0;
              let barColor = '#e2e8f0';
              if (item.count > 0) {
                if (item.count === maxCount && maxCount > 1) barColor = '#ef4444';
                else if (pct > 65) barColor = '#f59e0b';
                else if (pct > 30) barColor = '#3b82f6';
                else barColor = '#93c5fd';
              }
              const barHeight = Math.max(item.count > 0 ? 12 : 4, Math.round(pct));
              return `
                <div class="heatmap-col" title="${item.label} - ${item.count} transactions (${this.formatCurrency(item.revenue)})">
                  <span style="font-size: 0.62rem; font-weight: 700; color: ${item.count === maxCount && item.count > 0 ? '#ef4444' : 'var(--slate-500)'}; margin-bottom: 0.2rem;">
                    ${item.count > 0 ? item.count : ''}
                  </span>
                  <div class="heatmap-bar" style="height: ${barHeight}%; background-color: ${barColor};"></div>
                  <span class="heatmap-hour-label">${item.hour % 3 === 0 ? item.hour : ''}</span>
                </div>
              `;
            }).join('')}
          </div>
        `}
      </div>
    `;
  }

  generateAnalyticsCategoryBreakdown(sales) {
    const prodMap = {};
    (this.products || []).forEach(p => {
      prodMap[p.id] = p;
    });

    const catStats = {};
    let unitemisedRevenue = 0;
    let unitemisedCount = 0;

    sales.forEach(s => {
      // Same rule as the products board: an unitemised receipt is not a category. It used
      // to be booked as "Assorted Item" under "General" at the whole receipt's cost, which
      // is how a category board ends up with a margin no department ever earned.
      if (!Array.isArray(s.items) || s.items.length === 0) {
        unitemisedRevenue += Number(s.total_amount || 0);
        unitemisedCount++;
        return;
      }
      s.items.forEach(i => {
        const prod = prodMap[i.product_id] || {};
        const cat = i.category || prod.category || 'Uncategorised';
        if (!catStats[cat]) {
          catStats[cat] = {
            category: cat,
            units: 0,
            revenue: 0,
            cost: 0,
            profit: 0
          };
        }
        const qty = Number(i.quantity || 1);
        const sp = Number(i.selling_price || i.unit_selling_price || 0);
        const cp = Number(i.cost_price || i.unit_cost_price || (prod.cost_price || 0));
        const loose = Number(i.base_quantity > 0 ? i.base_quantity : qty);
        const sub = Number(i.subtotal || (sp * qty));
        catStats[cat].units += loose;
        catStats[cat].revenue += sub;
        catStats[cat].cost += (cp * loose);
        catStats[cat].profit += (sub - (cp * loose));
      });
    });

    const catList = Object.values(catStats).sort((a, b) => b.profit - a.profit);
    const totalProfit = catList.reduce((sum, c) => sum + Math.max(0, c.profit), 0) || 1;
    // Taking the unitemised receipts out of a category board is right; taking them out
    // without saying so is how a board reads GH₵40 short of the till's own takings and the
    // owner assumes the app is losing his money.
    const omittedNote = unitemisedCount > 0
      ? `<div style="font-size: 0.74rem; color: var(--slate-500); padding-top: 0.35rem;">
           <i class="fa-solid fa-circle-info"></i>
           ${unitemisedCount} sale${unitemisedCount === 1 ? '' : 's'} in this period carry no itemised lines (${this.formatCurrency(unitemisedRevenue)} of revenue) and are left out of this breakdown.
         </div>`
      : '';

    if (catList.length === 0) {
      return `
        <div style="text-align: center; padding: 2.5rem; color: var(--slate-400);">
          <i class="fa-solid fa-layer-group" style="font-size: 2rem; margin-bottom: 0.5rem; display: block;"></i>
          No category sales recorded for this period.
          ${omittedNote}
        </div>
      `;
    }

    return `
      <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 1rem;">
        ${catList.map(c => {
      const marginPct = c.revenue > 0 ? ((c.profit / c.revenue) * 100).toFixed(1) : '0.0';
      const sharePct = Math.min(100, Math.round((Math.max(0, c.profit) / totalProfit) * 100));
      const isHighMargin = Number(marginPct) >= 30;

      return `
            <div class="category-metric-card">
              <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.5rem;">
                <div>
                  <h5 style="margin: 0; font-size: 0.92rem; font-weight: 700; color: var(--slate-900); display: flex; align-items: center; gap: 0.4rem;">
                    <i class="fa-solid fa-tags" style="color: var(--primary);"></i>
                    ${this.escapeHtml(c.category)}
                  </h5>
                  <span style="font-size: 0.74rem; color: var(--slate-500);">${c.units} units sold</span>
                </div>
                <span class="badge ${isHighMargin ? 'badge-success' : 'badge-neutral'}" style="font-weight: 700;">
                  ${marginPct}% Margin
                </span>
              </div>

              <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 0.4rem;">
                <div>
                  <span style="font-size: 0.74rem; color: var(--slate-500); display: block;">Revenue</span>
                  <span style="font-size: 0.95rem; font-weight: 700; color: var(--slate-900);">${this.formatCurrency(c.revenue)}</span>
                </div>
                <div style="text-align: right;">
                  <span style="font-size: 0.74rem; color: var(--slate-500); display: block;">Gross Profit</span>
                  <span style="font-size: 0.95rem; font-weight: 700; color: var(--success);">+${this.formatCurrency(c.profit)}</span>
                </div>
              </div>

              <div class="progress-bar-bg" style="height: 6px; margin-bottom: 0.35rem;">
                <div class="progress-bar-fill" style="width: ${sharePct}%; background-color: ${isHighMargin ? 'var(--success)' : 'var(--primary)'};"></div>
              </div>
              <div style="font-size: 0.72rem; color: var(--slate-500); text-align: right;">
                Contributes ${sharePct}% to total store profit
              </div>
            </div>
          `;
    }).join('')}
      </div>
      ${omittedNote}
    `;
  }

  generateAnalyticsDeadStockSection() {
    const now = new Date();
    const thirtyDaysAgo = new Date(now.getTime() - (30 * 86400000));

    // Map sales to find last sale date for each product
    const productLastSale = {};
    let salesInWindow = 0;
    let linesInWindow = 0;
    (this.sales || []).forEach(s => {
      const sDate = new Date(String(s.sale_date || s.created_at).replace(' ', 'T'));
      if (isNaN(sDate.getTime())) return;
      const items = s.items || [];
      if (sDate >= thirtyDaysAgo && sDate <= now) {
        salesInWindow++;
        linesInWindow += items.length;
      }
      items.forEach(i => {
        if (!i.product_id) return;
        if (!productLastSale[i.product_id] || sDate > productLastSale[i.product_id]) {
          productLastSale[i.product_id] = sDate;
        }
      });
    });

    // Also check active/returned equipment rentals so rental fleet items dispatched in the last 30d are not called dead
    (this.rentals || []).forEach(r => {
      if (String(r.status || '').toUpperCase() === 'CANCELLED') return;
      const rDate = new Date(String(r.pickup_date || r.created_at || '').replace(' ', 'T'));
      if (isNaN(rDate.getTime())) return;
      (r.items || []).forEach(ri => {
        if (!ri.product_id) return;
        if (!productLastSale[ri.product_id] || rDate > productLastSale[ri.product_id]) {
          productLastSale[ri.product_id] = rDate;
        }
      });
    });

    const dormantProducts = [];
    let totalDormantCapital = 0;
    let totalDormantUnits = 0;

    (this.products || []).forEach(p => {
      const qty = Number(p.current_quantity || 0);
      if (qty <= 0) return; // Ignore out of stock items

      const lastDate = productLastSale[p.id];
      const createdRaw = p.created_at ? new Date(String(p.created_at).replace(' ', 'T')) : null;
      const createdDate = (createdRaw && !isNaN(createdRaw.getTime())) ? createdRaw : null;

      // A product added less than 30 days ago (e.g. yesterday) has not been sitting on the shelf
      // for 30+ days, so it cannot be flagged as 30-day dead stock.
      if (!lastDate && createdDate && createdDate > thirtyDaysAgo) {
        return;
      }

      const isDormant = !lastDate || lastDate < thirtyDaysAgo;

      if (isDormant) {
        const cost = Number(p.cost_price || 0);
        const lockedCash = qty * cost;
        totalDormantCapital += lockedCash;
        totalDormantUnits += qty;

        const daysDormant = lastDate
          ? Math.floor((now.getTime() - lastDate.getTime()) / 86400000)
          : (createdDate ? Math.max(30, Math.floor((now.getTime() - createdDate.getTime()) / 86400000)) : '30+');
        const lastSoldBadgeText = lastDate
          ? `${daysDormant} days ago`
          : (createdDate ? `Never sold (Added ${daysDormant}d ago)` : 'Never sold (30+ days)');

        dormantProducts.push({
          ...p,
          daysDormant,
          lastSoldBadgeText,
          lastDateStr: lastDate ? lastDate.toLocaleDateString() : 'Never sold in recorded ledger',
          lockedCash
        });
      }
    });

    dormantProducts.sort((a, b) => b.lockedCash - a.lockedCash);

    // "Never sold" here is inferred from the absence of a line naming the product. When the
    // till is holding receipt headers only - offline, or a ledger read before its lines were
    // fetched - every stocked item looks never-sold and the owner is told his whole shelf is
    // dead capital. Say it cannot see rather than inventing the figure.
    if (salesInWindow > 0 && linesInWindow === 0) {
      return `
        <div class="panel" style="margin-bottom: 1.25rem;">
          <div class="panel-header" style="background: #fffbeb; border-bottom: 1px solid #fef3c7;">
            <div>
              <h3 style="color: #92400e; margin: 0; font-size: 0.95rem; display: flex; align-items: center; gap: 0.5rem;">
                <i class="fa-solid fa-hourglass-half" style="color: #d97706;"></i> Dead Stock &amp; Dormant Working Capital Alert
              </h3>
              <span style="font-size: 0.76rem; color: #b45309;">Turnover cannot be judged from receipt headers alone</span>
            </div>
          </div>
          <div class="panel-body" style="padding: 1.5rem;">
            <div style="text-align: center; color: var(--slate-600); font-size: 0.86rem;">
              <i class="fa-solid fa-eye-slash" style="font-size: 1.4rem; display: block; margin-bottom: 0.4rem; color: #d97706;"></i>
              ${salesInWindow} sale${salesInWindow === 1 ? '' : 's'} in the last 30 days reached this till without their item lines, so no product can be proved to have moved.
              Connect to the shop's books and reopen Analytics to read turnover. Nothing here has been counted as dead.
            </div>
          </div>
        </div>
      `;
    }

    return `
      <div class="panel" style="margin-bottom: 1.25rem;">
        <div class="panel-header" style="background: #fffbeb; border-bottom: 1px solid #fef3c7;">
          <div>
            <h3 style="color: #92400e; margin: 0; font-size: 0.95rem; display: flex; align-items: center; gap: 0.5rem;">
              <i class="fa-solid fa-hourglass-half" style="color: #d97706;"></i> Dead Stock & Dormant Working Capital Alert
            </h3>
            <span style="font-size: 0.76rem; color: #b45309;">Products on shelves with zero turnover in the last 30+ days</span>
          </div>
          <div style="text-align: right;">
            <span style="font-size: 0.74rem; color: #92400e; display: block; font-weight: 600;">Tied-Up Working Capital:</span>
            <span style="font-size: 1.15rem; font-weight: 800; color: #b45309;">${this.formatCurrency(totalDormantCapital)}</span>
          </div>
        </div>
        <div class="panel-body" style="padding: ${dormantProducts.length > 0 ? '0' : '1.5rem'};">
          ${dormantProducts.length > 0 ? `
            <div class="table-responsive">
              <table class="data-table">
                <thead>
                  <tr>
                    <th>Product</th>
                    <th>Category</th>
                    <th style="text-align: right;">Shelf Units</th>
                    <th style="text-align: right;">Unit Cost</th>
                    <th style="text-align: right;">Tied-Up Cash</th>
                    <th>Last Sold</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  ${dormantProducts.slice(0, 5).map(p => `
                    <tr>
                      <td>
                        <strong style="color: var(--slate-900);">${this.escapeHtml(p.name)}</strong>
                        <div style="font-size: 0.72rem; color: var(--slate-500); font-family: monospace;">SKU: ${this.escapeHtml(p.sku || p.barcode || 'N/A')}</div>
                      </td>
                      <td><span class="badge badge-neutral">${this.escapeHtml(p.category || 'General')}</span></td>
                      <td style="text-align: right; font-weight: 700; color: #b45309;">${p.current_quantity}</td>
                      <td style="text-align: right;">${this.formatCurrency(p.cost_price || 0)}</td>
                      <td style="text-align: right; font-weight: 800; color: var(--danger);">${this.formatCurrency(p.lockedCash)}</td>
                      <td>
                        <span style="font-size: 0.76rem; color: var(--slate-600);"><i class="fa-solid fa-calendar-xmark" style="color: #f59e0b;"></i> ${this.escapeHtml(p.lastSoldBadgeText || (p.daysDormant + ' days ago'))}</span>
                      </td>
                      <td>
                        <button class="btn btn-outline btn-sm" onclick="app.switchView('products')" style="font-size: 0.72rem; padding: 0.2rem 0.5rem;" title="Adjust price or launch promo">
                          <i class="fa-solid fa-tag"></i> Clear
                        </button>
                      </td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            </div>
            ${dormantProducts.length > 5 ? `
              <div style="padding: 0.6rem 1rem; background: var(--slate-50); font-size: 0.76rem; color: var(--slate-600); border-top: 1px solid var(--slate-200); text-align: center;">
                Showing top 5 of ${dormantProducts.length} dormant products holding ${totalDormantUnits} units in storage. Consider clearance markdowns to restore liquidity.
              </div>
            ` : ''}
          ` : `
            <div style="text-align: center; color: var(--success); font-weight: 600; font-size: 0.88rem;">
              <i class="fa-solid fa-circle-check" style="font-size: 1.5rem; display: block; margin-bottom: 0.4rem;"></i>
              High inventory velocity! All stocked items have recorded active turnover in the last 30 days.
            </div>
          `}
        </div>
      </div>
    `;
  }

  // What the shop bought in, on the same window the rest of the page is read on.
  //
  // Analytics spoke only about money coming over the counter. The money going out to the
  // factory - normally the largest single number in a shop - appeared nowhere on it, so the
  // owner could see a healthy profit margin and not see that the week's takings had already
  // gone out again as stock. Purchase orders are not an expense, they are cash turning into
  // goods, which is why this sits beside the other boards and never inside net profit.
  generateAnalyticsPurchasingSection() {
    // A cashier's till is not handed the purchase book at all - the endpoint refuses it - so
    // drawing an empty board here would read as "the shop bought nothing", not "you may not
    // see this". The board is simply not theirs.
    if (typeof this.canAccessView === 'function' && !this.canAccessView('purchases')) return '';

    const dates = this.getAnalyticsDates();
    const dayKey = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    const from = dayKey(dates.start);
    const to = dayKey(dates.end);
    const branchFilter = this.selectedBranchFilter || 'ALL';
    const dayOf = p => String(p.order_date || p.created_at || '').slice(0, 10);

    const orders = (this.purchases || []).filter(p => {
      const d = dayOf(p);
      if (!d) return false;
      if (d < from || d > to) return false;
      if (branchFilter !== 'ALL' && String(p.branch_code || 'MAIN-01').toUpperCase() !== branchFilter.toUpperCase()) return false;
      return true;
    });

    if (orders.length === 0) {
      return `
        <div class="panel" style="margin-bottom: 1.25rem;">
          <div class="panel-header">
            <h3><i class="fa-solid fa-truck-ramp-box" style="color: #0369a1;"></i> Stock Bought In & Supplier Spend</h3>
            <span style="font-size: 0.78rem; color: var(--slate-500); font-weight: 500;">${this.escapeHtml(dates.label)}</span>
          </div>
          <div class="panel-body">
            <div style="text-align: center; color: var(--slate-400); font-weight: 600; font-size: 0.88rem; padding: 1rem 0;">
              <i class="fa-solid fa-truck" style="font-size: 1.4rem; display: block; margin-bottom: 0.4rem;"></i>
              No factory purchase order was recorded in this period.
            </div>
          </div>
        </div>
      `;
    }

    const shipping = orders.reduce((sum, p) => sum + Number(p.shipping_cost || 0), 0);
    // Goods and carriage apart, because purchases.php folds shipping_cost into total_cost
    // before it stores the order. Reading the order total as "into stock" and quoting the
    // carriage beside it showed the shop paying for its delivery twice.
    const orderTotal = orders.reduce((sum, p) => sum + Number(p.total_cost || 0), 0);
    const goodsIn = Math.round((orderTotal - shipping) * 100) / 100;
    const cashOut = orders.reduce((sum, p) => sum + Number(p.amount_paid || 0), 0);
    // Money the shop left at the factory on an earlier delivery and is now collecting in
    // goods. It is not cash out of the drawer, so it does not belong in the figure above,
    // but it does close the invoice - and one netted figure cannot say both, because taking
    // it off the net would credit the shop for money it already spent the moment the
    // overpayment that funded it falls in the same window. So the two directions are
    // counted per order and apart, the same way the supplier book keeps them.
    const drawnOut = orders.reduce((sum, p) => sum + Number(p.credit_used || 0), 0);
    let stillOwed = 0;
    let leftAtFactory = 0;
    orders.forEach(p => {
      const left = Math.round((Number(p.total_cost || 0) - Number(p.amount_paid || 0) - Number(p.credit_used || 0)) * 100) / 100;
      if (left > 0.005) stillOwed += left;
      else if (left < -0.005) leftAtFactory += -left;
    });
    const settled = Math.round(stillOwed * 100) / 100;
    const advanceHeld = Math.round(Math.max(0, leftAtFactory - drawnOut) * 100) / 100;

    // A supplier is owed the whole invoice, carriage included - the man who delivered is
    // paid for the delivery. So each row keeps the two halves apart for reading and adds
    // them back for the balance, rather than billing the goods and settling the invoice.
    const bySupplier = {};
    orders.forEach(p => {
      const key = String(p.supplier_name || 'One-Off Supplier').trim() || 'One-Off Supplier';
      const carry = Number(p.shipping_cost || 0);
      if (!bySupplier[key]) bySupplier[key] = { name: key, orders: 0, goods: 0, carriage: 0, billed: 0, paid: 0, drawn: 0 };
      bySupplier[key].orders++;
      bySupplier[key].goods += Number(p.total_cost || 0) - carry;
      bySupplier[key].carriage += carry;
      bySupplier[key].billed += Number(p.total_cost || 0);
      bySupplier[key].paid += Number(p.amount_paid || 0);
      bySupplier[key].drawn += Number(p.credit_used || 0);
    });
    const suppliers = Object.values(bySupplier).sort((a, b) => b.billed - a.billed);

    // Each product keeps its own loose unit: 120 eggs and 10 bags of rice do not add up to
    // "130" of anything, so the count is grouped per product rather than rolled into one.
    const byProduct = {};
    let linelessOrders = 0;
    orders.forEach(p => {
      const lines = this.purchaseSummaryLines(p);
      if (lines.length === 0) { linelessOrders++; return; }
      lines.forEach(l => {
        const key = l.name;
        if (!byProduct[key]) byProduct[key] = { name: key, units: 0, baseUnit: l.baseUnit };
        byProduct[key].units += l.loose;
      });
    });
    const products = Object.values(byProduct).sort((a, b) => b.units - a.units).slice(0, 6);

    return `
      <div class="panel" style="margin-bottom: 1.25rem;">
        <div class="panel-header">
          <h3><i class="fa-solid fa-truck-ramp-box" style="color: #0369a1;"></i> Stock Bought In & Supplier Spend</h3>
          <span style="font-size: 0.78rem; color: var(--slate-500); font-weight: 500;">${this.escapeHtml(dates.label)} &middot; ${orders.length} order(s)</span>
        </div>
        <div class="panel-body">
          <div style="display: flex; flex-wrap: wrap; gap: 1.5rem; margin-bottom: 1rem; font-size: 0.85rem;">
            <div>
              <div style="color: var(--slate-500); font-size: 0.74rem; text-transform: uppercase; letter-spacing: 0.04em;">Goods</div>
              <strong style="font-size: 1.15rem; font-family: monospace;">${this.formatCurrency(goodsIn)}</strong>
            </div>
            <div>
              <div style="color: var(--slate-500); font-size: 0.74rem; text-transform: uppercase; letter-spacing: 0.04em;">Carriage</div>
              <strong style="font-size: 1.15rem; font-family: monospace;">${this.formatCurrency(shipping)}</strong>
            </div>
            <div>
              <div style="color: var(--slate-500); font-size: 0.74rem; text-transform: uppercase; letter-spacing: 0.04em;">Billed</div>
              <strong style="font-size: 1.15rem; font-family: monospace;">${this.formatCurrency(orderTotal)}</strong>
            </div>
            <div>
              <div style="color: var(--slate-500); font-size: 0.74rem; text-transform: uppercase; letter-spacing: 0.04em;">Paid To Suppliers</div>
              <strong style="font-size: 1.15rem; font-family: monospace; color: #15803d;">${this.formatCurrency(cashOut)}</strong>
            </div>
            <div>
              <div style="color: var(--slate-500); font-size: 0.74rem; text-transform: uppercase; letter-spacing: 0.04em;">${settled > 0.005 ? 'Still To Pay' : 'Settled'}</div>
              <strong style="font-size: 1.15rem; font-family: monospace; color: ${settled > 0.005 ? '#dc2626' : '#15803d'}">${this.formatCurrency(settled)}</strong>
            </div>
            ${advanceHeld > 0.005 ? `
            <div>
              <div style="color: var(--slate-500); font-size: 0.74rem; text-transform: uppercase; letter-spacing: 0.04em;">Held With Suppliers</div>
              <strong style="font-size: 1.15rem; font-family: monospace; color: #0369a1;">${this.formatCurrency(advanceHeld)}</strong>
            </div>` : ''}
            ${drawnOut > 0.005 ? `
            <div>
              <div style="color: var(--slate-500); font-size: 0.74rem; text-transform: uppercase; letter-spacing: 0.04em;" title="Settled out of money an earlier order left with the factory, not out of today's drawer.">Drawn From Balances</div>
              <strong style="font-size: 1.15rem; font-family: monospace; color: #0369a1;">${this.formatCurrency(drawnOut)}</strong>
            </div>` : ''}
          </div>

          <div class="table-responsive" style="margin-bottom: ${products.length ? '1rem' : '0'};">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Factory / Supplier</th>
                  <th style="text-align: center;">Orders</th>
                  <th style="text-align: right;">Goods</th>
                  <th style="text-align: right;">Carriage</th>
                  <th style="text-align: right;">Billed</th>
                  <th style="text-align: right;">Paid</th>
                  <th style="text-align: right;">Balance</th>
                </tr>
              </thead>
              <tbody>
                ${suppliers.map(s => {
                  // What still runs against this supplier's name in the window: the invoice,
                  // less the cash handed over and less whatever was settled out of the money
                  // the shop already had sitting with him.
                  const left = Math.round((s.billed - s.paid - s.drawn) * 100) / 100;
                  return `
                    <tr>
                      <td style="font-weight: 600;">${this.escapeHtml(s.name)}</td>
                      <td style="text-align: center;">${s.orders}</td>
                      <td style="text-align: right; font-family: monospace;">${this.formatCurrency(s.goods)}</td>
                      <td style="text-align: right; font-family: monospace;">${this.formatCurrency(s.carriage)}</td>
                      <td style="text-align: right; font-family: monospace; font-weight: 600;">${this.formatCurrency(s.billed)}</td>
                      <td style="text-align: right; font-family: monospace; color: #15803d;">${this.formatCurrency(s.paid)}</td>
                      <td style="text-align: right; font-family: monospace; font-weight: 700; color: ${left > 0.005 ? '#dc2626' : (left < -0.005 ? '#0369a1' : 'var(--slate-400)')}">
                        ${left > 0.005 ? `owes ${this.formatCurrency(left)}` : (left < -0.005 ? `holds ${this.formatCurrency(Math.abs(left))}` : (s.drawn > 0.005 ? `settled &mdash; ${this.formatCurrency(s.drawn)} from balance` : 'settled'))}
                      </td>
                    </tr>`;
                }).join('')}
              </tbody>
            </table>
          </div>

          ${products.length > 0 ? `
            <div style="font-size: 0.76rem; color: var(--slate-500); text-transform: uppercase; letter-spacing: 0.04em; margin-bottom: 0.4rem;">Volume Bought In (loose units)</div>
            <div style="display: flex; flex-wrap: wrap; gap: 0.5rem;">
              ${products.map(pr => `
                <span class="badge badge-neutral" style="font-size: 0.78rem; padding: 0.35rem 0.6rem;">
                  ${this.escapeHtml(pr.name)}: <strong style="font-family: monospace;">${parseFloat(pr.units.toFixed(3))}</strong> ${this.escapeHtml(pr.baseUnit)}
                </span>`).join('')}
            </div>
          ` : ''}

          ${linelessOrders > 0 ? `
            <div style="margin-top: 0.75rem; font-size: 0.78rem; color: #b45309;">
              <i class="fa-solid fa-circle-exclamation"></i>
              ${linelessOrders} order(s) in this period reached this till without their item lines, so their quantities are left out of the volume above. Their money is counted.
            </div>
          ` : ''}
        </div>
      </div>
    `;
  }

  generateAnalyticsCustomerLoyaltySection() {
    const custStats = {};

    (this.sales || []).forEach(s => {
      const isNamed = s.customer_id && s.customer_id !== 'cust-walkin' && s.customer_name && s.customer_name !== 'Walk-in Customer';
      if (!isNamed) return;

      const key = s.customer_id || s.customer_name;
      if (!custStats[key]) {
        custStats[key] = {
          id: s.customer_id,
          name: s.customer_name,
          ordersCount: 0,
          totalSpent: 0,
          firstDate: null,
          lastDate: null
        };
      }

      const amt = Number(s.total_amount || 0);
      custStats[key].ordersCount++;
      custStats[key].totalSpent += amt;

      const d = new Date(String(s.sale_date || s.created_at).replace(' ', 'T'));
      if (!isNaN(d.getTime())) {
        if (!custStats[key].firstDate || d < custStats[key].firstDate) custStats[key].firstDate = d;
        if (!custStats[key].lastDate || d > custStats[key].lastDate) custStats[key].lastDate = d;
      }
    });

    const vips = Object.values(custStats).sort((a, b) => b.totalSpent - a.totalSpent);
    const totalVipSpend = vips.reduce((sum, c) => sum + c.totalSpent, 0);
    const repeatBuyersCount = vips.filter(c => c.ordersCount > 1).length;
    const memberById = {};
    (this.customers || []).forEach(c => { memberById[c.id] = c; });

    const getTierBadge = (cust) => {
      // The tier is the server's, taken from the points the member actually holds. Analytics used
      // to rank its own list by spend and label the top of it "Platinum VIP", so an owner could
      // read a badge next to a name the loyalty scheme had never heard of - and a shop that has
      // switched the scheme off, or a member who has no points, was still shown one.
      const member = memberById[cust.id];
      const tier = member ? String(member.loyalty_tier || '').toUpperCase() : '';
      const points = member ? Number(member.loyalty_points || 0) : 0;
      if (!tier || points <= 0) {
        return '<span class="badge badge-neutral" style="font-size:0.72rem;">Not on the scheme</span>';
      }
      const look = {
        PLATINUM: ['badge-tier-platinum', 'fa-crown', 'Platinum'],
        GOLD:     ['badge-tier-gold', 'fa-medal', 'Gold'],
        SILVER:   ['badge-tier-silver', 'fa-star', 'Silver'],
        BRONZE:   ['badge-tier-bronze', 'fa-shield', 'Bronze']
      }[tier] || ['badge-tier-bronze', 'fa-shield', tier.charAt(0) + tier.slice(1).toLowerCase()];
      return `<span class="${look[0]}" style="font-size:0.72rem;"><i class="fa-solid ${look[1]}"></i> ${this.escapeHtml(look[2])} &middot; ${points.toFixed(0)} pts</span>`;
    };

    return `
      <div class="panel" style="margin-bottom: 1.5rem;">
        <div class="panel-header">
          <div>
            <h3 style="margin: 0; font-size: 0.95rem; color: var(--slate-900); display: flex; align-items: center; gap: 0.5rem;">
              <i class="fa-solid fa-award" style="color: #ec4899;"></i> Customer Loyalty & VIP Lifetime Value (CLV)
            </h3>
            <span style="font-size: 0.76rem; color: var(--slate-500);">Repeat purchase frequency and highest spending accounts &middot; drawn from the whole ledger, not the period above</span>
          </div>
          <div style="display: flex; gap: 1rem; align-items: center; font-size: 0.78rem;">
            <span>Repeat Buyers: <strong>${repeatBuyersCount}</strong></span>
            <span>Total VIP Revenue: <strong style="color: var(--primary);">${this.formatCurrency(totalVipSpend)}</strong></span>
          </div>
        </div>
        <div class="panel-body" style="padding: 0;">
          ${vips.length > 0 ? `
            <div class="table-responsive">
              <table class="data-table">
                <thead>
                  <tr>
                    <th>Customer Name</th>
                    <th>Loyalty Tier</th>
                    <th style="text-align: right;">Total Orders</th>
                    <th style="text-align: right;">Lifetime Value (CLV)</th>
                    <th style="text-align: right;">Avg Order Value</th>
                    <th>Last Visit</th>
                    <th>Ledger</th>
                  </tr>
                </thead>
                <tbody>
                  ${vips.slice(0, 5).map(c => {
      const avg = c.ordersCount > 0 ? (c.totalSpent / c.ordersCount) : 0;
      return `
                      <tr>
                        <td>
                          <div style="font-weight: 700; color: var(--slate-900);">${this.escapeHtml(c.name)}</div>
                        </td>
                        <td>${getTierBadge(c)}</td>
                        <td style="text-align: right; font-weight: 700;">${c.ordersCount} visits</td>
                        <td style="text-align: right; font-weight: 800; color: var(--primary);">${this.formatCurrency(c.totalSpent)}</td>
                        <td style="text-align: right;">${this.formatCurrency(avg)}</td>
                        <td>
                          <span style="font-size: 0.76rem; color: var(--slate-600);">${c.lastDate ? c.lastDate.toLocaleDateString() : 'Recent'}</span>
                        </td>
                        <td>
                          <button class="btn btn-outline btn-sm" onclick="app.openCustomerStatementModal(${this.jsStr(c.id)})" style="font-size: 0.72rem; padding: 0.2rem 0.5rem;" title="View Statement of Account">
                            <i class="fa-solid fa-file-invoice"></i> Statement
                          </button>
                        </td>
                      </tr>
                    `;
    }).join('')}
                </tbody>
              </table>
            </div>
            ${vips.length > 5 ? `
              <div style="padding: 0.6rem 1rem; background: var(--slate-50); font-size: 0.76rem; color: var(--slate-600); border-top: 1px solid var(--slate-200); text-align: center;">
                Showing top 5 of ${vips.length} registered regular clients.
              </div>
            ` : ''}
          ` : `
            <div style="text-align: center; padding: 2.5rem; color: var(--slate-400);">
              <i class="fa-solid fa-users" style="font-size: 2rem; margin-bottom: 0.5rem; display: block;"></i>
              No named customer accounts recorded yet. Register walk-in buyers during checkout to track loyalty.
            </div>
          `}
        </div>
      </div>
    `;
  }

  getAnalyticsHTML() {
    const dates = this.getAnalyticsDates();
    const currentSales = this.filterSalesByRange(this.sales, dates.start, dates.end, this.analyticsUserFilter);
    const priorSales = this.filterSalesByRange(this.sales, dates.priorStart, dates.priorEnd, this.analyticsUserFilter);

    // A voided receipt is left out of every sum below, but it is named rather than hidden: an
    // owner who counts 40 receipts here against 44 slips out of the printer needs to be told
    // what the other four were and where their money went.
    const voidedInRange = this
      .filterSalesByRange(this.sales, dates.start, dates.end, this.analyticsUserFilter, null, true)
      .filter(s => this.isVoidedSale(s));
    const voidedCount = voidedInRange.length;
    const voidedValue = voidedInRange.reduce((sum, s) => sum + Number(s.total_amount || 0), 0);

    // Current metrics - refund-apportioned for 100% accounting accuracy with the dashboard
    const currentMetrics = currentSales.map(s => this.getSaleProfitMetrics(s));
    const rev = currentMetrics.reduce((sum, m) => sum + m.netRevenue, 0);
    const cost = currentMetrics.reduce((sum, m) => sum + m.netCost, 0);
    const profit = currentMetrics.reduce((sum, m) => sum + m.netProfit, 0);
    const totalRefunded = currentSales.reduce((sum, s) => sum + Number(s.refunded_amount || 0), 0);
    const txCount = currentSales.length;
    const avgBasket = txCount > 0 ? (rev / txCount) : 0;
    const margin = rev > 0 ? ((profit / rev) * 100).toFixed(1) : '0.0';

    // Prior metrics - refund-apportioned
    const priorMetrics = priorSales.map(s => this.getSaleProfitMetrics(s));
    const pRev = priorMetrics.reduce((sum, m) => sum + m.netRevenue, 0);
    const pProfit = priorMetrics.reduce((sum, m) => sum + m.netProfit, 0);
    const pTxCount = priorSales.length;
    const pAvgBasket = pTxCount > 0 ? (pRev / pTxCount) : 0;

    // Filter operating expenses for the active period & branch to derive Net Take-Home Profit
    const dayKey = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    const fromStr = dayKey(dates.start);
    const toStr = dayKey(dates.end);
    const branchFilter = this.selectedBranchFilter || 'ALL';
    const dayOfExp = e => String(e.expense_date || e.created_at || '').slice(0, 10);
    const filteredExpenses = (this.expenses || []).filter(e => {
      const d = dayOfExp(e);
      if (!d || d < fromStr || d > toStr) return false;
      if (branchFilter !== 'ALL' && String(e.branch_code || 'MAIN-01').toUpperCase() !== branchFilter.toUpperCase()) return false;
      return true;
    });
    const totalExpenses = filteredExpenses.reduce((sum, e) => sum + Number(e.amount || 0), 0);
    const netOperatingProfit = profit - totalExpenses;

    // Presets list
    const presets = [
      { id: 'today', label: 'Today' },
      { id: 'yesterday', label: 'Yesterday' },
      { id: 'last_7_days', label: 'Last 7 Days' },
      { id: 'this_month', label: 'This Month' },
      { id: 'last_month', label: 'Last Month' },
      { id: 'this_year', label: 'This Year' },
      { id: 'custom', label: 'Custom' }
    ];

    // Staff user options for filter
    const userOptions = [
      '<option value="ALL">All Attendants & Cashiers</option>',
      ...(this.users || []).map(u => {
        const val = u.full_name || u.username;
        const selected = this.analyticsUserFilter.toLowerCase() === val.toLowerCase() ? 'selected' : '';
        return `<option value="${this.escapeHtml(val)}" ${selected}>${this.escapeHtml(val)} (${this.escapeHtml(u.role_name || 'Staff')})</option>`;
      })
    ];

    // Multi-Branch options for filter
    const branchOptions = this.isMultiBranch ? [
      '<option value="ALL">All Branches (Consolidated)</option>',
      ...(this.branches || []).map(b => {
        const selected = (this.selectedBranchFilter || 'ALL').toUpperCase() === (b.branch_code || '').toUpperCase() ? 'selected' : '';
        return `<option value="${this.escapeHtml(b.branch_code)}" ${selected}>${this.escapeHtml(b.branch_code)} - ${this.escapeHtml(b.name)}</option>`;
      })
    ] : [];

    return `
      <div class="analytics-filter-bar">
        <div class="analytics-preset-chips">
          ${presets.map(p => `
            <button class="btn-chip-filter ${this.analyticsPreset === p.id ? 'active' : ''}" onclick="app.setAnalyticsPreset(${this.jsStr(p.id)})">
              ${p.label}
            </button>
          `).join('')}
        </div>

        <div class="analytics-filter-controls">
          <div class="analytics-date-inputs">
            <div style="display: flex; align-items: center; gap: 0.35rem;">
              <label for="analytics-start-date" style="font-size: 0.78rem; font-weight: 600; color: var(--slate-600);">From:</label>
              <input type="date" id="analytics-start-date" class="form-control" style="width: auto; padding: 0.35rem 0.5rem; font-size: 0.82rem;" value="${this.analyticsStartDate || dates.start.toISOString().slice(0, 10)}">
            </div>
            <div style="display: flex; align-items: center; gap: 0.35rem;">
              <label for="analytics-end-date" style="font-size: 0.78rem; font-weight: 600; color: var(--slate-600);">To:</label>
              <input type="date" id="analytics-end-date" class="form-control" style="width: auto; padding: 0.35rem 0.5rem; font-size: 0.82rem;" value="${this.analyticsEndDate || dates.end.toISOString().slice(0, 10)}">
            </div>
            ${this.isMultiBranch ? `
              <select id="analytics-branch-filter" class="form-control" style="width: auto; padding: 0.35rem 0.6rem; font-size: 0.82rem; font-weight: 600;" onchange="app.setAnalyticsBranchFilter(this.value)">
                ${branchOptions.join('')}
              </select>
            ` : ''}
            <select id="analytics-user-filter" class="form-control" style="width: auto; padding: 0.35rem 0.6rem; font-size: 0.82rem;">
              ${userOptions.join('')}
            </select>
          </div>

          <div style="display: flex; align-items: center; gap: 0.75rem;">
            <label style="display: flex; align-items: center; gap: 0.35rem; font-size: 0.78rem; color: var(--slate-700); cursor: pointer; user-select: none;">
              <input type="checkbox" id="analytics-toggle-compare" ${this.analyticsCompareWithPrior ? 'checked' : ''}>
              <span>Compare with prior period</span>
            </label>
            <button class="btn btn-outline btn-sm" onclick="app.exportAnalyticsCSV()" title="Export raw filtered transactions to CSV">
              <i class="fa-solid fa-file-csv"></i> Export CSV
            </button>
            <button class="btn btn-primary btn-sm" onclick="app.openAnalyticsReportModal()" title="Generate printable executive report">
              <i class="fa-solid fa-print"></i> Executive Report
            </button>
          </div>
        </div>

        <div style="margin-top: 0.75rem; font-size: 0.78rem; color: var(--slate-500); display: flex; align-items: center; justify-content: space-between;">
          <span>
            <strong>Active Range:</strong> ${this.escapeHtml(dates.label)}
            ${this.analyticsUserFilter !== 'ALL' ? ` · <strong>Attendant:</strong> ${this.escapeHtml(this.analyticsUserFilter)}` : ''}
            ${voidedCount > 0 ? ` · <strong style="color:#b91c1c;">${voidedCount} voided</strong> kept out of these figures (${this.formatCurrency(voidedValue)} handed back, goods restocked)` : ''}
          </span>
          ${this.analyticsCompareWithPrior ? `<span><strong>Comparing against:</strong> ${this.escapeHtml(dates.priorLabel)}</span>` : ''}
        </div>
      </div>

      ${(typeof this.isRentalsEnabled === 'function' && this.isRentalsEnabled()) ? `
        <div style="display:flex; justify-content:space-between; align-items:center; background:#faf5ff; border:1px solid #e9d5ff; border-radius:8px; padding:0.75rem 1.1rem; margin-bottom:1.25rem; flex-wrap:wrap; gap:0.6rem;">
          <div style="display:flex; align-items:center; gap:0.65rem;">
            <div style="width:34px; height:34px; border-radius:8px; background:#7c3aed; color:#fff; display:flex; align-items:center; justify-content:center; font-size:1rem;">
              <i class="fa-solid fa-boxes-packing"></i>
            </div>
            <div>
              <strong style="color:#581c87; font-size:0.88rem;">Event & Equipment Rental Analytics Active</strong>
              <div style="font-size:0.74rem; color:#7e22ce;">Track fleet deployment velocity, best performing hired gear, and venue demographics.</div>
            </div>
          </div>
          <button type="button" class="btn btn-sm btn-outline" onclick="app.switchView('rentals'); app.setRentalsFilter('analytics');" style="border-color:#a855f7; color:#7c3aed; font-weight:700; background:#fff;">
            <i class="fa-solid fa-chart-line"></i> View Fleet Analytics &amp; Rankings &rarr;
          </button>
        </div>
      ` : ''}

      <!-- KPI Comparative Stat Cards -->
      <div class="kpi-grid" style="margin-bottom: 1.25rem;">
        <div class="kpi-card">
          <div class="kpi-icon-wrapper kpi-blue">
            <i class="fa-solid fa-chart-line"></i>
          </div>
          <div class="kpi-info" style="flex: 1;">
            <h4>Gross Sales Revenue</h4>
            <p>${this.formatCurrency(rev)}</p>
            <div class="analytics-kpi-subtext">
              <span>Prior: ${this.formatCurrency(pRev)}</span>
              ${this.getAnalyticsGrowthBadge(rev, pRev)}
            </div>
          </div>
        </div>

        <div class="kpi-card">
          <div class="kpi-icon-wrapper kpi-green">
            <i class="fa-solid fa-arrow-trend-up"></i>
          </div>
          <div class="kpi-info" style="flex: 1;">
            <h4>Gross Profit</h4>
            <p>${this.formatCurrency(profit)}</p>
            <div class="analytics-kpi-subtext">
              <span>Margin: ${margin}% &middot; Net: <strong style="color: ${netOperatingProfit >= 0 ? '#15803d' : '#dc2626'};">${this.formatCurrency(netOperatingProfit)}</strong></span>
              ${totalExpenses > 0 ? `<span>&middot; Exp: ${this.formatCurrency(totalExpenses)}</span>` : ''}
              ${this.getAnalyticsGrowthBadge(profit, pProfit)}
            </div>
          </div>
        </div>

        <div class="kpi-card">
          <div class="kpi-icon-wrapper kpi-purple">
            <i class="fa-solid fa-receipt"></i>
          </div>
          <div class="kpi-info" style="flex: 1;">
            <h4>Completed Transactions</h4>
            <p>${txCount}</p>
            <div class="analytics-kpi-subtext">
              <span>Prior: ${pTxCount}</span>
              ${this.getAnalyticsGrowthBadge(txCount, pTxCount)}
            </div>
          </div>
        </div>

        <div class="kpi-card">
          <div class="kpi-icon-wrapper kpi-amber">
            <i class="fa-solid fa-basket-shopping"></i>
          </div>
          <div class="kpi-info" style="flex: 1;">
            <h4>Avg Basket Value</h4>
            <p>${this.formatCurrency(avgBasket)}</p>
            <div class="analytics-kpi-subtext">
              <span>Prior: ${this.formatCurrency(pAvgBasket)}</span>
              ${this.getAnalyticsGrowthBadge(avgBasket, pAvgBasket)}
            </div>
          </div>
        </div>
      </div>

      <!-- Row: Revenue Trend & Store Traffic Patterns (2-Column Grid) -->
      <div class="analytics-grid-2">
        <div class="chart-card" style="margin-bottom: 0;">
          <div class="chart-card-header">
            <h4><i class="fa-solid fa-chart-area" style="color: var(--primary);"></i> Revenue & Profit Velocity</h4>
            <div class="chart-legend">
              <div class="chart-legend-item">
                <span class="legend-dot" style="background-color: #2563eb;"></span>
                <span>Gross Revenue</span>
              </div>
              <div class="chart-legend-item">
                <span class="legend-dot" style="background-color: #10b981;"></span>
                <span>Gross Profit</span>
              </div>
            </div>
          </div>
          <div style="width: 100%; overflow: hidden; flex: 1; display: flex; align-items: center;">
            ${this.generateAnalyticsTrendChart(currentSales, dates.start, dates.end)}
          </div>
        </div>

        ${this.generateAnalyticsHourlyHeatmap(currentSales)}
      </div>

      <!-- Row: Tender Breakdown & Top Products -->
      <div class="analytics-grid-2">
        <div class="chart-card">
          <div class="chart-card-header">
            <h4><i class="fa-solid fa-credit-card" style="color: #8b5cf6;"></i> Payment Method Tender Breakdown</h4>
          </div>
          ${this.generateAnalyticsTenderChart(currentSales)}
        </div>

        <div class="chart-card">
          <div class="chart-card-header">
            <h4><i class="fa-solid fa-trophy" style="color: #f59e0b;"></i> Top 5 Products by Revenue</h4>
          </div>
          ${this.generateAnalyticsTopProducts(currentSales)}
        </div>
      </div>

      <!-- Department & Category Margin Breakdown -->
      <div class="panel" style="margin-bottom: 1.25rem;">
        <div class="panel-header">
          <h3><i class="fa-solid fa-layer-group" style="color: #10b981;"></i> Department & Category Margin Breakdown</h3>
          <span style="font-size: 0.78rem; color: var(--slate-500); font-weight: 500;">Gross profit contribution per inventory department</span>
        </div>
        <div class="panel-body">
          ${this.generateAnalyticsCategoryBreakdown(currentSales)}
        </div>
      </div>

      <!-- Staff / Attendant Comparative Matrix -->
      <div class="panel" style="margin-bottom: 1.25rem;">
        <div class="panel-header">
          <h3><i class="fa-solid fa-user-check" style="color: var(--primary);"></i> Staff & Attendant Comparative Performance</h3>
          <span style="font-size: 0.78rem; color: var(--slate-500); font-weight: 500;">Direct sales attribution per team member</span>
        </div>
        <div class="panel-body" style="padding: 0;">
          ${this.generateAnalyticsStaffTable(currentSales, rev)}
        </div>
      </div>

      <!-- Customer Demographics & Risk Analysis -->
      <div class="panel" style="margin-bottom: 1.25rem;">
        <div class="panel-header">
          <h3><i class="fa-solid fa-building-columns" style="color: #06b6d4;"></i> Customer Demographics & Accounts Receivable</h3>
          <span style="font-size: 0.78rem; color: var(--slate-500); font-weight: 500;">Buyer behavior and credit exposure</span>
        </div>
        <div class="panel-body">
          ${this.generateAnalyticsCustomerSummary(currentSales)}
        </div>
      </div>


      <!-- Customer Loyalty & VIP Lifetime Value (CLV) -->
      ${this.generateAnalyticsCustomerLoyaltySection()}

      <!-- Inventory & Ops: Dead Stock and Supplier Spend -->
      <!-- Dead Stock & Dormant Capital Alert -->
      ${this.generateAnalyticsDeadStockSection()}

      <!-- Stock Bought In & Supplier Spend -->
      ${this.generateAnalyticsPurchasingSection()}
    `;
  }

  bindAnalyticsEvents() {
    const startInput = document.getElementById('analytics-start-date');
    const endInput = document.getElementById('analytics-end-date');
    const userInput = document.getElementById('analytics-user-filter');
    const compareInput = document.getElementById('analytics-toggle-compare');

    if (startInput) {
      startInput.addEventListener('change', () => {
        this.analyticsPreset = 'custom';
        this.analyticsStartDate = startInput.value;
        this.renderCurrentView();
      });
    }

    if (endInput) {
      endInput.addEventListener('change', () => {
        this.analyticsPreset = 'custom';
        this.analyticsEndDate = endInput.value;
        this.renderCurrentView();
      });
    }

    if (userInput) {
      userInput.addEventListener('change', () => {
        this.analyticsUserFilter = userInput.value;
        this.renderCurrentView();
      });
    }

    if (compareInput) {
      compareInput.addEventListener('change', () => {
        this.analyticsCompareWithPrior = compareInput.checked;
        this.renderCurrentView();
      });
    }
  }

  setAnalyticsPreset(preset) {
    this.analyticsPreset = preset;
    const now = new Date();
    if (preset === 'today') {
      this.analyticsStartDate = now.toISOString().slice(0, 10);
      this.analyticsEndDate = now.toISOString().slice(0, 10);
    } else if (preset === 'yesterday') {
      const y = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
      this.analyticsStartDate = y.toISOString().slice(0, 10);
      this.analyticsEndDate = y.toISOString().slice(0, 10);
    } else {
      this.analyticsStartDate = '';
      this.analyticsEndDate = '';
    }
    this.renderCurrentView();
  }

  setAnalyticsBranchFilter(val) {
    this.selectedBranchFilter = val || 'ALL';
    this.renderCurrentView();
  }

  setAnalyticsTrafficTab(val) {
    this.analyticsTrafficTab = val || 'hourly';
    this.renderCurrentView();
  }

  openAnalyticsReportModal() {
    const dates = this.getAnalyticsDates();
    const currentSales = this.filterSalesByRange(this.sales, dates.start, dates.end, this.analyticsUserFilter);
    const rev = currentSales.reduce((sum, s) => sum + Number(s.total_amount || 0), 0);
    const profit = currentSales.reduce((sum, s) => sum + Number(s.gross_profit || 0), 0);
    const txCount = currentSales.length;
    const avgBasket = txCount > 0 ? (rev / txCount) : 0;
    const margin = rev > 0 ? ((profit / rev) * 100).toFixed(1) : '0.0';

    // Signed reports outlive the screen they came from, so the slips this report left out are
    // written on the page rather than left as an empty gap between it and the till roll.
    const voidedOnReport = this
      .filterSalesByRange(this.sales, dates.start, dates.end, this.analyticsUserFilter, null, true)
      .filter(s => this.isVoidedSale(s));

    const modal = document.getElementById('analytics-report-modal');
    const interactiveBody = document.getElementById('analytics-modal-interactive-body');
    const printableArea = document.getElementById('printable-analytics-area');
    if (!modal) return;

    let branchLabel = '';
    if (this.isMultiBranch) {
      if (this.selectedBranchFilter && this.selectedBranchFilter !== 'ALL') {
        const foundB = (this.branches || []).find(b => (b.branch_code || '').toUpperCase() === this.selectedBranchFilter.toUpperCase());
        branchLabel = foundB ? `${foundB.name} (${foundB.branch_code})` : this.selectedBranchFilter;
      } else {
        branchLabel = 'All Branches (Consolidated)';
      }
    }

    const reportContent = `
      <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; color: #0f172a; line-height: 1.45;">
        <!-- Header -->
        <div style="border-bottom: 2px solid #0f172a; padding-bottom: 0.85rem; margin-bottom: 1.25rem; display: flex; justify-content: space-between; align-items: flex-start;">
          <div style="display: flex; gap: 0.85rem; align-items: center;">
            <img src="${this.escapeHtml(this.getStoreLogo())}" alt="Logo" style="width: 48px; height: 48px; border-radius: 10px; object-fit: contain;">
            <div>
              <h2 style="margin: 0; font-size: 1.35rem; color: #0f172a; font-weight: 800;">${this.escapeHtml(this.storeProfile.store_name)}</h2>
              <div style="font-size: 0.82rem; color: #475569;">${this.escapeHtml(this.storeProfile.address || '')} · ${this.escapeHtml(this.storeProfile.phone || '')}</div>
              <div style="font-size: 0.85rem; font-weight: 700; color: #2563eb; margin-top: 0.35rem; text-transform: uppercase; letter-spacing: 0.05em;">
                Executive Sales & Comparative Analytics Report
              </div>
            </div>
          </div>
          <div style="text-align: right; font-size: 0.8rem; color: #475569;">
            ${this.isMultiBranch ? `<div><strong>Branch / Network:</strong> ${this.escapeHtml(branchLabel)}</div>` : ''}
            <div><strong>Report Period:</strong> ${this.escapeHtml(dates.label)}</div>
            <div><strong>Attendant Filter:</strong> ${this.escapeHtml(this.analyticsUserFilter === 'ALL' ? 'All Staff' : this.analyticsUserFilter)}</div>
            ${voidedOnReport.length > 0 ? `
              <div style="color:#b91c1c;"><strong>Voided receipts:</strong> ${voidedOnReport.length} · ${this.formatCurrency(voidedOnReport.reduce((sum, s) => sum + Number(s.total_amount || 0), 0))} handed back, excluded from every figure below</div>
            ` : ''}
            <div><strong>Generated:</strong> ${new Date().toLocaleString()}</div>
            <div><strong>Officer:</strong> ${this.escapeHtml(this.currentUser ? (this.currentUser.full_name || this.currentUser.username) : 'Administrator')}</div>
          </div>
        </div>

        <!-- KPI Summary Table -->
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 1.25rem;">
          <thead>
            <tr style="background: #f1f5f9;">
              <th style="padding: 0.5rem; text-align: left; font-size: 0.78rem; text-transform: uppercase;">Gross Revenue</th>
              <th style="padding: 0.5rem; text-align: left; font-size: 0.78rem; text-transform: uppercase;">Gross Profit</th>
              <th style="padding: 0.5rem; text-align: left; font-size: 0.78rem; text-transform: uppercase;">Profit Margin</th>
              <th style="padding: 0.5rem; text-align: left; font-size: 0.78rem; text-transform: uppercase;">Transactions</th>
              <th style="padding: 0.5rem; text-align: left; font-size: 0.78rem; text-transform: uppercase;">Avg Basket</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="padding: 0.6rem 0.5rem; font-size: 1.15rem; font-weight: 800; color: #0f172a; border-bottom: 1px solid #e2e8f0;">${this.formatCurrency(rev)}</td>
              <td style="padding: 0.6rem 0.5rem; font-size: 1.15rem; font-weight: 800; color: #15803d; border-bottom: 1px solid #e2e8f0;">+${this.formatCurrency(profit)}</td>
              <td style="padding: 0.6rem 0.5rem; font-size: 1.15rem; font-weight: 800; color: #0f172a; border-bottom: 1px solid #e2e8f0;">${margin}%</td>
              <td style="padding: 0.6rem 0.5rem; font-size: 1.15rem; font-weight: 800; color: #0f172a; border-bottom: 1px solid #e2e8f0;">${txCount}</td>
              <td style="padding: 0.6rem 0.5rem; font-size: 1.15rem; font-weight: 800; color: #0f172a; border-bottom: 1px solid #e2e8f0;">${this.formatCurrency(avgBasket)}</td>
            </tr>
          </tbody>
        </table>

        <!-- Staff Matrix Summary -->
        <h4 style="margin: 0 0 0.5rem 0; font-size: 0.95rem; font-weight: 700; color: #0f172a;">Staff & Attendant Comparative Breakdown</h4>
        ${this.generateAnalyticsStaffTable(currentSales, rev)}

        <div style="margin-top: 1.25rem;">
          <h4 style="margin: 0 0 0.5rem 0; font-size: 0.95rem; font-weight: 700; color: #0f172a;">Department & Category Margin Matrix</h4>
          ${this.generateAnalyticsCategoryBreakdown(currentSales)}
        </div>

        <div style="margin-top: 1.25rem;">
          <h4 style="margin: 0 0 0.5rem 0; font-size: 0.95rem; font-weight: 700; color: #0f172a;">Top 5 Best-Selling Products by Revenue</h4>
          ${this.generateAnalyticsTopProducts(currentSales)}
        </div>

        <div style="margin-top: 1.25rem;">
          <h4 style="margin: 0 0 0.5rem 0; font-size: 0.95rem; font-weight: 700; color: #0f172a;">Customer Demographics & Accounts Receivable</h4>
          ${this.generateAnalyticsCustomerSummary(currentSales)}
        </div>

        <div style="margin-top: 1.25rem;">
          ${this.generateAnalyticsDeadStockSection()}
        </div>

        <div style="margin-top: 1.25rem;">
          <h4 style="margin: 0 0 0.5rem 0; font-size: 0.95rem; font-weight: 700; color: #0f172a;">Stock Bought In & Supplier Spend</h4>
          ${this.generateAnalyticsPurchasingSection()}
        </div>

        <div style="margin-top: 2rem; border-top: 1px dashed #cbd5e1; padding-top: 0.75rem; font-size: 0.72rem; color: #64748b; display: flex; justify-content: space-between;">
          <span>StoreFlow Management System - Confidential Executive Report</span>
          <span>Sign-off: _______________________________</span>
        </div>
      </div>
    `;

    if (interactiveBody) interactiveBody.innerHTML = reportContent;
    if (printableArea) printableArea.innerHTML = reportContent;

    modal.classList.add('active');
  }

  closeAnalyticsReportModal() {
    const modal = document.getElementById('analytics-report-modal');
    if (modal) modal.classList.remove('active');
  }

  exportAnalyticsCSV() {
    const dates = this.getAnalyticsDates();
    // The export is what an accountant reconciles against the till roll, so the voided slips are
    // on the sheet rather than missing from it - with their money columns at nil, because a
    // column sum in a spreadsheet has no idea that a row marked VOID took nothing.
    const currentSales = this.filterSalesByRange(this.sales, dates.start, dates.end, this.analyticsUserFilter, null, true);

    if (currentSales.length === 0) {
      this.showToast('No sales records found for this period to export.', 'warning');
      return;
    }

    const headers = [
      'Receipt #',
      ...(this.isMultiBranch ? ['Branch Code'] : []),
      'Date & Time',
      'Attendant / Cashier',
      'Customer Name',
      'Items Count',
      'Subtotal',
      'Discount',
      'Total Revenue',
      'Total Cost',
      'Gross Profit',
      'Payment Method',
      'Status'
    ];

    const rows = currentSales.map(s => {
      const isVoidedRow = this.isVoidedSale(s);
      const m = this.getSaleProfitMetrics(s);
      const itemsCount = s.items ? s.items.reduce((sum, i) => sum + Number(i.quantity || 1), 0) : 1;
      return [
        `"${(s.receipt_number || '').replace(/"/g, '""')}"`,
        ...(this.isMultiBranch ? [`"${(s.branch_code || 'MAIN-01').replace(/"/g, '""')}"`] : []),
        `"${(s.sale_date || s.created_at || '').replace(/"/g, '""')}"`,
        `"${(s.attendant_name || s.cashier_name || '').replace(/"/g, '""')}"`,
        `"${(s.customer_name || 'Walk-in Customer').replace(/"/g, '""')}"`,
        itemsCount,
        isVoidedRow ? '0.00' : Number(s.subtotal || s.total_amount || 0).toFixed(2),
        isVoidedRow ? '0.00' : Number(s.discount || 0).toFixed(2),
        (isVoidedRow ? 0 : m.netRevenue).toFixed(2),
        (isVoidedRow ? 0 : m.netCost).toFixed(2),
        (isVoidedRow ? 0 : m.netProfit).toFixed(2),
        `"${(s.payment_method || 'CASH').replace(/"/g, '""')}"`,
        `"${(isVoidedRow ? 'VOIDED - restocked, no money taken' : (s.status || 'COMPLETED')).replace(/"/g, '""')}"`
      ];
    });

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(e => e.join(','))].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    const sDateStr = dates.start.toISOString().slice(0, 10);
    const eDateStr = dates.end.toISOString().slice(0, 10);
    link.setAttribute('download', `StoreFlow_Executive_Sales_${sDateStr}_to_${eDateStr}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    this.showToast(`Exported ${currentSales.length} records to CSV successfully.`, 'success');
  }

  // --- Toast Notifications (No alert) ---

  showToast(message, type = 'info', ms = 3500) {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;

    let icon = 'fa-circle-info';
    if (type === 'success') icon = 'fa-circle-check';
    if (type === 'danger') icon = 'fa-triangle-exclamation';
    if (type === 'warning') icon = 'fa-triangle-exclamation';

    toast.innerHTML = `<i class="fa-solid ${icon}"></i> <span></span>`;
    // Messages routinely quote stored values (product names, supplier notes, API
    // error text), so the span is filled as text rather than parsed as markup.
    toast.querySelector('span').textContent = String(message ?? '');
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      toast.style.transition = 'all 0.25s ease-out';
      setTimeout(() => toast.remove(), 250);
    }, Math.max(3500, Number(ms) || 3500));
  }
  // ==========================================================================
  // DIGITAL RECEIPTS & MNOTIFY SMS GATEWAY
  // ==========================================================================

  getFormattedReceiptText(sale) {
    if (!sale) return '';
    const prof = this.storeProfile || {};
    const storeName = prof.store_name || 'StoreFlow Mart';
    const currency = prof.currency_symbol || 'GHS';
    // A receipt sent to a phone becomes the customer's copy of the deal, so a void has to travel
    // with it - the same words on paper, in the chat and in the SMS.
    const isVoidedSlip = this.isVoidedSale(sale);

    let text = `🧾 ${storeName.toUpperCase()}\n`;
    if (prof.tagline) text += `${prof.tagline}\n`;
    if (prof.phone) text += `Tel: ${prof.phone}\n`;
    text += `--------------------------------\n`;
    text += `Receipt #: ${sale.receipt_number || 'N/A'}\n`;
    text += `Date: ${sale.sale_date || new Date().toLocaleString()}\n`;
    text += `Customer: ${sale.customer_name || 'Walk-in Customer'}\n`;
    if (isVoidedSlip) {
      text += `Status: ❌ VOIDED - not proof of purchase\n`;
      text += `Reason: ${String(sale.void_reason || 'No reason recorded')}\n`;
      text += `Cleared: ${sale.voided_at || 'today'}${sale.void_user_name ? ` by ${sale.void_user_name}` : ''}\n`;
    }
    text += `--------------------------------\n`;

    if (sale.items && sale.items.length) {
      sale.items.forEach(it => {
        const name = it.name || it.product_name || 'Item';
        const qty = it.quantity || 1;
        const price = Number(it.selling_price || it.unit_selling_price || 0).toFixed(2);
        const sub = (qty * price).toFixed(2);
        text += `• ${name}\n  ${qty} x ${currency} ${price} = ${currency} ${sub}\n`;
      });
    }

    text += `--------------------------------\n`;
    text += `Subtotal: ${currency} ${Number(sale.subtotal || 0).toFixed(2)}\n`;
    if (Number(sale.discount) > 0) {
      text += `Discount: -${currency} ${Number(sale.discount).toFixed(2)}\n`;
    }
    if (isVoidedSlip) {
      text += `Ringed: ${currency} ${Number(sale.total_amount || 0).toFixed(2)}\n`;
      text += `MONEY TAKEN: ${currency} 0.00\n`;
      text += `Payment: ${sale.payment_method || 'CASH'} (handed back)\n`;
      text += `Goods: back on the shelf\n`;
    } else {
      text += `TOTAL: ${currency} ${Number(sale.total_amount || 0).toFixed(2)}\n`;
      text += `Payment: ${sale.payment_method || 'CASH'}\n`;
      if (Number(sale.change_due) > 0) {
        text += `Change Due: ${currency} ${Number(sale.change_due).toFixed(2)}\n`;
      }
    }
    text += `--------------------------------\n`;
    text += `Served by: ${sale.attendant_name || 'Store Cashier'}\n`;
    text += isVoidedSlip
      ? `This receipt was VOIDED and booked nothing.`
      : `${prof.receipt_footer || 'Thank you for your business!'}`;
    return text;
  }

  // --- In-App Modern Prompt Dialog (Zero ugly browser prompts) ---

  showPromptModal({ title = 'Input Required', desc = '', label = 'Enter value', placeholder = '', defaultValue = '', hint = '', icon = 'fa-pen', confirmText = 'Continue' } = {}) {
    return new Promise((resolve) => {
      const modal = document.getElementById('app-prompt-modal');
      const titleEl = document.getElementById('prompt-modal-title');
      const descEl = document.getElementById('prompt-modal-desc');
      const labelEl = document.getElementById('prompt-modal-label');
      const inputEl = document.getElementById('prompt-modal-input');
      const hintEl = document.getElementById('prompt-modal-hint');
      const iconEl = document.getElementById('prompt-modal-icon');
      const confirmBtn = document.getElementById('prompt-modal-confirm');
      const confirmTextEl = document.getElementById('prompt-modal-confirm-text');
      const cancelBtn = document.getElementById('prompt-modal-cancel');

      if (!modal || !inputEl || !confirmBtn || !cancelBtn) {
        resolve(window.prompt(desc || title, defaultValue));
        return;
      }

      if (titleEl) titleEl.textContent = title;
      if (descEl) descEl.textContent = desc;
      if (labelEl) labelEl.textContent = label;
      if (confirmTextEl) confirmTextEl.textContent = confirmText;
      if (iconEl) iconEl.innerHTML = `<i class="fa-solid ${icon}"></i>`;
      if (hintEl) {
        if (hint) {
          hintEl.textContent = hint;
          hintEl.style.display = 'block';
        } else {
          hintEl.textContent = '';
          hintEl.style.display = 'none';
        }
      }

      inputEl.placeholder = placeholder;
      inputEl.value = defaultValue || '';

      const cleanup = () => {
        modal.classList.remove('active');
        inputEl.removeEventListener('keydown', handleKey);
        confirmBtn.removeEventListener('click', handleConfirm);
        cancelBtn.removeEventListener('click', handleCancel);
      };

      const handleConfirm = () => {
        const val = inputEl.value.trim();
        cleanup();
        resolve(val);
      };

      const handleCancel = () => {
        cleanup();
        resolve(null);
      };

      const handleKey = (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          handleConfirm();
        } else if (e.key === 'Escape') {
          e.preventDefault();
          handleCancel();
        }
      };

      confirmBtn.addEventListener('click', handleConfirm);
      cancelBtn.addEventListener('click', handleCancel);
      inputEl.addEventListener('keydown', handleKey);

      modal.classList.add('active');
      setTimeout(() => {
        inputEl.focus();
        inputEl.select();
      }, 50);
    });
  }

  // --- In-App Modern Confirmation Dialog (Zero ugly browser confirm popups) ---
  showConfirmModal({
    title = 'Are you sure?',
    message = 'Please confirm this action to proceed.',
    icon = 'fa-triangle-exclamation',
    confirmText = 'Yes, Proceed',
    cancelText = 'Cancel',
    confirmBtnClass = 'btn-danger'
  } = {}) {
    return new Promise((resolve) => {
      const modal = document.getElementById('app-confirm-modal');
      const titleEl = document.getElementById('confirm-modal-title');
      const msgEl = document.getElementById('confirm-modal-message');
      const iconEl = document.getElementById('confirm-modal-icon');
      const iconWrapper = document.getElementById('confirm-modal-icon-wrapper');
      const confirmBtn = document.getElementById('confirm-modal-confirm');
      const confirmTextEl = document.getElementById('confirm-modal-confirm-text');
      const cancelBtn = document.getElementById('confirm-modal-cancel');

      if (!modal || !confirmBtn || !cancelBtn) {
        resolve(window.confirm(message || title));
        return;
      }

      if (titleEl) titleEl.textContent = title;
      if (msgEl) msgEl.textContent = message;
      if (confirmTextEl) confirmTextEl.textContent = confirmText;
      if (iconEl) iconEl.className = `fa-solid ${icon}`;

      // Update button color based on confirmBtnClass
      confirmBtn.className = `btn ${confirmBtnClass}`;

      // Theme icon wrapper for danger vs primary/info
      if (iconWrapper) {
        if (confirmBtnClass.includes('danger')) {
          iconWrapper.style.background = '#fee2e2';
          iconWrapper.style.color = '#dc2626';
        } else if (confirmBtnClass.includes('primary') || confirmBtnClass.includes('info')) {
          iconWrapper.style.background = '#e0f2fe';
          iconWrapper.style.color = '#0284c7';
        } else {
          iconWrapper.style.background = '#fef3c7';
          iconWrapper.style.color = '#d97706';
        }
      }

      const cleanup = () => {
        modal.classList.remove('active');
        confirmBtn.removeEventListener('click', handleConfirm);
        cancelBtn.removeEventListener('click', handleCancel);
        document.removeEventListener('keydown', handleKey);
      };

      const handleConfirm = () => {
        cleanup();
        resolve(true);
      };

      const handleCancel = () => {
        cleanup();
        resolve(false);
      };

      const handleKey = (e) => {
        if (e.key === 'Escape') {
          e.preventDefault();
          handleCancel();
        } else if (e.key === 'Enter') {
          e.preventDefault();
          handleConfirm();
        }
      };

      confirmBtn.addEventListener('click', handleConfirm);
      cancelBtn.addEventListener('click', handleCancel);
      document.addEventListener('keydown', handleKey);

      modal.classList.add('active');
    });
  }

  async shareReceiptViaWhatsApp() {
    if (!this.currentSaleForReceipt) {
      this.showToast('No receipt data available to share.', 'warning');
      return;
    }
    const sale = this.currentSaleForReceipt;
    let customerPhone = sale.customer_phone || '';
    if (!customerPhone && sale.customer_id) {
      const cust = (this.customers || []).find(c => c.id === sale.customer_id);
      if (cust && cust.phone) customerPhone = cust.phone;
    }

    let phone = customerPhone ? customerPhone.replace(/[^0-9]/g, '') : '';
    if (!phone) {
      const input = await this.showPromptModal({
        title: 'Share Receipt via WhatsApp',
        desc: `Send formatted receipt for Receipt #${sale.receipt_number} directly to customer's WhatsApp chat.`,
        label: 'Customer WhatsApp Mobile Number',
        placeholder: 'e.g. 233244123456 or 0244123456',
        defaultValue: customerPhone || '',
        hint: 'Format: 024XXXXXXX or 233XXXXXXXXX',
        icon: 'fa-brands fa-whatsapp',
        confirmText: 'Open WhatsApp'
      });
      if (input === null || !input.trim()) return;
      phone = input.replace(/[^0-9]/g, '');
    }

    const text = this.getFormattedReceiptText(sale);
    const encoded = encodeURIComponent(text);

    if (phone) {
      window.open(`https://wa.me/${phone}?text=${encoded}`, '_blank');
    } else {
      window.open(`https://api.whatsapp.com/send?text=${encoded}`, '_blank');
    }
  }

  async sendReceiptViaSMS() {
    // A. Customer Debt Settlement Receipt
    if (this.currentPaymentReceipt) {
      const p = this.currentPaymentReceipt;
      const phone = await this.showPromptModal({
        title: 'Send Debt SMS Receipt (mNotify)',
        desc: `Send instant digital debt payment receipt to customer for ${this.formatCurrency(p.amount_paid)} (Receipt #${p.receipt_number}).`,
        label: 'Customer Mobile Phone Number',
        placeholder: 'e.g. 0244123456 or 233244123456',
        defaultValue: p.customer_phone || '',
        hint: 'Format: 024XXXXXXX or 233XXXXXXXXX',
        icon: 'fa-comment-sms',
        confirmText: 'Send Debt SMS'
      });
      if (!phone) return;

      try {
        this.showToast('Sending debt repayment SMS via mNotify...', 'info');
        const res = await this.apiFetch('api/endpoints/sms.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'send_debt_receipt',
            recipient: phone.trim(),
            customer_name: p.customer_name,
            receipt_number: p.receipt_number,
            amount_paid: Number(p.amount_paid || 0).toFixed(2),
            prev_balance: Number(p.prev_balance || 0).toFixed(2),
            new_balance: Number(p.new_balance || 0).toFixed(2),
            payment_method: p.payment_method
          })
        });
        const data = await res.json();
        if (data.success) {
          this.showToast(data.message || 'Debt payment SMS receipt sent successfully via mNotify!', 'success');
        } else {
          this.showToast(data.message || 'Failed to send debt payment SMS.', 'danger');
        }
      } catch (err) {
        this.showToast('SMS network error: ' + err.message, 'danger');
      }
      return;
    }

    // B. Merchandise Return / Credit Note Receipt
    if (this.currentReturnForReceipt) {
      const r = this.currentReturnForReceipt;
      const phone = await this.showPromptModal({
        title: 'Send Return SMS (mNotify)',
        desc: `Send return credit note SMS for Return #${r.return_number} (Refund: ${this.formatCurrency(r.total_refund_amount)}).`,
        label: 'Customer Mobile Phone Number',
        placeholder: 'e.g. 0244123456 or 233244123456',
        defaultValue: r.customer_phone || '',
        hint: 'Format: 024XXXXXXX or 233XXXXXXXXX',
        icon: 'fa-comment-sms',
        confirmText: 'Send Return SMS'
      });
      if (!phone) return;

      try {
        this.showToast('Sending return SMS via mNotify...', 'info');
        const res = await this.apiFetch('api/endpoints/sms.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'send_return_receipt',
            recipient: phone.trim(),
            customer_name: r.customer_name,
            return_number: r.return_number,
            receipt_number: r.receipt_number,
            total_refund: Number(r.total_refund_amount || 0).toFixed(2),
            refund_method: r.refund_method,
            items_summary: (r.items || []).map(i => `${i.product_name || i.name} (x${i.quantity})`).join(', ')
          })
        });
        const data = await res.json();
        if (data.success) {
          this.showToast(data.message || 'Return SMS receipt sent successfully!', 'success');
        } else {
          this.showToast(data.message || 'Failed to send return SMS.', 'danger');
        }
      } catch (err) {
        this.showToast('SMS network error: ' + err.message, 'danger');
      }
      return;
    }

    // C. POS Sales Receipt
    if (!this.currentSaleForReceipt) {
      this.showToast('No receipt data available to send.', 'warning');
      return;
    }
    const sale = this.currentSaleForReceipt;
    let customerPhone = sale.customer_phone || '';
    if (!customerPhone && sale.customer_id) {
      const cust = (this.customers || []).find(c => c.id === sale.customer_id);
      if (cust && cust.phone) customerPhone = cust.phone;
    }

    const phone = await this.showPromptModal({
      title: 'Send SMS Receipt (mNotify)',
      desc: `Send instant digital SMS receipt for Receipt #${sale.receipt_number} (Total: ${this.formatCurrency(sale.total_amount)}).`,
      label: 'Customer Mobile Phone Number',
      placeholder: 'e.g. 0244123456 or 233244123456',
      defaultValue: customerPhone || '',
      hint: 'Format: 024XXXXXXX or 233XXXXXXXXX',
      icon: 'fa-comment-sms',
      confirmText: 'Send SMS Receipt'
    });
    if (!phone) return;

    try {
      this.showToast('Sending SMS receipt via mNotify...', 'info');
      const res = await this.apiFetch('api/endpoints/sms.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'send_receipt',
          recipient: phone.trim(),
          receipt_number: sale.receipt_number,
          total_amount: Number(sale.total_amount || 0).toFixed(2),
          payment_method: sale.payment_method
        })
      });
      const data = await res.json();
      if (data.success) {
        this.showToast(data.message || 'SMS receipt sent successfully via mNotify!', 'success');
      } else {
        this.showToast(data.message || 'Failed to send SMS receipt.', 'danger');
      }
    } catch (err) {
      this.showToast('SMS network error: ' + err.message, 'danger');
    }
  }

  async shareReceiptNative() {
    if (!this.currentSaleForReceipt) return;
    const text = this.getFormattedReceiptText(this.currentSaleForReceipt);
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Receipt #${this.currentSaleForReceipt.receipt_number}`,
          text: text
        });
      } catch (e) {
        if (e.name !== 'AbortError') console.warn('Native share failed:', e);
      }
    } else if (navigator.clipboard) {
      await navigator.clipboard.writeText(text);
      this.showToast('Receipt copied to clipboard! You can paste into SMS, WhatsApp, or email.', 'success');
    } else {
      this.showToast('Sharing is not supported on this browser.', 'warning');
    }
  }

  async testMNotifySMS() {
    const key = document.getElementById('prof-mnotify-api-key')?.value.trim();
    const sender = document.getElementById('prof-mnotify-sender-id')?.value.trim() || 'StoreFlow';
    const testPhone = await this.showPromptModal({
      title: 'mNotify SMS Integration Test',
      desc: 'Enter your mobile phone number to receive a live verification SMS from your mNotify account.',
      label: 'Recipient Mobile Number',
      placeholder: 'e.g. 0244123456 or 233244123456',
      defaultValue: this.storeProfile?.phone || '',
      hint: 'Format: 024XXXXXXX or 233XXXXXXXXX',
      icon: 'fa-paper-plane',
      confirmText: 'Send Test SMS'
    });
    if (!testPhone) return;

    try {
      this.showToast('Dispatching test SMS via mNotify...', 'info');
      const res = await this.apiFetch('api/endpoints/sms.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'test_sms',
          api_key: (key && key !== '********') ? key : undefined,
          sender_id: sender,
          recipient: testPhone.trim()
        })
      });
      const data = await res.json();
      if (data.success) {
        this.showToast(data.message || 'Test SMS sent successfully!', 'success');
      } else {
        this.showToast(data.message || 'mNotify test failed.', 'danger');
      }
    } catch (err) {
      this.showToast('mNotify test error: ' + err.message, 'danger');
    }
  }

  // ==========================================================================
  // BARCODE & SHELF LABEL PRINTING STUDIO
  // ==========================================================================

  openBarcodeLabelModal(targetProductId = null) {
    const modal = document.getElementById('barcode-label-modal');
    const select = document.getElementById('barcode-prod-select');
    if (!modal || !select) return;

    select.innerHTML = `
      <option value="__ALL__">All Active Products (Batch Print)</option>
      ${this.products.map(p => `
        <option value="${this.escapeHtml(p.id)}" ${p.id === targetProductId ? 'selected' : ''}>
          ${this.escapeHtml(p.name)} (${this.escapeHtml(p.barcode || p.sku || 'No code')}) - ${this.formatCurrency(p.selling_price)}
        </option>
      `).join('')}
    `;

    if (targetProductId) {
      select.value = targetProductId;
    } else if (select.options.length > 1) {
      select.selectedIndex = 1;
    }

    modal.classList.add('active');
    this.rebuildBarcodeLabelSizes();
  }

  // The size list belongs to the product currently chosen, so it is rebuilt whenever the
  // product changes rather than being read at print time.
  rebuildBarcodeLabelSizes() {
    const sizeSelect = document.getElementById('barcode-unit-select');
    if (!sizeSelect) return;
    const product = this.getBarcodeLabelSelection();
    const sizes = product ? this.productUnitsOf(product) : [];
    sizeSelect.innerHTML = `
      <option value="__ALL__">Every size it answers to</option>
      ${sizes.map(u => `
        <option value="${this.escapeHtml(u.unit_name)}">
          ${this.escapeHtml(u.unit_name)}${u.is_base ? ' (loose)' : ` (${this.escapeHtml(String(u.size_in_base))} loose)`}
        </option>
      `).join('')}
    `;
    // Left on "every size": a shop opening the studio from a product with three sizes
    // wants the whole sheet, and the preview tells them how many stickers that is before
    // anything reaches the printer.
    sizeSelect.selectedIndex = 0;
    this.renderBarcodeLabelPreview();
  }

  getBarcodeLabelSelection() {
    const select = document.getElementById('barcode-prod-select');
    const selectedId = select?.value;
    if (!selectedId || selectedId === '__ALL__') return null;
    return this.products.find(p => p.id === selectedId) || null;
  }

  // One label per size that answers to a number of its own. A pack with no code typed for
  // it is deliberately not given the loose unit's code to wear: a sticker carrying the
  // egg's number on a crate is how a shop ends up charging egg money for thirty of them.
  barcodeLabelTargets(products, sizeFilter = '__ALL__') {
    const wanted = String(sizeFilter || '__ALL__').toLowerCase();
    const targets = [];
    for (const p of products) {
      const basePrice = Number(p.selling_price || 0);
      const looseCode = String(p.barcode || p.sku || '').trim();
      const units = this.productUnitsOf(p);
      const looseName = (units.find(x => x.is_base) || { unit_name: p.unit || 'pcs' }).unit_name;
      for (const u of units) {
        const ownCode = String(u.barcode || '').trim();
        const code = u.is_base && ownCode === '' ? looseCode : ownCode;
        if (code === '') continue;
        if (wanted !== '__all__' && u.unit_name.toLowerCase() !== wanted) continue;
        targets.push({
          product: p,
          unit: u,
          code,
          price: this.productUnitPrice(u, basePrice),
          baseUnit: looseName
        });
      }
    }
    return targets;
  }

  closeBarcodeLabelModal() {
    const modal = document.getElementById('barcode-label-modal');
    if (modal) modal.classList.remove('active');
  }

  renderBarcodeLabelPreview() {
    const previewContainer = document.getElementById('barcode-preview-grid');
    if (!previewContainer) return;

    const layout = document.getElementById('barcode-layout-select')?.value || 'A4-24';
    const rawQty = parseInt(document.getElementById('barcode-label-qty')?.value, 10);
    const qty = Math.max(1, Math.min(200, isNaN(rawQty) ? 24 : rawQty));

    const showStore = document.getElementById('barcode-opt-store-name')?.checked ?? true;
    const showName = document.getElementById('barcode-opt-prod-name')?.checked ?? true;
    const showPrice = document.getElementById('barcode-opt-price')?.checked ?? true;
    const showDigits = document.getElementById('barcode-opt-digits')?.checked ?? true;

    const prof = this.storeProfile || {};
    const storeName = prof.store_name || 'StoreFlow';

    const selectedId = document.getElementById('barcode-prod-select')?.value;
    const sizeFilter = document.getElementById('barcode-unit-select')?.value || '__ALL__';
    const isBatch = selectedId === '__ALL__' || !selectedId;

    const targets = isBatch
      ? this.barcodeLabelTargets(this.products, '__ALL__')
      : this.barcodeLabelTargets([this.getBarcodeLabelSelection()].filter(Boolean), sizeFilter);

    // A run of stickers for one size: the shop printed forty crate talkers, not one.
    const labelled = isBatch ? targets : targets.flatMap(t => Array.from({ length: qty }, () => t));

    if (labelled.length === 0) {
      previewContainer.innerHTML = `
        <div style="text-align: center; padding: 3rem 1rem; color: var(--slate-400);">
          <i class="fa-solid fa-barcode" style="font-size: 2.5rem; margin-bottom: 0.75rem; opacity: 0.4;"></i>
          <p style="font-weight: 600;">No label to print: nothing here answers to a code of its own.</p>
        </div>
      `;
      return;
    }

    let gridClass = 'layout-a4-24';
    if (layout === 'A4-30') gridClass = 'layout-a4-30';
    if (layout === 'THERMAL-50') gridClass = 'layout-thermal';
    if (layout === 'SHELF-TAG') gridClass = 'layout-shelf';

    previewContainer.className = `barcode-sheet-grid ${gridClass}`;

    previewContainer.innerHTML = labelled.map((t, idx) => {
      const svgId = `barcode-svg-${idx}`;
      const p = t.product;
      const priceStr = this.formatCurrency(t.price || 0);
      const sizeName = String(t.unit.unit_name || '').trim();
      const isPack = !t.unit.is_base;
      const labelName = isPack ? `${p.name} (${sizeName})` : p.name;
      const holds = isPack
        ? `${parseFloat(Number(t.unit.size_in_base).toFixed(3))} ${t.baseUnit}` : '';

      if (layout === 'SHELF-TAG') {
        return `
          <div class="barcode-label-card shelf-tag">
            ${showStore ? `<div class="label-store-name">${this.escapeHtml(storeName)}</div>` : ''}
            ${showName ? `<div class="label-prod-name" style="font-size: 0.95rem;">${this.escapeHtml(labelName)}</div>` : ''}
            ${showPrice ? `
              <div class="shelf-price-display">${priceStr}</div>
              <div style="font-size: 0.72rem; color: #64748b; font-weight: 600; text-transform: uppercase;">
                Per ${this.escapeHtml(sizeName)}${holds ? ` (${this.escapeHtml(holds)})` : ''}
              </div>
            ` : ''}
            <svg id="${svgId}" class="barcode-svg" style="max-height: 42px; margin-top: 4px;"></svg>
          </div>
        `;
      }

      return `
        <div class="barcode-label-card">
          ${showStore ? `<div class="label-store-name">${this.escapeHtml(storeName)}</div>` : ''}
          ${showName ? `<div class="label-prod-name">${this.escapeHtml(labelName)}${holds ? `<span style="font-size: 0.8rem; font-weight: 600; color: #64748b;"> · ${this.escapeHtml(holds)}</span>` : ''}</div>` : ''}
          ${showPrice ? `<div class="label-price">${priceStr}</div>` : ''}
          <svg id="${svgId}" class="barcode-svg"></svg>
        </div>
      `;
    }).join('');

    // Generate SVG barcodes with JsBarcode
    labelled.forEach((t, idx) => {
      const svgEl = document.getElementById(`barcode-svg-${idx}`);
      if (!svgEl) return;
      const code = String(t.code || '000000').trim();

      let format = 'CODE128';
      const cleanDigits = code.replace(/[^0-9]/g, '');
      if (cleanDigits.length === 13 && cleanDigits === code) {
        format = 'EAN13';
      } else if (cleanDigits.length === 12 && cleanDigits === code) {
        format = 'UPC';
      } else if (cleanDigits.length === 8 && cleanDigits === code) {
        format = 'EAN8';
      }

      try {
        if (typeof JsBarcode !== 'undefined') {
          JsBarcode(svgEl, code, {
            format: format,
            width: layout === 'THERMAL-50' ? 1.6 : 1.3,
            height: layout === 'SHELF-TAG' ? 36 : (layout === 'THERMAL-50' ? 38 : 32),
            displayValue: showDigits,
            fontSize: 10,
            font: 'monospace',
            textMargin: 1,
            margin: 2
          });
        }
      } catch (err) {
        try {
          JsBarcode(svgEl, code, {
            format: 'CODE128',
            width: 1.2,
            height: 32,
            displayValue: showDigits,
            fontSize: 10,
            margin: 2
          });
        } catch (e) {
          svgEl.outerHTML = `<div style="font-family: monospace; font-size: 0.8rem; font-weight: 700; color: #dc2626;">[${this.escapeHtml(code)}]</div>`;
        }
      }
    });
  }

  printBarcodeLabels() {
    document.body.classList.add('printing-barcode-labels');
    window.print();
    setTimeout(() => {
      document.body.classList.remove('printing-barcode-labels');
    }, 500);
  }

  // ==========================================================================
  // PHYSICAL STOCKTAKE & INVENTORY AUDIT STUDIO
  // ==========================================================================

  openStockAuditModal() {
    const modal = document.getElementById('stock-audit-modal');
    const branchSelect = document.getElementById('stock-audit-branch-select');
    if (!modal) return;

    if (branchSelect) {
      if (this.isMultiBranch && this.branches && this.branches.length > 0) {
        branchSelect.innerHTML = this.branches.map(b => `
          <option value="${this.escapeHtml(b.branch_code)}" ${b.branch_code === (this.stockAuditBranch || this.branchCode || 'MAIN-01') ? 'selected' : ''}>
            ${this.escapeHtml(b.name)} (${this.escapeHtml(b.branch_code)})
          </option>
        `).join('');
        this.stockAuditBranch = branchSelect.value;
      } else {
        branchSelect.innerHTML = `<option value="MAIN-01">Main Storefront (MAIN-01)</option>`;
        this.stockAuditBranch = 'MAIN-01';
      }
    }

    if (!this.stockAuditItems) {
      this.stockAuditItems = [];
    }

    modal.classList.add('active');
    this.renderStockAuditList();
  }

  closeStockAuditModal() {
    const modal = document.getElementById('stock-audit-modal');
    if (modal) modal.classList.remove('active');
  }

  onStockAuditBranchChange() {
    const sel = document.getElementById('stock-audit-branch-select');
    if (sel) {
      this.stockAuditBranch = sel.value;
      if (this.stockAuditItems && this.stockAuditItems.length > 0) {
        this.stockAuditItems.forEach(item => {
          const rawP = this.products.find(p => p.id === item.product_id);
          if (rawP) {
            const eff = this.getEffectiveProductForBranch(rawP);
            item.system_qty = Number(eff.effectiveStock || 0);
            item.variance = item.counted_qty - item.system_qty;
          }
        });
      }
      this.renderStockAuditList();
    }
  }

  onStockAuditSearch(event) {
    const query = (event.target?.value || '').trim();
    if (!query) return;

    if (event.key === 'Enter' || query.length >= 8) {
      this.handleStockAuditBarcodeScan(query);
      event.target.value = '';
    }
  }

  addAllProductsToAudit() {
    if (!this.products || this.products.length === 0) return;
    this.stockAuditItems = this.products.map(rawP => {
      const eff = this.getEffectiveProductForBranch(rawP);
      const systemStock = Number(eff.effectiveStock || 0);
      return {
        product_id: rawP.id,
        name: rawP.name,
        sku: rawP.sku,
        barcode: rawP.barcode,
        unit: rawP.unit || 'pcs',
        cost_price: Number(rawP.cost_price || 0),
        selling_price: Number(rawP.selling_price || 0),
        image_url: rawP.image_url || 'assets/images/products/placeholder.svg',
        system_qty: systemStock,
        counted_qty: 0,
        variance: 0 - systemStock
      };
    });
    this.renderStockAuditList();
    this.showToast(`Loaded ${this.stockAuditItems.length} products into audit sheet.`, 'info');
  }

  handleStockAuditBarcodeScan(code) {
    if (!code) return;
    const clean = code.trim().toLowerCase();
    const compactCode = clean.replace(/[\s\-_]/g, '');

    const product = this.products.find(p => {
      const pBarcode = (p.barcode || '').trim().toLowerCase();
      const pBarcodeCompact = pBarcode.replace(/[\s\-_]/g, '');
      const pSku = (p.sku || '').trim().toLowerCase();
      const pSkuCompact = pSku.replace(/[\s\-_]/g, '');
      const pName = (p.name || '').trim().toLowerCase();
      return (
        pBarcode === clean || (compactCode && pBarcodeCompact === compactCode) ||
        pSku === clean || (compactCode && pSkuCompact === compactCode) ||
        pName === clean
      );
    });

    if (!product) {
      this.playErrorSound();
      this.showToast(`No product found matching code: "${code}"`, 'warning');
      return;
    }

    if (!this.stockAuditItems) this.stockAuditItems = [];
    let item = this.stockAuditItems.find(i => i.product_id === product.id);

    if (item) {
      item.counted_qty += 1;
      item.variance = item.counted_qty - item.system_qty;
    } else {
      const eff = this.getEffectiveProductForBranch(product);
      const systemStock = Number(eff.effectiveStock || 0);
      item = {
        product_id: product.id,
        name: product.name,
        sku: product.sku,
        barcode: product.barcode,
        unit: product.unit || 'pcs',
        cost_price: Number(product.cost_price || 0),
        selling_price: Number(product.selling_price || 0),
        image_url: product.image_url || 'assets/images/products/placeholder.svg',
        system_qty: systemStock,
        counted_qty: 1,
        variance: 1 - systemStock
      };
      this.stockAuditItems.unshift(item);
    }

    this.playBeepSound(1400);
    this.renderStockAuditList();

    const badge = document.getElementById('scanner-status-badge');
    if (badge && this.isScannerRunning) {
      badge.innerHTML = `<i class="fa-solid fa-circle-check" style="color: #22c55e;"></i> Counted: <strong>${this.escapeHtml(product.name)}</strong> (Count: ${item.counted_qty})`;
      setTimeout(() => {
        if (badge && this.isScannerRunning) {
          badge.innerHTML = '<i class="fa-solid fa-camera"></i> Align next barcode inside the guide';
        }
      }, 1000);
    }
  }

  updateStockAuditCount(productId, deltaOrVal, isAbsolute = false) {
    if (!this.stockAuditItems) return;
    const item = this.stockAuditItems.find(i => i.product_id === productId);
    if (!item) return;

    if (isAbsolute) {
      item.counted_qty = Math.max(0, parseFloat(deltaOrVal) || 0);
    } else {
      item.counted_qty = Math.max(0, item.counted_qty + deltaOrVal);
    }
    item.variance = item.counted_qty - item.system_qty;
    this.renderStockAuditList();
  }

  renderStockAuditList() {
    const container = document.getElementById('stock-audit-items-container');
    if (!container) return;

    const items = this.stockAuditItems || [];

    let matches = 0;
    let variances = 0;
    items.forEach(it => {
      if (it.variance === 0) matches++;
      else variances++;
    });

    const statTotal = document.getElementById('audit-stat-total');
    const statMatches = document.getElementById('audit-stat-matches');
    const statVariances = document.getElementById('audit-stat-variances');
    if (statTotal) statTotal.textContent = items.length;
    if (statMatches) statMatches.textContent = matches;
    if (statVariances) statVariances.textContent = variances;

    if (items.length === 0) {
      container.innerHTML = `
        <div style="text-align: center; padding: 3.5rem 1rem; color: var(--slate-400);">
          <i class="fa-solid fa-barcode" style="font-size: 3rem; margin-bottom: 0.85rem; opacity: 0.35;"></i>
          <h4 style="margin: 0; color: var(--slate-600); font-weight: 700;">No items scanned in this stocktake yet</h4>
          <p style="font-size: 0.85rem; margin: 0.35rem 0 1.25rem 0;">Tap "Scan Barcode With Phone" above or search by product name/SKU to start counting shelf inventory.</p>
          <button class="btn btn-primary btn-sm" onclick="app.openCameraScanner('stock-audit')">
            <i class="fa-solid fa-camera"></i> Open Phone Barcode Scanner
          </button>
        </div>
      `;
      return;
    }

    container.innerHTML = items.map((it, auditIdx) => {
      let badgeClass = 'audit-variance-match';
      let badgeIcon = 'fa-check';
      let varianceText = 'Exact Match (0)';

      if (it.variance < 0) {
        badgeClass = 'audit-variance-short';
        badgeIcon = 'fa-arrow-trend-down';
        varianceText = `Shortage (${it.variance} ${this.escapeHtml(it.unit)})`;
      } else if (it.variance > 0) {
        badgeClass = 'audit-variance-over';
        badgeIcon = 'fa-arrow-trend-up';
        varianceText = `Surplus (+${it.variance} ${this.escapeHtml(it.unit)})`;
      }

      // Handlers address the row by index rather than embedding the stored product id:
      // an id inside a quoted JS string in onclick survives entity-decoding and can
      // therefore break out of the handler.
      return `
        <div class="stock-audit-card">
          <div style="display: flex; align-items: center; gap: 0.75rem; flex: 1; min-width: 220px;">
            <img src="${this.escapeHtml(it.image_url)}" class="table-img-thumb" alt="${this.escapeHtml(it.name)}" onerror="this.src='assets/images/products/placeholder.svg'">
            <div>
              <div style="font-weight: 700; font-size: 0.95rem; color: var(--slate-900);">${this.escapeHtml(it.name)}</div>
              <div style="font-size: 0.78rem; color: var(--slate-500); font-family: monospace;">
                SKU: ${this.escapeHtml(it.sku || 'N/A')} ${it.barcode ? `· <i class="fa-solid fa-barcode"></i> ${this.escapeHtml(it.barcode)}` : ''}
              </div>
            </div>
          </div>

          <div style="display: flex; align-items: center; gap: 1.25rem; flex-wrap: wrap;">
            <div style="text-align: right; font-size: 0.82rem;">
              <div style="color: var(--slate-500);">System Stock:</div>
              <strong style="font-size: 0.95rem; color: var(--slate-700);">${it.system_qty} ${this.escapeHtml(it.unit)}</strong>
            </div>

            <div style="display: flex; align-items: center; gap: 0.35rem;">
              <button type="button" class="audit-stepper-btn" onclick="app.updateStockAuditCountAtRow(${auditIdx}, -1)">-</button>
              <input type="number" class="audit-count-input" value="${it.counted_qty}" min="0" onchange="app.updateStockAuditCountAtRow(${auditIdx}, this.value, true)">
              <button type="button" class="audit-stepper-btn" onclick="app.updateStockAuditCountAtRow(${auditIdx}, 1)">+</button>
            </div>

            <div style="min-width: 140px; text-align: center;">
              <span class="audit-variance-badge ${badgeClass}">
                <i class="fa-solid ${badgeIcon}"></i> ${varianceText}
              </span>
            </div>

            <button type="button" class="btn btn-outline btn-sm" onclick="app.removeAuditItemAtRow(${auditIdx})" style="color: var(--danger); border-color: var(--danger-border); padding: 0.35rem 0.55rem;" title="Remove item from audit">
              <i class="fa-solid fa-xmark"></i>
            </button>
          </div>
        </div>
      `;
    }).join('');
  }

  updateStockAuditCountAtRow(index, value, isAbsolute = false) {
    const item = (this.stockAuditItems || [])[Number(index)];
    if (item) this.updateStockAuditCount(item.product_id, value, isAbsolute);
  }

  removeAuditItemAtRow(index) {
    const item = (this.stockAuditItems || [])[Number(index)];
    if (item) this.removeAuditItem(item.product_id);
  }

  removeAuditItem(productId) {
    if (!this.stockAuditItems) return;
    this.stockAuditItems = this.stockAuditItems.filter(i => i.product_id !== productId);
    this.renderStockAuditList();
  }

  async resetStockAudit() {
    if (!this.stockAuditItems || this.stockAuditItems.length === 0) return;
    const confirmed = await this.showConfirmModal({
      title: 'Clear Stocktake Audit?',
      message: 'Are you sure you want to clear this entire stocktake session? All counted rows will be discarded.',
      icon: 'fa-trash-can',
      confirmText: 'Yes, Clear Session',
      confirmBtnClass: 'btn-danger'
    });
    if (confirmed) {
      this.stockAuditItems = [];
      this.renderStockAuditList();
      this.showToast('Stocktake audit cleared.', 'info');
    }
  }

  exportStockAuditCSV() {
    const items = this.stockAuditItems || [];
    if (items.length === 0) {
      this.showToast('No items to export.', 'warning');
      return;
    }

    let csv = 'Product Name,SKU,Barcode,System Stock,Counted Stock,Variance,Unit,Cost Valuation Variance\n';
    items.forEach(it => {
      const costDiff = (it.variance * it.cost_price).toFixed(2);
      csv += `"${it.name.replace(/"/g, '""')}","${it.sku || ''}","${it.barcode || ''}",${it.system_qty},${it.counted_qty},${it.variance},"${it.unit}",${costDiff}\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `StoreFlow_Stocktake_${this.stockAuditBranch || 'MAIN'}_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    this.showToast('Stocktake audit CSV exported successfully.', 'success');
  }

  async commitStockAudit() {
    const items = this.stockAuditItems || [];
    const discrepancies = items.filter(i => i.variance !== 0);

    if (discrepancies.length === 0) {
      this.showToast('All counted items match system stock perfectly! No adjustments required.', 'success');
      this.closeStockAuditModal();
      return;
    }

    const confirmMsg = `Found ${discrepancies.length} products with stock variances.\n\nDo you want to commit these physical stocktake adjustments to the inventory ledger at branch "${this.stockAuditBranch || 'MAIN-01'}"?`;
    const confirmed = await this.showConfirmModal({
      title: 'Commit Physical Stocktake?',
      message: confirmMsg,
      icon: 'fa-clipboard-check',
      confirmText: 'Yes, Commit Adjustments',
      confirmBtnClass: 'btn-primary'
    });
    if (!confirmed) return;

    const commitBtn = document.getElementById('btn-commit-stock-audit');
    if (commitBtn) {
      commitBtn.disabled = true;
      commitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Committing...';
    }

    try {
      let successCount = 0;
      const refused = [];
      const unconfirmed = [];
      for (const it of discrepancies) {
        const type = it.variance > 0 ? 'ADJUSTMENT_ADD' : 'ADJUSTMENT_REMOVE';
        const qty = Math.abs(it.variance);
        const reason = `Stocktake Audit: Physical count ${it.counted_qty} vs System ${it.system_qty} (Variance: ${it.variance})`;

        if (!this.isOnline) {
          unconfirmed.push(it);
          continue;
        }
        let verdict;
        try {
          const res = await this.apiFetch('api/endpoints/inventory.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              product_id: it.product_id,
              type: type,
              quantity: qty,
              reason: reason,
              branch_code: this.stockAuditBranch || 'MAIN-01'
            })
          });
          verdict = await this.classifyApiResponse(res);
        } catch (e) {
          console.warn(`Failed to commit adjustment for ${it.name}:`, e);
          verdict = { verdict: 'unreachable' };
        }
        if (verdict.verdict === 'accepted') successCount++;
        else if (verdict.verdict === 'refused') refused.push({ it, message: verdict.message });
        else unconfirmed.push(it);
      }

      await this.fetchProducts();
      await this.fetchInventory();
      this.renderCurrentView();

      if (successCount > 0) {
        await this.logClientActivity(
          'STOCK_AUDIT',
          `Physical stocktake at Branch ${this.stockAuditBranch || 'MAIN-01'}: ${successCount} of ${discrepancies.length} products accepted by the server.`,
          true
        );
      }

      // A stocktake that "committed" N products used to mean the loop ran N times, not
      // that the server agreed once. Adjustments have no idempotency key, so an answer
      // the till could not read is filed as unconfirmed rather than quietly re-run.
      if (refused.length === 0 && unconfirmed.length === 0) {
        this.showToast(`Stocktake committed. ${successCount} products reconciled against the ledger.`, 'success');
        this.stockAuditItems = [];
        this.closeStockAuditModal();
      } else {
        const stillCounting = [...refused.map(r => r.it), ...unconfirmed];
        this.stockAuditItems = stillCounting;
        const bits = [];
        if (refused.length) {
          bits.push(`server refused ${refused.length}: ${refused.map(r => `${r.it.name} (${r.message})`).join(', ')}`);
        }
        if (unconfirmed.length) {
          bits.push(`${unconfirmed.length} unanswered - check the stock ledger before committing these again, an adjustment is not remembered by its own number`);
        }
        this.showToast(`${successCount} of ${discrepancies.length} committed; ${bits.join('; ')}. They stay on the count sheet.`, 'warning');
        this.renderCurrentView();
      }

    } catch (err) {
      this.showToast(`Error committing stock audit: ${err.message}`, 'danger');
    } finally {
      if (commitBtn) {
        commitBtn.disabled = false;
        commitBtn.innerHTML = '<i class="fa-solid fa-check-double"></i> Commit Stocktake Adjustments';
      }
    }
  }

  // ==========================================================================
  // COMPREHENSIVE PRODUCT DETAIL PAGE / MODAL
  // ==========================================================================

  async openProductDetailModal(productId) {
    if (!productId) return;
    const modal = document.getElementById('product-detail-modal');
    const content = document.getElementById('product-detail-content');
    const footer = document.getElementById('product-detail-footer');
    const titleEl = document.getElementById('product-detail-title');
    if (!modal || !content) return;

    let p = this.products.find(prod => String(prod.id) === String(productId));
    if (!p) {
      this.showToast('Product record not found.', 'warning');
      return;
    }

    if (titleEl) titleEl.innerHTML = `<i class="fa-solid fa-box-open"></i> ${this.escapeHtml(p.name)}`;

    const cost = Number(p.cost_price || 0);
    const price = Number(p.selling_price || 0);
    const margin = price - cost;
    const marginPercent = cost > 0 ? Math.round((margin / cost) * 100) : 100;
    const stock = Number(p.current_quantity || 0);
    const isOut = stock <= 0;
    const isLow = stock > 0 && stock <= Number(p.min_stock_alert || 5);
    const imgUrl = p.image_url || 'assets/images/products/placeholder.svg';
    const code = (p.barcode || p.sku || '').trim();

    // Inbound Factory Purchases for this product
    const prodPurchases = [];
    (this.purchases || []).forEach(po => {
      let items = po.items;
      if (typeof items === 'string') {
        try { items = JSON.parse(items); } catch (e) { items = []; }
      }
      if (Array.isArray(items)) {
        const match = items.find(it => String(it.product_id || it.id) === String(p.id) || String(it.name || '').toLowerCase() === String(p.name).toLowerCase());
        if (match) {
          prodPurchases.push({
            po_id: po.id,
            order_number: po.order_number || ('PO-' + po.id),
            supplier_name: po.supplier_name || 'Vendor',
            order_date: po.order_date || po.created_at || 'Recently',
            status: po.status || 'RECEIVED',
            quantity: Number(match.quantity || match.qty || 0),
            unit_cost: Number(match.unit_cost || match.cost || match.cost_price || p.cost_price || 0),
            total_cost: Number(match.total_cost || ((match.quantity || 1) * (match.unit_cost || p.cost_price || 0)))
          });
        }
      }
    });

    // Filter out any invalid or non-branch entries (e.g. 'ALL')
    const validBranchSettings = (p.branch_settings || []).filter(bs => (bs.branch_code || '').toUpperCase() !== 'ALL');

    content.innerHTML = `
      <!-- Hero Product Header -->
      <div style="background: #ffffff; padding: 1.15rem 1.25rem; border-radius: var(--radius-md); border: 1px solid var(--slate-200); margin-bottom: 1.25rem; display: flex; gap: 1.25rem; flex-wrap: wrap; align-items: center; justify-content: space-between;">
        <div style="display: flex; gap: 1rem; align-items: center; flex: 1; min-width: 260px;">
          <div style="width: 88px; height: 88px; border-radius: 12px; overflow: hidden; background: #ffffff; border: 1px solid var(--slate-200); display: flex; align-items: center; justify-content: center; flex-shrink: 0; padding: 4px;">
            <img src="${this.escapeHtml(imgUrl)}" alt="${this.escapeHtml(p.name)}" style="max-width: 100%; max-height: 100%; object-fit: contain;" onerror="this.src='assets/images/products/placeholder.svg'">
          </div>

          <div style="flex: 1;">
            <div style="display: flex; gap: 0.45rem; align-items: center; flex-wrap: wrap; margin-bottom: 0.35rem;">
              <span class="badge badge-neutral" style="font-size: 0.72rem;"><i class="fa-solid fa-folder"></i> ${this.escapeHtml(p.category || 'General')}</span>
              <span class="badge ${isOut ? 'badge-danger' : (isLow ? 'badge-warning' : 'badge-success')}" style="font-size: 0.72rem;">
                <i class="fa-solid ${isOut ? 'fa-circle-xmark' : (isLow ? 'fa-triangle-exclamation' : 'fa-circle-check')}"></i>
                ${isOut ? 'Out of Stock' : (isLow ? 'Low Stock Warning' : 'In Stock')}
              </span>
            </div>

            <h3 style="margin: 0 0 0.35rem 0; font-size: 1.25rem; color: var(--slate-900); font-weight: 800; line-height: 1.35;">${this.escapeHtml(p.name)}</h3>

            <div style="display: flex; gap: 1rem; flex-wrap: wrap; font-size: 0.8rem; color: var(--slate-600); font-family: monospace;">
              <div><strong>SKU:</strong> ${this.escapeHtml(p.sku || 'N/A')}</div>
              <div><strong>Barcode:</strong> ${this.escapeHtml(p.barcode || 'No barcode')}</div>
              <div><strong>Unit:</strong> ${this.escapeHtml(p.unit || 'pcs')}</div>
            </div>
          </div>
        </div>

        ${code ? `
          <div style="text-align: center; background: #ffffff; padding: 0.45rem 0.85rem; border-radius: 8px; border: 1px solid var(--slate-200); flex-shrink: 0; min-width: 160px;">
            <svg id="product-detail-barcode-svg" style="max-height: 44px; width: 100%;"></svg>
          </div>
        ` : ''}
      </div>

      <!-- Financial & Valuation Cards -->
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 0.85rem; margin-bottom: 1.25rem;">
        <div style="background: #ffffff; padding: 1rem; border-radius: var(--radius-md); border: 1px solid var(--slate-200);">
          <div style="font-size: 0.73rem; color: var(--slate-500); font-weight: 700; text-transform: uppercase;">Selling Price</div>
          <div style="font-size: 1.35rem; font-weight: 800; color: var(--primary); margin-top: 0.2rem;">${this.formatCurrency(price)}</div>
          <div style="font-size: 0.72rem; color: var(--slate-400); margin-top: 0.15rem;">Retail price at checkout</div>
        </div>

        <div style="background: #ffffff; padding: 1rem; border-radius: var(--radius-md); border: 1px solid var(--slate-200);">
          <div style="font-size: 0.73rem; color: var(--slate-500); font-weight: 700; text-transform: uppercase;">Factory Cost</div>
          <div style="font-size: 1.35rem; font-weight: 800; color: var(--slate-700); margin-top: 0.2rem;">${this.formatCurrency(cost)}</div>
          <div style="font-size: 0.72rem; color: var(--slate-400); margin-top: 0.15rem;">Purchase / acquisition cost</div>
        </div>

        <div style="background: #ffffff; padding: 1rem; border-radius: var(--radius-md); border: 1px solid var(--slate-200);">
          <div style="font-size: 0.73rem; color: var(--slate-500); font-weight: 700; text-transform: uppercase;">Gross Margin</div>
          <div style="font-size: 1.35rem; font-weight: 800; color: var(--success); margin-top: 0.2rem;">+${this.formatCurrency(margin)}</div>
          <div style="font-size: 0.72rem; color: var(--success); font-weight: 600; margin-top: 0.15rem;">+${marginPercent}% profit markup</div>
        </div>

        <div style="background: #ffffff; padding: 1rem; border-radius: var(--radius-md); border: 1px solid var(--slate-200);">
          <div style="font-size: 0.73rem; color: var(--slate-500); font-weight: 700; text-transform: uppercase;">Consolidated Stock</div>
          <div style="font-size: 1.35rem; font-weight: 800; color: ${isOut ? 'var(--danger)' : 'var(--slate-800)'}; margin-top: 0.2rem;">${stock} <span style="font-size: 0.85rem; font-weight: 600;">${this.escapeHtml(p.unit || 'pcs')}</span></div>
          <div style="font-size: 0.72rem; color: var(--slate-400); margin-top: 0.15rem;">Alert Level: ${p.min_stock_alert || 5} ${this.escapeHtml(p.unit || 'pcs')}</div>
        </div>
      </div>

      <!-- Multi-Branch Stock Allocation (If Multi-Branch Enabled) -->
      ${this.isMultiBranch && validBranchSettings.length > 0 ? `
        <div style="background: #ffffff; padding: 1.25rem; border-radius: var(--radius-md); border: 1px solid var(--slate-200); margin-bottom: 1.25rem;">
          <h4 style="margin: 0 0 0.85rem 0; font-size: 0.95rem; display: flex; align-items: center; gap: 0.45rem;">
            <i class="fa-solid fa-store" style="color: var(--primary);"></i> Branch Stock Allocation & Localized Pricing
          </h4>
          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Branch Code</th>
                  <th>Branch Name</th>
                  <th>Quantity on Hand</th>
                  <th>Local Selling Price</th>
                  <th>Sales Availability</th>
                </tr>
              </thead>
              <tbody>
                ${validBranchSettings.map(bs => {
      const branchInfo = (this.branches || []).find(b => (b.branch_code || '').toUpperCase() === (bs.branch_code || '').toUpperCase());
      const bName = branchInfo ? branchInfo.name : bs.branch_code;
      const bQty = Number(bs.current_quantity || 0);
      const bPrice = bs.custom_selling_price ? Number(bs.custom_selling_price) : price;
      const isAvail = bs.is_available !== 0 && bs.is_available !== false;
      return `
                    <tr>
                      <td style="font-family: monospace; font-weight: 700;">${this.escapeHtml(bs.branch_code)}</td>
                      <td style="font-weight: 600;">${this.escapeHtml(bName)}</td>
                      <td style="font-weight: 700;">
                        <span class="badge ${bQty <= 0 ? 'badge-danger' : 'badge-neutral'}">${bQty} ${this.escapeHtml(p.unit || 'pcs')}</span>
                      </td>
                      <td style="font-weight: 600; color: var(--primary);">${this.formatCurrency(bPrice)} ${bs.custom_selling_price ? '<span style="font-size: 0.7rem; color: var(--slate-400);">(Custom)</span>' : ''}</td>
                      <td>
                        <span class="badge ${isAvail ? 'badge-success' : 'badge-neutral'}">${isAvail ? 'Active' : 'Disabled'}</span>
                      </td>
                    </tr>
                  `;
    }).join('')}
              </tbody>
            </table>
          </div>
        </div>
      ` : ''}

      <!-- Lifetime Sales Performance & Recent Transactions for this Product -->
      <div style="background: #ffffff; padding: 1.25rem; border-radius: var(--radius-md); border: 1px solid var(--slate-200); margin-bottom: 1.25rem;">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.5rem; margin-bottom: 0.85rem;">
          <h4 style="margin: 0; font-size: 0.95rem; display: flex; align-items: center; gap: 0.45rem;">
            <i class="fa-solid fa-chart-line" style="color: var(--primary);"></i> Sales Activity & Velocity
          </h4>
          <div style="display: flex; gap: 0.6rem; font-size: 0.82rem;">
            <span style="background: var(--slate-100); padding: 0.25rem 0.6rem; border-radius: 6px;">Total Sold: <strong id="product-detail-sold-count"><i class="fa-solid fa-spinner fa-spin"></i></strong></span>
            <span style="background: #ecfdf5; color: #065f46; padding: 0.25rem 0.6rem; border-radius: 6px;">Revenue: <strong id="product-detail-revenue"><i class="fa-solid fa-spinner fa-spin"></i></strong></span>
          </div>
        </div>

        <div id="product-detail-sales-container">
          <div style="text-align: center; padding: 1.5rem; color: var(--slate-400); font-size: 0.85rem;">
            <i class="fa-solid fa-spinner fa-spin" style="font-size: 1.2rem; margin-bottom: 0.35rem; display: block;"></i>
            Loading live sales history...
          </div>
        </div>
      </div>

      <!-- Inbound Factory Purchases & Replenishment History for this Product -->
      <div style="background: #ffffff; padding: 1.25rem; border-radius: var(--radius-md); border: 1px solid var(--slate-200);">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.5rem; margin-bottom: 0.85rem;">
          <h4 style="margin: 0; font-size: 0.95rem; display: flex; align-items: center; gap: 0.45rem;">
            <i class="fa-solid fa-truck-ramp-box" style="color: #0284c7;"></i> Inbound Factory Purchases & Restocks
          </h4>
          <span style="background: #e0f2fe; color: #0369a1; padding: 0.25rem 0.6rem; border-radius: 6px; font-size: 0.82rem; font-weight: 700;">
            ${prodPurchases.length} Intake Order(s)
          </span>
        </div>

        ${prodPurchases.length > 0 ? `
          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>PO Number</th>
                  <th>Date</th>
                  <th>Factory / Supplier</th>
                  <th>Qty Received</th>
                  <th>Unit Cost</th>
                  <th>Total Cost</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                ${prodPurchases.map(po => `
                  <tr>
                    <td style="font-family: monospace; font-weight: 700;">${this.escapeHtml(po.order_number)}</td>
                    <td style="font-size: 0.82rem;">${this.escapeHtml(po.order_date || 'N/A')}</td>
                    <td style="font-weight: 600;">${this.escapeHtml(po.supplier_name)}</td>
                    <td style="font-weight: 700; color: #0369a1;">+${po.quantity} ${this.escapeHtml(p.unit || 'pcs')}</td>
                    <td style="font-family: monospace;">${this.formatCurrency(po.unit_cost)}</td>
                    <td style="font-weight: 700;">${this.formatCurrency(po.total_cost)}</td>
                    <td>
                      <span class="badge ${po.status === 'RECEIVED' ? 'badge-success' : 'badge-warning'}">
                        ${this.escapeHtml(po.status)}
                      </span>
                    </td>
                    <td>
                      <button class="btn btn-outline btn-sm" onclick="app.closeProductDetailModal(); app.viewPurchaseVoucher(${this.jsStr(po.po_id)});" title="View Factory Purchase Voucher">
                        <i class="fa-solid fa-file-invoice-dollar"></i> Voucher
                      </button>
                    </td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        ` : `
          <div style="text-align: center; padding: 1.5rem; color: var(--slate-400); font-size: 0.85rem;">
            <i class="fa-solid fa-truck-ramp-box" style="font-size: 1.5rem; margin-bottom: 0.35rem; display: block; opacity: 0.4;"></i>
            No factory purchase orders recorded for this stock item yet.
          </div>
        `}
      </div>
    `;

    // Render Barcode SVG via JsBarcode
    if (code && typeof JsBarcode !== 'undefined') {
      setTimeout(() => {
        const svgEl = document.getElementById('product-detail-barcode-svg');
        if (svgEl) {
          let format = 'CODE128';
          const cleanDigits = code.replace(/[^0-9]/g, '');
          if (cleanDigits.length === 13 && cleanDigits === code) format = 'EAN13';
          else if (cleanDigits.length === 12 && cleanDigits === code) format = 'UPC';
          else if (cleanDigits.length === 8 && cleanDigits === code) format = 'EAN8';

          try {
            JsBarcode(svgEl, code, {
              format: format,
              width: 1.4,
              height: 38,
              displayValue: true,
              fontSize: 10,
              font: 'monospace',
              margin: 2
            });
          } catch (e) {
            try {
              JsBarcode(svgEl, code, { format: 'CODE128', width: 1.3, height: 36, displayValue: true, fontSize: 10, margin: 2 });
            } catch (err) { }
          }
        }
      }, 30);
    }

    // Modal Footer Quick Actions
    if (footer) {
      footer.innerHTML = `
        <div style="display: flex; gap: 0.5rem; align-items: center; flex-wrap: wrap;">
          <button type="button" class="btn btn-outline btn-sm" onclick="app.closeProductDetailModal(); app.openBarcodeLabelModal(${this.jsStr(p.id)});" title="Print barcode stickers or shelf tags">
            <i class="fa-solid fa-barcode"></i> Print Barcode Labels
          </button>
          <button type="button" class="btn btn-outline btn-sm" onclick="app.closeProductDetailModal(); app.openStockAdjustmentModal(${this.jsStr(p.id)});" title="Adjust stock count">
            <i class="fa-solid fa-sliders"></i> Adjust Stock (+/-)
          </button>
          ${this.isMultiBranch && this.branches && this.branches.length > 1 ? `
            <button type="button" class="btn btn-outline btn-sm" onclick="app.closeProductDetailModal(); app.openTransferModal(${this.jsStr(p.id)});" title="Transfer stock to another branch">
              <i class="fa-solid fa-truck-arrow-right"></i> Transfer Stock
            </button>
          ` : ''}
        </div>
        <div style="display: flex; gap: 0.5rem; align-items: center;">
          <button type="button" class="btn btn-primary btn-sm" onclick="app.closeProductDetailModal(); app.editProduct(${this.jsStr(p.id)});">
            <i class="fa-solid fa-pen-to-square"></i> Edit Product
          </button>
          <button type="button" class="btn btn-secondary btn-sm" onclick="app.closeProductDetailModal()">
            Close
          </button>
        </div>
      `;
    }

    modal.classList.add('active');

    // Asynchronously fetch live product sales history from server
    try {
      const res = await this.apiFetch(`api/endpoints/products.php?action=sales_history&product_id=${encodeURIComponent(p.id)}`);
      const data = await res.json();
      if (data.success) {
        const soldEl = document.getElementById('product-detail-sold-count');
        const revEl = document.getElementById('product-detail-revenue');
        const salesContainer = document.getElementById('product-detail-sales-container');

        if (soldEl) soldEl.textContent = `${data.total_units} ${p.unit || 'pcs'}`;
        if (revEl) revEl.textContent = this.formatCurrency(data.total_revenue);

        if (salesContainer) {
          if (data.recent_sales && data.recent_sales.length > 0) {
            salesContainer.innerHTML = `
              <div class="table-responsive">
                <table class="data-table">
                  <thead>
                    <tr>
                      <th>Receipt #</th>
                      <th>Date</th>
                      <th>Customer</th>
                      <th>Qty Sold</th>
                      <th>Total Amount</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${data.recent_sales.map(rs => {
                      // "2 pcs" was said of two crates and of two eggs alike. The size on the
                      // line is what the customer carried out, and the loose count is what
                      // left the shelf, so both go on the row.
                      const sizeName = String(rs.unit || '').trim() || p.unit || 'pcs';
                      const loose = Number(rs.base_quantity || 0);
                      const soldQty = Number(rs.quantity || 0);
                      const looseNote = loose > soldQty
                        ? ` <span style="font-weight: 500; color: var(--slate-500); font-size: 0.78rem;">= ${this.escapeHtml(String(parseFloat(loose.toFixed(3))))} ${this.escapeHtml(p.unit || 'pcs')}</span>`
                        : '';
                      return `
                      <tr>
                        <td style="font-family: monospace; font-weight: 600;">${this.escapeHtml(rs.receipt_number)}</td>
                        <td style="font-size: 0.82rem;">${this.escapeHtml(rs.sale_date)}</td>
                        <td>${this.escapeHtml(rs.customer_name || 'Walk-in')}</td>
                        <td style="font-weight: 700;">${soldQty} ${this.escapeHtml(sizeName)}${looseNote}</td>
                        <td style="font-weight: 700; color: var(--primary);">${this.formatCurrency(rs.subtotal || (rs.quantity * rs.selling_price))}</td>
                        <td>
                          <button class="btn btn-outline btn-sm" onclick="app.closeProductDetailModal(); app.viewSaleReceipt(${this.jsStr(rs.sale_id)});" title="View Sale Receipt">
                            <i class="fa-solid fa-receipt"></i> Receipt
                          </button>
                        </td>
                      </tr>
                    `;
                    }).join('')}
                  </tbody>
                </table>
              </div>
            `;
          } else {
            salesContainer.innerHTML = `
              <div style="text-align: center; padding: 1.5rem; color: var(--slate-400); font-size: 0.85rem;">
                <i class="fa-solid fa-receipt" style="font-size: 1.5rem; margin-bottom: 0.35rem; display: block; opacity: 0.4;"></i>
                No sales transactions recorded for this product yet.
              </div>
            `;
          }
        }
      }
    } catch (e) {
      console.warn('Could not load live sales history for product from API, falling back to local sales:', e);
      try {
        const localMatches = [];
        let totalUnits = 0;
        let totalRevenue = 0;
        (this.sales || []).forEach(sale => {
          let items = sale.items;
          if (typeof items === 'string') {
            try { items = JSON.parse(items); } catch (_) { items = []; }
          }
          if (Array.isArray(items)) {
            items.forEach(it => {
              if (String(it.product_id || it.id) === String(p.id) || String(it.name || '').toLowerCase() === String(p.name).toLowerCase()) {
                const qty = Number(it.quantity || it.qty || 0);
                const sub = Number(it.subtotal || (qty * (it.selling_price || it.price || p.price || 0)));
                totalUnits += qty;
                totalRevenue += sub;
                localMatches.push({
                  sale_id: sale.id,
                  receipt_number: sale.receipt_number || ('REC-' + sale.id),
                  sale_date: (sale.created_at || sale.sale_date || '').slice(0, 10),
                  customer_name: sale.customer_name || 'Walk-in',
                  quantity: qty,
                  unit: it.unit || p.unit || 'pcs',
                  subtotal: sub
                });
              }
            });
          }
        });

        const soldEl = document.getElementById('product-detail-sold-count');
        const revEl = document.getElementById('product-detail-revenue');
        const salesContainer = document.getElementById('product-detail-sales-container');

        if (soldEl) soldEl.textContent = `${totalUnits} ${p.unit || 'pcs'}`;
        if (revEl) revEl.textContent = this.formatCurrency(totalRevenue);

        if (salesContainer) {
          if (localMatches.length > 0) {
            salesContainer.innerHTML = `
              <div class="table-responsive">
                <table class="data-table">
                  <thead>
                    <tr>
                      <th>Receipt #</th>
                      <th>Date</th>
                      <th>Customer</th>
                      <th>Qty Sold</th>
                      <th>Total Amount</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${localMatches.slice(0, 20).map(rs => `
                      <tr>
                        <td style="font-family: monospace; font-weight: 600;">${this.escapeHtml(rs.receipt_number)}</td>
                        <td style="font-size: 0.82rem;">${this.escapeHtml(rs.sale_date)}</td>
                        <td>${this.escapeHtml(rs.customer_name)}</td>
                        <td style="font-weight: 700;">${rs.quantity} ${this.escapeHtml(rs.unit)}</td>
                        <td style="font-weight: 700; color: var(--primary);">${this.formatCurrency(rs.subtotal)}</td>
                        <td>
                          <button class="btn btn-outline btn-sm" onclick="app.closeProductDetailModal(); app.viewSaleReceipt(${this.jsStr(rs.sale_id)});" title="View Sale Receipt">
                            <i class="fa-solid fa-receipt"></i> Receipt
                          </button>
                        </td>
                      </tr>
                    `).join('')}
                  </tbody>
                </table>
              </div>
            `;
          } else {
            salesContainer.innerHTML = `
              <div style="text-align: center; padding: 1.5rem; color: var(--slate-400); font-size: 0.85rem;">
                <i class="fa-solid fa-receipt" style="font-size: 1.5rem; margin-bottom: 0.35rem; display: block; opacity: 0.4;"></i>
                No sales transactions recorded for this product yet.
              </div>
            `;
          }
        }
      } catch (err) {
        console.warn('Fallback local sales calculation failed:', err);
      }
    }
  }

  closeProductDetailModal() {
    const modal = document.getElementById('product-detail-modal');
    if (modal) modal.classList.remove('active');
  }

  // =========================================================================
  // --- Merchandise Returns, Restocking & Customer Refunds (Credit Notes) ---
  // =========================================================================

  openSalesReturnModal(prefilledReceipt = '') {
    const modal = document.getElementById('sales-return-modal');
    if (!modal) return;

    this.currentSaleForReturn = null;
    this.currentReturnItems = [];

    const searchInput = document.getElementById('return-receipt-search-input');
    const container = document.getElementById('return-sale-container');
    const emptyState = document.getElementById('return-empty-state');
    const submitBtn = document.getElementById('btn-submit-sales-return');
    const refundBanner = document.getElementById('return-total-refund-banner');
    const reasonInput = document.getElementById('return-reason-input');

    if (container) container.style.display = 'none';
    if (emptyState) emptyState.style.display = 'block';
    // Always reset button to fresh state (clears stuck spinner from prior submission)
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<i class="fa-solid fa-arrow-rotate-left"></i> Process Refund';
    }
    if (refundBanner) refundBanner.textContent = this.formatCurrency(0);
    if (reasonInput) reasonInput.value = '';

    // Clear re-entry guard so the button works fresh every time the modal opens
    this._returnSubmitting = false;

    modal.classList.add('active');

    if (searchInput) {
      if (prefilledReceipt) {
        searchInput.value = prefilledReceipt.trim();
        setTimeout(() => this.lookupSaleForReturn(), 50);
      } else {
        searchInput.value = '';
        setTimeout(() => searchInput.focus(), 80);
      }
    }
  }

  closeSalesReturnModal() {
    const modal = document.getElementById('sales-return-modal');
    if (modal) modal.classList.remove('active');
    this.currentSaleForReturn = null;
    this.currentReturnItems = [];
    this._returnSubmitting = false;
    // Reset submit button so next open always starts clean (no stuck spinner)
    const submitBtn = document.getElementById('btn-submit-sales-return');
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<i class="fa-solid fa-arrow-rotate-left"></i> Process Refund';
    }
  }

  openSalesReturnForCurrentReceipt() {
    if (!this.currentSaleForReceipt || !this.currentSaleForReceipt.receipt_number) {
      this.showToast('No receipt loaded to return.', 'warning');
      return;
    }
    const receiptNum = this.currentSaleForReceipt.receipt_number;
    this.closeReceiptModal();
    this.openSalesReturnModal(receiptNum);
  }

  async lookupSaleForReturn() {
    const input = document.getElementById('return-receipt-search-input');
    const query = input ? input.value.trim() : '';

    if (!query) {
      this.showToast('Please enter an original Receipt #.', 'warning');
      return;
    }

    let sale = null;
    let items = [];

    if (this.isOnline) {
      try {
        const res = await this.apiFetch(`api/endpoints/returns.php?action=lookup_sale&receipt_number=${encodeURIComponent(query)}`);
        const data = await res.json();
        if (data.success && data.sale) {
          sale = data.sale;
          items = data.items || [];
        } else {
          this.showToast(data.message || 'Sale not found.', 'danger');
          return;
        }
      } catch (err) {
        console.warn('API error looking up return, fallback to local database:', err);
      }
    }

    // Local fallback if offline or API failed
    if (!sale) {
      sale = (this.sales || []).find(s => s.receipt_number === query || s.id === query);
      if (sale) {
        items = (sale.items || []).map(it => ({
          product_id: it.product_id,
          product_name: it.name || it.product_name,
          quantity: it.quantity,
          unit: it.unit || '',
          unit_label: it.unit || '',
          multiplier: Number(it.multiplier || 1),
          base_quantity: Number(it.base_quantity || 0),
          unit_price: it.selling_price || it.unit_selling_price || 0,
          sku: it.sku || '',
          remaining_returnable: it.quantity
        }));
      }
    }

    if (!sale) {
      this.showToast(`Receipt #${query} could not be found.`, 'danger');
      return;
    }

    this.currentSaleForReturn = sale;
    this.currentReturnItems = items;

    // Populate UI
    const container = document.getElementById('return-sale-container');
    const emptyState = document.getElementById('return-empty-state');
    const receiptDisp = document.getElementById('return-sale-receipt-display');
    const metaDisp = document.getElementById('return-sale-meta-display');
    const totalDisp = document.getElementById('return-sale-total-display');
    const tenderDisp = document.getElementById('return-sale-tender-display');

    if (receiptDisp) receiptDisp.textContent = sale.receipt_number;
    if (metaDisp) metaDisp.textContent = `Date: ${sale.sale_date} | Customer: ${sale.customer_name || 'Walk-in Customer'} | Branch: ${sale.branch_code || 'MAIN-01'}`;
    if (totalDisp) totalDisp.textContent = this.formatCurrency(sale.total_amount);
    if (tenderDisp) tenderDisp.textContent = `Paid via ${sale.payment_method || 'CASH'}${sale.payment_reference ? ` (Ref: ${sale.payment_reference})` : ''}`;

    this.renderReturnItemsTable();
    this.updateReturnTenderVisuals();

    if (emptyState) emptyState.style.display = 'none';
    if (container) container.style.display = 'block';
  }

  renderReturnItemsTable() {
    const tbody = document.getElementById('return-items-tbody');
    if (!tbody) return;

    const items = this.currentReturnItems || [];
    if (items.length === 0) {
      tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: var(--slate-400); padding: 1.5rem;">No returnable items on this receipt.</td></tr>`;
      return;
    }

    tbody.innerHTML = items.map((it, idx) => {
      const maxReturnable = Number(it.remaining_returnable !== undefined ? it.remaining_returnable : it.quantity);
      const isReturnable = maxReturnable > 0;
      const unitPrice = Number(it.unit_price || it.unit_selling_price || it.selling_price || 0);
      // The line's own size, not the product's loose unit: an egg and a box of 420 come back
      // as different quantities, and the counter has to be able to tell which one the
      // customer is holding before it types a number against it.
      const sizeLabel = String(it.unit_label || it.unit || '').trim();

      return `
        <tr style="background: ${isReturnable ? '#ffffff' : '#f8fafc'}; opacity: ${isReturnable ? 1 : 0.65};">
          <td>
            <strong style="color: var(--slate-900); display: block;">${this.escapeHtml(it.product_name || it.name || 'Item')}</strong>
            <span style="font-size: 0.75rem; color: var(--slate-500);">
              ${sizeLabel ? `<span style="display:inline-block; background: var(--slate-100); color: var(--slate-700); border-radius: 4px; padding: 0 0.35rem; margin-right: 0.3rem; font-weight: 700;">${this.escapeHtml(sizeLabel)}</span>` : ''}
              ${this.formatCurrency(unitPrice)}${it.sku ? ` | SKU: ${this.escapeHtml(it.sku)}` : ''}
            </span>
          </td>
          <td style="text-align: center;">
            <span style="font-weight: 700;">${it.quantity}</span>
            ${it.already_returned > 0 ? `<div style="font-size: 0.7rem; color: #dc2626;">(${it.already_returned} ret)</div>` : ''}
          </td>
          <td style="text-align: center;">
            ${isReturnable ? `
              <input type="number" class="form-control form-control-sm return-qty-input" 
                id="return-qty-${idx}"
                data-index="${idx}"
                data-price="${unitPrice}"
                data-unit="${this.escapeHtml(sizeLabel)}"
                data-product-id="${this.escapeHtml(it.product_id)}"
                data-product-name="${this.escapeHtml(it.product_name || it.name)}"
                min="0" max="${maxReturnable}" step="any" value="0"
                oninput="app.updateReturnCalculations()"
                style="width: 80px; margin: 0 auto; text-align: center; font-weight: 700;">
              <span style="font-size: 0.7rem; color: var(--slate-400); display: block; margin-top: 2px;">Max: ${maxReturnable}</span>
            ` : `
              <span class="badge badge-neutral">Fully Returned</span>
            `}
          </td>
          <td>
            ${isReturnable ? `
              <select class="form-control form-control-sm return-condition-select" id="return-cond-${idx}" style="font-size: 0.8rem; font-weight: 600;">
                <option value="RESTOCK">Restock to Shelf (Good)</option>
                <option value="DAMAGED">Damaged / Quarantine (Write-off)</option>
              </select>
            ` : `
              <span style="font-size: 0.75rem; color: var(--slate-400);">-</span>
            `}
          </td>
          <td style="text-align: right; font-weight: 700; color: #dc2626;" id="return-subtotal-${idx}">
            ${this.formatCurrency(0)}
          </td>
        </tr>
      `;
    }).join('');
  }

  // Mirror of saleRefundSplit() in api/config/db.php, which both server doors also call. The
  // receipt was taxed and discounted once, at the top, but a credit note is written line by line,
  // so the money that leaves the drawer is the returned lines' share of both. A till that queued
  // the bare line total would show the cashier 100.00 at the counter, hand over 100.00 from its own
  // drawer, and the server would book 93.83 - the shop eating the difference on every offline
  // refund. Change the arithmetic here and change it there, in the same commit.
  refundSplitForSale(sale, gross, refundableLeft, emptiesReceipt = false) {
    gross = Number((gross || 0).toFixed(2));
    refundableLeft = Number((refundableLeft || 0).toFixed(2));
    const subtotal = Number(sale?.subtotal || 0);
    const discount = Number(sale?.discount || 0);
    const tax = Number(sale?.tax || 0);

    if (subtotal <= 0.005) {
      return { gross, discount_share: 0, tax_share: 0, refund: Number(Math.max(0, Math.min(gross, refundableLeft)).toFixed(2)) };
    }

    let discountShare = Number((gross * discount / subtotal).toFixed(2));
    let taxShare = Number((gross * tax / subtotal).toFixed(2));
    let refund = Number((gross - discountShare + taxShare).toFixed(2));
    // The last credit note on a receipt settles the exact remainder, because three shares of
    // 93.83 come to 281.49 against the 281.50 the shop actually took.
    if (emptiesReceipt) refund = refundableLeft;
    if (refund > refundableLeft) refund = refundableLeft;
    if (refund < 0) refund = 0;
    taxShare = Number((refund - gross + discountShare).toFixed(2));
    return { gross, discount_share: discountShare, tax_share: taxShare, refund: Number(refund.toFixed(2)) };
  }

  // What the goods still returnable on this receipt are worth, grouped one price per size the way
  // the server groups it, so a slip handing back everything is recognised as doing so and gets the
  // remainder rather than its share.
  receiptLeftGross(items) {
    const byKey = {};
    (items || []).forEach((it) => {
      const label = String(it.unit_label ?? it.unit ?? '').trim().toLowerCase();
      const key = `${it.product_id}|${label}`;
      if (!byKey[key]) byKey[key] = { qty: 0, price: 0 };
      const left = it.remaining_returnable !== undefined ? it.remaining_returnable : it.quantity;
      byKey[key].qty += Math.max(0, Number(left) || 0);
      byKey[key].price = Math.max(byKey[key].price, Number(it.unit_price || it.unit_selling_price || it.selling_price) || 0);
    });
    let total = 0;
    Object.keys(byKey).forEach((k) => { total += byKey[k].qty * byKey[k].price; });
    return Number(total.toFixed(2));
  }

  // The refund a set of typed lines is worth on the receipt currently open in the returns modal.
  returnRefundForSale(gross) {
    const sale = this.currentSaleForReturn || {};
    const refundableLeft = Math.max(0, Number((Number(sale.total_amount || 0) - Number(sale.refunded_amount || 0)).toFixed(2)));
    const emptiesReceipt = Math.abs(this.receiptLeftGross(this.currentReturnItems) - Number(gross.toFixed(2))) <= 0.01;
    return this.refundSplitForSale(sale, gross, refundableLeft, emptiesReceipt);
  }

  updateReturnCalculations() {
    let totalRefund = 0;
    let totalItemsToReturn = 0;

    const qtyInputs = document.querySelectorAll('.return-qty-input');
    qtyInputs.forEach((input) => {
      const idx = input.getAttribute('data-index');
      const price = parseFloat(input.getAttribute('data-price')) || 0;
      const maxVal = parseFloat(input.getAttribute('max')) || 0;
      let qty = parseFloat(input.value) || 0;

      if (qty < 0) { qty = 0; input.value = 0; }
      if (qty > maxVal) { qty = maxVal; input.value = maxVal; }

      const subtotal = qty * price;
      totalRefund += subtotal;
      totalItemsToReturn += qty;

      const subtotalCell = document.getElementById(`return-subtotal-${idx}`);
      if (subtotalCell) {
        subtotalCell.textContent = this.formatCurrency(subtotal);
      }
    });

    const grossRefund = Number(totalRefund.toFixed(2));
    const split = this.returnRefundForSale(grossRefund);

    const banner = document.getElementById('return-total-refund-banner');
    if (banner) banner.textContent = this.formatCurrency(split.refund);

    const splitNote = document.getElementById('return-refund-split-note');
    if (splitNote) {
      splitNote.textContent = split.discount_share > 0 || split.tax_share > 0
        ? `${this.formatCurrency(split.gross)} of goods`
          + (split.discount_share > 0 ? ` less ${this.formatCurrency(split.discount_share)} discount share` : '')
          + (split.tax_share > 0 ? ` plus ${this.formatCurrency(split.tax_share)} tax share` : '')
        : '';
    }

    const submitBtn = document.getElementById('btn-submit-sales-return');
    if (submitBtn) {
      submitBtn.disabled = totalItemsToReturn <= 0;
    }
  }

  updateReturnTenderVisuals() {
    const cashRadio = document.querySelector('input[name="return_refund_method"][value="CASH"]');
    const cashLabel = document.getElementById('refund-method-cash-label');
    const creditLabel = document.getElementById('refund-method-credit-label');
    const hint = document.getElementById('refund-method-hint');

    const isCash = cashRadio ? cashRadio.checked : true;

    if (cashLabel && creditLabel) {
      cashLabel.style.borderColor = isCash ? 'var(--primary)' : 'var(--slate-200)';
      cashLabel.style.background = isCash ? '#f0f9ff' : '#ffffff';
      creditLabel.style.borderColor = !isCash ? '#2563eb' : 'var(--slate-200)';
      creditLabel.style.background = !isCash ? '#eff6ff' : '#ffffff';
    }

    if (hint) {
      hint.textContent = isCash
        ? 'Cash refund will be deducted from active register drawer.'
        : 'Store credit will be credited to the customer account balance (reduces debt or creates credit).';
    }
  }

  async submitSalesReturn() {
    if (!this.currentSaleForReturn) return;

    // Guard: prevent double-tap / repeated clicks while already processing
    if (this._returnSubmitting) return;
    this._returnSubmitting = true;

    const sale = this.currentSaleForReturn;
    const qtyInputs = document.querySelectorAll('.return-qty-input');
    const returnItems = [];

    qtyInputs.forEach((input) => {
      const idx = input.getAttribute('data-index');
      const qty = parseFloat(input.value) || 0;
      if (qty > 0) {
        const prodId = input.getAttribute('data-product-id');
        const prodName = input.getAttribute('data-product-name');
        const unitPrice = parseFloat(input.getAttribute('data-price')) || 0;
        const condition = document.getElementById(`return-cond-${idx}`)?.value || 'RESTOCK';

        returnItems.push({
          product_id: prodId,
          product_name: prodName,
          quantity: qty,
          unit: input.getAttribute('data-unit') || '',
          unit_price: unitPrice,
          refund_subtotal: Number((qty * unitPrice).toFixed(2)),
          item_condition: condition
        });
      }
    });

    if (returnItems.length === 0) {
      this.showToast('Please enter a quantity > 0 for at least one item to return.', 'warning');
      this._returnSubmitting = false;
      return;
    }

    const refundMethodRadio = document.querySelector('input[name="return_refund_method"]:checked');
    const refundMethod = refundMethodRadio ? refundMethodRadio.value : 'CASH';
    const reason = document.getElementById('return-reason-input')?.value.trim() || 'Customer return';
    const grossRefund = Number(returnItems.reduce((acc, i) => acc + i.refund_subtotal, 0).toFixed(2));
    // What the counter hands over is not the sum of the lines: the receipt carried its discount
    // and its tax at the top, and this slip takes its share of both. See refundSplitForSale().
    const split = this.returnRefundForSale(grossRefund);
    const totalRefund = split.refund;

    const splitLines = (split.discount_share > 0 || split.tax_share > 0)
      ? `\nGoods value: ${this.formatCurrency(split.gross)}`
        + `\nLess share of the receipt discount: -${this.formatCurrency(split.discount_share)}`
        + `\nPlus share of the receipt tax: ${this.formatCurrency(split.tax_share)}`
      : '';

    const confirmed = await this.showConfirmModal({
      title: 'Process Customer Return & Refund?',
      message: `Return ${returnItems.length} item line(s) for Original Receipt #${sale.receipt_number}.

Total Refund Amount: ${this.formatCurrency(totalRefund)}${splitLines}
Refund Tender: ${refundMethod === 'CASH' ? 'Cash from Drawer' : 'Customer Account Credit'}`,
      icon: 'fa-arrow-rotate-left',
      confirmText: 'Confirm & Process Return',
      confirmBtnClass: 'btn-danger'
    });
    if (!confirmed) {
      this._returnSubmitting = false; // release guard – user cancelled
      return;
    }

    const submitBtn = document.getElementById('btn-submit-sales-return');
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processing Return...';
    }

    try {
      const returnPayload = {
        sale_id: sale.id,
        receipt_number: sale.receipt_number,
        customer_id: sale.customer_id || 'cust-walkin',
        customer_name: sale.customer_name || 'Walk-in Customer',
        terminal_id: this.terminalId || 'REG-01',
        branch_code: sale.branch_code || this.branchCode || 'MAIN-01',
        user_id: this.currentUser?.id || 1,
        refund_method: refundMethod,
        reason: reason,
        return_date: new Date().toISOString().slice(0, 19).replace('T', ' '),
        items: returnItems
      };

      let resultReturnData = null;
      // What the move does to the member's standing, in one sentence for the counter, the shift
      // log and the paper handed over. It stays empty for a note queued offline on purpose: the
      // shop works the share out when the outbox replays, and a till that guessed the figure would
      // be telling the member a number the book has not agreed to yet.
      let loyaltyWords = '';

      if (this.isOnline) {
        let verdict = { verdict: 'unreachable' };
        try {
          const res = await this.apiFetch('api/endpoints/returns.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(returnPayload)
          });
          verdict = await this.classifyApiResponse(res);
        } catch (err) {
          console.warn('Online return unreachable, queuing offline:', err);
          verdict = { verdict: 'unreachable' };
        }

        if (verdict.verdict === 'accepted') {
          if (!verdict.body.return) {
            // It is filed. Minting a local credit note because the reply was unreadable
            // would refund the same customer twice once the outbox posted it.
            this.showToast('The server accepted this return but its reply was unreadable. Do not repeat the refund - check the returns list first.', 'danger', 12000);
            if (typeof this.fetchReturns === 'function') await this.fetchReturns();
            return;
          }
          resultReturnData = verdict.body.return;
          loyaltyWords = this.loyaltyReturnSentence(resultReturnData.loyalty);
          await this.logClientActivity(
            'SALE_RETURN',
            `Processed return ${resultReturnData.return_number || ''} for receipt #${returnPayload.receipt_number}. Refund: ${this.formatCurrency(totalRefund)} (${refundMethod}).${loyaltyWords ? ' ' + loyaltyWords : ''}`,
            false
          );
        } else if (verdict.verdict === 'refused') {
          // The server looked at this refund and said no - the item was not on the
          // receipt, the money is over what was paid, the cashier has no right to
          // erase it. Nothing has been handed over yet, so stop here rather than
          // writing a credit note the books will never hold.
          this.showToast(`Return refused: ${verdict.message}`, 'danger', 12000);
          await this.logClientActivity(
            'RETURN_REFUSED',
            `Refund of ${this.formatCurrency(totalRefund)} (${refundMethod}) against receipt #${returnPayload.receipt_number} was refused: ${verdict.message}`,
            false
          );
          return;
        }
      }

      // Local execution fallback if offline or API unavailable
      if (!resultReturnData) {
        const returnNumber = 'RET-' + new Date().toISOString().slice(0, 10).replace(/-/g, '') + '-' + Math.floor(1000 + Math.random() * 9000);
        resultReturnData = {
          id: 'ret_' + Date.now(),
          return_number: returnNumber,
          ...returnPayload,
          total_refund_amount: totalRefund,
          // Saved with the note so the paper the customer leaves with says where the number came
          // from. The server works these out for itself and does not read them off the outbox.
          refund_gross: split.gross,
          refund_discount_share: split.discount_share,
          refund_tax_share: split.tax_share,
          cashier_name: this.currentUser?.full_name || 'Cashier'
        };

        try {
          if (localDB.sales_returns) {
            await localDB.sales_returns.put({ ...resultReturnData, synced: 0 });
          }
          await localDB.sync_outbox.add({
            entity: 'sales_return',
            action: 'CREATE',
            data: resultReturnData,
            timestamp: new Date().toISOString(),
            synced: 0
          });
          await this.logClientActivity(
            'SALE_RETURN',
            `Processed offline return for receipt #${returnPayload.receipt_number}. Refund: ${this.formatCurrency(totalRefund)} (${refundMethod}).`,
            true
          );
        } catch (queueErr) {
          // The refund itself is already decided at this point. Losing the queue entry
          // silently is how a till hands out cash that never appears on the books.
          console.error('Failed to store the offline credit note:', queueErr);
          this.showToast(
            `This refund could not be saved on this till (${queueErr && queueErr.message ? queueErr.message : 'storage error'}). Hand over nothing yet - repeat the return once the till has room.`,
            'danger',
            14000
          );
          return;
        }
      }

      // Update local products inventory for items returned in good condition
      const activeBranchCode = (this.branchCode || 'MAIN-01').toUpperCase();
      for (const it of returnItems) {
        if (it.item_condition === 'RESTOCK') {
          const prod = (this.products || []).find(p => p.id === it.product_id);
          if (prod) {
            prod.current_quantity = Number(prod.current_quantity || 0) + Number(it.quantity);
            if (prod.branch_settings && Array.isArray(prod.branch_settings)) {
              const bs = prod.branch_settings.find(b => (b.branch_code || '').toUpperCase() === activeBranchCode);
              if (bs) bs.current_quantity = Number(bs.current_quantity || 0) + Number(it.quantity);
            }
            await localDB.products.put(prod);
          }
        }
      }

      // Update customer debt balance if Store Credit was issued
      if (refundMethod === 'STORE_CREDIT' && sale.customer_id && sale.customer_id !== 'cust-walkin') {
        const cust = (this.customers || []).find(c => c.id === sale.customer_id);
        if (cust) {
          cust.balance = Number(cust.balance || 0) - totalRefund;
          await localDB.customers.put(cust);
        }
      }

      // Update local sale record status and refunded_amount
      const localSaleIdx = (this.sales || []).findIndex(s => s.id === sale.id);
      if (localSaleIdx >= 0) {
        const curRef = Number(this.sales[localSaleIdx].refunded_amount || 0) + totalRefund;
        this.sales[localSaleIdx].refunded_amount = curRef;
        this.sales[localSaleIdx].status = (Number(this.sales[localSaleIdx].total_amount || 0) - curRef <= 0.01) ? 'REFUNDED' : 'PARTIALLY_REFUNDED';
        if (typeof localDB !== 'undefined' && localDB.sales) {
          try { await localDB.sales.put(this.sales[localSaleIdx]); } catch (e) {}
        }
      }

      // Close return modal
      this.closeSalesReturnModal();
      await this.fetchProducts();
      await this.fetchSales();
      // Products and sales were refetched here and returns were not, so the ledger kept showing
      // the refund count from before the refund. An offline slip stays in that list because
      // fetchReturns keeps whatever the server has never seen.
      await this.fetchReturns();
      this.renderCurrentView();
      if (typeof this.broadcastSyncEvent === 'function') {
        this.broadcastSyncEvent('RETURN_RECORDED', { returnData: resultReturnData });
      }

      this.showToast(`Return ${resultReturnData.return_number} processed successfully! Refund of ${this.formatCurrency(totalRefund)} issued via ${refundMethod}.${loyaltyWords ? ' ' + loyaltyWords : ''}`, 'success', loyaltyWords ? 10000 : 4000);

      // Display Official Return Credit Note Slip
      this.showReturnCreditNote(resultReturnData);
    } catch (unexpectedErr) {
      console.error('Unexpected error in submitSalesReturn:', unexpectedErr);
      this.showToast('An unexpected error occurred. Please try again.', 'danger');
    } finally {
      this._returnSubmitting = false;
    }
  }

  /**
   * The member's points, in the shop's answer to a credit note, said once for the counter. A
   * return desk that hands over cash and says nothing about the standing is a return desk that
   * gets argued with at the next purchase, when the member finds their balance trimmed.
   */
  loyaltyReturnSentence(loyalty) {
    if (!loyalty) return '';
    const moved = Number(loyalty.change || 0);
    const short = Number(loyalty.short || 0);
    const balance = Number(loyalty.balance || 0);
    if (moved < 0) {
      return `${Math.abs(moved).toLocaleString()} point(s) taken back off the member's balance, which stands at ${balance.toLocaleString()}.`;
    }
    if (moved > 0) {
      return `${moved.toLocaleString()} point(s) handed back to the member, whose balance is now ${balance.toLocaleString()}.`;
    }
    if (short > 0) {
      return `${short.toLocaleString()} of the points on this receipt could not be taken back - the member had already spent them.`;
    }
    return '';
  }

  showReturnCreditNote(returnData) {
    const modal = document.getElementById('receipt-modal');
    const container = document.getElementById('printable-receipt-area');
    if (!modal || !container) return;

    this.currentSaleForReceipt = null;
    this.currentPaymentReceipt = null;
    this.currentReturnForReceipt = returnData;

    const retBtn = document.getElementById('receipt-btn-return');
    if (retBtn) retBtn.style.display = 'none';
    const voidBtn = document.getElementById('receipt-btn-void');
    if (voidBtn) voidBtn.style.display = 'none';

    const prof = this.storeProfile;
    const isCredit = returnData.refund_method === 'STORE_CREDIT';
    const totalRefund = Number(returnData.total_refund_amount || 0);
    const typo = this.getReceiptTypographyStyles();

    container.innerHTML = `
      <div class="receipt-wrapper ${typo.classes}" style="${typo.cssText}">
        <div class="receipt-header-center">
          ${this.shouldPrintReceiptLogo() ? `<img src="${this.escapeHtml(this.getStoreLogo())}" alt="Logo" class="receipt-logo">` : ''}
          <h3>${this.escapeHtml(prof.store_name)}</h3>
          <p style="font-size: 0.8rem; margin: 0.2rem 0;">${this.escapeHtml(prof.tagline || '')}</p>
          <p style="font-size: 0.75rem;">${this.escapeHtml(prof.address || '')}</p>
          <p style="font-size: 0.75rem;">Phone: ${this.escapeHtml(prof.phone || '')}${prof.show_tax_on_receipt !== 0 && prof.tax_number ? ` | Tax ID: ${this.escapeHtml(prof.tax_number)}` : ''}</p>
          <div class="receipt-divider"></div>
          <p style="font-size: 0.85rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.05em; margin: 0.25rem 0; color: #4338ca;">
            <i class="fa-solid fa-arrow-rotate-left"></i> Official Return & Credit Note
          </p>
        </div>

        <div style="font-size: 0.75rem; margin-bottom: 0.5rem; line-height: 1.45;">
          <div><strong>Return Slip #:</strong> ${this.escapeHtml(returnData.return_number)}</div>
          <div><strong>Original Sale Receipt:</strong> ${this.escapeHtml(returnData.receipt_number)}</div>
          <div><strong>Date:</strong> ${this.escapeHtml(returnData.return_date)}</div>
          <div><strong>Customer:</strong> ${this.escapeHtml(returnData.customer_name || 'Walk-in Customer')}</div>
          <div><strong>Cashier:</strong> ${this.escapeHtml(returnData.cashier_name || 'Cashier')}</div>
          <div><strong>Terminal / Branch:</strong> ${this.escapeHtml(returnData.terminal_id || 'REG-01')} (${this.escapeHtml(returnData.branch_code || 'MAIN-01')})</div>
          ${returnData.reason ? `<div><strong>Reason:</strong> ${this.escapeHtml(returnData.reason)}</div>` : ''}
        </div>

        <div class="receipt-divider"></div>

        <table class="receipt-table">
          <thead>
            <tr>
              <th style="width: 44%;">Item Returned</th>
              <th style="text-align: center; width: 14%;">Qty</th>
              <th style="text-align: right; width: 21%;">Price</th>
              <th style="text-align: right; width: 21%;">Value</th>
            </tr>
          </thead>
          <tbody>
            ${(returnData.items || []).map(it => {
              const retSize = String(it.unit || it.unit_label || '').trim();
              const retMult = Math.max(1, Number(it.multiplier || 1));
              const retBase = Number(it.base_quantity || 0);
              return `
              <tr>
                <td style="word-break: break-word; padding-right: 0.35rem;">
                  ${this.escapeHtml(it.product_name || 'Item')}
                  <div style="font-size: 0.68rem; color: ${it.item_condition === 'RESTOCK' ? '#16a34a' : '#dc2626'}; font-weight: 600;">
                    ${it.item_condition === 'RESTOCK' ? '✓ Restocked to shelf' : '⚠ Damaged / Quarantined'}
                  </div>
                </td>
                <td style="text-align: center;">
                  ${it.quantity}${retSize ? ' ' + this.escapeHtml(retSize) : ''}
                  ${retMult > 1 && retBase > 0 ? `<div style="font-size: 0.66rem; color: #64748b;">= ${this.escapeHtml(String(parseFloat(retBase.toFixed(3))))} loose</div>` : ''}
                </td>
                <td style="text-align: right; white-space: nowrap;">${this.formatCurrency(it.unit_price)}</td>
                <td style="text-align: right; white-space: nowrap; color: #dc2626; font-weight: 700;">-${this.formatCurrency(it.refund_subtotal || (it.quantity * it.unit_price))}</td>
              </tr>
            `; }).join('')}
          </tbody>
        </table>

        <div class="receipt-divider"></div>

        <div style="font-size: 0.8rem; line-height: 1.6;">
          ${Number(returnData.refund_discount_share) > 0 || Number(returnData.refund_tax_share) > 0 ? `
          <div style="display: flex; justify-content: space-between; font-size: 0.75rem; color: var(--slate-600, #475569);">
            <span>Goods value of items returned:</span>
            <span>${this.formatCurrency(Number(returnData.refund_gross || 0))}</span>
          </div>
          <div style="display: flex; justify-content: space-between; font-size: 0.75rem; color: var(--slate-600, #475569);">
            <span>Less share of the receipt discount:</span>
            <span>-${this.formatCurrency(Number(returnData.refund_discount_share || 0))}</span>
          </div>
          <div style="display: flex; justify-content: space-between; font-size: 0.75rem; color: var(--slate-600, #475569);">
            <span>Plus share of the receipt tax:</span>
            <span>${this.formatCurrency(Number(returnData.refund_tax_share || 0))}</span>
          </div>` : ''}
          <div style="display: flex; justify-content: space-between; font-weight: bold; font-size: 1rem; margin: 0.4rem 0; background: #fee2e2; padding: 0.4rem 0.5rem; border-radius: 4px; border: 1px dashed #dc2626; color: #991b1b;">
            <span>TOTAL REFUND ISSUED:</span>
            <span>${this.formatCurrency(totalRefund)}</span>
          </div>
          ${(() => {
            // The points the receipt paid out moved with the goods, and the paper the customer
            // leaves with is where that gets answered. Nothing printed when the shop booked no
            // move - a walk-in bill, or a note still waiting in a shut till's outbox.
            const words = this.loyaltyReturnSentence(returnData.loyalty);
            return words ? `<div style="font-size: 0.75rem; color: #4338ca; margin-top: 0.3rem; line-height: 1.4;">
              <strong>Loyalty:</strong> ${this.escapeHtml(words)}</div>` : '';
          })()}

          <div style="display: flex; justify-content: space-between;">
            <span>Refund Tender:</span>
            <span style="font-weight: 700;">${isCredit ? 'Customer Store Credit' : 'Cash Payout from Drawer'}</span>
          </div>

          ${returnData.customer_balance !== undefined && returnData.customer_balance !== null ? `
            <div style="display: flex; justify-content: space-between; margin-top: 0.35rem;">
              <span>Customer Updated Balance:</span>
              <span style="font-weight: 700; color: ${Number(returnData.customer_balance) > 0 ? '#b91c1c' : '#15803d'};">
                ${Number(returnData.customer_balance) <= 0 ? 'CLEARED (' + this.formatCurrency(0) + ')' : this.formatCurrency(returnData.customer_balance)}
              </span>
            </div>
          ` : ''}
        </div>

        <div class="receipt-divider"></div>

        <div style="margin-top: 1.5rem; display: flex; justify-content: space-between; font-size: 0.72rem; color: #475569;">
          <div style="border-top: 1px solid #94a3b8; width: 45%; padding-top: 0.25rem; text-align: center;">Manager Signature</div>
          <div style="border-top: 1px solid #94a3b8; width: 45%; padding-top: 0.25rem; text-align: center;">Customer Signature</div>
        </div>

        <div style="text-align: center; font-size: 0.75rem; margin-top: 1rem;">
          <p>${this.escapeHtml(prof.receipt_footer || 'Thank you for your business!')}</p>
        </div>
      </div>
    `;

    modal.classList.add('active');
  }

  // --- PC Outage Backup Checkpoint & Delta Sync Engine ---

  getOutageCheckpointState() {
    try {
      const raw = localStorage.getItem('sf_outage_checkpoint');
      return raw ? JSON.parse(raw) : { active: false, started_at: null, started_ms: 0 };
    } catch (e) {
      return { active: false, started_at: null, started_ms: 0 };
    }
  }

  setOutageCheckpointState(state) {
    localStorage.setItem('sf_outage_checkpoint', JSON.stringify(state));
    this.updateCheckpointUI();
  }

  openCheckpointModal() {
    const modal = document.getElementById('checkpoint-modal');
    if (!modal) return;
    this.updateCheckpointUI();
    modal.classList.add('active');
  }

  closeCheckpointModal() {
    const modal = document.getElementById('checkpoint-modal');
    if (modal) modal.classList.remove('active');
  }

  updateCheckpointUI() {
    const cp = this.getOutageCheckpointState();
    const btnTopbar = document.getElementById('btn-topbar-checkpoint');
    const labelTopbar = document.getElementById('topbar-checkpoint-label');
    const toggleInput = document.getElementById('toggle-checkpoint-active');
    const statusText = document.getElementById('checkpoint-status-text');
    const slider = document.getElementById('checkpoint-slider');

    if (toggleInput) toggleInput.checked = !!cp.active;

    if (cp.active) {
      const dateStr = cp.started_at ? new Date(cp.started_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'recently';
      if (btnTopbar) {
        btnTopbar.style.background = '#d97706';
        btnTopbar.style.color = '#ffffff';
        btnTopbar.style.borderColor = '#b45309';
      }
      if (labelTopbar) labelTopbar.textContent = `Backup Active (${dateStr})`;
      if (statusText) statusText.innerHTML = `<strong style="color: #15803d;"><i class="fa-solid fa-circle-check"></i> ACTIVE since ${new Date(cp.started_at).toLocaleString()}</strong><br>All newly rung sales & changes are marked for PC export.`;
      if (slider) slider.style.backgroundColor = '#d97706';
    } else {
      if (btnTopbar) {
        btnTopbar.style.background = '#fffbeb';
        btnTopbar.style.color = '#d97706';
        btnTopbar.style.borderColor = '#fde68a';
      }
      if (labelTopbar) labelTopbar.textContent = 'PC Backup';
      if (statusText) statusText.innerHTML = 'Currently INACTIVE (normal counter mode)';
      if (slider) slider.style.backgroundColor = '#cbd5e1';
    }
  }

  toggleOutageCheckpoint(enabled) {
    if (enabled) {
      const now = new Date();
      const state = {
        active: true,
        started_at: now.toISOString(),
        started_ms: now.getTime()
      };
      this.setOutageCheckpointState(state);
      this.showToast('PC Outage Backup Mode ACTIVATED. Sales from now on will be tracked for PC recovery.', 'success');
    } else {
      if (confirm('Deactivate PC Backup Checkpoint mode? Be sure you have exported your delta transactions first.')) {
        this.setOutageCheckpointState({ active: false, started_at: null, started_ms: 0 });
        this.showToast('PC Outage Backup Mode deactivated.', 'info');
      } else {
        const toggleInput = document.getElementById('toggle-checkpoint-active');
        if (toggleInput) toggleInput.checked = true;
      }
    }
  }

  async exportOutageDelta() {
    const cp = this.getOutageCheckpointState();
    const minTimestamp = cp.started_ms ? new Date(cp.started_ms).toISOString() : new Date(Date.now() - 24 * 3600 * 1000).toISOString();

    const deltaData = {
      is_outage_delta: true,
      exported_at: new Date().toISOString(),
      checkpoint_started_at: cp.started_at || minTimestamp,
      terminal_id: this.terminalId || 'MOBILE-01',
      book_epoch: this.serverBookEpoch || '',
      sales: [],
      payments: [],
      expenses: [],
      shifts: [],
      returns: []
    };

    // Filter local memory sales created since checkpoint
    if (Array.isArray(this.sales)) {
      deltaData.sales = this.sales.filter(s => {
        const t = new Date(s.sale_date || s.created_at).getTime();
        return t >= (cp.started_ms || 0);
      });
    }

    // Include expenses
    if (Array.isArray(this.expenses)) {
      deltaData.expenses = this.expenses.filter(e => {
        const t = new Date(e.created_at || e.date).getTime();
        return t >= (cp.started_ms || 0);
      });
    }

    // Include sales returns
    if (Array.isArray(this.salesReturns)) {
      deltaData.returns = this.salesReturns.filter(r => {
        const t = new Date(r.created_at || r.return_date).getTime();
        return t >= (cp.started_ms || 0);
      });
    }

    const blob = new Blob([JSON.stringify(deltaData, null, 2)], { type: 'application/json' });
    const filename = `StoreFlow-Outage-Delta-${new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)}.sfdelta.json`;

    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();

    this.showToast(`Exported ${deltaData.sales.length} sales and outage records into ${filename}`, 'success');
  }

  async beamOutageDeltaToPc() {
    const pcUrl = prompt('Enter the PC Server IP / URL (e.g. http://192.168.1.100/storemgt):', localStorage.getItem('sf_pc_server_url') || 'http://localhost/storemgt');
    if (!pcUrl) return;
    localStorage.setItem('sf_pc_server_url', pcUrl);

    const cp = this.getOutageCheckpointState();
    const deltaData = {
      is_outage_delta: true,
      exported_at: new Date().toISOString(),
      checkpoint_started_at: cp.started_at,
      terminal_id: this.terminalId || 'MOBILE-01',
      book_epoch: this.serverBookEpoch || '',
      sales: Array.isArray(this.sales) ? this.sales.filter(s => new Date(s.sale_date || s.created_at).getTime() >= (cp.started_ms || 0)) : [],
      expenses: Array.isArray(this.expenses) ? this.expenses.filter(e => new Date(e.created_at || e.date).getTime() >= (cp.started_ms || 0)) : [],
      returns: Array.isArray(this.salesReturns) ? this.salesReturns.filter(r => new Date(r.created_at || r.return_date).getTime() >= (cp.started_ms || 0)) : []
    };

    try {
      this.showToast('Beaming delta to PC server...', 'info');
      const endpoint = pcUrl.replace(/\/+$/, '') + '/api/endpoints/sync.php';
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': this.currentUser?.token ? `Bearer ${this.currentUser.token}` : ''
        },
        body: JSON.stringify(deltaData)
      });
      const data = await res.json();
      if (data && data.success) {
        this.showToast(`Successfully beamed! PC processed ${data.processed?.sales?.length || 0} sales.`, 'success');
        this.closeCheckpointModal();
      } else {
        this.showToast(data.message || 'PC rejected sync', 'danger');
      }
    } catch (err) {
      this.showToast('Failed to reach PC server. Please export as file and copy over instead.', 'danger');
    }
  }

  async handleOutageDeltaFileSelect(event) {
    const file = event.target.files && event.target.files[0];
    if (!file) return;

    try {
      const text = await file.text();
      const payload = JSON.parse(text);

      if (!payload.sales && !payload.expenses && !payload.returns) {
        this.showToast('Selected file does not appear to be a valid StoreFlow delta package.', 'danger');
        return;
      }

      payload.is_outage_delta = true;
      this.showToast(`Importing delta file (${(payload.sales || []).length} sales)...`, 'info');

      const res = await fetch('api/endpoints/sync.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();

      if (data && data.success) {
        const salesCount = (data.processed && data.processed.sales) ? data.processed.sales.length : 0;
        this.showToast(`Outage Recovery Complete! ${salesCount} sales appended and stock deducted on PC.`, 'success');
        this.closeCheckpointModal();
        if (typeof this.loadInitialData === 'function') {
          await this.loadInitialData();
        }
      } else {
        this.showToast(data.message || 'Failed to import outage delta', 'danger');
      }
    } catch (err) {
      this.showToast('Error reading or processing delta file: ' + err.message, 'danger');
    } finally {
      event.target.value = '';
    }
  }

}

// Bootstrap Application
document.addEventListener('DOMContentLoaded', () => {
  window.app = new StoreApp();

  // Without these, a thrown error inside an async render left the operator staring
  // at an empty panel with no indication that the app had broken.
  window.addEventListener('error', (e) => {
    console.error('[StoreFlow]', e.message, e.filename, e.lineno);
  });
  window.addEventListener('unhandledrejection', (e) => {
    const reason = e.reason;
    console.error('[StoreFlow] Unhandled rejection:', (reason && reason.message) || reason);
  });
});
