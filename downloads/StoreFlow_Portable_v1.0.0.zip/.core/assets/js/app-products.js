Object.assign(StoreApp.prototype, {
  getProductsHTML() {
    const isCashier = this.isCashier();

    return `
      <div class="panel">
        <div class="panel-header">
          <h3><i class="fa-solid fa-boxes-stacked"></i> Products Catalog</h3>
          <div style="display: flex; gap: 0.5rem; align-items: center; flex-wrap: wrap;">
            <button class="btn btn-outline" onclick="app.openBarcodeLabelModal()" title="Open Barcode & Shelf Label Printing Studio" style="display: inline-flex; align-items: center; gap: 0.4rem; font-weight: 600;">
              <i class="fa-solid fa-tags" style="color: #6366f1;"></i> Barcode Studio
            </button>
            ${!isCashier ? `
              <button class="btn btn-outline" onclick="app.openBulkImportModal()" title="Import Products from Excel (.xlsx) or CSV with Column Mapping" style="display: inline-flex; align-items: center; gap: 0.4rem; font-weight: 600;">
                <i class="fa-solid fa-file-import" style="color: #0284c7;"></i> Import (CSV / XLSX)
              </button>
              <button class="btn btn-outline" onclick="app.exportProductsCatalog('xlsx')" title="Export Full Products Catalog to Excel (.xlsx)" style="display: inline-flex; align-items: center; gap: 0.4rem; font-weight: 600;">
                <i class="fa-solid fa-file-excel" style="color: #16a34a;"></i> Export .XLSX
              </button>
              <button class="btn btn-outline" onclick="app.exportProductsCatalog('csv')" title="Export Full Products Catalog to CSV" style="display: inline-flex; align-items: center; gap: 0.4rem; font-weight: 600;">
                <i class="fa-solid fa-file-csv" style="color: #2563eb;"></i> Export .CSV
              </button>
              <button class="btn btn-primary" onclick="app.openNewProductModal()" style="display: inline-flex; align-items: center; gap: 0.4rem;">
                <i class="fa-solid fa-plus"></i> Add New Product
              </button>
            ` : ''}
          </div>
        </div>
        <div class="panel-body">
          <div style="display: flex; gap: 1rem; margin-bottom: 1.25rem; flex-wrap: wrap;">
            <input type="text" id="products-search-input" class="form-control" placeholder="Search by name, SKU, or barcode..." style="max-width: 320px;">
            <select id="products-cat-filter" class="form-control" style="max-width: 200px;">
              <option value="All">All Categories</option>
              ${this.categories.map(c => `<option value="${this.escapeHtml(c)}">${this.escapeHtml(c)}</option>`).join('')}
            </select>
          </div>

          <div class="table-responsive">
            <table class="data-table" id="products-table">
              <thead>
                <tr>
                  <th style="width: 50px;">Photo</th>
                  <th>Product Name</th>
                  <th>SKU / Barcode</th>
                  <th>Category</th>
                  ${!isCashier ? '<th>Factory Cost</th>' : ''}
                  <th>Selling Price</th>
                  ${!isCashier ? '<th>Margin</th>' : ''}
                  <th>Stock on Hand</th>
                  ${!isCashier ? '<th>Actions</th>' : ''}
                </tr>
              </thead>
              <tbody id="products-table-body">
                ${this.products.map(p => {
                  const cost = Number(p.cost_price || 0);
                  const price = Number(p.selling_price || 0);
                  const margin = price - cost;
                  const marginPercent = cost > 0 ? Math.round((margin / cost) * 100) : 100;
                  const stock = Number(p.current_quantity || 0);
                  const isOut = stock <= 0;
                  const isLow = stock > 0 && stock <= Number(p.min_stock_alert || 5);
                  const imgUrl = p.image_url || 'assets/images/products/placeholder.svg';
                  const packRows = this.productUnitsOf(p).filter(u => !u.is_base);
                  const biggestPack = packRows.length > 0
                    ? packRows.reduce((a, b) => (b.size_in_base > a.size_in_base ? b : a), packRows[0]) : null;
                  const pType = p.product_type || 'standard';

                  return `
                    <tr>
                      <td>
                        <img src="${this.escapeHtml(imgUrl)}" class="table-img-thumb" alt="${this.escapeHtml(p.name)}" onerror="this.src='assets/images/products/placeholder.svg'">
                      </td>
                      <td style="font-weight: 600;">
                        <div>${this.escapeHtml(p.name)}</div>
                        <div style="margin-top: 0.2rem; display: flex; gap: 0.3rem; flex-wrap: wrap;">
                          ${pType === 'service' ? `
                            <span class="badge" style="background: #e0f2fe; color: #0369a1; border: 1px solid #bae6fd; font-size: 0.68rem; font-weight: 700;">
                              <i class="fa-solid fa-bell-concierge"></i> Service / Labor
                            </span>
                          ` : (pType === 'combo' ? `
                            <span class="badge" style="background: #f5f3ff; color: #6b21a8; border: 1px solid #ddd6fe; font-size: 0.68rem; font-weight: 700;">
                              <i class="fa-solid fa-layer-group"></i> Combo (${(p.combo_items || []).length} items)
                            </span>
                          ` : '')}
                          ${(this.isRentalProduct && this.isRentalProduct(p)) ? `
                            <span class="badge" style="background: #faf5ff; color: #7c3aed; border: 1px solid #d8b4fe; font-size: 0.68rem; font-weight: 700;">
                              <i class="fa-solid fa-boxes-packing"></i> Rental Fleet
                            </span>
                          ` : ''}
                          ${p.has_expiry == 1 ? `
                            <span class="badge" style="background: #fff7ed; color: #c2410c; border: 1px solid #fed7aa; font-size: 0.68rem; font-weight: 700;">
                              <i class="fa-solid fa-clock-rotate-left"></i> Perishable${p.expiry_date ? ` · Exp: ${this.escapeHtml(p.expiry_date)}` : ''}
                            </span>
                          ` : ''}
                        </div>
                      </td>
                      <td><span style="font-family: monospace;">${this.escapeHtml(p.sku || 'N/A')}</span></td>
                      <td><span class="badge badge-neutral">${this.escapeHtml(p.category || 'General')}</span></td>
                      ${!isCashier ? `<td>${this.formatCurrency(cost)}</td>` : ''}
                      <td style="font-weight: 700; color: var(--primary);">
                        ${this.formatCurrency(price)} <span style="font-size: 0.75rem; font-weight: normal; color: var(--slate-500);">/ ${this.escapeHtml(p.unit || 'pcs')}</span>
                        ${packRows.map(u => `
                          <div style="font-size: 0.72rem; color: #6366f1; font-weight: 600; margin-top: 2px;">
                            ${this.escapeHtml(u.unit_name)} (${u.size_in_base}x): ${this.formatCurrency(this.productUnitPrice(u, price))}
                          </div>
                        `).join('')}
                      </td>
                      ${!isCashier ? `<td style="color: var(--success); font-weight: 600;">+${this.formatCurrency(margin)} (${marginPercent}%)</td>` : ''}
                      <td>
                        ${pType === 'service' ? `
                          <span class="badge" style="background: #f1f5f9; color: #475569; font-weight: 700; border: 1px solid #cbd5e1;">
                            <i class="fa-solid fa-infinity"></i> Non-Inventory
                          </span>
                        ` : (pType === 'combo' ? `
                          <span class="badge" style="background: #f5f3ff; color: #6b21a8; font-weight: 700; border: 1px solid #ddd6fe;">
                            <i class="fa-solid fa-boxes-stacked"></i> Auto-Bundled
                          </span>
                        ` : `
                          <span class="badge ${isOut ? 'badge-danger' : (isLow ? 'badge-warning' : 'badge-success')}">
                            ${stock} ${this.escapeHtml(p.unit || 'pcs')}
                          </span>
                          ${biggestPack ? `
                            <div style="font-size: 0.70rem; color: var(--slate-500); margin-top: 2px;">
                              ≈ ${Math.floor(stock / biggestPack.size_in_base)} ${this.escapeHtml(biggestPack.unit_name)}${Math.floor(stock / biggestPack.size_in_base) === 1 ? '' : 's'}
                              ${(stock % biggestPack.size_in_base) > 0 ? ` + ${(stock % biggestPack.size_in_base)} ${this.escapeHtml(p.unit || 'pcs')}` : ''}
                            </div>
                          ` : ''}
                        `)}
                      </td>
                      ${!isCashier ? `
                        <td>
                          <div style="display: flex; gap: 0.35rem;">
                            <button class="btn btn-outline btn-sm" onclick="app.openProductDetailModal(${this.jsStr(p.id)})" title="View Product Details">
                              <i class="fa-solid fa-eye"></i>
                            </button>
                            <button class="btn btn-outline btn-sm" onclick="app.openBarcodeLabelModal(${this.jsStr(p.id)})" title="Print Barcode Labels">
                              <i class="fa-solid fa-barcode"></i>
                            </button>
                            <button class="btn btn-outline btn-sm" onclick="app.editProduct(${this.jsStr(p.id)})" title="Edit Product">
                              <i class="fa-solid fa-pen-to-square"></i> Edit
                            </button>
                            <button class="btn btn-outline btn-sm" onclick="app.confirmDeleteProduct(${this.jsStr(p.id)}, ${this.jsStr(p.name)})" style="color: var(--danger); border-color: var(--danger-border);" title="Delete Product">
                              <i class="fa-solid fa-trash"></i>
                            </button>
                          </div>
                        </td>
                      ` : ''}
                    </tr>
                  `;
                }).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  },

  bindProductsEvents() {
    const searchInput = document.getElementById('products-search-input');
    const catSelect = document.getElementById('products-cat-filter');

    const filterTable = () => {
      const q = (searchInput?.value || '').toLowerCase();
      const cat = catSelect?.value || 'All';
      const rows = document.querySelectorAll('#products-table-body tr');

      rows.forEach(r => {
        const text = r.innerText.toLowerCase();
        const matchesQuery = !q || text.includes(q);
        const matchesCat = cat === 'All' || text.includes(cat.toLowerCase());
        r.style.display = (matchesQuery && matchesCat) ? '' : 'none';
      });
    };

    if (searchInput) searchInput.addEventListener('input', filterTable);
    if (catSelect) catSelect.addEventListener('change', filterTable);

    const imgFileInput = document.getElementById('prod-form-image-file');
    if (imgFileInput) {
      imgFileInput.onchange = (e) => {
        const file = e.target.files[0];
        if (file) {
          const reader = new FileReader();
          reader.onload = (event) => {
            const dataUrl = event.target.result;
            const preview = document.getElementById('prod-form-image-preview');
            const urlField = document.getElementById('prod-form-image-url');
            if (preview) preview.src = dataUrl;
            if (urlField) urlField.value = dataUrl;
          };
          reader.readAsDataURL(file);
        }
      };
    }
  },

  setProductType(type) {
    const pType = ['standard', 'service', 'combo'].includes(type) ? type : 'standard';
    const typeInput = document.getElementById('prod-form-type');
    if (typeInput) typeInput.value = pType;

    const btnStandard = document.getElementById('btn-ptype-standard');
    const btnService = document.getElementById('btn-ptype-service');
    const btnCombo = document.getElementById('btn-ptype-combo');

    if (btnStandard) {
      btnStandard.style.border = (pType === 'standard') ? '2px solid var(--primary)' : '1.5px solid var(--slate-200)';
      btnStandard.style.background = (pType === 'standard') ? '#eff6ff' : '#ffffff';
    }
    if (btnService) {
      btnService.style.border = (pType === 'service') ? '2px solid #0284c7' : '1.5px solid var(--slate-200)';
      btnService.style.background = (pType === 'service') ? '#e0f2fe' : '#ffffff';
    }
    if (btnCombo) {
      btnCombo.style.border = (pType === 'combo') ? '2px solid #8b5cf6' : '1.5px solid var(--slate-200)';
      btnCombo.style.background = (pType === 'combo') ? '#f5f3ff' : '#ffffff';
    }

    const physicalSections = document.getElementById('prod-form-physical-sections');
    const comboSection = document.getElementById('prod-form-combo-section');
    const unitInput = document.getElementById('prod-form-unit');

    if (pType === 'service') {
      if (physicalSections) physicalSections.style.display = 'none';
      if (comboSection) comboSection.style.display = 'none';
      if (unitInput && (!unitInput.value || unitInput.value === 'pcs')) unitInput.value = 'service';
    } else if (pType === 'combo') {
      if (physicalSections) physicalSections.style.display = 'none';
      if (comboSection) comboSection.style.display = 'block';
      if (unitInput && (!unitInput.value || unitInput.value === 'service')) unitInput.value = 'pack';
      this.recalcComboSummary();
    } else {
      if (physicalSections) physicalSections.style.display = 'block';
      const stockGroup = document.getElementById('prod-form-stock-group');
      if (stockGroup) stockGroup.style.display = 'block';
      if (comboSection) comboSection.style.display = 'none';
      if (unitInput && unitInput.value === 'service') unitInput.value = 'pcs';
    }
  },

  renderComboComponentRows(comboItems) {
    const tbody = document.getElementById('prod-form-combo-tbody');
    if (!tbody) return;
    tbody.innerHTML = '';
    const items = Array.isArray(comboItems) ? comboItems : [];
    if (items.length === 0) {
      this.addComboComponentRow();
    } else {
      items.forEach(it => this.addComboComponentRow(it));
    }
    this.recalcComboSummary();
  },

  addComboComponentRow(comp = {}) {
    const tbody = document.getElementById('prod-form-combo-tbody');
    if (!tbody) return;
    const currentProdId = document.getElementById('prod-form-id')?.value || '';
    // Available products that can be components (exclude services, combos and self)
    const candidateProducts = (this.products || []).filter(p => p.id !== currentProdId && (p.product_type || 'standard') === 'standard');

    const selectedCompId = comp.component_product_id || comp.product_id || '';
    const qty = comp.quantity ? Number(comp.quantity) : 1;
    const unit = comp.unit || 'pcs';

    const tr = document.createElement('tr');
    tr.className = 'prod-combo-row';
    tr.innerHTML = `
      <td style="padding: 0.3rem 0.4rem;">
        <select class="form-control prod-combo-item-id" onchange="app.onComboItemChange(this)" style="font-size: 0.82rem; padding: 0.35rem 0.5rem; width: 100%;">
          <option value="">-- Select Child Product --</option>
          ${candidateProducts.map(p => `
            <option value="${this.escapeHtml(p.id)}" data-cost="${Number(p.cost_price || 0)}" data-price="${Number(p.selling_price || 0)}" data-unit="${this.escapeHtml(p.unit || 'pcs')}" ${p.id === selectedCompId ? 'selected' : ''}>
              ${this.escapeHtml(p.name)} (${this.formatCurrency(p.selling_price || 0)})
            </option>
          `).join('')}
        </select>
      </td>
      <td style="padding: 0.3rem 0.4rem;">
        <input type="number" class="form-control prod-combo-item-qty" min="0.01" step="any" value="${qty}" oninput="app.recalcComboSummary()" style="font-size: 0.82rem; padding: 0.35rem 0.5rem; width: 100%;">
      </td>
      <td style="padding: 0.3rem 0.4rem; font-size: 0.78rem; color: var(--slate-600);" class="prod-combo-item-unit">
        ${this.escapeHtml(unit)}
      </td>
      <td style="padding: 0.3rem 0.4rem; text-align: right; font-weight: 600; font-size: 0.8rem; color: var(--slate-700);" class="prod-combo-item-cost">
        $0.00
      </td>
      <td style="padding: 0.3rem 0.4rem; text-align: right;">
        <button type="button" class="btn btn-outline btn-sm" onclick="this.closest('tr').remove(); app.recalcComboSummary();" style="color: var(--danger); border-color: var(--danger-border); padding: 0.15rem 0.45rem;">
          <i class="fa-solid fa-xmark"></i>
        </button>
      </td>
    `;
    tbody.appendChild(tr);
    this.recalcComboSummary();
  },

  onComboItemChange(selectEl) {
    const tr = selectEl.closest('tr');
    if (!tr) return;
    const opt = selectEl.options[selectEl.selectedIndex];
    const unitEl = tr.querySelector('.prod-combo-item-unit');
    if (unitEl && opt) {
      unitEl.textContent = opt.getAttribute('data-unit') || 'pcs';
    }
    this.recalcComboSummary();
  },

  recalcComboSummary() {
    let totalCost = 0;
    let totalRetail = 0;
    document.querySelectorAll('.prod-combo-row').forEach(tr => {
      const select = tr.querySelector('.prod-combo-item-id');
      const qtyInput = tr.querySelector('.prod-combo-item-qty');
      const costEl = tr.querySelector('.prod-combo-item-cost');
      if (!select || !qtyInput) return;
      const opt = select.options[select.selectedIndex];
      if (!opt || !opt.value) {
        if (costEl) costEl.textContent = '$0.00';
        return;
      }
      const itemCost = parseFloat(opt.getAttribute('data-cost')) || 0;
      const itemPrice = parseFloat(opt.getAttribute('data-price')) || 0;
      const qty = parseFloat(qtyInput.value) || 0;
      const lineCost = itemCost * qty;
      const lineRetail = itemPrice * qty;
      totalCost += lineCost;
      totalRetail += lineRetail;
      if (costEl) costEl.textContent = this.formatCurrency(lineCost);
    });

    const totalCostDisp = document.getElementById('combo-total-cost-display');
    const marginDisp = document.getElementById('combo-suggested-margin-display');
    if (totalCostDisp) totalCostDisp.textContent = this.formatCurrency(totalCost);
    if (marginDisp) marginDisp.textContent = `Sum of items: ${this.formatCurrency(totalRetail)}`;

    const costField = document.getElementById('prod-form-cost');
    const priceField = document.getElementById('prod-form-price');
    const type = document.getElementById('prod-form-type')?.value;
    if (type === 'combo') {
      if (costField && (parseFloat(costField.value) === 0 || !costField.value)) {
        costField.value = totalCost.toFixed(2);
      }
      if (priceField && (parseFloat(priceField.value) === 0 || !priceField.value) && totalRetail > 0) {
        priceField.value = totalRetail.toFixed(2);
      }
    }
  },

  collectComboItems() {
    const items = [];
    document.querySelectorAll('.prod-combo-row').forEach(tr => {
      const select = tr.querySelector('.prod-combo-item-id');
      const qtyInput = tr.querySelector('.prod-combo-item-qty');
      if (!select || !qtyInput) return;
      const compId = select.value;
      const qty = parseFloat(qtyInput.value) || 1;
      const opt = select.options[select.selectedIndex];
      const unit = opt ? (opt.getAttribute('data-unit') || 'pcs') : 'pcs';
      if (compId) {
        items.push({
          component_product_id: compId,
          quantity: qty,
          unit: unit
        });
      }
    });
    return items;
  },

  openNewProductModal() {
    document.getElementById('product-modal-title').innerText = 'Add New Product';
    document.getElementById('prod-form-id').value = '';
    document.getElementById('prod-form-name').value = '';
    document.getElementById('prod-form-sku').value = '';
    document.getElementById('prod-form-barcode').value = '';
    document.getElementById('prod-form-category').value = 'General';
    document.getElementById('prod-form-unit').value = 'pcs';
    document.getElementById('prod-form-cost').value = '0.00';
    document.getElementById('prod-form-price').value = '0.00';
    const stockLbl = document.getElementById('prod-form-stock-label');
    if (stockLbl) stockLbl.innerText = 'Initial Stock Quantity';
    const stockHint = document.getElementById('prod-form-stock-hint');
    if (stockHint) stockHint.innerText = 'Starting stock in warehouse on creation.';
    document.getElementById('prod-form-stock').value = '0';
    document.getElementById('prod-form-stock-group').style.display = 'block';
    document.getElementById('prod-form-min-alert').value = '5';
    document.getElementById('prod-form-location').value = 'Main Storefront';
    document.getElementById('prod-form-image-url').value = 'assets/images/products/placeholder.svg';
    document.getElementById('prod-form-image-preview').src = 'assets/images/products/placeholder.svg';

    const expCheck = document.getElementById('prod-form-has-expiry');
    if (expCheck) expCheck.checked = false;
    const expBox = document.getElementById('prod-form-expiry-fields');
    if (expBox) expBox.style.display = 'none';
    const batchNoInput = document.getElementById('prod-form-batch-no');
    if (batchNoInput) batchNoInput.value = '';
    const expDateInput = document.getElementById('prod-form-expiry-date');
    if (expDateInput) expDateInput.value = '';
    const mfgDateInput = document.getElementById('prod-form-mfg-date');
    if (mfgDateInput) mfgDateInput.value = '';
    const alertDaysInput = document.getElementById('prod-form-alert-days');
    if (alertDaysInput) alertDaysInput.value = '30';

    const isRentalsEnabled = (this.storeProfile?.enable_rentals !== 0 && localStorage.getItem('storeflow_enable_rentals') !== '0');
    const rWrap = document.getElementById('prod-form-rental-wrap');
    if (rWrap) rWrap.style.display = isRentalsEnabled ? 'flex' : 'none';

    const rCheck = document.getElementById('prod-form-is-rental');
    if (rCheck) rCheck.checked = false;

    this.setProductType('standard');
    this.renderComboComponentRows([]);
    this.renderProductUnitRows(null);

    this.renderProductModalBranchRows(null);
    document.getElementById('product-modal').classList.add('active');
  },

  editProduct(productId) {
    const p = this.products.find(item => item.id === productId);
    if (!p) return;

    document.getElementById('product-modal-title').innerText = 'Edit Product';
    document.getElementById('prod-form-id').value = p.id;
    document.getElementById('prod-form-name').value = p.name;
    document.getElementById('prod-form-sku').value = p.sku || '';
    document.getElementById('prod-form-barcode').value = p.barcode || '';
    document.getElementById('prod-form-category').value = p.category || 'General';
    document.getElementById('prod-form-unit').value = p.unit || 'pcs';
    document.getElementById('prod-form-cost').value = p.cost_price || 0;
    document.getElementById('prod-form-price').value = p.selling_price || 0;

    const pType = p.product_type || 'standard';
    const stockLbl = document.getElementById('prod-form-stock-label');
    if (stockLbl) stockLbl.innerText = 'Current Stock Quantity';
    const stockHint = document.getElementById('prod-form-stock-hint');
    if (stockHint) stockHint.innerText = 'Current physical units in main warehouse.';
    const currentStock = (p.current_quantity !== undefined && p.current_quantity !== null)
      ? p.current_quantity
      : ((p.stock !== undefined && p.stock !== null) ? p.stock : 0);
    document.getElementById('prod-form-stock').value = currentStock;
    document.getElementById('prod-form-stock-group').style.display = (pType === 'service') ? 'none' : 'block';

    document.getElementById('prod-form-min-alert').value = p.min_stock_alert || 5;
    document.getElementById('prod-form-location').value = p.location || 'Main Storefront';

    const isPerishable = p.has_expiry == 1;
    const expCheck = document.getElementById('prod-form-has-expiry');
    if (expCheck) expCheck.checked = isPerishable;
    const expBox = document.getElementById('prod-form-expiry-fields');
    if (expBox) expBox.style.display = isPerishable ? 'block' : 'none';
    const batchNoInput = document.getElementById('prod-form-batch-no');
    if (batchNoInput) batchNoInput.value = p.batch_number || '';
    const expDateInput = document.getElementById('prod-form-expiry-date');
    if (expDateInput) expDateInput.value = p.expiry_date || '';
    const mfgDateInput = document.getElementById('prod-form-mfg-date');
    if (mfgDateInput) mfgDateInput.value = p.mfg_date || '';
    const alertDaysInput = document.getElementById('prod-form-alert-days');
    if (alertDaysInput) alertDaysInput.value = p.alert_before_days || 30;

    this.setProductType(pType);
    if (pType === 'combo') {
      this.renderComboComponentRows(p.combo_items || []);
    } else {
      this.renderComboComponentRows([]);
    }

    const isRentalsEnabled = (this.storeProfile?.enable_rentals !== 0 && localStorage.getItem('storeflow_enable_rentals') !== '0');
    const rWrap = document.getElementById('prod-form-rental-wrap');
    if (rWrap) rWrap.style.display = isRentalsEnabled ? 'flex' : 'none';

    const rCheckEdit = document.getElementById('prod-form-is-rental');
    if (rCheckEdit) rCheckEdit.checked = Boolean(Number(p.is_rental) === 1 || (this.isRentalProduct && this.isRentalProduct(p)));

    this.renderProductUnitRows(p);

    const img = p.image_url || 'assets/images/products/placeholder.svg';
    document.getElementById('prod-form-image-url').value = img;
    document.getElementById('prod-form-image-preview').src = img;

    this.renderProductModalBranchRows(p);
    document.getElementById('product-modal').classList.add('active');
  },

  // The loose unit is not a row the shop types: it is the product, and its price is the
  // selling price field above. Only the packs built on top of it are editable here.
  productUnitRowHtml(unit = {}) {
    const price = (unit.selling_price === null || unit.selling_price === undefined || unit.selling_price === '')
      ? '' : Number(unit.selling_price).toFixed(2);
    return `
      <tr class="prod-unit-row">
        <td style="padding: 0.2rem 0.4rem 0.2rem 0; min-width: 140px;">
          <input type="text" class="form-control prod-unit-name" list="pack-unit-suggestions" placeholder="e.g. Crate"
                 value="${this.escapeHtml(unit.unit_name || '')}" style="font-size: 0.82rem; padding: 0.3rem 0.45rem; width: 100%; min-width: 120px;">
        </td>
        <td style="padding: 0.2rem 0.4rem;">
          <input type="number" class="form-control prod-unit-size" min="2" step="any" placeholder="30"
                 value="${unit.size_in_base ? this.escapeHtml(String(unit.size_in_base)) : ''}"
                 oninput="app.suggestProductUnitPrice(this)" style="font-size: 0.82rem; padding: 0.3rem 0.45rem;">
        </td>
        <td style="padding: 0.2rem 0.4rem;">
          <div style="display: flex; gap: 0.3rem;">
            <input type="number" class="form-control prod-unit-price" step="any" placeholder="0.00" value="${price}"
                   style="font-size: 0.82rem; padding: 0.3rem 0.45rem;">
            <button type="button" class="btn btn-outline btn-sm" title="Fill in loose price x this multiplier"
                    onclick="app.suggestProductUnitPrice(this)"
                    style="font-size: 0.72rem; white-space: nowrap; padding: 0 0.45rem; background: #ffffff;">
              <i class="fa-solid fa-calculator" style="color: #6366f1;"></i>
            </button>
          </div>
        </td>
        <td style="padding: 0.2rem 0.4rem;">
          <input type="text" class="form-control prod-unit-barcode" placeholder="e.g. 8901234567890"
                 value="${this.escapeHtml(unit.barcode || '')}" style="font-size: 0.82rem; padding: 0.3rem 0.45rem;">
        </td>
        <td style="padding: 0.2rem 0; text-align: right;">
          <button type="button" class="btn btn-outline btn-sm" title="Stop selling this size" onclick="app.removeProductUnitRow(this)"
                  style="color: var(--danger); border-color: var(--danger-border); padding: 0 0.45rem;">
            <i class="fa-solid fa-xmark"></i>
          </button>
        </td>
      </tr>
    `;
  },

  renderProductUnitRows(product = null) {
    const tbody = document.getElementById('prod-form-units-tbody');
    if (!tbody) return;
    const baseUnit = (document.getElementById('prod-form-unit')?.value || 'pcs').trim() || 'pcs';
    const baseRow = `
      <tr class="prod-unit-base-row">
        <td style="padding: 0.2rem 0.4rem 0.2rem 0;">
          <span class="badge badge-neutral" id="prod-unit-base-name">${this.escapeHtml(baseUnit)}</span>
          <span style="font-size: 0.70rem; color: var(--slate-500); margin-left: 0.3rem;">loose unit</span>
        </td>
        <td style="padding: 0.2rem 0.4rem; font-size: 0.80rem; color: var(--slate-500);">1</td>
        <td style="padding: 0.2rem 0.4rem; font-size: 0.74rem; color: var(--slate-500);">from the selling price</td>
        <td style="padding: 0.2rem 0.4rem; font-size: 0.74rem; color: var(--slate-500);">the code field above</td>
        <td></td>
      </tr>
    `;
    tbody.innerHTML = baseRow + this.productUnitsOf(product)
      .filter(u => !u.is_base)
      .map(u => this.productUnitRowHtml(u))
      .join('');
  },

  addProductUnitRow() {
    const tbody = document.getElementById('prod-form-units-tbody');
    if (!tbody) return;
    tbody.insertAdjacentHTML('beforeend', this.productUnitRowHtml());
    const added = tbody.querySelectorAll('.prod-unit-row');
    added[added.length - 1]?.querySelector('.prod-unit-name')?.focus();
  },

  // Changing the loose unit relabels the row that carries it; the typed packs stay as they
  // are, because the shop still means thirty each of them.
  refreshProductUnitBaseRow() {
    const cell = document.getElementById('prod-unit-base-name');
    if (cell) cell.innerText = (document.getElementById('prod-form-unit')?.value || 'pcs').trim() || 'pcs';
  },

  removeProductUnitRow(button) {
    button?.closest?.('.prod-unit-row')?.remove();
  },

  suggestProductUnitPrice(target) {
    const row = target?.closest?.('.prod-unit-row');
    if (!row) return;
    const size = parseFloat(row.querySelector('.prod-unit-size')?.value) || 0;
    const basePrice = parseFloat(document.getElementById('prod-form-price')?.value) || 0;
    const priceInput = row.querySelector('.prod-unit-price');
    if (priceInput && size > 1 && basePrice > 0) {
      priceInput.value = (size * basePrice).toFixed(2);
    }
  },

  collectProductUnits() {
    const rows = [];
    document.querySelectorAll('#prod-form-units-tbody .prod-unit-row').forEach(row => {
      const name = (row.querySelector('.prod-unit-name')?.value || '').trim();
      const size = (row.querySelector('.prod-unit-size')?.value || '').trim();
      const price = (row.querySelector('.prod-unit-price')?.value || '').trim();
      const code = (row.querySelector('.prod-unit-barcode')?.value || '').trim();
      // A row clicked into existence and never filled in is the shop changing its mind,
      // not a size with a blank name.
      if (name === '' && size === '' && price === '' && code === '') return;
      rows.push({
        unit_name: name, size_in_base: size,
        selling_price: price === '' ? null : price,
        barcode: code
      });
    });
    return rows;
  },

  // The same refusals the catalogue endpoint makes, checked before anything is written.
  // An offline till keeps its own copy of the product, so a size the server would reject
  // would otherwise sit on the shelf and price a crate as a loose egg.
  checkProductUnits(units, baseUnitName, looseCode = '') {
    if (String(baseUnitName || '').length > 40) return 'The loose unit name is too long.';
    if (units.length > 12) return 'A product can have at most 12 sellable sizes.';
    const base = String(baseUnitName || 'pcs').trim().toLowerCase();
    const wanted = String(looseCode || '').trim().toLowerCase().replace(/[\s\-_]/g, '');
    const seen = {};
    const seenCodes = {};
    for (const u of units) {
      const name = String(u.unit_name || '').trim();
      if (name === '') return 'A pack size needs a name, such as Crate or Carton.';
      if (name.length > 40) return `"${name}" is too long for a size name.`;
      const key = name.toLowerCase();
      if (key === base) return `"${name}" is the loose unit, so it cannot be a pack size as well.`;
      if (seen[key]) return `"${name}" is used twice on this product.`;
      seen[key] = true;

      const size = Number(u.size_in_base);
      if (String(u.size_in_base).trim() === '' || !Number.isFinite(size) || size <= 1) {
        return `"${name}" must hold more than one ${baseUnitName} to be a pack.`;
      }
      if (size > 1000000) return `"${name}" is too large to be a real pack.`;
      if (u.selling_price !== null && String(u.selling_price).trim() !== '') {
        const price = Number(u.selling_price);
        if (!Number.isFinite(price) || price < 0) return `"${name}" has a price that is not a number.`;
      }

      // Two sizes answering the same number is not a clerical detail: the scanned code
      // picks one and the customer is charged for the other. The loose unit answers the
      // product's own code, so a pack wearing that number would take the till to the
      // pack price every time the shop reaches for the single. Codes are compared the way
      // the scanner reads them, with the digit grouping taken out.
      const code = String(u.barcode || '').trim();
      if (code.length > 64) return `"${name}" has a code that is too long.`;
      const codeKey = code.toLowerCase().replace(/[\s\-_]/g, '');
      if (codeKey === '') continue;
      if (wanted !== '' && codeKey === wanted) return `"${name}" uses the same code as the loose ${baseUnitName}.`;
      if (seenCodes[codeKey]) return `"${name}" shares a code with ${seenCodes[codeKey]}.`;
      seenCodes[codeKey] = name;
    }
    return '';
  },

  renderProductModalBranchRows(product = null) {
    const section = document.getElementById('prod-form-branch-section');
    const tbody = document.getElementById('prod-form-branch-tbody');
    const stockGroup = document.getElementById('prod-form-stock-group');

    if (!section || !tbody) return;

    if (!this.isMultiBranch) {
      section.style.display = 'none';
      if (stockGroup) stockGroup.style.display = product ? 'none' : 'block';
      return;
    }

    section.style.display = 'block';
    if (stockGroup) stockGroup.style.display = 'none';

    const branchList = this.branches && this.branches.length > 0 ? this.branches : [{ branch_code: 'MAIN-01', name: 'Main Storefront' }];
    const settingsMap = {};
    if (product && product.branch_settings) {
      product.branch_settings.forEach(b => {
        settingsMap[(b.branch_code || '').toUpperCase()] = b;
      });
    }

    tbody.innerHTML = branchList.map(b => {
      const code = (b.branch_code || 'MAIN-01').toUpperCase();
      const existing = settingsMap[code];
      const stock = existing ? Number(existing.current_quantity || 0) : (product && code === 'MAIN-01' ? Number(product.current_quantity || 0) : 0);
      const customPrice = (existing && existing.custom_selling_price !== null && existing.custom_selling_price !== undefined) ? existing.custom_selling_price : '';
      const isAvail = existing ? (existing.is_available !== 0) : true;

      return `
        <tr data-branch-code="${this.escapeHtml(code)}">
          <td>
            <div style="font-weight: 700; color: var(--slate-900); font-size: 0.85rem;">${this.escapeHtml(b.name)}</div>
            <span style="font-size: 0.72rem; color: var(--slate-500); font-family: monospace;">${this.escapeHtml(code)}</span>
          </td>
          <td>
            <input type="number" class="form-control prod-branch-stock" data-branch="${this.escapeHtml(code)}" value="${stock}" min="0" style="padding: 0.25rem 0.5rem; font-size: 0.85rem; font-weight: 700;">
          </td>
          <td>
            <input type="number" class="form-control prod-branch-price" data-branch="${this.escapeHtml(code)}" value="${this.escapeHtml(customPrice)}" step="any" placeholder="Default" style="padding: 0.25rem 0.5rem; font-size: 0.85rem;">
          </td>
          <td style="text-align: center;">
            <input type="checkbox" class="prod-branch-avail" data-branch="${this.escapeHtml(code)}" ${isAvail ? 'checked' : ''} style="width: 18px; height: 18px; cursor: pointer;">
          </td>
        </tr>
      `;
    }).join('');
  },

  toggleProductExpiryFields(checked) {
    const box = document.getElementById('prod-form-expiry-fields');
    if (box) box.style.display = checked ? 'block' : 'none';
    if (checked) {
      const bInput = document.getElementById('prod-form-batch-no');
      if (bInput && !bInput.value) {
        this.generateBatchNumber();
      }
    }
  },

  generateBatchNumber() {
    const d = new Date();
    const dateStr = d.toISOString().slice(0, 10).replace(/-/g, '');
    const rand = Math.floor(100 + Math.random() * 900);
    const bInput = document.getElementById('prod-form-batch-no');
    if (bInput) bInput.value = `LOT-${dateStr}-${rand}`;
  },

  closeProductModal() {
    document.getElementById('product-modal').classList.remove('active');
  },

  async saveProductForm() {
    const id = document.getElementById('prod-form-id').value || ('prod_' + Math.random().toString(36).substring(2, 10));
    const isEdit = Boolean(document.getElementById('prod-form-id').value);
    const name = document.getElementById('prod-form-name').value.trim();
    if (!name) {
      this.showToast('Product name is required.', 'warning');
      return;
    }

    let sku = document.getElementById('prod-form-sku').value.trim();
    if (!sku) {
      if (isEdit) {
        const existingProd = this.products.find(p => p.id === id);
        sku = existingProd?.sku || '';
      }
      if (!sku) {
        const cleanName = name.replace(/[^a-zA-Z0-9]/g, '').substring(0, 4).toUpperCase() || 'PROD';
        sku = 'SKU-' + cleanName + '-' + Math.floor(100 + Math.random() * 900);
      }
    }

    const hasExpiry = document.getElementById('prod-form-has-expiry')?.checked ? 1 : 0;
    const batchNumber = (document.getElementById('prod-form-batch-no')?.value || '').trim();
    const expiryDate = (document.getElementById('prod-form-expiry-date')?.value || '').trim() || null;
    const mfgDate = (document.getElementById('prod-form-mfg-date')?.value || '').trim() || null;
    const alertBeforeDays = parseInt(document.getElementById('prod-form-alert-days')?.value) || 30;

    const productType = document.getElementById('prod-form-type')?.value || 'standard';
    const baseUnitName = document.getElementById('prod-form-unit').value.trim() || 'pcs';
    const looseBarcode = document.getElementById('prod-form-barcode').value.trim();
    const unitRows = (productType === 'service') ? [] : this.collectProductUnits();
    const unitProblem = this.checkProductUnits(unitRows, baseUnitName, looseBarcode);
    if (unitProblem) {
      this.showToast(unitProblem, 'warning');
      return;
    }

    const comboItems = (productType === 'combo') ? this.collectComboItems() : [];
    if (productType === 'combo' && comboItems.length === 0) {
      this.showToast('Please add at least one child component to this combo pack.', 'warning');
      return;
    }

    const payload = {
      id,
      name,
      sku,
      barcode: looseBarcode,
      category: document.getElementById('prod-form-category').value.trim() || 'General',
      unit: (productType === 'service' ? 'service' : baseUnitName),
      cost_price: parseFloat(document.getElementById('prod-form-cost').value) || 0,
      selling_price: parseFloat(document.getElementById('prod-form-price').value) || 0,
      initial_stock: (productType === 'service' ? 0 : (parseFloat(document.getElementById('prod-form-stock').value) || 0)),
      current_stock: (productType === 'service' ? 0 : (parseFloat(document.getElementById('prod-form-stock').value) || 0)),
      min_stock_alert: parseInt(document.getElementById('prod-form-min-alert').value) || 5,
      location: document.getElementById('prod-form-location').value.trim() || 'Main Storefront',
      image_url: document.getElementById('prod-form-image-url').value || 'assets/images/products/placeholder.svg',
      has_expiry: (productType === 'service' ? 0 : hasExpiry),
      batch_number: batchNumber,
      expiry_date: expiryDate,
      mfg_date: mfgDate,
      alert_before_days: alertBeforeDays,
      units: unitRows,
      product_type: productType,
      is_rental: document.getElementById('prod-form-is-rental')?.checked ? 1 : 0,
      combo_items: comboItems
    };

    if (this.isMultiBranch) {
      const branchSettings = [];
      let totalStock = 0;
      document.querySelectorAll('#prod-form-branch-tbody tr').forEach(row => {
        const bCode = row.getAttribute('data-branch-code');
        const stock = parseFloat(row.querySelector('.prod-branch-stock')?.value) || 0;
        const customPriceVal = row.querySelector('.prod-branch-price')?.value;
        const customPrice = (customPriceVal !== '' && customPriceVal !== null && !isNaN(parseFloat(customPriceVal))) ? parseFloat(customPriceVal) : null;
        const isAvail = row.querySelector('.prod-branch-avail')?.checked ? 1 : 0;
        branchSettings.push({ branch_code: bCode, current_quantity: stock, custom_selling_price: customPrice, is_available: isAvail });
        totalStock += stock;
      });
      payload.branch_settings = branchSettings;
      payload.current_quantity = totalStock;
    }

    if (isEdit) {
      const idx = this.products.findIndex(p => p.id === id);
      if (idx >= 0) {
        this.products[idx] = { ...this.products[idx], ...payload };
        await localDB.products.put(this.products[idx]);
      }
    } else {
      payload.current_quantity = this.isMultiBranch ? payload.current_quantity : payload.initial_stock;
      this.products.push(payload);
      await localDB.products.put(payload);
    }

    if (this.isOnline) {
      try {
        const res = await this.apiFetch('api/endpoints/products.php', {
          method: isEdit ? 'PUT' : 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        const resData = await res.json().catch(() => null);
        if (!res.ok || (resData && resData.success === false)) {
          throw new Error(resData?.message || 'Server error saving product');
        }
        await this.fetchProducts();
        await this.fetchInventory();
      } catch (err) {
        console.warn('Backend product save notice:', err.message);
        await localDB.sync_outbox.add({ entity: 'product', action: isEdit ? 'UPDATE' : 'CREATE', data: payload, timestamp: new Date().toISOString(), synced: 0 });
      }
    } else {
      await localDB.sync_outbox.add({ entity: 'product', action: isEdit ? 'UPDATE' : 'CREATE', data: payload, timestamp: new Date().toISOString(), synced: 0 });
    }

    this.closeProductModal();
    this.renderCurrentView();
    if (typeof this.broadcastSyncEvent === 'function') {
      this.broadcastSyncEvent('PRODUCT_MUTATED', { action: isEdit ? 'UPDATE' : 'CREATE', product: payload });
    }
    this.showToast('Product saved successfully!', 'success');
  },

  // =========================================================================
  // BULK PRODUCT IMPORT (CSV / XLSX WITH INTERACTIVE COLUMN MAPPER) & EXPORT
  // =========================================================================

  getBulkImportFieldDefinitions() {
    return [
      { key: '', label: '-- Ignore Column --' },
      { key: 'name', label: 'Product Name * (Required)' },
      { key: 'selling_price', label: 'Selling Price (Loose Unit) *' },
      { key: 'cost_price', label: 'Factory Cost Price' },
      { key: 'category', label: 'Category (e.g. Beverages)' },
      { key: 'sku', label: 'SKU / Item Code' },
      { key: 'barcode', label: 'Barcode (Loose Unit)' },
      { key: 'unit', label: 'Loose Unit Name (btl, pcs, can)' },
      { key: 'initial_stock', label: 'Stock Quantity (in Loose Units)' },
      { key: 'min_stock_alert', label: 'Min Stock Alert Threshold' },
      { key: 'location', label: 'Storage Location' },
      { key: 'pack_unit', label: 'Pack 1: Size Name (Crate / Carton)' },
      { key: 'pack_size', label: 'Pack 1: Holds (Units per Pack)' },
      { key: 'pack_price', label: 'Pack 1: Selling Price' },
      { key: 'pack_barcode', label: 'Pack 1: Barcode' },
      { key: 'pack2_unit', label: 'Pack 2: Size Name (Half-Pack)' },
      { key: 'pack2_size', label: 'Pack 2: Holds (Units per Pack)' },
      { key: 'pack2_price', label: 'Pack 2: Selling Price' },
      { key: 'expiry_date', label: 'Expiry Date (YYYY-MM-DD)' },
      { key: 'batch_number', label: 'Batch / Lot Number' }
    ];
  },

  openBulkImportModal() {
    this._bulkImportRawMatrix = null;
    this._bulkImportFileName = '';
    this._bulkImportColMap = {};

    const fileInput = document.getElementById('bulk-import-file-input');
    if (fileInput) fileInput.value = '';
    const fileLabel = document.getElementById('bulk-import-filename-label');
    if (fileLabel) fileLabel.textContent = 'No file selected yet';
    const mapperSec = document.getElementById('bulk-import-mapper-section');
    if (mapperSec) mapperSec.style.display = 'none';
    const btnImport = document.getElementById('btn-execute-bulk-import');
    if (btnImport) {
      btnImport.disabled = true;
      btnImport.innerHTML = '<i class="fa-solid fa-cloud-arrow-up"></i> Import Products';
    }
    const modal = document.getElementById('bulk-import-modal');
    if (modal) modal.classList.add('active');
  },

  closeBulkImportModal() {
    const modal = document.getElementById('bulk-import-modal');
    if (modal) modal.classList.remove('active');
  },

  async handleBulkImportFileSelect(event) {
    const file = event?.target?.files?.[0];
    if (!file) return;

    this._bulkImportFileName = file.name;
    const fileLabel = document.getElementById('bulk-import-filename-label');
    if (fileLabel) {
      fileLabel.innerHTML = `<i class="fa-solid fa-file-circle-check" style="color: #16a34a;"></i> ${this.escapeHtml(file.name)} <span style="font-weight: 400; color: var(--slate-500);">(${(file.size / 1024).toFixed(1)} KB)</span>`;
    }

    try {
      const ext = (file.name.split('.').pop() || '').toLowerCase();
      let matrix = [];
      if (ext === 'xlsx') {
        const buffer = await file.arrayBuffer();
        matrix = await this.parseXlsxMatrix(buffer);
      } else {
        const text = await file.text();
        matrix = this.parseCsvMatrix(text);
      }

      // Filter out completely blank rows
      matrix = (matrix || []).filter(row => Array.isArray(row) && row.some(cell => String(cell ?? '').trim() !== ''));
      if (matrix.length === 0) {
        this.showToast('The selected file appears to be empty.', 'warning');
        return;
      }

      this._bulkImportRawMatrix = matrix;
      this.reparseBulkImportPreview(true);
    } catch (err) {
      console.error('Bulk import file parse error:', err);
      this.showToast('Could not read file: ' + (err.message || 'Unsupported format'), 'danger');
    }
  },

  reparseBulkImportPreview(autoDetect = false) {
    const matrix = this._bulkImportRawMatrix;
    if (!Array.isArray(matrix) || matrix.length === 0) return;

    const hasHeaders = Boolean(document.getElementById('bulk-import-has-headers')?.checked);
    const maxCols = matrix.reduce((max, r) => Math.max(max, r.length), 0);

    const headers = [];
    for (let c = 0; c < maxCols; c++) {
      const rawH = hasHeaders ? String(matrix[0]?.[c] ?? '').trim() : '';
      headers.push(rawH || `Column ${c + 1}`);
    }

    const dataRows = hasHeaders ? matrix.slice(1) : matrix.slice(0);
    this._bulkImportHeaders = headers;
    this._bulkImportDataRows = dataRows;

    if (autoDetect || !this._bulkImportColMap || Object.keys(this._bulkImportColMap).length === 0) {
      this._bulkImportColMap = this.autoDetectBulkColumnMap(headers);
    }

    this.renderBulkImportMapperTable();
  },

  autoDetectBulkColumnMap(headers) {
    const map = {};
    const usedKeys = new Set();
    const rules = [
      { key: 'name', rx: /^(product\s*name|item\s*name|item\s*description|product\s*title|product|item|description|name|article|good)$/i },
      { key: 'sku', rx: /^(sku|item\s*code|product\s*code|code|part\s*no|ref|plu)$/i },
      { key: 'barcode', rx: /^(barcode|bar\s*code|upc|ean|gtin|loose\s*barcode|scan\s*code)$/i },
      { key: 'category', rx: /^(category|department|dept|group|product\s*group|section|brand|type)$/i },
      { key: 'unit', rx: /^(unit|uom|base\s*unit|loose\s*unit|measure|selling\s*unit)$/i },
      { key: 'cost_price', rx: /^(cost\s*price|factory\s*cost|buying\s*price|unit\s*cost|cost|purchase\s*price|wholesale\s*cost|supply\s*price)$/i },
      { key: 'selling_price', rx: /^(selling\s*price|retail\s*price|unit\s*price|price|sale\s*price|customer\s*price|loose\s*price|rate|mrp)$/i },
      { key: 'initial_stock', rx: /^(stock|stock\s*on\s*hand|current\s*stock|opening\s*stock|initial\s*stock|qty|quantity|on\s*hand|balance|inventory)$/i },
      { key: 'min_stock_alert', rx: /^(min\s*stock|reorder\s*level|min\s*alert|alert\s*threshold|low\s*stock|minimum\s*stock)$/i },
      { key: 'location', rx: /^(location|shelf|bin|aisle|warehouse|storefront)$/i },
      { key: 'pack_unit', rx: /^(pack\s*unit|pack\s*1\s*name|pack\s*name|pack\s*type|wholesale\s*unit|box\s*type|crate\s*type)$/i },
      { key: 'pack_size', rx: /^(pack\s*size|pack\s*1\s*holds|pack\s*holds|units\s*per\s*pack|bottles\s*per\s*crate|qty\s*per\s*pack|multiplier|case\s*pack)$/i },
      { key: 'pack_price', rx: /^(pack\s*price|pack\s*1\s*price|crate\s*price|carton\s*price|box\s*price|wholesale\s*price|case\s*price)$/i },
      { key: 'pack_barcode', rx: /^(pack\s*barcode|pack\s*1\s*barcode|crate\s*barcode|carton\s*barcode|case\s*barcode)$/i },
      { key: 'pack2_unit', rx: /^(pack\s*2\s*name|pack\s*2\s*unit|second\s*pack\s*name|half\s*pack\s*name)$/i },
      { key: 'pack2_size', rx: /^(pack\s*2\s*size|pack\s*2\s*holds|second\s*pack\s*holds|half\s*pack\s*holds)$/i },
      { key: 'pack2_price', rx: /^(pack\s*2\s*price|second\s*pack\s*price|half\s*pack\s*price)$/i },
      { key: 'expiry_date', rx: /^(expiry\s*date|exp\s*date|expiration|expiry|best\s*before)$/i },
      { key: 'batch_number', rx: /^(batch\s*number|batch\s*no|lot\s*number|lot\s*no|batch|lot)$/i }
    ];

    // Pass 1: exact regex match
    headers.forEach((h, idx) => {
      const clean = String(h || '').replace(/[*_#-]+/g, ' ').replace(/\s+/g, ' ').trim();
      for (const r of rules) {
        if (!usedKeys.has(r.key) && r.rx.test(clean)) {
          map[idx] = r.key;
          usedKeys.add(r.key);
          break;
        }
      }
    });

    // Pass 2: substring heuristics for unmapped headers
    headers.forEach((h, idx) => {
      if (map[idx]) return;
      const lower = String(h || '').toLowerCase();
      const tryAssign = (k, cond) => {
        if (!map[idx] && !usedKeys.has(k) && cond) {
          map[idx] = k;
          usedKeys.add(k);
        }
      };
      tryAssign('name', lower.includes('product name') || lower.includes('item name') || lower.includes('description'));
      tryAssign('pack_price', (lower.includes('crate') || lower.includes('carton') || lower.includes('pack') || lower.includes('wholesale')) && lower.includes('price'));
      tryAssign('pack_size', (lower.includes('crate') || lower.includes('carton') || lower.includes('pack')) && (lower.includes('size') || lower.includes('hold') || lower.includes('qty')));
      tryAssign('pack_unit', (lower.includes('pack') || lower.includes('wholesale')) && (lower.includes('unit') || lower.includes('type') || lower.includes('name')));
      tryAssign('cost_price', lower.includes('cost') || lower.includes('buying'));
      tryAssign('selling_price', lower.includes('selling') || lower.includes('retail') || lower.includes('price'));
      tryAssign('initial_stock', lower.includes('stock') || lower.includes('quantity') || lower.includes('qty') || lower.includes('on hand'));
      tryAssign('min_stock_alert', lower.includes('reorder') || lower.includes('alert'));
      tryAssign('barcode', lower.includes('barcode') || lower.includes('ean') || lower.includes('upc'));
      tryAssign('sku', lower.includes('sku') || lower.includes('item code'));
      tryAssign('category', lower.includes('category') || lower.includes('dept'));
      tryAssign('unit', lower.includes('unit') || lower.includes('uom'));
      tryAssign('expiry_date', lower.includes('expir'));
      tryAssign('batch_number', lower.includes('batch') || lower.includes('lot'));
    });

    return map;
  },

  renderBulkImportMapperTable() {
    const mapperSec = document.getElementById('bulk-import-mapper-section');
    const thead = document.getElementById('bulk-import-preview-thead');
    const tbody = document.getElementById('bulk-import-preview-tbody');
    if (!mapperSec || !thead || !tbody) return;

    mapperSec.style.display = 'flex';
    const headers = this._bulkImportHeaders || [];
    const dataRows = this._bulkImportDataRows || [];
    const fields = this.getBulkImportFieldDefinitions();

    // Row 1: Dropdown selectors for each column
    // Row 2: Original uploaded column title
    const selectRowCells = headers.map((h, colIdx) => {
      const selectedKey = this._bulkImportColMap[colIdx] || '';
      const isMapped = Boolean(selectedKey);
      return `
        <th data-col-th="${colIdx}" style="min-width: 195px; padding: 0.6rem 0.65rem; vertical-align: top; background: ${isMapped ? '#eff6ff' : '#f8fafc'}; border-bottom: 2px solid ${isMapped ? '#3b82f6' : 'var(--slate-200)'}; border-right: 1px solid var(--slate-200);">
          <div style="display: flex; align-items: center; justify-content: space-between; font-size: 0.7rem; font-weight: 700; color: ${isMapped ? '#1d4ed8' : 'var(--slate-500)'}; margin-bottom: 0.35rem; text-transform: uppercase;">
            <span>Column ${colIdx + 1}</span>
            <span class="bulk-col-status-icon">${isMapped ? '<i class="fa-solid fa-circle-check" style="color: #16a34a;"></i> Matched' : 'Ignored'}</span>
          </div>
          <select class="form-control bulk-col-map-select" data-col-idx="${colIdx}" onchange="app.onBulkColMapChange(this)" style="font-size: 0.78rem; font-weight: 700; padding: 0.35rem 0.45rem; border-color: ${isMapped ? '#60a5fa' : 'var(--slate-300)'}; background: #ffffff;">
            ${fields.map(f => `<option value="${f.key}" ${f.key === selectedKey ? 'selected' : ''}>${this.escapeHtml(f.label)}</option>`).join('')}
          </select>
          <div style="margin-top: 0.4rem; font-size: 0.75rem; font-weight: 700; color: var(--slate-800); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${this.escapeHtml(h)}">
            <i class="fa-solid fa-table-columns" style="color: var(--slate-400); font-size: 0.68rem;"></i> ${this.escapeHtml(h)}
          </div>
        </th>
      `;
    }).join('');

    thead.innerHTML = `<tr>${selectRowCells}</tr>`;

    const sampleRows = dataRows.slice(0, 8);
    if (sampleRows.length === 0) {
      tbody.innerHTML = `<tr><td colspan="${Math.max(1, headers.length)}" style="text-align: center; padding: 1.5rem; color: var(--slate-400);">No data rows found below header row. Uncheck "First row contains column titles" if your file has no headers.</td></tr>`;
    } else {
      tbody.innerHTML = sampleRows.map((row) => {
        const cells = headers.map((_, colIdx) => {
          const val = String(row[colIdx] ?? '').trim();
          const isMapped = Boolean(this._bulkImportColMap[colIdx]);
          return `<td data-col-td="${colIdx}" style="padding: 0.45rem 0.65rem; border-right: 1px solid var(--slate-100); color: ${isMapped ? 'var(--slate-800)' : 'var(--slate-400)'}; background: ${isMapped ? '#ffffff' : '#fcfcfd'}; white-space: nowrap; max-width: 220px; overflow: hidden; text-overflow: ellipsis;">${val !== '' ? this.escapeHtml(val) : '<span style="color: #cbd5e1;">—</span>'}</td>`;
        }).join('');
        return `<tr>${cells}</tr>`;
      }).join('');
    }

    this.updateBulkImportValidationState();
  },

  onBulkColMapChange(selectEl) {
    const colIdx = parseInt(selectEl.getAttribute('data-col-idx'), 10);
    const chosenKey = selectEl.value;

    // If another column already uses this key, unmap that other column so each target field maps to 1 column
    if (chosenKey !== '') {
      Object.keys(this._bulkImportColMap).forEach(otherIdx => {
        if (Number(otherIdx) !== colIdx && this._bulkImportColMap[otherIdx] === chosenKey) {
          delete this._bulkImportColMap[otherIdx];
        }
      });
    }

    if (chosenKey === '') {
      delete this._bulkImportColMap[colIdx];
    } else {
      this._bulkImportColMap[colIdx] = chosenKey;
    }

    this.renderBulkImportMapperTable();
  },

  updateBulkImportValidationState() {
    const headers = this._bulkImportHeaders || [];
    const dataRows = this._bulkImportDataRows || [];
    const mappedValues = Object.values(this._bulkImportColMap || {}).filter(Boolean);
    const hasName = mappedValues.includes('name');
    const hasPrice = mappedValues.includes('selling_price');

    const summaryEl = document.getElementById('bulk-import-file-summary');
    if (summaryEl) {
      summaryEl.textContent = `${dataRows.length} product row${dataRows.length === 1 ? '' : 's'} detected in ${this._bulkImportFileName || 'sheet'}`;
    }

    const matchBadge = document.getElementById('bulk-import-match-badge');
    if (matchBadge) {
      matchBadge.textContent = `${mappedValues.length} of ${headers.length} columns matched`;
    }

    const readyBadge = document.getElementById('bulk-import-ready-badge');
    const btnImport = document.getElementById('btn-execute-bulk-import');

    if (dataRows.length === 0) {
      if (readyBadge) {
        readyBadge.style.color = '#dc2626';
        readyBadge.innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i> No product rows to import`;
      }
      if (btnImport) btnImport.disabled = true;
      return;
    }

    if (!hasName) {
      if (readyBadge) {
        readyBadge.style.color = '#d97706';
        readyBadge.innerHTML = `<i class="fa-solid fa-circle-exclamation"></i> Please match the "Product Name *" column above`;
      }
      if (btnImport) {
        btnImport.disabled = true;
        btnImport.innerHTML = `<i class="fa-solid fa-cloud-arrow-up"></i> Match Product Name to Continue`;
      }
    } else {
      if (readyBadge) {
        readyBadge.style.color = '#15803d';
        readyBadge.innerHTML = `<i class="fa-solid fa-circle-check"></i> Ready to import ${dataRows.length} product${dataRows.length === 1 ? '' : 's'}${!hasPrice ? ' (Selling Price not mapped — will default to 0.00)' : ''}`;
      }
      if (btnImport) {
        btnImport.disabled = false;
        btnImport.innerHTML = `<i class="fa-solid fa-cloud-arrow-up"></i> Import ${dataRows.length} Product${dataRows.length === 1 ? '' : 's'}`;
      }
    }
  },

  cleanImportedNumber(raw) {
    if (raw === null || raw === undefined) return '';
    const str = String(raw).trim();
    if (str === '') return '';
    // Strip currency symbols (GH₵, GHS, $, £, €, commas, spaces)
    const cleaned = str.replace(/[^0-9.-]+/g, '');
    if (cleaned === '' || cleaned === '-' || cleaned === '.') return '';
    const num = Number(cleaned);
    return Number.isFinite(num) ? num : '';
  },

  async executeBulkProductImport() {
    const dataRows = this._bulkImportDataRows || [];
    const colMap = this._bulkImportColMap || {};
    const dupMode = document.getElementById('bulk-import-dup-mode')?.value || 'update';

    if (dataRows.length === 0) return;

    // Reverse map: fieldKey -> column index
    const fieldToCol = {};
    Object.entries(colMap).forEach(([colIdx, fieldKey]) => {
      if (fieldKey) fieldToCol[fieldKey] = Number(colIdx);
    });

    if (fieldToCol.name === undefined) {
      this.showToast('Please match a column to "Product Name *" before importing.', 'warning');
      return;
    }

    const getCell = (row, key) => {
      const idx = fieldToCol[key];
      if (idx === undefined) return '';
      return String(row[idx] ?? '').trim();
    };

    const items = [];
    for (const row of dataRows) {
      const name = getCell(row, 'name');
      if (!name) continue;

      const item = { name };
      if (fieldToCol.sku !== undefined) item.sku = getCell(row, 'sku');
      if (fieldToCol.barcode !== undefined) item.barcode = getCell(row, 'barcode');
      if (fieldToCol.category !== undefined) item.category = getCell(row, 'category') || 'General';
      if (fieldToCol.unit !== undefined) item.unit = getCell(row, 'unit') || 'pcs';
      if (fieldToCol.location !== undefined) item.location = getCell(row, 'location') || 'Main Storefront';
      if (fieldToCol.expiry_date !== undefined) item.expiry_date = getCell(row, 'expiry_date');
      if (fieldToCol.batch_number !== undefined) item.batch_number = getCell(row, 'batch_number');

      if (fieldToCol.cost_price !== undefined) {
        const c = this.cleanImportedNumber(getCell(row, 'cost_price'));
        if (c !== '') item.cost_price = c;
      }
      if (fieldToCol.selling_price !== undefined) {
        const p = this.cleanImportedNumber(getCell(row, 'selling_price'));
        if (p !== '') item.selling_price = p;
      }
      if (fieldToCol.initial_stock !== undefined) {
        const s = this.cleanImportedNumber(getCell(row, 'initial_stock'));
        if (s !== '') item.initial_stock = s;
      }
      if (fieldToCol.min_stock_alert !== undefined) {
        const m = this.cleanImportedNumber(getCell(row, 'min_stock_alert'));
        if (m !== '') item.min_stock_alert = Math.round(m);
      }

      // Build wholesale pack units if Pack 1 or Pack 2 columns were mapped
      const units = [];
      const p1Name = getCell(row, 'pack_unit');
      const p1Size = this.cleanImportedNumber(getCell(row, 'pack_size'));
      const p1Price = this.cleanImportedNumber(getCell(row, 'pack_price'));
      const p1Barcode = getCell(row, 'pack_barcode');

      if (p1Name || (p1Size && p1Size > 1) || (p1Price && p1Price > 0)) {
        const sizeVal = (p1Size && p1Size > 1) ? p1Size : 12;
        units.push({
          unit_name: p1Name || 'Crate',
          size_in_base: sizeVal,
          unit_price: (p1Price && p1Price > 0) ? p1Price : 0,
          barcode: p1Barcode || ''
        });
      }

      const p2Name = getCell(row, 'pack2_unit');
      const p2Size = this.cleanImportedNumber(getCell(row, 'pack2_size'));
      const p2Price = this.cleanImportedNumber(getCell(row, 'pack2_price'));
      if (p2Name || (p2Size && p2Size > 1) || (p2Price && p2Price > 0)) {
        const size2Val = (p2Size && p2Size > 1) ? p2Size : 6;
        units.push({
          unit_name: p2Name || 'Half-Pack',
          size_in_base: size2Val,
          unit_price: (p2Price && p2Price > 0) ? p2Price : 0,
          barcode: ''
        });
      }

      if (units.length > 0) {
        item.units = units;
      }

      items.push(item);
    }

    if (items.length === 0) {
      this.showToast('No valid product rows with a Product Name were found.', 'warning');
      return;
    }

    const btnImport = document.getElementById('btn-execute-bulk-import');
    if (btnImport) {
      btnImport.disabled = true;
      btnImport.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Importing ${items.length} Products...`;
    }

    try {
      const res = await this.apiFetch('api/endpoints/products.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'bulk_import',
          duplicate_mode: dupMode,
          items
        })
      });
      const resData = await res.json().catch(() => null);
      if (!res.ok || !resData || resData.success === false) {
        throw new Error(resData?.message || 'Bulk import failed on server');
      }

      await this.fetchProducts();
      await this.fetchInventory();
      this.closeBulkImportModal();
      this.renderCurrentView();

      if (typeof this.broadcastSyncEvent === 'function') {
        this.broadcastSyncEvent('PRODUCT_MUTATED', { action: 'BULK_IMPORT' });
      }

      this.showToast(`Import complete! ${resData.created || 0} added, ${resData.updated || 0} updated, ${resData.skipped || 0} skipped.`, 'success');
    } catch (err) {
      console.error('Bulk import execution error:', err);
      this.showToast(err.message || 'Error importing products', 'danger');
      if (btnImport) {
        btnImport.disabled = false;
        btnImport.innerHTML = `<i class="fa-solid fa-cloud-arrow-up"></i> Import ${items.length} Products`;
      }
    }
  },

  // -------------------------------------------------------------------------
  // EXPORT FULL CATALOG & DOWNLOAD SAMPLE TEMPLATES (.XLSX & .CSV)
  // -------------------------------------------------------------------------

  exportProductsCatalog(format = 'xlsx') {
    const products = this.products || [];
    if (products.length === 0) {
      this.showToast('No products in catalog to export.', 'warning');
      return;
    }

    const headers = [
      'Product Name',
      'SKU',
      'Barcode',
      'Category',
      'Loose Unit',
      'Factory Cost Price',
      'Selling Price',
      'Stock on Hand',
      'Min Stock Alert',
      'Storage Location',
      'Pack 1 Name',
      'Pack 1 Holds',
      'Pack 1 Price',
      'Pack 1 Barcode',
      'Pack 2 Name',
      'Pack 2 Holds',
      'Pack 2 Price',
      'Expiry Date',
      'Batch Number'
    ];

    const rows = [headers];
    for (const p of products) {
      const packRows = (this.productUnitsOf ? this.productUnitsOf(p) : []).filter(u => !u.is_base);
      const p1 = packRows[0] || null;
      const p2 = packRows[1] || null;
      rows.push([
        p.name || '',
        p.sku || '',
        p.barcode || '',
        p.category || 'General',
        p.unit || 'pcs',
        Number(p.cost_price || 0),
        Number(p.selling_price || 0),
        Number(p.current_quantity || 0),
        Number(p.min_stock_alert || 5),
        p.location || 'Main Storefront',
        p1 ? (p1.unit_name || '') : '',
        p1 ? Number(p1.size_in_base || '') : '',
        p1 ? Number(this.productUnitPrice ? this.productUnitPrice(p1, p.selling_price) : (p1.unit_price || 0)) : '',
        p1 ? (p1.barcode || '') : '',
        p2 ? (p2.unit_name || '') : '',
        p2 ? Number(p2.size_in_base || '') : '',
        p2 ? Number(this.productUnitPrice ? this.productUnitPrice(p2, p.selling_price) : (p2.unit_price || 0)) : '',
        p.expiry_date || '',
        p.batch_number || ''
      ]);
    }

    const dateStamp = new Date().toISOString().slice(0, 10);
    if (format === 'xlsx') {
      const blob = this.buildXlsxBlob('Products Catalog', rows);
      this.triggerBlobDownload(blob, `StoreFlow_Products_Catalog_${dateStamp}.xlsx`);
      this.showToast(`Exported ${products.length} products to Excel (.xlsx).`, 'success');
    } else {
      const csvText = this.buildCsvString(rows);
      const blob = new Blob(['\uFEFF' + csvText], { type: 'text/csv;charset=utf-8;' });
      this.triggerBlobDownload(blob, `StoreFlow_Products_Catalog_${dateStamp}.csv`);
      this.showToast(`Exported ${products.length} products to CSV.`, 'success');
    }
  },

  downloadBulkImportTemplate(format = 'xlsx') {
    const rows = [
      [
        'Product Name', 'SKU', 'Barcode', 'Category', 'Loose Unit',
        'Factory Cost Price', 'Selling Price', 'Opening Stock', 'Min Stock Alert',
        'Pack 1 Name', 'Pack 1 Holds', 'Pack 1 Price',
        'Pack 2 Name', 'Pack 2 Holds', 'Pack 2 Price', 'Expiry Date'
      ],
      [
        'Club Beer Large (625ml)', 'SKU-CLUB-625', '603300010011', 'Alcoholic Drinks', 'btl',
        11.50, 15.00, 240, 24,
        'Crate', 12, 170.00,
        'Half-Crate', 6, 86.00, '2027-06-30'
      ],
      [
        'Coca-Cola Original (300ml)', 'SKU-COKE-300', '5449000000996', 'Minerals & Soft Drinks', 'btl',
        4.20, 6.00, 480, 48,
        'Crate', 24, 135.00,
        'Half-Pack', 12, 68.00, '2027-08-15'
      ],
      [
        'Voltic Mineral Water (500ml)', 'SKU-VOLT-500', '603400020022', 'Water', 'btl',
        1.80, 2.50, 600, 60,
        'Shrink Pack', 24, 55.00,
        'Half-Pack', 12, 28.00, ''
      ]
    ];

    if (format === 'xlsx') {
      const blob = this.buildXlsxBlob('Sample Import Template', rows);
      this.triggerBlobDownload(blob, 'StoreFlow_Sample_Product_Import.xlsx');
    } else {
      const csvText = this.buildCsvString(rows);
      const blob = new Blob(['\uFEFF' + csvText], { type: 'text/csv;charset=utf-8;' });
      this.triggerBlobDownload(blob, 'StoreFlow_Sample_Product_Import.csv');
    }
  },

  triggerBlobDownload(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 250);
  },

  // -------------------------------------------------------------------------
  // PURE-JS OFFLINE CSV & XLSX PARSERS AND GENERATORS (ZERO EXTERNAL CDNs)
  // -------------------------------------------------------------------------

  buildCsvString(rows) {
    return rows.map(row => row.map(cell => {
      const str = String(cell ?? '');
      if (/[",\r\n;]/.test(str)) {
        return '"' + str.replace(/"/g, '""') + '"';
      }
      return str;
    }).join(',')).join('\r\n');
  },

  parseCsvMatrix(text) {
    const clean = String(text || '').replace(/^\uFEFF/, '');
    const firstLine = clean.split(/\r?\n/)[0] || '';
    const commaCount = (firstLine.match(/,/g) || []).length;
    const semiCount = (firstLine.match(/;/g) || []).length;
    const tabCount = (firstLine.match(/\t/g) || []).length;
    let delim = ',';
    if (tabCount > commaCount && tabCount >= semiCount) delim = '\t';
    else if (semiCount > commaCount) delim = ';';

    const rows = [];
    let row = [];
    let field = '';
    let inQuotes = false;

    for (let i = 0; i < clean.length; i++) {
      const ch = clean[i];
      const next = clean[i + 1];

      if (inQuotes) {
        if (ch === '"' && next === '"') {
          field += '"';
          i++;
        } else if (ch === '"') {
          inQuotes = false;
        } else {
          field += ch;
        }
      } else {
        if (ch === '"') {
          inQuotes = true;
        } else if (ch === delim) {
          row.push(field.trim());
          field = '';
        } else if (ch === '\r' && next === '\n') {
          row.push(field.trim());
          rows.push(row);
          row = [];
          field = '';
          i++;
        } else if (ch === '\n' || ch === '\r') {
          row.push(field.trim());
          rows.push(row);
          row = [];
          field = '';
        } else {
          field += ch;
        }
      }
    }
    if (field !== '' || row.length > 0) {
      row.push(field.trim());
      rows.push(row);
    }
    return rows;
  },

  async parseXlsxMatrix(arrayBuffer) {
    const bytes = new Uint8Array(arrayBuffer);
    const view = new DataView(arrayBuffer);

    // Locate End of Central Directory (EOCD) signature 0x06054b50
    let eocdOffset = -1;
    for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65557); i--) {
      if (view.getUint32(i, true) === 0x06054b50) {
        eocdOffset = i;
        break;
      }
    }
    if (eocdOffset < 0) {
      throw new Error('Invalid .xlsx file (ZIP directory not found).');
    }

    const totalEntries = view.getUint16(eocdOffset + 10, true);
    const cdOffset = view.getUint32(eocdOffset + 16, true);
    const decoder = new TextDecoder('utf-8');
    const files = {};

    let ptr = cdOffset;
    for (let e = 0; e < totalEntries; e++) {
      if (ptr + 46 > bytes.length || view.getUint32(ptr, true) !== 0x02014b50) break;
      const compMethod = view.getUint16(ptr + 10, true);
      const compSize = view.getUint32(ptr + 20, true);
      const nameLen = view.getUint16(ptr + 28, true);
      const extraLen = view.getUint16(ptr + 30, true);
      const commentLen = view.getUint16(ptr + 32, true);
      const localHeaderOffset = view.getUint32(ptr + 42, true);
      const name = decoder.decode(bytes.subarray(ptr + 46, ptr + 46 + nameLen));
      ptr += 46 + nameLen + extraLen + commentLen;

      if (name === 'xl/sharedStrings.xml' || /^xl\/worksheets\/sheet\d+\.xml$/i.test(name)) {
        const lNameLen = view.getUint16(localHeaderOffset + 26, true);
        const lExtraLen = view.getUint16(localHeaderOffset + 28, true);
        const dataStart = localHeaderOffset + 30 + lNameLen + lExtraLen;
        const compressedSlice = bytes.subarray(dataStart, dataStart + compSize);

        if (compMethod === 0) {
          files[name] = decoder.decode(compressedSlice);
        } else if (compMethod === 8 && typeof DecompressionStream !== 'undefined') {
          const ds = new DecompressionStream('deflate-raw');
          const writer = ds.writable.getWriter();
          writer.write(compressedSlice);
          writer.close();
          const decompressedBuf = await new Response(ds.readable).arrayBuffer();
          files[name] = decoder.decode(new Uint8Array(decompressedBuf));
        } else {
          throw new Error('Unsupported XLSX compression method (' + compMethod + ').');
        }
      }
    }

    const sheetKey = files['xl/worksheets/sheet1.xml']
      ? 'xl/worksheets/sheet1.xml'
      : Object.keys(files).find(k => /^xl\/worksheets\/sheet\d+\.xml$/i.test(k));
    if (!sheetKey) {
      throw new Error('No worksheet found inside .xlsx file.');
    }

    const domParser = new DOMParser();
    const sharedStrings = [];
    if (files['xl/sharedStrings.xml']) {
      const ssDoc = domParser.parseFromString(files['xl/sharedStrings.xml'], 'application/xml');
      const siNodes = ssDoc.getElementsByTagName('si');
      for (let i = 0; i < siNodes.length; i++) {
        const tNodes = siNodes[i].getElementsByTagName('t');
        let str = '';
        for (let j = 0; j < tNodes.length; j++) {
          str += tNodes[j].textContent || '';
        }
        sharedStrings.push(str);
      }
    }

    const colRefToIndex = (ref) => {
      const letters = (String(ref || '').match(/^[A-Z]+/i) || [''])[0].toUpperCase();
      if (!letters) return -1;
      let idx = 0;
      for (let i = 0; i < letters.length; i++) {
        idx = idx * 26 + (letters.charCodeAt(i) - 64);
      }
      return idx - 1;
    };

    const sheetDoc = domParser.parseFromString(files[sheetKey], 'application/xml');
    const rowNodes = sheetDoc.getElementsByTagName('row');
    const matrix = [];

    for (let r = 0; r < rowNodes.length; r++) {
      const cNodes = rowNodes[r].getElementsByTagName('c');
      const rowArr = [];
      let fallbackCol = 0;

      for (let c = 0; c < cNodes.length; c++) {
        const cell = cNodes[c];
        const refAttr = cell.getAttribute('r') || '';
        const colIdx = refAttr ? colRefToIndex(refAttr) : fallbackCol;
        const targetCol = colIdx >= 0 ? colIdx : fallbackCol;
        fallbackCol = targetCol + 1;

        const cellType = cell.getAttribute('t') || '';
        let val = '';
        if (cellType === 'inlineStr') {
          const tNodes = cell.getElementsByTagName('t');
          for (let j = 0; j < tNodes.length; j++) val += tNodes[j].textContent || '';
        } else {
          const vNode = cell.getElementsByTagName('v')[0];
          const rawV = vNode ? (vNode.textContent || '') : '';
          if (cellType === 's') {
            const ssIdx = parseInt(rawV, 10);
            val = (!isNaN(ssIdx) && sharedStrings[ssIdx] !== undefined) ? sharedStrings[ssIdx] : rawV;
          } else {
            val = rawV;
          }
        }
        while (rowArr.length <= targetCol) rowArr.push('');
        rowArr[targetCol] = String(val).trim();
      }
      matrix.push(rowArr);
    }

    return matrix;
  },

  buildXlsxBlob(sheetTitle, rowsMatrix) {
    const xmlEscape = (str) => String(str ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');

    const colIndexToLetter = (idx) => {
      let n = idx + 1;
      let str = '';
      while (n > 0) {
        const rem = (n - 1) % 26;
        str = String.fromCharCode(65 + rem) + str;
        n = Math.floor((n - 1) / 26);
      }
      return str;
    };

    const sheetRowsXml = rowsMatrix.map((row, rIdx) => {
      const rowNum = rIdx + 1;
      const styleAttr = rIdx === 0 ? ' s="1"' : '';
      const cellsXml = row.map((cell, cIdx) => {
        const ref = `${colIndexToLetter(cIdx)}${rowNum}`;
        if (typeof cell === 'number' && Number.isFinite(cell) && rIdx > 0) {
          return `<c r="${ref}"><v>${cell}</v></c>`;
        }
        return `<c r="${ref}" t="inlineStr"${styleAttr}><is><t>${xmlEscape(cell)}</t></is></c>`;
      }).join('');
      return `<row r="${rowNum}">${cellsXml}</row>`;
    }).join('');

    const files = [
      {
        name: '[Content_Types].xml',
        content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>`
      },
      {
        name: '_rels/.rels',
        content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>`
      },
      {
        name: 'xl/workbook.xml',
        content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
    <sheet name="${xmlEscape(sheetTitle || 'Sheet1').slice(0, 31)}" sheetId="1" r:id="rId1"/>
  </sheets>
</workbook>`
      },
      {
        name: 'xl/_rels/workbook.xml.rels',
        content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>`
      },
      {
        name: 'xl/styles.xml',
        content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="2">
    <font><sz val="11"/><name val="Calibri"/></font>
    <font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>
  </fonts>
  <fills count="3">
    <fill><patternFill patternType="none"/></fill>
    <fill><patternFill patternType="gray125"/></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FF1E3A8A"/></patternFill></fill>
  </fills>
  <borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="2">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
    <xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/>
  </cellXfs>
</styleSheet>`
      },
      {
        name: 'xl/worksheets/sheet1.xml',
        content: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <sheetData>${sheetRowsXml}</sheetData>
</worksheet>`
      }
    ];

    // Pack files into a valid Stored ZIP archive with IEEE CRC-32
    const encoder = new TextEncoder();
    const crcTable = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) {
        c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
      }
      crcTable[n] = c >>> 0;
    }
    const crc32 = (bytes) => {
      let crc = 0xFFFFFFFF;
      for (let i = 0; i < bytes.length; i++) {
        crc = (crc >>> 8) ^ crcTable[(crc ^ bytes[i]) & 0xFF];
      }
      return (crc ^ 0xFFFFFFFF) >>> 0;
    };

    const localChunks = [];
    const centralChunks = [];
    let offset = 0;

    for (const f of files) {
      const nameBytes = encoder.encode(f.name);
      const dataBytes = encoder.encode(f.content);
      const crc = crc32(dataBytes);

      const localHeader = new Uint8Array(30 + nameBytes.length);
      const lv = new DataView(localHeader.buffer);
      lv.setUint32(0, 0x04034b50, true);
      lv.setUint16(4, 20, true);
      lv.setUint16(6, 0, true);
      lv.setUint16(8, 0, true); // STORED (0)
      lv.setUint16(10, 0, true);
      lv.setUint16(12, 0, true);
      lv.setUint32(14, crc, true);
      lv.setUint32(18, dataBytes.length, true);
      lv.setUint32(22, dataBytes.length, true);
      lv.setUint16(26, nameBytes.length, true);
      lv.setUint16(28, 0, true);
      localHeader.set(nameBytes, 30);

      const centralHeader = new Uint8Array(46 + nameBytes.length);
      const cv = new DataView(centralHeader.buffer);
      cv.setUint32(0, 0x02014b50, true);
      cv.setUint16(4, 20, true);
      cv.setUint16(6, 20, true);
      cv.setUint16(8, 0, true);
      cv.setUint16(10, 0, true);
      cv.setUint16(12, 0, true);
      cv.setUint16(14, 0, true);
      cv.setUint32(16, crc, true);
      cv.setUint32(20, dataBytes.length, true);
      cv.setUint32(24, dataBytes.length, true);
      cv.setUint16(28, nameBytes.length, true);
      cv.setUint16(30, 0, true);
      cv.setUint16(32, 0, true);
      cv.setUint16(34, 0, true);
      cv.setUint16(36, 0, true);
      cv.setUint32(38, 0, true);
      cv.setUint32(42, offset, true);
      centralHeader.set(nameBytes, 46);

      localChunks.push(localHeader, dataBytes);
      centralChunks.push(centralHeader);
      offset += localHeader.length + dataBytes.length;
    }

    const cdSize = centralChunks.reduce((sum, c) => sum + c.length, 0);
    const eocd = new Uint8Array(22);
    const ev = new DataView(eocd.buffer);
    ev.setUint32(0, 0x06054b50, true);
    ev.setUint16(4, 0, true);
    ev.setUint16(6, 0, true);
    ev.setUint16(8, files.length, true);
    ev.setUint16(10, files.length, true);
    ev.setUint32(12, cdSize, true);
    ev.setUint32(16, offset, true);
    ev.setUint16(20, 0, true);

    return new Blob([...localChunks, ...centralChunks, eocd], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    });
  }
});
