// assets/js/db.js
// Offline IndexedDB Engine using Dexie.js

const localDB = new Dexie('StoreFlowDB');

localDB.version(1).stores({
  products: 'id, name, sku, barcode, category, current_quantity, is_active',
  inventory: 'id, product_id, current_quantity',
  purchases: 'id, order_number, supplier_name, order_date, total_cost',
  sales: 'id, receipt_number, customer_id, sale_date, total_amount, gross_profit, payment_method, synced',
  customers: 'id, name, phone, email, balance',
  store_profile: 'id, store_name',
  sync_outbox: '++id, entity, action, timestamp, synced'
});

localDB.version(2).stores({
  activity_logs: 'id, action_type, user_name, role_name, created_at'
});

localDB.version(3).stores({
  customer_payments: 'id, customer_id, user_id, amount, payment_method, created_at'
});

localDB.version(4).stores({
  register_shifts: 'id, shift_number, user_id, cashier_name, terminal_id, shift_date, created_at, synced'
});

localDB.version(5).stores({
  branches: 'id, branch_code, name, is_active'
});

localDB.version(6).stores({
  vendors: 'id, name, phone, balance, payment_terms',
  vendor_payments: 'id, vendor_id, amount, payment_date'
});

localDB.version(7).stores({
  branch_inventory: 'id, branch_code, product_id, current_quantity, is_available',
  stock_transfers: 'id, transfer_number, source_branch, destination_branch, created_at, synced'
});

localDB.version(8).stores({
  sales_returns: 'id, return_number, sale_id, receipt_number, customer_id, return_date, created_at, synced'
});

localDB.version(9).stores({
  product_batches: 'id, product_id, batch_number, expiry_date, branch_code, status, current_quantity, synced'
});

localDB.version(10).stores({
  expenses: 'id, expense_number, category, payment_source, branch_code, expense_date, shift_id, synced'
});

localDB.version(11).stores({
  estimates: 'id, estimate_number, customer_id, customer_name, total_amount, status, valid_until, created_at, synced'
});

localDB.version(12).stores({
  // Which set of the shop's records the queue above belongs to, and the notice that says the
  // book underneath it has been replaced. Both live beside the outbox rather than in
  // localStorage because they are cleared together or not at all: a till that lost only the
  // name would walk in looking like a brand-new counter and be handed the book to replay into.
  book_meta: 'key'
});

localDB.version(13).stores({
  products: 'id, name, sku, barcode, category, current_quantity, is_active, product_type'
});

window.localDB = localDB;
console.log('Local IndexedDB initialized successfully.');
