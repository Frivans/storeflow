// assets/js/db.js
// Offline IndexedDB Engine using Dexie.js

const localDB = new Dexie('StoreFlowDB');

localDB.version(1).stores({
  products: 'id, name, sku, barcode, category, current_quantity, is_active',
  inventory: 'id, product_id, current_quantity',
  purchases: 'id, order_number, supplier_name, order_date, total_cost',
  sales: 'id, receipt_number, customer_id, sale_date, total_amount, gross_profit, payment_method, synced',
  customers: 'id, name, phone, email, balance',
  store_profile: 'id, store_name',
  sync_outbox: '++id, entity, action, timestamp, synced'
});

localDB.version(2).stores({
  activity_logs: 'id, action_type, user_name, role_name, created_at'
});

localDB.version(3).stores({
  customer_payments: 'id, customer_id, user_id, amount, payment_method, created_at'
});

localDB.version(4).stores({
  register_shifts: 'id, shift_number, user_id, cashier_name, terminal_id, shift_date, created_at, synced'
});

localDB.version(5).stores({
  branches: 'id, branch_code, name, is_active'
});

localDB.version(6).stores({
  vendors: 'id, name, phone, balance, payment_terms',
  vendor_payments: 'id, vendor_id, amount, payment_date'
});

localDB.version(7).stores({
  branch_inventory: 'id, branch_code, product_id, current_quantity, is_available',
  stock_transfers: 'id, transfer_number, source_branch, destination_branch, created_at, synced'
});

localDB.version(8).stores({
  sales_returns: 'id, return_number, sale_id, receipt_number, customer_id, return_date, created_at, synced'
});

localDB.version(9).stores({
  product_batches: 'id, product_id, batch_number, expiry_date, branch_code, status, current_quantity, synced'
});

localDB.version(10).stores({
  expenses: 'id, expense_number, category, payment_source, branch_code, expense_date, shift_id, synced'
});

localDB.version(11).stores({
  estimates: 'id, estimate_number, customer_id, customer_name, total_amount, status, valid_until, created_at, synced'
});

localDB.version(12).stores({
  book_meta: 'key'
});

localDB.version(13).stores({
  products: 'id, name, sku, barcode, category, current_quantity, is_active, product_type'
});

window.localDB = localDB;
console.log('Local IndexedDB initialized successfully.');

// Native Android SQLite Dual-Storage Bridge (Safe Non-Blocking Wrappers)
if (window.StoreFlowAndroid && typeof window.StoreFlowAndroid.sqliteUpsert === 'function') {
  const syncTables = [
    'products', 'sales', 'customers', 'expenses', 'register_shifts',
    'activity_logs', 'store_profile', 'sync_outbox', 'branches', 'vendors', 'estimates'
  ];

  syncTables.forEach(tName => {
    const table = localDB[tName];
    if (!table) return;

    const origPut = table.put.bind(table);
    table.put = async function(item, key) {
      const res = await origPut(item, key);
      try {
        const id = String(key || (item && item.id) || (tName === 'store_profile' ? 1 : ''));
        if (id) {
          window.StoreFlowAndroid.sqliteUpsert(tName, id, 'id', JSON.stringify(item));
        }
      } catch (e) {
        console.warn(`[SQLite Native] sync put notice on ${tName}:`, e);
      }
      return res;
    };

    const origAdd = table.add.bind(table);
    table.add = async function(item, key) {
      const res = await origAdd(item, key);
      try {
        const id = String(res || key || (item && item.id) || (tName === 'store_profile' ? 1 : ''));
        if (id) {
          window.StoreFlowAndroid.sqliteUpsert(tName, id, 'id', JSON.stringify(item));
        }
      } catch (e) {
        console.warn(`[SQLite Native] sync add notice on ${tName}:`, e);
      }
      return res;
    };

    const origDelete = table.delete.bind(table);
    table.delete = async function(key) {
      const res = await origDelete(key);
      try {
        window.StoreFlowAndroid.sqliteDelete(tName, 'id', String(key));
      } catch (e) {
        console.warn(`[SQLite Native] sync delete notice on ${tName}:`, e);
      }
      return res;
    };
  });

  // Ground-Truth Hydration: Restores Dexie from device's storeflow.db if cache was ever cleared
  window.syncWithNativeSqlite = async function() {
    try {
      for (const tName of syncTables) {
        const table = localDB[tName];
        if (!table) continue;
        const jsonStr = window.StoreFlowAndroid.sqliteQueryAll(tName);
        if (!jsonStr) continue;
        const rows = JSON.parse(jsonStr);
        if (Array.isArray(rows) && rows.length > 0) {
          const currentCount = await table.count();
          if (currentCount === 0 || rows.length > currentCount) {
            await table.clear();
            await table.bulkPut(rows);
            console.log(`[StoreFlow SQLite] Restored ${rows.length} records from device storeflow.db into ${tName}`);
          }
        }
      }
    } catch (err) {
      console.warn('[StoreFlow SQLite] Hydration notice:', err);
    }
  };

  // Run hydration only after Dexie is ready
  localDB.open().then(() => {
    window.syncWithNativeSqlite();
  }).catch(() => {});
}
