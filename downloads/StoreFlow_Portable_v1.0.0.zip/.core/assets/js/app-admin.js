// assets/js/app-admin.js
// Administration modules (Store Profile, Users, Backups, and Activity Logs)
// are fully maintained in assets/js/app.js.
