Object.assign(StoreApp.prototype, {
  setSalesBranchFilter(branchCode) {
    this.salesBranchFilter = branchCode;
    this.renderCurrentView();
  },

  resetSalesFilters() {
    this.salesSearchQuery = '';
    this.salesDateFilter = 'ALL';
    this.salesFromDate = '';
    this.salesToDate = '';
    this.salesPaymentFilter = 'ALL';
    this.salesStatusFilter = 'ALL';
    this.renderCurrentView();
  },

  getSalesHTML() {
    // The server only sends the shop's cost and margin to a user entitled to see them,
    // so the columns follow that same permission rather than the role's name.
    const showsMargin = this.maySeeProductCost();
    
    // 1. Branch filter
    let list = (this.salesBranchFilter && this.salesBranchFilter !== 'ALL')
      ? this.sales.filter(s => (s.branch_code || 'MAIN-01').toUpperCase() === this.salesBranchFilter.toUpperCase())
      : this.sales;

    // 2. Search query filter
    const q = (this.salesSearchQuery || '').trim().toLowerCase();
    if (q) {
      list = list.filter(s => {
        const rcpt = (s.receipt_number || '').toLowerCase();
        const cust = (s.customer_name || '').toLowerCase();
        const ref = (s.payment_reference || '').toLowerCase();
        const phone = (s.customer_phone || '').toLowerCase();
        return rcpt.includes(q) || cust.includes(q) || ref.includes(q) || phone.includes(q);
      });
    }

    // 3. Date filter
    const now = new Date();
    const pad = n => String(n).padStart(2, '0');
    const todayStr = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;

    if (this.salesDateFilter === 'TODAY') {
      list = list.filter(s => (s.sale_date || '').startsWith(todayStr));
    } else if (this.salesDateFilter === 'YESTERDAY') {
      const y = new Date(now.getTime() - 86400000);
      const yStr = `${y.getFullYear()}-${pad(y.getMonth() + 1)}-${pad(y.getDate())}`;
      list = list.filter(s => (s.sale_date || '').startsWith(yStr));
    } else if (this.salesDateFilter === 'THIS_WEEK') {
      const weekAgo = new Date(now.getTime() - 7 * 86400000);
      const weekStr = `${weekAgo.getFullYear()}-${pad(weekAgo.getMonth() + 1)}-${pad(weekAgo.getDate())}`;
      list = list.filter(s => (s.sale_date || '').substring(0, 10) >= weekStr);
    } else if (this.salesDateFilter === 'THIS_MONTH') {
      const monthStr = `${now.getFullYear()}-${pad(now.getMonth() + 1)}`;
      list = list.filter(s => (s.sale_date || '').startsWith(monthStr));
    } else if (this.salesDateFilter === 'CUSTOM') {
      if (this.salesFromDate) {
        list = list.filter(s => (s.sale_date || '').substring(0, 10) >= this.salesFromDate);
      }
      if (this.salesToDate) {
        list = list.filter(s => (s.sale_date || '').substring(0, 10) <= this.salesToDate);
      }
    }

    // 4. Payment method filter
    if (this.salesPaymentFilter && this.salesPaymentFilter !== 'ALL') {
      list = list.filter(s => {
        const pm = (s.payment_method || '').toUpperCase();
        if (this.salesPaymentFilter === 'CASH') return pm === 'CASH';
        if (this.salesPaymentFilter === 'MOMO') return pm === 'MOMO' || pm.includes('MOBILE');
        if (this.salesPaymentFilter === 'CARD') return pm === 'CARD' || pm === 'POS';
        if (this.salesPaymentFilter === 'CREDIT') return pm === 'CREDIT' || pm.includes('ACCOUNT');
        if (this.salesPaymentFilter === 'BANK') return pm === 'BANK' || pm.includes('CHEQUE');
        return true;
      });
    }

    // 5. Status filter
    if (this.salesStatusFilter && this.salesStatusFilter !== 'ALL') {
      list = list.filter(s => {
        const isVoid = this.isVoidedSale(s);
        const refAmt = Number(s.refunded_amount || 0);
        const isFullRef = s.status === 'REFUNDED' || (refAmt >= Number(s.total_amount || 0) && Number(s.total_amount || 0) > 0);
        if (this.salesStatusFilter === 'COMPLETED') return !isVoid && !isFullRef;
        if (this.salesStatusFilter === 'REFUNDED') return isFullRef || refAmt > 0;
        if (this.salesStatusFilter === 'VOIDED') return isVoid;
        return true;
      });
    }

    const filteredSales = list;
    const salesMetrics = filteredSales.map(s => ({
      sale: s,
      metrics: this.getSaleProfitMetrics(s)
    }));

    const totalRev = salesMetrics.reduce((sum, item) => sum + item.metrics.netRevenue, 0);
    const totalProfit = salesMetrics.reduce((sum, item) => sum + item.metrics.netProfit, 0);
    const totalRefunded = filteredSales.reduce((sum, s) => sum + Number(s.refunded_amount || 0), 0);
    // Counted apart, never hidden: the receipts are on the ledger below, and a day on which four
    // bills were cancelled is not the same shop as a day on which none were.
    const voidedSales = filteredSales.filter(s => this.isVoidedSale(s));
    const voidedValue = voidedSales.reduce((sum, s) => sum + Number(s.total_amount || 0), 0);
    const billableCount = filteredSales.length - voidedSales.length;
    const aov = billableCount > 0 ? (totalRev / billableCount) : 0;
    const creditTotal = filteredSales.filter(s => (s.payment_method || '').toUpperCase() === 'CREDIT').reduce((sum, s) => sum + Number(s.total_amount || 0), 0);

    const hasActiveFilters = Boolean(
      (this.salesSearchQuery && this.salesSearchQuery.trim()) ||
      (this.salesDateFilter && this.salesDateFilter !== 'ALL') ||
      (this.salesPaymentFilter && this.salesPaymentFilter !== 'ALL') ||
      (this.salesStatusFilter && this.salesStatusFilter !== 'ALL') ||
      (this.salesBranchFilter && this.salesBranchFilter !== 'ALL')
    );

    return `
      <div class="panel" style="margin-bottom: 1.5rem;">
        <div class="panel-body" style="display: flex; gap: 2rem; flex-wrap: wrap;">
          <div>
            <span style="font-size: 0.8rem; color: var(--slate-500); text-transform: uppercase; font-weight: 600;">Total Transactions</span>
            <p style="font-size: 1.4rem; font-weight: 700; color: var(--slate-900);">${billableCount} <span style="font-size: 0.8rem; font-weight: 500; color: var(--slate-400);">(of ${this.sales.length})</span></p>
          </div>
          ${voidedSales.length > 0 ? `
            <div title="Voided receipts stay on the ledger with their reason and their hand, and count as nothing.">
              <span style="font-size: 0.8rem; color: #b91c1c; text-transform: uppercase; font-weight: 600;">Voided</span>
              <p style="font-size: 1.4rem; font-weight: 700; color: #b91c1c;">${voidedSales.length} <span style="font-size: 0.85rem; font-weight: 600;">(${this.formatCurrency(voidedValue)})</span></p>
            </div>
          ` : ''}
          <div>
            <span style="font-size: 0.8rem; color: var(--slate-500); text-transform: uppercase; font-weight: 600;">Net Sales Revenue</span>
            <p style="font-size: 1.4rem; font-weight: 700; color: var(--primary);">${this.formatCurrency(totalRev)}</p>
          </div>
          ${totalRefunded > 0 ? `
            <div>
              <span style="font-size: 0.8rem; color: #dc2626; text-transform: uppercase; font-weight: 600;">Refunded / Returned</span>
              <p style="font-size: 1.4rem; font-weight: 700; color: #dc2626;">-${this.formatCurrency(totalRefunded)}</p>
            </div>
          ` : ''}
          ${showsMargin ? `
            <div>
              <span style="font-size: 0.8rem; color: var(--slate-500); text-transform: uppercase; font-weight: 600;">Net Gross Profit</span>
              <p style="font-size: 1.4rem; font-weight: 700; color: var(--success);">${this.formatCurrency(totalProfit)}</p>
            </div>
          ` : ''}
          <div>
            <span style="font-size: 0.8rem; color: var(--slate-500); text-transform: uppercase; font-weight: 600;">Avg. Basket Size</span>
            <p style="font-size: 1.4rem; font-weight: 700; color: #6366f1;">${this.formatCurrency(aov)}</p>
          </div>
          ${creditTotal > 0 ? `
            <div>
              <span style="font-size: 0.8rem; color: #b45309; text-transform: uppercase; font-weight: 600;">Credit (On Account)</span>
              <p style="font-size: 1.4rem; font-weight: 700; color: #b45309;">${this.formatCurrency(creditTotal)}</p>
            </div>
          ` : ''}
        </div>
      </div>

      <div class="panel">
        <div class="panel-header" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.75rem;">
          <h3><i class="fa-solid fa-receipt"></i> Completed Store Sales & Receipts Ledger</h3>
          <div style="display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap;">
            <button type="button" class="btn btn-outline btn-sm" onclick="app.refreshViewDataOnVisit('sales')" title="Fetch latest sales records">
              <i class="fa-solid fa-arrows-rotate"></i> Refresh
            </button>
            <button type="button" class="btn btn-outline btn-sm" onclick="app.openSalesReturnModal()" style="color: #4338ca; border-color: #c7d2fe; font-weight: 700;">
              <i class="fa-solid fa-arrow-rotate-left"></i> Process Return
            </button>
            ${this.isMultiBranch ? `
              <label style="font-size: 0.8rem; font-weight: 600; color: var(--slate-600);"><i class="fa-solid fa-store"></i> Branch:</label>
              <select id="sales-branch-filter" class="form-control" style="width: auto; padding: 0.35rem 0.65rem; font-size: 0.82rem; font-weight: 600;" onchange="app.setSalesBranchFilter(this.value)">
                <option value="ALL">All Branches (Consolidated)</option>
                ${(this.branches || []).map(b => `
                  <option value="${this.escapeHtml(b.branch_code)}" ${this.salesBranchFilter === b.branch_code ? 'selected' : ''}>
                    ${this.escapeHtml(b.branch_code)} - ${this.escapeHtml(b.name)}
                  </option>
                `).join('')}
              </select>
            ` : ''}
          </div>
        </div>
        <div class="panel-body">
          <!-- Comprehensive Sales Filter Bar -->
          <div style="background: var(--slate-50); border: 1px solid var(--slate-200); border-radius: 8px; padding: 0.85rem 1rem; margin-bottom: 1.25rem; display: flex; flex-wrap: wrap; gap: 0.75rem; align-items: center; justify-content: space-between;">
            <div style="display: flex; gap: 0.65rem; flex-wrap: wrap; align-items: center; flex: 1;">
              <!-- Search Input -->
              <div style="position: relative; min-width: 220px; flex: 1;">
                <i class="fa-solid fa-magnifying-glass" style="position: absolute; left: 0.75rem; top: 50%; transform: translateY(-50%); color: var(--slate-400); font-size: 0.85rem;"></i>
                <input type="text" id="sales-search-input" class="form-control" placeholder="Search Receipt #, buyer, phone..." style="padding-left: 2.1rem;" value="${this.escapeHtml(this.salesSearchQuery || '')}">
              </div>
              <!-- Date Preset Filter -->
              <select id="sales-date-filter" class="form-control" style="width: auto; min-width: 140px; font-weight: 600;">
                <option value="ALL" ${(!this.salesDateFilter || this.salesDateFilter === 'ALL') ? 'selected' : ''}>All Dates</option>
                <option value="TODAY" ${this.salesDateFilter === 'TODAY' ? 'selected' : ''}>Today</option>
                <option value="YESTERDAY" ${this.salesDateFilter === 'YESTERDAY' ? 'selected' : ''}>Yesterday</option>
                <option value="THIS_WEEK" ${this.salesDateFilter === 'THIS_WEEK' ? 'selected' : ''}>Last 7 Days</option>
                <option value="THIS_MONTH" ${this.salesDateFilter === 'THIS_MONTH' ? 'selected' : ''}>This Month</option>
                <option value="CUSTOM" ${this.salesDateFilter === 'CUSTOM' ? 'selected' : ''}>Custom Range...</option>
              </select>
              <!-- Custom Date Range -->
              <div id="sales-custom-dates" style="display: ${this.salesDateFilter === 'CUSTOM' ? 'flex' : 'none'}; gap: 0.4rem; align-items: center;">
                <input type="date" id="sales-from-date" class="form-control" style="width: auto; padding: 0.35rem 0.5rem;" value="${this.escapeHtml(this.salesFromDate || '')}">
                <span style="color: var(--slate-400); font-size: 0.8rem;">to</span>
                <input type="date" id="sales-to-date" class="form-control" style="width: auto; padding: 0.35rem 0.5rem;" value="${this.escapeHtml(this.salesToDate || '')}">
              </div>
              <!-- Payment Method Filter -->
              <select id="sales-payment-filter" class="form-control" style="width: auto; min-width: 140px; font-weight: 600;">
                <option value="ALL" ${(!this.salesPaymentFilter || this.salesPaymentFilter === 'ALL') ? 'selected' : ''}>All Payments</option>
                <option value="CASH" ${this.salesPaymentFilter === 'CASH' ? 'selected' : ''}>Cash</option>
                <option value="MOMO" ${this.salesPaymentFilter === 'MOMO' ? 'selected' : ''}>MoMo (Mobile Money)</option>
                <option value="CARD" ${this.salesPaymentFilter === 'CARD' ? 'selected' : ''}>Card / POS</option>
                <option value="CREDIT" ${this.salesPaymentFilter === 'CREDIT' ? 'selected' : ''}>Credit / On Account</option>
                <option value="BANK" ${this.salesPaymentFilter === 'BANK' ? 'selected' : ''}>Bank Transfer / Cheque</option>
              </select>
              <!-- Transaction Status Filter -->
              <select id="sales-status-filter" class="form-control" style="width: auto; min-width: 130px; font-weight: 600;">
                <option value="ALL" ${(!this.salesStatusFilter || this.salesStatusFilter === 'ALL') ? 'selected' : ''}>All Statuses</option>
                <option value="COMPLETED" ${this.salesStatusFilter === 'COMPLETED' ? 'selected' : ''}>Completed Only</option>
                <option value="REFUNDED" ${this.salesStatusFilter === 'REFUNDED' ? 'selected' : ''}>Refunded / Returned</option>
                <option value="VOIDED" ${this.salesStatusFilter === 'VOIDED' ? 'selected' : ''}>Voided Only</option>
              </select>
            </div>
            ${hasActiveFilters ? `
              <button type="button" class="btn btn-outline btn-sm" onclick="app.resetSalesFilters()" style="color: var(--slate-600); font-weight: 600;" title="Clear all active sales filters">
                <i class="fa-solid fa-xmark"></i> Clear Filters
              </button>
            ` : ''}
          </div>
          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Receipt #</th>
                  <th>Date & Time</th>
                  ${this.isMultiBranch ? '<th>Branch</th>' : ''}
                  <th>Customer (Buyer)</th>
                  <th>Revenue</th>
                  ${showsMargin ? '<th>Factory Cost</th>' : ''}
                  ${showsMargin ? '<th>Profit</th>' : ''}
                  <th>Payment</th>
                  <th>Receipt</th>
                </tr>
              </thead>
              <tbody>
                ${salesMetrics.length > 0 ? salesMetrics.map(({ sale: s, metrics: m }) => `
                  <tr style="cursor: pointer;" onclick="app.viewSaleReceipt(${this.jsStr(s.id)})">
                    <td style="font-weight: 600; font-family: monospace;">${this.escapeHtml(s.receipt_number)}</td>
                    <td>${this.escapeHtml(s.sale_date)}</td>
                    ${this.isMultiBranch ? `<td><span class="badge badge-outline" style="font-family: monospace; font-size: 0.75rem;">${this.escapeHtml(s.branch_code || 'MAIN-01')}</span></td>` : ''}
                    <td>${this.escapeHtml(s.customer_name || 'Walk-in Customer')}</td>
                    <td style="font-weight: 700;">
                      ${m.isVoided ? `
                        <span style="text-decoration: line-through; color: var(--slate-400);">${this.formatCurrency(s.total_amount)}</span>
                        <div style="font-size: 0.78rem; color: #b91c1c; font-weight: 700; margin-top: 2px;">${this.formatCurrency(0)}</div>
                        <span class="badge badge-danger" style="font-size: 0.68rem; margin-top: 2px;"
                              title="${this.escapeHtml(String(s.void_reason || 'No reason recorded'))} — voided ${this.escapeHtml(String(s.voided_at || ''))} by ${this.escapeHtml(String(s.void_user_name || 'Unknown'))}">
                          VOIDED
                        </span>
                      ` : m.isFullyRefunded ? `<span style="text-decoration: line-through; color: var(--slate-400);">${this.formatCurrency(s.total_amount)}</span>` : this.formatCurrency(s.total_amount)}
                      ${!m.isVoided && Number(s.refunded_amount || 0) > 0 ? `
                        <div style="font-size: 0.72rem; color: #dc2626; font-weight: 600; margin-top: 2px;">
                          -${this.formatCurrency(s.refunded_amount)} refunded
                        </div>
                        <span class="badge ${s.status === 'REFUNDED' ? 'badge-danger' : 'badge-warning'}" style="font-size: 0.68rem; margin-top: 2px;">
                          ${this.escapeHtml(s.status)}
                        </span>
                      ` : ''}
                    </td>
                    ${showsMargin ? `
                      <td>
                        ${m.isVoided ? `
                          <span style="color: var(--slate-400); text-decoration: line-through;">${this.formatCurrency(s.total_cost || 0)}</span>
                          <div style="font-size: 0.7rem; color: var(--slate-500); font-weight: 600;">(Back on the shelf)</div>
                        ` : m.isFullyRefunded ? `
                          <span style="color: var(--slate-400); text-decoration: line-through;">${this.formatCurrency(s.total_cost || 0)}</span>
                          <div style="font-size: 0.7rem; color: var(--slate-500); font-weight: 600;">(Restocked)</div>
                        ` : m.isPartiallyRefunded ? `
                          <span>${this.formatCurrency(m.netCost)}</span>
                          <div style="font-size: 0.7rem; color: var(--slate-400);">(orig ${this.formatCurrency(s.total_cost || 0)})</div>
                        ` : `
                          <span style="color: var(--slate-500);">${this.formatCurrency(s.total_cost || 0)}</span>
                        `}
                      </td>
                    ` : ''}
                    ${showsMargin ? `
                      <td>
                        ${m.isVoided ? `
                          <span style="color: var(--slate-400); font-weight: 600;">${this.formatCurrency(0)}</span>
                          <span class="badge badge-danger" style="font-size: 0.65rem; margin-left: 3px;">Voided</span>
                        ` : m.isFullyRefunded ? `
                          <span style="color: var(--slate-400); font-weight: 600;">${this.formatCurrency(0)}</span>
                          <span class="badge badge-neutral" style="font-size: 0.65rem; margin-left: 3px;">Refunded</span>
                        ` : m.isPartiallyRefunded ? `
                          <span style="color: var(--success); font-weight: 700;">+${this.formatCurrency(m.netProfit)}</span>
                          <span class="badge badge-warning" style="font-size: 0.65rem; margin-left: 3px;">Net</span>
                        ` : `
                          <span style="color: var(--success); font-weight: 700;">+${this.formatCurrency(s.gross_profit || 0)}</span>
                        `}
                      </td>
                    ` : ''}
                    <td>
                      <span class="badge badge-neutral">${this.escapeHtml(s.payment_method)}</span>
                      ${s.payment_reference ? `<div style="font-size: 0.72rem; color: #0284c7; font-weight: 600; font-family: monospace; margin-top: 2px;">Ref: ${this.escapeHtml(s.payment_reference)}</div>` : ''}
                    </td>
                    <td>
                      <div style="display: flex; gap: 0.35rem;">
                        <button class="btn btn-outline btn-sm" onclick="event.stopPropagation(); app.viewSaleReceipt(${this.jsStr(s.id)})">
                          <i class="fa-solid fa-print"></i> View
                        </button>
                        ${m.isVoided ? '' : `
                          <button class="btn btn-outline btn-sm" style="color: #4338ca; border-color: #c7d2fe; font-weight: 600;" onclick="event.stopPropagation(); app.openSalesReturnModal(${this.jsStr(s.receipt_number)})" title="Process customer merchandise return for this sale">
                            <i class="fa-solid fa-arrow-rotate-left"></i> Return
                          </button>
                        `}
                        ${this.canVoidSale(s) ? `
                          <button class="btn btn-outline btn-sm" style="color: #b91c1c; border-color: #fecaca; font-weight: 600;" onclick="event.stopPropagation(); app.voidSaleReceipt(${this.jsStr(s.id)})" title="Cancel this receipt as though it was never rung - today only, with a reason, and the goods go straight back on the shelf">
                            <i class="fa-solid fa-ban"></i> Void
                          </button>
                        ` : ''}
                      </div>
                    </td>
                  </tr>
                `).join('') : `
                  <tr>
                    <td colspan="${showsMargin ? (this.isMultiBranch ? 9 : 8) : (this.isMultiBranch ? 7 : 6)}" style="text-align: center; padding: 3rem; color: var(--slate-400);">
                      <i class="fa-solid fa-receipt" style="font-size: 2rem; margin-bottom: 0.5rem; display: block;"></i>
                      ${hasActiveFilters ? 'No sales matched your search and filter criteria.' : 'No sales recorded for the selected branch.'}
                    </td>
                  </tr>
                `}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  },

  bindSalesEvents() {
    const searchInput = document.getElementById('sales-search-input');
    if (searchInput) {
      let debounceTimer = null;
      searchInput.addEventListener('input', (e) => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => {
          this.salesSearchQuery = e.target.value;
          this.renderCurrentView();
          const nextInput = document.getElementById('sales-search-input');
          if (nextInput) {
            nextInput.focus();
            nextInput.setSelectionRange(nextInput.value.length, nextInput.value.length);
          }
        }, 220);
      });
    }

    const dateFilter = document.getElementById('sales-date-filter');
    if (dateFilter) {
      dateFilter.addEventListener('change', (e) => {
        this.salesDateFilter = e.target.value;
        const customDiv = document.getElementById('sales-custom-dates');
        if (customDiv) {
          customDiv.style.display = (this.salesDateFilter === 'CUSTOM') ? 'flex' : 'none';
        }
        if (this.salesDateFilter !== 'CUSTOM') {
          this.renderCurrentView();
        }
      });
    }

    const fromDate = document.getElementById('sales-from-date');
    if (fromDate) {
      fromDate.addEventListener('change', (e) => {
        this.salesFromDate = e.target.value;
        this.renderCurrentView();
      });
    }

    const toDate = document.getElementById('sales-to-date');
    if (toDate) {
      toDate.addEventListener('change', (e) => {
        this.salesToDate = e.target.value;
        this.renderCurrentView();
      });
    }

    const paymentFilter = document.getElementById('sales-payment-filter');
    if (paymentFilter) {
      paymentFilter.addEventListener('change', (e) => {
        this.salesPaymentFilter = e.target.value;
        this.renderCurrentView();
      });
    }

    const statusFilter = document.getElementById('sales-status-filter');
    if (statusFilter) {
      statusFilter.addEventListener('change', (e) => {
        this.salesStatusFilter = e.target.value;
        this.renderCurrentView();
      });
    }
  },

  // What the server will accept, said before the cashier types a reason rather than after.
  // The rules are the same on both sides - today's receipt, nothing already credited, a hand
  // entitled to clear this bill - and the server keeps the authority: a till that shows a
  // button the book refuses still gets the refusal in one sentence.
  canVoidSale(sale) {
    if (!sale || this.isVoidedSale(sale)) return false;
    if (String(sale.status || 'COMPLETED').trim().toUpperCase() !== 'COMPLETED') return false;
    if (Number(sale.refunded_amount || 0) > 0.009) return false;
    if (typeof this.hasPerm === 'function' && !this.hasPerm('manage_sales')) return false;

    const holdsSettings = typeof this.hasPerm === 'function' && this.hasPerm('manage_settings');
    const rangItThemselves = Number(sale.user_id) === Number(this.currentUser?.id);
    if (!holdsSettings && !rangItThemselves) return false;

    const now = new Date();
    const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    return String(sale.sale_date || sale.created_at || '').slice(0, 10) === today;
  },

  async voidSaleReceipt(saleId) {
    // A slip can be opened from a row the ledger has not paged in yet - a webhook order, or the
    // receipt the counter just printed - so the copy already on screen is the next place to look.
    const sale = (this.sales || []).find(s => String(s.id) === String(saleId))
      || (String(this.currentSaleForReceipt?.id) === String(saleId) ? this.currentSaleForReceipt : null);
    if (!sale) {
      this.showToast('That receipt is not on this till any more. Refresh the ledger and try again.', 'warning');
      return;
    }

    // A void clears the receipt on the shop's book and puts stock back on its shelf, so it is
    // not queued offline the way a sale is. A till that cannot reach the server says so instead
    // of cancelling a bill the book has never seen.
    if (!this.isOnline) {
      this.showToast('The shop server has to see a void, so the till needs a connection. Nothing has been cancelled.', 'warning');
      return;
    }
    if (!this.canVoidSale(sale)) {
      this.showToast('Only a receipt from today, with nothing credited against it, can be voided - and only by the attendant who rang it or a manager.', 'warning');
      return;
    }

    const reason = await this.showPromptModal({
      title: 'Void Receipt',
      desc: `Cancel ${sale.receipt_number || 'this receipt'} (${this.formatCurrency(sale.total_amount || 0)}) as though it was never rung? The goods go straight back on the shelf and the bill stays on the ledger at ${this.formatCurrency(0)}. Hand any cash back before the drawer is counted.`,
      label: 'Reason for voiding *',
      placeholder: 'e.g. Mis-ring, wrong items keyed, customer changed mind',
      defaultValue: '',
      icon: 'fa-ban',
      confirmText: 'Void Receipt'
    });

    if (reason === null || reason === undefined) return;
    if (!String(reason).trim()) {
      this.showToast('A void needs a reason. It is stamped on the ledger and read back at the shift count.', 'warning');
      return;
    }

    try {
      const res = await this.apiFetch('api/endpoints/sales.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'void', sale_id: sale.id, reason: String(reason).trim() })
      });
      const outcome = await this.classifyApiResponse(res);

      if (outcome.verdict === 'unreachable') {
        this.showToast('The till could not reach the shop server, so the receipt is still live and the money is still in the drawer.', 'warning');
        return;
      }
      if (outcome.verdict === 'refused') {
        this.showToast(outcome.message, 'danger');
        return;
      }

      const voided = outcome.body?.sale;
      const idx = (this.sales || []).findIndex(s => String(s.id) === String(sale.id));
      if (idx >= 0) {
        this.sales[idx] = { ...this.sales[idx], ...(voided || {}), status: 'VOID' };
        if (typeof localDB !== 'undefined' && localDB.sales) {
          try { await localDB.sales.put(this.sales[idx]); } catch (e) {}
        }
      }

      // The shelf and the account moved on the server, so both are re-read rather than
      // recalculated here. The receipt itself comes back with the delta poll.
      if (typeof this.fetchProducts === 'function') { try { await this.fetchProducts(); } catch (e) {} }
      if (typeof this.fetchCustomers === 'function') { try { await this.fetchCustomers(); } catch (e) {} }
      if (typeof this.broadcastSyncEvent === 'function') {
        this.broadcastSyncEvent('SALE_VOIDED', { saleId: sale.id, receiptNumber: sale.receipt_number });
      }

      this.closeReceiptModal?.();
      this.renderCurrentView();
      this.showToast(outcome.body?.message || `Receipt ${sale.receipt_number || ''} is voided.`, 'success');
    } catch (e) {
      this.showToast('The receipt could not be voided: ' + (e?.message || e), 'danger');
    }
  },

  async viewSaleReceipt(saleId) {
    let sale = this.sales.find(s => s.id === saleId);
    if (!sale) return;

    if (!sale.items || sale.items.length === 0) {
      if (this.isOnline) {
        try {
          const res = await this.apiFetch(`api/endpoints/sales.php?id=${saleId}`);
          const data = await res.json();
          if (data.success && data.sale) {
            sale = data.sale;
          }
        } catch (e) {
          console.warn('Could not fetch sale details');
        }
      }
    }

    if (!sale.items) {
      sale.items = [{ name: 'Store Items Total', quantity: 1, selling_price: sale.total_amount }];
    }

    // Server returns `product_name`; offline/local sales use `name`. Normalize both.
    sale.items = sale.items.map(it => {
      const prod = this.products.find(p => String(p.id) === String(it.product_id));
      return {
        ...it,
        name: it.name || it.product_name || (prod ? prod.name : 'Item'),
        selling_price: it.selling_price || it.unit_selling_price || it.unit_price || 0
      };
    });

    if (sale.customer_id) {
      const cust = this.customers.find(c => c.id === sale.customer_id);
      if (cust) {
        sale.customer_balance = cust.balance;
      }
    }

    this.showReceiptModal(sale);
  }
});
