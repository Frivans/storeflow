// assets/js/app-analytics.js
// Analytics & Comparative Reports module is fully maintained in assets/js/app.js.
