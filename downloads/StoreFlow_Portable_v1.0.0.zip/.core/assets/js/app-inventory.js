// assets/js/app-inventory.js
// Inventory and Stock Control module is fully maintained in assets/js/app.js.
