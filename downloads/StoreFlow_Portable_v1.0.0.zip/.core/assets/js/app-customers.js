Object.assign(StoreApp.prototype, {
  getCustomersHTML() {
    return `
      <div class="panel">
        <div class="panel-header">
          <h3><i class="fa-solid fa-users"></i> Customers (Buyers) Directory</h3>
          <button class="btn btn-primary" onclick="app.openNewCustomerModal()"><i class="fa-solid fa-user-plus"></i> Add Customer</button>
        </div>
        <div class="panel-body">
          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Customer Name</th>
                  <th>Phone Number</th>
                  <th>Email</th>
                  <th>Address</th>
                  <th>Outstanding Balance</th>
                  <th>Points</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                ${this.customers.map(c => {
                  const bal = Number(c.balance || 0);
                  const pts = Number(c.loyalty_points || 0);
                  const tier = String(c.loyalty_tier || 'BRONZE').toUpperCase();
                  return `
                    <tr>
                      <td style="font-weight: 600;">${this.escapeHtml(c.name)}</td>
                      <td>${this.escapeHtml(c.phone || 'N/A')}</td>
                      <td>${this.escapeHtml(c.email || 'N/A')}</td>
                      <td>${this.escapeHtml(c.address || 'In-Store')}</td>
                      <td>
                        ${bal > 0 ? `<span style="color: var(--danger); font-weight: 700;"><i class="fa-solid fa-triangle-exclamation"></i> ${this.formatCurrency(bal)}</span>` : (bal < 0 ? `<span class="badge badge-success" style="font-weight: 600;"><i class="fa-solid fa-credit-card"></i> Credit: ${this.formatCurrency(Math.abs(bal))}</span>` : `<span style="color: var(--slate-600); font-weight: 500;">${this.formatCurrency(0)}</span>`) }
                      </td>
                      <td>
                        ${c.id === 'cust-walkin' ? '<span style="color: var(--slate-400);">&mdash;</span>' : `
                          <span style="font-weight: 700; font-family: monospace;">${pts.toLocaleString()}</span>
                          ${pts > 0 ? `<span class="badge badge-neutral" style="font-size: 0.68rem; margin-left: 0.3rem;">${this.escapeHtml(tier)}</span>` : ''}
                        `}
                      </td>
                      <td>
                        <div style="display: flex; gap: 0.35rem;">
                          ${c.id !== 'cust-walkin' ? `
                            <button class="btn btn-outline btn-sm" onclick="app.openDebtPaymentModal(${this.jsStr(c.id)})" title="Record payment or deposit" style="color: var(--success); border-color: var(--success);"><i class="fa-solid fa-hand-holding-dollar"></i> Pay</button>
                            <button class="btn btn-outline btn-sm" onclick="app.openCustomerStatementModal(${this.jsStr(c.id)})" title="View Statement of Account & Ledger" style="color: var(--primary); border-color: var(--primary);"><i class="fa-solid fa-file-invoice"></i> Statement</button>
                          ` : ''}
                          ${(c.id !== 'cust-walkin' && !this.isCashier()) ? `
                            <button class="btn btn-outline btn-sm" onclick="app.adjustCustomerLoyalty(${this.jsStr(c.id)})" title="Gift or correct this member's points" style="color: #b45309; border-color: #f59e0b;"><i class="fa-solid fa-gift"></i> Points</button>
                          ` : ''}
                          <button class="btn btn-outline btn-sm" onclick="app.editCustomer(${this.jsStr(c.id)})" title="Edit Details"><i class="fa-solid fa-pen"></i> Edit</button>
                          ${(c.id !== 'cust-walkin' && !this.isCashier()) ? `
                            <button class="btn btn-outline btn-sm" onclick="app.confirmDeleteCustomer(${this.jsStr(c.id)}, ${this.jsStr(c.name)})" style="color: var(--danger); border-color: var(--danger-border);" title="Delete Customer"><i class="fa-solid fa-trash"></i></button>
                          ` : ''}
                        </div>
                      </td>
                    </tr>
                  `;
                }).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  },

  bindCustomersEvents() {},

  openNewCustomerModal() {
    document.getElementById('cust-form-id').value = '';
    document.getElementById('cust-form-name').value = '';
    document.getElementById('cust-form-phone').value = '';
    document.getElementById('cust-form-email').value = '';
    document.getElementById('cust-form-address').value = '';
    document.getElementById('cust-form-balance').value = '0.00';
    document.getElementById('cust-form-notes').value = '';
    document.getElementById('customer-modal').classList.add('active');
  },

  editCustomer(customerId) {
    const c = this.customers.find(item => item.id === customerId);
    if (!c) return;

    document.getElementById('cust-form-id').value = c.id;
    document.getElementById('cust-form-name').value = c.name;
    document.getElementById('cust-form-phone').value = c.phone || '';
    document.getElementById('cust-form-email').value = c.email || '';
    document.getElementById('cust-form-address').value = c.address || '';
    document.getElementById('cust-form-balance').value = c.balance || 0;
    document.getElementById('cust-form-notes').value = c.notes || '';
    document.getElementById('customer-modal').classList.add('active');
  },

  closeCustomerModal() {
    document.getElementById('customer-modal').classList.remove('active');
  },

  async saveCustomerForm() {
    const id = document.getElementById('cust-form-id').value || ('cust_' + Math.random().toString(36).substring(2, 10));
    const isEdit = Boolean(document.getElementById('cust-form-id').value);
    const name = document.getElementById('cust-form-name').value.trim();

    if (!name) {
      this.showToast('Customer name is required.', 'warning');
      return;
    }

    const payload = {
      id,
      name,
      phone: document.getElementById('cust-form-phone').value.trim(),
      email: document.getElementById('cust-form-email').value.trim(),
      address: document.getElementById('cust-form-address').value.trim(),
      balance: parseFloat(document.getElementById('cust-form-balance').value) || 0,
      notes: document.getElementById('cust-form-notes').value.trim()
    };

    if (isEdit) {
      const idx = this.customers.findIndex(c => c.id === id);
      if (idx >= 0) {
        this.customers[idx] = { ...this.customers[idx], ...payload };
        await localDB.customers.put(this.customers[idx]);
      }
    } else {
      this.customers.push(payload);
      await localDB.customers.put(payload);
    }

    if (this.isOnline) {
      try {
        await this.apiFetch('api/endpoints/customers.php', {
          method: isEdit ? 'PUT' : 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
      } catch (err) {
        await localDB.sync_outbox.add({ entity: 'customer', action: isEdit ? 'UPDATE' : 'CREATE', data: payload, timestamp: new Date().toISOString(), synced: 0 });
      }
    } else {
      await localDB.sync_outbox.add({ entity: 'customer', action: isEdit ? 'UPDATE' : 'CREATE', data: payload, timestamp: new Date().toISOString(), synced: 0 });
    }

    this.closeCustomerModal();
    this.renderCurrentView();
    if (typeof this.broadcastSyncEvent === 'function') {
      this.broadcastSyncEvent('CUSTOMER_MUTATED', { action: isEdit ? 'UPDATE' : 'CREATE', customer: payload });
    }
    this.showToast('Customer saved successfully!', 'success');
  }
});
