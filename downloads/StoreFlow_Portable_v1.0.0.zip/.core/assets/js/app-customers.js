Object.assign(StoreApp.prototype, {
  resetCustomerFilters() {
    this.custSearchQuery = '';
    this.custBalanceFilter = 'ALL';
    this.custTierFilter = 'ALL';
    this.custSortFilter = 'NAME';
    this.renderCurrentView();
  },

  getCustomersHTML() {
    const validCustomers = this.customers.filter(c => c.id !== 'cust-walkin');
    const totalCustCount = validCustomers.length;
    const totalDebt = validCustomers.reduce((sum, c) => sum + (Number(c.balance || 0) > 0 ? Number(c.balance) : 0), 0);
    const debtorCount = validCustomers.filter(c => Number(c.balance || 0) > 0).length;
    const totalCreditAdv = validCustomers.reduce((sum, c) => sum + (Number(c.balance || 0) < 0 ? Math.abs(Number(c.balance)) : 0), 0);
    const totalPoints = validCustomers.reduce((sum, c) => sum + Number(c.loyalty_points || 0), 0);

    // Filter & Sort
    let list = [...this.customers];

    const q = (this.custSearchQuery || '').trim().toLowerCase();
    if (q) {
      list = list.filter(c => {
        const name = (c.name || '').toLowerCase();
        const phone = (c.phone || '').toLowerCase();
        const email = (c.email || '').toLowerCase();
        const addr = (c.address || '').toLowerCase();
        return name.includes(q) || phone.includes(q) || email.includes(q) || addr.includes(q);
      });
    }

    if (this.custBalanceFilter === 'DEBT') {
      list = list.filter(c => Number(c.balance || 0) > 0);
    } else if (this.custBalanceFilter === 'SETTLED') {
      list = list.filter(c => Number(c.balance || 0) === 0);
    } else if (this.custBalanceFilter === 'CREDIT') {
      list = list.filter(c => Number(c.balance || 0) < 0);
    }

    if (this.custTierFilter && this.custTierFilter !== 'ALL') {
      if (this.custTierFilter === 'HAS_POINTS') {
        list = list.filter(c => Number(c.loyalty_points || 0) > 0);
      } else {
        list = list.filter(c => (c.loyalty_tier || 'BRONZE').toUpperCase() === this.custTierFilter);
      }
    }

    const sort = this.custSortFilter || 'NAME';
    if (sort === 'DEBT_DESC') {
      list.sort((a, b) => Number(b.balance || 0) - Number(a.balance || 0));
    } else if (sort === 'POINTS_DESC') {
      list.sort((a, b) => Number(b.loyalty_points || 0) - Number(a.loyalty_points || 0));
    } else {
      list.sort((a, b) => {
        if (a.id === 'cust-walkin') return -1;
        if (b.id === 'cust-walkin') return 1;
        return (a.name || '').localeCompare(b.name || '');
      });
    }

    const hasActiveFilters = Boolean(
      (this.custSearchQuery && this.custSearchQuery.trim()) ||
      (this.custBalanceFilter && this.custBalanceFilter !== 'ALL') ||
      (this.custTierFilter && this.custTierFilter !== 'ALL') ||
      (this.custSortFilter && this.custSortFilter !== 'NAME')
    );

    return `
      <!-- Customers KPI Summary Cards -->
      <div class="panel" style="margin-bottom: 1.5rem;">
        <div class="panel-body" style="display: flex; gap: 2rem; flex-wrap: wrap;">
          <div>
            <span style="font-size: 0.8rem; color: var(--slate-500); text-transform: uppercase; font-weight: 600;">Registered Customers</span>
            <p style="font-size: 1.4rem; font-weight: 700; color: var(--slate-900);">${totalCustCount}</p>
          </div>
          <div>
            <span style="font-size: 0.8rem; color: #dc2626; text-transform: uppercase; font-weight: 600;">Total Debt Owed</span>
            <p style="font-size: 1.4rem; font-weight: 700; color: #dc2626;">${this.formatCurrency(totalDebt)}</p>
          </div>
          <div>
            <span style="font-size: 0.8rem; color: #b45309; text-transform: uppercase; font-weight: 600;">Active Debtors</span>
            <p style="font-size: 1.4rem; font-weight: 700; color: #b45309;">${debtorCount} <span style="font-size: 0.85rem; font-weight: 600; color: var(--slate-500);">(${((debtorCount / (totalCustCount || 1)) * 100).toFixed(0)}% of buyers)</span></p>
          </div>
          ${totalCreditAdv > 0 ? `
            <div>
              <span style="font-size: 0.8rem; color: var(--success); text-transform: uppercase; font-weight: 600;">Pre-paid Deposits</span>
              <p style="font-size: 1.4rem; font-weight: 700; color: var(--success);">${this.formatCurrency(totalCreditAdv)}</p>
            </div>
          ` : ''}
          <div>
            <span style="font-size: 0.8rem; color: var(--primary); text-transform: uppercase; font-weight: 600;">Total Loyalty Points</span>
            <p style="font-size: 1.4rem; font-weight: 700; color: var(--primary);">${totalPoints.toLocaleString()} <span style="font-size: 0.85rem; font-weight: 600; color: var(--slate-500);">pts</span></p>
          </div>
        </div>
      </div>

      <div class="panel">
        <div class="panel-header" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.75rem;">
          <h3><i class="fa-solid fa-users"></i> Customers (Buyers) Directory</h3>
          <button class="btn btn-primary" onclick="app.openNewCustomerModal()"><i class="fa-solid fa-user-plus"></i> Add Customer</button>
        </div>
        <div class="panel-body">
          <!-- Comprehensive Customer Filter Bar -->
          <div style="background: var(--slate-50); border: 1px solid var(--slate-200); border-radius: 8px; padding: 0.85rem 1rem; margin-bottom: 1.25rem; display: flex; flex-wrap: wrap; gap: 0.75rem; align-items: center; justify-content: space-between;">
            <div style="display: flex; gap: 0.65rem; flex-wrap: wrap; align-items: center; flex: 1;">
              <div style="position: relative; min-width: 240px; flex: 1;">
                <i class="fa-solid fa-magnifying-glass" style="position: absolute; left: 0.75rem; top: 50%; transform: translateY(-50%); color: var(--slate-400); font-size: 0.85rem;"></i>
                <input type="text" id="customers-search-input" class="form-control" placeholder="Search customer name, phone, email, address..." style="padding-left: 2.1rem;" value="${this.escapeHtml(this.custSearchQuery || '')}">
              </div>
              <!-- Balance Status Filter -->
              <select id="customers-balance-filter" class="form-control" style="width: auto; min-width: 160px; font-weight: 600;">
                <option value="ALL" ${(!this.custBalanceFilter || this.custBalanceFilter === 'ALL') ? 'selected' : ''}>All Balances</option>
                <option value="DEBT" ${this.custBalanceFilter === 'DEBT' ? 'selected' : ''}>Owing Debt (Debtors Only)</option>
                <option value="SETTLED" ${this.custBalanceFilter === 'SETTLED' ? 'selected' : ''}>Zero Balance (Settled)</option>
                <option value="CREDIT" ${this.custBalanceFilter === 'CREDIT' ? 'selected' : ''}>Pre-paid Deposits (Credit)</option>
              </select>
              <!-- Loyalty Tier Filter -->
              <select id="customers-tier-filter" class="form-control" style="width: auto; min-width: 140px; font-weight: 600;">
                <option value="ALL" ${(!this.custTierFilter || this.custTierFilter === 'ALL') ? 'selected' : ''}>All Loyalty Tiers</option>
                <option value="HAS_POINTS" ${this.custTierFilter === 'HAS_POINTS' ? 'selected' : ''}>Has Points (> 0)</option>
                <option value="BRONZE" ${this.custTierFilter === 'BRONZE' ? 'selected' : ''}>Bronze Members</option>
                <option value="SILVER" ${this.custTierFilter === 'SILVER' ? 'selected' : ''}>Silver Members</option>
                <option value="GOLD" ${this.custTierFilter === 'GOLD' ? 'selected' : ''}>Gold Members</option>
                <option value="PLATINUM" ${this.custTierFilter === 'PLATINUM' ? 'selected' : ''}>Platinum VIP</option>
              </select>
              <!-- Sorting Filter -->
              <select id="customers-sort-filter" class="form-control" style="width: auto; min-width: 140px; font-weight: 600;">
                <option value="NAME" ${(!this.custSortFilter || this.custSortFilter === 'NAME') ? 'selected' : ''}>Name (A &rarr; Z)</option>
                <option value="DEBT_DESC" ${this.custSortFilter === 'DEBT_DESC' ? 'selected' : ''}>Highest Debt First</option>
                <option value="POINTS_DESC" ${this.custSortFilter === 'POINTS_DESC' ? 'selected' : ''}>Most Points First</option>
              </select>
            </div>
            ${hasActiveFilters ? `
              <button type="button" class="btn btn-outline btn-sm" onclick="app.resetCustomerFilters()" style="color: var(--slate-600); font-weight: 600;" title="Clear all active customer filters">
                <i class="fa-solid fa-xmark"></i> Clear Filters
              </button>
            ` : ''}
          </div>

          <div class="table-responsive">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Customer Name</th>
                  <th>Phone Number</th>
                  <th>Email</th>
                  <th>Address</th>
                  <th>Outstanding Balance</th>
                  <th>Points</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                ${list.length > 0 ? list.map(c => {
                  const bal = Number(c.balance || 0);
                  const pts = Number(c.loyalty_points || 0);
                  const tier = String(c.loyalty_tier || 'BRONZE').toUpperCase();
                  return `
                    <tr>
                      <td style="font-weight: 600;">${this.escapeHtml(c.name)}</td>
                      <td>${this.escapeHtml(c.phone || 'N/A')}</td>
                      <td>${this.escapeHtml(c.email || 'N/A')}</td>
                      <td>${this.escapeHtml(c.address || 'In-Store')}</td>
                      <td>
                        ${bal > 0 ? `<span style="color: var(--danger); font-weight: 700;"><i class="fa-solid fa-triangle-exclamation"></i> ${this.formatCurrency(bal)}</span>` : (bal < 0 ? `<span class="badge badge-success" style="font-weight: 600;"><i class="fa-solid fa-credit-card"></i> Credit: ${this.formatCurrency(Math.abs(bal))}</span>` : `<span style="color: var(--slate-600); font-weight: 500;">${this.formatCurrency(0)}</span>`) }
                      </td>
                      <td>
                        ${c.id === 'cust-walkin' ? '<span style="color: var(--slate-400);">&mdash;</span>' : `
                          <span style="font-weight: 700; font-family: monospace;">${pts.toLocaleString()}</span>
                          ${pts > 0 ? `<span class="badge badge-neutral" style="font-size: 0.68rem; margin-left: 0.3rem;">${this.escapeHtml(tier)}</span>` : ''}
                        `}
                      </td>
                      <td>
                        <div style="display: flex; gap: 0.35rem;">
                          ${c.id !== 'cust-walkin' ? `
                            <button class="btn btn-outline btn-sm" onclick="app.openDebtPaymentModal(${this.jsStr(c.id)})" title="Record payment or deposit" style="color: var(--success); border-color: var(--success);"><i class="fa-solid fa-hand-holding-dollar"></i> Pay</button>
                            <button class="btn btn-outline btn-sm" onclick="app.openCustomerStatementModal(${this.jsStr(c.id)})" title="View Statement of Account & Ledger" style="color: var(--primary); border-color: var(--primary);"><i class="fa-solid fa-file-invoice"></i> Statement</button>
                          ` : ''}
                          ${(c.id !== 'cust-walkin' && !this.isCashier()) ? `
                            <button class="btn btn-outline btn-sm" onclick="app.adjustCustomerLoyalty(${this.jsStr(c.id)})" title="Gift or correct this member's points" style="color: #b45309; border-color: #f59e0b;"><i class="fa-solid fa-gift"></i> Points</button>
                          ` : ''}
                          <button class="btn btn-outline btn-sm" onclick="app.editCustomer(${this.jsStr(c.id)})" title="Edit Details"><i class="fa-solid fa-pen"></i> Edit</button>
                          ${(c.id !== 'cust-walkin' && !this.isCashier()) ? `
                            <button class="btn btn-outline btn-sm" onclick="app.confirmDeleteCustomer(${this.jsStr(c.id)}, ${this.jsStr(c.name)})" style="color: var(--danger); border-color: var(--danger-border);" title="Delete Customer"><i class="fa-solid fa-trash"></i></button>
                          ` : ''}
                        </div>
                      </td>
                    </tr>
                  `;
                }).join('') : `
                  <tr>
                    <td colspan="7" style="text-align: center; padding: 2.5rem; color: var(--slate-400);">
                      <i class="fa-solid fa-user-xmark" style="font-size: 2rem; margin-bottom: 0.5rem; display: block;"></i>
                      ${hasActiveFilters ? 'No customers matched your filter criteria.' : 'No customer accounts registered yet.'}
                    </td>
                  </tr>
                `}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;
  },

  bindCustomersEvents() {
    const searchInput = document.getElementById('customers-search-input');
    if (searchInput) {
      let debounceTimer = null;
      searchInput.addEventListener('input', (e) => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => {
          this.custSearchQuery = e.target.value;
          this.renderCurrentView();
          const nextInput = document.getElementById('customers-search-input');
          if (nextInput) {
            nextInput.focus();
            nextInput.setSelectionRange(nextInput.value.length, nextInput.value.length);
          }
        }, 220);
      });
    }

    const balFilter = document.getElementById('customers-balance-filter');
    if (balFilter) {
      balFilter.addEventListener('change', (e) => {
        this.custBalanceFilter = e.target.value;
        this.renderCurrentView();
      });
    }

    const tierFilter = document.getElementById('customers-tier-filter');
    if (tierFilter) {
      tierFilter.addEventListener('change', (e) => {
        this.custTierFilter = e.target.value;
        this.renderCurrentView();
      });
    }

    const sortFilter = document.getElementById('customers-sort-filter');
    if (sortFilter) {
      sortFilter.addEventListener('change', (e) => {
        this.custSortFilter = e.target.value;
        this.renderCurrentView();
      });
    }
  },

  openNewCustomerModal() {
    document.getElementById('cust-form-id').value = '';
    document.getElementById('cust-form-name').value = '';
    document.getElementById('cust-form-phone').value = '';
    document.getElementById('cust-form-email').value = '';
    document.getElementById('cust-form-address').value = '';
    document.getElementById('cust-form-balance').value = '0.00';
    document.getElementById('cust-form-notes').value = '';
    document.getElementById('customer-modal').classList.add('active');
  },

  editCustomer(customerId) {
    const c = this.customers.find(item => item.id === customerId);
    if (!c) return;

    document.getElementById('cust-form-id').value = c.id;
    document.getElementById('cust-form-name').value = c.name;
    document.getElementById('cust-form-phone').value = c.phone || '';
    document.getElementById('cust-form-email').value = c.email || '';
    document.getElementById('cust-form-address').value = c.address || '';
    document.getElementById('cust-form-balance').value = c.balance || 0;
    document.getElementById('cust-form-notes').value = c.notes || '';
    document.getElementById('customer-modal').classList.add('active');
  },

  closeCustomerModal() {
    document.getElementById('customer-modal').classList.remove('active');
  },

  async saveCustomerForm() {
    const id = document.getElementById('cust-form-id').value || ('cust_' + Math.random().toString(36).substring(2, 10));
    const isEdit = Boolean(document.getElementById('cust-form-id').value);
    const name = document.getElementById('cust-form-name').value.trim();

    if (!name) {
      this.showToast('Customer name is required.', 'warning');
      return;
    }

    const payload = {
      id,
      name,
      phone: document.getElementById('cust-form-phone').value.trim(),
      email: document.getElementById('cust-form-email').value.trim(),
      address: document.getElementById('cust-form-address').value.trim(),
      balance: parseFloat(document.getElementById('cust-form-balance').value) || 0,
      notes: document.getElementById('cust-form-notes').value.trim()
    };

    if (isEdit) {
      const idx = this.customers.findIndex(c => c.id === id);
      if (idx >= 0) {
        this.customers[idx] = { ...this.customers[idx], ...payload };
        await localDB.customers.put(this.customers[idx]);
      }
    } else {
      this.customers.push(payload);
      await localDB.customers.put(payload);
    }

    if (this.isOnline) {
      try {
        await this.apiFetch('api/endpoints/customers.php', {
          method: isEdit ? 'PUT' : 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
      } catch (err) {
        await localDB.sync_outbox.add({ entity: 'customer', action: isEdit ? 'UPDATE' : 'CREATE', data: payload, timestamp: new Date().toISOString(), synced: 0 });
      }
    } else {
      await localDB.sync_outbox.add({ entity: 'customer', action: isEdit ? 'UPDATE' : 'CREATE', data: payload, timestamp: new Date().toISOString(), synced: 0 });
    }

    this.closeCustomerModal();
    this.renderCurrentView();
    if (typeof this.broadcastSyncEvent === 'function') {
      this.broadcastSyncEvent('CUSTOMER_MUTATED', { action: isEdit ? 'UPDATE' : 'CREATE', customer: payload });
    }
    this.showToast('Customer saved successfully!', 'success');
  }
});
