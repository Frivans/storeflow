@echo off
setlocal EnableDelayedExpansion
title Stop StoreFlow POS
set "PORT=8095"
echo Stopping StoreFlow Background Server on port %PORT%...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":%PORT% " ^| findstr "LISTENING"') do (
    tasklist /FI "PID eq %%a" 2>nul | findstr /i "php.exe" >nul 2>nul
    if !ERRORLEVEL! equ 0 (
        taskkill /F /PID %%a >nul 2>nul
    )
)
echo StoreFlow Server Stopped.
ping 127.0.0.1 -n 2 >nul
